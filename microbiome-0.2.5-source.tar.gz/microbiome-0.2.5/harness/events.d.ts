import '@deepseek-ai/dsh-jobs/types'
import '@deepseek-ai/dsh-session/types'
declare module '@deepseek-ai/dsh-jobs/types' {
  interface JobKindMap { microbiome: 'microbiome' }
}
declare module '@deepseek-ai/dsh-session/types' {
  interface SessionEventMap {
    'microbiome/model-request': { attempt: number; request: unknown }
    'microbiome/model-result': { attempt: number; result: unknown }
    'microbiome/model-error': { attempt: number; error: string; code: string; usage: unknown }
  }
}
