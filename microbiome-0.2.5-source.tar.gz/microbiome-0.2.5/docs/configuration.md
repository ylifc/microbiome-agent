# Microbiome 配置说明

默认由用户正在使用的宿主负责模型选择和认证。Microbiome 不要求填写模型名、API Key 或云服务提供商，也不要求创建 `.env`。
完整使用步骤见 [中文手册](Microbiome_Agent_完整使用手册.md)。

## 项目路径

```bash
microbiome init --project /work/project --raw-data /data/reads --database /data/databases --output /work/results
microbiome call project.inspect --json '{"project":"/work/project"}'
```

初始化时显式指定路径，之后以 `project_config.yaml` 和确认后的输入清单为准。切换宿主时仍打开同一计算端项目，不重新推断数据来源。
数据库与索引使用持久目录，不能放入 Conda 环境。服务器路径与桌面本机路径分别属于各自机器；远程工作区应在执行服务器上启动服务。

## 模型与工具连接

| 方式 | 配置内容 | 模型负责人 |
| --- | --- | --- |
| Skill + CLI | 导入导出的 Skill，并使 CLI 可用 | 当前宿主 |
| stdio MCP | 导入导出的 Python 启动命令 | 当前宿主 |
| HTTP MCP | `http://127.0.0.1:8765/mcp` | 当前宿主 |
| 直接模型端口 | `--endpoint http://127.0.0.1:8000` | 已有兼容服务；自动发现模型 |

```bash
microbiome export --host codex --output /absolute/new/adapter
microbiome mcp --transport http --port 8765
microbiome endpoint --endpoint http://127.0.0.1:8000 --check
microbiome endpoint --endpoint http://127.0.0.1:8000 --project /work/project
```

HTTP MCP 限本机回环绑定；没有内置远程认证、SSH 隧道或公开服务部署。
直接模型端口须支持 `/v1/models` 与 `/v1/chat/completions`，发现过程会进行短推理检查。
连接失败、没有兼容模型或要求客户端认证时给出具体错误；不会读取宿主私有凭据或自动连接别处。
服务认证问题应由已有服务/宿主解决，默认接入不新增 API Key 填写步骤。

## 执行设置

资源与数据路径首先使用持久化项目配置。`MICROBIOME_TIMEOUT_SECONDS` 等执行配置仍可用于库层兼容；它们不改变生产冻结锁。
软件环境创建由已批准的依赖计划决定，默认允许在合法维护阶段安装；生产阶段始终禁止安装、下载、升级和修复。
线程、内存和 GPU 预算通过任务参数指定，必须满足预检与冻结执行规则。

## Python 集成

可给现有 A1 分析协调器注入已经连接的模型对象，无需重新创建提供商客户端。
辅助工具也需模型时，用同一上下文包住初始化与整个会话：

```python
from microbiome.agent import A1
from microbiome.harness.model import use_host_model

# connected_model 由调用方已有的宿主/端口适配器提供。
with use_host_model(connected_model):
    agent = A1(model_client=connected_model, path="/work/agent-data")
    for event in agent.go_stream("介绍项目当前状态"):
        print(event)
```

`harness.model` 是兼容保留的内部模块名，这段代码不会启动旧工作台。
默认 `get_llm()` 没有已连接模型时立即报告 `HOST_MODEL_NOT_ATTACHED`，不会选择备用云模型。

## 历史配置迁移

旧 `MICROBIOME_LLM`、`MICROBIOME_LLM_MODEL`、`MICROBIOME_SOURCE`、`MICROBIOME_CUSTOM_BASE_URL` 与 `MICROBIOME_CUSTOM_API_KEY` 默认不生效。
只有显式设置 `MICROBIOME_LEGACY_MODEL_CONFIG=1` 才读取这组旧环境变量；明确传入旧 Python 库模型参数的用法仍保留兼容。
正常宿主与端口接入不使用这个开关。旧配置文件可保留归档，不必把旧账户信息复制到新配置。

## 常见问题

- `HOST_MODEL_NOT_ATTACHED`：从宿主调用 MCP/CLI，或使用 `microbiome endpoint` 接入已运行服务；裸 `A1()` 不会自行选择模型。
- 端口无法连接：检查服务运行在哪台机器、是否监听指定地址，以及该端口是 MCP 还是模型 API。
- 本地数据不存在：修正清单或路径，不会自动改成 SRA 下载。
- 资源漂移或不完整：在独立维护阶段修复、验证并重新冻结，生产不自动修改资源。
- 宿主重启：使用相同项目和 job ID 查询任务；连接重建不会自动重新提交分析。
