# 发行包安装与自检

0.2.4 发行包将 Microbiome 的完整运行源码、测试、流程参考、资源与宿主 Skill、文档和宿主模板放在一起。数量和文件内容以本次构建实际扫描结果与 SHA256 清单为准。预算维护、检查点、资源入口一致性和路径修复见 [0.2.4 发行说明](releases/0.2.4.md)及[维护操作](agent_maintenance.md)；阶段文件权限见 [0.2.1](releases/0.2.1.md)，绘图能力见 [0.2.0](releases/0.2.0.md)。

本项目的固定 ZIP 交付位置是 `packaged/microbiome-latest.zip`，校验文件为 `packaged/microbiome-latest.zip.sha256`；`packaged/CURRENT` 指向对应的版本目录。0.2.4 ZIP 内有 `microbiome-0.2.4/bundle/` 和独立的 `validation/` 证据目录。校验文件记录完整 ZIP 的 SHA256，bundle 自身另有逐文件清单。

科学软件、数据库、真实测序数据及用户账户不随包复制；安装这些资源仍需当前项目已批准的依赖计划。旧构建目录和 `github_upload` 快照不是当前源码，不重复打包。

## 目录用途

| 路径 | 内容 |
| --- | --- |
| `bundle/source/` | 当前运行源码、测试、构建脚本、环境描述和文档的完整发布快照 |
| `bundle/source/docs/` | 历史 0.2.0 Word 手册、当前 Markdown 发行/维护说明和 Skill 索引；相对源码链接在此保持有效 |
| `bundle/docs/README.md` | 指向完整文档的导航 |
| `bundle/wheels/` | 当前 Agent 的安装 wheel |
| `bundle/wheelhouse/` | 离线版的 Python 运行及源码构建依赖 |
| `bundle/skills/` | 可浏览的资源与宿主 Skill 原文镜像 |
| `bundle/workflows/` | 每个流程的 YAML 元数据与完整指南 |
| `bundle/integrations/templates/` | 宿主 Skill、Codex 与 VS Code 配置模板 |
| `bundle/catalog/` | 源码、依赖、Skills、流程和宿主模板的机器可读清单 |
| `bundle/examples/portable_demo/` | 安装后可执行的合成数据演示 |
| `bundle/manifest.json` | 每个文件的 SHA256、构建环境和能力清单 |
| 发行目录中的压缩包与 `SHA256SUMS` | 方便复制和校验的完整安装包 |
| 发行目录中的 `validation/` | 本次实际安装与模拟运行的证据；独立于不可变 bundle |

源码中的文档相对路径以 `source/` 为项目根目录。Word 手册保留为历史 0.2.0 文档，未重新生成；最新接口差异以 [0.2.4](releases/0.2.4.md)与当前维护说明为准。不要单独移动 Word 手册后期待源码链接仍能定位；共享时保留发行目录结构。

## 安装

在 Linux 或 WSL 中，直接使用发行目录时进入 `bundle/`；解压 ZIP 后进入 `microbiome-0.2.4/bundle/`。兼容的 tar.gz 包解压后目录名为 `microbiome-portable/`。运行：

```bash
bash install.sh
"$HOME/.local/share/microbiome-runtime/bin/microbiome" doctor
```

也可指定全新目录：

```bash
bash install.sh --prefix /absolute/new/microbiome-runtime
/absolute/new/microbiome-runtime/bin/microbiome doctor
```

离线版默认使用随包依赖且不访问包索引，要求匹配构建记录中的 Python 次版本、操作系统和架构。本次提供 Linux x86_64 / Python 3.13 离线依赖；其他环境可用 `source/` 重新构建。源码声明 Python 3.11+，不表示本次已验证所有操作系统和 Python 版本。

原生命令执行还需要主机已有 `bubblewrap`（`bwrap`）及可用的 Linux 用户命名空间；它属于主机组件，不是 wheel 中的 Python 依赖。`doctor` 显示该组件路径，实际执行时建立隔离边界；边界无法建立时停止，不退回无限制执行。需求记录、状态查看和维护导出仍可使用。

安装器创建独立 venv，拒绝覆盖非受管目录，核对入口映射后再执行自检，不继承系统第三方包、不写入模型配置。升级用 `bash upgrade.sh --prefix 原目录`；卸载用 `bash uninstall.sh --prefix 原目录`，会保留运行环境和分析数据。

升级不会替换已经运行的旧进程。新的维护 schema 和恢复工具须由升级后的进程加载；先保存任务标识并核对实际版本，避免把旧进程的工具清单当成新版本能力。便携 JSON CLI/MCP 的 `project.recovery` 只读取恢复状态；Harness 的 `microbiome_resume_planning` 才会调用宿主模型继续规划，二者都不生成科学批准。

## 简单任务与宿主接入

```bash
microbiome stats /data/reads/input.fasta --output /work/new-statistics
microbiome stats /data/reads/R1.fastq.gz /data/reads/R2.fastq.gz \
  --paired --output /work/new-paired-statistics
microbiome export --host codex --output /work/new-codex-adapter
```

没有把安装目录加入 PATH 时，使用上面的完整 `bin/microbiome` 路径。输出父目录须已存在，输出目录本身须为新目录且位于原始输入目录之外。

统计任务不用模型或科研项目，提供记录数、长度、GC 和配对核验；累计上限为 256 MiB 解压内容及 200 万条记录（双端两侧合计）。它不会批准其他分析、推断质量编码或生成分类结论。
宿主导出支持 Codex、VS Code 和 WorkBuddy，导出目录包含 `microbiome-workflow` 与 `microbiome-visualization` 两个完整 Skill。MCP 与已有模型端口的区别见[接入说明](portable_integration.md)。Python 树图依赖随标准运行环境安装；R 解释器及可选 R 包属于单独的机器可读依赖范围，必须先发现和复用现有环境，不能因安装 Agent 就自动安装全部绘图软件。

## 模拟安装后的验证

在任意工作目录，以 Python 3.11+ 运行发行包自检脚本。`--prefix` 使用安装器记录定位实际 venv，不会扫描或更换模型：

```bash
python /absolute/bundle/scripts/verify_portable_release.py \
  --bundle /absolute/bundle \
  --prefix /absolute/installed/microbiome-runtime \
  --output /absolute/new/verification-results
```

脚本核对整个 bundle 的哈希，确认导入来自全新 venv，逐文件比较已安装代码与源码清单，并检查依赖一致性、五个公开启动命令、流程目录、宿主导出、项目初始化及轻量任务。`--prefix` 还会核对安装目录中的启动符号链接和受管记录；仅 Python 模块能导入不足以判定安装成功。
人工 FASTA 的预期值是 2 条序列、16 个碱基、8 个 G/C 和 14 个非歧义碱基；双端文件各含 2 条记录。坏 FASTQ、缺失输入和重复输出目录应失败，原始文件保持不变。

完整冻结生命周期另用合成数据测试输入确认、依赖范围、预检、冻结、生产批准与确定性重放。科研流程还需在真实任务上验证工具、数据库和质量指标，工程测试不等同于所有科学路线已验收。

## 重建与校验

```bash
python source/scripts/build_portable_release.py --verify /absolute/bundle
python source/scripts/build_portable_release.py \
  --output /absolute/new/release --offline-deps \
  --wheel-cache /absolute/bundle/wheelhouse --no-index
```

重建环境需要先安装 `build-requirements.in` 和 `requirements.in`，离线时使用 `wheelhouse` 与 `requirements.lock`。构建器不会覆盖非空发行目录，只有全部清单、镜像与 wheel 内容核验通过才发布成品。生成的包具有自己的构建时间、源码指纹与校验和。
