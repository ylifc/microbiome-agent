"""Build the editable overview mind map and Word handbook from the Markdown source."""
from __future__ import annotations

import re
import textwrap
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "Microbiome_Agent_使用手册_中英双语.md"
OUTPUT = ROOT / "Microbiome_Agent_使用手册_中英双语.docx"
MAP = ROOT / "mindmap.png"
FONT = Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc")
FONT_BOLD = Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc")


def make_map() -> None:
    width, height = 1900, 1320
    canvas = Image.new("RGB", (width, height), "#F6F8FB")
    draw = ImageDraw.Draw(canvas)
    title_font = ImageFont.truetype(str(FONT_BOLD), 48)
    center_font = ImageFont.truetype(str(FONT_BOLD), 45)
    center_sub = ImageFont.truetype(str(FONT), 27)
    node_title = ImageFont.truetype(str(FONT_BOLD), 31)
    node_body = ImageFont.truetype(str(FONT), 24)

    draw.text((width // 2, 24), "Microbiome Agent 总体使用思维导图", font=title_font,
              fill="#152A3A", anchor="ma")
    # Put the system goal at the top and branch into two readable columns.
    # The previous radial layout crowded the central node at Word scale.
    center = (510, 105, 1390, 305)
    nodes = [
        (48, 380, 880, 570, "研究设计  Research design", ["问题 · 样本单位 · 备选方法", "限制 · 目标图表 · 资源成本"], "#3F7CAC", "left"),
        (48, 585, 880, 775, "输入与元数据  Inputs", ["本地优先 manifest · 路径核验", "样本身份 · 分组 · 独立实验单位"], "#4E9A8A", "left"),
        (48, 790, 880, 980, "方法与资源  Methods", ["22 条流程参考 · 软件/数据库 Skill", "核查 READY 状态和适用条件"], "#8561A8", "left"),
        (48, 995, 880, 1185, "绘图与功能组学  Figures", ["群落 · 系统发育 · MAG/contig", "KEGG/NR/COG/arCOG · TPM · WGCNA"], "#D17B43", "left"),
        (1020, 380, 1852, 570, "方案和审批  Review", ["计划 · 参数 · 输入输出 · 依赖范围", "查看完整材料与指纹后作真实决定"], "#3F7CAC", "right"),
        (1020, 585, 1852, 775, "小试与冻结  Pilot", ["验证代表性输入、日志和验收条件", "通过后冻结参数与工具数据库"], "#4E9A8A", "right"),
        (1020, 790, 1852, 980, "生产与任务  Production", ["稳定 request ID · 持久 job · 日志", "状态检查 · 结果审计 · 公开恢复"], "#8561A8", "right"),
        (1020, 995, 1852, 1185, "宿主与接口  Integration", ["Codex · VS Code · WorkBuddy", "JSON CLI · MCP · 显式模型端口"], "#D17B43", "right"),
    ]

    # Connectors are drawn before the cards so every endpoint stays behind a node.
    cx, cy = (center[0] + center[2]) // 2, (center[1] + center[3]) // 2
    left_stem, right_stem, branch_y = 460, 1440, 345
    draw.line([(cx, center[3]), (cx, branch_y), (left_stem, branch_y)], fill="#91A2AF", width=7)
    draw.line([(cx, branch_y), (right_stem, branch_y)], fill="#91A2AF", width=7)
    draw.line([(left_stem, branch_y), (left_stem, (nodes[3][1] + nodes[3][3]) // 2)], fill="#91A2AF", width=7)
    draw.line([(right_stem, branch_y), (right_stem, (nodes[7][1] + nodes[7][3]) // 2)], fill="#91A2AF", width=7)
    for node in nodes:
        x1, y1, x2, y2, _, _, color, side = node
        cy_node = (y1 + y2) // 2
        px = x2 if side == "left" else x1
        sx = left_stem if side == "left" else right_stem
        draw.line([(sx, cy_node), (px, cy_node)], fill=color, width=6)
        draw.ellipse((px - 8, cy_node - 8, px + 8, cy_node + 8), fill=color)

    draw.rounded_rectangle(center, radius=42, fill="#183B56", outline="#183B56", width=5)
    draw.text((cx, cy - 50), "Microbiome Agent", font=center_font, fill="white", anchor="mm")
    draw.text((cx, cy + 18), "微生物分析工作流引擎", font=center_sub, fill="#DDEBF4", anchor="mm")
    draw.text((cx, cy + 72), "宿主提供对话 · 服务负责状态与执行证据", font=center_sub,
              fill="#DDEBF4", anchor="mm")

    for x1, y1, x2, y2, heading, body, color, _ in nodes:
        draw.rounded_rectangle((x1, y1, x2, y2), radius=28, fill="white", outline=color, width=5)
        draw.rounded_rectangle((x1, y1, x2, y1 + 12), radius=8, fill=color)
        draw.text((x1 + 30, y1 + 40), heading, font=node_title, fill="#183247")
        for index, line in enumerate(body):
            draw.text((x1 + 34, y1 + 96 + index * 39), line, font=node_body, fill="#435669")

    canvas.save(MAP, format="PNG", optimize=True, dpi=(220, 220))


def set_cell_shading(cell, fill: str) -> None:
    shading = OxmlElement("w:shd")
    shading.set(qn("w:fill"), fill)
    cell._tc.get_or_add_tcPr().append(shading)


def set_table_borders(table) -> None:
    tbl_pr = table._tbl.tblPr
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        element = OxmlElement(f"w:{edge}")
        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), "4")
        element.set(qn("w:space"), "0")
        element.set(qn("w:color"), "D9DDE3")
        borders.append(element)
    tbl_pr.append(borders)


def set_repeat_table_header(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    repeat = OxmlElement("w:tblHeader")
    repeat.set(qn("w:val"), "true")
    tr_pr.append(repeat)


def set_font(run, *, name="Noto Sans CJK SC", size=10.2, bold=None, color=None) -> None:
    run.font.name = name
    run._element.rPr.rFonts.set(qn("w:eastAsia"), name)
    run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if color:
        run.font.color.rgb = RGBColor.from_string(color)


def clean_markdown(text: str) -> str:
    text = re.sub(r"!\[([^]]*)\]\([^)]*\)", r"\1", text)
    text = re.sub(r"\[([^]]+)\]\((?:<)?([^)>]+)(?:>)?\)", r"\1（\2）", text)
    text = text.replace("**", "").replace("`", "")
    return text.strip()


def table_cells(line: str) -> list[str]:
    return [part.strip() for part in line.strip().strip("|").split("|")]


def render_markdown() -> None:
    doc = Document()
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(0.65)
    section.bottom_margin = Inches(0.62)
    section.left_margin = Inches(0.72)
    section.right_margin = Inches(0.72)
    section.header_distance = Inches(0.30)
    section.footer_distance = Inches(0.30)

    styles = doc.styles
    title_style = styles["Title"]
    title_ppr = title_style._element.get_or_add_pPr()
    title_border = title_ppr.find(qn("w:pBdr"))
    if title_border is not None:
        title_ppr.remove(title_border)
    title_style.font.name = "Noto Sans CJK SC"
    title_style._element.rPr.rFonts.set(qn("w:eastAsia"), "Noto Sans CJK SC")
    title_style.font.color.rgb = RGBColor(22, 42, 58)
    title_style.font.bold = True
    normal = styles["Normal"]
    normal.font.name = "Noto Sans CJK SC"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "Noto Sans CJK SC")
    normal.font.size = Pt(10.2)
    normal.font.color.rgb = RGBColor(36, 48, 59)
    normal.paragraph_format.space_after = Pt(5)
    normal.paragraph_format.line_spacing = 1.12
    for style_name, size in (("Heading 1", 17), ("Heading 2", 13.5), ("Heading 3", 11.5)):
        style = styles[style_name]
        style.font.name = "Noto Sans CJK SC"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "Noto Sans CJK SC")
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = RGBColor(20, 36, 49)
        style.paragraph_format.keep_with_next = True
        style.paragraph_format.space_before = Pt(11 if style_name == "Heading 1" else 8)
        style.paragraph_format.space_after = Pt(4)

    header = section.header.paragraphs[0]
    header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    r = header.add_run("MICROBIOME AGENT   |   使用总览与操作手册   |   2026.10")
    set_font(r, size=8, color="73808C")
    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = footer.add_run("Microbiome Agent  ·  ")
    set_font(run, size=8, color="73808C")
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), "PAGE")
    footer._p.append(fld)

    lines = SOURCE.read_text(encoding="utf-8").splitlines()
    i = 0
    in_code = False
    code_lines: list[str] = []
    seen_image = False
    while i < len(lines):
        raw = lines[i]
        line = raw.strip()
        if line.startswith("```"):
            if not in_code:
                in_code = True
                code_lines = []
            else:
                p = doc.add_paragraph()
                p.paragraph_format.left_indent = Inches(0.18)
                p.paragraph_format.right_indent = Inches(0.10)
                p.paragraph_format.space_before = Pt(2)
                p.paragraph_format.space_after = Pt(7)
                p.paragraph_format.keep_together = True
                r = p.add_run("\n".join(code_lines))
                set_font(r, name="DejaVu Sans Mono", size=8.3, color="263746")
                in_code = False
            i += 1
            continue
        if in_code:
            code_lines.append(raw.rstrip())
            i += 1
            continue
        if not line or line == "---":
            i += 1
            continue
        if line.startswith("!["):
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_before = Pt(2)
            p.add_run().add_picture(str(MAP), width=Inches(7.0))
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_after = Pt(1)
            set_font(p.add_run("图 1  Microbiome Agent 的设计、运行与结果验收路径"), size=8.5, color="66727E")
            seen_image = True
            doc.add_page_break()
            i += 1
            continue
        if line.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                row = table_cells(lines[i])
                if row and not all(set(cell) <= {"-", ":", " "} for cell in row):
                    rows.append(row)
                i += 1
            if not rows:
                continue
            cols = max(len(row) for row in rows)
            table = doc.add_table(rows=1, cols=cols)
            table.autofit = True
            table.style = "Table Grid"
            for row_idx, row_data in enumerate(rows):
                cells = table.rows[0].cells if row_idx == 0 else table.add_row().cells
                for col, cell in enumerate(cells):
                    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
                    value = clean_markdown(row_data[col]) if col < len(row_data) else ""
                    cell.text = value
                    for paragraph in cell.paragraphs:
                        paragraph.paragraph_format.space_after = Pt(2)
                        paragraph.paragraph_format.space_before = Pt(2)
                        for run in paragraph.runs:
                            set_font(run, size=8.2, bold=(row_idx == 0), color=("FFFFFF" if row_idx == 0 else "2B3742"))
                    if row_idx == 0:
                        set_cell_shading(cell, "244D68")
                    elif row_idx % 2 == 0:
                        set_cell_shading(cell, "F2F6F8")
            set_repeat_table_header(table.rows[0])
            for row in table.rows:
                cant_split = OxmlElement("w:cantSplit")
                row._tr.get_or_add_trPr().append(cant_split)
            set_table_borders(table)
            doc.add_paragraph().paragraph_format.space_after = Pt(2)
            continue
        heading = re.match(r"^(#{1,3})\s+(.+)$", line)
        if heading:
            depth = len(heading.group(1))
            text = clean_markdown(heading.group(2))
            if depth == 1 and not doc.paragraphs:
                p = doc.add_paragraph(style="Title")
                p.paragraph_format.space_after = Pt(4)
                # Word's built-in Title style can inherit a decorative rule.
                # Explicitly remove it so the cover remains clean in LO/Word.
                ppr = p._p.get_or_add_pPr()
                border = ppr.find(qn("w:pBdr"))
                if border is not None:
                    ppr.remove(border)
                r = p.add_run(text)
                set_font(r, size=23, bold=True, color="162A3A")
            else:
                p = doc.add_paragraph(clean_markdown(heading.group(2)), style=f"Heading {depth}")
            i += 1
            continue
        if line.startswith("- "):
            p = doc.add_paragraph(style="List Bullet")
            p.paragraph_format.space_after = Pt(3)
            set_font(p.add_run(clean_markdown(line[2:])), size=9.8)
            i += 1
            continue
        if re.match(r"^\d+\.\s", line):
            p = doc.add_paragraph(style="List Number")
            p.paragraph_format.space_after = Pt(3)
            set_font(p.add_run(clean_markdown(re.sub(r"^\d+\.\s", "", line))), size=9.8)
            i += 1
            continue
        # Fold Markdown soft line breaks into one readable paragraph.
        paragraph_lines = [line]
        i += 1
        while i < len(lines):
            nxt = lines[i].strip()
            if not nxt or nxt == "---" or nxt.startswith(("#", "|", "```", "![", "- ")) or re.match(r"^\d+\.\s", nxt):
                break
            paragraph_lines.append(nxt)
            i += 1
        p = doc.add_paragraph()
        p.paragraph_format.widow_control = True
        p.paragraph_format.keep_together = False
        text = clean_markdown(" ".join(paragraph_lines))
        set_font(p.add_run(text), size=10.0)

    if not seen_image:
        raise ValueError("Mind map image must be present at the beginning of the handbook")
    doc.core_properties.title = "Microbiome Agent 使用总览与操作手册"
    doc.core_properties.subject = "Microbiome Agent 功能、接口、分析生命周期与绘图技能"
    doc.core_properties.author = "Microbiome project documentation"
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    doc.save(OUTPUT)


if __name__ == "__main__":
    make_map()
    render_markdown()
    print(OUTPUT)
