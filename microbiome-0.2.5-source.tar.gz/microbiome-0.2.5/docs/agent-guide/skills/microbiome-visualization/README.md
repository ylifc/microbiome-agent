# 绘图技能正式资产 / Canonical visualization skill

本目录仅作导航，不是可安装技能副本。完整技能、脚本、图谱和依赖声明统一维护于 [microbiome-visualization](../../../../microbiome/integrations/templates/skills/microbiome-visualization/SKILL.md)。

安装后使用 `microbiome export --host codex --output /new/adapter`（也支持 `vscode`、`workbuddy`）导出全部正式宿主技能，再按宿主规则导入。发行包中的 `skills/host/` 是同一正式资产的校验镜像。不要只复制本导航目录。

This directory is navigation only. Exported host skills, wheel package data and `skills/host/` in a release all originate from the canonical package assets linked above. Export does not install R or optional scientific packages.
