# Microbiome Agent guide and release documentation

This directory contains the user guide, the overall workflow mind map, and bilingual GitHub documentation for the current Microbiome software project.

本目录收录当前 Microbiome 软件项目的总览手册、总体工作思维导图，以及供 GitHub 发布使用的中英文项目说明。

## Files

- `Microbiome_Agent_使用手册_中英双语.docx` — Word handbook with the overall mind map at the beginning.
- `Microbiome_Agent_使用手册_中英双语.md` — editable source for the handbook.
- `mindmap.mmd` — editable Mermaid source for the overview map.
- `mindmap.png` — high-resolution map embedded in the Word handbook.
- `README_GitHub_双语.md` — bilingual repository landing page and usage overview.
- `skills/microbiome-visualization/README.md` — navigation to the canonical installable visualization skill, figure atlases, R/Python recipes and local tools.

The visualization skill is guidance plus narrowly scoped scripts. It does not install plotting packages, annotate genes, run WGCNA, or validate every scientific route by itself. Check the installed tools, databases, input contracts, and analysis approvals for each project.

