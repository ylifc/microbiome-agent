# Full refactor execution plan and status

This document is the durable implementation record for the full-process microbial bioinformatics agent refactor.

## Completed milestones

1. Added an explicit persisted lifecycle from path confirmation through completion/cancellation.
2. Added versioned requirements, append-only decisions, compact conversation summaries, and invalidation semantics.
3. Extended read-only discovery to FASTA/FASTQ format, pairing, validity, duplicates, tools, environments, and database inventory.
4. Added versioned plan artifacts, local evidence registry, explicit plan confirmation, dependency-gap reporting, and install approval.
5. Bound bootstrap and database resolution to the current confirmed requirements and plan fingerprints.
6. Added persistent tool/database knowledge profiles, error signatures, bounded repair attempts, and verified-only fix lookup.
7. Added cross-process database resource locks while retaining resumable and atomic acquisition behavior.
8. Replaced leading-record pilots with deterministic, format-aware, paired-synchronized 10% logical-record sampling and disk preflight.
9. Added isolated pre-test directories, per-node command records, logs, assertions, checkpoints, and regression suites.
10. Added requirements-bound immutable freeze artifacts, pipeline hashes/versions, and a generated replay entry point.
11. Hardened production preflight, output isolation, branch-aware failure containment, checkpoint resume, and final reports.
12. Added regression tests for the strict lifecycle and updated operator documentation.
13. Added persisted production approval states, five-way natural-language intent classification, and approval records bound to requirements version plus pipeline hash/version.
14. Connected the conversational confirmation gate to an automatic `ProductionController` → read-only preflight → deterministic executor path; validated structured projects are frozen internally.
15. Added a frozen RAW-data input contract and full-dataset target inventory. Production always roots input selection at the original `RAW_DATA_PATH`; pilot subset paths are automatically rebound and cannot leak into production manifests.

## Acceptance criteria

- All required fields and confirmation gates are persisted and testable outside chat context.
- A production run cannot begin unless the current requirements, plan, tools, databases, and validation all match the frozen hash chain.
- The default pre-test is exactly 10% by logical record count, deterministic, format-correct, and synchronized for paired reads.
- A failed branch does not silently change tools/parameters and does not prevent independent DAG branches from running.
- A changed requirement or repaired production failure cannot reuse a stale validation or lock.
- Full repository tests and lint checks pass before release.
- A user approval is required for production and becomes invalid after any requirement or pipeline change.
- The normal conversational workflow never asks the user to run `microbiome-pipeline`, freeze a lock, or edit a persisted artifact.
- All target sequence files frozen from `RAW_DATA_PATH` are scheduled; no production input can resolve under `pre_test_run/input_subset`.

## Operational follow-up

Real microbial workflows should add tool-specific output assertions and database marker contracts to each plan. External evidence may be recorded in `plans/evidence_registry.yaml`; if unavailable, its status must remain explicit rather than being represented as reviewed evidence.
