# 绘图规划、执行与视觉复核

绘图是可选能力。复制文件、序列统计和没有绘图需求的旧计划不会新增图形要求。绘图 Skill 与 scripts 位于 `microbiome/integrations/templates/skills/microbiome-visualization/`；依赖声明不代表软件已安装。新增依赖仍经过现有发现、批准和 bootstrap 流程。

## 规划参考

`planning.context` 接受可选 `visualization_topics`，值为 `tables`、`phylogeny`、`functional`、`wgcna` 的不重复列表。未明确指定时按绘图请求选择；仅“分析”不会触发。声明 `figure_contract` 的步骤不能用空 topics 绕过参考。

返回的 `context.visualization` 含完整所选说明、版本、内容指纹和脚本哈希；同一内容保存在项目 planning receipt 中。计划声明：

```json
{
  "visualization_topics": ["tables"],
  "visualization_decision": {
    "disposition": "use",
    "reason": "展示已计算的记录长度，保留原始单位并单独审阅图像。"
  },
  "workflow_reference_evidence": {
    "path": "/absolute/project/plans/planning_evidence/actual-receipt.json",
    "context_fingerprint": "使用实际 planning.context 返回值"
  }
}
```

`disposition` 可为 `use`、`adapt`、`not_applicable`；前两者需要实际 figure 步骤，后者不能保留 figure 步骤。应用检查参考实际交付、输入绑定和指纹，不声称验证模型思考。仅查询参考可用 `microbiome call visualization.reference --json '{"topics":["tables"]}'`。

## DAG 图形合同

R 和 Python renderer 均可作为现有 DAG 命令运行。每个图形步骤按通常方式声明 `input`、`output`、经审阅的真实 adapter、软件环境和资源。额外添加 `figure_contract`；其中 input/output 都引用本步骤映射的键，不是文件名：

```json
{
  "schema_version": 1,
  "figure_id": "sequence_lengths",
  "kind": "bar",
  "dataset_kind": "synthetic",
  "source_scientific_status": "synthetic_fixture",
  "source_inputs": ["reads"],
  "source_evidence_inputs": [],
  "image_outputs": ["png", "svg"],
  "required_review_outputs": ["png", "svg"],
  "manifest_output": "figure_manifest",
  "quantity": "每条合成序列的长度",
  "units": "nt",
  "transformation": "none"
}
```

`output.figure_manifest` 必须是 `{run_dir}` 下新的 JSON 文件。renderer 只生成它负责的图像；命令成功后由引擎生成统一清单。源文件在运行前后完整哈希一致，图像需通过 PNG/SVG/PDF 结构检查。检查结构不证明可读性或科学有效性。图像、清单必须与输入分离、在该次 run 内，不能指向符号链接或覆盖已有文件。

基础 R `plot_table_base.R` 和 `plot_contig_functions.R` 的 DAG 命令必须显式加 `--allow-empty-output true`：引擎会预建声明图像的父目录，这个参数只允许严格为空的普通目录，包含隐藏文件的目录、目录或祖先符号链接、输入目录与覆盖均拒绝。独立运行省略该选项时仍要求新目录。将 PNG/PDF/SVG 的具体文件键写入 `image_outputs`，统一 JSON manifest 使用独立文件名，避免与 renderer 的本地清单重名。此选项不安装包、不改变分析/显示变换。

真实生物数据使用 `dataset_kind: biological`，必须声明非空 `source_evidence_inputs`。`source_scientific_status` 为 `unverified` 或 `validated`，它是有来源的声明，绘图模块不会独立认证来源结论。转录、DNA 丰度、原始计数、相对量及其单位不能相互冒充。

引擎自动添加 `figure_manifest` 断言，核验图像、源文件和计划合同。所有适用 pilot case 的图形需要单独视觉复核后才能冻结；普通执行成功不代替复核。图形合同、参考和 pilot review 指纹进入冻结锁。生产使用锁定合同，每次新运行得到自己的 preview，不能沿用 pilot 的视觉声明。

## 独立 renderer 与公共接口

已有 R/Python 图像也可通过 `microbiome call visualization.manifest --file registration.json` 注册。请求为 `{contract, inputs, outputs, renderer}`；`inputs`、`outputs` 是显式本地绝对路径映射，合同与上述相同。此操作不执行 renderer、不安装、不改变项目批准状态。

`microbiome call visualization.inspect --json '{"manifest":"/work/figures/figure.json"}'` 核验来源/图像/清单和已有 review，返回 `visual_status`、`manifest_sha256`、图像路径、必查 output 键及复核记录路径/指纹。添加 `"require_review": true` 可让尚未复核的图形明确失败。

MCP 提供同一个 `microbiome_visualization(action, arguments)`，action 为 `reference`、`manifest`、`inspect`、`review`；arguments 与各 JSON CLI 操作一致。此接口没有隐含渲染或安装。

## 实际视觉复核

先打开 `required_review_outputs` 对应的真实图片，检查预期显示大小、长标签、密集区域、图例、来源身份以及单位/变换；再提交 `visualization.review`。不得复制下面占位内容冒充已查看：

```json
{
  "manifest": "/work/figures/figure.json",
  "review": {
    "manifest_sha256": "实际 inspect 返回的 SHA256",
    "verdict": "pass",
    "reviewer": "实际审阅人或代理身份",
    "observations": "记录实际看到的标签、单位、图例和异常情况",
    "inspected_outputs": ["png", "svg"],
    "checks": {
      "labels_readable": true,
      "no_clipping": true,
      "legend_consistent": true,
      "identities_checked": true,
      "units_and_transformations_checked": true
    },
    "limitations": ["明确剩余限制；没有额外限制时可使用空列表"]
  }
}
```

使用 `microbiome call visualization.review --file actual-review.json`。复核会验证真实源文件和所有图像哈希、manifest 绑定、审阅者、观察记录和必查图覆盖，写独立 `*.review.json`，保留原 preview 清单不变。`visual_status: reviewed` 仅代表绑定的人工/代理声明与完整性检查；不是机器证明“看过”，不是科学验证，也不批准生产。

源表、图片或 manifest 变化后复核失效；新的生产运行需重新打开实际产物。改变设计、统计模型或筛选条件需要普通的新计划与验证，不能借绘图修改活动冻结流程。

有相同命令、输入/输出和合同的明确 FAILED 执行日志时，重试先将已知失败图像及清单归档到本次 run 的 `.figure-attempts/` 再渲染；没有这样的失败证据时不自动覆盖。局部修复必须连同属于该清单的 review 侧车归档。

`examples/portable_demo/plot_sequence_lengths.py` 是小型真实 Python renderer；测试中的 synthetic review 只是验证状态机的 fixture，不代表人工视觉验收。真实预览仍应在实际安装运行时生成并查看。
