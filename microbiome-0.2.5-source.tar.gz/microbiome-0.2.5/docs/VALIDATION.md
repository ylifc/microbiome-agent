# Microbiome 0.1.0 发布验收记录

日期：2026-09-09。验证使用本机新建的独立 venv、测试 DSH_HOME 和合成数据目录；未进入用户正在使用的 Harness 安装，也没有在另一台实体机器上测试。

## 已通过

- Python 冻结流程、跨样本与持久会话回归：47 项通过。
- Python 预检收尾、预检证据、模型兼容与初版桥接回归：36 项通过。
- Python 规划取证、资源契约、软件历史回归：89 项通过。
- 最终 NDJSON 桥接与路径绑定测试：7 项通过；包括真实子进程的独立预检确认、独立生产确认、生产阶段零模型调用及重复消息回执复用。包括资源模块先导入、随后绑定项目路径的回归；其中 5 项与上述回归重叠；本次累计覆盖至少 174 个不同 Python 测试。
- 最终注册表延迟绑定修复后，Skills 与桥接/路径测试合计 54 项通过。
- 修改适配器路径解析后复验冻结流程与跨样本：31 项通过。
- Node 原生测试：5 项通过，覆盖真实用户消息来源、重复调用、宿主路由、停止序列、工具调用格式及截断响应失败处理。
- 发布包独立安装：Linux x86_64 / Python 3.13 离线、Python 3.12 在线均通过 `pip check` 与安装 doctor。在线安装在 SOCKS 代理环境验证，独立 venv 的代理依赖先从包内初始化。
- 两个 Python 版本均从安装后的模块执行合成 FASTQ 流程：逐样本复制、跨样本计数、小数据预检、冻结、全量重放与恢复。one=20、two=30，验收套件 PASSED。
- 使用 npm 发布的 DeepSeek Harness 0.1.0-rc.8、Node 22.23.1 实际加载 Cordis preset，创建真实 Agent 并完成一次对话；验证作用域工具、后台 jobs、受管理 Python subprocess、宿主 `prepareCall` 模型服务、状态查询、同消息复用及扩展会话事件重放。
- 全局工具过滤修复后通过真实宿主复验：保留 microbiome_workflow、microbiome_project_status、job_output、job_list、job_kill；其他模式保持原工具。后来增加的无关全局工具在本模式执行时被拒绝。
- 安装器重复安装、升级、回退、卸载及重新安装通过；测试宿主配置与已有 venv 保留。
- 包内文件篡改和 manifest 路径越界均被拒绝。
- 新增 Python 文件通过 Ruff F/E9 检查；Node 插件语法检查、Shell 语法检查及相关 diff 空白检查通过。

## 资源目录

107 个软件 Skill、33 个数据库 Skill，结构审计 0 错误；保留 11 项已有数据库说明警告，详见 catalog.json。全部资源在新机器初始为未探测，绝不把 Skill 或历史文本当成 READY 注册凭证。

## 验证边界

宿主模型服务测试使用确定性适配器，没有请求真实付费模型，没有使用用户的 API key。真实提供商网络、额度、企业代理、目标机器配置与硬件须现场验证。

没有下载大型生物数据库，没有安装 107 个科学软件或执行真实生物学研究任务。科学依赖、数据库和输出有效性必须按实际项目进行批准、预检和冻结。离线包仅保证匹配标签的核心程序依赖可离线安装，不能提供离线网络文献检索。

macOS、Windows 原生、ARM、集群调度与长期守护进程模式未纳入本次验收。Windows 应使用 Linux/WSL2；宿主退出或 Agent 销毁后通过持久项目恢复任务，不保证进程永久后台存活。

## 可复验命令

```bash
pytest -q tests/test_frozen_pipeline.py tests/test_cohort_workflow.py
pytest -q tests/test_harness_integration.py
node --test tests/test_harness_plugin.mjs
python -m microbiome.harness.doctor
python -m microbiome.harness.smoke --directory /一个尚不存在的合成验收目录
node scripts/verify_harness_runtime.mjs /安装了宿主npm包的目录 /实际preset根目录 /新的验收目录
```

最后三个命令请使用发布包安装的专用解释器/宿主包路径，并在源码工作目录之外执行。运行版本、文件清单与 SHA256 以发布目录 manifest.json 和 SHA256SUMS 为准。
