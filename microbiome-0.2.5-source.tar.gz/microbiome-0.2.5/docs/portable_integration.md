# Portable Microbiome integration

The host owns conversation and model selection. Microbiome supplies a versioned workflow catalog and an independent workflow engine. Default commands and MCP do not initialize A1, require model credentials, or call a host model API. The separate explicit `endpoint` command can reuse an already running compatible model service. Legacy agent/provider integrations remain opt-in compatibility paths.

## Install the runtime

Use Python 3.11+ in a dedicated environment on the Linux execution machine (including WSL2). From this source checkout:

```bash
python3 -m venv "$HOME/.local/share/microbiome-runtime"
"$HOME/.local/share/microbiome-runtime/bin/python" -m pip install .
"$HOME/.local/share/microbiome-runtime/bin/microbiome-service" call catalog.list
```

This installs the Python runtime and its declared Python dependencies. It does not initialize a project, install scientific command-line software, acquire raw samples, or download databases. The distribution currently retains the legacy agent's Python dependencies for compatibility. It does not yet provide a minimal dependency-only core wheel. Existing READY scientific environments and databases stay in their original locations.

After installation, `microbiome-service` and `microbiome-mcp` are real console entry points. Without changing PATH, equivalent commands are:

```bash
/absolute/runtime/bin/python -m microbiome.integrations.cli call catalog.list
/absolute/runtime/bin/python -m microbiome.integrations.mcp_server
```

The MCP command defaults to stdio JSON-RPC using the `mcp>=1.28,<2` SDK. To reuse a local service port, explicitly start Streamable HTTP:

```bash
microbiome mcp --transport http --port 8765
# MCP URL: http://127.0.0.1:8765/mcp
```

The server binds only `127.0.0.1`, not the public network; it exposes workflow tools, not model inference. Start it in a terminal or your own process manager before connecting a host. All engine paths refer to the execution machine, not the browser/desktop. For remote Linux work, run the host in its supported remote workspace environment and configure the server there; this release does not install SSH tunnels or a remote scheduler.

## Install the thin skill and host configuration

The wheel includes two shared skills, `microbiome-workflow` and `microbiome-visualization`, in `microbiome/integrations/templates/skills/`, plus configuration examples in `microbiome/integrations/templates/configs`. The visualization skill includes executable helpers, reference documents and a machine-readable dependency declaration. Export both skills with the current runtime interpreter path:

```bash
/absolute/runtime/bin/python -m microbiome.integrations.cli export --host codex --output /absolute/new-adapter-directory
```

The export creates a new directory only; it never edits your host settings. `--host` accepts `codex`, `vscode`, `workbuddy`. Review and merge the generated settings rather than replacing an existing configuration file.

For a running HTTP service, export URL-based Codex or VS Code settings:

```bash
microbiome-service export --host codex --mcp-url http://127.0.0.1:8765/mcp --output /absolute/new-http-adapter
```

`--mcp-url` accepts only a loopback HTTP URL with an explicit port and `/mcp` path. It neither starts the service nor edits host settings. WorkBuddy receives both local skills without generated connector settings; configure a supported connector in that host using its own version-specific UI/documentation.

- **Codex:** copy the exported `microbiome-workflow` and `microbiome-visualization` directories to your user or project skill location (for example `~/.agents/skills/`). Merge the generated `config.toml` MCP table into the Codex configuration. Codex CLI and IDE extension can share MCP configuration. See [official Codex MCP configuration](https://developers.openai.com/codex/mcp/) and [skills](https://developers.openai.com/codex/skills/).
- **VS Code:** copy both skill directories into the project's `.github/skills/` directory or another supported skill location. Merge `mcp.json` into `.vscode/mcp.json` on the execution machine. Use the remote workspace configuration for Remote SSH/WSL, since user-profile servers normally run locally. See [official MCP configuration](https://code.visualstudio.com/docs/agent-customization/mcp-servers) and [agent skills](https://code.visualstudio.com/docs/copilot/customization/agent-skills).
- **WorkBuddy:** import both exported local skill folders through the [official local skill import flow](https://www.workbuddy.cn/docs/workbuddy/From-Beginner-to-Expert-Guide/Function-Description/Skills-Market), and make `microbiome-service` available on the execution machine's PATH. The same skill's JSON CLI operations provide the working integration. The export does **not** invent a WorkBuddy MCP configuration filename or claim tested connector support. Configure any MCP connector separately against the installed stdio command according to your WorkBuddy version's documentation. Marketplace publication has [additional metadata requirements](https://open.workbuddy.cn/docs/skill); this is a local skill package, not a submitted marketplace listing.

Install both exported skill directories in the host's supported skill location. The workflow skill retrieves catalog and figure guidance on demand; export records a file inventory and fingerprint for both skills. Installing a skill or an MCP server does not give the engine access to a host's model account, API token, or subscription quota. See [0.2.0](releases/0.2.0.md) for plotting capabilities and separate Python/R dependencies.

## Reuse an existing model API port

Use this separate branch only when you already have an OpenAI-compatible local or gateway service. The URL is explicit; Microbiome does not scan ports, start a model, download weights, guess a cloud endpoint, or extract host credentials:

```bash
microbiome endpoint --endpoint http://127.0.0.1:8000 --check
microbiome endpoint --endpoint http://127.0.0.1:8000 --project /work/project
microbiome endpoint --endpoint localhost:8000/v1 --project /work/project --prompt "What is a FASTQ file?"
```

`--check` sends `GET /v1/models`, then at most three short `POST /v1/chat/completions` probes asking for `READY`; it does not initialize an agent or project. A bare server URL gains `/v1`; an explicit API prefix such as `/gateway/v1` is preserved. Advertised `default_model`, `default: true` or `is_default: true` is preferred when present. Otherwise model IDs are sorted for deterministic selection. The first verified chat route is reported with the selected ID; no `--model`, provider selection or API key is needed. Model listings do not standardize default or chat-capability metadata, so an actual chat response is required. Only the first three candidates are probed; if they all fail the error lists those failures rather than silently choosing an unverified model.

The endpoint branch injects the same verified client into the existing A1 and persistent `ConversationWorkflow`, including nested model helpers. The project and its dialogue survive process restarts. `--project` resumes its recorded paths; without it, an interactive terminal asks for raw-data/database/results/knowledge locations. Noninteractive use requires an existing `--project` and `--prompt`. Closing this foreground conversation is distinct from submitting a detached portable job; use the service job API for jobs intended to survive host/process disconnection.

An accessible model port is required. HTTP 401/403 means that the supplied route requires authentication this client does not possess; use an already authorized local gateway route or the host's MCP integration. Microbiome does not ask for an API key or read another application's private credential files. Redirects are rejected so requests do not silently move to a different destination. Existing model services may incur their own usage costs; `--check` makes up to three small inference requests, and normal conversations call only the explicitly supplied endpoint.

Endpoint conversations keep the same explicit plan/dependency/production confirmations as the existing workflow. Approved missing dependencies can be prepared during bootstrap/pretest repair. Connecting the endpoint does not itself install scientific tools or databases; production remains frozen and cannot repair them.

`software.inspect` / `microbiome_software_inspect` exposes the same read-only resource discovery used by the internal planner. Supply `project`, `logical_tool` and optional `executable`, `software_family`, `environment_name` hints as separate fields. It searches existing environments and probes version/help/package ownership; it never installs or writes READY records. `NEEDS_PACKAGE_MAPPING` requires documented upstream/package evidence before a dependency plan can propose installation.

## Lifecycle and approvals

For simple sequence-file counts or validation, use the bounded utility below instead of creating a research design. Assembly, profiling, annotation, differential inference and other scientific analyses continue through the full lifecycle in this section.

1. Explicitly initialize user-designated directories:

   ```bash
   microbiome-service init --project /work/project --raw-data /data/reads --database /data/databases --output /work/results
   ```

2. `input.resolve` with the project and original input declaration creates a pending manifest proposal. Missing local files stop resolution. Remote raw acquisition is deliberately not exposed through this first portable adapter; use the existing approved acquisition workflow separately. `requirements.propose` stages `dataset`, `target`, and `analysis_goal` objects.
3. `approval.inspect` reports the project's approval mode, defaulting to `interactive`. `decision.inspect` returns full review material and `decision_fingerprint`. In the default mode, the operator uses `decide --project ... --topic input|dataset|target|analysis_goal --action CONFIRM --expected ...` in their own terminal. The terminal displays the material and requires an explicit typed response. It rechecks the exact fingerprint immediately before invoking the existing RequirementManager. If the user explicitly delegates decisions to the host, use the project-scoped mode described below. Confirming input persists its exact resolved manifest; downstream work uses that manifest.
4. `planning.context` provides the complete selected workflow documents, resource summary and persisted evidence receipt. `plan.validate` checks a candidate object and requires decisions for every selected reference. `plan.save` also checks study deliverables, confirmed sample metadata/statistical design, raw-input bindings, and expands cohort templates from the manifest before saving. Declare `dataset.comparative_analysis: true` for comparative inference, plus the explicit statistical design/replicates/multiple-testing policy; every candidate needs deliverables naming actual step outputs. Supply an unexpanded cohort template, not model-generated `cohort_members`. Inspect/decide `analysis_plan`, then call `dependencies.review` and inspect/decide `dependencies`. `dependencies.preview` also accepts an unsaved candidate and does not approve it.
5. Submit `bootstrap` and `resolve_databases` jobs. These reuse the existing phase/approval gates. Bootstrap may install or repair only dependencies in the user's already approved plan; submitting bootstrap is a separate explicit action. No installation occurs while merely reading a guide, connecting MCP, or starting the Python runtime.
6. Submit `pretest` with an optional `fraction` between 0.05 and 0.10. It loads every biological sample from the confirmed manifest and subsamples reads; cohort plans validate the expanded joint DAG. Host-supplied `runtime_inputs`/sample overrides are rejected. Then submit `finalize`, which produces validated frozen locks and readiness records.
7. Inspect/decide `production`, then submit `production` with optional `run_id`, `resume`, `threads`, `memory_gb`, `gpus`. The existing batch scheduler binds the full dataset from the confirmed manifest. FrozenPipelineExecutor enforces the lock, manifest, resource fingerprints, readiness and production approval. Production cannot plan, install, download or repair.

Example JSON calls (every MCP operation uses these exact service functions):

```bash
microbiome-service call input.resolve --json '{"project":"/work/project","declaration":"/data/reads/sample_list.txt"}'
microbiome-service call requirements.propose --json '{"project":"/work/project","topic":"analysis_goal","value":{"objective":"Describe community composition"}}'
microbiome-service call decision.inspect --json '{"project":"/work/project","topic":"analysis_goal"}'
microbiome-service decide --project /work/project --topic analysis_goal --action CONFIRM --expected FULL_FINGERPRINT_FROM_REVIEW
microbiome-service call plan.validate --file candidate-arguments.json
microbiome-service call job.start --json '{"project":"/work/project","operation":"pretest","request_id":"pilot-1","parameters":{"fraction":0.1}}'
microbiome-service call job.status --json '{"project":"/work/project","job_id":"ID_RETURNED_BY_SUBMISSION"}'
```

`candidate-arguments.json` contains `{"plan": {...}}`, and additionally `"project"` when saving. All replies use `{schema_version: 1, ok, result|error}`. Unknown operation/parameter names fail; no `approved=true` or private state-bypass flags are accepted. CLI failures return exit status 2. MCP responses carry the same `ok/error` fields, which hosts must inspect.

For selected workflow references, copy the earlier `planning.context` receipt into `plan.workflow_reference_evidence`. Saving verifies the project-local persisted content hash, delivered document versions, selected set and current input manifest before collecting a fresh save-time evidence snapshot. A fabricated path, stale document or changed manifest stops saving. This proves the document-delivery data flow; it cannot prove how a model reasoned. Standalone `plan.validate` validates shape/reference decisions but intentionally does not certify prior delivery.

### Project-scoped host delegation

Approval mode is `interactive` unless explicitly changed for a project. Only a user's explicit request to delegate workflow decisions authorizes a host to configure `host_delegated`; a general analysis request or a new project does not automatically enable it. Inspect the current mode before configuring it:

```bash
microbiome-service call approval.inspect --json '{"project":"/work/project"}'
microbiome-service call approval.configure --file approval-request.json
```

The configuration file supplies `project` (absolute path), `mode` (`host_delegated` or `interactive`), `user_request` (the user's actual verbatim request), `source` (a truthful conversation reference), `scope` (the explicit project task), and `topics` (the delegated subset of `input`, `dataset`, `target`, `analysis_goal`, `analysis_plan`, `dependencies`, `production`). The operation returns an `authorization_fingerprint`; retain it for decisions. Use the same operation with `mode: "interactive"` and `topics: []` when the user requests a return to terminal confirmation. Do not invent delegation text or extend the recorded task scope.

For each delegated decision, first read the full current `decision.inspect` material. Then call `decision.record` with `project`, `topic`, `action` (`CONFIRM`, `MODIFY`, or `CANCEL`), `expected` (the full current `decision_fingerprint`), `authorization_fingerprint`, and `reason` (the host's concrete review rationale). A decision must stay within the recorded project scope and topics. Review artifacts and fingerprints remain required; delegation is not an unconditional approval of future artifacts.

MCP exposes these operations as `microbiome_approval_mode(action="inspect"|"configure", project, mode, user_request, source, scope, topics)` and `microbiome_record_decision` with the same decision fields. Only configuration needs the mode and delegation fields. If an existing MCP process has not loaded the new tools, the JSON CLI provides the same operations without restarting the host.

The engine records delegation as a **host assertion**, not independent authentication of a natural-language user request, and distinguishes delegated host decisions from direct operator confirmations in its audit trail. Never script, pipe, impersonate or prefill the interactive operator response. The interactive terminal is an explicit operator interface, not a security sandbox against software with the same OS account and filesystem access. Existing valid approvals remain reusable; compatibility APIs are not removed.

Returning to `interactive` stops subsequent delegated decisions; it does not rewrite existing valid approvals or stop running jobs. Cancel a running job separately with `job.cancel` when requested.

Delegation changes only who records a reviewed decision through which channel. Confirmed inputs, approved dependency scope, passed pretest, scientific validation, finalization, frozen locks and production approval remain required. It does not authorize resource repair or scientific parameter changes during frozen production.

## Quick local sequence statistics

An explicit request to count or validate local FASTA/FASTQ files can run without a model, project initialization, scientific software or a research plan:

```bash
microbiome stats /data/reads/contigs.fa.gz --output /work/new-sequence-stats
microbiome stats /data/reads/R1.fastq.gz /data/reads/R2.fastq.gz --paired --output /work/new-pair-stats
```

For a JSON client, the equivalent operations are:

```bash
microbiome call sequence.stats --json '{"inputs":["/data/reads/contigs.fa.gz"],"output":"/work/new-sequence-stats"}'
microbiome call sequence.stats --json '{"inputs":["/data/reads/R1.fastq.gz","/data/reads/R2.fastq.gz"],"output":"/work/new-pair-stats","paired":true}'
```

The same operation is available through `microbiome-service call sequence.stats` and MCP tool `microbiome_sequence_stats(inputs, output, paired=false)`. The implementation itself uses only Python's standard library and can also run as `python -m microbiome.integrations.sequence_stats /data/reads/file.fa --output /work/new-stats`. It never calls a model, shell command, network service or installer. It does not create, approve or change scientific pipeline state.

Supply one or two absolute local file paths. Format is detected from content; gzip is detected by its header. Wrapped nucleotide FASTA and FASTQ are supported, using ungapped IUPAC nucleotide letters (including U and ambiguity codes). FASTQ checks the `@`/`+` record structure, optional repeated identifier, sequence/quality length and quality characters in ASCII 33–126. It does not infer a Phred offset or report biological quality thresholds. Paired mode requires two FASTQ files in R1,R2 order, compares every record ID in order, recognizes `/1`/`/2` and CASAVA labels, and rejects reversed labels, mismatches or unequal record counts. Duplicate input paths, including hard links to the same file, are rejected.

Each file reports record count, total bases, minimum/maximum/mean length, base counts, ambiguous bases and GC percentage. GC is `100 × (G+C)/(A+C+G+T+U)`; ambiguity codes are excluded from the denominator. A file containing only ambiguous bases has `gc_percent: null`. These are file-level descriptive statistics, not a completed taxonomic, assembly or comparative analysis.

The output directory must be new, with an existing parent, outside every input file's directory. Existing paths and output symlinks (including symlink ancestors) are rejected; inputs are opened read-only. A successful run produces:

- `stats.json`: complete validated statistics.
- `execution.json`: run ID, operation/version, input byte SHA-256 hashes, Python executable/version, implementation file SHA-256, result/log hashes and final status.
- `execution.log.jsonl`: timestamped start/completion or failure events.

The JSON/MCP reply exposes these paths and the statistics. Compare the recorded hashes with the files to verify provenance; rerunning produces a new output directory, never overwrites an earlier run. The synchronous utility is limited to **256 MiB of total decompressed input and 2,000,000 total records** (both mates count). Oversized files need a separately reviewed larger-file workflow. Malformed/truncated files, corrupt gzip, pairing errors or input identity/size/timestamp changes during reading fail and do not produce successful statistics. Once the output directory has been created, failures retain a `FAILED` execution record and log; invalid path/output checks can fail before any directory is created. A completed utility report never substitutes for pilot validation, production approval or a frozen scientific lock.

## Long jobs and switching hosts

`job.start` returns a durable project-local job ID immediately. Reuse a stable `request_id` for one logical submission: duplicate requests return the same job; changed arguments with the same ID fail. The detached worker survives a normal MCP process exit and stores request, process identity, status, logs and result in `state/portable/jobs/<job_id>`. It holds the same project operation lock used by the legacy worker, and rechecks submission-time contract fingerprints before execution. No host session ID, model route or chat transcript owns execution.

Another host can call `job.status` with the same absolute project path and job ID on the same machine. `job.cancel` verifies the Linux process identity before signalling the worker group. Cancellation retains scientific artifacts; it does not rewrite lifecycle state to pretend the interrupted stage succeeded. Status is terminal only when recorded by the worker or its death is detected.

Machine reboot, forced termination, or interrupted scientific stages require explicit inspection and recovery. They are reported as interrupted/failed, never automatically resubmitted. Production `resume` uses the original `run_id` and existing engine checkpoint/lifecycle checks; these checks may require repair/revalidation first. The adapter does not claim generic arbitrary-stage resume, remote scheduling, or cluster failover. Long worker logs and full results stay on disk; the status response includes their paths.

## Validation and compatibility

`tests/test_portable_integration.py` exercises real MCP initialize/list/call over stdio and loopback HTTP without importing A1, shared CLI semantics, rejection of fabricated approvals, stale decision rejection, local-first manifests, approved frozen execution and persistence beyond a submitting process. `tests/test_endpoint_integration.py` uses a local fake HTTP model service for discovery, bounded probes, protocol errors and actual persisted conversation, with private credential-file reads denied. Scientific adapters now resolve through `microbiome.assets`; the old `microbiome.harness.assets` import and resource files remain for existing integrations and frozen absolute paths.

The project uses the [official MCP Python SDK 1.x](https://github.com/modelcontextprotocol/python-sdk/tree/v1.x). SDK 2.x migration, all-host end-user acceptance tests, WorkBuddy marketplace publishing, and a smaller optional-agent dependency split are separate work.
