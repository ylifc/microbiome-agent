# Biomni Harness 本地产品版

本次版本提供 `biomni` CLI、Linux 浏览器工作台、统一模型配置、上下文预算、持久任务记录和独立 Microbiome Agent 入口。原有冻结生产、本地样本清单优先和资源注册契约继续有效。GUI 提交的是用户实际输入，界面不会代替用户批准安装、下载或生产。

## 安装、升级与卸载

发布目录 `Biomni-Harness-Release/` 包含 `harness/`、`microbiome_agent/`、`config_templates/`、`requirements/`、`scripts/`、`docs/`。Python wheel 同时包含三个分析辅助脚本、GUI 静态文件和集成锁；运行时不需要源码目录。

```bash
cd Biomni-Harness-Release
# 本次离线 wheelhouse 对应 Linux x86_64 / Python 3.13；请指定匹配解释器。
BIOMNI_INSTALL_PYTHON=/path/to/python3.13 ./install.sh --prefix "$HOME/.local/share/biomni-runtime"
export PATH="$HOME/.local/share/biomni-runtime/bin:$PATH"
biomni init
biomni doctor
biomni gui --open
```

安装创建独立、带所有权标记的版本化 venv，不修改 Conda/base、系统 Python、IDE hooks 或 shell 配置。安装前校验发布文件摘要，离线安装后在源码目录外执行 doctor；验证失败不切换已有启动器。配置默认在 `~/.local/share/biomni/config.json`，可用 `BIOMNI_HOME` 或 `biomni --config /absolute/config.json` 指定。

升级运行新发布目录的 `./upgrade.sh --prefix ...`；它保留配置、历史运行时和项目数据。卸载运行 `./uninstall.sh --prefix ...`，只撤销受管理启动器，保留运行时用于回退，也保留所有配置、日志、样本和数据库。需要完全移除保留运行时，应先人工核对所有权标记与备份，再由用户处理。根目录原安装入口继续兼容旧 Harness；使用 `./install.sh --standalone` 选择新发布包。

离线依赖锁与 manifest 描述构建平台。其他 Python/平台应重新构建 wheelhouse，不能直接复用本次二进制依赖。

```bash
python scripts/build_product_release.py --output /absolute/new-release
```

构建需要网络获取 Python 依赖；安装已构建包不需要网络。Evolver/SkyDiscover 不随核心安装，不会安装科学工具、下载数据库或自动拉取 Ollama 模型。

## 模型与上下文

`config_templates/models.json` 展示 OpenAI、Anthropic、DeepSeek、OpenAI compatible 和 Ollama 的统一七字段：`provider`、`model`、`base_url`、`api_key`、`context_length`、`temperature`、`max_tokens`。模型 ID 必须是用户实际可用服务的 ID，不能从产品名称推断存在某 API。密钥推荐 `${ENV_VAR}` 注入；本地配置权限为 0600，浏览器读取接口不返回密钥。GUI 密钥空值保存表示保留已有密钥。

Ollama 在首次调用时只读查询 model_info 中的上下文容量，并取服务端声明与配置上限的较小值；其他提供方没有通用容量查询协议时，无法从模型名称可靠推断服务端上限时使用 32768 默认值，不宣称发现了真实容量。每次请求计算输入预算、输出预留、工具定义和协议余量。估算采用保守 UTF-8 字节计数，不等于供应商计费 token。压缩以完整用户轮次为单位，保留工具调用/响应配对、系统信息、当前请求和持久项目状态；旧消息可加入明确标注为非权威的摘录。必要状态仍放不下则在发请求前失败。原始历史和冻结清单不被压缩覆盖。

结构化输出经过本地 JSON/schema 校验；空响应和截断结果作为失败返回。五类 SDK 已通过本地 HTTP fixture 的真实客户端调用；fixture 不证明外部账户可用。真实账户和实际上下文容量由部署环境验证。

## CLI 与工作台

```bash
biomni run --project /absolute/project --data-dir /absolute/reads --db-dir /absolute/databases "检查本地输入并说明下一步"
biomni doctor --network
```

`doctor` 默认只读本机环境；GPU/CUDA/Ollama 不存在不影响纯远程模型模式。`--network` 才请求配置服务的模型列表，既不生成模型输出，也不安装模型。

GUI 只监听 `127.0.0.1`，启动时输出带随机 fragment token 的地址。浏览器将 token 转入当前会话，不放请求 URL。任务、模型、上下文、日志、诊断均使用同一 API；Host、Origin 和请求 token 必须匹配。不要直接绑定公网。一个任务目录只有一个管理进程；同项目重复提交受阻，重启中的未完成任务标记为 interrupted，不自动重放批准。Linux worker 随管理进程退出终止，正常取消终止进程组。

路径指服务器上的绝对路径。新项目缺 `data_dir/db_dir` 会被拒绝；本地缺文件不触发 SRA。生产执行仍依赖既有机器校验后的锁，GUI 不改变科学参数。任务日志只在本地保留；错误类别显示在日志中，凭证异常内容不回显。

## 可选工程经验模块

三个集成默认关闭，也不在普通项目运行中自动触发。它们面向显式的维护/离线工程流程；没有后台循环、自动核心补丁、自动发布或远程任务领取。阶段交接见本目录另外三份文档。运行状态必须区分真实调用、fixture、dry-run 和 BLOCKED。

本次 Evolver 真实禁网调用及通用工程候选回归已完成。EvoMap 只有 fixture 契约验证，`LIVE_QUERY=BLOCKED`。SkyDiscover 固定版本已安装并真实启动其 CLI 帮助入口，`LIVE_SEARCH=BLOCKED`；这不等于完成了 EvoX 搜索。付费模型预算未授权，而且上游搜索与独立模型代理的沙箱联调尚未验收，因此 SearchAdapter 始终拒绝实际搜索。
