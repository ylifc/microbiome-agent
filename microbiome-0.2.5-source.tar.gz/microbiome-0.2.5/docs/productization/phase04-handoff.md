# 阶段 04 前置工程交接

本轮完成的前置条件是统一模型配置、上下文管理、标准 Agent 入口、持久任务服务及本地 GUI。本文件供阶段 05—07 引用，不扩展未提供的其他阶段要求。

- 模型边界：`settings.ModelConfig` 的七字段配置，经 `providers.ManagedChatModel` 转入既有 `get_llm`；OpenAI、Anthropic、DeepSeek、OpenAI compatible、Ollama 的真实 SDK 在本地 HTTP fixture 上验证文本/JSON/工具/截断/空响应。凭证通过环境引用或 0600 配置，公开接口不返回密钥。
- 上下文边界：`context.prepare_context` 自动预算；`capabilities.context_capacity` 读取 Ollama 能力并受配置上限约束。项目状态从持久配置、状态文件和 manifest/锁位置读取。新 standalone 路径所有模型请求均经 ManagedChatModel；旧 dsh 插件的宿主上下文策略仍由其宿主负责。
- Agent 边界：`AgentAdapter.run/status`，每任务独立 Python 进程；既有确定性 workflow 处理用户确认，冻结生产不请求模型。GUI 不从日志或模型文本推导新授权。
- 持久化边界：TaskManager SQLite、每任务事件 JSONL、单管理器锁、同项目活动任务互斥、受管取消、Linux 父进程死亡处理。任务启动时冻结模型配置，完成后删除临时请求中的凭证副本。
- 资源边界：标准 wheel 打包三个辅助文件；科学资源继续来自验证过的注册表/冻结锁，产品安装不会创建数据库或覆盖 READY 软件。
- UI/API：五个页面共享 loopback token/Host/Origin 验证；任务日志与上下文来自真实事件；配置保存不触发模型请求。可使用 CLI 独立运行，不依赖浏览器或 Evolver/EvoMap/EvoX。

阶段 05 的输入应是白名单工程快照，不可直接传入这些本地任务日志。三个集成默认为 off，当前需显式维护调用；生产工作流不自动触发它们。调用授权、模型 token/费用预算、外发授权和发布授权必须分别表达。
