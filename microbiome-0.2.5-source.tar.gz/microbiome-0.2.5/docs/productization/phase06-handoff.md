# 阶段 06 交接：EvoMap 隔离查询

协议依据为 [llms.txt](https://evomap.ai/llms.txt)、[GEP-A2A 文档](https://evomap.ai/docs/en/05-a2a-protocol.md)及 [API access](https://evomap.ai/docs/en/28-api-access.md)，快照日期与摘要记录在集成锁。首版仅窄 HTTP GET：`/a2a/assets/search` 与显式 SHA256 ID 的 `/a2a/assets/:id` 元数据。未请求 `detailed=true`、购买内容或 POST fetch；默认 metadata/code preview 不冒充完整可执行资产。

`LIVE_QUERY=BLOCKED`：本次没有既有查询授权、有效凭证或明确计费条件，未自动注册、发 hello、支付、换身份或使用其他通道绕过。协议 HTTP fixtures 与真实本地 Evolver 证据分开；不能把文档抓取或 fixture 当作真实 Hub 查询。

| 外发字段 | 处理 |
|---|---|
| signals | 仅 TABLE_SHAPE / CONFIG_PARSE / TIMEOUT / UNKNOWN 枚举 |
| status / limit | 适配器固定 promoted / 10 |
| asset ID | 必须由调用方明确选择，格式 sha256:64位小写十六进制 |
| Authorization | 可选环境注入，仅发固定 HTTPS 主机请求头，不进入日志/持久经验 |
| 工具、版本、平台、摘要 | 本地白名单可生成脱敏快照；当前查询不外发这些额外字段 |
| 原始日志、样本、病例、路径、任意问题文本 | 不外发 |

只有 enabled、authorized、local_insufficient 均满足才发查询；默认 3 次请求、单次 8 秒，至多 5 次/15 秒，可用内存 TTL 缓存。429 遵守有界 Retry-After/指数等待与抖动；遇到过长日期格式等待不跟随，返回本地模式。其他网络失败立即回退；不会无限重试。凭证已配置、公开请求成功和鉴权已证明分别记录，公开端点成功不宣称鉴权成功。

固定主机 evomap.ai，拒绝重定向及解析到内网地址；不采用 shell、不解压 archive、不执行返回命令、限制 JSON 类型与 256 KB 内容。固定文档没有 search 分页 cursor 规范，因此发现 next 字段时返回 pagination_unsupported，绝不盲目跟随。缺少版本/许可证标记 incomplete_metadata，不自动补全。

资产保存 source_object、来源 ID/URL、规范化内容摘要、版本、许可证、平台自报验证/GDI、适用环境；所有平台标签均保留为数据，local_validation 始终 NOT_VALIDATED。Gene/Capsule 只有在调用方明确提供审查后的工程候选时映射为内部 Proposal，再交阶段 05 验证。错误/不完整数据留在隔离区，不写有效经验，默认不回传反馈。

`prepare_export` 只产出脱敏 payload、摘要、UNKNOWN 成本和 publish_authorized=false，完全无网络写操作。发布、自动更新 Skill、心跳、staking、积分、远程任务均未实现/未启用。关闭适配器不改变本地项目处理。

测试覆盖：401/403/429/500、断网回退、大小/类型/格式漂移、未知分页、重定向、命令注入文本保持隔离、伪验证标签、许可证缺失、敏感标记外发为零、缓存与 prepare_export 无请求。保留限制：尚未完成真实 Hub 契约和完整内容获取；DNS 检查与 HTTP 建连之间未做 IP 固定，应在生产外联网关进一步固定允许目标。
