# 产品化执行与验证报告

日期：2026-09-14。执行对象是第二份修复/产品化计划，以及用户补充的阶段 05—07；第一份审计计划的结果保留在 `docs/audits/2026-09-14-harness/`。这些文档作为任务规格使用，没有赋予第三方文本运行、发布或审批权限。

## 已交付

- 修复审计 B01—B06：DeepSeek 环境凭证、OpenAI 显式凭证/地址、`config.llm`、标准 wheel 三个辅助资源、Anthropic 核心依赖、新项目缺路径时不提前绑定会话。GUI 联调额外修复所有五类本地端点绕过宿主全局代理的问题；Anthropic 新 SDK 使用 httpx2，需要 SDK 原生 transport，不能混用 httpx 对象。
- 统一模型配置与独立 AgentAdapter；每次模型调用执行上下文预算、状态保留、完整轮次压缩和结构化输出验证。Ollama 容量元数据只读探测，其他提供方使用保守配置上限。
- `biomni` CLI、只读 doctor、带认证的 Linux 浏览器工作台；持久任务、进程组取消、重启 interrupted 标记与配置权限。
- `Biomni-Harness-Release/`：安装/升级/卸载脚本、标准 wheel、离线依赖锁与 wheelhouse、配置模板、文档、SHA256 manifest。没有科学软件/数据库自动安装，也没有替换任何 READY 资源。
- Evolver 固定源码真实本地禁网调用成功；输入、命令、文本输出、退出状态和持久性检查均归档。合成工程故障通过独立候选回归并登记 locally_verified，错误候选被拒绝。
- EvoMap 可选 HTTP 元数据查询与隔离导入、白名单、缓存/预算/错误处理、只准备发布 payload；真实网络调用未授权。
- SkyDiscover EvoX 固定源码校验、真实 CLI 启动和 dry-run/检查点契约；未运行真实搜索。

## 验证证据

| 检查 | 实际结果 | 证据 |
|---|---|---|
| 新增模型、上下文、任务/GUI API、集成、安装边界测试 | 69 passed | evidence/product-tests.log |
| 冻结流水线、真实 worker、DeepSeek、Ollama 重点回归 | 41 passed | evidence/focused-regression.log |
| 本地输入、持久状态、软件复用、注册与批准范围回归 | 133 passed | evidence/workflow-regression.log |
| Node Harness 插件测试 | 5 passed | evidence/node-regression.log |
| Evolver 固定版本最终真实调用 | proposal，退出 0，生产/全局配置指纹不变 | evidence/evolver-live-final/、evolver-persistence.json |
| 合成候选真实验收 | 基线错误；错误候选拒绝；修复 locally_verified | evidence/candidate-demo/ |
| 内核沙箱探针 | 禁网、生产/home/oracle 不可见、系统根只读 | evidence/sandbox-live.json |
| 浏览器实际操作 | 保存模型、提交任务、超限拒绝、成功任务、上下文、日志、doctor；无脚本错误 | evidence/gui-smoke.json |
| 离线安装与升级 | 独立 venv，源码外 doctor 通过 | evidence/install-offline.log、upgrade-offline.log、installed-wheel.json |
| 安装后 Agent 运行 | 源码目录外，真实 worker + 本地合成模型返回 ok | evidence/installed-agent-smoke.log |
| 卸载 | 仅撤销受管理启动器，运行时/配置/项目保留 | evidence/uninstall-smoke.json |

合计 243 项 Python 测试及 5 项 Node 测试。模型测试使用真实安装的 SDK 和本地合成 HTTP 响应，没有外部付费请求。浏览器最初的失败保留在证据中：第一次暴露全局代理问题，第二次正确触发上下文超限，最后在明确提高合成端点上限后成功；没有改写失败记录。

## 明确未完成的外部验收

`LIVE_QUERY=BLOCKED`：没有取得真实 EvoMap 查询的既有授权与有效凭证/计费范围；未自动注册或支付。首版仅获取元数据，不冒充完成详细内容购买或真实平台验证。

`LIVE_SEARCH=BLOCKED`：没有 token/金额预算，且上游 EvoX 搜索与受信模型代理在沙箱中的联调尚未验收。当前 SearchAdapter 即使开启也拒绝真实搜索。没有把 CLI --help、自写循环或候选普通测试宣称为 EvoX 搜索。阶段 07 交接列出后续门槛。

上下文限制：现有 Agent 的部分系统/工具提示较长，按保守 UTF-8 字节计数可能超过默认 32768 上限。系统约束不会被静默截断；应使用确实支持更大上下文的服务并明确配置，或另行缩小工具目录。合成 fixture 的 200000/512000 上限不代表真实模型容量。尚未验证真实供应商账户，也未声称真实测序数据端到端生产已执行。

沙箱依赖 Linux bubblewrap、user namespaces 与 prlimit；不可用时失败关闭。系统运行时为只读宿主系统目录，尚未交付可复现的固定基础容器镜像。EvoMap 仍需在部署侧限制外联网关目标；DNS 检查与建连间的 IP 固定尚未实现。

## 变更边界

开始时工作树已有大量未提交/删除文件。本次保留这些用户工作，没有提交、重置、覆盖整树或推送。`changes.patch` 和 `change-manifest.json` 将本次开始前的文件快照作为基线，而不是把既有未提交工作算入本次修改。发布目录为生成产物，按 manifest 校验；测试日志与原始契约证据单独保留。
