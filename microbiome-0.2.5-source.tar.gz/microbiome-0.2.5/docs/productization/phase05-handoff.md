# 阶段 05 交接：Evolver 本地提案

固定来源：[EvoMap/evolver 31b0691](https://github.com/EvoMap/evolver/commit/31b0691acd97ba18878019312e646f1f2d970d43)，package 1.94.0，GPL-3.0-or-later，包声明 Node >=22.12。完整包依赖、归档 SHA256 和入口文件哈希见 `microbiome/harness/integrations/integration-lock.json`。本次使用 Node 22.23.1，独立临时源码目录内 `npm ci --ignore-scripts --omit=dev --omit=optional --no-audit --no-fund`，没有全局安装。第三方许可与核心 Apache 许可分开；发布包只分发适配器与来源锁，不捆绑 Evolver。

实际入口为 `node index.js run`。该版本输出文本 GEP prompt；Adapter 归档原文并识别有限的 GEP 标记，不虚构官方 JSON Proposal API。识别状态包括 proposal/no_suggestion/unparseable/timeout/nonzero_exit/blocked；输出 guidance 不代表修复完成。提案没有执行、批准、发布或自授 verified 的权限。

最终完整源码锁与持久性复核：`evidence/evolver-live-final/`、`evidence/evolver-persistence.json`（生产入口与实际 IDE 配置摘要前后一致）。

真实成功证据：`evidence/evolver-live-success/{input.json,execution.json,proposal.json}`。第一次失败日志保留在 `evidence/evolver-live/execution.json`：`--jitless` 禁用了依赖需要的 WebAssembly。修复启动参数为 `--disable-wasm-trap-handler --max-old-space-size=128 --max-opt=0` 后退出 0。实际命令完整保存在 execution.json，未使用 `--loop`、review 等待、hook、后台任务或核心代码自动修改。

Linux bubblewrap 创建独立 user/pid/network 命名空间、清空环境、只读挂载运行时/锁定源码/审查输入，工作区为有大小上限的 tmpfs。每次在新 scratch Git 中运行；生产仓库、真实用户 home、IDE 配置均不挂载。`prlimit` 限制地址空间、进程数、单文件大小、CPU 和文件句柄，父进程限制墙钟并清理进程组。Evolver 可能仍尝试网络：禁止依赖上游“关闭”环境变量承诺，内核网络命名空间阻断实际连接。沙箱探针证据在 `evidence/sandbox-live.json`；当前宿主只读 `/usr` 等系统根并非内容寻址容器镜像，跨主机复现还应固定操作系统镜像。

输入白名单只接收规范化错误码、受限公共工具名/版本和通用平台名；自由文本日志、路径、患者/密钥标记一律丢弃，摘要由枚举重新生成。快照保存在 scratch 的 `memory/engineering.json` 和 `MEMORY.md`，绝不挂载真实 session logs。

`Proposal` 校验基线、允许文件和内容大小，拒绝绝对路径、目录穿越、验收/预算/冻结锁/权限文件。首例仅接受 `candidate.py`。现有 Agent 根据审查后的建议实现合成整数表校验；`CandidateValidator` 在独立 scratch Git 中以只读代码挂载执行，用开发/保留/最终集进行固定 oracle 回归。评估器与未使用输入留在受信父进程，不在候选挂载内。只允许正确性修复晋级，计时只作诊断，不宣称性能显著改善。

`evidence/candidate-demo/ledger.json` 记录：故障基线、不合格候选 NO_PROMOTION、合格修复 locally_verified；同目录保存原始提案与候选补丁。最终验收通过即停止，无生产自动写入；失败保留基线，scratch 清除。重启沿用账本，已提交但未确认记录不重跑。实际示例入口：`evidence/run_engineering_demo.py`（合成数据、零付费请求）。

启用方式是在显式维护脚本构造 `EvolverAdapter(source_dir=..., node=..., enabled=True)`；缺 Node、缺包、源码漂移或沙箱不可用返回失败状态，禁止降级为无沙箱运行。连续三次失败熔断。关闭 `enabled` 或移除独立安装目录即可卸载；核心无需 Evolver。系统未自动保存临时上游目录为永久用户配置。
