# 阶段 07 交接：SkyDiscover EvoX 有界工程优化

指定来源是 [skydiscover-ai/skydiscover c30ca19](https://github.com/skydiscover-ai/skydiscover/commit/c30ca1907b0084c7ef2d2ed4b6398d181a3fad0c)，不是 EMI-Group/EvoX。许可证 Apache-2.0；提交与入口源码哈希在 integration lock。本次在独立测试 venv 安装固定源码，真实执行 `python -m skydiscover.main optimize --help`，确认 --search evox、--config、--iterations、--output、--checkpoint 入口。没有调用会安装 IDE hook 的 `skydiscover init`。

实际启动日志及已冻结 dry-run 计划位于 `evidence/evox-dry-run/search-state.json`，另有 `skydiscover-help.log`。上游没有 --dry-run CLI 参数，当前 dry-run 是本地适配器的准备阶段，不虚构上游参数。

`LIVE_SEARCH=BLOCKED`，未提交任何模型调用，token=0、费用=0、EvoX 候选=0。用户未指定 token/金额预算；此外上游搜索与独立模型代理在强隔离中的联调尚未完成。即使设置预算，本版本仍以 upstream_sandbox_model_broker_not_validated 拒绝实际搜索。不能将独立 CandidateValidator 的普通候选验证循环称为 EvoX 搜索，也不能将 --help 成功称为真实搜索成功。

`SearchAdapter` 目前提供真实版本校验、CLI 启动检查、OptimizationTask/模型脱敏配置映射、检查点计划摘要、BLOCKED 状态和零调用账本。任务/模型/预算漂移拒绝恢复。`OptimizationTask` 固定非生物合成表格式校验、候选文件/接口、基线、oracle 版本、语义约束、停止条件、候选操作、预算。默认最多 5 个候选、并发 1、单候选 5 秒（配置最高 60）、总墙钟最多 600 秒，最多 5 次保留集查询。策略不能扩权、修改指标或扩大预算。

独立候选沙箱与评估器已经真实运行（阶段 05）：开发集用于反馈，保留集有次数上限，最后验收只对可晋级修复使用一次。正确性先于计时；当前只接受明确正确性修复，不接受未证明稳定收益的性能晋级。只生成补丁和证据，生产版本不自动改变。超时、越界写、网络访问、fork、读取隐藏验收文件的实际隔离测试均在产品化测试中覆盖。

剩余可发布搜索门槛：实现/验证将上游 LLMInterface.init_client 转发到现有 ModelAdapter 的受信代理；使其所有模型池/搜索策略调用均经过原子预算预留与故障记账；在上游策略不可读写 oracle/保留集且不能绕过代理的沙箱内真实完成授权任务；验证中断后不重复计费。需要有明确 token/费用上限的合法模型服务后才能进行，不能硬编码某一“GPT-6 SDK”。

EvoX 关闭不影响阶段 03—06；现有配置、上下文、GUI、冻结生产与本地经验功能均可单独使用。此交接如实标记阶段 07 部分完成，未伪造搜索成绩或模型成本。
