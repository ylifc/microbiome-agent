# Microbiome Agent 完整使用手册

适用对象：使用 Codex、WorkBuddy、VS Code 或本地模型服务开展微生物计算分析的研究人员与开发者。

本手册说明如何安装 Microbiome、连接已有宿主或模型服务、准备输入、审阅方案、管理软件与数据库，并通过小数据预检形成可重复执行的生产流程。Microbiome 负责输入与资源核验、流程契约和执行记录；宿主模型负责理解研究问题并形成可审查的候选方案。默认入口不要求另建模型账户，也不读取宿主的订阅凭据。

文档基于当前工作区代码与流程目录整理，核对日期为 2026 年 9 月 29 日。命令中的示例目录、模型地址和项目路径应替换为自己的实际值。流程参考说明不代表所有生信软件已安装，也不代表 21 条科学路线均已完成真实数据端到端验证。

## 1 项目定位与工作边界

Microbiome 是微生物生物信息分析的规划与执行软件。它以本地 FASTQ、FASTA、样本清单及元数据为输入，把研究目标转成有明确输入、输出、依赖、资源、参数和验收条件的工作流。执行阶段调用已核验的命令行软件，保存日志、检查点、资源指纹和结果报告。

日常工作从研究问题开始。例如，“用这些群落 DNA 样本恢复细菌 MAG，并比较丰度”还需要补充测序平台、组装方式、样本关系和比较设计。系统可以提供方法参考与候选步骤，但组别、重复、参考适用性及影响结论的参数必须来自真实信息。

用户可以在已有的 Codex、WorkBuddy、VS Code 等宿主中继续对话，由该宿主的模型调用 Microbiome 工具。也可以显式连接一个已经运行的模型 HTTP 服务。二者共用项目状态、流程目录和冻结执行机制。项目不再以开发一套独立聊天界面或完整 harness 为主线。

### 能力与证据层级

| 层级 | 表示什么 | 不应作出的推断 |
| --- | --- | --- |
| 流程参考 CURATED_REFERENCE | 已整理输入、方法选择、输出、局限与来源 | 不等于可执行方案或本机资源就绪 |
| 候选计划通过 schema 校验 | 字段、步骤引用、部分约束符合程序契约 | 不等于命令已在当前环境运行成功 |
| 软件或数据库 READY | 当前注册记录已通过相应核验 | 不授权更新、重建或替换该资源 |
| 当前项目小试通过 | 指定输入子集上的命令、接口与输出检查通过 | 不自动证明生物学结论正确 |
| 冻结 lock | 本次验证过的流程与资源被固定 | 不允许生产阶段临时增加方法或依赖 |

本项目的工程范围包括文件与路径检查、工具调用、参考数据库管理、计算分析和结果解释支持。实际分析应保留原始证据、负结果、未分类项和不确定性，不因希望得到某个结果而更改统计设计或阈值。

## 2 整体结构与数据流

项目包含相互分工的五层。了解这些边界，有助于判断失败发生在研究设计、资源准备还是执行阶段。

| 层 | 主要实现 | 职责 |
| --- | --- | --- |
| 宿主接入 | integrations 服务与 MCP | 暴露版本化操作，返回结构化结果和决策摘要 |
| 流程参考 | workflows 目录 | 保存 22 条方法说明、适用条件和出处指纹 |
| 规划与契约 | PlanningContext 和 study | 提供已确认输入与资源证据，校验候选方案 |
| 资源管理 | Registry Skill Knowledge | 记录实际位置版本、用法指导和已验证经验 |
| 验证与生产 | pipeline 状态机和执行器 | 小试、验收、冻结、漂移检查、重放与审计 |

典型数据流如下。箭头表示前一步的产物是后一步的依据，不表示所有步骤可跳过用户审阅。

```text
本地输入声明 → 持久样本清单 → 方法参考和资源核验
                               ↓
                     候选方案与参考采用说明
                               ↓
               确认需求和方案 → 确认依赖准备范围
                               ↓
                   资源准备 → 小数据端到端预检
                               ↓
                 输出验收 → 冻结流程和资源锁
                               ↓
                 确认全量执行 → 生产重放与报告
```

流程文档用于设计，Registry 用于提供当前资源事实，lock 用于决定生产行为。软件 Skill 中的示例命令不会自动成为本项目的执行命令；历史成功记录也不能覆盖本次输入或资源发生变化的事实。

宿主通过 `planning.context` 获得相关流程的完整正文、元数据和证据回执。提交方案时，须说明每份参考是采用、调整还是不适用，并给出理由与实际步骤关联。回执证明接口已提供相应资料和出处，不能证明模型内部推理正确，因此用户仍应审阅科学设计。

## 3 选择接入方式

### 使用已有宿主模型

当已经在 Codex、WorkBuddy 或具备 MCP 功能的 VS Code 客户端中工作时，优先将 Microbiome 配置为工具服务。宿主负责模型选择、对话和已有的账户认证。Microbiome 本身不需要再启动一个模型，也不应索取宿主订阅的密钥。

MCP 是宿主与工具之间的接口。常见方式是 stdio：宿主启动指定的 Python 进程，并通过标准输入输出通信。可选 HTTP 方式允许连接同一机器上运行的工具服务。模型 HTTP 地址与 MCP HTTP 地址的用途不同，配置时应分别核对。

### 使用已有模型端口

当没有可用宿主，或者希望直接使用本地推理服务时，可以显式使用 endpoint 客户端。它连接用户给出的模型服务地址，探测服务所提供的模型，再由同一 Microbiome 工作流引擎执行已获授权的操作。它不会把 Codex 或 WorkBuddy 的登录状态转换为通用模型 API。

若模型服务本身设置认证，应先通过该服务已有的授权方式提供可访问的本地路由；当前 endpoint 客户端不接收独立的密钥参数。本地无认证服务不应被额外要求购买其他模型 API。模型调用只是设计与对话的一部分，安装依赖、下载数据和运行生产仍受项目决策与状态约束。

### 默认命令入口

本次默认的 `microbiome`、`biomni` 和 `microbiome-run` 是相同的轻量入口，无参数时显示帮助。研究问题在宿主对话中输入，或显式进入 endpoint 客户端。旧的独立模型与 harness 路线保留为兼容入口，名称为 `microbiome-legacy-run` 与 `microbiome-legacy-harness`。

```bash
microbiome --help
microbiome doctor
microbiome call catalog.list
```

`doctor` 用于检查轻量安装和接口，不应把它理解为所有生信环境、数据库和科学流程的全面验收。

JSON CLI 响应包含 `schema_version`、`ok` 和 `result` 或 `error`。失败时命令返回退出码 2；MCP 返回同样的结果字段。宿主应检查 `ok` 和错误内容，不能只凭工具调用有响应就认为任务成功。

## 4 安装运行环境并连接宿主

### 在执行机器上安装

长任务运行器当前面向 Linux 或 WSL2。项目路径、原始数据路径、Conda 环境与数据库路径均指执行机器上的路径。桌面浏览器能看到某个文件，不代表 Linux 执行环境能访问该文件；使用远程开发时，应在对应远程工作区配置服务。

推荐为 Python 运行时使用独立虚拟环境。以下命令从项目源码目录执行，适用于 Python 3.11 或以上版本；替换示例安装路径后再运行。

```bash
python3 -m venv /work/microbiome-runtime
/work/microbiome-runtime/bin/python -m pip install .
/work/microbiome-runtime/bin/microbiome doctor
/work/microbiome-runtime/bin/microbiome call catalog.list
```

此安装处理项目 Python 包及其声明依赖，不创建分析项目，不安装 MEGAHIT、Bakta 等全部科学软件，也不下载数据库。当前发行包仍保留部分旧 agent 的 Python 依赖，尚不能视为已经完成最小化拆包。已经 READY 的生信环境和数据库应继续留在原位置。

将运行时的 `bin` 加入 PATH 后，可以使用简短命令；否则始终使用绝对路径。宿主启动命令也应指向这个运行时中的解释器，避免因不同终端使用不同 Python 而找不到包。

### 导出接入配置

```bash
microbiome export --host codex --output /work/adapters/codex
microbiome export --host vscode --output /work/adapters/vscode
microbiome export --host workbuddy --output /work/adapters/workbuddy
```

每次导出要求输出目录尚不存在，避免覆盖已有配置。导出包含共享的 `microbiome-workflow` Skill；Codex 和 VS Code 还会获得相应 MCP 配置片段。先查看生成文件，再合并到现有配置，不要用整份示例覆盖其他 MCP 服务。

Codex 用户把共享 Skill 安装到其支持的用户或项目 Skill 目录，并合并 `config.toml` 片段。VS Code 用户把 Skill 放到相应项目 Skill 位置，并合并 `mcp.json`；在 Remote SSH 或 WSL 工作区，应确认服务器实际在远程执行机器启动。WorkBuddy 可导入本地 Skill，并让执行环境能够直接调用 `microbiome-service`；该 Skill 也能通过 JSON CLI 调用服务。WorkBuddy 的 MCP 配置形式取决于安装版本，本项目不生成未经核实的专用配置文件。

### stdio 和本机 HTTP

stdio 通常由宿主启动，无需手工常驻进程。等价的直接启动命令如下；它输出的是协议内容，不是交互聊天界面。

```bash
microbiome mcp
```

需要本机 HTTP MCP 时，显式启动服务：

```bash
microbiome mcp --transport http --port 8765
```

该接口固定监听回环地址，MCP URL 为 `http://127.0.0.1:8765/mcp`。可以为 Codex 或 VS Code 导出 URL 配置：

```bash
microbiome-service export --host codex \
  --mcp-url http://127.0.0.1:8765/mcp \
  --output /work/adapters/codex-http
```

此服务不是公网部署、模型网关或远程调度器。宿主与执行进程若位于不同机器，需要先解决宿主支持的远程工作区接入；本项目不会自动建立 SSH 隧道。

### 轻量序列检查与统计

已安装后，检查一个本地核酸 FASTA 或 FASTQ 不需要初始化项目或调用模型。执行基础统计可使用以下命令，输入和输出分别位于数据目录与结果目录。

```bash
microbiome stats /data/reads/input.fa --output /work/new-stats
microbiome stats /data/reads/R1.fastq.gz \
  /data/reads/R2.fastq.gz --paired --output /work/new-paired-stats
```

输出目录须不存在、父目录已经存在，并位于原始输入所在目录之外。接口支持 gzip 和换行序列，核验核酸字符、FASTQ 序列与质量长度及质量字符范围；开启 paired 时核对所有记录的数量、顺序及配对标识。两个独立文件可以分别统计，但不能把真正的配对检查省略成成功。

结果包括记录数、总碱基数、最短最长和平均长度、GC 与歧义计数。GC 分母只计 A/C/G/T/U；全为歧义字符时 gc_percent 为 null。输出 stats.json、execution.json 和 execution.log.jsonl，记录输入、结果、日志与源码指纹及 Python 版本。此任务不推断 Phred 编码，也不提供 Q20/Q30、分类、覆盖度或组间差异结论。

一次调用累计解压内容最多 256 MiB、最多 200 万条记录，双端两侧都计入。损坏、漂移、配对错误和超限均返回失败，不能把部分统计作为完整结果。路径预检失败可能不会创建结果目录；已创建的失败记录保留作诊断，重试使用新的目录。

宿主可调用 MCP 工具 microbiome_sequence_stats，等价服务操作为 sequence.stats。该操作不需要安装科学软件、数据库或修改项目批准状态；超出其范围时再建立科学分析方案。详见[序列统计参考](../microbiome/workflows/sequence-statistics/GUIDE.md)。

## 5 建立项目与确认输入

### 固定四个目录

一个项目至少确定项目根目录、原始数据目录、持久数据库目录和输出目录。持久数据库应保存在 Conda 环境之外；结果目录也不应覆盖原始 reads。

```bash
microbiome init --project /work/study-a \
  --raw-data /data/study-a/reads \
  --database /data/reference-databases \
  --output /work/study-a-results
```

初始化生成项目配置和状态目录。已有项目应使用 `project.inspect` 查看，不能反复初始化以“恢复”状态。不同项目可以使用同一持久数据库根目录，但仍需验证实际版本、入口与指纹。

```bash
microbiome call project.inspect \
  --json '{"project":"/work/study-a"}'
```

### 本地输入优先

明确给出的本地文件、目录或清单是输入来源。`sample_list.txt` 不是下载请求；本地文件缺失时应纠正路径或补齐文件，不能据此自动改用 SRA。配对文件应有明确对应，样本 ID 必须稳定且不重复。

在宿主中给出实际数据位置和研究目标后，要求它先调用输入解析工具。对应 JSON CLI 示例：

```bash
microbiome call input.resolve --json \
  '{"project":"/work/study-a","declaration":"/data/study-a/reads/sample_list.txt"}'
```

输入解析产生待审阅材料。确认后，系统持久保存 input manifest，后续规划、预检与生产从这份清单取样本，不再从聊天文字重新推断来源。远程样本与参考数据库分别管理。通用引擎按样本区分本地记录与明确远程编号；当前轻量输入接口不直接启动原始样本远程获取，需要通过另行批准的获取流程完成后再解析。

### 补齐研究设计

输入之外还需要确认 `dataset`、`target` 和 `analysis_goal`。宿主用 `requirements.propose` 提交待审阅对象。数据集信息应包括样本数、平台、布局、样本元数据及适用的比较设计；目标应说明分析对象和参考需求；分析目标应说明产物与可验收范围。

比较分析必须有真实分组、生物学重复、协变量、统计设计与多重检验策略。用户尚未提供这些信息时，系统应提问或限于描述性分析，不能补造组别或把技术重复当生物学重复。

## 6 查阅和选择流程参考

当前目录包含 22 条参考，其中 21 条是科学方法路线，1 条是可直接调用的基础序列统计。下表用于定位，完整正文包含输入要求、必须澄清的问题、阶段、候选资源、验收与局限。每条都有版本、状态和内容指纹。进入规划时只加载有关资料；显式指定的 ID 不因默认检索数量限制被截断。

| 分析路线 | Workflow ID |
| --- | --- |
| 本地核酸序列检查与基础统计 | sequence-statistics |
| 宏基因组细菌和古菌 MAG | assembly-mag |
| 宏基因组 contig 与基因目录且不分箱 | metagenome-contigs |
| 宏转录组联合细菌和古菌 MAG | metatranscriptome-bacterial-mag |
| 单菌短读长 WGS | short-read-isolate-wgs |
| 单菌参考引导和无参考转录组 | microbial-rna |
| DNA 病毒 | dna-virus |
| RNA 病毒 | rna-virus |
| 宏基因组病毒 | virome |
| 宏转录组病毒 | metatranscriptome-virome |
| 病毒系统发育 | viral-phylogeny |
| 细菌和古菌系统发育 | bacterial-archaeal-phylogeny |
| 宏基因组真菌 contig | fungal-metagenome-contigs |
| 真菌 MAG | fungal-mag |
| 宏转录组联合真核微生物基因组 | metatranscriptome-eukaryotic-genomes |
| 宿主相关与共生菌数据去宿主 | host-associated-depletion |
| 长读长和混合单菌组装 | long-hybrid-isolate |
| 分离株比较与群体关系 | comparative-outbreak-genomics |
| 非组装型 shotgun 物种与功能谱 | shotgun-taxonomy-function |
| 基因和蛋白功能注释 | microbial-functional-annotation |
| 16S 18S 和 ITS 扩增子 | amplicon |
| 移动元件和耐药相关序列注释 | mobile-amr |

```bash
microbiome call catalog.search --json \
  '{"query":"宏转录组联合真核微生物基因组"}'
microbiome call catalog.show --json \
  '{"workflow_id":"metatranscriptome-eukaryotic-genomes"}'
```

“单菌宏转录组”需要先澄清：纯培养单菌的 RNA-seq 属于单菌转录组；群落 RNA 中分析某类细菌属于宏转录组。参考引导与无参考组装是依据输入选择的分支。真核、原核、DNA 病毒和 RNA 病毒分别具有不同的组装、注释和质量假设。

RNA 覆盖度反映表达，不能替代 DNA 分箱覆盖度。真菌 MAG 应选择真核质量模型；BUSCO 重复标记不能直接当成污染百分比。病毒序列完整度评价需检查相应数据库的适用范围。完整的科学方法说明见[流程目录](workflow_catalog.md)，不要仅根据表中的名称机械套用。

本轮方法审查还明确了几个可执行条件。差异统计通过共同 feature 矩阵和样本设计进入 cohort 阶段；无参考表达比较先固定共同转录本集合，不能把不同样本的组装 ID 直接合并。当前编译器支持 sample 到 cohort 的汇总，不支持 cohort 输出反向供 sample 模板消费。只有 contig 时允许分类和注释，覆盖与丰度必须标为未测定。备选工具和条件性病毒评价模型只在选中后进入依赖范围。

## 7 从研究问题形成可审阅方案

输入与研究需求确认后，让宿主调用 `planning.context`。例如，用户已提供群落 DNA 并明确要做细菌 MAG，宿主应读取相应指南与本机资源证据，再设计具体步骤。

```bash
microbiome call planning.context --json \
  '{"project":"/work/study-a","query":"恢复细菌MAG并报告DNA丰度","workflow_ids":["assembly-mag"]}'
```

响应包含完整参考内容、资源上下文和持久化回执。模型应以实际数据与资源为依据，给出组装、覆盖、分箱、质量评估等被选中的步骤，说明哪些既有结果可以复用。没有依据时不额外叠加多套同类软件。

### 方案必须包含的内容

每个执行步骤需要唯一 `step_id`、目的、逻辑工具、版本要求、环境绑定、输入输出、数据库、argv 命令模板、参数、依赖、资源预算和成功或失败条件。输出路径使用 `{run_dir}`，运行输入通过 `{runtime.reads}`、`{runtime.reads_1}`、`{runtime.reads_2}` 或 `{runtime.fasta}` 绑定。命令模板首项是 `{executable}`，不能把随意拼接的 shell 命令当作计划。

交付物必须引用本计划中存在的步骤和输出键。跨样本分析使用 sample/cohort 范围，由系统依据已确认 manifest 展开；宿主不应自己编造成员列表。元数据、参数文件与适配器也属于需记录指纹的输入或代码。

流程参考采用说明位于 `workflow_decisions`。`use` 表示采用，`adapt` 表示依据输入调整，`not_applicable` 表示不适用。前两者需要关联实际执行步骤；不适用项应给出具体理由，并用空步骤列表。

```yaml
workflow_ids:
  - assembly-mag
workflow_decisions:
  - workflow_id: assembly-mag
    disposition: adapt
    reason: 已提供受检contigs，从DNA覆盖度计算开始。
    step_ids: [coverage, binning, quality]
```

这里是结构示例，步骤 ID 必须替换为当前方案真实存在的 ID。`plan.workflow_reference_evidence` 应使用先前 `planning.context` 返回的回执，不能自行编造路径或指纹。

### 校验和保存

宿主可先预览依赖，再校验候选。`plan.validate` 检查结构与参考采用说明；`plan.save` 还检查项目需求、已确认输入、交付物和文档读取回执，并保存待审阅方案。校验成功不自动批准执行。

```bash
microbiome call plan.validate --file /work/candidate-arguments.json
microbiome call plan.save --file /work/save-arguments.json
```

前一个 JSON 文件形如 `{"plan": {...}}`；后一个还需要 `"project":"/work/study-a"`。省略号仅表示此处不重复完整候选，不是可执行 JSON。通常由宿主根据需求生成文件，用户重点审查科学选择、输入、资源和验收条件。

## 8 审阅决策与授权边界

轻量接口保留独立的操作员决策通道。宿主能生成方案、展示材料和查询状态，但 MCP 不提供批准操作。用户在自己的交互终端审阅精确材料，并对其内容指纹作决定。

| 决策主题 | 用户核对的材料 |
| --- | --- |
| input | 样本 ID 文件路径布局及解析结果 |
| dataset | 样本信息平台分组与统计设计 |
| target | 分析对象参考需求和适用范围 |
| analysis_goal | 分析目的产物和范围 |
| analysis_plan | 实际步骤参数资源引用与验收 |
| dependencies | 复用与待准备资源及批准范围 |
| production | 小试验收摘要冻结锁与全量范围 |

```bash
microbiome call decision.inspect --json \
  '{"project":"/work/study-a","topic":"analysis_plan"}'
microbiome decide --project /work/study-a \
  --topic analysis_plan --action CONFIRM \
  --expected FULL_DECISION_FINGERPRINT
```

把 `FULL_DECISION_FINGERPRINT` 替换为当前审阅响应中的完整 `decision_fingerprint`。终端会再次展示材料，并要求输入它显示的确认挑战。内容在审阅后变化时，旧指纹会被拒绝，应重新检查。`MODIFY` 和 `CANCEL` 用于修改或取消当前主题的决定。

输入、方案、依赖与生产是不同决定。确认方案不等于批准所有可能用到的软件，也不等于允许全量运行。此分离由当前接口的代码边界决定，不是通过在提示词中写一句“请谨慎”实现。不要使用管道、脚本代答或让模型冒充操作员输入挑战。

## 9 软件与数据库的发现和准备

### 按能力发现已有软件

查找顺序为冻结锁、已验证工具注册表、Skill 映射、所有现有 Conda 环境、PATH 与项目软件目录，然后查询 Conda 元数据，最后才考虑经批准的安装。环境名称与规划器建议不同，只要能力与版本得到验证，就应复用。

```bash
microbiome call software.inspect --json \
  '{"project":"/work/study-a","logical_tool":"spades",
    "executable":"spades.py","software_family":"spades"}'
```

逻辑工具名、软件家族、包名、可执行文件名、环境名、环境前缀和 Skill ID 是不同字段。检查工具时应保持这些身份清楚，不能根据一个别名猜测包名。`NEEDS_PACKAGE_MAPPING` 表示缺少可验证包映射；应补齐官方文档或包元数据依据，然后重新提出依赖计划。

### Skill 数量与清单

正式包共有 141 个 Skill：107 个软件资源 Skill、33 个数据库资源 Skill、1 个供宿主读取的薄 Skill。22 份 workflow 参考另行统计。完整名称及文档路径见[项目 Skill 完整清单](skill_inventory.md)。数量不表示这些工具已安装或 READY，也不表示 21 条科学路线均已端到端验收；历史源码副本与安装副本不重复计数。

### 三层资源记忆

| 层 | 保存内容 | 主要用途 |
| --- | --- | --- |
| Registry | 路径版本状态实际运行入口与指纹 | 提供可核验的资源事实 |
| Skill | 输入输出用法选择条件与参数指导 | 帮助规划正确调用 |
| Knowledge | 验证调用失败修复和安装历史 | 复用经验并避免重犯错误 |

缺少 Skill 不代表软件不存在。反过来，存在 Skill 也不表示软件已经安装。工具注册 READY 前需要真实可执行文件、版本与帮助检查；数据库注册需要相应 marker、入口、版本和指纹检查。

### 依赖计划与安装

保存并确认分析方案后，调用 `dependencies.review` 形成依赖报告，再审阅 `dependencies` 决策。准备工作只能处理当前已批准范围内的资源。新增依赖要形成新版本并重新批准，不能在失败修复时顺带安装未审阅的软件。

```bash
microbiome call dependencies.review --json \
  '{"project":"/work/study-a"}'
```

获批后，提交 `bootstrap` 作业可发现、验证或在允许阶段创建独立环境。禁止安装进 base/root，禁止删除健康用户环境，也不能覆盖非 Conda 目录。重试应有边界；安装成功的判断来自实际验证，不来自安装器最后一行文字。

执行绑定保存准确的 Conda prefix 和可执行文件。生产不依赖用户终端当时激活的环境，也不应把已核实的 prefix 改回一个可能指向别处的环境名。

### 持久数据库

数据库、索引和参考放在用户指定的持久根目录中。READY 资源直接复用；缺失、损坏、不完整或漂移应停止相应步骤，并转入单独维护过程。获取和本地化要有明确来源、许可条件、批准范围、部分下载处理和完成验证。

当前轻量 `resolve_databases` 作业用于核验已准备好的数据库，不是一个任意下载器。缺失数据应通过已批准的资源获取流程或操作员准备后重新核验。原始样本下载与数据库获取有各自的标识与授权，不能混为一个“缺资源就下载”的操作。

## 10 小数据预检与冻结

完整的依赖准备顺序通常是 `bootstrap`、`resolve_databases`、`pretest`、`finalize`。每个作业都返回持久 job ID；确认前一作业完成后再提交下一阶段。同一项目有操作锁，避免多个宿主同时改变执行状态。

```bash
microbiome call job.start --json \
  '{"project":"/work/study-a","operation":"bootstrap","request_id":"bootstrap-1"}'
microbiome call job.start --json \
  '{"project":"/work/study-a","operation":"resolve_databases","request_id":"databases-1"}'
```

本章的轻量 `job.start` 预检接口使用确定性子集，可指定 0.05 到 0.10 的抽样比例。它保留全部生物学样本，对每个样本抽取完整序列记录；双端同步抽样。宿主不能另传一套未经确认的 runtime inputs 覆盖持久清单。endpoint 对话路线的默认样本选择见第 12 章。

```bash
microbiome call job.start --json \
  '{"project":"/work/study-a","operation":"pretest",
    "request_id":"pilot-1",
    "parameters":{"fraction":0.1}}'
```

小试应覆盖所有选定的软件和格式接口，检查输出能否解析、ID 是否一致、计数与配对是否合理，以及任务对应的科学质量指标。统计模型的验证需要保留研究设计；不能为得到显著结果改组别或过滤规则。子集不足以检验某个模型时，应修订方案并重新审批。

失败应保留日志与最小重现证据，区分输入、路径、环境、依赖、数据库、参数、资源和输出验证问题。修复只在允许的预生产阶段进行。修复改变了科学参数、工具或数据库时，需要重新验证相应流程，不应继续沿用旧锁。

```bash
microbiome call job.start --json \
  '{"project":"/work/study-a","operation":"finalize","request_id":"freeze-1"}'
```

`finalize` 只在符合状态要求的成功预检后执行。它生成并核验 pipeline、toolchain 和 database lock，以及生产就绪记录。冻结内容包含步骤顺序、命令模板、参数、输入输出契约、工具路径与版本、数据库入口与指纹、验收证据和流程参考出处。后续更新参考文档不会改变这次生产锁。

## 11 全量生产与长任务管理

冻结完成后，审阅 `production` 决策材料。它包含预检摘要、锁定资源及全量范围。确认后再提交生产作业；生产执行前仍会核对输入、资源和锁的指纹。

```bash
microbiome call decision.inspect --json \
  '{"project":"/work/study-a","topic":"production"}'
microbiome decide --project /work/study-a \
  --topic production --action CONFIRM \
  --expected FULL_DECISION_FINGERPRINT
microbiome call job.start --json \
  '{"project":"/work/study-a","operation":"production",
    "request_id":"full-1",
    "parameters":{"run_id":"full-1","threads":16,"memory_gb":64}}'
```

示例 CPU 与内存仅用于演示参数位置，应根据机器和已批准计划设置；它们不表示任何具体生信任务的推荐需求。生产按锁运行，不调用规划器改变步骤，不临时安装、下载、修复软件或变更科学参数。

### 查询和取消

`request_id` 标识一次逻辑提交；相同 ID 和参数的重试返回已有 job，参数变化则拒绝复用。`job_id` 标识持久后台作业，用它查询进度。不要因为聊天断开就换一个 request ID 重复提交。

```bash
microbiome call job.status --json \
  '{"project":"/work/study-a","job_id":"RETURNED_JOB_ID"}'
microbiome call job.cancel --json \
  '{"project":"/work/study-a","job_id":"RETURNED_JOB_ID"}'
```

取消请求返回后，继续查询直到终态。取消保留已有科学产物，不把中断阶段改写成成功。作业状态可为 queued、running、completed、failed、cancelled 或 interrupted。完整日志与结果留在磁盘，响应提供对应路径。

### 切换宿主与恢复

正常关闭 MCP 或聊天进程不会自动杀死已分离的本机 worker。另一个宿主可使用相同执行机器上的绝对项目路径与 job ID 查询。模型账户、聊天 ID 或原宿主窗口不是作业的所有者。

机器重启、强制终止或科学程序中途失败时，应先查看 `project.inspect`、`job.status` 和日志。当前接口不承诺任意阶段无条件自动恢复。生产恢复使用原 `run_id` 与 `resume: true`，但仍受原有检查点、状态和资源漂移检查约束。

```bash
microbiome call job.start --json \
  '{"project":"/work/study-a","operation":"production",
    "request_id":"full-1-resume",
    "parameters":{"run_id":"full-1","resume":true}}'
```

此示例表示明确提交一次恢复请求，不保证任何失败状态均可直接接受。若状态要求维护或重新验证，先处理该原因。不要手改状态文件把失败伪装成通过，也不要删除锁来绕过检查。

## 12 直接使用已有模型服务端口

endpoint 客户端适合已经有本地或明确指定模型服务的用户。它使用 OpenAI 兼容的模型列表和聊天接口，探测地址提供的模型，不自动启动推理服务。指定服务应自行对当前执行机器提供可访问的端口。

```bash
microbiome endpoint --endpoint http://127.0.0.1:8000 --check
microbiome endpoint --endpoint http://127.0.0.1:8000 \
  --project /work/study-a
```

地址省略 `/v1` 时会规范化到对应接口；典型请求为 `GET /v1/models` 和 `POST /v1/chat/completions`。客户端优先考虑服务声明的默认模型或唯一模型，最多检查 3 个候选，每次发起至多 16 token 的短生成探测；`--check` 也会执行这类推理请求。用户不需要另外填写模型 ID、供应商或密钥。该地址必须提供相应协议，任意宿主聊天窗口并不等于模型服务端口。

```bash
microbiome endpoint --endpoint http://127.0.0.1:8000 \
  --project /work/study-a \
  --prompt '先核查本地样本和现有资源，再讨论细菌MAG方案'
```

endpoint 复用现有持久对话工作流。用户先讨论方案，按界面要求明确回复“确认执行”开展批准范围内的准备与小试，验收和冻结后再回复“确认全量执行”。这条显式对话路线与 MCP 的操作员终端审批接口分别保留，不应把二者的命令混为一套。

endpoint 对话路线默认可按输入类型和组别选择代表样本进行预检；包含 cohort 跨样本步骤时保留全部样本。它与第 10 章轻量作业接口始终保留全部样本的策略不同，审阅时应核对实际样本范围，尤其是涉及组间比较和重复的任务。

endpoint 的对话内执行不自动变为第 11 章的分离后台 job；需要断开后持续查询的轻量作业，应使用 `job.start` 提交并保存 job ID。

先用 `--check` 区分端口不可达、协议不兼容、没有模型和模型不可用。连接成功后继续使用已初始化项目，遵守相同的输入确认、参考阅读、方案审阅与执行边界。模型服务拒绝访问或需要认证时，应修复该服务的本机接入配置；客户端不会读取浏览器、Codex 或 WorkBuddy 的会话凭据来代替认证，也不会自动切换到其他云端服务。

| 地址类型 | 示例 | 对端提供的能力 |
| --- | --- | --- |
| 模型服务 | http://127.0.0.1:8000 | 模型列表与聊天生成 |
| Microbiome MCP 服务 | http://127.0.0.1:8765/mcp | 目录项目计划资源与作业工具 |

## 13 结果检查与故障定位

### 查看哪些产物

项目根保存项目配置与实验方案。需求、预检、锁和报告可能位于独立输出根；不要假定所有内容都在同一个目录。使用 `project.inspect` 返回的实际路径定位。

| 产物 | 检查重点 |
| --- | --- |
| input_manifest.yaml | 样本与文件是否对应来源是否已确认 |
| experiment_plan.yaml | 实际步骤参数交付物及参考采用说明 |
| dependency_gap_report.yaml | 复用资源待准备项及批准范围 |
| validation_report.json | 每步执行与输出断言证据 |
| pipeline.lock.yaml | 冻结 DAG 输入输出参数与验证来源 |
| toolchain.lock.yaml 和 database.lock.yaml | 软件环境数据库入口版本及指纹 |
| reports 与执行日志 | 成败原因科学质量指标与最终产物 |
| state/portable/jobs 中的记录 | 作业请求进程身份状态日志和结果 |

验收报告时，先核对样本、数据库版本和参数，再看质量指标与科学结果。分类丰度通常是相对量；未分类、未注释或模型不适用项应保留。差异分析要检查纳入样本、对照、效应量、多重检验和模型诊断，不能只看显著条目。系统发育树需要结合比对、支持度、参考采样和方法限制解释。

### 常见问题

| 现象 | 优先检查与处理 |
| --- | --- |
| 找不到本地 FASTQ | 检查执行机器路径和清单文件本身不要改成 SRA |
| 宿主看不到 MCP 工具 | 检查解释器路径服务启动日志与宿主配置位置 |
| HTTP 端口连接失败 | 区分模型端口与 MCP 端口确认进程地址和协议 |
| 提示缺少 Skill | 先检查软件发现报告及已有环境不立即安装 |
| NEEDS_PACKAGE_MAPPING | 补齐官方包名可执行文件关系再审阅依赖 |
| STALE_DECISION | 材料已变化重新 inspect 并审阅新指纹 |
| PROJECT_BUSY | 查询当前作业避免并行修改同一项目 |
| STALE_JOB | 提交后契约变化先检查项目状态不要自动重提 |
| 资源或输入漂移 | 保留证据转入维护和重新验证 |
| 进程中断 | 查看持久状态和日志按阶段决定恢复或重新预检 |

### 验证范围

前一轮 2026 年 9 月 29 日核心回归覆盖 21 个测试文件，286 项通过，包括流程目录、参考传递、资源发现、审批边界与冻结执行。endpoint 与 portable 接口联合测试另记录 18 项通过，包括真实本机 HTTP MCP 握手，以及本地模拟模型服务驱动的持久对话。兼容性批次有 4 项因缺少 `langchain_anthropic` 而跳过。各批次存在重叠，不相加为总数；详细范围、命令与发行包检查见[本轮验证记录](validation_host_integration.md)。这些是工程验证，不等于 21 类真实生物分析全部通过。

本轮打包前另复核 21 份科学参考并新增基础统计参考；目录、全文参考传递和 sample 到 cohort 生命周期的 3 个测试文件合计 70 项通过。最新完整回归与候选包安装结果以[打包前验证记录](validation_host_integration.md)为准，不把不同批次的数字相加。

真实使用还需要在目标机器核查具体工具版本、数据库、文件接口和任务级质量。WorkBuddy 各版本连接器、所有宿主的完整人工操作、集群调度与跨机器故障迁移，不属于当前工程测试可以替代的验证范围。

## 14 维护与源码导航

### 扩充流程说明

新增方法目录使用 `workflow.yaml` 和 `GUIDE.md`。YAML 保存稳定 ID、语义版本、别名、适用条件、输入、澄清问题、阶段、产物、资源引用、验收、局限与一手来源；正文解释如何选择和判断。声明 `CURATED_REFERENCE` 与 `executable: false`，不把文档状态写成资源 READY。

复用已有软件和数据库 Skill ID，未知资源明确标记发现需求。不要在参考文档中写入机器路径、密钥、自动批准语句或通用于所有研究的固定参数。修改方法应更新版本并核对内容指纹；已有冻结生产锁继续使用原验证内容，不能被新文档静默改变。

### 安装维护与卸载

源码根目录还提供受管理的安装器。它在指定 prefix 下创建版本化运行时，并在自检成功后提供入口，不修改 shell 配置，不安装全部科学软件。

```bash
bash install.sh --prefix /work/microbiome-managed
bash install.sh --prefix /work/microbiome-managed --upgrade
bash uninstall.sh --prefix /work/microbiome-managed
```

可用 `--python` 指定安装器使用的解释器，或对带校验清单且包含完整依赖 wheel 的发行包使用 `--offline`；离线包还需匹配构建时的 Python 次版本、操作系统和架构。默认 prefix 为用户目录下的 `.local/share/microbiome-runtime`。受管理安装器拒绝覆盖已有非托管目录；卸载仅禁用其拥有的入口，保留运行时和用户数据。使用前可查看安装器帮助，避免混用手动虚拟环境与受管理 prefix。

### 源码和进一步阅读

下列链接以手册所在的仓库 docs 目录为基准。把手册单独发送给他人时，还应提供对应源码版本，才能可靠追溯实现。

| 阅读目标 | 文件 |
| --- | --- |
| 默认入口与命令转发 | [microbiome cli](../microbiome/cli.py) |
| JSON 操作和审批边界 | [integration service](../microbiome/integrations/service.py) 与 [CLI](../microbiome/integrations/cli.py) |
| MCP 和模型端口客户端 | [MCP server](../microbiome/integrations/mcp_server.py) 与 [endpoint client](../microbiome/integrations/endpoint_cli.py) |
| 长作业与取消恢复 | [durable jobs](../microbiome/integrations/jobs.py) |
| 完整参考目录 | [workflow catalog](workflow_catalog.md) 与 [catalog loader](../microbiome/workflows/catalog.py) |
| 规划证据与编译 | [planning context](../microbiome/pipeline/planning_context.py) 与 [study](../microbiome/pipeline/study.py) |
| 资源解析与知识 | [resources](../microbiome/pipeline/resources.py) 与 [knowledge](../microbiome/pipeline/knowledge.py) |
| 冻结生产机制 | [frozen pipeline](frozen_pipeline.md) 与 [executor](../microbiome/pipeline/execution.py) |
| 跨样本统计接口 | [cohort workflows](cohort_workflows.md) |
| 宿主配置与部署边界 | [portable integration](portable_integration.md) |

开发者可运行针对本次改动的测试和以下冻结执行回归。测试失败时保留日志，定位契约差异，不通过删除断言或修改状态来制造成功。

```bash
pytest -q tests/test_workflow_catalog.py
pytest -q tests/test_workflow_planning_references.py
pytest -q tests/test_portable_integration.py
pytest -q tests/test_frozen_pipeline.py
```

方法细节的一手来源集中保存在各流程 GUIDE 与 YAML 中，包括 SPAdes、CheckM2、GTDB-Tk、BUSCO、EukCC、STAR、DADA2、IQ-TREE 等官方文档及原始研究。更新这些来源时，应同时核对当前安装版本的帮助和实际接口，而不是自动升级已 READY 的资源。
