# Agent 维护与阶段文件权限

维护工具让 agent 在任务范围内读取项目事实、保存草稿、修复输入声明、清理自有临时文件和导出记录。0.2.3 增加能力握手、直接结构化输入更正和独立数据库候选服务，见[发行说明](releases/0.2.3.md)；科学执行、资源准备和维护使用各自的服务，维护操作不会生成科学批准。

0.2.4 增加规划预算维护、持久检查点和清理引用保护，参数与边界见[0.2.4 发行说明](releases/0.2.4.md)。

## 阶段与范围

| 场景 | 可以写入 | 可以清理 | 保持保护 |
| --- | --- | --- | --- |
| 需求与规划 | 当前项目草稿；允许阶段的 scratch；带版本的输入声明 | 已登记且未被外部修改的草稿/临时文件 | 原始数据、未知文件、已有资源 |
| BOOTSTRAP / PRETEST_REPAIR | 批准依赖计划指定的新软件前缀或资源准备范围 | 维护登记的自有临时产物 | 健康环境、READY 资源、范围外依赖 |
| 预检执行 | 当前尝试的临时视图及声明输出；独立需求草稿 | 运行结束后再清理已登记失败产物 | 原始输入、上游结果、审批记录 |
| 冻结与生产 | 当前批次声明的输出、执行证据；独立需求草稿 | 无活跃运行时按登记清理自有产物 | 冻结锁、软件、数据库与科学参数 |
| 完成与失败 | 新草稿和导出；合法修复由对应版本化服务处理 | 草稿隔离/恢复，临时文件隔离/恢复/永久删除 | 正式科学结果与审计证据 |

并非项目目录中的所有文件都归 agent 所有。创建者登记、路径、类型、指纹和当前阶段共同决定权限；不能给任意旧文件补一个所有权标签后删除。正式日志和审计证据不属于普通 scratch。

原生命令看到只读宿主文件系统和明确可写的当前工作视图，子进程继承边界。只有成功步骤声明的输出由控制器发布，未声明副产物不会写回正式输出。失败暂存产物单独保留并登记，重试不依赖先前未声明的隐含文件。需要额外输出时应修改输出合同并重新验证。

## 工具参数

Harness 的 `microbiome_maintenance` 复用当前会话绑定的项目，调用参数为 `operation` 与 `arguments`。九个操作共用 [maintenance_contract.json](../microbiome/pipeline/maintenance_contract.json)，由 Python、CLI、MCP 与 Harness 在各自入口使用同一契约验证：

| operation | 用途 |
| --- | --- |
| `inspect` | 查看摘要、输入状态、已登记产物、待处理操作或权限 |
| `list_directory` | 在指定绑定目录内分页列出一层文件元数据 |
| `read_artifact` | 分页读取绑定目录中的受限文本，无需写入所有权 |
| `read_diagnostic` | 分页读取输入或编译诊断，并标明是否仍为当前阻塞 |
| `write_draft` | 保存任务草稿或允许阶段的 scratch |
| `repair_input` | 保存并验证带来源和版本的有效输入更正 |
| `cleanup` | 预览、隔离、恢复或删除允许范围内的登记产物 |
| `export` | 导出实际可见记录及覆盖说明 |
| `planning_policy` | 查看、测量、有限调整或回退规划预算；不改变执行合同 |

先用 `inspect` 获取实际阶段、当前阻塞与 `effective_paths`；不能凭默认目录名猜测位置：

```json
{"operation":"inspect","arguments":{}}
```

摘要中的目录条目包含实际路径、来源、存在状态和读取范围；`read_allowed` 不表示可写。`inspect` 的 `section:"permissions"` 返回各操作完整参数 schema；`input`、`artifacts`、`pending` 分区支持分页。未知参数返回结构化字段错误与建议调用，不通过尝试 shell 或直接编辑注册表绕过接口。

`inspect(section="summary")` 的 `diagnostic_snapshot` 汇总当前阻塞、已解决的历史诊断、仍有效的输入与需求事实、检查点是否真的保存了候选、规划预算、宿主容量缺口和一个有负责方的 `next_action`。快照只读取固定项目控制记录，每个记录上限 1 MiB，快照 JSON 上限 16 KiB；省略内容明确列在 `limits.truncated_fields`。原始数据、凭据和任意诊断路径不会被读取，文件详细内容继续使用现有分页读取接口。

容量未知的预算错误应交给 `host_adapter` 取得实际模型元数据；仅调整证据片段大小不能修复宿主容量传递。快照中的后端 `planning_ledger` 只统计内部规划调用，外层模型的工具选择与诊断调用需结合宿主 usage 事件核算。持久清单指纹通过只表示记录自身完整，不替代执行前对真实输入文件的核验。

### 目录、文本与完整诊断

读取使用 `root` 选择持久绑定，取值为 `raw_data`、`database`、`output`、`download`、`knowledge`、`project`；`path` 必须是该 root 下的相对路径，不能是绝对路径或包含 `..`。root 本身不一致时先核对绑定项目，不能在读取参数中另指定新根目录。

```json
{"operation":"list_directory","arguments":{"root":"raw_data","path":".","limit":50}}
```

```json
{"operation":"read_artifact","arguments":{"root":"project","path":"project_config.yaml","limit":4096}}
```

```json
{"operation":"read_diagnostic","arguments":{"diagnostic_id":"compiler_failure","limit":4096}}
```

`diagnostic_id` 为 `input_resolution` 或 `compiler_failure`。先检查返回的 `diagnostic.current` 和 `diagnostic.status`；旧失败文件仍存在不代表当前任务还被它阻塞。文本读取单文件最多 16 MiB，每页 `limit` 最多 65536 个 Unicode 字符；目录或分区每页最多 100 条。需要更多内容时原样传回 `next_cursor`，保留原操作、root/path 或 diagnostic_id，直到 `next_cursor` 为 null。cursor 已包含位置与快照，不同时传 `offset` 或 `snapshot`。收到 `SNAPSHOT_CHANGED` 时从第一页重新读取，不能拼接不同快照。

目录读取是非递归的；按返回的子目录继续定位。文本读取会脱敏，秘密存储、链接、非普通文件、二进制或过大文本会明确拒绝。读取用户文件不要求先把它登记为 agent 所有；读权限不允许接管、修改或删除该文件。

### 草稿、清理与导出

可写草稿位于输出目录的 `.agent-workspace/drafts/`；scratch 位于 `.agent-workspace/scratch/`。使用相对路径：

```json
{"operation":"write_draft","arguments":{"path":"requirements.md","content":"用户目标与尚待确认的问题","role":"draft"}}
```

返回文件路径、artifact 标识及维护版本。后续清理优先使用返回的标识，默认 preview 展示受影响文件；quarantine 将文件移到可恢复区域，restore 恢复，purge 只适用于 scratch。清理不递归接受整个项目路径，不采用宽泛通配符。

```json
{"operation":"cleanup","arguments":{"artifact_ids":["返回的实际标识"],"action":"preview"}}
```

输入更正通过 `repair_input` 保存新声明及来源消息。`expected_input_revision` 可检查输入版本，避免覆盖并发更正；冻结后保存待处理请求。活跃任务持有执行锁时，该操作返回 `PROJECT_BUSY`，可先用 `write_draft` 保存更正要求，待任务结束后提交。`APPLIED` 仅表示更正已保存，必须检查 `validation_status`、`resume_ready` 和 `next_action`；不把文字声明当成已验证文件。

```json
{"operation":"repair_input","arguments":{"declaration":"原始数据使用已经核对的本地清单。"}}
```

`export` 默认生成新的项目导出文件；用户明确指定的绝对 JSON 路径或已有目录可作为 destination，拒绝覆盖已有目标。返回路径、哈希与覆盖范围：

```json
{"operation":"export","arguments":{}}
```

写入、修复、清理和导出使用稳定 `request_id`，不确定是否完成时重试相同 ID；已完成请求返回原结果，同一 ID 配不同内容会拒绝。只读操作读取当前状态，分页一致性由 snapshot/cursor 保障。`expected_revision` 检查维护登记版本。便携 `project.maintain` 还需提供 project、user_message、message_id、session_id；这些是调用宿主提供的真实来源声明，不是独立身份认证。模型不能用维护接口替代科学批准。

## 输入事实与恢复规划

输入状态分别记录文件/目录、样本与资源角色、清单模式、布局、远程标识、来源和验证结果。新消息更新相关有效字段，历史仍用于审计；已经确认的输入使用持久清单。需求原文保存为未确认草稿，不能因输入报错丢弃，也不能把未解析描述伪装成已验证样本。

路径错误先读取实际绑定和目录。若当前授权范围内只有一个可核实且不改变样本选择的候选，可据实更正并记录来源；多候选、缺少决定性事实或更正会改变样本集合时，再请用户澄清。缺少本地文件不是 SRA 下载指令；资源目录也不是原始数据。不要让用户重写已经保存的研究目标或填写内部 JSON。

Harness 中，完成 `repair_input` 后检查回执的验证结果，再读取维护回执顶层 `planning_recovery`；必要时重新 `inspect` 获得当前 token。只有 `available:true` 才调用：

```json
{"recovery_token":"从当前 planning_recovery 原样复制的 64 位 token"}
```

以上是 Harness 工具 `microbiome_resume_planning` 的参数，不是 maintenance 的第九个操作。它通过当前宿主模型恢复输入核验和方案编译，保存助手恢复记录，不新增或伪造用户消息，不重放历史批准；成功后停在方案审阅。使用返回的 job_id 等待任务，不能再次提交原用户消息来模拟恢复。token 过期或不可用时按 `reason` 检查当前事实；相同证据已尝试的任务复用回执，不无限循环重试。

便携 JSON CLI 的 `project.recovery` / MCP 的 `microbiome_planning_recovery` **只读**。便携宿主读取检查点后，沿已有 `microbiome_planning_context`、`microbiome_plan`（`plan.validate` / `plan.save`）与相应决策接口继续；它没有 Harness 模型恢复的副作用，不能把读取成功当成恢复已执行。输入、依赖、预检和生产的原有确认规则继续生效。

数据库候选必须使用 `database:{alias:descriptor}`，alias 对应实际命令绑定。唯一且明确的 alias 可做结构规范化，其余错误进入有次数上限的内部编译修复。失败记录在 `compiler_repair` 及其 `blocker`，可通过 `read_diagnostic` 查看；不会自动补造路径、版本或 marker。

## 资源证据与阶段责任

`list_directory` / `read_artifact` 用于核实存在什么及其记录内容；它们不授予 `READY` 状态。当前版本没有新的正式数据库候选绑定/注册 API，仍由既有受控 bootstrap/repair 路线验证运行入口、版本、marker、consumer 合同和指纹后注册。描述性版本文字、`UNKNOWN` 或未经核验的 glob 不能冒充通过的资源合同。

规划层应保留研究目标并报告资源证据缺口。需要获取或修复资源时使用当前批准范围与正确阶段，不能删除必要步骤、更换研究目标或改科学参数来掩盖缺资源。维护工具不开放通用 shell、任意注册表写入、健康环境删除或冻结合同修改。

## 故障处理

输入解析报错时保留原始数据和现有项目，先检查已绑定目录与诊断，再保存更正。相同输入和相同错误不应无限重复规划。需求草稿中未确认的陈述不自动成为已确认的样本或研究事实。

项目锁放在用户状态目录，兼容旧版项目内锁。草稿、查看与导出使用独立维护登记锁，可与长任务并行；会改变输入或清理运行相关产物的动作还需要项目操作锁。检测到活跃任务、文件变化、符号链接或未知所有权时返回具体错误。

导出会明确区分宿主提供的事件、项目已有记录和不可见内容，并记录遗漏原因。导出期间运行可能继续产生新事件，因此它是有覆盖说明的诊断快照；不能称为宿主完整对话数据库的备份。

宿主提供 `microbiome/export-integrity` 尾记录时，`coverage.visible_host_events_complete` 表示本次可见事件的正文、工具结果和关联是否完整；`exported_scope_complete` 还要求没有遗漏允许导出的项目记录。尾记录缺失或检查失败时，两者不会误报成功，原因列在 `coverage.issues`。整体 `complete` 和 `host_database_complete` 仍为 false，因为该导出不具有读取完整宿主数据库的能力。

项目初始化可由可信宿主通过 `path_confirmation` 声明路径来源：`user_direct` 保留真实用户确认；`host_delegation` 必须携带实际 `user_request` 与来源，记录有效确认但 `confirmed_by_user=false`；`configured` 仅记录配置值，等待路径确认。旧的显式用户路径调用保持兼容，重开既有项目不会重写原来的路径确认审计。
