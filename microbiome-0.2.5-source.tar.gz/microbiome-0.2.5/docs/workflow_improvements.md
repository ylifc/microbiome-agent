# 持久化六阶段工作流

当前 `microbiome`、`biomni`、`microbiome-run` 都是同一个宿主工具入口：无参数显示接入帮助，`init/call/decide/export` 调用结构化 pipeline 服务。用户在已有 Codex、WorkBuddy、VS Code 等宿主中讨论任务，模型与认证由宿主管理，无需再次配置 provider、模型名或 API Key。接入方式见 [可迁移宿主集成](portable_integration.md)。

本文保留 `ConversationWorkflow` 六阶段对话及历史改进记录。显式 endpoint 对话和旧版兼容会话仍使用 `microbiome/agent/workflow.py`；普通 MCP 接入由宿主通过服务操作推进。所有路径的生产执行器均重放已验证的 lock，不调用规划模型。

## 使用方法

```bash
# 初始化用户指定的持久路径；不连接模型、不安装分析工具
microbiome init --project /project/workflow --raw-data /project/raw \
  --database /project/databases --output /project/results

# 导出后由用户按宿主规则导入；也可选择 vscode 或 workbuddy
microbiome export --host codex --output /new/microbiome-integration

# 重启后读取同一项目状态，继续在宿主中处理
microbiome call project.inspect --json '{"project":"/project/workflow"}'

# 若选择已有本地模型服务，可显式指定其端口并恢复对话
microbiome endpoint --endpoint http://127.0.0.1:8000 --project /project/workflow
```

MCP 默认通过 stdio 接入；需要本地 HTTP 工具端口时运行 `microbiome mcp --transport http --port 8765`，地址是 `http://127.0.0.1:8765/mcp`。这与 `endpoint` 指向的模型 API 是两种接口。`endpoint` 自动发现并探测可用 chat 模型，不读取宿主私有凭据；只有认证后才能访问的服务需要由已有宿主提供可访问的路由。

项目配置保存原始数据、下载、数据库、结果、知识记录目录。只有列入当前依赖方案、展示并确认的安装才会执行。恢复现有项目会使用持久路径；改变冻结路径会阻止生产预检。MCP/JSON 工具不自行批准方案，服务模式的审核通过 `microbiome decide` 在真实交互终端记录。

以下自然语言确认和重试指令说明 `ConversationWorkflow` 对话路径；endpoint 会话沿用这些机制。旧版会话 CLI 已显式更名为 `microbiome-legacy-run`，原有参数仅在该兼容命令下使用：

```bash
# 可选旧版独立会话兼容入口，使用其显式配置的独立模型
microbiome-legacy-run --no-prompt-paths \
  --data /project/raw --download-dir /project/downloads \
  --db-dir /project/databases --results-dir /project/results
microbiome-legacy-run --project /project/results
```

1. 提供研究目标和本地文件、目录、样本清单或明确的远程 run accession。显式文件及目录限定输入范围；缺失文件、重复样本 ID 和缺失配对会作为输入问题返回。确认后的 `requirements/input_manifest.yaml` 持续传递到预检和全量运行。
2. 补齐样本与分析目标。规划器先讨论设计，再编译成声明输入、输出、软件版本、环境、参数、依赖、资源限制和验收条件的结构化方案。PubMed 检索结果参与最终方案编译；获取失败或无结果会如实展示，不会宣称已完成文献验证。
3. 只读检查本地 Registry、Skill 映射、现有环境、PATH 及数据库契约，给出可复用和缺失资源列表。只读预览写入 `plans/dependency_preview.yaml`，不会覆盖已批准的依赖报告。
4. 阅读展示的具体方案和依赖变更，回复 **确认执行**。这次决定绑定输入清单、方案和依赖范围；范围改变必须重新展示。资源齐全时显示无需安装。缺失的数据库需完整、确定的获取命令；命令变化会阻止执行。包管理器缺失时，官方发行版本、安装位置和 SHA256 先列入方案再执行。
5. 逐样本方案按输入布局和声明分组选取代表样本；跨样本方案保留全部生物学样本，只减少各样本的读数。每个案例运行整个 DAG。全部案例和每个计划步骤都必须通过；缺失的声明样本或生成目录中的伪原始输入在冻结前被拒绝。失败写入 Knowledge，不会自动重复相同失败设计；修订方案后重新确认。冻结管理文件整理失败时可回复 **重试冻结**，使用已保存的验证报告重试。
6. 预检及冻结就绪后，回复 **确认全量执行**。使用所有样本的完整输入，输出到 `runs/`；逐样本方案分别执行，跨样本方案执行一个包含全部成员的 DAG，汇总节点仅运行一次。冻结的参数、工具和数据库保持不变。最终返回批次报告及交付文件索引。

对话中可用 **修改输入 ...** 明确替换输入，或 **取消** 结束任务并保留已有数据。中断的全量批次使用 **恢复批次 batch-id**；执行器复核相同流程、样本和检查点，复用已验证输出。已发生分析失败的批次需要回归验证和新版本，不能借“恢复”重复失败流程。问题和含糊回答不会当作执行授权。

## 持久文件与验证依据

| 文件/目录 | 作用 |
| --- | --- |
| `project_config.yaml` | 五类持久路径与运行配置 |
| `state/conversation.json` | 对话、待确认方案、失败设计和验证报告位置 |
| `requirements/input_manifest.yaml` | 每个样本的明确来源、路径和输入范围指纹 |
| `plans/proposed_plan.yaml` | 向用户展示的完整待确认方案 |
| `plans/evidence_registry.yaml` | 检索问题、来源、访问时间、实际读取范围与状态 |
| `plans/planning_evidence/*.json` | 最终方案实际读取的 Skill、资源事实与分级历史；保存范围和内容指纹 |
| `requirements/decision_log.jsonl` | 需求、方案、依赖与生产授权历史 |
| `config/tool_registry.yaml`、`database_registry.yaml` | 软件和数据库的路径、版本、READY 状态及契约 |
| `resource_skills/software/*/command_schema.yaml`、`knowledge/tools/*/command_schema.yaml` | 新学习 Skill 和已知软件的本地帮助参数声明、覆盖范围与来源行号 |
| `knowledge/tools/*`（可自定义根目录） | 实际成功/失败调用、验收检查、错误签名及验证过的修复 |
| `pipeline/validation_suite.json` | 代表样本覆盖和所有案例报告指纹 |
| `pipeline/*.lock.yaml` | 全量执行的软件、数据库、参数和输入绑定依据 |
| `runs/*.production_batch.yaml` | 执行前即保存的完整队列，逐样本更新状态 |
| `reports/*-batch-report.md`、`*-artifact-index.json` | 全量状态、逐样本报告、已验证文件索引及未完成项 |

文献检索使用 [NCBI E-utilities](https://www.ncbi.nlm.nih.gov/books/NBK25499/)，在单进程内控制请求频率；实际读取的范围是标题和摘要，不等同于读完全文或完成方法学验证。原始 run 下载使用 [ENA 文件报告](https://ena-docs.readthedocs.io/en/latest/retrieval/programmatic-access/file-reports.html) 的文件 URL、大小和 MD5。混合清单只下载远程记录；本地样本不重复获取。原始样本下载与参考数据库获取分别授权和管理。

## 旧项目兼容与边界

旧执行日志仍可用于恢复管理文件，但成功日志不能自动确认需求或依赖。`finalize_successful_pretest(..., review_requirements=...)` 仅生成待审核恢复方案；审核其具体命令、路径和研究目标后，调用 `approve_recovery(project, proposal_fingerprint, user_message)` 保存真实决定，再执行 finalization。已批准的恢复快照可以恢复丢失的管理文件；已冻结 lock 不会被兼容路径覆盖。

自动对话编译支持逐样本 FASTQ/FASTA DAG，以及 `execution_scope: cohort` 的跨样本 DAG。跨样本方案由持久输入清单展开逐样本节点和一次汇总/统计节点；预检保留所有生物学样本，并同步抽取每个样本的双端记录。组间统计仍需明确样本分组、生物学重复、统计设计、多重检验策略和经过验证的适配器。详见 [跨样本工作流](cohort_workflows.md)。报告只汇总可核查的结果，不编造科学结论。

生成的参数文档标为 `partial_help_extraction`：记录本地帮助实际列出的选项、占位符、默认值和行号。帮助未说明的类型、必填性或默认值标为未知；子命令和任务特定参数仍需查阅该版本帮助，并经过真实输出验收。退出码为零或聊天打印“成功”都不能单独成为正确调用或修复的证据。

输入漂移检测沿用文件大小、修改时间与首尾内容指纹，不是全文件密码学完整性证明；下载采用完整校验和。批次当前顺序执行，每一步使用冻结资源策略分配资源。未提供完整性元数据的任意远程 URL 不会自动下载。

## 验证

新增 `tests/test_persistent_workflow.py` 使用合成 FASTQ 和真实文件命令验证确认、预检、冻结、批次中断恢复、检查点复用、输出索引和输入漂移。网络、远程下载和安装边界使用隔离替身，不安装软件、不下载真实样本或数据库。

```bash
pytest -q tests/test_frozen_pipeline.py
pytest -q tests/test_persistent_workflow.py tests/test_pretest_evidence.py tests/test_pretest_finalization.py
```

### 此前六阶段工作流验收记录

- 全套初跑：620 项通过，2 项失败。失败是旧测试仍期待在生产预检时拒绝非法输入，而新实现提前在冻结前拒绝；缺失文件异常现也统一为 `FreezeError`。
- 更新后，路径策略、生产输入绑定及持久工作流组合回归：37 项通过。
- 冻结流程、预检最终整理和资源解析最终回归：59 项通过。
- 持久入口与 CLI 最终回归：24 项通过；另补测失败预检的上下文保留与禁止原样重试。
- 修改文件的 Python 语法、Ruff F/E9 检查及 `git diff --check` 通过。

全套初跑后未重复运行耗时的整个套件；上述修复与后续入口调整均分别复验。真实模型服务的方案质量、具体研究任务的软件/数据库准备及真实数据的科学验收，需要在实际部署任务中确认。

## 资源契约与工具目录改进（2026-09-09）

按规划取证、历史分级、环境判定，数据库与跨样本契约，工具目录扩充的顺序实施：

| 范围 | 已实现行为 | 主要文件 |
| --- | --- | --- |
| 规划取证 | 加载项目学习到的 Skills；显式依赖不受检索条数截断；编译器改变工具、环境、数据库或参数后重新读取证据；最多三轮，无法稳定时阻止提交 | `pipeline/planning_context.py`、`agent/workflow.py` |
| 历史分级 | 成功调用必须有输出验收；旧 Markdown 与无验收日志标为未验证；错误与修复按签名归并，并按版本、环境、数据库区分；修复必须关联完整的 PASSED 报告 | `pipeline/knowledge.py`、`software_memory.py` |
| 环境判定 | 逐个候选环境探测 R/Python 包及函数；解释器存在不能证明分析包可用；共享可执行名称不能任选一个软件 Skill；安装请求包含已审批的完整依赖集合 | `resource_skills/runtime.py`、`resolver.py`、`registry.py` |
| 数据库契约 | 完整索引集合、非空组件、消费软件参数对应文件、版本组件清单、目录/文件/索引前缀入口；规则进入注册表与 lock，生产重新核对冻结规则 | `resource_skills/contracts.py`、`pipeline/resources.py`、`pipeline/registry.py`、`pipeline/execution.py` |
| 跨样本适配 | 由持久清单展开逐样本节点和一次汇总节点；配对抽样、全体成员绑定、统计设计检查；适配脚本及静态参数输入记录指纹 | `pipeline/cohort.py`、`scripts/cohort_tables.py`、`scripts/run_dada2.R`、`scripts/run_ancombc2.R` |

以上 `pipeline/` 和 `resource_skills/` 均位于 `microbiome/` 下。使用方法见 [资源 Skills](resource_skills.md) 和 [跨样本工作流](cohort_workflows.md)。

目录按用途分批补充，共新增 14 个软件 Skill：

- 统计与数据互通：phyloseq、vegan、decontam、ALDEx2、MaAsLin 3、BIOM、scikit-bio。
- 预处理、群落与功能分析：KneadData、SortMeRNA、mOTUs、dbCAN、KofamScan。
- 基因组分箱与群体变异分析：VAMB、inStrain。

新增 mOTUs、dbCAN、KOfam、SortMeRNA rRNA 四个数据库 Skill，均为待选定具体发行版的资源说明，未登记为本地 READY。
全部软件 Skill 补充结构化软件家族、参数说明覆盖范围和上下游关系；无法解析为 Skill ID 的任务说明单独保留。
目录合计 107 个软件、33 个数据库。审计零错误，11 项既有数据库依赖尚无对应 Skill，作为发现提示继续解析。
这些数量表示文档目录规模，不表示本机已安装、每个参数均已验证或全部分析均已跑通。

本次未安装分析软件、未下载参考数据库。工程验收使用合成数据和真实文件命令；DADA2 与 ANCOM-BC2 脚本通过 R 语法检查，真实包接口、数据库适用性和科学结果仍需具体任务的小数据预检。

复验入口：

```bash
pytest -q tests/test_resource_evidence_contracts.py tests/test_cohort_workflow.py tests/test_frozen_pipeline.py tests/test_pretest_finalization.py
python -m microbiome.resource_skills.audit --strict
```

本轮已完成的组合回归：主组合 163 项通过；资源解析与目录追加组合 96 项通过；路径、输入绑定、预检证据与数据库复用组合 44 项通过；上述复验命令中的冻结、跨样本与预检最终整理组合 61 项通过；冻结数据库入口不可替换的补充检查通过。组合之间存在重叠，未重新运行整个仓库的全部测试。修改文件的 Ruff F/E9 与 `git diff --check` 通过。


## 2026-09-09：Harness 可迁移发布（历史兼容记录）

新增宿主模型注入、NDJSON Python 驱动与 Cordis preset；全部模型调用走当前会话路由。后台任务由宿主 jobs/subprocess 持有，真实用户消息提供确认来源；移除旧驱动自动确认与关闭冻结生产的行为。路径、请求回执和项目状态持久化。

适配器与历史指导随 wheel 分发，历史记录保持 LEGACY_UNVERIFIED。当时的 DeepSeek 专用安装器逐文件校验、独立版本 venv、原子模式切换，支持离线依赖包、重复安装、回退与保留数据卸载。该适配仍保留为显式兼容路径；当前 `install.sh`、`upgrade.sh`、`uninstall.sh` 默认管理 portable 服务，不再要求安装或配置自建 Harness。默认服务依赖宿主模型，或使用用户明确提供的 endpoint。历史安装机制见 [DeepSeek 兼容迁移手册](DeepSeek_Harness_Microbiome_Guide.md)。
