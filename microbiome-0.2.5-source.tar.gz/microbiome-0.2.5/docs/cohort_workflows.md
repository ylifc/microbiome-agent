# 跨样本流程与适配器

默认流程仍按样本执行。跨样本流程设置 `plan.execution_scope: cohort`，每个步骤显式设置
`scope: sample` 或 `scope: cohort`。系统依据已经确认的输入清单，把逐样本步骤展开为独立节点，
然后执行一次汇总或统计节点。展开后的整个 DAG 接受依赖审批、小数据验证和冻结。

```mermaid
flowchart LR
  M[已确认样本清单] --> A[样本一处理]
  M --> B[样本二处理]
  A --> C[矩阵汇总与统计]
  B --> C
  C --> D[输出验收与冻结]
```

## 输入与参数约定

- 逐样本步骤继续使用 `{runtime.reads}`、`{runtime.reads_1}`、`{runtime.reads_2}` 或 `{runtime.fasta}`。
- 跨样本命令中的独立 argv 元素 `{cohort.STEP_ID.OUTPUT_NAME}` 展开为清单顺序的逐样本输出路径。
- `{cohort.sample_ids}` 展开为相同顺序的样本 ID。
- `{cohort.reads}`、`{cohort.reads_1}`、`{cohort.reads_2}`、`{cohort.fasta}` 直接引用所有样本的对应输入。
- 不使用通配符推测成员、拼接 shell 字符串或从对话重新猜测输入来源。
- 如果某样本缺少声明的输入角色，规划阶段拒绝该方案。
- 组间推断仍须提供完整样本元数据、生物学重复、统计设计和多重检验策略。

预检保留全部生物学样本，只减少每个样本的序列记录；双端数据按样本同步抽样。
统计模型、过滤规则和参数不因试跑结果自动改变。样本或读数不足以验证模型时应修改方案并重新审批。
生产绑定全部成员与对应输入角色，调换样本或配对、修改源文件都会阻止重放。

## 通用表格适配器

`scripts/cohort_tables.py` 提供三个明确操作：

| 操作 | 参数 | 输出与检查 |
| --- | --- | --- |
| `manifest` | `--inputs`、`--sample-ids`、可选 `--mates`、`--output` | sample_id/r1/r2 TSV；样本与文件逐一对应 |
| `merge` | 上述输入参数、`--feature-column`、`--value-column`、`--units counts或abundance` | feature_id × samples 矩阵；拒绝重复特征、非有限值、负数；counts 模式拒绝小数 |
| `qc-counts` | `--inputs`、`--sample-ids`、`--output` | sample_id/reads TSV；逐条检查 FASTQ 结构与序列/质量长度 |

例如汇总逐样本输出的跨样本 argv：

```json
["{executable}", "/repository/scripts/cohort_tables.py", "merge",
 "--inputs", "{cohort.profile.counts}",
 "--sample-ids", "{cohort.sample_ids}",
 "--feature-column", "feature_id", "--value-column", "count",
 "--units", "counts", "--output", "{output.matrix}"]
```

`/repository` 必须替换为实际仓库路径。步骤应声明 `scope: cohort`、相应 output 和
`table_columns`/`unique_column`/`row_count` 等验收条件。汇总输入必须来自同一种分类体系、特征命名和单位；
缺失特征补零适用于明确可比较的同一特征空间，不能用来掩盖不同数据库版本。

## DADA2 适配器

```text
Rscript scripts/run_dada2.R manifest.tsv output_dir parameters.json
```

环境需要 `dada2` 和 `jsonlite`。参数 JSON 必须含 `seed`、正整数 `threads`、
`primers_removed: true`、`filter`、`learn`、`infer`、`chimera`；双端还需 `merge`。
各对象分别传入该版本的 `filterAndTrim`、`learnErrors`、`dada`、`removeBimeraDenovo`、`mergePairs`。
由适配器固定的路径、线程和压缩参数不能被这些对象覆盖。

可选 `taxonomy` 对象包含 `reference` 及 `assignTaxonomy` 参数；参考文件必须属于已声明、验证的数据库契约。
截断位置、期望错误、合并重叠等参数由已批准研究设计确定，适配器不推测引物、不调参或下载参考。

输入清单必须有 sample_id/r1，可选 r2/run_id。本适配器支持同一次测序运行中的单端或双端样本；
多次测序运行或混合布局需要单独设计误差学习与后续合并。
输出 counts.tsv（特征 × 样本）、asv.fasta、read-tracking.tsv、error-models.pdf、dada2.rds、
parameters.json、sessionInfo.txt；声明 taxonomy 时另输出 taxonomy.tsv。
任何样本过滤后零读数或去嵌合后零 ASV 都会失败，保留诊断结果供修订方案。

方法来源：[DADA2 官方教程](https://benjjneb.github.io/dada2/tutorial.html)。
教程参数仅是示例，不能代替当前数据的质量检查和实际安装版本的帮助。

## ANCOM-BC2 适配器

```text
Rscript scripts/run_ancombc2.R counts.tsv metadata.tsv output_dir parameters.json
```

环境需要 `ANCOMBC` 和 `jsonlite`。适配器要求安装版本支持 `ancombc2(data=matrix, meta_data=...)` 接口，
不兼容的旧版本会明确退出。输入 counts.tsv 第一列是唯一特征 ID；其余列是样本整数计数。
metadata.tsv 第一列是唯一 sample_id，必须与矩阵样本集合完全一致。

JSON 必须含 `seed` 和 `model`；`model` 至少含 `fix_formula`、`p_adj_method`、`n_cl`。
其他参数逐一核对已安装函数签名。`factor_levels` 对象指定分类变量的完整水平顺序，第一水平作为参考。
模型中使用的字符型固定效应必须声明水平。所有元数据、模型、过滤与对比参数应在审批前公开。

适配器拒绝负值/小数/非有限计数、样本错配、缺失数据、设计矩阵秩亏、无残差自由度和不支持的公式项。
公式支持变量与常见组合运算；转换后的协变量应提前生成并声明，不能在公式中执行任意函数。
随机效应通过显式 rand_formula 传递。适配器不删除协变量、不自动改变对照组、不以显著性作为成功条件。

输出完整 ancombc2.rds、res.tsv 及该次调用实际生成的其他结果表、parameters.json、sessionInfo.txt。
检查结果列、样本纳入情况、模型诊断和所选对比，不能以文件非空代替统计验收。
来源：[ANCOM-BC2 官方教程](https://bioconductor.org/packages/release/bioc/vignettes/ANCOMBC/inst/doc/ANCOMBC2.html)。

## 冻结与验证边界

适配器作为 argv 的脚本参数时自动记录路径和指纹；也可显式声明 adapter_path。
参数文件与元数据文件必须出现在步骤 input 中，静态输入指纹随方案保存并在生产预检核对。
修改适配器或参数文件必须重新规划、预检和冻结。

工程测试使用合成 FASTQ 验证逐样本展开、一次汇总、配对抽样、冻结、全量数据绑定及角色调换拒绝。
R 脚本另外检查语法。具体 R 包、真实数据库、误差模型和统计结果的任务级验收，仍由实际部署环境的小数据预检完成。
