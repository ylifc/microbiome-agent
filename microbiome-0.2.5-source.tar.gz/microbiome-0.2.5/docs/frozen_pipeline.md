# 微生物生物信息 Agent：持久状态、预检、冻结与生产执行

对话入口的六阶段流程、项目恢复、批次恢复及旧日志授权规则见[操作补充](workflow_improvements.md)。成功执行事实不能代替用户确认。

`microbiome-pipeline` 把一次分析拆成可审计的持久生命周期。对话只负责收集和确认需求；真正的事实来源是 `OUTPUT_ROOT` 下的版本化 YAML/JSON 文件。生产执行器不含规划器，不调用 LLM，也不会在运行中安装软件、下载数据库、重建索引、切换工具或修改参数。

适用范围是 FASTQ/FASTA 等序列的计算分析，包括质控、组装、比对、分类、注释、数据库管理和调试。不扩展到病原体工程、毒力或传播性改造、新病原体设计/合成、培养操作或湿实验优化。

## 权威生命周期

```text
路径确认 → 数据发现/表征 → 需求确认
  → 资源/证据审查 → 方案确认 → 依赖差距确认
  → bootstrap/数据库就绪 → 确定性 10% 小试 → PRETEST_PASSED
  → PRETEST_FINALIZING → 自动冻结/锁校验/就绪检查 → AWAITING_PRODUCTION_APPROVAL
  → 用户自然语言确认 → PRODUCTION_APPROVED
  → 只读生产预检 → 全量执行 → 最终报告
                              ↘ 失败 → 回归样本 → 修复后双重重验证
```

状态保存在 `OUTPUT_ROOT/project_state.yaml`，非法跳转会失败。四类分析需求 `input`、`dataset`、`target`、`analysis_goal` 必须逐项通过 `CONFIRM`；`MODIFY` 会增加需求版本并使旧方案、依赖审查、验证报告和锁失效；`CANCEL` 会进入取消状态。已经确认且没有新冲突的字段不会重复询问。

## 初始化与目录契约

```bash
microbiome-pipeline --project /analysis/project init \
  --raw-data /data/raw \
  --database /data/databases \
  --output /analysis/results

microbiome-pipeline --project /analysis/project discover
```

三个目录必须有不同角色且不能解析为同一路径。`OUTPUT_PATH` 可以位于 `RAW_DATA_PATH`
内部，例如 `2026-8-11/{sample_list.txt, *.fastq.gz, out/}`；所有原始数据扫描器会按已解析的
实际输出根在递归前剪枝，而不是要求用户移动 `out/`。`RAW_DATA_PATH` 位于输出根内部、以及
数据库根与输出根互相嵌套仍会被拒绝。数据库位于原始数据根内部时也会从输入扫描中排除。
路径判断使用规范化路径关系而不是字符串前缀。核心布局如下：

```text
/analysis/project/
  project_config.yaml
  experiment_plan.yaml                 # 可编辑方案，不是生产锁
  config/{database_registry.yaml,tool_registry.yaml}
  docs/RESOURCE_CATALOG.md
  state/{discovery_inventory.json,bootstrap_report.json,database_resolution.json}

/analysis/results/                      # OUTPUT_ROOT
  project_config.yaml -> /analysis/project/project_config.yaml
  project_state.yaml
  requirements/
    requirements.yaml
    decision_log.jsonl                  # 只追加
    conversation_summary.md
  plans/
    analysis_plan_vN.yaml
    analysis_plan_vN.md
    evidence_registry.yaml
    dependency_gap_report.yaml
  pre_test_run/
    validation-*/{input_subset,outputs,tmp,logs,commands,checkpoints,pipeline,reports,regression_cases}/
    regression_cases/
  pipeline/
    toolchain.lock.yaml
    database.lock.yaml
    pipeline.lock.yaml
    production_approval.yaml           # 绑定需求版本、pipeline 版本与 hash
    validation_report.json
    run_pipeline.py
  knowledge/{tools,databases}/
  runs/<run_id>/{outputs,tmp,logs,checkpoints,run_manifest.yaml}
  reports/<run_id>-final-report.{json,md}
```

`discover` 只读扫描 FASTQ/FASTA、压缩格式、首条记录、paired-end 配对、重复 inode、数据库目录、Conda 环境和 PATH 工具。配置的输出根、嵌套数据库根及其所有生成内容不会进入原始输入清单。发现结果与已确认输入类型冲突时停止，不能默默覆盖用户选择。

## 需求与显式门禁

CLI 支持 JSON 对象形式的确认：

```bash
microbiome-pipeline --project /analysis/project requirements \
  --topic input --action CONFIRM --value-json '{"type":"paired_fastq"}'
microbiome-pipeline --project /analysis/project requirements \
  --topic dataset --action CONFIRM --value-json '{"sample_count":24}'
microbiome-pipeline --project /analysis/project requirements \
  --topic target --action CONFIRM --value-json '{"organism_scope":"microbial"}'
microbiome-pipeline --project /analysis/project requirements \
  --topic analysis_goal --action CONFIRM \
  --value-json '{"objective":"quality control and taxonomic profiling"}'
```

在编写 `experiment_plan.yaml` 后，依次执行：

```bash
microbiome-pipeline --project /analysis/project plan-save
microbiome-pipeline --project /analysis/project plan-decision --action CONFIRM
microbiome-pipeline --project /analysis/project dependency-review
microbiome-pipeline --project /analysis/project dependency-decision --action CONFIRM
microbiome-pipeline --project /analysis/project bootstrap
microbiome-pipeline --project /analysis/project resolve-databases
```

方案节点必须声明用途、工具和选择理由、版本/环境、输入输出、数据库、argv 命令模板、参数、依赖 DAG、成功/失败标准、验证方法和 CPU/内存/GPU 策略。命令必须是 argv 列表并以 `{executable}` 开头；禁止 shell 拼接、破坏性命令以及生产期下载/安装/建库命令。

依赖审查报告把每项标为 `READY`、`NEEDS_INSTALL`、`NEEDS_DATABASE`、`NEEDS_INDEX_BUILD` 或 `NEEDS_REPAIR`。只有显式批准当前需求版本和当前方案指纹后，bootstrap 才能运行。

## 数据库与工具资产

YAML 注册表是机器事实来源，`RESOURCE_CATALOG.md` 是自动生成视图。数据库条目记录稳定资源 ID、用途、类型、根目录、真实运行入口、版本、源文件、marker、支持工具、文档、状态和指纹；工具条目记录绝对可执行文件、环境、版本、用途、已验证命令、失败模式、资源策略和数据库绑定。

相同 `resource_id` 的路径、版本、marker 或运行入口不可静默变化。跨进程文件锁会串行化同一数据库的下载、本地化、索引和注册表更新；下载使用 `.part` 断点文件并在大小/校验通过后原子替换，已就绪资源会在锁内再次检查并复用。

## 确定性 10% 全流程预检

```bash
microbiome-pipeline --project /analysis/project validate \
  --input reads_1=/data/raw/S01_R1.fastq.gz \
  --input reads_2=/data/raw/S01_R2.fastq.gz \
  --sample-id S01-validation
```

默认按逻辑记录数精确抽取 10%，固定 seed 为 `1729`，不是简单取文件头。paired-end 两端使用同一位置集合并校验 read ID/顺序；FASTA 按完整记录抽取。文件较小时至少取一条。预检前估算空间，超过安全上限或空间不足时停止。只有用户明确设置 `--fraction` 或 `--max-records` 才改变默认规模，实际比例和 seed 会写入 manifest。

预检在隔离目录中执行完整 DAG。每个节点必须同时满足退出码和输出断言；输入指纹必须不变。每条命令、stdout/stderr、资源分配、检查点和失败记录都持久保存。

## 冻结、自然语言审批与生产

小试通过后，`A1` 会在结构化验证产物齐全时自动调用 `PipelineFreezer`，展示实际通过的软件、版本、环境、数据库、路径和流程摘要，并进入 `AWAITING_PRODUCTION_APPROVAL`。普通用户无需运行 `freeze`、`preflight` 或 `run`，只需回复“确认全量执行”“开始跑全部数据”或 `proceed`。否定回复进入 `PAUSED`，修改请求进入 `PLAN_MODIFICATION`；问题或含糊回复不会启动生产。

`freeze` 只接受当前需求版本下全部通过的报告，生成需求指纹、方案指纹、工具/数据库锁、pipeline hash 和版本号。内容变化时必须 `freeze --new-version`，旧锁进入不可变历史。

自然语言确认由 `ProductionApprovalManager` 解析为结构化事件，并同时写入 `requirements/decision_log.jsonl` 与 `pipeline/production_approval.yaml`。确认记录绑定当前 requirements version、pipeline version 和 pipeline hash；任一内容变化都会使确认失效。随后 `ProductionController` 自动调用后台 `FrozenPipelineExecutor`，而不是让对话模型自由生成生产命令。

冻结锁还包含 `production_input_contract`：其 `raw_data_root` 是原始 `RAW_DATA_PATH`，并记录实际输出/数据库排除根和小试输入到原始输入的映射。全量样本的权威顺序是已确认的 `input_manifest.yaml`，缺失时读取原始 `sample_list.txt`，两者都不存在时才使用冻结的 RAW 文件清单；已有 manifest 时生产阶段不会重新扫描或重新猜测样本。即使调用方误传 `pre_test_run/**/input_subset/`，预检也会把它替换为锁定的原始输入；任何最终生产输入都不能位于输出/小试目录或 `RAW_DATA_PATH` 之外。只有运行时输入绑定和新的输出目录会变化，软件、版本、可执行路径、Conda 环境、数据库/参考数据、参数、命令模板及 DAG 顺序全部沿用冻结内容。

生产预检逐项确认：用户审批、需求版本、pipeline hash、原始输入根、磁盘、绝对 executable、软件版本、环境前缀、数据库 marker/指纹、注册表契约和输出边界。执行期间只回放冻结 argv，不安装软件、不下载/重建数据库、不替换工具、不修改参数。节点只有在输出验证通过后才写 `COMPLETED` 检查点；恢复执行还会核对 pipeline、输入、工具、数据库及输出指纹。

`microbiome-pipeline` CLI 和生成的 `run_pipeline.py` 仍作为后台运维/调试接口保留，但生产预检和运行同样要求已有且有效的自然语言审批记录；它们不是普通用户完成确认流程所需的操作。

一个 DAG 分支失败时，仅其后代标为 `BLOCKED_BY_FAILURE`；无依赖的分支继续执行。最终报告列出版本、hash、输入、工具、数据库、资源、步骤状态、失败样本、耗时和输出路径。

## 失败、知识库与修复

错误按输入、路径、环境、依赖、数据库/索引、命令语法、格式、网络、资源、参数、软件、流水线逻辑和输出验证分类。工具与数据库的 profile、已验证版本、错误签名和修复记录存入 `knowledge/`。

`PRETEST_PASSED` 之后采用强制恢复策略：`PATH_CONFIGURATION_ERROR`、`MANIFEST_ERROR`、
`METADATA_ERROR`、`STATE_ERROR`、`INPUT_BINDING_ERROR` 只允许修复管理状态并重新
Finalize，状态机默认禁止转入 `PRETEST_REPAIR`，不会重复执行生信命令。只有软件/环境、
数据库实际调用、科学参数或 Pipeline 成功证据没有验证通过时，才允许重新进入针对性小试。
每次 Finalize 失败的类别、恢复方式和详情都保存在 `project_state.yaml`。

修复尝试有上限。未验证尝试只记为 `FAILED_ATTEMPT`，不会成为推荐知识；只有回归验证通过的修复才标记 `VERIFIED`。生产失败不会热修复，而会生成最小化候选：

1. 最小化失败输入并把 regression manifest 标为 `READY`；
2. 修订并重新确认方案/依赖，重新 bootstrap 和解析数据库；
3. 运行 `repair-validate --regression-manifest <case.yaml>`；
4. 原始代表子集和失败回归样本都通过后，使用 `freeze --new-version`；
5. 重新运行失败样本，已完成且指纹一致的检查点可恢复。

任何影响科学结果的变化都会触发重验证；生产路径没有隐藏 fallback。
