# Architecture audit against the microbial-agent refactor specification

Date: 2026-08-18

## Pre-refactor findings

The conversational `A1` agent already supported planning, a pilot/full-run confirmation flow, software memories, resource skills, resumable downloads, and optional frozen production. The main architectural risk was that the default agent could still mix conversational planning, resource mutation, repair, and execution in one large runtime object. Important decisions were primarily chat/session state, the pilot sampler selected leading records, and strict frozen production was optional.

The repository also had useful lower-level primitives that should be retained: safe argv execution, progress events, conda/tool discovery, database skill metadata, partial-file downloads, output validation, resource snapshots, and software-specific memory files.

## Implemented boundaries

| Concern | Authoritative implementation | Production behavior |
| --- | --- | --- |
| Paths and project layout | `microbiome.path_policy.PathPolicy`, `microbiome.pipeline.project.PipelineProject` | Role-aware nesting; configured output/database trees are pruned from raw discovery |
| Lifecycle | `microbiome.pipeline.state.ProjectStateMachine` | Invalid phase jumps fail |
| Requirements | `microbiome.pipeline.requirements.RequirementManager` | Version/fingerprint must match frozen pipeline |
| Plan and evidence | `microbiome.pipeline.lifecycle`, `microbiome.pipeline.evidence` | Current plan must be confirmed |
| Dependency gaps | `microbiome.pipeline.dependencies.DependencyResolver` | Explicit approval before bootstrap |
| Tools/databases | YAML registries plus generated catalog | Read-only verification; no repair |
| Database acquisition | resource skills plus per-resource `fcntl` lock | Not callable from frozen replay |
| Pre-test | `microbiome.pipeline.validation.SmallScaleValidator` | Full DAG on deterministic logical-record subset |
| Freeze | `microbiome.pipeline.freeze.PipelineFreezer` | Immutable lock and pipeline hash |
| Production approval | `microbiome.pipeline.approval.ProductionApprovalManager` | Five-way intent; durable approval bound to requirements and pipeline |
| Production input | `microbiome.pipeline.inputs.ProductionInputResolver` | Manifest-first full input binding; rejects/rebinds pilot and generated-output paths |
| Automatic dispatch | `microbiome.pipeline.approval.ProductionController` | Approval immediately invokes preflight and frozen execution |
| Full execution | `microbiome.pipeline.execution.FrozenPipelineExecutor` | No planner, LLM, installer, downloader, or fallback |
| Repair knowledge | `microbiome.pipeline.knowledge` | Only verified fixes are returned as recommendations |
| Reporting | `microbiome.pipeline.reporting.FinalReportWriter` | Durable JSON and Markdown reports |

## Residual compatibility boundary

`microbiome-run` and `A1` remain available for conversational planning. After a structured small-scale validation passes, `A1` automatically freezes it when needed, displays a grounded validation summary, persists the user's natural-language production decision, and invokes the deterministic controller. `A1(require_frozen_production=False)` remains an explicit legacy escape hatch. If an old conversational pilot lacks enough structured evidence to reconstruct a safe lock, strict mode stops instead of inventing one; it never directs the user to run internal CLI commands or uses the pilot subset as production input.

## Safety invariants

- No raw-data output path is accepted by a frozen step.
- Production commands are argv arrays and cannot contain shell control operators.
- Download/install/index executables and known index-building subcommands are rejected from plans.
- Every production output must resolve below `OUTPUT_ROOT/runs/<run_id>/outputs`.
- Resource registry and lock fingerprints are checked before every production run.
- Requirements, plan, validation, tools, databases, and checkpoints are version/fingerprint bound.
- Production approval is mandatory and is bound to both requirements version and frozen pipeline hash/version.
- Production input root equals the original `RAW_DATA_PATH`; persisted sample identity drives all-sample scheduling.
- A confirmed input manifest drives production without a RAW rescan; a frozen target inventory is only the no-manifest fallback.
- `OUTPUT_PATH` may be nested below `RAW_DATA_PATH`, but is pruned before every input-tree traversal.
- A supplied path under `pre_test_run` is never executed in production; a recorded pilot subset is rebound to its original raw source.
- PATH/MANIFEST/METADATA/STATE/BINDING failures after `PRETEST_PASSED` retry Finalize and cannot automatically re-run scientific steps.
- Production failures create regression candidates and require revalidation; they are never hot-patched.
