# Microbiome 微生物实验设计与分析改造 — 总体设计（Spec）

> 日期：2026-07-29
> 状态：设计已获用户确认（架构=方案A；示范子系统=宏基因组；多软件可选；数据库下载器+独立环境）
> 本文件是总体设计书；宏基因组子系统的"可执行实现计划"见同目录 plans/。

---

## 1. 目标

在 Microbiome（通用生物医学 AI Agent）基础上，扩展面向**微生物实验设计与分析**的工具能力。Agent 通过检索工具 + 生成代码，调用下列能力完成端到端分析；工具函数统一返回 **markdown 研究日志**（步骤 + 结果 + 输出文件路径），与现有 `microbiology.py` 模式一致。

覆盖能力域：
1. 单菌基因组：拼接、基因抽取、注释
2. 单菌转录组：拼接、注释
3. 宏基因组：拼接、分箱、功能基因注释、TPM/FPKM 丰度
4. 宏转录组：拼接、注释、TPM/FPKM 丰度
5. 宏基因组分箱 × 宏转录组 联合分析
6. 微生物基因组进化关系分析
7. 保守基因抽取 + 系统发育树构建
8. 病毒基因组：有参/无参拼接；DNA/RNA 宏病毒组拼接与注释
9. 扩增子（amplicon）分析与注释
10. 病毒/细菌/古菌 分子钟分析
11. 化合物-代谢互作网络分析
12. 微生物数据库下载能力
13. **保留**原有：网络科研信息检索、按用户目的规划生信分析路径、学习/调用其它生信软件的能力

## 2. 总体架构（方案 A：按学科大类扩模块）

贴合 Microbiome 原生工具模式，不重造轮子：
- 每个领域一个模块文件 `microbiome/tool/{module}.py` + 对应 `microbiome/tool/tool_description/{module}.py`（schema）。
- 在 `microbiome/utils.py::read_module2api()` 的 `fields` 列表中注册新模块名。
- 复用现有辅助：`run_bash_script`（CLI 执行）、`function_to_api_schema`（schema 生成）、`check_and_download_s3_files`（数据湖下载）、`run_with_timeout`（超时）。
- 工具函数约定：函数内 import、步骤化、关键结果落盘（fasta/tsv/png 等）、返回 markdown 研究日志；检测依赖 CLI 是否在 PATH，缺失则在日志中给出明确安装命令，不静默失败。

### 新增模块清单

| 模块 | 覆盖能力域 | 主要工具函数（示例） |
|---|---|---|
| `microbial_genomics.py` | 1,6,7,10 | assemble_isolate_genome, predict_genes_isolate, annotate_isolate_genome, extract_conserved_genes, build_phylogenetic_tree, molecular_clock_analysis |
| `metagenomics.py` | 3,4,5 | assemble_metagenome, predict_genes, bin_metagenome, assess_bins_quality, annotate_metagenome, calculate_gene_abundance, taxonomic_profile, joint_binning_transcriptome_analysis |
| `transcriptomics.py`（含单菌转录组 2） | 2,4 | assemble_transcriptome, annotate_transcriptome, transcript_abundance |
| `virology.py` | 8 | assemble_virus_reference_guided, assemble_virus_denovo, annotate_virome, identify_viral_contigs |
| `amplicon.py` | 9 | amplicon_qc_denoise, amplicon_taxonomy, amplicon_diversity |
| `microbial_networks.py` | 11 | build_compound_metabolic_network, analyze_network |
| `microbial_databases.py` | 12 | download_gtdb, download_card, download_checkv, download_genomad, download_dbcan, download_eggnog, download_kraken2_db |

> 说明：能力域 13（网络检索/路径规划/自学新软件）为 Microbiome 原生的 `literature`/`database` 模块 + A1 agent 的规划与 `run_bash_script`/工具检索能力，本改造**保留并依赖**，不新增。

### 底层技术路线（混合 C）
- 纯 Python 计算（TPM/FPKM 归一化、contig 深度统计、网络构建、表格处理）：pandas / numpy / pysam / Biopython / networkx。
- 重型流程：subprocess 调成熟 CLI（MEGAHIT/metaSPAdes、Prodigal、MetaBAT2/MaxBin2、CheckM(2)、Bakta/eggNOG-mapper、Salmon/Kallisto、BWA/Bowtie2、Kraken2、IQ-TREE/FastTree、MAFFT、BEAST/TreeTime、geNomad/CheckV、Trinity/RNAspades、QIIME2/DADA2 等）。
- 同一环节封装多款软件，由 agent 按需选择（用户已确认"都封装"）。

## 3. 环境安装策略（不改 biomni_e1）

- 新增 `microbiome_env/microbiome_env.yml`：mamba/bioconda 一键安装全部 CLI。
- 新增 `microbiome_env/setup_microbiome.sh`：建环境 + 可选下载数据库。
- 本期实测：用 mamba 把宏基因组所需 CLI 装入专用 conda env（机器已有 miniforge/mamba 及 megahit/iqtree/mafft/bowtie2/gtdbtk/seqkit 等 env 可复用/参考），并用小型 mock 数据跑通核心链。

## 4. 数据库下载策略

`microbial_databases.py` 中每个下载器：从官方源下载 → 落盘数据湖 → 在 `env_desc.py::data_lake_dict` 登记 → 返回 路径+版本+校验 的研究日志。大库（GTDB/Kraken2 full）提供 精简/完整 两档，默认不拉爆磁盘。本期只写下载器，不全量下载大库。

## 5. 分阶段路线图

每个子系统走独立 spec→plan→实现 周期（Superpowers 流程）。

- **阶段 0（本期）**：总体架构 + 宏基因组子系统端到端示范（含环境脚本、数据库下载器骨架、mock 数据实测）。
- **阶段 1**：单菌基因组 + 单菌转录组。
- **阶段 2**：宏转录组 + 宏基因组×宏转录组联合分析。
- **阶段 3**：病毒学（有参/无参、DNA/RNA 宏病毒组）+ geNomad/CheckV 数据库。
- **阶段 4**：扩增子 + 进化/保守基因/分子钟。
- **阶段 5**：化合物-代谢网络 + 数据库下载器全量 + 文档/教程/know-how 完善。

## 6. 本期示范：宏基因组子系统（详）

模块：`metagenomics.py`。工具与数据流：

```
reads(fastq)
  └─ assemble_metagenome (MEGAHIT | metaSPAdes) → contigs.fasta
       ├─ predict_genes (Prodigal) → genes.fna / proteins.faa / genes.gff
       │    └─ calculate_gene_abundance (Salmon 或 Bowtie2+自算) → abundance_tpm_fpkm.tsv
       ├─ bin_metagenome (MetaBAT2 | MaxBin2) → bins/*.fa
       │    └─ assess_bins_quality (CheckM/CheckM2) → bins_quality.tsv
       ├─ annotate_metagenome (Bakta | eggNOG-mapper) → annotations.tsv
       └─ taxonomic_profile (Kraken2) → taxonomy_report.tsv
```

验收：用小型 mock 宏基因组（如 MEGAHIT 示例或 Zymo mock 子集）实测跑通
`assemble → predict_genes → bin → assess → abundance`，产出日志与结果文件。

## 7. 测试策略（TDD）
- 每个工具函数：先写失败测试（用小 fixture 数据），再实现至通过（红-绿-重构）。
- CLI 封装：用极小子集数据验证命令拼接、退出码处理、输出文件生成与日志内容。
- 纯 Python 计算（TPM/FPKM）：用手算可核对的极小矩阵断言数值。
- 完成前：运行测试套件 + 实测核心链，凭证据（命令输出/退出码）声明通过。

## 8. 风险与备注
- 大型 CLI 安装耗时/占盘：用专用 env + 按需安装，文档注明磁盘需求。
- 部分软件 license 限制性：在工具日志与文档标注，遵循 `commercial_mode`。
- CheckM 数据库较大：质量评估默认提供"跳过/最小库"提示。
- 不改变 A1 agent 主循环与既有工具，向后兼容。