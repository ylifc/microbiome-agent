# 宏基因组子系统实现计划（阶段 0 示范）

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 为 Microbiome 新增 `metagenomics` 工具模块，实现宏基因组 拼接→基因预测→丰度(TPM/FPKM)→分箱→质量评估→注释 端到端能力，并用 mamba 实测跑通核心链。

**Architecture:** 贴合 Microbiome 原生工具模式：`microbiome/tool/metagenomics.py`（工具函数，返回 markdown 研究日志）+ `microbiome/tool/tool_description/metagenomics.py`（schema）+ 注册进 `read_module2api` 的 `fields`。纯 Python 做 TPM/FPKM 与深度统计（pandas/pysam/Biopython），重型步骤用 subprocess 调 CLI。依赖 CLI 缺失时在日志中给出安装命令，不静默失败。

**Tech Stack:** Python 3.10+（专用 conda env `microbiome`）、pandas、numpy、pysam、biopython、pytest；CLI：megahit、spades、prodigal、metabat2、maxbin2、checkm-genome、salmon、bwa、bowtie2、kraken2（后两者本期可选）。

## Global Constraints

- 工具函数：函数内 import；步骤化；关键结果落盘（fasta/tsv）；返回 markdown 研究日志字符串。
- 每个工具先检测依赖 CLI 是否在 PATH；缺失则返回含 `mamba install -c bioconda -c conda-forge <pkg>` 提示的日志，**不抛异常**。
- TPM/FPKM 计算必须用纯 Python（不依赖 Salmon）作为默认可测路径；Salmon 作为可选后端。
- 默认 conda env 名：`microbiome`。工具通过 `os.environ.get("MICROBIOME_ENV", "microbiome")` 读取，可用 `conda run -n <env> <cmd>` 执行 CLI；若 CLI 已在 PATH 则直接调用。
- 所有数值计算必须有 pytest 断言；CLI 封装用极小子集数据验证命令拼接与输出文件生成。
- 遵循 YAGNI：本期只实现上表工具，注释（eggNOG/Bakta）与 Kraken2 作为占位在后续阶段。
- 遵守 TDD：先写失败测试 → 跑确认失败 → 最小实现 → 跑通过 → 提交。

## 文件结构

- 创建 `microbiome/tool/metagenomics.py` — 工具函数实现
- 创建 `microbiome/tool/tool_description/metagenomics.py` — `description` schema 列表
- 修改 `microbiome/utils.py` — `read_module2api` 的 `fields` 列表中加入 `"metagenomics"`
- 创建 `microbiome_env/microbiome_env.yml` — conda 环境
- 创建 `microbiome_env/setup_microbiome.sh` — 一键建环境脚本
- 创建 `tests/test_metagenomics.py` — pytest 测试
- 创建 `tests/fixtures/` — 极小测试数据（contigs.fa、reads、genes）

---

### Task 1: 统一 conda 环境（microbiome）与安装脚本

**Files:**
- Create: `microbiome_env/microbiome_env.yml`
- Create: `microbiome_env/setup_microbiome.sh`

**Interfaces:**
- Produces: 名为 `microbiome` 的 conda env，含 megahit/spades/prodigal/metabat2/maxbin2/checkm-genome/salmon/bwa/bowtie2/seqkit/pysam/biopython/pandas/pytest。

- [ ] **Step 1: 写 microbiome_env.yml**

```yaml
name: microbiome
channels: [bioconda, conda-forge, defaults]
dependencies:
  - python=3.10
  - megahit>=1.2.9
  - spades>=3.15
  - prodigal>=2.6
  - metabat2>=2.15
  - maxbin2>=2.2.7
  - checkm-genome>=1.2
  - salmon>=1.10
  - bwa>=0.7.17
  - bowtie2>=2.5
  - seqkit>=2.6
  - pandas
  - numpy
  - pysam
  - biopython
  - pytest
  - pip
```

- [ ] **Step 2: 写 setup_microbiome.sh**

```bash
#!/usr/bin/env bash
set -euo pipefail
ENV_NAME="${1:-microbiome}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mamba env create -f "$HERE/microbiome_env.yml" -n "$ENV_NAME" || \
  mamba env update -f "$HERE/microbiome_env.yml" -n "$ENV_NAME"
echo "Environment '$ENV_NAME' ready. Activate: conda activate $ENV_NAME"
```

- [ ] **Step 3: 实际创建环境并验证关键 CLI**

Run: `mamba env create -f microbiome_env/microbiome_env.yml -n microbiome`
Expected: 成功；`conda run -n microbiome bash -lc "megahit --version; prodigal -v; metabat2 -h; salmon --version"` 均有输出。

- [ ] **Step 4: Commit**

```bash
git add microbiome_env/microbiome_env.yml microbiome_env/setup_microbiome.sh
git commit -m "feat(env): add microbiome conda env and setup script"
```

---

### Task 2: 模块骨架 + 依赖检测辅助 + fields 注册

**Files:**
- Create: `microbiome/tool/metagenomics.py`（先含 `_find_cli`/`_run` 辅助与一个最小工具）
- Create: `microbiome/tool/tool_description/metagenomics.py`
- Modify: `microbiome/utils.py`（fields 加 "metagenomics"）
- Test: `tests/test_metagenomics.py`

**Interfaces:**
- Produces: `_find_cli(tool)`, `_run(cmd, log)`；`assemble_metagenome(reads_1, reads_2, out_dir, assembler="megahit", env=None) -> str`（骨架版）。

- [ ] **Step 1: 写失败测试 — fields 已注册 metagenomics**

```python
def test_metagenomics_registered():
    from microbiome.utils import read_module2api
    m = read_module2api()
    assert "microbiome.tool.metagenomics" in m
```

- [ ] **Step 2: 跑测试确认失败**

Run: `pytest tests/test_metagenomics.py::test_metagenomics_registered -v`
Expected: FAIL（AssertionError: 未注册）

- [ ] **Step 3: 最小实现 — 建模块、schema、注册 fields**

`tool_description/metagenomics.py` 先含 `description = []`（后续填充）；`metagenomics.py` 含辅助函数；`utils.py` 的 `fields` 列表加 `"metagenomics"`。

- [ ] **Step 4: 跑测试确认通过**

Run: `pytest tests/test_metagenomics.py::test_metagenomics_registered -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add microbiome/tool/metagenomics.py microbiome/tool/tool_description/metagenomics.py microbiome/utils.py tests/test_metagenomics.py
git commit -m "feat(metagenomics): scaffold module, schema, and register field"
```

---

### Task 3: 依赖检测辅助 `_find_cli` 与缺依赖提示

**Files:**
- Modify: `microbiome/tool/metagenomics.py`
- Test: `tests/test_metagenomics.py`

**Interfaces:**
- Consumes: `_find_cli(tool, env)`，`_run(cmd)`
- Produces: 缺依赖时返回含安装命令的 markdown 日志字符串。

- [ ] **Step 1: 写失败测试 — 缺 CLI 时返回安装提示**

```python
def test_missing_cli_returns_install_hint():
    from microbiome.tool.metagenomics import assemble_metagenome
    log = assemble_metagenome("r1.fq", "r2.fq", "out", assembler="definitely_not_a_tool")
    assert "mamba install" in log.lower() or "not found" in log.lower()
```

- [ ] **Step 2: 跑测试确认失败**（assemble_metagenome 未实现）
- [ ] **Step 3: 实现 `_find_cli`/`_run`/`assemble_metagenome` 骨架 + 缺依赖分支**
- [ ] **Step 4: 跑测试确认通过**
- [ ] **Step 5: Commit** — `git commit -m "feat(metagenomics): CLI detection with install hints"`

---

### Task 4: 拼接工具 assemble_metagenome（megahit 实测）

**Files:**
- Modify: `microbiome/tool/metagenomics.py`、`tool_description/metagenomics.py`
- Test: `tests/test_metagenomics.py`、`tests/fixtures/`（小 reads）

**Interfaces:**
- Produces: `assemble_metagenome(...) -> str`，落盘 `out_dir/contigs.fasta`，日志含 contig 数与 N50。

- [ ] **Step 1: 写失败测试 — 用合成 reads 跑出 contigs.fasta**

```python
def test_assemble_megahit(tmp_path):
    from microbiome.tool.metagenomics import assemble_metagenome
    # fixtures: 合成小双端 reads
    log = assemble_metagenome(str(FIX/"r1.fq"), str(FIX/"r2.fq"), str(tmp_path), assembler="megahit")
    assert (tmp_path/"contigs.fasta").exists()
    assert "contig" in log.lower()
```

- [ ] **Step 2: 生成极小合成 reads fixture 并跑测试确认失败**
- [ ] **Step 3: 实现 assemble_metagenome（megahit 命令拼接、conda run 或直接调用、解析输出统计 N50）**
- [ ] **Step 4: 跑测试确认通过（实测 megahit 跑通）**
- [ ] **Step 5: 更新 tool_description schema**
- [ ] **Step 6: Commit** — `git commit -m "feat(metagenomics): assemble_metagenome with megahit"`

---

### Task 5: 基因预测 predict_genes（prodigal 实测）

**Files:** Modify `metagenomics.py` + schema；Test + fixtures（小 contigs.fa）
**Interfaces:** Produces `predict_genes(contigs, out_dir) -> str`，落盘 `genes.fna/proteins.faa/genes.gff`。

- [ ] **Step 1: 失败测试** — 预测出非空 proteins.faa 且日志含基因数
- [ ] **Step 2: 跑确认失败**
- [ ] **Step 3: 实现（prodigal -p meta）**
- [ ] **Step 4: 跑确认通过**
- [ ] **Step 5: schema + Commit** — `git commit -m "feat(metagenomics): predict_genes with prodigal"`

---

### Task 6: 丰度计算 calculate_gene_abundance（纯 Python TPM/FPKM）

**Files:** Modify `metagenomics.py` + schema；Test（手算可核对矩阵）
**Interfaces:** Consumes 比对计数（bwa/bowtie2+featureCounts 或简化 salmon）；Produces `abundance_tpm_fpkm.tsv`；纯函数 `_tpm(lengths, counts)`、`_fpkm(lengths, counts)`。

- [ ] **Step 1: 失败测试 — 手算核对 TPM/FPKM 数值**

```python
def test_tpm_fpkm_math():
    from microbiome.tool.metagenomics import _tpm, _fpkm
    lengths = [1000, 2000]; counts = [100, 100]
    tpm = _tpm(lengths, counts); fpkm = _fpkm(lengths, counts)
    assert abs(sum(tpm) - 1e6) < 1e-3
    assert tpm[0] > tpm[1]  # 短基因同计数下 TPM 更高
```

- [ ] **Step 2: 跑确认失败**
- [ ] **Step 3: 实现 `_tpm`/`_fpkm` 与 `calculate_gene_abundance`（默认纯 Python：读 BAM/计数表→TPM/FPKM）**
- [ ] **Step 4: 跑确认通过**
- [ ] **Step 5: schema + Commit** — `git commit -m "feat(metagenomics): TPM/FPKM abundance (pure python)"`

---

### Task 7: 分箱 bin_metagenome（metabat2 实测）

**Files:** Modify `metagenomics.py` + schema；Test
**Interfaces:** Produces `bin_metagenome(contigs, reads_1, reads_2, out_dir, binner="metabat2") -> str`，落盘 `bins/*.fa`；先用 bwa 产生深度（metabat2 需要）。

- [ ] **Step 1: 失败测试** — 生成 bins/ 目录且日志含 bin 数
- [ ] **Step 2: 跑确认失败**
- [ ] **Step 3: 实现（bwa 比对→samtools depth 或 metabat2 自带 jgi_summarize→metabat2）**
- [ ] **Step 4: 跑确认通过（实测）**
- [ ] **Step 5: schema + Commit** — `git commit -m "feat(metagenomics): bin_metagenome with metabat2"`

---

### Task 8: 质量评估 assess_bins_quality（checkm 实测）

**Files:** Modify `metagenomics.py` + schema；Test
**Interfaces:** Produces `assess_bins_quality(bins_dir, out_dir) -> str`，落盘 `bins_quality.tsv`（完整度/污染度）。

- [ ] **Step 1: 失败测试** — 产出质量表
- [ ] **Step 2: 跑确认失败**
- [ ] **Step 3: 实现（checkm lineage_wf；库缺失时提示下载或跳过）**
- [ ] **Step 4: 跑确认通过**
- [ ] **Step 5: schema + Commit** — `git commit -m "feat(metagenomics): assess_bins_quality with checkm"`

---

### Task 9: 端到端核心链实测 + 文档

**Files:** Create `tests/test_metagenomics_e2e.py`；Modify `microbiome_env/README.md`（增 microbiome 段）
**Interfaces:** Consumes 全部工具；验证 `assemble→predict→abundance→bin→assess` 全链。

- [ ] **Step 1: 写 e2e 测试（小 mock 数据，串起 5 个工具，断言各产物存在）**
- [ ] **Step 2: 跑确认通过（实测全链）**
- [ ] **Step 3: 更新 README/know-how（宏基因组使用说明）**
- [ ] **Step 4: Commit** — `git commit -m "feat(metagenomics): e2e pipeline + docs"`

---

## Self-Review 记录
- Spec 覆盖：本期宏基因组的 拼接/基因预测/丰度/分箱/质量 均有对应 Task；注释/Kraken2 明确推迟到后续阶段（YAGNI）。
- 占位符：无 TBD/TODO；每个 Task 含可执行步骤与代码。
- 类型一致性：工具函数签名在各 Task 间一致（reads/contigs/out_dir/env）。