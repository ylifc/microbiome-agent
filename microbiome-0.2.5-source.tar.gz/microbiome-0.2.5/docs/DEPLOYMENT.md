# 部署与迁移

当前默认部署是可被不同宿主调用的 Microbiome 能力包，模型与认证留在用户已有宿主中。
计算端使用 Linux / WSL 与 Python 3.11+，不再要求先安装 DeepSeek Harness 或填写模型配置。

## 源码安装

```bash
bash install.sh
"$HOME/.local/share/microbiome-runtime/bin/microbiome" doctor
"$HOME/.local/share/microbiome-runtime/bin/microbiome" export --host codex --output /absolute/new/adapter
```

安装器创建自己的 Python venv，并在验证成功后切换受管启动入口。它不会改写 shell 配置，也不会预装生信软件或获取数据库。
导出的 Skill 和 MCP 配置由用户导入或合并至现有宿主。`--host` 可改为 `vscode` 或 `workbuddy`。
已有非受管目录不能直接作为安装目标；自定义目录使用 `bash install.sh --prefix /absolute/new/runtime`。

## 端口接入

宿主工具服务可用 stdio，也可启动本机 HTTP MCP：

```bash
microbiome mcp --transport http --port 8765
microbiome export --host codex --mcp-url http://127.0.0.1:8765/mcp --output /absolute/new/http-adapter
```

已有模型服务可以直接连接：

```bash
microbiome endpoint --endpoint http://127.0.0.1:8000 --check
microbiome endpoint --endpoint http://127.0.0.1:8000 --project /work/project
```

两类端口协议不同。模型端口自动发现可用模型并做短响应检查，需支持 OpenAI 兼容 models/chat-completions 接口。
当前 MCP HTTP 绑定回环地址；远程服务器请使用宿主支持的远程工作区方式，当前版本不自动建立隧道或部署远程调度器。

## 升级与卸载

```bash
bash install.sh --upgrade
bash install.sh --uninstall
```

自定义安装目录需重复传入相同 `--prefix`。升级先构建和验证新环境，然后切换本安装器管理的入口；旧运行环境保留。
卸载停用受管入口，不删除用户数据、数据库、分析项目、宿主配置或保留的环境。
配置导出使用具体 Python 环境路径，升级后应重新导出并合并宿主配置；正在运行的任务应按原运行环境完成后再切换。

已有经校验、包含全部依赖 wheel 的发行包可用 `--offline`；离线包必须匹配构建时的 Python 次版本、操作系统与架构。
源码目录本身不是离线发行包。历史构建脚本仍有 harness 名称，不代表默认安装入口继续依赖自建工作台。

## 兼容范围

`microbiome`、`biomni`、`microbiome-run` 均为当前跨宿主入口。旧对话入口改为 `microbiome-legacy-run`，旧工作台改为 `microbiome-legacy-harness`。
旧 DeepSeek 安装器只通过 `install.sh --legacy-deepseek` 显式调用；历史 standalone 安装器通过 `--legacy-standalone` 调用。
这些兼容入口不属于新用户必需步骤。普通配置不读取旧模型环境变量，也不提示添加 API Key。

完整操作、能力与限制见 [Microbiome 中文手册](Microbiome_Agent_完整使用手册.md) 和 [接口说明](portable_integration.md)。
