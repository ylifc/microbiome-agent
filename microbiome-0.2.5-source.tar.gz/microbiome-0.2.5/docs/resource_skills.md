# Microbiome Resource Skills

Resource skills are validated `SKILL.md` files that tell the planner which local databases and software environments are safe to use. They are loaded from `microbiome/resource_skills/` and the optional project directory `ResourceSkills/`.

Schema validation means the document is structurally readable, not that its analysis was run locally.
The persistent workflow additionally loads `<output>/resource_skills/`. Its planning context records
every explicitly selected resource without a top-k cutoff, and re-queries the final compiler dependencies
when tools, environments, databases or parameters change. Receipts and full read evidence are stored in
`plans/planning_evidence/` and referenced by the proposed plan. Unknown Skills remain discovery events.

The catalog now contains 107 software and 33 database Skills. Added software covers phyloseq, vegan,
decontam, ALDEx2, MaAsLin 3, BIOM, scikit-bio, KneadData, SortMeRNA, mOTUs, dbCAN, KofamScan, VAMB and inStrain.
The four new database families (mOTUs, dbCAN, KOfam, SortMeRNA rRNA) are discovery documentation, not READY
installations. Their concrete releases, full component manifests and consumer contracts require validation.

Run the read-only audit with `python -m microbiome.resource_skills.audit --strict`. It reports missing
adapters and malformed contracts as errors, and unresolved database dependencies as discovery warnings.
`parameter_guidance` and `parameter_coverage` distinguish curated task guidance from a complete manual.
Upstream/downstream Skill IDs are separate from free-text `upstream_tasks`/`downstream_tasks` notes.

R/Python Skills declare a `runtime` package/function contract. Resolution probes every candidate environment
for that capability, not merely its interpreter. Shared `Rscript` or `python` names cannot alias an arbitrary
scientific package. Installation includes the approved required package set, and discovery captures help
and command schemas for known as well as newly learned tools.

Database `validation_contract` rules are copied into the proposed plan and frozen with it. Supported checks
include complete index suffix sets sharing one directory/prefix, non-empty components, consumer parameter
files (such as a selected read length), and release component manifests. `runtime_kind: index_prefix`
with `runtime_suffix_sets` describes an index prefix that is not itself a file. Consumer-specific mappings
use `consumer_entrypoint_kinds` and `consumer_suffix_sets`. Production validates the frozen rules.

Knowledge successes require passing output assertions. Legacy Markdown success claims are returned as
`LEGACY_UNVERIFIED`; original records remain preserved. Fixes need an intact fingerprinted PASSED validation
report. Queries fold error/fix events and match actual tool version, environment and database paths;
other-context errors are explicitly separated. Database acquisition/validation history is also queried.
See [cohort workflows](cohort_workflows.md) for the bundled table, DADA2 and ANCOM-BC2 adapters.

The registry keeps the catalog summary compact, retrieves relevant skills from names, aliases, English/Chinese keywords, tasks, formats, and workflow relations, then injects the complete matching `SKILL.md` bodies into plan refinement and confirmed execution. A skill body is therefore operational model context, not passive documentation. The agent can explicitly call `get_resource_skill_details(kind, skill_id)` when it needs one complete skill.

## Registry, Skill, and Knowledge are separate

Every persistent resource has three layers:

| Layer | Software | Database/reference/index |
| --- | --- | --- |
| Registry | Exact executable, Conda prefix, version, family, package mapping, status and validation timestamps | Root, exact consumer entrypoint, markers, release, status, provenance and fingerprint |
| Skill | Capabilities, inputs/outputs, parameters, command patterns and validation rules | Biological scope, formats, consumers, acquisition/localization rules and path arguments |
| Knowledge | Captured version/help, install recipes and attempts, real invocations, errors and verified fixes | Acquisition/localization/validation events, observed failures and verified recovery history |

The layers are intentionally not interchangeable. A Skill is usage guidance and may be learned or repaired before Freeze. Registry entries are validated location/version facts. Knowledge contains historical evidence but only fixes marked verified are reusable. `pipeline.lock.yaml`, `toolchain.lock.yaml`, and `database.lock.yaml` remain the only production execution facts.

## Generic Unknown Tool resolution

`Unknown software skill` is no longer the normal control path. `ToolResolver` separates the planner's logical name from the software family, package name, executable, environment and Skill ID, then resolves in this order:

1. validated frozen toolchain binding;
2. fingerprinted `tool_registry.yaml` binding;
3. existing Skill/alias/family mapping;
4. every existing project and Conda environment;
5. `PATH` and project software directories;
6. installed Conda package metadata;
7. a new approved installation.

An executable discovered under a differently named environment is reused after version/help validation. If it has no Skill, `SoftwareSkillBuilder` captures local version/help output and writes a schema-compatible project Skill. If it is absent, `CondaEnvironmentManager` may install only a verified package candidate that is inside the current approved dependency-plan scope. Attempts are bounded, base/root is forbidden, healthy user environments are never deleted, and a zero installer exit code alone is not `READY`.

The dependency report stores a scope fingerprint and version. Re-reviewing an unchanged scope retains its version; adding a new tool/database produces a new version and requires a matching approval. One approval covers the full disclosed dependency plan—there is no package-by-package prompt—but it never authorizes an unexpected dependency discovered later.

`ResourceBootstrapManager` coordinates the software and database managers. Automatic mutation is limited to `BOOTSTRAP` and `PRETEST_REPAIR`. `FROZEN`/`PRODUCTION` resolution requires the validated lock and will not search for alternatives, install packages, download databases, or build Skills.

## Planning order

1. Local `READY` resources with a valid skill.
2. Registered skills that need database preparation or a declared conda environment.
3. Unregistered software, databases, or newly researched external resources.

Within the same capability, `selection_tier: default` identifies the mature preferred path. `selection_tier: conditional` is selected only when its input, biological purpose, or cross-validation role applies. Existing catalog skills without an explicit tier are reported as `established` for backward compatibility.

Planning only inspects local state and never starts a transfer. For each suitable database it compares local readiness, scientific scope, advantages, limitations, expected size, release and consumer format. A missing open database may be proposed with its official source, isolated `Database/<id>/` target, acquisition/localization commands and `[MICROBIOME_DB_ACQUISITION:<id>]`. The registry adds that marker only when it can resolve a complete machine-executable acquisition command; prose and placeholders such as `<release>` do not grant authorization. Replying `确认执行` authorizes only those marked resources. License/login-gated or incompletely specified resources stay manual blockers.

The first confirmation runs a deterministic resource-preparation gate before invoking the analysis model. It creates only the environments disclosed in the confirmed plan, executes the approved Skill commands, localizes the downloaded files, reloads the registry, and requires every declared readiness marker. Each attempt writes `Database/<id>/microbiome-acquisition.json` with commands, exit codes, output, plan hash, and final status. Any failed command or missing marker blocks the pilot. Once resources are READY, the Agent performs an end-to-end pilot on a tiny representative subset. It never processes the complete input. Only after real pilot outputs pass validation does the Agent ask for `确认全量执行`; that second confirmation starts the full-data run with the commands corrected during the pilot.

Large public archives should use `python -m microbiome.resource_skills.acquisition download` with an exact expected size and publisher checksum. The helper migrates an interrupted target to `.part`, bypasses broken proxy variables when `--direct` is approved, uses `aria2c` multi-connection transfer when available, rotates declared official mirrors, restarts a stalled aria2 process while preserving its piece map, and publishes the final path only after validation. An accompanying `.aria2` file means the partial archive contains tracked non-contiguous pieces and must be resumed with aria2; the helper blocks a contiguous HTTP fallback in that state. This is the registered recovery path for Bakta DB rather than Bakta's truncating built-in downloader. Bakta localization safely extracts the verified archive and reuses a READY pinned `Database/amrfinderplus/latest` release before considering a new AMRFinderPlus transfer.

Each database occupies exactly one direct subdirectory below `Database/`. Different software environments are invoked with separate `conda run -n/-p` processes; do not chain `conda activate` and `conda deactivate`.

## Software schema

```markdown
---
name: Example Tool
description: What the tool is used for.
kind: software
id: example-tool
version: 2
selection_tier: conditional # default, conditional, or established
aliases: [Example Tool, example abbreviation, 中文别名]
keywords: [analysis term, file format, biological task]
environment: example-tool-env
executables: [example-tool]
packages: [example-tool]
environment_file: "" # alternatively, a pinned official Conda YAML URL/path
pip_packages: []
channels: [conda-forge, bioconda]
tasks: [example analysis]
databases: [example-db]
optional_databases: [] # resources needed only for selected subcommands or data types
capabilities: [supported analysis and its boundary]
inputs: [input artifact and exact format]
outputs: [output artifact and exact format]
upstream: [upstream-skill-id]
downstream: [downstream-skill-id]
excludes: [incompatible input or task phrase]
---

# Example Tool

## Capabilities and selection
## Inputs and upstream
## Outputs and downstream
## Parameters and decision rules
## Workflow patterns
## Validation and failure handling
```

The body should explain workflow-relevant subcommands and options, not merely list a command. For each important option, record what it controls, its default or accepted range when stable, when to change it, interactions with other options, and the output/scientific consequences. Name the upstream producer and downstream consumer for every important format so the planner can verify coordinate systems, identifiers, compression, pairing, and reference-version compatibility while chaining tools.

Use `excludes` for strong negative applicability constraints that cannot be inferred from generic task words. For example, GTDB-Tk can classify genomes but must be suppressed for `16S扩增子` FASTQ classification even though both tasks contain the word “分类”.

If the environment is absent, the registry renders a `mamba create` command. When several skills share one environment, their channels, Conda packages, and PyPI packages are deduplicated into that single command. The exact environment name and packages must appear in the user-confirmed plan before that command can execute.

Software distributions such as QIIME 2 that publish a complete, release-specific Conda YAML may set `environment_file` and leave `packages` empty. The registry then renders `mamba env create -y -n <environment> -f <environment_file>` instead of inventing package specs. Pin the release in both the environment name and YAML URL.

## Curated catalog added in this integration

Preferred `default` software: `ncbi-datasets`, `sra-toolkit`, `fastp`, `nanoplot`, `chopper`, `minimap2`, `flye`, `quast`, `snippy`, `snp-sites`, `snp-dists`, `skani`, `gubbins`, `panaroo`, `amrfinderplus`, and `checkm2`.

Reference acquisition software: `gget` for Ensembl/Ensembl Genomes eukaryotic DNA/GTF/cDNA/CDS/peptide assets, and `ncbi-datasets` for exact RefSeq/GenBank assemblies including bacteria and archaea. Both register immutable packages under the itemized `reference-genomes` database Skill; species names resolve to RefSeq reference accessions with the read-only `resolve_reference_genome_accessions()` tool, and NCBI taxon downloads run with a preflight assembly-count guard. Individual genes, transcripts, plasmids, loci and proteins use the read-only NCBI ESearch/ESummary resolver plus `ncbi-edirect` EFetch, then register exact accession-version packages under `reference-sequences`. Virus genome acquisition uses `gget virus` (preferred) or `datasets download virus genome` (limited fallback) through `plan_virus_genome_download()` and, after confirmation, `download_virus_genomes(..., approved=True)`; packages register under the itemized `virus-genomes` database Skill with per-isolate segment-completeness validation. SRA runs are project input data rather than databases: ENA metadata resolution selects a reviewed smallest pilot, `[MICROBIOME_DATA_ACQUISITION:sra-runs]` authorizes only that run on the first confirmation, and full confirmation resumes the remaining reviewed runs under `Data/sra/` with per-run validation, checksums and an atomic data manifest.

Context-dependent `conditional` software: `semibin2`, `dastool`, `gunc`, `hmmer`, `antismash`, `mob-suite`, `integronfinder`, `kraken2`, `dada2`, `qiime2`, and `ancombc2`.

Paired database skills: `amrfinderplus`, `bakta`, `checkm2`, `gunc`, `antismash`, `mob-suite`, `kraken2`, `pfam`, `silva`, `unite`, `reference-genomes`, `reference-sequences`, and `virus-genomes`. Every built-in database Skill declares acquisition mode, source, advantages, limitations, estimated size, localization, readiness, provenance, and validation. `automatic` or `conditional` acquisition still requires its deterministic marker and plan confirmation; `manual` resources never receive an automatic marker. Raw SRA runs deliberately use the separate data authorization and are not included in this database catalog.

For software distributed only through PyPI, put Conda bootstrap packages such as `pip` in `packages` and declare the application in `pip_packages`. The rendered creation command installs those packages with `conda run -n <environment> python -m pip`, so it never modifies the active Python environment.

## Database schema

```markdown
---
name: Example Database
description: What the database contains.
kind: database
id: example-db
version: 2
aliases: [Example DB, 中文别名]
keywords: [organism, annotation type, biological topic]
folder: example-db
required_markers: [index.dbtype]
raw_markers: [sequences.fasta]
compatible_software: [example-tool]
contents: [biological entities and annotations represented]
formats: [raw FASTA, localized index files]
consumers: [example-tool]
advantages: [why this source is scientifically preferred]
limitations: [coverage, bias, licensing, size, and compatibility constraints]
estimated_size: "Approximate compressed, expanded, and index size."
acquisition_mode: automatic # automatic, conditional, or manual
acquisition_commands:
  - "exact command allowed only after marked-plan confirmation"
update_policy: Pin one release per analysis and validate upgrades separately.
license_notes: Record official access, redistribution, citation, and use terms.
download_urls: [https://official.example/database]
localization_commands:
  - "conda run -n example-tool-env example-tool index Database/example-db/sequences.fasta Database/example-db/index"
---

# Example Database

## Scope and biological meaning
## Directory and readiness contract
## Acquisition and localization
## Software consumers and parameter coupling
## Workflow inputs and outputs
## Versioning, provenance, and updates
## Validation and failure handling
```

`folder` must be one directory name. The registry resolves it only as `Database/<folder>/`, preventing databases from being mixed together.

The database body must distinguish raw download files from localized/indexed assets, explain each consumer's database-path parameter and format expectations, and state release pinning, provenance, license, validation, and failure-recovery rules. Commands intended for automatic execution must be complete single-process commands without prose prefixes or unresolved `<placeholders>`; write explanatory alternatives in the body instead. `localization_commands` run only when acquisition has not already produced the readiness markers. A readiness marker proves only that declared local files exist; consumer compatibility still needs a lightweight validation command.

Multi-format references can add `common_markers`, `consumer_markers`, and `consumer_localization_commands`. The registry then blocks only the selected consumer format. For example, a READY SILVA DADA2 training FASTA does not require a QIIME classifier unless the confirmed plan actually selects QIIME 2.

## Adding skills

Skills can be added without editing the registry:

```python
from microbiome.resource_skills import add_database_skill, add_software_skill

add_software_skill(
    "example-tool",
    "Example analysis software.",
    environment="example-tool-env",
    selection_tier="conditional",
    executables=["example-tool"],
    packages=["example-tool"],
    tasks=["example analysis"],
    databases=["example-db"],
    aliases=["Example Tool", "示例工具"],
    keywords=["example format", "示例分析"],
    capabilities=["Analyze example records"],
    inputs=["FASTA with stable record IDs"],
    outputs=["TSV with one result per record"],
    upstream=["example-assembler"],
    downstream=["example-reporter"],
    excludes=["incompatible example input"],
    parameter_guidance=["--strict: retain high-confidence results only"],
)

add_database_skill(
    "example-db",
    "Example reference database.",
    folder="example-db",
    required_markers=["index.dbtype"],
    compatible_software=["example-tool"],
    contents=["Curated example reference records"],
    formats=["source FASTA", "example-tool index"],
    consumers=["example-tool"],
    advantages=["Curated records for the selected analysis"],
    limitations=["Does not cover unrelated organisms or evidence types"],
    estimated_size="About 2 GB localized",
    acquisition_mode="automatic",
    acquisition_commands=["example-tool download --output Database/example-db"],
    update_policy="Pin one release per analysis.",
    license_notes="Follow the official access and citation terms.",
    download_urls=["https://official.example/database"],
    localization_commands=["example-tool index sequences.fasta index"],
)
```

The files are written under `ResourceSkills/software/` or `ResourceSkills/database/`. When `instructions` is omitted, the API generates all required v2 sections from the structured fields and leaves explicit guidance where domain details still need to be documented. The next planning turn reloads them automatically.
