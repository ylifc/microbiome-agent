# Biomni Harness 缺陷清单

审计日期：2026-09-14。本轮确认六项缺陷，其中三项 P1、三项 P2；未修改业务源码。另有三项架构或发布缺口，单独列出，避免把缺少验收证据当成运行错误。P1 表示受影响的主要使用路径应在发布前修复；P2 表示条件触发的功能错误或接口契约问题。

## B01 P1 DeepSeek 环境变量密钥被默认占位值覆盖

位置：[microbiome/llm.py:58](/home/ylifc/AI_models_works/bioinformatics/biomni/Biomni_further_developed/microbiome/llm.py:58)、[microbiome/llm.py:309](/home/ylifc/AI_models_works/bioinformatics/biomni/Biomni_further_developed/microbiome/llm.py:309)。

触发：用户设置 `DEEPSEEK_API_KEY`，通过 `get_llm(model="deepseek-chat", source="DeepSeek")` 使用独立模型入口，未显式传入 `api_key`。

源码先把 `None` 改成非空字符串 `EMPTY`，后面的 `api_key or os.getenv("DEEPSEEK_API_KEY")` 永远优先选择该占位值。离线创建真实 ChatOpenAI 对象，检查其凭据字段，结果 `deepseek_env_key_forwarded=false`、`deepseek_key_is_EMPTY=true`。这说明实际客户端会使用错误凭据；本轮没有向服务端发送请求，未声称观察到 HTTP 401。

影响：依赖标准环境变量配置的 DeepSeek 独立入口不可正确认证。Harness 模式提前返回注入模型，不经过此分支。

最小修复：各提供商完成显式值、配置值、环境变量解析后，再决定是否允许占位值。新增验证最终客户端密钥来源的测试，不只检查对象非空或 URL 正确。

## B02 P1 OpenAI 显式密钥与地址未传入客户端

位置：[microbiome/llm.py:134](/home/ylifc/AI_models_works/bioinformatics/biomni/Biomni_further_developed/microbiome/llm.py:134)、[microbiome/llm.py:142](/home/ylifc/AI_models_works/bioinformatics/biomni/Biomni_further_developed/microbiome/llm.py:142)。

触发：使用 `source="OpenAI"`，显式提供 `api_key` 或 `base_url`，例如代理网关、企业端点。两个 ChatOpenAI 构造分支均未传递这两个参数。

复现：使用占位环境密钥 `audit-env`、显式密钥 `audit-explicit` 和 `https://audit.invalid/v1` 创建 gpt-4o 对象，观察到显式密钥和地址均未生效。没有外发请求或输出真实凭据。

影响：配置接口承诺的覆盖行为失效；可能使用错误账户或目标端点。Harness 模式不受此独立分支影响。

最小修复：统一传递已解析配置，并为普通 OpenAI 与 Responses 分支分别断言最终客户端参数。

## B03 P2 MicrobiomeConfig 字段名不一致导致异常

位置：[microbiome/llm.py:43](/home/ylifc/AI_models_works/bioinformatics/biomni/Biomni_further_developed/microbiome/llm.py:43)；实际字段定义位于 [microbiome/config.py:36](/home/ylifc/AI_models_works/bioinformatics/biomni/Biomni_further_developed/microbiome/config.py:36)。

触发：`get_llm(config=MicrobiomeConfig(llm="deepseek-chat", source="DeepSeek", api_key="audit-placeholder"))`，未另传 `model`。

结果：`AttributeError: 'MicrobiomeConfig' object has no attribute 'llm_model'`。配置字段实际名为 `llm`。A1 当前将模型名作为位置参数传递，因此该路径通常绕过此错误；不能将其夸大为所有 A1 启动都会失败。

最小修复：读取现有 `config.llm`，或者显式维护兼容别名，并补充仅传 config 的公共 API 测试。

以上三项的结果见 [model-probes.json](evidence/model-probes.json)。离线复验命令：

```bash
PYTHONPATH=. python docs/audits/2026-09-14-harness/evidence/reproduce_models.py
```

## B04 P1 普通 wheel 缺少跨样本适配器

位置：[microbiome/harness/assets.py:10](/home/ylifc/AI_models_works/bioinformatics/biomni/Biomni_further_developed/microbiome/harness/assets.py:10)、[pyproject.toml:85](/home/ylifc/AI_models_works/bioinformatics/biomni/Biomni_further_developed/pyproject.toml:85)；仅专用发布脚本 [scripts/build_harness_release.py:102](/home/ylifc/AI_models_works/bioinformatics/biomni/Biomni_further_developed/scripts/build_harness_release.py:102) 才会把脚本复制进包。

触发：通过标准 Python wheel 构建、安装项目，在源码目录之外解析 `asset://cohort_tables.py`。`cohort_tables.py`、`run_dada2.R`、`run_ancombc2.R` 在普通 wheel 中均不存在。

本轮在临时源码副本使用 `pip wheel --no-deps --no-build-isolation` 构建成功，将 wheel 解压为独立安装布局，在该布局之外调用包内 `asset_path`，得到 `FileNotFoundError: Incomplete installation: cohort_tables.py`。结果见 [wheel-assets.json](evidence/wheel-assets.json)，构建输出见 [wheel-build.log](evidence/wheel-build.log)。这是隔离 wheel 布局验证，没有新建并安装所有依赖的干净 venv。

影响：常规 wheel 的跨样本工作流、对应 `microbiome-asset` 和 doctor 检查失败；源码可因 fallback 找到 scripts 而掩盖缺陷。已检查的 2026-09-09 专用 Harness 发布 wheel 含这些文件，此条不指该专用包缺件。

最小修复：将适配器作为常规包资源维护，使标准 wheel 和专用发布包共用同一打包路径；增加源码目录外的 wheel 资源检查。

## B05 P2 默认 Claude 入口缺少可安装依赖声明

位置：[microbiome/config.py:36](/home/ylifc/AI_models_works/bioinformatics/biomni/Biomni_further_developed/microbiome/config.py:36)、[microbiome/llm.py:169](/home/ylifc/AI_models_works/bioinformatics/biomni/Biomni_further_developed/microbiome/llm.py:169)、[pyproject.toml:15](/home/ylifc/AI_models_works/bioinformatics/biomni/Biomni_further_developed/pyproject.toml:15)、[pyproject.toml:49](/home/ylifc/AI_models_works/bioinformatics/biomni/Biomni_further_developed/pyproject.toml:49)。

配置默认选择 Claude，而 Anthropic 分支导入 `langchain_anthropic`。核心依赖及所有 extras 均没有声明 `langchain-anthropic`。本轮环境中该包也不存在。

影响：仅安装当前项目声明依赖并保留默认模型时，独立入口缺少必要适配器并抛出 ImportError。宿主模式注入模型，通常不触发该分支。缺少包本身不能推导为 Claude API 不支持。

最小修复：为支持的独立 provider 提供明确 extras，或把默认 provider 的依赖纳入默认安装；在干净环境逐个检查公开声明支持的入口。

## B06 P2 未完成项目接入就持久绑定会话

位置：[microbiome/harness/plugin.mjs:181](/home/ylifc/AI_models_works/bioinformatics/biomni/Biomni_further_developed/microbiome/harness/plugin.mjs:181)、[microbiome/harness/plugin.mjs:187](/home/ylifc/AI_models_works/bioinformatics/biomni/Biomni_further_developed/microbiome/harness/plugin.mjs:187)、[microbiome/harness/plugin.mjs:193](/home/ylifc/AI_models_works/bioinformatics/biomni/Biomni_further_developed/microbiome/harness/plugin.mjs:193)；缺少新项目路径的拒绝位于 [microbiome/harness/worker.py:71](/home/ylifc/AI_models_works/bioinformatics/biomni/Biomni_further_developed/microbiome/harness/worker.py:71)。

触发：首次调用 `microbiome_workflow({})`。工具 schema 允许该调用，插件选择默认项目、启动 job，并立即保存 session binding；worker 随后会因缺少 data_dir/db_dir 返回 NEEDS_PATHS。用户在下一条真实消息补充一个不同的明确项目目录，插件却先报 `Session bound to another project; open a new session`。

本轮以隔离宿主 job 替身复现插件侧持久绑定及后续拒绝，见 [binding-probe.json](evidence/binding-probe.json)。此探针没有运行失败 worker；worker 的 NEEDS_PATHS 分支是源码证据。真实宿主正常路径的测试另行通过。

影响：普通路径补充流程变成需要重开会话的死路；首次同消息重试也只返回旧 job ID。

最小修复：新项目接入前校验必要参数；成功建立项目后再提交持久绑定，或在确定没有创建有效项目时回滚临时绑定。保留对已经成功绑定项目的禁止切换规则。

## 单独记录的缺口

| ID | 缺口 | 判定依据与处置 |
| --- | --- | --- |
| G01 | 00–09 与进化系统缺少可追溯实现 | 无阶段定义、验收映射及 Evolver/EvoMap/EvoX 调用链。应补充规格和证据，不应伪造完成百分比。 |
| G02 | 缺少模型感知的统一上下文预算 | `agent/workflow.py:409` 只按消息条数截取；`PlanningContext.collect` 含全文；Python 桥接仅发 messages/stop/tools。宿主 route 可携带预算，但本仓库没有基于窗口的输入计量和预算测试。 |
| G03 | 默认发布构建没有生成依赖锁 | `build_harness_release.py:137` 仅在 `--offline-deps` 下生成 requirements.lock；无该开关的 portable 构建将重新解析宽松依赖。现存受检发布包含锁，不能把潜在默认构建缺口说成现存包完全无锁。 |

## 修复顺序与回归要求

优先修复 B01、B02、B04，再修复 B03、B05、B06；G02 需要清晰的宿主与插件配置职责设计，G01 需要原始研发计划。每次改动后保留冻结执行、独立生产确认及资源漂移拒绝的现有行为。详细通过记录与未测范围见 [deployment_gap_report.md](deployment_gap_report.md)。
