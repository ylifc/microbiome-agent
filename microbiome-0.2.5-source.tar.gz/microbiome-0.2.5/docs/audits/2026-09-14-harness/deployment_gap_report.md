# Biomni Harness 部署缺口报告

审计日期：2026-09-14。结论：现有专用发布包完整性通过，本机真实宿主服务与合成冻结流程通过；普通 wheel 存在缺件，默认 Claude 依赖和独立模型配置仍有问题。本轮没有在全新 Ubuntu 主机执行完整安装，不能把本机测试或历史验收声明提升为第三方机器可直接部署的保证。

## 已执行验证

| 检查 | 本轮结果 | 证据 |
| --- | --- | --- |
| 指定冻结流程测试 | 29 passed，120.81 秒 | [frozen-tests.log](evidence/frozen-tests.log)，汇总自工具执行结果 |
| Harness、模型、持久流程、输入绑定、分析经验 | 45 passed，84.79 秒 | [targeted-tests.log](evidence/targeted-tests.log) |
| 软件复用、资源注册、解析、证据、输入发现、Conda bootstrap | 100 passed，45.39 秒 | [resource-tests-corrected.log](evidence/resource-tests-corrected.log) |
| Node 桥接 | 5 passed | [node-tests.log](evidence/node-tests.log) |
| 真实宿主集成 | DeepSeek Harness 0.1.0-rc.8，通过 preset、Agent、工具隔离、jobs、subprocess、确定性模型调用及事件重放 | [host-acceptance.json](evidence/host-acceptance.json) |
| 源码模式 doctor | ok=true；107 个软件 Skill、33 个数据库 Skill、0 errors、11 warnings；scientific_runtime=NOT_PROBED | [doctor.json](evidence/doctor.json) |
| 合成执行验收 | 实际复制、计数、预检、冻结、生产、恢复通过；one=20、two=30 | [synthetic-smoke.log](evidence/synthetic-smoke.log) |
| 现存发布包 | portable 与 offline 两个 SHA256 均匹配；bundle manifest 中 35 个文件验证通过 | [release-check.json](evidence/release-check.json) |
| 发布包与当前桥接源码一致性 | plugin、worker、model、llm 四个文件逐字节一致 | [release-check.json](evidence/release-check.json) |
| 普通 wheel | 无依赖构建成功，三个适配器均缺失；隔离安装布局 asset lookup 失败 | [wheel-assets.json](evidence/wheel-assets.json) |

总计 174 个 Python 测试和 5 个 Node 测试通过。真实宿主组合测试、smoke、构建和配置探针另计。一次资源测试命令误引用不存在的 `tests/test_planning_context.py`，未收集任何测试；已纠正文件列表后得到 100 passed。该命令错误保留于 [resource-tests.log](evidence/resource-tests.log)，不计为项目测试失败，也不计入通过数。

本轮使用现有 Python 3.13.13、Node 22.23.1 及 `/tmp/microbiome-harness-host-rc8` 中的宿主依赖。为验收建立独立临时 preset、session、项目和合成数据目录，加载当前工作区源码。没有修改用户正在使用的 Harness preset、生产锁、科学环境或数据库。普通 wheel 验证使用临时源码副本和既有构建依赖，不安装科学软件。

## Ubuntu 安装能力分层判断

| 层次 | 现有能力 | 缺口 |
| --- | --- | --- |
| 核心 Python 引擎 | 专用 install.sh 调用 Python 安装器，版本化独立 venv，pip check 与 doctor 后切换 preset | 本轮未执行新的完整 venv 安装；普通 wheel 缺跨样本 assets，见 B04 |
| 宿主平台 | 已适配外部 Harness rc.8 的 Cordis、LLM、jobs、subprocess | 本项目不安装和配置完整宿主；宿主源码版本检查仅在提供 --harness-source 时执行 |
| 科学软件 | 现有 Conda 环境/注册表优先发现；批准后有 bounded install；版本/help 验证后登记 | 核心 venv 不是科学工具环境；107 个 Skill 不是 107 个软件已安装。部分工具仍需包映射、许可证或平台适配 |
| 数据库与索引 | 持久目录、运行入口、markers、指纹、READY 复用和批准获取 | 33 个 Skill 不是数据库数据；doctor 的 11 条警告表示相关数据库发现说明仍有缺口 |
| 模型联网 | 宿主模型路由可以继承；独立路径有 provider 分支 | 真实四家服务未测；独立入口 B01、B02、B03、B05 需修复 |
| 生产恢复 | 冻结锁、状态、运行回执、检查点与明确恢复命令 | 依赖宿主进程生命周期，不是独立长期守护服务；宿主退出后的进程持续性未验收 |

## 发布脚本审阅

[scripts/install_harness.py:25](/home/ylifc/AI_models_works/bioinformatics/biomni/Biomni_further_developed/scripts/install_harness.py:25) 校验 manifest 文件及路径边界；现有发布 artifact 校验通过。安装目标是受管理目录，已有非受管理 preset 会被拒绝。版本化 runtime 保留旧版本，失败时清理本次新建目录，切换失败时恢复旧 preset。这些属于实质安装代码，不是空接口。

仍需收敛的发布事项：

1. **统一常规与专用构建。** 当前发布脚本额外复制三份 assets，普通 wheel 没有它们。修复 B04 后应在源码外运行同一 doctor/smoke。
2. **保证每种发布模式都有锁。** 默认 `build_harness_release.py` 只有 `--offline-deps` 分支产生 requirements.lock。现存 2026-09-09 portable 包带锁，是使用该分支生成的结果，不能说明默认路径也锁定依赖。
3. **澄清 Python 版本契约。** 包声明 >=3.11；专用发布 manifest 的 release_python_min 为 3.12，离线包要求 build_python 的次版本和架构一致。新用户需要清楚区分源码支持范围和具体发布依赖限制。
4. **补充宿主版本与部署验收矩阵。** 构建器硬编码宿主版本 rc.8 和 commit 字符串；这些不是当前宿主实测身份的自动采集。实际加载检查不能代替版本化兼容矩阵。
5. **恢复路径测试。** B06 表明失败接入仍可持久绑定。需覆盖缺少路径、更正路径、worker 启动失败、重复消息、取消和宿主重启后的恢复。
6. **把验收绑定到发布输入。** 仓库大量未提交变化，builder 从工作区复制，不是从固定 Git 提交导出。应记录工作区内容指纹、锁、构建工具和最终 artifact；没有独立签名或可信发布来源验证时，SHA256 只能证明完整性。

以上是后续可审查的工程修改建议，不代表本轮已经重建或发布新版。

## 真实安装与历史声明的界线

`docs/VALIDATION.md` 和发布目录中的 `VALIDATION.json` 记录了 2026-09-09 的新 venv、Python 3.12/3.13、升级回退卸载等历史验收。本轮读取并核对其范围，但没有重新执行全部历史操作。仅对上表列出的检查给出“本轮通过”结论。

本轮未验证：新的 Ubuntu VM/容器离线安装与在线安装、真实提供商网络与计费、完整科学工具安装、大型数据库获取、真实研究任务、ARM/macOS/Windows 原生、调度集群、长任务跨宿主重启。不存在这类证据时应标记未验证，不应直接判定这些平台必然不可用。

## 推荐后续验收

先修复 [bug_list.md](bug_list.md) 中六项具体问题，并补上普通 wheel 和 provider 参数的回归。然后对待发布包在干净 Ubuntu 环境验证在线/离线安装、幂等重装、切换失败回滚、卸载保留数据、源码外 doctor 与固定合成 smoke。科学软件和数据库仍应按具体项目依赖计划分别批准和验证。最后补充 00–09 原始定义和 Evolver/EvoMap/EvoX 的真实目标代码，再评审进化能力与发布晋级机制。

## 可复验命令

在本项目根目录与现有测试环境中运行：

```bash
pytest -q tests/test_frozen_pipeline.py
pytest -q tests/test_harness_integration.py tests/test_deepseek.py tests/test_llm_ollama.py tests/test_persistent_workflow.py tests/test_production_input_binding.py tests/test_analysis_experience.py
pytest -q tests/test_software_reuse.py tests/test_resource_skills.py tests/test_resource_resolver.py tests/test_resource_evidence_contracts.py tests/test_input_resolution.py tests/test_conda_bootstrap.py
node --test tests/test_harness_plugin.mjs
python -m microbiome.harness.doctor
PYTHONPATH=. python docs/audits/2026-09-14-harness/evidence/reproduce_models.py
```

宿主组合测试需使用隔离 preset 和新的工作目录；具体本轮路径见 [runtime-root.txt](evidence/runtime-root.txt)，结果已复制到报告 evidence 中，不依赖临时目录永久存在。源码文件指纹、运行环境与通过统计见 [audit-snapshot.json](evidence/audit-snapshot.json)。
