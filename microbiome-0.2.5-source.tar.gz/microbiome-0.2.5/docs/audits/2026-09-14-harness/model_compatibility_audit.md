# Biomni Harness 模型兼容性审计

审计日期：2026-09-14。结论：宿主路由桥接已通过真实 Harness 服务组合测试；四家真实提供商的网络兼容性均未在本轮验证。独立入口另外存在已复现配置缺陷，不能用宿主桥接测试通过来覆盖这些问题。

## 两套接入路径

Harness 路径在 [microbiome/llm.py:36](/home/ylifc/AI_models_works/bioinformatics/biomni/Biomni_further_developed/microbiome/llm.py:36) 优先返回 ContextVar 注入的模型。`worker.py` 设置 `MICROBIOME_LLM_TRANSPORT=harness`，由 `HarnessChatModel` 通过 NDJSON 请求宿主 `llm.prepareCall`。如果缺少注入模型则抛 HARNESS_UNAVAILABLE，不会自动回退到其他提供商。

独立路径由 `microbiome/llm.py:get_llm` 构造 LangChain 提供商客户端。该路径涉及本地环境变量、base_url、api_key 和默认模型。worker 明确拒绝携带模型/凭据配置的请求，因此独立入口的修复应与宿主路由职责区分。

## 提供商矩阵

| 提供商 | 独立实现 | 本轮观察 | 可确认程度 |
| --- | --- | --- | --- |
| OpenAI | ChatOpenAI；gpt-5 前缀使用 Responses 包装 | 显式 api_key/base_url 丢失，见 B02；没有远端请求 | 适配代码存在，配置覆盖有缺陷，API 兼容未测 |
| Claude / Anthropic | ChatAnthropic | 项目未声明 langchain-anthropic，当前环境缺包；显式 api_key/base_url 也未出现在该分支构造参数中 | 独立默认安装路径不完整；宿主侧 Claude 未测 |
| DeepSeek | OpenAI 兼容 ChatOpenAI | 标准环境变量密钥被 EMPTY 覆盖，见 B01；现有三项测试只验证来源、地址和对象存在 | 独立认证配置有缺陷；真实模型与流响应未测 |
| Ollama | ChatOllama | 两项测试使用替代类确认 URL 去除 /v1、loopback 不走环境代理、reasoning=False | 构造配置契约已测；未启动或请求 Ollama 服务 |
| Harness 当前模型 | HarnessChatModel → plugin → 宿主 LLM 服务 | 真实 rc.8 宿主、两次确定性模型调用、后台 worker、会话重放测试通过 | 宿主服务集成已验证；不等于上述四家全部联网成功 |

未依据源码注释推断最新模型 API 行为。例如 DeepSeek reasoner 与 gpt-5 的参数处理需要针对具体模型版本验证；本轮只报告本地代码行为，不认证这些注释在所有服务端版本上成立。

## 配置字段核对

| 字段 | 当前实现 | 缺口或限制 |
| --- | --- | --- |
| provider | 独立入口使用 source；宿主 route.provider | 两套命名不同；宿主 worker 不接受用户指定 provider |
| model | 独立 config.llm；宿主 route.model | get_llm 的 config-only 路径错误读取 llm_model，见 B03 |
| base_url | 独立入口部分提供商支持；宿主交由 prepareCall | OpenAI 显式覆盖无效；不能通过 worker 替换宿主端点 |
| context_length | MicrobiomeConfig 未定义；规划上下文无统一窗口计量 | 无证据证明插件能自动适配小窗口或长会话 |
| 输出 token 预算 | Anthropic、Custom、DeepSeek 独立分支固定 8192；宿主继承准备后的 route 配置 | 无跨 provider 统一可配置字段；Python invoke 的 max_tokens 不通过 NDJSON 传递 |
| 输入预算 | 最近 40 条 history 加资源全文与编译信息 | 40 条不是 token 上限，全文知识和多次编译可能超过窗口 |
| temperature | 独立入口参数；宿主完全继承路由 | Python HarnessChatModel.invoke 的 temperature 被忽略；这一点应作为明确契约或显式报错 |
| stop | 桥接传递并由 prepareCall 处理 | Node 替代测试覆盖传递；未验证每家服务端对停止序列的支持 |

宿主路由在测试中保留 `maxTokens=2048`，这证明桥接可保留宿主配置；不能由此断言插件没有任何输出预算，也不能断言它已实现输入窗口管理。

## 响应和工具协议

`plugin.mjs:43` 聚合 text-delta、tool-call-delta、block-end、usage 和 finish，拒绝缺少终止事件、max-tokens 截断、未闭合 JSON 工具参数；`model.py` 生成 AIMessage，工具调用由 Python 侧消费。`with_structured_output` 通过提示词要求 JSON，再本地解析与 Pydantic/jsonschema 校验；这不是提供商原生强制 JSON schema。

仅接受文本 block；图像等输入会被明确拒绝。强制 tool_choice 除 auto 外被拒绝。用量放在 `response_metadata.harness_usage` 和会话扩展事件中，未证明进入宿主标准费用统计。

重试有次数上限及宿主错误分类判断，但本轮未做 provider 网络错误、429、超时、并发取消与部分流重试的完整矩阵。不能把一条文本对话通过当作这些路径的验收。

## 本轮证据

- [model-probes.json](evidence/model-probes.json)：真实客户端对象的离线配置检查，所有凭据均为占位值。
- [node-tests.log](evidence/node-tests.log)：5 项桥接单元测试通过。
- [targeted-tests.log](evidence/targeted-tests.log)：包含 7 项 Python Harness 集成、DeepSeek、Ollama、持久工作流及输入绑定测试。
- [host-acceptance.json](evidence/host-acceptance.json)：真实 rc.8 宿主服务测试；模型 adapter 为确定性测试实现。

下一轮应先修复配置传递，再针对每个已配置的提供商验证一次文本、结构化输出、工具调用、截断、错误和取消；模型能力与 token 预算应按具体 provider/model/version 留下机器可读验收记录。本轮未调用用户付费模型或读取、展示真实密钥。
