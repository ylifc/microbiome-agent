# Biomni Harness 架构审计

审计日期：2026-09-14。结论：当前工作区实现了可运行的 Microbiome 工作流引擎与 DeepSeek Harness 插件；不能据此认定文档所列完整 Harness 平台、00–09 阶段以及 Evolver、EvoMap、EvoX 已完成。核心冻结执行链有本轮测试支持，模型独立入口与普通 wheel 分发仍存在已复现缺陷。

## 审计依据与范围

用户要求“按照这个计划检查这个项目”。附件 `01_GPT6_Codex_Harness_Audit_Prompt.docx` 提供七项审查范围和四份 Markdown 输出要求；其中关于开发者身份、开发完成状态的文字没有被当作事实。本轮检查并记录问题，不修改业务源码、不重构、不发布。

被审对象是当前工作目录 `Biomni_further_developed`，Git HEAD 为 `fc7f37459fdbe9dc4febad8527edf22fa1163d4a`，实际包名为 `microbiome`。开始审计时已有 70 个修改项、344 个删除项和 105 个未跟踪项，因此结论针对当前工作区，不能仅通过 checkout 此 HEAD 重现。`github_upload` 镜像、历史项目输出、外部宿主完整实现不作为当前源码的替代品。

检查了 `microbiome/harness`、`harness`、模型配置、Agent 到持久工作流的调用链、pipeline 资源/冻结/执行/知识模块，以及构建安装脚本与相关测试。不是对全部科学工具算法逐项进行有效性评审。

## 实际调用链

```mermaid
flowchart TD
  U[Harness 真实用户事件] --> P[plugin.mjs 注册工作流工具]
  P --> J[宿主 jobs 与 subprocess]
  J --> W[worker.py 协议与项目锁]
  W --> A[A1 与 ConversationWorkflow]
  A --> I[持久输入清单]
  A --> C[PlanningContext 与方案编译]
  C --> M[HarnessChatModel]
  M --> N[NDJSON model_request]
  N --> H[宿主 llm.prepareCall 与当前模型路由]
  A --> D[依赖计划与用户确认]
  D --> T[资源准备与小数据验收]
  T --> F[ValidationFinalizer 与冻结锁]
  F --> B[独立生产确认与 ProductionController]
  B --> E[确定性执行与检查点]
  E --> K[Knowledge 与最终报告]
```

这里的 jobs、LLM 服务和 Cordis 插件加载器由外部 DeepSeek Harness 提供。仓库没有重新实现这些宿主核心服务。

## 九个架构组件核对

| 组件 | 状态 | 源码证据与边界 |
| --- | --- | --- |
| Agent 入口 | 已连接并动态验证 | `harness/agent.cordis.yml` → [microbiome/harness/plugin.mjs:171](/home/ylifc/AI_models_works/bioinformatics/biomni/Biomni_further_developed/microbiome/harness/plugin.mjs:171) → `worker.py:117`；独立 CLI 为 `microbiome/cli.py`。 |
| Harness 核心 | 外部依赖 | `plugin.mjs:9` 注入 tools、llm、subprocess、jobs；`scripts/verify_harness_runtime.mjs` 使用真实已安装宿主包组合测试。不能将插件等同于完整宿主实现。 |
| Model Adapter | 已连接，兼容性部分验证 | [microbiome/harness/model.py:32](/home/ylifc/AI_models_works/bioinformatics/biomni/Biomni_further_developed/microbiome/harness/model.py:32) 实现 LangChain 适配；`plugin.mjs:43` 调用宿主 prepared stream；未对四家外部提供商发起真实请求。 |
| Tool Registry | 已连接，存在不同职责层 | [microbiome/tool/tool_registry.py:6](/home/ylifc/AI_models_works/bioinformatics/biomni/Biomni_further_developed/microbiome/tool/tool_registry.py:6) 是工具描述/检索目录；`pipeline/registry.py` 和 `resource_skills/resolver.py` 管理执行事实；宿主仅暴露工作流、状态和任务工具。描述目录不能当 READY 注册表。 |
| Workflow Adapter | 已连接，专用耦合 | `worker.py:117` 直接构造 A1；`agent/workflow.py:317` 调用其私有规划、确认识别等方法。NDJSON 有 protocol=1，但尚无通用 Agent Protocol/ABC 及多个实现的契约测试。 |
| Context Builder | 已连接，预算不足 | `pipeline/planning_context.py:9` 组装 Skill、绑定及 Knowledge，持久化指纹；`agent/workflow.py:409` 取最近 40 条消息。全文资源内容与消息未按模型 token 窗口统一裁剪。 |
| Experience Store | 已连接 | `pipeline/knowledge.py:36`、`execution.py:618` 记录真实调用及验收；`analysis_experience.py` 与 `agent/a1.py:3391` 提供历史摘要检索。历史材料明确分为已验证事实与未验证指导。 |
| Evolution Controller | 未发现实现或调用链 | 在当前源码、测试、脚本和文档中未找到 Evolver、EvoMap、EvoX 或相应控制器；失败签名、回归候选、安装经验不等于模型或策略进化系统。 |
| Release Manager | 有打包安装脚本，非进化发布服务 | `scripts/build_harness_release.py` 与 `install_harness.py` 实现 manifest、版本化 venv、preset 备份回退；未发现候选策略评估、晋级、运行中策略版本治理。 |

## 00–09 阶段核对

附件只写“阶段00–09完成情况”，未给出每个阶段名称、交付物或验收条件。当前源码及文档中也未检索到与此编号体系匹配的计划。现有 `pipeline/state.py:16` 定义的是 NEW、BOOTSTRAP、PRETEST、FROZEN、PRODUCTION 等运行状态，不能替代研发阶段。

| 阶段 | 结论 |
| --- | --- |
| 00 | 无法判定，缺少该阶段定义与验收映射 |
| 01 | 无法判定，缺少该阶段定义与验收映射 |
| 02 | 无法判定，缺少该阶段定义与验收映射 |
| 03 | 无法判定，缺少该阶段定义与验收映射 |
| 04 | 无法判定，缺少该阶段定义与验收映射 |
| 05 | 无法判定，缺少该阶段定义与验收映射 |
| 06 | 无法判定，缺少该阶段定义与验收映射 |
| 07 | 无法判定，缺少该阶段定义与验收映射 |
| 08 | 无法判定，缺少该阶段定义与验收映射 |
| 09 | 无法判定，缺少该阶段定义与验收映射 |

这些结论不等于十个阶段均未实现；它们表示当前证据不足以赋予完成状态。补充原始阶段计划和目标 Harness 源码边界后才能建立可追溯矩阵。

## mock 与真实执行的区分

- `tests/test_harness_plugin.mjs` 使用替代宿主服务，验证协议、消息来源和工具注册；不能证明真实模型联网。
- `tests/test_harness_integration.py` 启动真实 Python worker，模型响应由测试提供；包含预检和生产分别确认、生产零模型调用、回执复用。
- 本轮运行 `scripts/verify_harness_runtime.mjs`，真实加载本地 DeepSeek Harness 0.1.0-rc.8 的 preset、Agent、tools、jobs、subprocess、LLM 服务，并通过两次确定性模型调用完成验证。证据见 [host-acceptance.json](evidence/host-acceptance.json)。仍未调用 OpenAI、Claude、DeepSeek 或 Ollama 服务端。
- 本轮 synthetic smoke 实际执行合成文件复制、计数、验收、冻结、全量和恢复，结果 one=20、two=30。它不是生物软件或真实数据有效性的验证。
- 未在专用 `microbiome/harness` 桥接代码中发现用 `pass`、TODO 或空函数冒充上述能力的情况。缺失的进化系统应记为“未发现”，不应描述为已经集成但只运行 mock。

## 项目约束核对

本地输入由 `ConversationWorkflow._resolve` 优先恢复持久 manifest，`stage` 校验输入指纹；混合 manifest 在原始数据获取模块逐条处理。依赖计划按当前确认指纹进入 BOOTSTRAP；生产通过 `pipeline/execution.py:74` 的独立执行器重放锁，资源预检发现漂移时停止。`resource_skills/resolver.py:56` 限定可变阶段；同文件 785 行起优先检查锁和注册表，再进行已有环境发现。安装、获取与 Skill 生成的具体边界由测试和机器可读契约支撑，而不只依赖提示词。

已通过的冻结及持久流程测试涵盖本地输入不重扫、全量不使用预检子集、审批失效、数据库漂移、锁篡改和恢复。软件安装与数据库网络获取测试使用隔离夹具或 hook；本轮未实际安装科学软件或获取数据库。

## 验收结论

可以确认“专用 Harness 插件加冻结工作流引擎”已经跑通受测路径。不能确认“完整九组件自进化 Harness”“00–09 全部完成”“四家模型均可用”或“任意 Ubuntu 新机器安装即完成科学分析”。具体缺陷、模型差异和部署缺口分别见 [bug_list.md](bug_list.md)、[model_compatibility_audit.md](model_compatibility_audit.md)、[deployment_gap_report.md](deployment_gap_report.md)。
