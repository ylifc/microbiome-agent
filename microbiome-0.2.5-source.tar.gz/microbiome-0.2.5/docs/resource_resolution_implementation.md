# Resource Resolution and Self-Learning Implementation Report

Date: 2026-08-20

1. `Unknown software skill: blastn` was raised by `ResourceSkillRegistry.get_skill()` in `microbiome/resource_skills/registry.py`. The old method looked up only `(kind, skill_id)` and raised `KeyError` on a miss.
2. The packaged Skill was already `software:ncbi-blast`, with `blastn` declared as an executable/alias. Treating the planner name as an exact Skill ID made a missing lookup fatal before executable discovery could run.
3. `ToolResolver` now separates logical tool, software family, package candidates, executable, Conda prefix, version and Skill. Resolution order is frozen lock, Tool Registry, Skill/alias mapping, project environments/directories, all Conda environments, PATH, package metadata and finally an approved installation.
4. This machine already has `blastn`; no installation was needed.
5. The selected environment is `/home/ylifc/miniforge3/envs/ncbi_blast`. Resolution is capability-based, so a differently named environment would also be reused after validation.
6. No BLAST installation command was run. For a genuinely missing approved dependency, the bounded installer uses a project prefix under `.biomni/envs/<family>` and verified package/channel metadata.
7. Installation status for BLAST is `not attempted / existing installation reused`. First and second generic resolution both reported `installed: false`.
8. Validated executable: `/home/ylifc/miniforge3/envs/ncbi_blast/bin/blastn`.
9. Validated version: `blastn 2.17.0+`, Conda package `blast 2.17.0` from Bioconda. The working version invocation is `-version`; the working help invocation is `-help`.
10. The existing, non-duplicated Skill is `microbiome/resource_skills/software/ncbi-blast/SKILL.md`. Unknown validated tools are learned under `<OUTPUT_PATH>/resource_skills/software/<family>/SKILL.md` (or the configured custom Skill root).
11. The current machine binding is persisted in `ResourceSkills/tool_registry.yaml`; alias/family/package mappings are in `ResourceSkills/tool_alias_registry.yaml`. These machine-specific files are intentionally Git-ignored.
12. Generated software Skills contain capabilities, inputs/upstream, outputs/downstream, parameter rules, workflow patterns, validation/failure handling, exact executable/environment metadata, package mapping and local documentation references.
13. BLAST help/version snapshots are packaged under `microbiome/resource_skills/software/ncbi-blast/docs/` and refreshed at runtime under `ResourceSkills/software/ncbi-blast/docs/` or project Knowledge.
14. Existing BLAST failure/fix history remains in `software_memory/ncbi-blast.md`. Strict projects use `<OUTPUT_PATH>/knowledge/tools/<family>/known_errors.jsonl`; only verified fixes are reusable.
15. Current discovery/reuse validations are in `ResourceSkills/knowledge/tools/ncbi-blast/validation_history.jsonl`. Real strict-pipeline invocations are appended to `<OUTPUT_PATH>/knowledge/tools/<tool>/invocations.jsonl`.
16. Database Registry stores one persistent root/base contract plus status, release, markers, fingerprint, provenance and a `consumer_entrypoints` mapping. READY entries are revalidated and reused; identity drift is rejected.
17. A validated unskilled database is converted to a schema-compatible Database Skill by `DatabaseSkillBuilder`; acquisition failure or partial state never produces READY.
18. The base `runtime_entry` and every software-specific entrypoint are stored separately. Freeze binds each step to `consumer_entrypoints[step.tool]` when present, rather than passing a database directory where an index file/prefix is required.
19. Second software resolution hits the fingerprinted Tool Registry, re-runs bounded validation, loads the existing Skill and performs zero installs. READY software is never automatically updated.
20. Second database resolution validates the existing Registry/markers/fingerprint and performs zero acquisitions. Acquirers remain approval-gated, idempotent and outside Production.
21. Main implementation files: `microbiome/resource_skills/resolver.py`, resource Skill registry/exports, pipeline resource/registry/knowledge/lifecycle/dependency/freeze/execution modules, A1 pilot resource preparation, AGENTS rules, package manifest and resource documentation.
22. `tests/test_resource_resolver.py` adds generic discovery, approved install, zero-install reuse, family/multi-executable reuse, stale Registry recovery, broken Skill recovery, Production prohibition, database zero-download reuse, consumer entrypoint and BLAST alias regressions.
23. Executed the required focused frozen-pipeline tests, the new resource tests, related lifecycle/Agent/Production suites, Ruff checks and the complete repository test suite. The real local BLAST executable/version/help and Conda package metadata were also inspected.
24. Results: full suite `539 passed`; final focused resource + frozen regression `38 passed`; Ruff checks passed. Actual first BLAST resolution used the existing Conda environment, and the immediate second resolution used `tool registry`, with zero installs both times.

Production remains deliberately different from Bootstrap: it requires valid pipeline/toolchain/database locks plus matching Registries and physical fingerprints. It cannot call discovery fallback, installer, downloader or SkillBuilder.
