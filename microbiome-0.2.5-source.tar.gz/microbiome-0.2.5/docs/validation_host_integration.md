# 宿主与端口接入验证记录

核对日期：2026 年 9 月 29 日。以下为当前工作区的工程验证，不是 21 类分析流程的真实样本科学验收。

本页保留上一轮宿主接入改造的原始记录。随后完成的全新离线安装、22 份参考、轻量任务及安装包验证见[发行包工程验收记录](packaging_validation.md)。

## 核心流程回归

```bash
pytest -q tests/test_frozen_pipeline.py tests/test_workflow_planning_references.py tests/test_workflow_dependency_installation.py tests/test_portable_integration.py tests/test_planning_context_cache.py tests/test_planning_context_budget.py tests/test_study_compiler_schema.py tests/test_study_compiler_repair.py tests/test_clarification_resume.py tests/test_persistent_workflow.py tests/test_cohort_workflow.py tests/test_agent_planning.py tests/test_harness_planning_prompt.py tests/test_full_refactor_lifecycle.py tests/test_production_input_binding.py tests/test_resource_resolver.py tests/test_resource_evidence_contracts.py tests/test_version_probe.py tests/test_workflow_catalog.py tests/test_host_model_defaults.py tests/test_default_entrypoint.py
```

结果：286 passed，耗时 327.77 秒。覆盖必需的冻结生产测试、流程参考传递与校验、安装范围、输入绑定、跨样本执行、资源契约和默认入口。

## 默认接入与模型隔离

```bash
pytest -q tests/test_endpoint_integration.py tests/test_default_entrypoint.py tests/test_host_model_defaults.py tests/test_cli.py tests/test_path_config.py tests/test_dbroot_datalake.py tests/test_product_installer.py tests/test_llm_ollama.py tests/test_harness_integration.py tests/test_product_models.py
```

结果：87 passed，4 skipped。跳过项来自缺少 `langchain_anthropic` 的旧 Anthropic 兼容测试；本轮未为这些可选测试安装外部依赖。
随后补充原始 endpoint URL 不输出的回归，以及默认升级脚本修正，重跑 `tests/test_host_model_defaults.py` 与 `tests/test_default_entrypoint.py`：22 passed。

最后补充旧 wheel 已有命令文件但入口映射仍旧的情况：安装器先用标准库读取六个 console 入口映射，再运行应用自检；首次安装和升级均测试拒绝旧映射，升级保留原状态与启动入口。最终 `pytest -q tests/test_default_entrypoint.py`：15 passed。实际临时安装的 wheel 也通过这六个映射检查。

## 两类端口

```bash
pytest -q tests/test_endpoint_integration.py tests/test_portable_integration.py
```

结果：18 passed。验证使用本机真实 HTTP 服务与 MCP 协议；模型响应由测试服务提供，没有调用实际付费模型。
覆盖模型发现、默认候选优先、最多三次探测、错误码、禁止继承凭据和代理、实际 A1 持久对话、指定项目绑定、stdio/HTTP MCP、配置导出、审批和冻结作业。

## 安装包

从当前源码的临时副本构建 wheel，在临时 `system-site-packages` venv 内通过 `--no-index --no-deps` 安装。
从工作树外清空 `PYTHONPATH` 运行 15 项 console 检查，全部通过。

- `microbiome`、`biomni`、`microbiome-run` 均映射到 `microbiome.cli:main`。
- 安装位置已核对为临时 venv 的 `site-packages`，未意外导入源码树。
- 默认帮助、自检、目录、MCP/endpoint 帮助及显式 legacy 帮助均通过。
- 自检识别 21 类流程参考、107 个软件 Skill 和 33 个数据库 Skill；模型连接为 `NOT_REQUESTED`，科学运行环境为 `NOT_PROBED`。
- 核对 11 份关键源码与当前工作区逐字节一致。

这项验证复用了现有 Python 依赖，不等于在全新无依赖机器完成在线或离线全量安装。它未安装实际生信软件、下载数据库或改写用户宿主配置。

## 验证边界

不同批次存在重复用例，不能简单相加为独立测试总数。工程测试证明接口和契约的行为，真实科研任务仍需按样本、工具、数据库和统计设计完成各自预检。
尚未把全部宿主 UI 的导入操作、WorkBuddy 各版本 MCP 连接器、远程调度和全部科学流程验收作为本次完成项。
