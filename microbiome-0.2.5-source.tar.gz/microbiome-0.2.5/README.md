# Microbiome：跨宿主微生物分析 Agent

Microbiome 将微生物分析知识、资源管理和可复现执行封装为 **Workflow Catalog + 执行核心 + Skill / MCP / CLI**。
用户在 Codex、WorkBuddy、VS Code 或其他支持工具调用的宿主中对话，宿主负责模型和认证，Microbiome 负责输入解析、方案验证、资源准备、预检、冻结与生产执行。默认安装和启动无需另填模型名称或 API Key。

- [中文手册（历史 0.2.0 Markdown）](docs/Microbiome_Agent_完整使用手册.md) · [历史 0.2.0 Word 手册](docs/Microbiome_Agent_完整使用手册.docx)；最新差异见 [0.2.4](docs/releases/0.2.4.md)
- [跨宿主接入与操作接口](docs/portable_integration.md)
- [分析流程与轻量任务参考目录](docs/workflow_catalog.md)
- [配置说明](docs/configuration.md) · [部署与迁移](docs/DEPLOYMENT.md)
- [发行包安装与自检](docs/packaging.md)
- [0.2.4：规划预算、检查点恢复与资源入口一致性](docs/releases/0.2.4.md)
- [0.2.3：能力握手、数据库受控绑定与结构化修复](docs/releases/0.2.3.md)
- [0.2.2：分页取证与安全恢复规划](docs/releases/0.2.2.md)
- [0.2.1：输入修复、维护工具与阶段文件权限](docs/releases/0.2.1.md)
- [Agent 维护操作与文件范围](docs/agent_maintenance.md)
- [0.2.0：版本统一、绘图接入与固定 ZIP 交付](docs/releases/0.2.0.md)
- [发行包工程验收记录](docs/packaging_validation.md) · [宿主接入验证记录](docs/validation_host_integration.md)
- [冻结生产与恢复](docs/frozen_pipeline.md) · [资源解析规则](docs/resource_skills.md)

## 安装与检查

计算端使用 Linux / WSL 和 Python 3.11+。在本仓库运行：

```bash
bash install.sh
"$HOME/.local/share/microbiome-runtime/bin/microbiome" doctor
```

安装器在用户目录创建专用 Python 环境，验证后生成启动入口，不改动 shell 配置，也不预装科学软件或下载数据库。
可以用 `--prefix /absolute/new/runtime` 指定位置；已有非受管目录会被拒绝，避免覆盖用户环境。
开发者也可自行创建专用 venv，执行 `python -m pip install -e .`。
下方简写命令假定已把安装目录的 `bin/` 加入 PATH；也可始终使用安装器输出的完整命令路径。

普通入口 `microbiome`、`biomni`、`microbiome-run` 现在共用同一个跨宿主 CLI。无参数时显示帮助；安装自检不会连接模型。

```bash
microbiome doctor
microbiome call catalog.list
microbiome export --host codex --output /absolute/new/codex-adapter
```

导出支持 `codex`、`vscode`、`workbuddy`。导出目录须尚不存在；导出不会替换用户的宿主配置。
导出的 Skill 按需读取版本化流程参考。Codex / VS Code 同时生成可合并的 MCP 配置；WorkBuddy 提供可导入的本地 Skill 与统一 CLI，具体 MCP 连接器配置依宿主版本处理。

## 两种端口

**宿主工具端口：** 宿主的现有模型通过 MCP 调用 Microbiome，不向本项目转交模型账户凭据。
默认使用 stdio，也可在本机提供 HTTP MCP：

```bash
microbiome mcp
# 或在另一个终端启动本机 HTTP 服务：
microbiome mcp --transport http --port 8765
microbiome export --host vscode --mcp-url http://127.0.0.1:8765/mcp --output /absolute/new/vscode-adapter
```

**已有模型服务端口：** 明确指定现成的 OpenAI 兼容服务 URL，程序发现模型并进行短响应检查，无需手填模型 ID：

```bash
microbiome endpoint --endpoint http://127.0.0.1:8000 --check
microbiome endpoint --endpoint http://127.0.0.1:8000 --project /work/project
```

模型服务需要提供 `/v1/models` 和 `/v1/chat/completions`。检查会发出少量实际推理请求。
MCP 服务不是模型推理服务，普通聊天窗口也不是可调用的模型端口。
连接只使用显式提供的地址，不扫描端口、不读取宿主私有凭据、不自动回退云服务。
当前直接模型端口适用于无需额外客户端认证的服务；认证由已有宿主处理的场景使用宿主接入方式。

## 简单任务直接执行

检查小型 FASTA/FASTQ 文件的记录数、长度、GC、模糊碱基和双端配对，可直接使用轻量入口，无需模型或创建完整科研项目：

```bash
microbiome stats /data/raw/contigs.fasta --output /work/new-sequence-report
microbiome stats /data/raw/R1.fastq.gz /data/raw/R2.fastq.gz --paired --output /work/new-paired-report
```

也可由宿主调用 MCP 的 `microbiome_sequence_stats`，或 JSON 操作 `sequence.stats`。
输入只读，输出必须是原始输入目录之外的全新目录，父目录须存在。支持 gzip 和折行序列，保存原始文件 SHA256、统计 JSON、执行记录及日志。
GC 分母为 A+C+G+T+U；不推断 Phred 编码。此同步入口限累计 256 MiB 解压内容和 200 万条记录；更大的任务使用经过审阅的分析方案。
损坏文件、缺失本地输入、配对不匹配或输出冲突会明确失败，不会转为下载或覆盖已有结果。

## 能力与流程参考

目录收录完整分析与轻量任务参考，每类包含 `workflow.yaml` 与 `GUIDE.md`，定义输入、分析步骤、适用条件、质量门槛、产物、软件环境与数据库需求。最新数量以 `microbiome doctor` 与 `catalog.list` 为准。

| 分析范围 | 已提供的规划参考 |
| --- | --- |
| 细菌/古菌宏基因组 | 基因组分箱 MAG；不分箱 contig；分类与功能；功能注释 |
| 宏转录组 | 联合细菌 MAG；联合真核微生物基因组；病毒表达与识别 |
| 单菌 | 短读长基因组拼接与分析；长读长/混合拼接；RNA 拼接、定量与差异分析 |
| 病毒 | DNA 病毒；RNA 病毒；宏基因组病毒；宏转录组病毒；系统发育 |
| 真菌与宿主关联样本 | 真菌 contig；真菌 MAG；保留共生菌的宿主去除 |
| 比较与扩展 | 细菌/古菌系统发育；比较基因组；扩增子；移动元件与耐药注释 |
| 轻量检查 | FASTA/FASTQ 格式、长度、GC、记录数与双端对应检查 |

“单菌宏转录组”在参考目录中按单菌 RNA-seq 处理；混合微生物群落 RNA 使用宏转录组流程。
参考是分析设计依据，具体分支取决于样本、实验设计、参考完整度和可用资源。
目录收录不等于这些工具已安装，也不等于每个流程已经用真实数据完整验证。

`planning.context` 向宿主模型返回选中流程的完整说明，并持久化文档版本与交付凭据。
方案须逐项声明 `use / adapt / not_applicable`、理由及实际步骤 ID；保存方案时校验先前交付凭据、当前文档版本和已确认输入。
这一契约验证参考确实送入规划接口以及方案是否记录取舍，不能证明模型内部如何思考。

## 从输入到结果

1. **初始化路径与确认输入。** 本地文件/目录/清单优先，逐样本分类；缺失本地文件报本地错误，不推断 SRA 下载。确认后使用持久化清单。
2. **形成分析方案。** 读取参考和服务器资源信息，明确目标、样本分组、生物学重复、统计设计、步骤及交付物。
3. **审查依赖。** 软件、数据库和原始样本获取分开管理；未知资源先发现和验证，再形成明确依赖计划。
4. **准备资源。** 在已批准的 BOOTSTRAP / PRETEST_REPAIR 阶段复用或创建环境；注册通过可执行文件、版本和帮助检查的工具。
5. **端到端预检。** 服务作业从已确认清单覆盖每个样本，确定性抽取 5%–10% 的数据，检查输入输出、命令与完整流程。直接端口对话沿用已审查的预检范围，默认按类型和组别选择代表样本；跨样本分析保留全部样本。
6. **冻结。** 固定工具、环境前缀、数据库运行入口、指纹、参数和 DAG，并记录就绪状态。
7. **生产执行。** 经生产确认后，对完整数据重放已验证锁；不调用规划器、不安装、不下载、不改变科学参数。
8. **结果与恢复。** 保存日志、输出验证、检查点及批次报告。使用持久化 job ID 查询或取消任务；生产恢复沿用同一运行标识和冻结约束。

```bash
microbiome init --project /work/project --raw-data /data/reads --database /data/databases --output /work/results
microbiome call input.resolve --json '{"project":"/work/project","declaration":"/data/reads/sample_list.txt"}'
microbiome call project.inspect --json '{"project":"/work/project"}'
```

MCP 与 CLI 共用版本化操作；MCP 提供审阅材料，实际批准由用户在交互终端记录，且绑定当前材料的指纹。
宿主应先展示具体方案与资源需求，再引导相应批准，不能用工具调用冒充用户确认。
完整字段、审批命令与 job 示例见[接入说明](docs/portable_integration.md)。

## 服务器软件与数据库管理

软件解析依次参考冻结锁、验证过的注册表、已有 Skill、全部现存 Conda 环境、PATH/项目软件目录和 Conda 元数据，最后才考虑已批准安装。
逻辑工具名、软件家族、包名、可执行文件名、环境名和 Skill ID 分开记录；生产调用保存的真实环境和启动方式，不依赖临时 `conda activate`。

每项资源维护三层记录：Registry 保存位置与版本，Skill 保存用途和用法，Knowledge 保存成功调用、安装配方、失败与修复经验。
只安装当前批准依赖计划的内容，不装入 `base/root`，不覆盖健康用户环境。新增依赖会形成新计划版本。

数据库、参考与索引放入用户指定持久数据库根目录。已 `READY` 资源直接复用；漂移、损坏或缺失会停止执行并要求独立维护，禁止在生产中自动更新或修复。

## 开发、验证与兼容

当前发行构建器为 `scripts/build_portable_release.py`，默认生成到 `packaged/` 下的新版本目录：

```bash
bash scripts/package.sh
# 有匹配本机 Python/平台的依赖缓存时，可生成完全离线安装包：
bash scripts/package.sh --offline-deps --wheel-cache /absolute/wheel-cache --no-index
```

发行包包含安装 wheel、完整运行源码与测试、全部项目 Skill、流程说明、宿主模板、文档、文件清单与校验和。真实样本、数据库、用户环境和账户凭据不属于发布内容。
离线依赖限定构建机器的 Python 次版本、操作系统与架构；不同平台可从源码重新构建。安装后可以运行 `examples/portable_demo/run_demo.py`，或用 `scripts/verify_portable_release.py` 复现新环境检查。

```bash
pytest -q tests/test_frozen_pipeline.py
pytest -q tests/test_workflow_catalog.py tests/test_workflow_planning_references.py
pytest -q tests/test_portable_integration.py tests/test_host_model_defaults.py
```

代码主要位于 `microbiome/pipeline/`、`microbiome/workflows/`、`microbiome/resource_skills/`、`microbiome/integrations/` 和 `microbiome/agent/`。
历史 A1 库接口和旧工作台保留兼容入口 `microbiome-legacy-run` / `microbiome-legacy-harness`，不再作为开发主线。
旧模型环境变量仅在显式选择 `MICROBIOME_LEGACY_MODEL_CONFIG=1` 的兼容路径读取；普通入口不要求创建 `.env` 或模型配置。
Python 包目前仍携带兼容 Agent 所需依赖，尚未拆分为最小核心发行包。

历史文档见 [DeepSeek 兼容说明](docs/DeepSeek_Harness_Microbiome_Guide.md)，其中旧入口命令不适用于当前默认安装。
运行引擎和环境管理测试不替代 21 类流程在真实样本上的科学验收，也不代表所有宿主 UI 已完成导入验收。

本项目基于 Biomni 进一步开发，采用 [Apache-2.0 许可证](LICENSE)。贡献方式见 [CONTRIBUTION.md](CONTRIBUTION.md)。
