"""Unified proxy handling so downloads work with AND without a network proxy.

让数据下载在"有网络代理"和"无网络代理"的环境下都能顺利进行：

- ``auto`` 模式（默认）：先探测目标地址能否直连，不通再探测已配置的代理，
  哪种通道可用就用哪种，并把选择在进程内缓存；下载重试时还会在
  直连 ↔ 代理之间自动切换（见 :func:`select_transport` / :func:`alternate_transport`）。
- ``direct`` 模式：强制直连（清空代理变量）。
- ``proxy`` 模式：强制走代理（``MICROBIOME_PROXY`` 显式指定，或沿用系统代理变量）。

``socks://`` 代理会被归一化为可用形式：安装了 PySocks 时 requests 直接使用
``socks5h://``；否则探测同一 host:port 是否同时提供 HTTP 代理（Clash 等工具的
mixed 端口），可用则改用 ``http://`` 形式；都不可用时视为不可用。

环境变量
--------
MICROBIOME_PROXY_MODE      : ``auto`` | ``direct`` | ``proxy``（默认 ``auto``）
MICROBIOME_PROXY           : 显式代理地址，如 ``http://127.0.0.1:7897``（优先于系统变量）
MICROBIOME_PROXY_PROBE_URL : ``auto`` 模式的默认探测目标（默认 NCBI FTP 站点）

本模块不依赖 microbiome 内部其它模块，可被 cli / download_utils / acquisition /
tool 层安全导入。探测函数为模块级私有函数，测试可 monkeypatch 替换。
"""

from __future__ import annotations

import os
import socket
import threading
from urllib.parse import urlparse

_PROXY_ENV_KEYS = (
    "http_proxy",
    "https_proxy",
    "HTTP_PROXY",
    "HTTPS_PROXY",
    "all_proxy",
    "ALL_PROXY",
    "ftp_proxy",
    "FTP_PROXY",
)
_LOCAL_HOSTS = {"localhost", "127.0.0.1", "::1"}
_LOCAL_NO_PROXY = ("localhost", "127.0.0.1", "::1")
_DEFAULT_PROBE_URL = "https://ftp.ncbi.nlm.nih.gov"
_SOCKS_SCHEMES = {"socks", "socks4", "socks4a", "socks5", "socks5h"}

_TCP_TIMEOUT = 2.0
_CONNECT_TIMEOUT = 3.0

# cache: url origin (or "default") -> (mode, proxies)
_CHOICE_CACHE: dict[str, tuple[str, dict | None]] = {}
_CACHE_LOCK = threading.Lock()


# ---------------------------------------------------------------------------
# low-level probes (monkeypatchable in tests)
# ---------------------------------------------------------------------------
def _tcp_probe(host: str, port: int, timeout: float = _TCP_TIMEOUT) -> bool:
    """True when a TCP connection to host:port succeeds quickly."""
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def _probe_url(url: str | None = None) -> str:
    return url or os.environ.get("MICROBIOME_PROXY_PROBE_URL") or _DEFAULT_PROBE_URL


def _get_probe(url: str, proxies: dict | None, timeout: float) -> bool:
    """True when a real HTTP(S) GET round-trip succeeds (any status counts).

    裸 TCP 探测不可靠：有的网络会接受连接后丢包（假连通），必须完成一次真实
    请求才能判定通道可用。stream=True 只取响应头，不下载正文。
    """
    import requests

    session = requests.Session()
    session.trust_env = False
    if proxies:
        session.proxies.update(proxies)
    try:
        with session.get(_probe_url(url), stream=True, timeout=(timeout, timeout)):
            return True
    except Exception:
        return False


def _direct_probe(url: str, timeout: float = _CONNECT_TIMEOUT) -> bool:
    """True when ``url`` answers a real HTTP(S) request over a direct connection."""
    return _get_probe(url, None, timeout)


def _proxy_probe(proxies: dict, url: str, timeout: float = _CONNECT_TIMEOUT) -> bool:
    """True when ``url`` answers a real HTTP(S) request through ``proxies``."""
    return _get_probe(url, proxies, timeout)


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def is_local_url(url: str | None) -> bool:
    """Local URLs (Ollama, test servers ...) must never go through a proxy."""
    if not url:
        return False
    host = urlparse(url).hostname or ""
    return host in _LOCAL_HOSTS or host.endswith(".localhost")


def _socks_requests_supported() -> bool:
    try:
        import socks  # noqa: F401  (PySocks)

        return True
    except ImportError:
        return False


def _socks_httpx_supported() -> bool:
    try:
        import socksio  # noqa: F401

        return True
    except ImportError:
        return False


def _is_socks_url(url: str) -> bool:
    return urlparse(url if "://" in url else f"socks://{url}").scheme in _SOCKS_SCHEMES


def _with_scheme(raw: str, scheme: str) -> str:
    parsed = urlparse(raw if "://" in raw else f"http://{raw}")
    return f"{scheme}://{parsed.netloc or parsed.path}"


def normalize_proxy_url(raw: str | None, *, for_requests: bool = True, probe: bool = True) -> str | None:
    """Normalize a proxy URL into a form the download stack can actually use.

    - ``http``/``https`` 形式原样返回；
    - ``socks*`` 形式：requests 可用（已装 PySocks）时返回 ``socks5h://``；否则探测同
      host:port 的 HTTP CONNECT（Clash mixed 端口），成功则返回 ``http://`` 形式；
    - 无法归一化时：``for_requests=True`` 返回 None（requests 用不了），
      ``for_requests=False`` 返回 ``socks5h://`` 形式（curl/aria2 等子进程仍可用）。
    """
    if not raw:
        return None
    raw = raw.strip()
    if not raw:
        return None
    parsed = urlparse(raw if "://" in raw else f"http://{raw}")
    if parsed.scheme in ("http", "https"):
        return raw
    if parsed.scheme in _SOCKS_SCHEMES:
        if for_requests and _socks_requests_supported():
            return _with_scheme(raw, "socks5h")
        if probe:
            socks = urlparse(raw if "://" in raw else f"socks://{raw}")
            http_form = f"http://{socks.hostname}:{socks.port or 1080}"
            if _proxy_probe({"http": http_form, "https": http_form}, _probe_url()):
                return http_form
        if for_requests:
            return None
        return _with_scheme(raw, "socks5h")
    return raw


def _proxy_mode() -> str:
    mode = (os.environ.get("MICROBIOME_PROXY_MODE") or "auto").strip().lower()
    return mode if mode in ("auto", "direct", "proxy") else "auto"


def _configured_proxy_urls() -> list[str]:
    """Configured proxy URLs in priority order (MICROBIOME_PROXY first, deduped)."""
    urls: list[str] = []
    explicit = os.environ.get("MICROBIOME_PROXY")
    if explicit and explicit.strip():
        urls.append(explicit.strip())
    for key in ("https_proxy", "HTTPS_PROXY", "http_proxy", "HTTP_PROXY", "all_proxy", "ALL_PROXY"):
        value = os.environ.get(key)
        if value and value.strip() and value.strip() not in urls:
            urls.append(value.strip())
    return urls


def configured_proxies(*, for_requests: bool = True, probe: bool = True) -> dict[str, str] | None:
    """Normalized ``requests``-style proxies dict from the environment, or None."""
    for raw in _configured_proxy_urls():
        normalized = normalize_proxy_url(raw, for_requests=for_requests, probe=probe)
        if normalized:
            return {"http": normalized, "https": normalized}
    return None

# ---------------------------------------------------------------------------
# transport selection (auto / direct / proxy) with process-wide caching
# ---------------------------------------------------------------------------
def _cache_key(url: str | None) -> str:
    if not url:
        return "default"
    parsed = urlparse(url)
    if not parsed.hostname:
        return "default"
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    return f"{parsed.scheme}://{parsed.hostname}:{port}"


def select_transport(url: str | None = None, *, force_refresh: bool = False) -> tuple[str, dict | None]:
    """Pick the working transport for ``url``: ``("direct", None)`` or ``("proxy", {...})``.

    auto 模式：本机地址永远直连；未配置代理时直连；否则先探测直连、再探测代理，
    可用的结果按目标 origin 缓存；两者都不通时返回 direct（由调用方重试时轮换通道）。
    """
    if is_local_url(url):
        return "direct", None
    mode = _proxy_mode()
    if mode == "direct":
        return "direct", None
    if mode == "proxy":
        proxies = configured_proxies(for_requests=True)
        return ("proxy", proxies) if proxies else ("direct", None)
    if not _configured_proxy_urls():
        return "direct", None

    key = _cache_key(url)
    with _CACHE_LOCK:
        if not force_refresh and key in _CHOICE_CACHE:
            return _CHOICE_CACHE[key]

    target = _probe_url(url)
    if _direct_probe(target):
        choice: tuple[str, dict | None] = ("direct", None)
        definitive = True
    else:
        usable = None
        for raw in _configured_proxy_urls():
            normalized = normalize_proxy_url(raw, for_requests=True, probe=False)
            if not normalized:
                continue
            candidate = {"http": normalized, "https": normalized}
            if _proxy_probe(candidate, target):
                usable = candidate
                break
        choice = ("proxy", usable) if usable else ("direct", None)
        definitive = usable is not None

    if definitive:
        with _CACHE_LOCK:
            _CHOICE_CACHE[key] = choice
    return choice


def alternate_transport(url: str | None, last_mode: str) -> tuple[str, dict | None]:
    """The opposite channel of ``last_mode`` — used to switch on repeated failures."""
    if last_mode == "proxy":
        return "direct", None
    proxies = configured_proxies(for_requests=True, probe=False)
    return ("proxy", proxies) if proxies else ("direct", None)


def remember_transport(url: str | None, transport: tuple[str, dict | None]) -> None:
    """Cache a transport that just succeeded so later downloads reuse it."""
    with _CACHE_LOCK:
        _CHOICE_CACHE[_cache_key(url)] = transport


def transport_plans(url: str | None) -> list[tuple[str, dict | None]]:
    """Ordered transports to try for ``url``: preferred first, then the alternate.

    下载重试按该列表轮换，实现"有代理/无代理都能下"的自动回退。
    本机地址（本地 Ollama、测试服务器等）永远只走直连。
    """
    if is_local_url(url):
        return [("direct", None)]
    primary = select_transport(url)
    alternate = alternate_transport(url, primary[0])
    return [primary, alternate] if alternate != primary else [primary]


# ---------------------------------------------------------------------------
# session / subprocess env builders
# ---------------------------------------------------------------------------
def session_for(url: str | None = None, *, transport: tuple[str, dict | None] | None = None):
    """A ``requests.Session`` pinned to the selected transport (never trusts env).

    trust_env=False 避免被损坏的代理变量（如未装 PySocks 的 socks://）影响；
    代理显式来自 select_transport 的探测结果。
    """
    import requests

    mode, proxies = transport or select_transport(url)
    session = requests.Session()
    session.trust_env = False
    if mode == "proxy" and proxies:
        session.proxies.update(proxies)
    return session


def strip_proxy_env(base_env: dict | None = None) -> dict:
    """Env with every proxy variable removed and no_proxy='*' (force direct)."""
    env = dict(base_env if base_env is not None else os.environ)
    for key in _PROXY_ENV_KEYS:
        env.pop(key, None)
    env["no_proxy"] = "*"
    env["NO_PROXY"] = "*"
    return env


def _proxy_download_env(base_env: dict | None = None) -> dict | None:
    """Env with normalized proxy vars for subprocesses; None when no proxy is configured."""
    proxies = configured_proxies(for_requests=False)
    if not proxies:
        return None
    env = dict(base_env if base_env is not None else os.environ)
    for key in _PROXY_ENV_KEYS:
        env.pop(key, None)
    proxy_url = proxies["https"]
    env["http_proxy"] = proxy_url
    env["https_proxy"] = proxy_url
    env["HTTP_PROXY"] = proxy_url
    env["HTTPS_PROXY"] = proxy_url
    env["all_proxy"] = proxy_url
    env["ALL_PROXY"] = proxy_url
    env["no_proxy"] = ",".join(_LOCAL_NO_PROXY)
    env["NO_PROXY"] = ",".join(_LOCAL_NO_PROXY)
    return env


def download_env(url: str | None = None, base_env: dict | None = None) -> dict:
    """Subprocess env for external downloaders (curl/wget/aria2/prefetch/gget ...).

    - 选中直连：清空全部代理变量并设 ``no_proxy=*``；
    - 选中代理：写入归一化后的 http(s)_proxy（socks 自动转可用形式），
      localhost 永远走直连。
    """
    if is_local_url(url) or _proxy_mode() == "direct":
        return strip_proxy_env(base_env)
    if _proxy_mode() == "auto" and select_transport(url)[0] != "proxy":
        return strip_proxy_env(base_env)
    return _proxy_download_env(base_env) or strip_proxy_env(base_env)


def download_env_plans(url: str | None = None, base_env: dict | None = None) -> list[dict]:
    """Ordered subprocess envs mirroring :func:`transport_plans` for retry rotation.

    与 transport_plans 对齐：首选通道的 env 在前，备选通道（直连↔代理）在后，
    供 run_download_command 等子进程下载在重试时轮换。
    """
    if is_local_url(url) or _proxy_mode() == "direct":
        return [strip_proxy_env(base_env)]
    envs: list[dict] = []
    for mode, _ in transport_plans(url):
        env = _proxy_download_env(base_env) if mode == "proxy" else strip_proxy_env(base_env)
        if env is None:
            continue
        if env not in envs:
            envs.append(env)
    return envs or [strip_proxy_env(base_env)]


def describe_transport(url: str | None = None) -> str:
    """Human-readable summary of the selected transport (for logs)."""
    mode, proxies = select_transport(url)
    if mode == "proxy" and proxies:
        return f"代理 {proxies['https']}"
    return "直连"


# ---------------------------------------------------------------------------
# process startup sanitization (used by the CLI)
# ---------------------------------------------------------------------------
def _ensure_localhost_no_proxy(env: dict) -> None:
    for key in ("no_proxy", "NO_PROXY"):
        existing = env.get(key, "")
        if existing.strip() == "*":
            return
        entries = [e.strip() for e in existing.split(",") if e.strip()]
        merged = list(dict.fromkeys([*entries, *_LOCAL_NO_PROXY]))
        env[key] = ",".join(merged)


def sanitize_process_proxy_env(*, log=None) -> str:
    """Fix the current process env so localhost stays direct and proxies are usable.

    CLI 启动时调用：

    1. localhost/127.0.0.1/::1 加入 no_proxy（本地 Ollama 绝不走代理）；
    2. MICROBIOME_PROXY 显式指定时写入标准代理变量；
    3. socks:// 形式归一化（httpx 未装 socksio 时碰到 socks scheme 会直接崩溃）；
    4. direct 模式清空代理；proxy 模式保留；
    5. auto 模式：代理全部不可达且直连可用时清空代理（修复"残留坏代理"环境），
       代理可达则保留供下载使用。

    Returns a short human-readable summary of the resulting network setup.
    """
    env = os.environ
    mode = _proxy_mode()
    _ensure_localhost_no_proxy(env)

    explicit = env.get("MICROBIOME_PROXY")
    if explicit:
        normalized = normalize_proxy_url(explicit, for_requests=False)
        if normalized:
            for key in ("http_proxy", "https_proxy", "HTTP_PROXY", "HTTPS_PROXY"):
                env[key] = normalized

    # Normalize socks-scheme vars: httpx crashes on them without socksio.
    for key in _PROXY_ENV_KEYS:
        value = env.get(key)
        if not value or not _is_socks_url(value):
            continue
        normalized = normalize_proxy_url(value, for_requests=False)
        if normalized and _is_socks_url(normalized) and not _socks_httpx_supported():
            normalized = normalize_proxy_url(value, for_requests=True)
        if normalized:
            env[key] = normalized
        else:
            env.pop(key, None)

    # Propagate a normalized all_proxy to http(s)_proxy: wget 等工具只读这两个变量。
    if not any(env.get(k) for k in ("http_proxy", "https_proxy", "HTTP_PROXY", "HTTPS_PROXY")):
        fallback = env.get("all_proxy") or env.get("ALL_PROXY")
        if fallback:
            for key in ("http_proxy", "https_proxy", "HTTP_PROXY", "HTTPS_PROXY"):
                env[key] = fallback

    if mode == "direct":
        for key in _PROXY_ENV_KEYS:
            env.pop(key, None)
        env["no_proxy"] = "*"
        env["NO_PROXY"] = "*"
        summary = "direct（已忽略所有代理设置）"
    elif mode == "proxy":
        proxies = configured_proxies(for_requests=False, probe=False)
        summary = f"proxy（{proxies['https']}）" if proxies else "proxy（未配置代理，实际为直连）"
    else:
        raw_urls = _configured_proxy_urls()
        reachable = False
        for raw in raw_urls:
            parsed = urlparse(raw if "://" in raw else f"http://{raw}")
            if parsed.hostname and _tcp_probe(parsed.hostname, parsed.port or 8080):
                reachable = True
                break
        if raw_urls and not reachable and _direct_probe(_DEFAULT_PROBE_URL):
            for key in _PROXY_ENV_KEYS:
                env.pop(key, None)
            env["no_proxy"] = "*"
            env["NO_PROXY"] = "*"
            summary = "auto（检测到代理均不可达而直连可用，已自动切换为直连）"
        elif raw_urls and reachable:
            proxies = configured_proxies(for_requests=False, probe=False)
            summary = f"auto（代理可用：{proxies['https'] if proxies else raw_urls[0]}）"
        elif raw_urls:
            summary = "auto（代理与直连探测均未成功，保留原代理设置，下载时将自动重试切换）"
        else:
            summary = "auto（未配置代理，直连）"

    summary = f"网络模式：{summary}"
    if log:
        log(f"🌐 {summary}")
    return summary

