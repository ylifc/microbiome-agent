"""Deterministic local-first input-source resolution for Microbiome.

This module answers exactly one question: *where do the user's raw sequencing
inputs come from?* It never selects analysis software, downloads reference
databases, designs a pipeline, or transfers SRA runs. It is deliberately
separated from analysis-goal parsing (what the user wants to do) and from
download decisions (whether a remote resource must be fetched).

The invariant enforced here is: **look at what the user already has before
considering any download**. A local sample manifest such as 'sample_list.txt'
is a raw-data source, not an SRA download request. Per-sample classification
supports mixed manifests (95 local FASTQ samples + 2 SRA accessions) without
dragging the whole task into SRA acquisition mode.
"""

from __future__ import annotations

import csv
import gzip
import io
import os
import re
import stat
from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path
from typing import Any

import yaml

from microbiome.path_policy import is_same_or_within, iter_files_pruned

MANIFEST_FILENAMES = {
    "sample_list.txt",
    "samples.tsv",
    "samples.csv",
    "sample_manifest.tsv",
    "sample_manifest.csv",
    "sample_manifest.txt",
    "manifest.txt",
    "manifest.tsv",
    "manifest.csv",
}

FASTQ_SUFFIXES = (".fastq", ".fq", ".fastq.gz", ".fq.gz")
FASTA_SUFFIXES = (".fasta", ".fa", ".fna", ".faa", ".ffn", ".fsa", ".fasta.gz", ".fa.gz")
SEQUENCE_SUFFIXES = (*FASTQ_SUFFIXES, *FASTA_SUFFIXES)

# Strict SRA run accession rule (SRR/ERR/DRR + digits only). This is the ONLY
# pattern that may produce a remote SRA candidate, and only after local files
# have already been ruled out.
SRA_RUN_ACCESSION_RE = re.compile(r"^[SED]RR\d+$", re.IGNORECASE)

# Markdown display escapes that must never leak into a real filesystem path.
_MARKDOWN_ESCAPE_RE = re.compile(r"\\([_*\[\]().#!+\->~])")


def _unescape_markdown(value: str) -> str:
    return _MARKDOWN_ESCAPE_RE.sub(r"\1", value)


def _absolute(value: str) -> Path:
    expanded = os.path.expandvars(os.path.expanduser(str(value).strip()))
    return Path(expanded).resolve()


class SourceType(StrEnum):
    LOCAL_PAIRED_FASTQ = "LOCAL_PAIRED_FASTQ"
    LOCAL_SINGLE_FASTQ = "LOCAL_SINGLE_FASTQ"
    LOCAL_FASTA = "LOCAL_FASTA"
    LOCAL_OTHER = "LOCAL_OTHER"
    REMOTE_SRA_RUN = "REMOTE_SRA_RUN"
    REMOTE_URL = "REMOTE_URL"
    MISSING_LOCAL_FILE = "MISSING_LOCAL_FILE"
    AMBIGUOUS = "AMBIGUOUS"
    UNKNOWN = "UNKNOWN"


LOCAL_SOURCE_TYPES = {
    SourceType.LOCAL_PAIRED_FASTQ,
    SourceType.LOCAL_SINGLE_FASTQ,
    SourceType.LOCAL_FASTA,
    SourceType.LOCAL_OTHER,
}


@dataclass
class PathResolver:
    """Keep raw, normalized, and resolved path values strictly separate.

    'resolved_absolute_path' is the only value downstream code may use for
    filesystem access. 'normalized_from_display_escape' records the one
    permitted fallback: when the exact value does not exist but the value with
    Markdown escapes removed does.
    """

    raw_value: str
    normalized_path: str
    resolved_absolute_path: str
    exists: bool
    normalized_from_display_escape: bool = False

    @property
    def path(self) -> Path:
        return Path(self.resolved_absolute_path)


def resolve_path(raw_value: str | os.PathLike[str]) -> PathResolver:
    """Resolve a user-supplied path without ever reusing display-escaped text.

    The exact value is tested first. Only when it does not exist is a Markdown
    escape removal attempted, and the result is flagged rather than silently
    substituted.
    """
    raw = str(raw_value).strip()
    if not raw:
        return PathResolver(raw, raw, raw, exists=False)
    exact = _absolute(raw)
    if exact.exists():
        return PathResolver(raw, str(exact), str(exact), exists=True)
    unescaped = _unescape_markdown(raw)
    if unescaped != raw:
        candidate = _absolute(unescaped)
        if candidate.exists():
            return PathResolver(
                raw,
                unescaped,
                str(candidate),
                exists=True,
                normalized_from_display_escape=True,
            )
    return PathResolver(raw, str(exact), str(exact), exists=False)


def _existing_relative(value: str, base_dirs: list[Path]) -> Path | None:
    """Resolve a manifest cell value to the first existing file.

    Resolution order: absolute path (including its Markdown-unescaped form),
    then 'manifest_dir / value', then 'raw_data_root / value'. The first
    existing regular file wins, preserving the manifest's relative-path base.
    """
    raw = str(value).strip()
    if not raw:
        return None
    if raw.startswith(("http://", "https://", "ftp://")):
        return None
    if Path(raw).is_absolute():
        resolved = resolve_path(raw)
        if resolved.exists and resolved.path.is_file():
            return resolved.path
        return None
    for base in base_dirs:
        resolved = resolve_path(str(base / raw))
        if resolved.exists and resolved.path.is_file():
            return resolved.path
    return None


# ---------------------------------------------------------------------------
# Sample manifest parsing
# ---------------------------------------------------------------------------

SAMPLE_ID_HEADERS = {
    "sample",
    "sample_id",
    "sampleid",
    "sample_name",
    "sample_names",
    "id",
    "name",
}

R1_HEADERS = {
    "r1",
    "read1",
    "read_1",
    "reads_1",
    "forward",
    "fastq1",
    "fastq_1",
    "read1_fastq",
    "read_1_fastq",
    "r1_fastq",
    "forward_fastq",
    "fastq_r1",
}

R2_HEADERS = {
    "r2",
    "read2",
    "read_2",
    "reads_2",
    "reverse",
    "fastq2",
    "fastq_2",
    "read2_fastq",
    "read_2_fastq",
    "r2_fastq",
    "reverse_fastq",
    "fastq_r2",
}

FASTA_HEADERS = {"fasta", "fa", "fna", "faa", "fasta_path", "reference", "genome"}


def _normalize_header(token: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", token.strip().lower()).strip("_")


def _looks_like_r1(norm: str) -> bool:
    return bool(
        "read1" in norm
        or "read_1" in norm
        or "forward" in norm
        or "fastq1" in norm
        or "fastq_1" in norm
        or re.search(r"(?:^|_)r1(?:$|_)", norm)
        or norm.endswith("_1")
    )


def _looks_like_r2(norm: str) -> bool:
    return bool(
        "read2" in norm
        or "read_2" in norm
        or "reverse" in norm
        or "fastq2" in norm
        or "fastq_2" in norm
        or re.search(r"(?:^|_)r2(?:$|_)", norm)
        or norm.endswith("_2")
    )


def _classify_header(token: str) -> str | None:
    """Map a header token to a column role: sample_id | r1 | r2 | fasta | None."""
    norm = _normalize_header(token)
    if not norm:
        return None
    if norm in SAMPLE_ID_HEADERS:
        return "sample_id"
    if norm in R1_HEADERS:
        return "r1"
    if norm in R2_HEADERS:
        return "r2"
    if norm in FASTA_HEADERS:
        return "fasta"
    # Mate tokens are strong signals and must be checked before generic
    # sample/name/id fallbacks, so headers like 'sample_list_R1' map to R1
    # rather than being swallowed by the 'sample' keyword.
    if _looks_like_r1(norm):
        return "r1"
    if _looks_like_r2(norm):
        return "r2"
    if any(key in norm for key in ("sample", "sampleid", "id", "name")):
        return "sample_id"
    return None


def _is_sequence_cell(value: str) -> bool:
    lowered = value.strip().lower()
    return any(lowered.endswith(suffix) for suffix in SEQUENCE_SUFFIXES) or lowered.startswith(
        ("http://", "https://", "ftp://")
    )


@dataclass
class SampleManifest:
    path: Path
    format: str
    delimiter: str | None
    header: list[str] | None
    rows: list[list[str]]
    sample_id_column: int | None = None
    r1_column: int | None = None
    r2_column: int | None = None
    fasta_column: int | None = None

    def sample_count(self) -> int:
        return len(self.rows)


class SampleManifestParser:
    """Parse sample_list.txt / samples.tsv / samples.csv / manifest.txt.

    Never treats these files as SRA accession lists. Detects delimiter
    (TSV/CSV/whitespace), skips blank lines and '#' comments, and maps headers
    through a case-insensitive alias table.
    """

    def __init__(self, path: str | Path):
        self.path = Path(path)

    def parse(self) -> SampleManifest:
        if not self.path.is_file():
            raise FileNotFoundError(f"sample manifest not found: {self.path}")
        text = self.path.read_text(encoding="utf-8", errors="replace")
        lines = [line.strip() for line in text.splitlines() if line.strip() and not line.lstrip().startswith("#")]
        if not lines:
            raise ValueError(f"sample manifest is empty: {self.path}")

        delimiter = self._detect_delimiter(lines)
        rows = [self._split(line, delimiter) for line in lines]
        rows = [row for row in rows if any(cell.strip() for cell in row)]
        if not rows:
            raise ValueError(f"sample manifest has no data rows: {self.path}")

        header = self._detect_header(rows[0])
        data_rows = rows[1:] if header is not None else rows
        manifest = SampleManifest(
            path=self.path,
            format=self._format_name(delimiter),
            delimiter=delimiter,
            header=header,
            rows=data_rows,
        )
        self._map_columns(manifest)
        return manifest

    @staticmethod
    def _detect_delimiter(lines: list[str]) -> str | None:
        for line in lines[:10]:
            if "\t" in line:
                return "\t"
            if "," in line:
                return ","
        return None

    @staticmethod
    def _split(line: str, delimiter: str | None) -> list[str]:
        if delimiter is not None:
            return next(csv.reader(io.StringIO(line), delimiter=delimiter))
        return line.split()

    @staticmethod
    def _format_name(delimiter: str | None) -> str:
        if delimiter == "\t":
            return "tsv"
        if delimiter == ",":
            return "csv"
        return "whitespace"

    @staticmethod
    def _detect_header(row: list[str]) -> list[str] | None:
        roles = [_classify_header(cell) for cell in row]
        if not any(role is not None for role in roles):
            return None
        # A data row always carries file-ish cells in its R1/R2 slots.
        if any(_is_sequence_cell(cell) for cell in row):
            return None
        return row

    @staticmethod
    def _map_columns(manifest: SampleManifest) -> None:
        if manifest.header is not None:
            for index, token in enumerate(manifest.header):
                role = _classify_header(token)
                if role == "sample_id" and manifest.sample_id_column is None:
                    manifest.sample_id_column = index
                elif role == "r1" and manifest.r1_column is None:
                    manifest.r1_column = index
                elif role == "r2" and manifest.r2_column is None:
                    manifest.r2_column = index
                elif role == "fasta" and manifest.fasta_column is None:
                    manifest.fasta_column = index
            return
        width = max((len(row) for row in manifest.rows), default=0)
        if width >= 3:
            manifest.sample_id_column = 0
            manifest.r1_column = 1
            manifest.r2_column = 2
        elif width == 2:
            manifest.r1_column = 0
            manifest.r2_column = 1
        elif width == 1:
            manifest.sample_id_column = 0


def is_sra_run_accession(value: str) -> bool:
    return bool(SRA_RUN_ACCESSION_RE.fullmatch(str(value).strip()))


# ---------------------------------------------------------------------------
# Input data model
# ---------------------------------------------------------------------------


@dataclass
class SampleInput:
    sample_id: str
    source_type: SourceType
    layout: str | None = None
    r1: str | None = None
    r2: str | None = None
    fasta: str | None = None
    accession: str | None = None
    resolved_paths: list[str] = field(default_factory=list)
    validation_status: str = "PENDING"
    r1_exists: bool = False
    r2_exists: bool = False
    readable: bool = True
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "sample_id": self.sample_id,
            "source_type": self.source_type.value,
            "layout": self.layout,
            "r1": self.r1,
            "r2": self.r2,
            "fasta": self.fasta,
            "accession": self.accession,
            "resolved_paths": self.resolved_paths,
            "validation_status": self.validation_status,
            "readable": self.readable,
            "paired": self.layout == "paired_end" and self.r1_exists and self.r2_exists,
            "error": self.error,
        }


@dataclass
class DownloadDecision:
    required: bool = False
    sra_allowed: bool = True
    reason: str = ""


@dataclass
class InputResolutionResult:
    manifest_path: str | None = None
    source_types: set[str] = field(default_factory=set)
    samples: list[SampleInput] = field(default_factory=list)
    unresolved: list[dict[str, Any]] = field(default_factory=list)
    requires_download: bool = False
    overall_source: str = "UNKNOWN"
    raw_data_root: str = ""
    layout: str | None = None
    manifest_format: str | None = None

    @property
    def has_usable_local_data(self) -> bool:
        return any(sample.source_type in LOCAL_SOURCE_TYPES and not sample.error for sample in self.samples)

    @property
    def errors(self) -> list[str]:
        return [str(item.get("reason", "unresolved input")) for item in self.unresolved] + [
            f"{sample.sample_id}: {sample.error or sample.validation_status}"
            for sample in self.samples
            if sample.error or sample.source_type in {SourceType.AMBIGUOUS, SourceType.MISSING_LOCAL_FILE}
        ]

    @property
    def has_remote_sra(self) -> bool:
        return any(sample.source_type is SourceType.REMOTE_SRA_RUN for sample in self.samples)

    @property
    def is_ambiguous(self) -> bool:
        return any(sample.source_type is SourceType.AMBIGUOUS for sample in self.samples)

    @property
    def local_sample_count(self) -> int:
        return sum(1 for sample in self.samples if sample.source_type in LOCAL_SOURCE_TYPES)

    @property
    def remote_sample_count(self) -> int:
        return sum(1 for sample in self.samples if sample.source_type in {SourceType.REMOTE_SRA_RUN, SourceType.REMOTE_URL})

    def local_paired_r1_count(self) -> int:
        return sum(
            1
            for sample in self.samples
            if sample.source_type is SourceType.LOCAL_PAIRED_FASTQ and sample.r1_exists
        )

    def local_paired_r2_count(self) -> int:
        return sum(
            1
            for sample in self.samples
            if sample.source_type is SourceType.LOCAL_PAIRED_FASTQ and sample.r2_exists
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "manifest_path": self.manifest_path,
            "source_types": sorted(self.source_types),
            "samples": [sample.to_dict() for sample in self.samples],
            "unresolved": self.unresolved,
            "requires_download": self.requires_download,
            "overall_source": self.overall_source,
            "raw_data_root": self.raw_data_root,
            "layout": self.layout,
        }


# ---------------------------------------------------------------------------
# Local file discovery helpers
# ---------------------------------------------------------------------------


def _is_fastq(path: Path) -> bool:
    return path.name.lower().endswith(FASTQ_SUFFIXES)


def _is_fasta(path: Path) -> bool:
    return path.name.lower().endswith(FASTA_SUFFIXES)


def _is_sequence_file(path: Path) -> bool:
    return _is_fastq(path) or _is_fasta(path)


def _list_sequence_files(
    directory: Path,
    *,
    excluded_roots: tuple[Path, ...] = (),
) -> list[Path]:
    """List sequence files below a declared root, pruning generated trees.

    Traversal is bounded to the declared root and prunes configured exclusions
    before descent, so ``RAW_DATA_PATH/out`` is never treated as raw input.
    """
    if not directory.is_dir():
        return []
    return [
        path
        for path in iter_files_pruned(directory, excluded_roots=excluded_roots, onerror=_raise_input_access_error)
        if _is_sequence_file(path)
    ]


def _raise_input_access_error(error):
    raise error


def _filename_identity(filename: str) -> dict[str, str | None]:
    """Parse the same filename identity for discovery and manifest matching.

    Illumina's sample ordinal, lane, mate and chunk are separate from the
    sample identifier. Multiple files for one mate remain ambiguous: this
    resolver never concatenates lanes or invents a new biological sample.
    """
    base = re.sub(r"\.(?:fastq|fq)(?:\.gz)?$", "", filename, flags=re.IGNORECASE)
    match = re.match(
        r"^(?P<sample_id>.+?)(?:_S(?P<sample_number>\d+))?"
        r"(?:_L(?P<lane>\d{3}))?[._\-]+R(?P<mate>[12])(?:[._\-]+(?P<chunk>\d+))?$",
        base, re.I,
    )
    if match:
        return match.groupdict()
    match = re.match(r"^(?P<sample_id>.+?)[._\-]+(?P<mate>[12])(?:[._\-]+(?P<chunk>\d+))?$", base)
    return {"sample_id": match.group("sample_id") if match else base,
            "mate": match.group("mate") if match else None,
            "chunk": match.group("chunk") if match else None,
            "sample_number": None, "lane": None}


def _mate_of(sample_id: str, filename: str) -> str | None:
    identity = _filename_identity(filename)
    # Existing manifests may explicitly include the sample/lane suffix in ID.
    base = re.sub(r"\.(?:fastq|fq)(?:\.gz)?$", "", filename, flags=re.I)
    legacy_id = re.sub(r"[._\-]+(?:R)?[12](?:[._\-]+\d+)?$", "", base, flags=re.I)
    return identity["mate"] if sample_id in {identity["sample_id"], legacy_id} else None


def find_local_pairs(
    sample_id: str,
    search_dirs: list[Path],
    *,
    excluded_roots: tuple[Path, ...] = (),
) -> tuple[list[Path], list[Path]]:
    """Return (r1_files, r2_files) matching 'sample_id' in the search roots."""
    r1: list[Path] = []
    r2: list[Path] = []
    for directory in search_dirs:
        for path in _list_sequence_files(directory, excluded_roots=excluded_roots):
            if not _is_fastq(path):
                continue
            mate = _mate_of(sample_id, path.name)
            if mate == "1":
                r1.append(path)
            elif mate == "2":
                r2.append(path)
    r1 = list(dict.fromkeys(path.resolve() for path in r1))
    r2 = list(dict.fromkeys(path.resolve() for path in r2))
    return r1, r2


def _derive_sample_id_from_filename(filename: str) -> str:
    return _filename_identity(filename)["sample_id"] or filename


def _single_file_sample_id(filename: str) -> str:
    """Retain mate-looking suffixes when an entire file is one sample."""
    for suffix in sorted(SEQUENCE_SUFFIXES, key=len, reverse=True):
        if filename.lower().endswith(suffix):
            return filename[:-len(suffix)] or filename
    return filename


def _explicit_layout(message: str) -> str | None:
    """Use the latest affirmative layout declaration in chronological user text."""
    layout = None
    independent = r"每(?:个|份)(?:\s*\.?(?:FASTQ|fq)\s*)?文件(?:是|为|作为|对应)?(?:一|1)个(?:独立)?样本"
    pattern = r"单端|双端|(?<![A-Za-z0-9_./-])(?:single|paired)[ _-]?end(?![A-Za-z0-9_./-])|" + independent
    for match in re.finditer(pattern, message, flags=re.IGNORECASE):
        prefix = message[max(0, match.start() - 20):match.start()]
        if re.search(r"(?:不是|并非|非|不为|没有|不是用|不用|无需|不需要|not(?:\s+a)?|no)\s*$", prefix, flags=re.IGNORECASE):
            continue
        layout = "single_end" if match.group().startswith(("单端", "每")) or match.group().lower().startswith("single") else "paired_end"
    return layout


def _path_role(message: str, start: int, end: int, *, default: str = "raw") -> str:
    """Classify only explicit labels next to a path, never its filename."""
    separators = r"[\n，。；,;]"
    prefix = re.split(separators, message[:start])[-1]
    # A labelled value commonly starts on the following line. Keep only that
    # immediately preceding label, not arbitrary earlier prose or a prior path.
    if not prefix.strip() and not re.search(r"\n\s*\n\s*$", message[:start]):
        previous = message[:start].rstrip().splitlines()
        if previous and not re.search(r"(?:/|~)[^\s]+", previous[-1]):
            prefix = previous[-1]
    suffix = re.split(separators, message[end:])[0]
    # A workspace breadcrumb names a destination/context, not raw data. The
    # host resolves its actual absolute path; the input parser only keeps role.
    if re.search(r"(?:工作区|工作目录|workspace)\s*[>＞]\s*$", prefix, re.I):
        return ("raw" if re.search(r"(?:原始(?:数据|文件|输入)?|输入(?:数据|目录)?|raw(?: data)?|input)\s*(?:位于|在|为|是|[:：=])?\s*(?:当前|本)?(?:工作区|工作目录|workspace)\s*[>＞]\s*$", prefix, re.I)
                else "resource")
    # A preceding path must not supply role words through its directory names.
    prefix = re.sub(r"(?:/|~)[^\s]+", " ", prefix)
    raw = r"原始(?:数据|文件|序列|样本)?|测序(?:文件|数据)|样本(?:文件|清单|数据)|输入(?:文件|路径|目录|数据)?|(?<![A-Za-z0-9_/])(?:raw|input|sample)[ _-]?(?:data|files?|manifest|reads?|path|directory|dir|root)?\b"
    resource = r"参考(?:基因组|序列|数据库|文件|路径|目录)?|数据库(?:路径|目录|文件)?|索引(?:目录|路径|文件)?|输出(?:路径|目录|文件)?|结果(?:路径|目录|文件)|软件(?:路径|目录|环境)|下载(?:路径|目录|缓存)?|知识(?:库|路径|目录)?|项目(?:路径|目录)|(?<![A-Za-z0-9_/])(?:reference|database|db|output|software|conda|results?|download|knowledge|project)(?:[ _-](?:genome|sequence|file|path|root|directory|dir|memory))?(?:[ _-](?:dir|root|path))?\b"
    def affirmative(match):
        return not re.search(r"(?:不是|并非|不作为|不用|无需|不需要|没有|无|not(?:\s+a)?|no)\s*$",
                             prefix[:match.start()], re.I)
    labels = sorted([(m.start(), m.end(), "raw") for m in re.finditer(raw, prefix, re.I) if affirmative(m)]
                    + [(m.start(), m.end(), "resource") for m in re.finditer(resource, prefix, re.I) if affirmative(m)])
    following = re.match(r"\s*(?:作为|用作|是|为)\s*(?:的)?(" + raw + "|" + resource + ")", suffix, re.I)
    if following:
        label = following.group(1)
        return "resource" if re.fullmatch(resource, label, re.I) else "raw"
    if not labels:
        if re.search(r"(?:工作区|工作目录|workspace)\s*[:：=]?\s*$", prefix, re.I):
            return "resource"
        return default
    # Method prose such as "reference-guided assembly" is not a declaration
    # that the following file is a reference. Require a direct label connector.
    connector = r"(?:\s|[:：=\-，]|文件|路径|目录|根目录|是|为|在|位于|请|使用|采用|选用|的是|设置为|设为|存放于|保存在|保存到|以下才是|和|与|及|以及|、|files?|path|directory|is|at|and|use|using)*"
    if not re.fullmatch(connector, prefix[labels[-1][1]:], re.I):
        return default
    if len(labels) > 1 and labels[-1][2] != labels[-2][2] and re.fullmatch(
        r"\s*(?:/|和|与|及|或|、|and|or|&)\s*", prefix[labels[-2][1]:labels[-1][0]], re.I
    ):
        return "ambiguous"
    return labels[-1][2]


def _peek_fastq(path: Path) -> dict[str, Any]:
    opener = gzip.open if path.name.lower().endswith(".gz") else open
    try:
        with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
            record = [handle.readline() for _ in range(4)]
        valid = bool(record) and record[0].startswith("@") and record[2].startswith("+")
        return {"valid": valid, "non_empty": path.stat().st_size > 0}
    except PermissionError:
        raise
    except (OSError, EOFError):
        return {"valid": False, "non_empty": False}


# ---------------------------------------------------------------------------
# The resolver
# ---------------------------------------------------------------------------


class InputSourceResolver:
    """Resolve where each sample's raw sequencing input comes from.

    Responsibilities: identify the input resource, parse manifests, resolve
    paths, check files, classify per-sample source types, and produce a
    machine-readable input manifest. It never selects software, downloads
    reference databases, designs pipelines, or executes SRA transfers.
    """

    def __init__(
        self,
        raw_data_root: str | os.PathLike[str],
        output_root: str | os.PathLike[str] | None = None,
        *,
        database_root: str | os.PathLike[str] | None = None,
        download_root: str | os.PathLike[str] | None = None,
        knowledge_root: str | os.PathLike[str] | None = None,
        project_root: str | os.PathLike[str] | None = None,
        workspace_root: str | os.PathLike[str] | None = None,
    ):
        self.raw_data_root = Path(raw_data_root).expanduser()
        self.output_root = Path(output_root).expanduser() if output_root else None
        self.workspace_root = Path(workspace_root).expanduser().resolve() if workspace_root else None
        raw = self.raw_data_root.resolve()
        self.resource_roots = {
            role: Path(value).expanduser().resolve()
            for role, value in {"output": output_root, "database": database_root,
                                "download": download_root, "knowledge": knowledge_root,
                                "project": project_root}.items() if value
        }
        # A parent project directory is a binding, not an instruction to prune
        # its raw-data child. Dedicated resource children are excluded.
        self.excluded_roots = tuple(root for root in self.resource_roots.values()
                                    if root != raw and not is_same_or_within(raw, root))
        self._configured_excluded_roots = self.excluded_roots

    def _is_excluded(self, path: Path) -> bool:
        return any(is_same_or_within(path, root) for root in self.excluded_roots)

    def resolve(self, user_message: str, *, allow_sra_download: bool = True) -> InputResolutionResult:
        return self.resolve_selection(self.selection_from_message(user_message),
                                      allow_sra_download=allow_sra_download)

    def selection_from_message(self, user_message: str, *, preserve_binding: bool = False) -> dict[str, Any]:
        """Extract one message, preserving roles without historical prose.

        ``automatic`` is a legacy standalone-call default. Conversation state
        instead starts with the project's explicitly bound directory.
        """
        if "用户任务：" in user_message:
            user_message = user_message.rsplit("用户任务：", 1)[-1]
        labelled = self._candidate_records(user_message)
        ignored = []
        if preserve_binding:
            retained = []
            for value, role in labelled:
                if role == "raw" and not self._is_explicit_input_reference(user_message, value):
                    ignored.append({"value": value, "reason": "unclassified path cannot replace the persisted raw-data binding"})
                else:
                    retained.append((value, role))
            labelled = retained
        paths = [value for value, role in labelled if role == "raw"]
        if any(Path(value).suffix.lower() in {".txt", ".tsv", ".csv"} for value in paths):
            mode = "manifest"
        elif any(Path(value).name.lower().endswith(SEQUENCE_SUFFIXES) for value in paths):
            mode = "explicit_files"
        elif paths:
            mode = "directory"
        elif self._extract_accessions(user_message):
            mode = "remote_records"
        else:
            mode = "automatic"
        return {"schema_version": 1, "mode": mode, "paths": paths,
                "resources": [value for value, role in labelled if role == "resource"],
                "ambiguous_paths": [value for value, role in labelled if role == "ambiguous"],
                "ignored_candidates": ignored,
                "layout": _explicit_layout(user_message),
                "remote_ids": self._extract_accessions(user_message)}

    def _is_explicit_input_reference(self, message, value):
        """A bound root, explicit input label or literal file declaration has authority."""
        candidate = Path(value).expanduser()
        candidate = candidate if candidate.is_absolute() else self.raw_data_root / candidate
        if candidate.resolve() == self.raw_data_root.resolve():
            return True
        if self.workspace_root is not None:
            for raw_value, role in self._path_candidate_records(message):
                for occurrence in re.finditer(re.escape(raw_value), message):
                    if (role == "raw" and re.search(r"(?:工作区|工作目录|workspace)\s*[>＞]\s*$",
                            message[:occurrence.start()], re.I)
                            and (self.workspace_root / raw_value.lstrip("/")).resolve() == candidate.resolve()):
                        return True
        for occurrence in re.finditer(re.escape(value), message):
            start, end = occurrence.span()
            if re.search(r"(?:不要|不用|排除|忽略|不是输入|exclude|ignore|not)\s*$", message[max(0, start - 24):start], re.I):
                continue
            quotes = {"`": "`", '"': '"', "'": "'", "“": "”"}
            if start and end < len(message) and message[end] == quotes.get(message[start - 1]):
                start, end = start - 1, end + 1
            if _path_role(message, start, end, default="unspecified") == "raw":
                return True
            if message.strip().strip('`"\'“”') == value:
                return True
            if value.lower().endswith(SEQUENCE_SUFFIXES) or self._is_manifest_name(value):
                return True
        return False

    def _locate_input_file(self, value: str, *, roots: list[Path] | None = None) -> tuple[Path | None, list[Path]]:
        """Resolve inside declared roots only; a nested basename must be unique.

        Explicit absolute and relative paths have exact semantics. Only a bare
        basename is searched recursively, with output/resource trees pruned.
        The process CWD never supplies a similarly named accidental input.
        """
        candidate = Path(value).expanduser()
        roots = roots or [self.raw_data_root]
        # Structured declarations are literal filesystem strings. Try them
        # before legacy display-escape/whitespace normalization.
        exact_candidates = [candidate] if candidate.is_absolute() else [root / candidate for root in roots]
        for exact in exact_candidates:
            try:
                is_file = stat.S_ISREG(exact.stat().st_mode)
            except (FileNotFoundError, NotADirectoryError):
                is_file = False
            if is_file:
                return (exact.resolve(), []) if not self._is_excluded(exact) else (None, [])
        exact = _existing_relative(str(candidate), roots)
        if exact is not None:
            return (exact, []) if not self._is_excluded(exact) else (None, [])
        if candidate.is_absolute() or len(candidate.parts) != 1:
            return None, []
        matches = sorted({path.resolve() for root in roots
                          for path in iter_files_pruned(root, excluded_roots=self.excluded_roots, onerror=_raise_input_access_error)
                          if path.name == value and not self._is_excluded(path)})
        return (matches[0], []) if len(matches) == 1 else (None, matches)

    def selection_from_structure(self, value: dict[str, Any]) -> dict[str, Any]:
        """Validate typed input facts without translating them through prose."""
        from microbiome.pipeline.maintenance_contract import validate_maintenance_request

        value = validate_maintenance_request("repair_input", {"selection": value})["selection"]
        key = next(name for name in ("files", "directories", "manifest", "samples") if name in value)
        paths = list(value[key]) if key in {"files", "directories"} else [value[key]] if key == "manifest" else [
            row[role] for row in value["samples"] for role in ("r1", "r2", "fasta") if role in row]
        rows = value.get("samples", [])
        return {"schema_version": 1, "mode": {"files": "explicit_files", "directories": "directory",
                    "manifest": "manifest", "samples": "structured_samples"}[key],
                "paths": list(dict.fromkeys(paths)), "resources": [], "ambiguous_paths": [],
                "layout": value.get("layout"), "remote_ids": [row["accession"].upper() for row in rows if "accession" in row],
                "sample_records": rows, "structured_source": key}

    def _resolve_structured_samples(self, selection, *, allow_sra_download):
        result = InputResolutionResult(manifest_format="structured")
        layout = selection.get("layout")
        for row in selection["sample_records"]:
            sample_id = row["sample_id"]
            if "accession" in row:
                if allow_sra_download:
                    result.samples.append(SampleInput(sample_id=sample_id,
                        source_type=SourceType.REMOTE_SRA_RUN, accession=row["accession"].upper(),
                        layout=layout, validation_status="PENDING"))
                else:
                    result.unresolved.append({"sample_id": sample_id,
                        "reason": "SRA accession found but SRA acquisition is disabled by the user"})
                continue
            paths, failed = {}, False
            for role in ("r1", "r2", "fasta"):
                if role not in row:
                    continue
                path, alternatives = self._locate_input_file(row[role])
                if path is None:
                    result.unresolved.append({"sample_id": sample_id, "candidate": row[role],
                        "reason": f"ambiguous local basename: {row[role]}; provide an exact path" if alternatives else f"referenced local input not found: {row[role]}",
                        "matching_paths": list(map(str, alternatives))})
                    failed = True
                elif not path.name.lower().endswith(FASTA_SUFFIXES if role == "fasta" else FASTQ_SUFFIXES):
                    result.unresolved.append({"sample_id": sample_id, "candidate": row[role],
                        "reason": f"{role} requires a supported {'FASTA' if role == 'fasta' else 'FASTQ'} filename"})
                    failed = True
                else:
                    paths[role] = path
            if failed:
                continue
            if "fasta" in paths:
                if layout:
                    result.unresolved.append({"sample_id": sample_id, "reason": "FASTQ layout cannot be applied to a FASTA sample"})
                    continue
                result.samples.append(SampleInput(sample_id=sample_id, source_type=SourceType.LOCAL_FASTA,
                    fasta=str(paths["fasta"]), resolved_paths=[str(paths["fasta"])], validation_status="CONFIRMED"))
            elif paths.get("r1") == paths.get("r2"):
                result.unresolved.append({"sample_id": sample_id, "reason": "R1 and R2 must reference different files"})
            elif layout == "single_end" and "r2" in paths:
                result.unresolved.append({"sample_id": sample_id, "reason": "single-end instruction conflicts with explicit R1/R2 sample fields"})
            else:
                result.samples.append(self._sample_from_pair(sample_id, paths["r1"], paths.get("r2")))
        self._check_declared_layout(result, layout)
        self._finalize(result)
        return result

    def resolve_selection(self, selection: dict[str, Any], *, allow_sra_download: bool = True) -> InputResolutionResult:
        """Resolve persisted file facts directly, without parsing them as prose."""
        try:
            return self._resolve_selection(selection, allow_sra_download=allow_sra_download)
        except OSError as error:
            code = "LOCAL_INPUT_ACCESS_DENIED" if isinstance(error, PermissionError) else "LOCAL_INPUT_IO_ERROR"
            result = InputResolutionResult(unresolved=[{"code": code, "candidate": error.filename,
                "reason": f"{code}: {error.strerror or str(error)}", "errno": error.errno}])
            self._finalize(result)
            return result

    def _resolve_selection(self, selection: dict[str, Any], *, allow_sra_download: bool) -> InputResolutionResult:
        layout = selection.get("layout")
        single_end = layout == "single_end"
        labelled = ([(value, "raw") for value in selection.get("paths", [])]
                    + [(value, "resource") for value in selection.get("resources", [])]
                    + [(value, "ambiguous") for value in selection.get("ambiguous_paths", [])])
        ambiguous = [value for value, role in labelled if role == "ambiguous"]
        if ambiguous:
            result = InputResolutionResult(unresolved=[{
                "reason": "local path has conflicting raw-input/resource labels; clarify its role: " + value
            } for value in ambiguous])
            self._finalize(result)
            return result
        resources = []
        for value, role in labelled:
            if role == "resource":
                path = Path(value).expanduser()
                resources.append((path if path.is_absolute() else self.raw_data_root / path).resolve())
        self.excluded_roots = self._configured_excluded_roots + tuple(resources)
        if selection.get("mode") == "structured_samples":
            return self._resolve_structured_samples(selection, allow_sra_download=allow_sra_download)
        candidates = list(selection.get("paths", []))
        directories = []
        for value in candidates:
            candidate = Path(value).expanduser()
            candidate = candidate if candidate.is_absolute() else self.raw_data_root / candidate
            source = selection.get("structured_source")
            if ((source == "directories" and (not candidate.is_dir() or self._is_excluded(candidate)))
                    or (source in {"files", "manifest"} and candidate.is_dir())):
                result = InputResolutionResult(unresolved=[{"candidate": value,
                    "reason": f"declared {source} input has an incompatible path type or resource scope: {value}"}])
                self._finalize(result)
                return result
            if candidate.is_dir() and not self._is_excluded(candidate):
                directories.append(candidate.resolve())
        search_roots = list(dict.fromkeys(directories)) or [Path(value).expanduser()
                        for value in selection.get("search_roots", [])] or [self.raw_data_root]
        located = {}
        for candidate in candidates:
            candidate_path = Path(candidate).expanduser()
            rooted = candidate_path if candidate_path.is_absolute() else self.raw_data_root / candidate_path
            if rooted.resolve() in directories:
                continue
            found, alternatives = self._locate_input_file(candidate, roots=search_roots)
            if found is None:
                reason = (f"ambiguous local basename: {candidate}; provide an exact path" if alternatives
                          else f"referenced local input not found: {candidate}")
                result = InputResolutionResult(unresolved=[{"reason": reason, "candidate": candidate,
                                                            "matching_paths": list(map(str, alternatives))}])
                self._finalize(result)
                return result
            located[candidate] = found
        manifest_paths = [path for value, path in located.items()
                          if Path(value).suffix.lower() in {".txt", ".tsv", ".csv"}]
        if len(set(manifest_paths)) > 1:
            result = InputResolutionResult(unresolved=[{"reason": "multiple explicit manifests; select one manifest",
                                                        "matching_paths": list(map(str, manifest_paths))}])
            self._finalize(result)
            return result
        explicit = list(dict.fromkeys(path for path in located.values() if _is_sequence_file(path)))
        if selection.get("structured_source") == "files" and len(explicit) != len(located):
            result = InputResolutionResult(unresolved=[{"reason": "files must contain only supported FASTQ/FASTA paths; use manifest for a sample table"}])
            self._finalize(result)
            return result
        if selection.get("structured_source") == "manifest" and not manifest_paths:
            result = InputResolutionResult(unresolved=[{"reason": "manifest must reference a supported .txt, .tsv or .csv sample table"}])
            self._finalize(result)
            return result
        if explicit and not manifest_paths:
            result = InputResolutionResult(samples=self._group_raw_files(explicit, single_end=single_end))
            self._check_declared_layout(result, layout)
            self._finalize(result)
            return result
        manifest_path = manifest_paths[0] if manifest_paths else None
        # A selected directory means inventory that directory. Summary/QC
        # tables and historical sample lists are never allowed to take over.
        if manifest_path is None and selection.get("mode") == "automatic":
            manifest_path = self._find_manifest("")
        if manifest_path is not None:
            result = self._resolve_manifest(manifest_path, allow_sra_download=allow_sra_download,
                                            layout=layout)
        else:
            files = list(dict.fromkeys(path for root in search_roots
                         for path in _list_sequence_files(root, excluded_roots=self.excluded_roots)))
            if files:
                result = InputResolutionResult(samples=self._group_raw_files(files, single_end=single_end))
            else:
                result = InputResolutionResult()
                for accession in selection.get("remote_ids", []):
                    if allow_sra_download:
                        result.samples.append(SampleInput(sample_id=accession, source_type=SourceType.REMOTE_SRA_RUN,
                                                          accession=accession, validation_status="PENDING"))
                    else:
                        result.unresolved.append({"sample_id": accession,
                            "reason": "SRA accession found but SRA acquisition is disabled by the user"})
        self._check_declared_layout(result, layout)
        self._finalize(result)
        return result

    @staticmethod
    def _check_declared_layout(result, layout):
        if layout == "paired_end":
            for sample in result.samples:
                if sample.source_type is SourceType.LOCAL_SINGLE_FASTQ:
                    result.unresolved.append({"sample_id": sample.sample_id,
                        "reason": "paired-end instruction requires both R1/R2 files; a mate is missing"})

    def _find_manifest(self, user_message: str) -> Path | None:
        for candidate in self._extract_path_candidates(user_message):
            if not self._is_manifest_name(candidate):
                continue
            resolved, _ = self._locate_input_file(candidate)
            if resolved is not None:
                return resolved
        for name in sorted(MANIFEST_FILENAMES):
            for path in self._manifest_candidates_under_root(name):
                if path.is_file():
                    return path
        return None

    def _manifest_candidates_under_root(self, name: str) -> list[Path]:
        candidates = [self.raw_data_root / name]
        candidates.extend(sorted(self.raw_data_root.glob(f"*/{name}")))
        return [path for path in candidates if not self._is_excluded(path)]

    @staticmethod
    def _is_manifest_name(value: str) -> bool:
        name = Path(value).name.lower()
        if name in MANIFEST_FILENAMES:
            return True
        if name.endswith((".txt", ".tsv", ".csv")) and ("sample" in name or "manifest" in name):
            return True
        return False

    @staticmethod
    def _looks_like_manifest(path: Path) -> bool:
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return False
        for line in text.splitlines():
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            if "\t" in stripped:
                cells = stripped.split("\t")
            elif "," in stripped:
                cells = next(csv.reader(io.StringIO(stripped)), [])
            else:
                cells = stripped.split()
            if any(_classify_header(cell) for cell in cells):
                return True
            return False
        return False

    @staticmethod
    def _path_candidate_records(message: str) -> list[tuple[str, str]]:
        if not message:
            return []
        candidates = []
        absolute_spans = []
        quoted_spans = []
        quoted = r"(?P<quote>[`\"'])(?P<path>[^\n]+?)(?P=quote)|“(?P<cn_path>[^\n]+?)”"
        for match in re.finditer(quoted, message):
            token = match.group("path") or match.group("cn_path")
            if not (token.startswith(("/", "~/", "./", "../"))
                    or token.lower().endswith((*SEQUENCE_SUFFIXES, ".txt", ".tsv", ".csv"))):
                continue
            quoted_spans.append((match.start(), match.end()))
            absolute_spans.append((match.start(), match.end()))
            candidates.append((match.start(), match.end(), token,
                               _path_role(message, match.start(), match.end(), default="unspecified")))
        for match in re.finditer(r"(?<![A-Za-z0-9_./])/[^\s，。；：、,;()（）\[\]\"'`“”]+", message):
            if any(start <= match.start() < end for start, end in quoted_spans):
                continue
            # Slashes in ordinary prose (数据库/资源文件, 前/后段) are
            # not absolute paths. A glued value requires a path connector.
            if (match.start() and message[match.start() - 1].isalnum()
                    and not re.search(r"(?:为|是|于|用|在|到)$", message[:match.start()])):
                continue
            token = match.group(0).rstrip("，。；：,.;)")
            if token and len(token) > 1:
                absolute_spans.append((match.start(), match.end()))
                candidates.append((match.start(), match.end(), token,
                                   _path_role(message, match.start(), match.end(), default="unspecified")))
        for match in re.finditer(
            r"[^\s，。；：、,;()（）\[\]\"'`“”]+\.(?:txt|tsv|csv|fastq|fq|fasta|fa|fna|faa|ffn|fsa)(?:\.gz)?",
            message,
            flags=re.IGNORECASE,
        ):
            token = match.group(0).rstrip("，。；：,.;)")
            if token and not any(start <= match.start() < end for start, end in quoted_spans) and not any(match.start() <= start and end <= match.end()
                                 for start, end in absolute_spans):
                candidates.append((match.start(), match.end(), token,
                                   _path_role(message, match.start(), match.end(), default="unspecified")))
        # A later explicit role correction for the same exact path supersedes
        # its earlier label; unrelated source declarations are retained.
        roles = {}
        previous_end, previous_role = 0, "raw"
        for start, end, value, role in sorted(candidates):
            gap = message[previous_end:start]
            if role == "unspecified":
                role = previous_role if (roles and re.fullmatch(r"[\s、,，;；]*", gap)
                                          and not re.search(r"\n\s*\n", gap)) else "raw"
            roles[value] = role
            previous_end, previous_role = end, role
        return list(roles.items())

    def _candidate_records(self, message: str) -> list[tuple[str, str]]:
        """Apply validated path roles ahead of natural-language candidates.

        Only a known bound value may remove adjacent explanatory prose. Existing
        Unicode paths always retain their exact spelling, even when their name
        contains words such as 目录下的数据库.
        """
        records = []
        bindings = [(str(self.raw_data_root.resolve()), "raw")]
        bindings += [(str(root), "resource") for root in self.resource_roots.values()]
        for value, role in self._path_candidate_records(message):
            occurrence = list(re.finditer(re.escape(value), message))
            breadcrumb = (occurrence and re.search(r"(?:工作区|工作目录|workspace)\s*[>＞]\s*$",
                message[:occurrence[-1].start()], re.I))
            if breadcrumb and self.workspace_root is not None:
                resolved_child = (self.workspace_root / value.lstrip("/")).resolve()
                if not resolved_child.is_relative_to(self.workspace_root):
                    records.append((value, "ambiguous"))
                    continue
                value = str(resolved_child)
            path = Path(value).expanduser()
            resolved = (path if path.is_absolute() else self.raw_data_root / path).resolve()
            if not resolved.exists():
                for bound, bound_role in sorted(bindings, key=lambda item: len(item[0]), reverse=True):
                    if value.startswith(bound) and re.fullmatch(
                        r"(?:目录|文件夹|路径)(?:下|中|里)?(?:的)?(?:数据库|数据|文件|原始数据)?", value[len(bound):]
                    ):
                        value, role, resolved = bound, bound_role, Path(bound)
                        break
            if resolved == self.raw_data_root.resolve():
                role = "raw"
            elif any(resolved == root or (is_same_or_within(resolved, root)
                    and not is_same_or_within(self.raw_data_root.resolve(), root))
                    for root in self.resource_roots.values()):
                # Explicitly calling a bound database file "raw" is a role
                # conflict. Never silently select a different raw sample set.
                occurrences = list(re.finditer(re.escape(value), message))
                occurrence = occurrences[-1] if occurrences else None
                explicit_raw = False
                if role == "raw" and occurrence:
                    start, end = occurrence.span()
                    quotes = {"`": "`", '"': '"', "'": "'", "“": "”"}
                    if start and end < len(message) and message[end] == quotes.get(message[start - 1]):
                        start, end = start - 1, end + 1
                    explicit_raw = _path_role(message, start, end, default="unspecified") == "raw"
                role = "ambiguous" if explicit_raw else "resource"
            records.append((value, role))
        return records

    def _extract_path_candidates(self, message: str) -> list[str]:
        return [value for value, role in self._candidate_records(message) if role == "raw"]

    def _resolve_manifest(self, manifest_path: Path, *, allow_sra_download: bool,
                          layout: str | None = None) -> InputResolutionResult:
        manifest_dir = manifest_path.parent
        parsed = SampleManifestParser(manifest_path).parse()
        samples: list[SampleInput] = []
        unresolved: list[dict[str, Any]] = []
        for row in parsed.rows:
            outcome = self._resolve_record(
                parsed,
                row,
                manifest_dir,
                allow_sra_download=allow_sra_download,
            )
            if isinstance(outcome, SampleInput):
                if layout == "single_end" and outcome.source_type is SourceType.LOCAL_PAIRED_FASTQ:
                    if parsed.r2_column is not None:
                        unresolved.append({"sample_id": outcome.sample_id,
                                           "reason": "single-end instruction conflicts with explicit R1/R2 manifest columns"})
                    else:
                        # Only filename-based pairing may be overridden. An
                        # explicit two-column pair remains a conflicting input.
                        samples.extend(self._group_raw_files([Path(outcome.r1), Path(outcome.r2)],
                                                             single_end=True))
                elif layout == "paired_end" and outcome.source_type is SourceType.LOCAL_SINGLE_FASTQ:
                    unresolved.append({"sample_id": outcome.sample_id,
                                       "reason": "paired-end instruction conflicts with a single-file manifest sample; declare both R1/R2 paths"})
                else:
                    samples.append(outcome)
            else:
                unresolved.append(outcome)
        return InputResolutionResult(
            manifest_path=str(manifest_path.resolve()),
            samples=samples,
            unresolved=unresolved,
            manifest_format=parsed.format,
        )

    def _resolve_without_manifest(
        self,
        user_message: str,
        *,
        allow_sra_download: bool,
        single_end: bool = False,
    ) -> InputResolutionResult:
        selection = self.selection_from_message(user_message)
        if selection["mode"] == "automatic":
            selection["mode"] = "directory"
        if single_end:
            selection["layout"] = "single_end"
        return self.resolve_selection(selection, allow_sra_download=allow_sra_download)

    def _explicit_sequence_files(self, message: str) -> list[Path]:
        found: list[Path] = []
        for candidate in self._extract_path_candidates(message):
            name = Path(candidate).name.lower()
            if not (name.endswith(FASTQ_SUFFIXES) or name.endswith(FASTA_SUFFIXES)):
                continue
            resolved, _ = self._locate_input_file(candidate)
            if resolved is not None:
                found.append(resolved)
        return list(dict.fromkeys(path.resolve() for path in found))

    def _pair_explicit_files(self, files: list[Path]) -> dict[str, tuple[Path, Path | None]]:
        pairs: dict[str, tuple[Path, Path | None]] = {}
        for path in files:
            if not _is_fastq(path):
                continue
            sample_id = _derive_sample_id_from_filename(path.name)
            mate = _mate_of(sample_id, path.name)
            r1, r2 = pairs.get(sample_id, (None, None))
            if mate == "1":
                pairs[sample_id] = (path, r2)
            elif mate == "2":
                pairs[sample_id] = (r1, path)
            else:
                pairs.setdefault(sample_id, (path, None))
        return pairs

    def _group_raw_files(self, files: list[Path], *, single_end: bool = False) -> list[SampleInput]:
        if single_end:
            return [self._sample_from_file(path) for path in sorted(files)]
        by_sample: dict[str, dict[str, list[Path]]] = {}
        for path in files:
            if _is_fasta(path):
                sample_id = re.sub(r"\.(?:fasta|fa|fna|faa|ffn|fsa)(?:\.gz)?$", "", path.name, flags=re.IGNORECASE)
                bucket = by_sample.setdefault(sample_id, {"1": [], "2": [], "fasta": []})
                bucket["fasta"].append(path)
                continue
            sample_id = _derive_sample_id_from_filename(path.name)
            mate = _mate_of(sample_id, path.name)
            bucket = by_sample.setdefault(sample_id, {"1": [], "2": [], "fasta": []})
            if mate in {"1", "2"}:
                bucket[mate].append(path)
            else:
                bucket["1"].append(path)
        samples: list[SampleInput] = []
        for sample_id, bucket in sorted(by_sample.items()):
            fasta = bucket.get("fasta") or []
            r1 = bucket.get("1") or []
            r2 = bucket.get("2") or []
            if len(fasta) > 1 or (fasta and (r1 or r2)):
                samples.append(SampleInput(sample_id=sample_id, source_type=SourceType.AMBIGUOUS,
                                           error="multiple sequence inputs share a sample identifier; provide an explicit manifest"))
            elif fasta:
                samples.append(
                    SampleInput(
                        sample_id=sample_id,
                        source_type=SourceType.LOCAL_FASTA,
                        fasta=str(fasta[0].resolve()),
                        resolved_paths=[str(path.resolve()) for path in fasta],
                        validation_status="CONFIRMED",
                    )
                )
            elif len(r1) == 1 and len(r2) == 1:
                samples.append(self._sample_from_pair(sample_id, r1[0], r2[0]))
            elif len(r1) == 1 and not r2:
                samples.append(self._sample_from_pair(sample_id, r1[0], None))
            elif len(r1) > 1 or len(r2) > 1:
                samples.append(
                    SampleInput(
                        sample_id=sample_id,
                        source_type=SourceType.AMBIGUOUS,
                        error=f"{len(r1)} R1 and {len(r2)} R2 candidates",
                    )
                )
            elif r2 and not r1:
                samples.append(SampleInput(sample_id=sample_id, source_type=SourceType.MISSING_LOCAL_FILE,
                                           error="R2 found but R1 is missing"))
        return samples

    def _resolve_record(
        self,
        manifest: SampleManifest,
        row: list[str],
        manifest_dir: Path,
        *,
        allow_sra_download: bool,
    ) -> SampleInput | dict[str, Any]:
        def cell(index: int | None) -> str:
            if index is None or index >= len(row):
                return ""
            return row[index].strip()

        sample_id = cell(manifest.sample_id_column)
        r1_value = cell(manifest.r1_column)
        r2_value = cell(manifest.r2_column)
        fasta_value = cell(manifest.fasta_column)
        base_dirs = [manifest_dir, self.raw_data_root]

        if fasta_value:
            fasta_path = _existing_relative(fasta_value, base_dirs)
            if fasta_path is not None and not self._is_excluded(fasta_path):
                return SampleInput(
                    sample_id=sample_id or _derive_sample_id_from_filename(fasta_path.name),
                    source_type=SourceType.LOCAL_FASTA,
                    fasta=str(fasta_path.resolve()),
                    resolved_paths=[str(fasta_path.resolve())],
                    validation_status="CONFIRMED",
                )
            return {
                "sample_id": sample_id or fasta_value,
                "reason": f"referenced FASTA not found: {fasta_value}",
            }

        if r1_value:
            if r1_value.startswith(("http://", "https://", "ftp://")):
                return SampleInput(
                    sample_id=sample_id or _derive_sample_id_from_filename(r1_value.rsplit("/", 1)[-1]),
                    source_type=SourceType.REMOTE_URL,
                    r1=r1_value,
                    r2=r2_value or None,
                    validation_status="PENDING",
                )
            r1_path = _existing_relative(r1_value, base_dirs)
            r2_path = _existing_relative(r2_value, base_dirs) if r2_value else None
            if r1_path is not None and self._is_excluded(r1_path):
                r1_path = None
            if r2_path is not None and self._is_excluded(r2_path):
                r2_path = None
            if r1_path is None:
                return {
                    "sample_id": sample_id or _derive_sample_id_from_filename(r1_value),
                    "reason": f"referenced local FASTQ not found: {r1_value}",
                }
            if r2_value and r2_path is None:
                return self._incomplete_pair(
                    sample_id or _derive_sample_id_from_filename(r1_value),
                    r1_path,
                    r2_value,
                )
            if r2_path is not None:
                return self._sample_from_pair(
                    sample_id or _derive_sample_id_from_filename(r1_value),
                    r1_path,
                    r2_path,
                )
            return SampleInput(
                sample_id=sample_id or _derive_sample_id_from_filename(r1_value),
                source_type=SourceType.LOCAL_SINGLE_FASTQ,
                r1=str(r1_path.resolve()),
                resolved_paths=[str(r1_path.resolve())],
                r1_exists=True,
                validation_status="CONFIRMED",
            )

        if sample_id:
            # A one-column manifest commonly contains complete filenames,
            # including names ending in _1.fq. Resolve those exact local files
            # before interpreting a bare identifier as a paired sample or SRA.
            if _is_sequence_file(Path(sample_id)) and not sample_id.startswith(("http://", "https://", "ftp://")):
                path = _existing_relative(sample_id, base_dirs)
                if path is not None and not self._is_excluded(path):
                    return self._sample_from_file(path)
                return {"sample_id": sample_id,
                        "reason": f"referenced local sequencing file not found: {sample_id}"}
            r1_files, r2_files = find_local_pairs(
                sample_id,
                base_dirs,
                excluded_roots=self.excluded_roots,
            )
            if len(r1_files) == 1 and len(r2_files) == 1:
                return self._sample_from_pair(sample_id, r1_files[0], r2_files[0])
            if len(r1_files) == 1 and not r2_files:
                return self._sample_from_pair(sample_id, r1_files[0], None)
            if len(r1_files) > 1 or len(r2_files) > 1:
                return SampleInput(
                    sample_id=sample_id,
                    source_type=SourceType.AMBIGUOUS,
                    error=f"found {len(r1_files)} R1 and {len(r2_files)} R2 candidates for {sample_id}",
                )
            if is_sra_run_accession(sample_id):
                if allow_sra_download:
                    return SampleInput(
                        sample_id=sample_id,
                        source_type=SourceType.REMOTE_SRA_RUN,
                        accession=sample_id.upper(),
                        validation_status="PENDING",
                    )
                return {
                    "sample_id": sample_id,
                    "reason": "SRA accession found but SRA acquisition is disabled by the user",
                }
            return {
                "sample_id": sample_id,
                "reason": f"no local FASTQ/FASTA found for {sample_id} and it is not a supported accession",
            }

        return {
            "sample_id": sample_id or "(unknown)",
            "reason": "record contains no sample id, R1/R2 or FASTA value",
        }

    def _sample_from_file(self, path: Path) -> SampleInput:
        sample_id = _single_file_sample_id(path.name)
        if _is_fastq(path):
            return self._sample_from_pair(sample_id, path, None)
        return SampleInput(sample_id=sample_id, source_type=SourceType.LOCAL_FASTA,
                           fasta=str(path.resolve()), resolved_paths=[str(path.resolve())],
                           validation_status="CONFIRMED")

    def _incomplete_pair(self, sample_id: str, r1_path: Path, r2_value: str) -> SampleInput:
        return SampleInput(
            sample_id=sample_id,
            source_type=SourceType.MISSING_LOCAL_FILE,
            layout="paired_end",
            r1=str(r1_path.resolve()),
            r2=r2_value,
            r1_exists=True,
            r2_exists=False,
            resolved_paths=[str(r1_path.resolve())],
            validation_status="INCOMPLETE_PAIR",
            error=f"R1 found but R2 missing: {r2_value}",
        )

    def _sample_from_pair(self, sample_id: str, r1: Path, r2: Path | None) -> SampleInput:
        peek_r1 = _peek_fastq(r1) if r1.is_file() else {"valid": False, "non_empty": False}
        if r2 is None:
            return SampleInput(
                sample_id=sample_id,
                source_type=SourceType.LOCAL_SINGLE_FASTQ,
                layout="single_end",
                r1=str(r1.resolve()),
                resolved_paths=[str(r1.resolve())],
                r1_exists=True,
                readable=peek_r1.get("valid", False) or peek_r1.get("non_empty", False),
                validation_status="CONFIRMED",
            )
        peek_r2 = _peek_fastq(r2) if r2.is_file() else {"valid": False, "non_empty": False}
        paired = r1.is_file() and r2.is_file()
        return SampleInput(
            sample_id=sample_id,
            source_type=SourceType.LOCAL_PAIRED_FASTQ,
            layout="paired_end",
            r1=str(r1.resolve()),
            r2=str(r2.resolve()),
            resolved_paths=[str(r1.resolve()), str(r2.resolve())],
            r1_exists=r1.is_file(),
            r2_exists=r2.is_file(),
            readable=(peek_r1.get("valid", False) or peek_r1.get("non_empty", False))
            and (peek_r2.get("valid", False) or peek_r2.get("non_empty", False)),
            validation_status="CONFIRMED" if paired else "INCOMPLETE_PAIR",
        )

    @staticmethod
    def _extract_accessions(message: str) -> list[str]:
        tokens = [match.group(0) for match in re.finditer(
            r"(?<![A-Za-z0-9_./-])[ESD]RR\d+(?![A-Za-z0-9_./-])", message, re.I)
            if _path_role(message, match.start(), match.end()) == "raw"]
        return list(
            dict.fromkeys(token.upper() for token in tokens if is_sra_run_accession(token))
        )

    def _finalize(self, result: InputResolutionResult) -> None:
        seen = set()
        for sample in result.samples:
            if not sample.sample_id or sample.sample_id in seen:
                result.unresolved.append({"reason": f"missing or duplicate sample identifier: {sample.sample_id}"})
            seen.add(sample.sample_id)
        result.raw_data_root = str(self.raw_data_root.resolve())
        result.source_types = {sample.source_type.value for sample in result.samples}
        remote = result.remote_sample_count
        local = result.local_sample_count
        if local and not remote:
            result.overall_source = "LOCAL"
        elif remote and not local:
            result.overall_source = "REMOTE"
        elif local and remote:
            result.overall_source = "MIXED"
        else:
            result.overall_source = "UNKNOWN"
        result.requires_download = remote > 0
        if result.samples and all(
            sample.source_type is SourceType.LOCAL_PAIRED_FASTQ for sample in result.samples
        ):
            result.layout = "paired_end"
        elif result.samples and all(
            sample.source_type is SourceType.LOCAL_SINGLE_FASTQ for sample in result.samples
        ):
            result.layout = "single_end"

    def to_input_manifest(self, result: InputResolutionResult) -> dict[str, Any]:
        samples_yaml = []
        for sample in result.samples:
            entry: dict[str, Any] = {
                "sample_id": sample.sample_id,
                "source_type": sample.source_type.value,
                "layout": sample.layout,
            }
            if sample.r1 is not None:
                entry["r1"] = {"path": sample.r1, "exists": sample.r1_exists}
            if sample.r2 is not None:
                entry["r2"] = {"path": sample.r2, "exists": sample.r2_exists}
            if sample.fasta is not None:
                entry["fasta"] = {
                    "path": sample.fasta,
                    "exists": bool(sample.fasta and Path(sample.fasta).is_file()),
                }
            if sample.accession is not None:
                entry["accession"] = sample.accession
            entry["validation"] = {
                "readable": sample.readable,
                "paired": sample.layout == "paired_end" and sample.r1_exists and sample.r2_exists,
            }
            samples_yaml.append(entry)

        return {
            "manifest_version": 1,
            "source_manifest": {
                "path": result.manifest_path,
                "format": result.manifest_format,
            },
            "raw_data_root": result.raw_data_root,
            "overall_source": result.overall_source,
            "layout": result.layout,
            "requires_raw_data_download": result.requires_download,
            "samples": samples_yaml,
            "unresolved": result.unresolved,
            "resolution_status": "CONFIRMED"
            if result.has_usable_local_data and not result.errors and not result.requires_download
            else ("PENDING" if result.is_ambiguous or result.has_remote_sra else "INCOMPLETE"),
        }

    def write_input_manifest(self, result: InputResolutionResult) -> str | None:
        if self.output_root is None:
            return None
        requirements_dir = self.output_root / "requirements"
        requirements_dir.mkdir(parents=True, exist_ok=True)
        path = requirements_dir / "input_manifest.yaml"
        payload = self.to_input_manifest(result)
        from microbiome.pipeline.io import object_fingerprint, write_yaml

        payload["manifest_fingerprint"] = object_fingerprint(payload)
        write_yaml(path, payload)
        return str(path)


# ---------------------------------------------------------------------------
# Rendering helpers
# ---------------------------------------------------------------------------


def summarize_resolution(result: InputResolutionResult) -> str:
    """Render a Chinese input-identification summary matching the project spec."""
    lines = ["[microbiome-run] 输入数据识别"]
    if result.manifest_path:
        lines.append(f"已读取本地样本清单：{result.manifest_path}")
    lines.append(f"数据来源：{_source_label(result.overall_source)}")
    lines.append(f"测序类型：{_layout_label(result.layout)}")
    lines.append(f"样本数：{len(result.samples)}")
    local_paired = [
        sample for sample in result.samples if sample.source_type is SourceType.LOCAL_PAIRED_FASTQ
    ]
    if local_paired:
        r1 = result.local_paired_r1_count()
        r2 = result.local_paired_r2_count()
        lines.append(f"已定位本地双端 FASTQ：R1 {r1}/{len(local_paired)}，R2 {r2}/{len(local_paired)}")
    remote = result.remote_sample_count
    if remote:
        lines.append(f"发现 {remote} 个远程 SRA run（需单独确认是否下载）")
    if result.has_usable_local_data and not result.requires_download:
        lines.append("原始数据将直接使用这些本地 FASTQ 文件，不需要下载 SRA 原始测序数据。")
    elif result.has_usable_local_data:
        lines.append("本地样本直接复用；仅为清单中的远程记录申请下载。")
    lines.extend(f"输入错误：{error}" for error in result.errors)
    if result.is_ambiguous:
        ambiguous = [sample.sample_id for sample in result.samples if sample.source_type is SourceType.AMBIGUOUS]
        lines.append(f"以下样本存在多个候选配对，需要确认：{', '.join(ambiguous)}")
    incomplete = [
        sample.sample_id
        for sample in result.samples
        if sample.source_type is SourceType.MISSING_LOCAL_FILE
    ]
    if incomplete:
        lines.append(f"以下样本的本地双端数据不完整：{', '.join(incomplete)}")
    return "\n".join(lines)


def _source_label(source: str) -> str:
    return {
        "LOCAL": "本地文件",
        "REMOTE": "远程 SRA",
        "MIXED": "本地文件 + 远程 SRA 混合",
        "UNKNOWN": "未知",
    }.get(source, source)


def _layout_label(layout: str | None) -> str:
    return {
        "paired_end": "双端 FASTQ",
        "single_end": "单端 FASTQ",
        None: "待确认",
    }.get(layout, layout or "待确认")


def strip_sra_acquisition(text: str) -> str:
    """Remove any SRA acquisition marker or download_sra_runs call from a plan.

    Used when raw input is local (or the user declined SRA) so no downstream
    stage can re-enter the SRA acquisition workflow.
    """
    cleaned = re.sub(
        r"\[MICROBIOME_DATA_ACQUISITION:sra-runs\]",
        "",
        text or "",
        flags=re.IGNORECASE,
    )
    cleaned = re.sub(r"download_sra_runs\s*\(.*?\)", "", cleaned, flags=re.DOTALL)
    cleaned = re.sub(r"\n\s*\n\s*\n+", "\n\n", cleaned)
    return cleaned.strip()


def read_input_manifest(output_root: str | os.PathLike[str]) -> dict[str, Any] | None:
    """Read a persisted input_manifest.yaml if present (single source of truth)."""
    path = Path(output_root).expanduser() / "requirements" / "input_manifest.yaml"
    if not path.is_file():
        return None
    try:
        payload = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError):
        return None
    return payload if isinstance(payload, dict) else None


def inspect_local_input_sources(
    raw_data_root: str | None = None,
    query: str = "",
    output_root: str | None = None,
) -> str:
    """Read-only planner tool: report local sample manifests and FASTQ/FASTA files.

    This is the deterministic counterpart to resolve_sra_accessions: before ever
    reaching for SRA, the planner must look here for what already exists.
    """
    root = Path(
        raw_data_root or os.environ.get("MICROBIOME_DATA_DIR") or os.environ.get("MICROBIOME_DATA_ROOT") or "."
    ).expanduser()
    configured_output = output_root or os.environ.get("MICROBIOME_RESULTS_DIR")
    output = Path(configured_output).expanduser().resolve() if configured_output else None
    exclusions = (output,) if output is not None and is_same_or_within(output, root) else ()
    lowered = (query or "").strip().lower()
    lines = [f"# Local input data under {root}"]
    manifests: list[str] = []
    for name in sorted(MANIFEST_FILENAMES):
        for path in [root / name, *root.glob(f"*/{name}")]:
            if path.is_file() and not any(is_same_or_within(path, item) for item in exclusions):
                manifests.append(str(path))
    if manifests:
        lines.append("sample manifests:")
        lines.extend(f"- {path}" for path in manifests)
    else:
        lines.append("sample manifests: (none found)")
    files = _list_sequence_files(root, excluded_roots=exclusions)
    if files:
        lines.append("sequence files:")
        for path in files[:200]:
            lines.append(f"- {path}")
    else:
        lines.append("sequence files: (none found)")
    if lowered and (manifests or files):
        lines.append("note: filter query was ignored because local files were listed directly")
    return "\n".join(lines)
