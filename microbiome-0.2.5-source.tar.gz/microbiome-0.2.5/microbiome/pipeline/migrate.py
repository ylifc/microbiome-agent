"""One-time recovery for pre-freeze pilot runs (e.g. an old pilot_playbook.md).

Migration never guesses: a Markdown playbook proves no exit codes, so commands
recovered from it are recorded as UNKNOWN/unverified audit entries and can
never enter a lock. Only artifacts that already carry verifiable success
(a fingerprint-valid PASSED validation report) are promoted into the ledger.
The report always names exactly which strict artifacts are still missing.
"""

from __future__ import annotations

import re
from copy import deepcopy
from pathlib import Path
from typing import Any

from microbiome.pipeline.io import canonical_path, read_json, read_yaml
from microbiome.pipeline.ledger import ExecutionLedger, infer_command_facts

_PLAYBOOK_CODE_RE = re.compile(r"```(?:bash|sh|shell|python|r|R)?\s*\n(.*?)```", re.DOTALL)

STRICT_ARTIFACTS = (
    ("project_config.yaml", "project_config.yaml"),
    ("experiment_plan.yaml", "experiment_plan.yaml"),
    ("requirements/requirements.yaml", "requirements/requirements.yaml (confirmed)"),
    ("plans/dependency_gap_report.yaml", "plans/dependency_gap_report.yaml"),
    ("state/bootstrap_report.json", "state/bootstrap_report.json (PASSED)"),
    ("state/database_resolution.json", "state/database_resolution.json (PASSED)"),
)


def _find_validation_report(root: Path) -> Path | None:
    direct = root / "pipeline" / "validation_report.json"
    if direct.is_file():
        return direct
    candidates = root / "state" / "candidates"
    if candidates.is_dir():
        reports = sorted(candidates.glob("*/validation_report.json"))
        for path in reversed(reports):
            try:
                if read_json(path).get("status") == "PASSED":
                    return path
            except (OSError, ValueError):
                continue
    return None


def recover_legacy_pretest(results_root: str | Path) -> dict[str, Any]:
    """Recover machine-readable pre-test state from a legacy results directory.

    Accepts either a strict project root (with ``project_config.yaml``) or a
    plain conversational results directory. Returns a report with ``status``
    RECOVERABLE (strict finalization can run) or INCOMPLETE
    (``artifacts_missing`` names exactly what is absent).
    """
    root = canonical_path(results_root)
    output_root = root
    if (root / "project_config.yaml").is_file():
        try:
            from microbiome.pipeline.project import PipelineProject

            output_root = PipelineProject(root).output_root
        except (OSError, RuntimeError, ValueError, KeyError):
            output_root = root
    ledger = ExecutionLedger(output_root / "pre_test_run" / "pipeline" / "execution_ledger.jsonl")
    present: list[str] = []
    missing: list[str] = []

    artifact_paths = {
        "project_config.yaml": root / "project_config.yaml",
        "experiment_plan.yaml": root / "experiment_plan.yaml",
        "requirements/requirements.yaml": output_root / "requirements" / "requirements.yaml",
        "plans/dependency_gap_report.yaml": output_root / "plans" / "dependency_gap_report.yaml",
        "state/bootstrap_report.json": root / "state" / "bootstrap_report.json",
        "state/database_resolution.json": root / "state" / "database_resolution.json",
    }
    for relative, label in STRICT_ARTIFACTS:
        if artifact_paths[relative].is_file():
            present.append(label)
        else:
            missing.append(label)

    validation_path = _find_validation_report(output_root)
    if validation_path is None:
        validation_path = _find_validation_report(root)
    if validation_path is not None:
        present.append("a PASSED validation_report.json")
    else:
        missing.append("a PASSED validation_report.json")

    requirements_path = output_root / "requirements" / "requirements.yaml"
    if requirements_path.is_file():
        try:
            requirements = read_yaml(requirements_path)
            confirmed = requirements.get("confirmed_fields", {})
            if not all(confirmed.get(topic) is True for topic in ("paths", "input", "dataset", "target", "analysis_goal")):
                missing.append("requirements confirmation (all required topics)")
        except (OSError, ValueError):
            missing.append("requirements/requirements.yaml (readable)")

    records_written = 0
    # Verified facts first: a PASSED validation report proves real executions.
    if validation_path is not None and not ledger.final_successful_attempts():
        report = read_json(validation_path)
        for step in report.get("steps", []):
            executable = step.get("exact_executable_path")
            ledger.record(
                phase="validation",
                source="migration-validation-report",
                step_id=str(step.get("step_id") or "unknown"),
                attempt=int(step.get("source_attempt") or 1),
                status="PASSED",
                tool={
                    "name": Path(str(executable)).name if executable else None,
                    "version": step.get("exact_software_version"),
                    "executable": executable,
                },
                environment={"conda_prefix": step.get("exact_environment"), "conda_env": None},
                command={"kind": "argv", "argv": list(step.get("exact_command_line") or [])},
                inputs=sorted(str(value) for value in (step.get("input_files") or {}).values()),
                outputs=sorted(str(value) for value in (step.get("output_files") or {}).values()),
                database_resources=[
                    {"alias": alias, "path": str(path)}
                    for alias, path in (step.get("exact_database_path") or {}).items()
                ],
                parameters={"declared": deepcopy(step.get("exact_parameters", []))},
                exit_code=step.get("exit_code"),
                output_validation={"passed": True, "detail": "migrated from a PASSED validation report"},
                verified=True,
            )
            records_written += 1

    # Playbook commands are audit-only: no exit code can be verified from text.
    playbook_path = output_root / "pilot_playbook.md"
    if not playbook_path.is_file():
        playbook_path = root / "pilot_playbook.md"
    playbook_commands = 0
    if playbook_path.is_file():
        text = playbook_path.read_text(encoding="utf-8", errors="replace")
        for code in _PLAYBOOK_CODE_RE.findall(text):
            snippet = code.strip()
            if not snippet:
                continue
            facts = infer_command_facts(snippet)
            ledger.record(
                phase="pilot",
                source="migration-playbook",
                step_id=None,
                status="UNKNOWN",
                command={"kind": facts["kind"], "code": snippet[:2000]},
                tool={"name": facts["tool_name"], "version": None, "executable": facts["executable"]},
                environment={"conda_prefix": facts["conda_prefix"], "conda_env": facts["conda_env"]},
                inputs=facts["inputs"],
                outputs=facts["outputs"],
                database_resources=facts["database_resources"],
                verified=False,
            )
            records_written += 1
            playbook_commands += 1

    # Classification: every file above is auto-backfillable metadata. The only
    # blocking question is whether verified successful execution facts exist.
    execution_facts_missing: list[str] = []
    if not ledger.final_successful_attempts():
        execution_facts_missing.append(
            "no verified successful execution records (execution ledger absent or unverifiable)"
        )
    finalizable = not execution_facts_missing
    return {
        "status": "RECOVERABLE" if finalizable else "INCOMPLETE",
        "finalizable": finalizable,
        "root": str(root),
        "ledger_path": str(ledger.path) if records_written or ledger.path.is_file() else None,
        "records_written": records_written,
        "playbook_commands_recorded_unverified": playbook_commands,
        "artifacts_present": present,
        "artifacts_missing": missing,
        "metadata_missing": missing,  # all auto-backfillable; none of these block production
        "execution_facts_missing": execution_facts_missing,
        "note": (
            "Management artifacts are auto-backfilled from verified execution facts and never "
            "block production. Playbook-derived commands stay UNKNOWN/unverified and cannot "
            "enter a pipeline lock; only verified execution records are lock-eligible."
        ),
    }
