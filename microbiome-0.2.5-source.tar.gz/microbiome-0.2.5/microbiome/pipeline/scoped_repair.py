"""Explicit, audited selective repair of a terminated complete-derived pilot.

The legacy same-science continuation contract is deliberately not changed.
This first repair generation keeps biological inputs and DAG dependencies fixed;
only corroborated, unchanged nodes with an unchanged completed closure may reuse
native evidence. Changed/failed nodes and all descendants are rerun.
"""
from __future__ import annotations

import copy
import hashlib
import re
import shutil
from datetime import UTC, datetime
from pathlib import Path

from microbiome.pipeline.commands import render_step
from microbiome.pipeline.continuation import (
    REVIEW_FIELDS, _approved_resources, require_no_other_worker, validate_checkpoint,
    validate_validation_id,
)
from microbiome.pipeline.errors import ConfigurationError
from microbiome.pipeline.io import (
    fast_file_fingerprint, fingerprint_existing_paths, object_fingerprint,
    read_json, read_yaml, write_json, write_yaml,
)


def _require(condition, message):
    if not condition:
        raise ConfigurationError("scoped repair: " + message)


def _sha(path):
    path = Path(path)
    _require(path.is_file() and not path.is_symlink(), "missing or redirected control evidence: " + str(path))
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _verified(value, field):
    return isinstance(value, dict) and value.get(field) == object_fingerprint({k: v for k, v in value.items() if k != field})


def _root(project, validation_id):
    validate_validation_id(validation_id)
    root = project.pretest_dir / validation_id
    _require(root.is_dir() and not root.is_symlink()
             and root.resolve().parent == project.pretest_dir.resolve(), "source validation root is missing or redirected")
    for name in ("pipeline", "input_subset", "outputs", "commands", "checkpoints", "reports", "tmp", "logs", "regression_cases"):
        _require((root / name).is_dir() and not (root / name).is_symlink(), "source control directory is missing or redirected")
    _require(not (root / "scoped_repairs").exists() and not (root / "scoped_repairs").is_symlink()
             and not (root / "continuations").exists() and not (root / "continuations").is_symlink()
             and not list((root / "pipeline").glob("continuation-*.yaml"))
             and not list((root / "pipeline").glob("scoped-repair-*.yaml")),
             "a prior continuation/repair exists; chained or partially published repair is unsupported")
    return root


def _source_job(project, root, source_plan, manifest_path):
    """Bind the original native report to a real terminated portable request."""
    from microbiome.integrations.jobs import _dead_worker_evidence, _request
    report_path = root / "reports" / "validation_report.json"
    report = read_json(report_path)
    _require(_verified(report, "report_fingerprint"), "source report fingerprint invalid")
    _require(report.get("validation_id") == root.name and report.get("validation_root") == str(root)
             and report.get("plan_fingerprint") == source_plan["plan_fingerprint"]
             and report.get("requirements_version") == source_plan["requirements_version"], "source report identity or plan mismatch")
    _require(report.get("status") in {"PASSED", "FAILED"} and report.get("completed_at")
             and report.get("source_mapping") == str(root / "input_subset" / "source_mapping.yaml"), "source report is not terminal")
    _require(report.get("pilot_mode") == "complete_derived_samples"
             and "pretest_fraction" in report and report["pretest_fraction"] is None,
             "source is not a complete-derived pilot")
    _require(not report.get("continuation"), "continued or repaired sources require a separately reviewed extension")
    subset = report.get("representative_subset", {})
    _require(subset.get("mode") == "complete_derived_samples" and subset.get("sampling_performed") is False,
             "source lacks explicit complete-input evidence")
    matches = []
    for result_path in (project.state_dir / "portable" / "jobs").glob("*/result.json"):
        result = read_json(result_path)
        if isinstance(result, dict) and result.get("validation_id") == root.name:
            matches.append(result_path)
    _require(len(matches) == 1, "requires exactly one original terminal portable pretest result")
    directory = matches[0].parent
    _require(not directory.is_symlink() and directory.resolve().parent ==
             (project.state_dir / "portable" / "jobs").resolve(), "source portable job directory redirected")
    request = read_json(directory / "request.json")
    status = read_json(directory / "status.json")
    _require(request.get("operation") == status.get("operation") == "pretest"
             and request.get("project") == str(project.root)
             and request.get("job_id") == status.get("job_id") == directory.name,
             "source job identity/operation mismatch")
    payload = {key: request[key] for key in ("project", "operation", "parameters", "request_id")}
    _require(request.get("request_fingerprint") == object_fingerprint(payload), "source request fingerprint invalid")
    expected_id = hashlib.sha256((str(project.root) + "\0" + request["request_id"]).encode()).hexdigest()[:32]
    _require(directory.name == expected_id, "source job ID does not match request")
    _request("pretest", request["parameters"])
    _require(request["parameters"] == {}, "source must be a native first-generation complete-derived pretest")
    _require(status.get("status") == ("completed" if report["status"] == "PASSED" else "failed"),
             "source job is not the matching natural terminal result")
    _require(read_json(matches[0]) == report, "source portable result differs from the final report")
    _require(request.get("binding", {}).get(str(project.plan_path)) == _sha(root / "pipeline" / "experiment_plan.yaml"),
             "source request does not bind original plan bytes")
    _require(request.get("binding", {}).get(str(manifest_path)) == _sha(manifest_path),
             "confirmed derived manifest differs from original source request")
    # Config phase/updated_at change through normal bootstrap and validation transitions.
    # Preserve the source submission digest; the immutable input manifest, complete
    # scientific plan and exact rendered execution contracts bind scientific paths.
    config_sha = request.get("binding", {}).get(str(project.config_path))
    _require(isinstance(config_sha, str) and re.fullmatch(r"[0-9a-f]{64}", config_sha),
             "source request lacks its original configuration digest")
    process = _dead_worker_evidence(read_json(directory / "process.json"))
    paths = [report_path, root / "pipeline" / "experiment_plan.yaml", matches[0],
             directory / "request.json", directory / "status.json", directory / "process.json"]
    return report, directory, process, {str(path): _sha(path) for path in paths}


def _owned_path(path, outputs):
    raw = Path(path)
    _require(not raw.is_symlink() and raw.resolve().is_relative_to(outputs.resolve()) and raw.resolve() != outputs.resolve(),
             "declared output is redirected or escapes the validation output root")
    for parent in raw.parents:
        if parent == outputs:
            break
        _require(not parent.is_symlink(), "declared output has a redirected parent")
        _require(not parent.exists() or parent.is_dir(), "declared output parent is not a directory")
    return raw.resolve()



def _global_science(plan):
    result = copy.deepcopy({k: v for k, v in plan.items() if k not in REVIEW_FIELDS | {"steps", "deliverables"}})
    # Only these two explicitly enumerated review receipts may be refreshed.
    # Every other nested science field, including other review evidence, is exact.
    design = result.get("scientific_design")
    if design is not None:
        _require(isinstance(design, dict), "scientific_design must be an object")
        review = design.get("review_evidence")
        if review is not None:
            _require(isinstance(review, dict), "scientific review_evidence must be an object")
            for key in ("requirements_sha256", "planning_context_sha256"):
                if key in review:
                    _require(isinstance(review[key], str) and re.fullmatch(r"[0-9a-f]{64}", review[key]),
                             "malformed scientific review receipt: " + key)
                    review.pop(key)
    return result


def audit_scoped_repair(project, validation_id, plan, rendered_by_id, bootstrap, database_report, runtime_inputs):
    """Read-only eligibility audit; inconsistent success evidence never becomes reuse."""
    from microbiome.pipeline.derived import KIND, verify_derived_manifest
    from microbiome.pipeline.cohort import cohort_runtime_inputs
    from microbiome.pipeline.ledger import ExecutionLedger
    from microbiome.pipeline.models import topological_step_ids
    from microbiome.pipeline.scheduler import validate_parallel_paths, live_scheduling
    from microbiome.resource_config import get_config
    from microbiome.pipeline.dependencies import require_bootstrap_approval
    from microbiome.pipeline.state import LifecycleState
    from microbiome.pipeline.validation import _load_phase_report
    require_no_other_worker(project)
    requirements = require_bootstrap_approval(project, plan, allowed_states=(
        LifecycleState.PRETEST_PREPARATION, LifecycleState.PRETEST_REPAIR, LifecycleState.PRETEST_RUNNING))
    _require(read_yaml(project.plan_path) == plan, "target is not the current approved complete plan")
    for filename, value, label in (("bootstrap_report.json", bootstrap, "bootstrap"),
                                  ("database_resolution.json", database_report, "databases")):
        _require(value == _load_phase_report(project.state_dir / filename, plan["plan_fingerprint"],
                 requirements["requirements_version"], label), "target phase evidence differs from current approved report")
    root = _root(project, validation_id)
    source = read_yaml(root / "pipeline" / "experiment_plan.yaml")
    _require(_verified(source, "plan_fingerprint") and _verified(plan, "plan_fingerprint"), "source or target plan fingerprint invalid")
    manifest_path = project.requirements_dir / "input_manifest.yaml"
    manifest = read_yaml(manifest_path)
    _require(manifest.get("input_kind") == KIND, "confirmed immutable derived inputs required")
    verify_derived_manifest(project, manifest)
    _require(plan.get("pilot_mode") == source.get("pilot_mode") == "complete_derived_samples"
             and plan.get("execution_scope") == source.get("execution_scope") == "cohort",
             "both plans must use complete-derived cohort validation")
    _require(runtime_inputs == cohort_runtime_inputs(plan, manifest), "runtime roles differ from confirmed complete inputs")
    report, directory, process, source_hashes = _source_job(project, root, source, manifest_path)
    source_hashes[str(manifest_path)] = _sha(manifest_path)
    # Plan review metadata and output delivery declarations can change, never the cohort/global science.
    _require(_global_science(source) == _global_science(plan), "global scientific scope or sample membership changed")
    mapping_path = root / "input_subset" / "source_mapping.yaml"
    mapping = read_yaml(mapping_path)
    _require(_verified(mapping, "manifest_fingerprint"), "source mapping fingerprint invalid")
    expected = [{"sample_id": m["sample_id"], "source": {role: runtime_inputs[key] for role, key in m["runtime"].items()}}
                for m in plan.get("cohort_members", [])]
    _require(mapping.get("fraction") is None and
             [{"sample_id": m["sample_id"], "source": m["source"]} for m in mapping.get("samples", [])] == expected
             and all(m.get("source") == m.get("subset") for m in mapping.get("samples", [])),
             "source sample artifact mapping differs from confirmed inputs")
    _require(report.get("runtime_input_source") == fingerprint_existing_paths(runtime_inputs),
             "current complete derived input fingerprints differ from source pilot")
    _require(report["representative_subset"].get("manifest_fingerprint") == manifest["manifest_fingerprint"],
             "source representative inputs differ from the confirmed manifest")
    source_hashes[str(mapping_path)] = _sha(mapping_path)
    old_steps = {s["step_id"]: s for s in source["steps"]}
    steps = {s["step_id"]: s for s in plan["steps"]}
    _require(len(old_steps) == len(source["steps"]) and len(steps) == len(plan["steps"])
             and set(old_steps) == set(steps) == set(rendered_by_id), "step membership changed")
    _require(all(old_steps[sid].get("dependencies", []) == s.get("dependencies", []) for sid, s in steps.items()),
             "DAG dependencies changed")
    policy = live_scheduling(plan.get("execution_scheduling"), get_config().snapshot())
    for sid, step in steps.items():
        resources = rendered_by_id[sid]["resources"]
        _require(all(type(resources.get(key)) is int and resources[key] > 0 for key in ("threads", "memory_gb"))
                 and type(resources.get("gpus", 0)) is int and resources.get("gpus", 0) >= 0,
                 "invalid native scheduling resources: " + sid)
        _require(resources["threads"] <= policy["max_total_threads"]
                 and resources["memory_gb"] <= policy["max_total_memory_gb"], "step cannot fit current scheduling budget: " + sid)
        for name, fp in step.get("static_input_fingerprints", {}).items():
            _require(fast_file_fingerprint(step["input"][name]) == fp, "reviewed static input drift: " + sid)
        if step.get("adapter_path"):
            _require(fast_file_fingerprint(step["adapter_path"]) == step.get("adapter_fingerprint"), "reviewed adapter drift: " + sid)
    # This first version requires the old approved tool/database family to remain READY unchanged.
    approval_path = _approved_resources(project, source, bootstrap, database_report)
    target_approval_path = _approved_resources(project, plan, bootstrap, database_report)
    source_hashes[approval_path] = _sha(approval_path)
    source_hashes[target_approval_path] = _sha(target_approval_path)
    for path in (project.plan_path, project.requirements_path,
                 project.plans_dir / "dependency_gap_report.yaml",
                 project.state_dir / "bootstrap_report.json", project.state_dir / "database_resolution.json"):
        source_hashes[str(path)] = _sha(path)
    old_rendered = {sid: render_step(s, bootstrap["tools"][sid], database_report["databases"],
        runtime_inputs=runtime_inputs, run_dir=root / "outputs", temp_dir=root / "tmp", sample_id=report.get("sample_id", "cohort"),
        resource_snapshot=report["resource_snapshot"], project_paths=project.load_config()["paths"])
        for sid, s in old_steps.items()}
    # Native cohort report historically does not carry sample_id; commands are checked below.
    validate_parallel_paths(list(old_steps.values()), old_rendered)
    validate_parallel_paths(list(steps.values()), rendered_by_id)
    changed = {sid for sid in steps if old_steps[sid] != steps[sid]}
    _require(changed, "no reviewed step contract changed; use the strict resume_validation_id interface")
    reports = {r["step_id"]: r for r in report["steps"]}
    _require(len(reports) == len(report["steps"]) and set(reports) <= set(steps), "source report step membership invalid")
    _require(all(r.get("status") in {"PASSED", "FAILED"} for r in reports.values()), "invalid source step status")
    # Re-render every source execution, including invalidated nodes, against the
    # original plan/snapshot. Operational config timestamps may change; scientific
    # paths and execution semantics must still reproduce the recorded baseline.
    for sid, recorded in reports.items():
        rendered = old_rendered[sid]
        _require(recorded.get("exact_command_line") == rendered["command"]
                 and recorded.get("input_files") == rendered["inputs"]
                 and recorded.get("output_files") == rendered["outputs"]
                 and recorded.get("exact_resources") == rendered["resources"]
                 and recorded.get("exact_database_path") == rendered["databases"],
                 "source execution no longer renders from its original scientific configuration: " + sid)
    if report["status"] == "PASSED":
        _require(set(reports) == set(steps) and all(r["status"] == "PASSED" for r in reports.values())
                 and report.get("failed_step") is None, "source PASS contradicts planned step coverage")
    else:
        _require(report.get("failed_step") in reports
                 and reports[report["failed_step"]]["status"] == "FAILED", "source failure lacks its failed native step")
    ledger = ExecutionLedger.for_project(project)
    _require(ledger.path.is_file() and not ledger.path.is_symlink(), "missing or redirected execution ledger")
    source_hashes[str(ledger.path)] = _sha(ledger.path)
    ledger_entries = [e for e in ledger.entries() if e.get("validation_id") == validation_id]
    latest = {e.get("step_id"): e for e in ledger_entries}
    invalidated = {}; adopted = {}
    for sid in topological_step_ids(plan["steps"]):
        step = steps[sid]
        if sid in changed:
            invalidated[sid] = "reviewed step contract changed"
        elif any(dep in invalidated for dep in step.get("dependencies", [])):
            invalidated[sid] = "descendant of changed, failed or incomplete step"
        elif reports.get(sid, {}).get("status") != "PASSED":
            invalidated[sid] = "source step failed or was not completed"
        if sid in invalidated:
            continue
        cp_path = root / "checkpoints" / f"{sid}.json"
        cmd_path = root / "commands" / f"{sid}.command.json"
        _require(cp_path.is_file() and cmd_path.is_file() and not cp_path.is_symlink() and not cmd_path.is_symlink(),
                 "successful source step lacks safe command/checkpoint evidence: " + sid)
        cp, cmd = read_json(cp_path), read_json(cmd_path)
        _require(cp.get("plan_fingerprint") == source["plan_fingerprint"], "non-native checkpoint provenance: " + sid)
        _require(cp.get("step_report") == reports[sid], "checkpoint/report corroboration failed: " + sid)
        entry = latest.get(sid, {})
        _require(entry.get("attempt") == reports[sid].get("source_attempt"), "latest ledger attempt differs from source report: " + sid)
        _require("input_fingerprint" in cp, "scoped repair requires recorded input fingerprints: " + sid)
        rd = rendered_by_id[sid]
        checks = validate_checkpoint(step, cp, cmd, entry, rd, source["plan_fingerprint"])
        _require(reports[sid].get("exact_command_line") == rd["command"]
                 and reports[sid].get("input_files") == rd["inputs"]
                 and reports[sid].get("output_files") == rd["outputs"]
                 and reports[sid].get("exact_resources") == rd["resources"], "source report execution differs from target contract: " + sid)
        owned = [Path(p).resolve() for value in adopted.values() for p in value["rendered"]["outputs"].values()]
        bound = [Path(p).resolve() for p in runtime_inputs.values()]
        bound += [Path(step["input"][k]).resolve() for k in step.get("static_input_fingerprints", {})]
        _require(all(any(Path(p).resolve() == q or q in Path(p).resolve().parents for q in owned + bound)
                     for p in rd["inputs"].values()), "input lacks adopted or immutable provenance: " + sid)
        adopted[sid] = {"command_record": cmd, "assertions": checks, "ledger": entry, "rendered": rd,
            "input_fingerprint_before": fingerprint_existing_paths(rd["inputs"]), "passed": True,
            "source_checkpoint_fingerprint": object_fingerprint(cp), "source_command_fingerprint": object_fingerprint(cmd),
            "source_ledger_fingerprint": object_fingerprint(entry)}
        source_hashes[str(cp_path)] = _sha(cp_path); source_hashes[str(cmd_path)] = _sha(cmd_path)
    _require(adopted, "no unchanged, corroborated completed dependency closure remains")
    from microbiome.visualization.artifacts import owned_review_paths
    protected = [_owned_path(p, root / "outputs") for v in adopted.values()
                 for p in [*v["rendered"]["outputs"].values(), *owned_review_paths(v["rendered"]["outputs"])]]
    archive_outputs = {}
    for sid in invalidated:
        paths = set(old_rendered[sid]["outputs"].values()) | set(rendered_by_id[sid]["outputs"].values())
        paths.update(str(p) for outputs in (old_rendered[sid]["outputs"], rendered_by_id[sid]["outputs"])
                     for p in owned_review_paths(outputs))
        owned_paths = [_owned_path(p, root / "outputs") for p in paths]
        _require(not any(p == q or p in q.parents or q in p.parents for p in owned_paths for q in protected),
                 "repair output/archive ownership overlaps adopted output: " + sid)
        archive_outputs[sid] = sorted(str(p) for p in owned_paths)
    archive_controls = []
    for sid in invalidated:
        for path in [root / "checkpoints" / f"{sid}.json", *(root / "commands").glob(f"{sid}.command.*")]:
            _require(not path.is_symlink(), "invalidated execution evidence redirected")
            if path.exists():
                _require(path.is_file(), "invalidated execution evidence is not a file")
                archive_controls.append(str(path))
                source_hashes[str(path)] = _sha(path)
    all_outputs = {p for values in archive_outputs.values() for p in values}
    archive_output_fingerprints = fingerprint_existing_paths({p: p for p in sorted(all_outputs)})
    return {"mode": "scoped_repair", "validation_id": validation_id, "source_job_id": directory.name,
            "source_plan_fingerprint": source["plan_fingerprint"], "target_plan_fingerprint": plan["plan_fingerprint"],
            "source_plan": source, "source_resource_approval": approval_path, "resource_approval": target_approval_path,
            "source_process_evidence": process, "source_evidence_sha256": source_hashes,
            "changed_steps": sorted(changed), "invalidated_steps": invalidated,
            "archive_outputs": archive_outputs, "archive_controls": sorted(archive_controls),
            "archive_output_fingerprints": archive_output_fingerprints, "adopted": adopted}


def publish_scoped_repair(project, audit, plan, rendered_by_id):
    """Archive every invalidated native fact before replay; preserve successful ancestors."""
    _require(audit.get("mode") == "scoped_repair" and audit["target_plan_fingerprint"] == plan["plan_fingerprint"],
             "publish audit does not match target plan")
    # A second complete read-only audit closes output/ledger/approval/process drift
    # between inspection and publication. Every rejecting check precedes mutation.
    from microbiome.pipeline.cohort import cohort_runtime_inputs
    fresh = audit_scoped_repair(project, audit["validation_id"], plan, rendered_by_id,
        read_json(project.state_dir / "bootstrap_report.json"),
        read_json(project.state_dir / "database_resolution.json"),
        cohort_runtime_inputs(plan, read_yaml(project.requirements_dir / "input_manifest.yaml")))
    for field in ("source_evidence_sha256", "archive_outputs", "archive_controls",
                  "archive_output_fingerprints", "changed_steps", "invalidated_steps", "adopted"):
        _require(fresh[field] == audit[field], "repair evidence changed after audit: " + field)
    root = _root(project, audit["validation_id"])
    for path, digest in audit["source_evidence_sha256"].items():
        _require(_sha(path) == digest, "source evidence changed after repair audit")
    target_snapshot = root / "pipeline" / f"scoped-repair-{plan['plan_fingerprint']}.yaml"
    _require(not target_snapshot.exists() and not target_snapshot.is_symlink(), "target snapshot already exists or is redirected")
    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%S%fZ")
    archive = root / "scoped_repairs" / stamp
    archive.mkdir(parents=True, exist_ok=False)
    journal = {key: value for key, value in audit.items() if key not in {"adopted", "source_plan"}}
    evidence_archive = {path: str(archive / "source_evidence" / (str(index) + "-" + Path(path).name))
                        for index, path in enumerate(audit["source_evidence_sha256"])}
    journal["source_evidence_archive"] = evidence_archive
    journal.update(created_at=datetime.now(UTC).isoformat(), status="PREPARED", source_validation_root=str(root),
        archive=str(archive), reused_steps={sid: {"source_record_id": v["ledger"]["record_id"],
            "source_attempt": v["ledger"]["attempt"], "source_checkpoint_fingerprint": v["source_checkpoint_fingerprint"],
            "source_command_fingerprint": v["source_command_fingerprint"], "source_ledger_fingerprint": v["source_ledger_fingerprint"],
            "assertions": v["assertions"]} for sid, v in audit["adopted"].items()})
    # This prepared record makes partial publication fail closed rather than silently retrying.
    journal["journal_fingerprint"] = object_fingerprint(journal)
    journal_path = archive / "repair.json"; write_json(journal_path, journal)
    for path, destination in evidence_archive.items():
        source, target = Path(path), Path(destination)
        target.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(source, target)
    moved = []
    all_outputs = sorted({Path(p) for values in audit["archive_outputs"].values() for p in values}, key=lambda p: len(p.parts))
    for path in all_outputs:
        if any(parent in path.parents for parent in moved):
            continue
        _owned_path(path, root / "outputs")
        if path.exists():
            destination = archive / "outputs" / path.relative_to(root / "outputs")
            destination.parent.mkdir(parents=True, exist_ok=True)
            was_directory = path.is_dir(); shutil.move(str(path), str(destination)); moved.append(path)
            if was_directory:
                path.mkdir()  # retain existing shells potentially created by unchanged layout ancestors
    for value in audit["archive_controls"]:
        path = Path(value)
        destination = archive / path.relative_to(root)
        destination.parent.mkdir(parents=True, exist_ok=True); shutil.move(str(path), str(destination))
    target_snapshot = root / "pipeline" / f"scoped-repair-{plan['plan_fingerprint']}.yaml"
    write_yaml(target_snapshot, plan)
    journal.update(status="PUBLISHED", target_plan_snapshot=str(target_snapshot), moved_output_paths=[str(p) for p in moved])
    journal["journal_fingerprint"] = object_fingerprint({k: v for k, v in journal.items() if k != "journal_fingerprint"})
    write_json(journal_path, journal)
    return {"mode": "scoped_repair", "journal_path": str(journal_path), "journal_fingerprint": journal["journal_fingerprint"],
            "reused_steps": list(audit["adopted"]), "source_plan_fingerprint": audit["source_plan_fingerprint"],
            "source_job_id": audit["source_job_id"], "invalidated_steps": audit["invalidated_steps"]}
