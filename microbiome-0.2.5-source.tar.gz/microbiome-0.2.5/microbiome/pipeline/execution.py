"""LLM-free preflight, resumable checkpointing, and frozen production replay."""

from __future__ import annotations

import os
import re
import shutil
import subprocess

from microbiome.pipeline.process_file_policy import run_scoped_process
import time
from datetime import UTC, datetime
from fnmatch import fnmatchcase
from pathlib import Path
from typing import TYPE_CHECKING, Any

from microbiome.pipeline.commands import PLACEHOLDER_RE, evaluate_assertions, render_step, run_logged_command
from microbiome.pipeline.diagnostics import failure_record
from microbiome.pipeline.errors import ConfigurationError, ExecutionError, PreflightError, ResourceNotReadyError
from microbiome.pipeline.inputs import ProductionInputResolver
from microbiome.pipeline.io import (
    canonical_path,
    executable_path,
    fingerprint_existing_paths,
    manifest_fingerprint,
    object_fingerprint,
    path_fingerprint,
    read_json,
    read_yaml,
    write_json,
    write_yaml,
)
from microbiome.pipeline.models import FailureCategory, PipelinePhase, topological_step_ids
from microbiome.pipeline.registry import load_database_registry, load_tool_registry
from microbiome.pipeline.resources import database_fingerprint
from microbiome.resource_config import get_config

if TYPE_CHECKING:
    from microbiome.pipeline.project import PipelineProject

RUN_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$")
SAMPLE_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$")


def _utcnow() -> str:
    return datetime.now(UTC).isoformat()


def _verify_manifest(value: dict[str, Any], name: str) -> None:
    expected = manifest_fingerprint(value)
    if value.get("manifest_fingerprint") != expected:
        raise PreflightError(f"{name} fingerprint is invalid")


def _required_runtime_keys(steps: list[dict[str, Any]]) -> set[str]:
    keys: set[str] = set()
    for step in steps:
        values = [*step.get("input", {}).values(), *step.get("output", {}).values(), *step["command_template"]]
        for value in values:
            if not isinstance(value, str):
                continue
            for match in PLACEHOLDER_RE.finditer(value):
                if match.group(1).startswith("runtime."):
                    keys.add(match.group(1).partition(".")[2])
    return keys


def _is_relative_to(path: Path, parent: Path) -> bool:
    try:
        path.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


def _relative_glob_matches(path: Path, pattern: str) -> bool:
    """Match an entire relative path with pathlib-style, component-wise globs."""
    glob = Path(pattern)
    if glob.is_absolute() or ".." in glob.parts:
        return False

    def match(parts: tuple[str, ...], patterns: tuple[str, ...]) -> bool:
        if not patterns:
            return not parts
        if patterns[0] == "**":
            return match(parts, patterns[1:]) or bool(parts and match(parts[1:], patterns))
        return bool(parts and fnmatchcase(parts[0], patterns[0]) and match(parts[1:], patterns[1:]))

    return match(path.parts, glob.parts)


def _verify_run_scoped_paths(step: dict[str, Any], rendered: dict[str, Any], outputs_root: Path) -> None:
    """Re-resolve paths so newly created symlinks cannot escape the run boundary."""
    step_id = step["step_id"]
    for value in rendered.get("outputs", {}).values():
        if not _is_relative_to(canonical_path(value), outputs_root):
            raise PreflightError(f"step {step_id} output escapes the run outputs directory: {value}")
    templates = step.get("input", {})
    run_scoped = {key for key, value in templates.items() if "{run_dir}" in value}
    for _ in templates:
        run_scoped |= {key for key, value in templates.items()
                       if any("{input." + name + "}" in value for name in run_scoped)}
    for name in run_scoped:
        value = rendered["inputs"][name]
        if ".." in Path(templates[name]).parts or not _is_relative_to(canonical_path(value), outputs_root):
            raise PreflightError(f"step {step_id} input escapes its declared run output path: {value}")


def _verify_step_input_ancestry(
    steps: list[dict[str, Any]], rendered_steps: dict[str, dict[str, Any]], outputs_root: Path,
) -> None:
    """Separate real sources from future artifacts of declared DAG ancestors.

    Directory membership is justified by a frozen glob assertion, never by a
    coincidental common path prefix or an output alias that sounds like a folder.
    """
    from microbiome.pipeline.commands import _criterion_parts

    by_id = {step["step_id"]: step for step in steps}
    ordered = topological_step_ids(steps)
    ancestors: dict[str, set[str]] = {}
    for step_id in ordered:
        dependencies = set(by_id[step_id].get("dependencies", []))
        ancestors[step_id] = dependencies | set().union(*(ancestors[item] for item in dependencies))

    produced: dict[Path, set[str]] = {}
    directories: list[tuple[str, Path, str]] = []
    for step_id in ordered:
        rendered = rendered_steps[step_id]
        _verify_run_scoped_paths(by_id[step_id], rendered, outputs_root)
        for value in rendered.get("outputs", {}).values():
            target = canonical_path(value)
            produced.setdefault(target, set()).add(step_id)
        for criterion in by_id[step_id].get("success_assertions", []):
            kind, target, options = _criterion_parts(criterion)
            if kind != "glob_non_empty" or not target.startswith("output."):
                continue
            alias = target.removeprefix("output.")
            if alias in rendered.get("outputs", {}):
                directories.append((step_id, canonical_path(rendered["outputs"][alias]),
                                    str(options.get("pattern") or "*")))

    for step_id in ordered:
        for name, value in rendered_steps[step_id].get("inputs", {}).items():
            path = canonical_path(value)
            inside_run = _is_relative_to(path, outputs_root)
            owners = set(produced.get(path, set()))
            for producer, directory, pattern in directories:
                if path != directory and _is_relative_to(path, directory):
                    if _relative_glob_matches(path.relative_to(directory), pattern):
                        owners.add(producer)
            if len(owners) > 1:
                raise PreflightError(f"step {step_id} input has ambiguous output producers: {path}")
            if owners & ancestors[step_id]:
                continue
            if owners or inside_run:
                raise PreflightError(f"step {step_id} input has no declared ancestor output contract: {path}")
            if not path.exists():
                raise PreflightError(f"step {step_id} source input is missing: {path}")


class FrozenPipelineExecutor:
    """Replay a validated lock. This class has no planner or fallback selector."""

    def __init__(self, project: PipelineProject):
        self.project = project

    def _load_locks(self) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any], dict[str, Any]]:
        paths = (
            self.project.pipeline_lock_path,
            self.project.toolchain_lock_path,
            self.project.database_lock_path,
            self.project.validation_report_path,
        )
        missing = [str(path) for path in paths if not path.is_file()]
        if missing:
            raise PreflightError(f"required frozen artifacts are missing: {', '.join(missing)}")
        pipeline = read_yaml(paths[0])
        toolchain = read_yaml(paths[1])
        databases = read_yaml(paths[2])
        validation = read_json(paths[3])
        _verify_manifest(pipeline, "pipeline lock")
        _verify_manifest(toolchain, "toolchain lock")
        _verify_manifest(databases, "database lock")
        if pipeline.get("validation_status") != "PASSED" or validation.get("status") != "PASSED":
            raise PreflightError("production requires a PASSED validation report")
        if validation.get("report_fingerprint") != object_fingerprint({k: v for k, v in validation.items() if k != "report_fingerprint"}):
            raise PreflightError("validation report fingerprint is invalid")
        if pipeline.get("validation_suite_fingerprint"):
            from microbiome.pipeline.cases import verify_validation_suite
            suite = verify_validation_suite(self.project, {"validation_strategy": "manifest_cases",
                "execution_scope": pipeline.get("execution_scope"), "cohort_members": pipeline.get("cohort_members"),
                "plan_fingerprint": pipeline["plan_fingerprint"], "steps": pipeline["steps"]})
            if suite["suite_fingerprint"] != pipeline["validation_suite_fingerprint"]:
                raise PreflightError("representative validation suite changed after freeze")
        if pipeline.get("validation_report_fingerprint") != validation.get("report_fingerprint"):
            raise PreflightError("validation report does not match pipeline.lock.yaml")
        if pipeline.get("toolchain_lock_fingerprint") != toolchain.get("manifest_fingerprint"):
            raise PreflightError("toolchain.lock.yaml does not match pipeline.lock.yaml")
        if pipeline.get("database_lock_fingerprint") != databases.get("manifest_fingerprint"):
            raise PreflightError("database.lock.yaml does not match pipeline.lock.yaml")
        hash_payload = {
            key: value
            for key, value in pipeline.items()
            if key not in {"pipeline_hash", "pipeline_version", "manifest_fingerprint"}
        }
        if pipeline.get("pipeline_hash") != object_fingerprint(hash_payload):
            raise PreflightError("pipeline hash is invalid")
        return pipeline, toolchain, databases, validation

    def _verify_resource_registries(
        self,
        pipeline: dict[str, Any],
        toolchain: dict[str, Any],
        database_lock: dict[str, Any],
    ) -> dict[str, Any]:
        """Check that frozen resources still match the persistent facts.

        This is deliberately read-only.  A missing, changed, or non-READY
        resource stops production instead of triggering repair or discovery.
        """
        config = self.project.load_config()
        missing_registries = [
            str(path)
            for path in (self.project.database_registry_path, self.project.tool_registry_path)
            if not path.is_file()
        ]
        if missing_registries:
            raise PreflightError(
                "persistent resource registries are missing; rerun bootstrap and database resolution: "
                + ", ".join(missing_registries)
            )
        database_registry = load_database_registry(
            self.project.database_registry_path,
            database_root=config["paths"]["database"],
        )
        tool_registry = load_tool_registry(self.project.tool_registry_path)

        for resource_id, locked in database_lock.get("databases", {}).items():
            registered = database_registry["resources"].get(resource_id)
            if registered is None:
                raise PreflightError(f"database resource is absent from registry: {resource_id}")
            if registered.get("status") != "READY":
                raise PreflightError(
                    f"database resource requires maintenance: {resource_id}={registered.get('status')}"
                )
            if registered.get("read_only") is not True:
                raise PreflightError(f"database resource is not registered read-only: {resource_id}")
            comparisons = {
                "root_path": locked.get("root_path") or locked.get("path"),
                "runtime_entry": locked.get("runtime_entry") or locked.get("path"),
                **(
                    {"consumer_entrypoints": dict(locked.get("consumer_entrypoints") or {})}
                    if "consumer_entrypoints" in locked
                    else {}
                ),
                **({"common_markers": list(locked.get("common_markers") or [])} if "common_markers" in locked else {}),
                **(
                    {"consumer_markers": dict(locked.get("consumer_markers") or {})}
                    if "consumer_markers" in locked
                    else {}
                ),
                "version": str(locked.get("database_version", "UNKNOWN")),
                "marker_files": list(locked.get("expected_marker_files", [])),
                "fingerprint": locked.get("fingerprint"),
            }
            for field in ("validation_contract", "runtime_kind", "runtime_suffix_sets",
                          "consumer_entrypoint_kinds", "consumer_suffix_sets", "bindings"):
                if field in locked:
                    comparisons[field] = locked[field]
            drift = [field for field, expected in comparisons.items() if registered.get(field) != expected]
            if drift:
                raise PreflightError(f"database registry drift for {resource_id}: {', '.join(drift)}")

        steps_by_id = {step["step_id"]: step for step in pipeline.get("steps", [])}
        for step_id, locked in toolchain.get("tools", {}).items():
            registered = tool_registry["tools"].get(step_id)
            if registered is None:
                raise PreflightError(f"tool contract is absent from registry: {step_id}")
            if registered.get("allow_setup_in_production") is not False:
                raise PreflightError(f"tool contract permits production setup: {step_id}")
            if registered.get("allow_db_build_in_production") is not False:
                raise PreflightError(f"tool contract permits production database builds: {step_id}")
            comparisons = {
                "tool_id": locked.get("tool"),
                "conda_prefix": locked.get("environment_prefix"),
                "executable": locked.get("executable"),
                # Older registries omit these additive integrity fields. The
                # frozen lock is still checked against live files below; do not
                # mutate or invalidate an otherwise identical legacy registry.
                **({"executable_fingerprint": locked["executable_fingerprint"]}
                   if locked.get("executable_fingerprint") and "executable_fingerprint" in registered else {}),
                **({"virtual_environment_fingerprint": locked["virtual_environment_fingerprint"]}
                   if locked.get("virtual_environment_fingerprint") and "virtual_environment_fingerprint" in registered else {}),
                "version": locked.get("version_output"),
                "version_args": locked.get("version_args", ["--version"]),
                **({"version_exit_code": locked["version_exit_code"]} if "version_exit_code" in locked else {}),
                **({"runtime_launcher": locked["runtime_launcher"],
                    "runtime_launcher_fingerprint": locked.get("runtime_launcher_fingerprint")}
                   if "runtime_launcher" in locked else {}),
            }
            drift = [field for field, expected in comparisons.items() if registered.get(field) != expected]
            if drift:
                raise PreflightError(f"tool registry drift for {step_id}: {', '.join(drift)}")
            step = steps_by_id[step_id]
            expected_resources = {
                alias: str(spec.get("logical_name") or alias) for alias, spec in step.get("database", {}).items()
            }
            registered_contract = registered.get("database_contract")
            if not expected_resources:
                if registered_contract != "none":
                    raise PreflightError(f"tool database contract drift for {step_id}")
            elif (
                not isinstance(registered_contract, dict)
                or {
                    alias: value.get("resource_id")
                    for alias, value in registered_contract.items()
                    if isinstance(value, dict)
                }
                != expected_resources
            ):
                raise PreflightError(f"tool database contract drift for {step_id}")
        return {
            "database_registry": str(self.project.database_registry_path),
            "database_registry_fingerprint": database_registry["manifest_fingerprint"],
            "tool_registry": str(self.project.tool_registry_path),
            "tool_registry_fingerprint": tool_registry["manifest_fingerprint"],
        }

    @staticmethod
    def _verify_tool(entry: dict[str, Any]) -> dict[str, Any]:
        executable = executable_path(entry["executable"])
        if not executable.is_file() or not os.access(executable, os.X_OK):
            raise PreflightError(f"validated executable is missing or not executable: {executable}")
        prefix = entry.get("environment_prefix")
        if prefix and not canonical_path(prefix).is_dir():
            raise PreflightError(f"validated environment prefix is missing: {prefix}")
        from microbiome.pipeline.io import fast_file_fingerprint
        if entry.get("executable_fingerprint") and fast_file_fingerprint(executable) != entry["executable_fingerprint"]:
            raise PreflightError(f"environment drift: executable fingerprint changed: {executable}")
        if entry.get("virtual_environment_fingerprint"):
            config = canonical_path(prefix) / "pyvenv.cfg" if prefix else None
            if not config or not config.is_file() or fast_file_fingerprint(config) != entry["virtual_environment_fingerprint"]:
                raise PreflightError("environment drift: validated virtual environment configuration changed")
        try:
            from microbiome.pipeline.resources import (
                locked_tool_command, tool_environment, verified_package_probe_version,
            )

            result = run_scoped_process(
                locked_tool_command([str(executable), *entry.get("version_args", ["--version"])], entry),
                env=tool_environment(prefix),
                capture_output=True,
                text=True,
                timeout=30,
                check=False,
                stdin=subprocess.DEVNULL,
            )
        except (OSError, subprocess.TimeoutExpired, ConfigurationError, ResourceNotReadyError) as exc:
            raise PreflightError(f"could not verify executable {executable}: {exc}") from exc
        raw_output = "\n".join(part.strip() for part in (result.stdout, result.stderr) if part.strip())
        observed = raw_output[:4000]
        package_evidence = None
        if observed != entry.get("version_output", ""):
            try:
                package_evidence = verified_package_probe_version(entry, raw_output, result.returncode)
            except (OSError, ConfigurationError, ResourceNotReadyError) as exc:
                raise PreflightError(f"could not verify executable {executable}: {exc}") from exc
            if package_evidence:
                observed = package_evidence["version_output"]
        if result.returncode != entry.get("version_exit_code", 0) or observed != entry.get("version_output", ""):
            raise PreflightError(
                f"environment drift for {entry.get('tool')}: version smoke test no longer matches validation"
            )
        return {"executable": str(executable), "version_match": True, "environment_prefix": prefix,
                **({"package_version_verification": package_evidence} if package_evidence else {})}

    @staticmethod
    def _verify_database(entry: dict[str, Any], steps: list[dict[str, Any]] | None = None) -> dict[str, Any]:
        root = canonical_path(entry.get("root_path") or entry["path"])
        if not root.is_dir():
            raise PreflightError(f"validated database path is missing: {root}")
        observed = database_fingerprint(root, list(entry["expected_marker_files"]))
        if observed != entry.get("fingerprint"):
            raise PreflightError(f"database drift detected for {entry['logical_name']}: {root}")
        from microbiome.pipeline.resources import DatabaseResolver
        from microbiome.pipeline.errors import ConfigurationError, ResourceNotReadyError
        # Recheck the frozen consumer rules, without consulting current Skills.
        spec = {**entry, "expected_markers": list(entry["expected_marker_files"]),
                "version": entry.get("database_version", "UNKNOWN")}
        consumers = {False: [], True: []}
        for step in steps or []:
            for alias, value in step.get("database", {}).items():
                if str(value.get("logical_name") or alias) != entry["logical_name"]:
                    continue
                legacy = "database_path" in step and "database_binding_version" not in step
                consumers[legacy].append({**step, "database": {alias: {**spec,
                    **({"binding_id": value["binding_id"]} if "binding_id" in value else {})}}})
        if not any(consumers.values()):
            consumers[False] = [{"database": {entry["logical_name"]: spec}}]
        try:
            for legacy, group in consumers.items():
                if group:
                    DatabaseResolver(root.parent).resolve_plan(group, legacy_frozen_bindings=legacy)
        except (ConfigurationError, ResourceNotReadyError) as exc:
            raise PreflightError(f"frozen database contract failed for {entry['logical_name']}: {exc}") from exc
        return {
            "root_path": str(root),
            "runtime_entry": entry.get("runtime_entry") or entry["path"],
            "fingerprint_match": True,
        }

    def preflight(
        self,
        runtime_inputs: dict[str, str] | None,
        *,
        sample_id: str,
        run_id: str,
        threads: int | None = None,
        memory_gb: int | None = None,
        gpus: int | None = None,
        _batch: bool = False,
        _resume: bool = False,
    ) -> dict[str, Any]:
        """Perform read-only production checks. It never repairs or downloads."""
        if not RUN_ID_RE.fullmatch(run_id):
            raise ConfigurationError(f"invalid run_id: {run_id!r}")
        if not SAMPLE_ID_RE.fullmatch(sample_id):
            raise ConfigurationError(f"invalid sample_id: {sample_id!r}")
        pipeline, toolchain, database_lock, _validation = self._load_locks()
        from microbiome.pipeline.approval import ProductionApprovalManager
        from microbiome.pipeline.requirements import RequirementManager
        from microbiome.pipeline.state import LifecycleState, ProjectStateMachine

        approval = ProductionApprovalManager(self.project).require_valid_approval()
        requirements = RequirementManager(self.project).require_confirmed()
        if (
            pipeline.get("requirements_version") != requirements["requirements_version"]
            or pipeline.get("requirements_fingerprint") != requirements["requirements_fingerprint"]
        ):
            raise PreflightError("requirements changed after pipeline freeze; revalidation is required")
        machine = ProjectStateMachine(self.project)
        machine.require(
            LifecycleState.PRODUCTION_APPROVED,
            LifecycleState.PRODUCTION_PREFLIGHT,
            LifecycleState.COMPLETED,
            *((LifecycleState.PRODUCTION_RUNNING,) if _batch or _resume else ()),
        )
        registry_checks = self._verify_resource_registries(pipeline, toolchain, database_lock)
        resolved_inputs, input_rebinding = ProductionInputResolver(self.project, pipeline).resolve(runtime_inputs)
        required = _required_runtime_keys(pipeline["steps"])
        # The frozen contract's declared runtime bindings are authoritative inputs
        # even when command templates are materialized into .steps scripts (which
        # carry no {runtime.*} placeholders). Without this, a materialized lock
        # wrongly reports its own bindings (e.g. reads_1/reads_2) as "undeclared".
        contract_bindings = (pipeline.get("production_input_contract") or {}).get("bindings") or {}
        required |= set(contract_bindings)
        missing_keys = sorted(required - resolved_inputs.keys())
        extra_keys = sorted(resolved_inputs.keys() - required)
        if missing_keys:
            raise PreflightError(f"runtime inputs are missing locked keys: {', '.join(missing_keys)}")
        if extra_keys:
            raise PreflightError(f"runtime inputs contain undeclared keys: {', '.join(extra_keys)}")
        resource_snapshot = get_config().snapshot(
            threads_cap=threads,
            memory_cap_gb=memory_gb,
            gpu_cap=gpus,
        )
        input_checks = {}
        for name, value in resolved_inputs.items():
            path = canonical_path(value)
            if not path.exists():
                raise PreflightError(f"raw input does not exist: {path}")
            if path.is_file() and path.stat().st_size == 0:
                raise PreflightError(f"raw input is empty: {path}")
            input_checks[name] = path_fingerprint(path)

        tool_checks = {step_id: self._verify_tool(entry) for step_id, entry in toolchain.get("tools", {}).items()}
        database_checks = {
            name: self._verify_database(entry, pipeline.get("steps", []))
            for name, entry in database_lock.get("databases", {}).items()
        }
        config = self.project.load_config()
        output_root = canonical_path(config["paths"]["output"], must_exist=True)
        if not os.access(output_root, os.W_OK | os.X_OK):
            raise PreflightError(f"OUTPUT_PATH is not writable: {output_root}")
        minimum_gb = float(config.get("production", {}).get("minimum_free_disk_gb", 1.0))
        free_gb = shutil.disk_usage(output_root).free / (1024**3)
        if free_gb < minimum_gb:
            raise PreflightError(f"insufficient free disk: {free_gb:.2f} GiB available, {minimum_gb:.2f} GiB required")

        run_root = self.project.runs_dir / run_id
        outputs_root = self.project.runs_dir / run_id / "outputs"
        temp_root = run_root / "tmp"
        rendered_steps: dict[str, dict[str, Any]] = {}
        step_by_id = {step["step_id"]: step for step in pipeline["steps"]}
        for step_id in topological_step_ids(pipeline["steps"]):
            step_contract = step_by_id[step_id]
            from microbiome.pipeline.io import fast_file_fingerprint
            for key, fingerprint in step_contract.get("static_input_fingerprints", {}).items():
                path = canonical_path(step_contract["input"][key], must_exist=True)
                if fast_file_fingerprint(path) != fingerprint:
                    raise PreflightError(f"static input or parameter file drifted: {path}")
            if step_contract.get("adapter_path"):
                adapter = canonical_path(step_contract["adapter_path"], must_exist=True)
                if fast_file_fingerprint(adapter) != step_contract.get("adapter_fingerprint"):
                    raise PreflightError(f"reviewed adapter drifted: {adapter}")
            step = step_by_id[step_id]
            tool_entry = toolchain["tools"][step_id]
            rendered = render_step(
                step,
                tool_entry,
                database_lock["databases"],
                runtime_inputs=resolved_inputs,
                run_dir=outputs_root,
                temp_dir=temp_root,
                sample_id=sample_id,
                resource_snapshot=resource_snapshot,
                project_paths=config["paths"],
            )
            for output in rendered["outputs"].values():
                target = canonical_path(output)
                if not _is_relative_to(target, outputs_root):
                    raise PreflightError(f"step {step_id} output escapes the run outputs directory: {target}")
            rendered_steps[step_id] = rendered

        _verify_step_input_ancestry(pipeline["steps"], rendered_steps, outputs_root)
        from microbiome.pipeline.scheduler import live_scheduling, validate_parallel_paths
        scheduling = live_scheduling(pipeline.get("execution_scheduling"), resource_snapshot)
        if scheduling["max_concurrent_steps"] > 1:
            validate_parallel_paths(pipeline["steps"], rendered_steps)
            for sid, rendered in rendered_steps.items():
                allocation = rendered["resources"]
                if (allocation["threads"] > scheduling["max_total_threads"] or
                        allocation["memory_gb"] > scheduling["max_total_memory_gb"]):
                    raise PreflightError(f"step cannot fit approved live scheduling budget: {sid}")
        result = {
            "status": "PASSED",
            "checked_at": _utcnow(),
            "pipeline_version": pipeline["pipeline_version"],
            "pipeline_fingerprint": pipeline["manifest_fingerprint"],
            "pipeline_hash": pipeline["pipeline_hash"],
            "requirements_version": requirements["requirements_version"],
            "production_approval": {
                "approved_at": approval["approved_at"],
                "approval_fingerprint": approval["approval_fingerprint"],
            },
            "production_input_root": input_rebinding.get("input_root", input_rebinding["raw_data_root"]),
            "input_rebinding": input_rebinding,
            "resolved_runtime_inputs": resolved_inputs,
            "run_id": run_id,
            "sample_id": sample_id,
            "input_checks": input_checks,
            "tool_checks": tool_checks,
            "database_checks": database_checks,
            "registry_checks": registry_checks,
            "output_path": str(output_root),
            "run_outputs_path": str(outputs_root),
            "free_disk_gb": round(free_gb, 3),
            "resource_strategy": "MAXIMIZE_WITHIN_LIVE_AND_FROZEN_LIMITS",
            "resource_snapshot": resource_snapshot.as_dict(),
            "rendered_steps": rendered_steps,
        }
        if machine.current in {LifecycleState.PRODUCTION_APPROVED, LifecycleState.COMPLETED}:
            machine.transition(LifecycleState.PRODUCTION_PREFLIGHT, reason=f"read-only preflight passed for {run_id}")
        return result

    @staticmethod
    def _checkpoint_reusable(
        checkpoint_path: Path,
        *,
        pipeline: dict[str, Any],
        tool: dict[str, Any],
        database_lock: dict[str, Any],
        rendered: dict[str, Any],
    ) -> bool:
        if not checkpoint_path.is_file():
            return False
        try:
            checkpoint = read_json(checkpoint_path)
            if checkpoint.get("completion_status") != "COMPLETED":
                return False
            if checkpoint.get("pipeline_version") != pipeline["pipeline_version"]:
                return False
            if checkpoint.get("pipeline_hash") != pipeline["pipeline_hash"]:
                return False
            if checkpoint.get("tool_version") != tool["version_output"]:
                return False
            if checkpoint.get("database_fingerprint") != object_fingerprint(database_lock.get("databases", {})):
                return False
            if checkpoint.get("input_fingerprint") != fingerprint_existing_paths(rendered["inputs"]):
                return False
            if checkpoint.get("output_fingerprint") != fingerprint_existing_paths(rendered["outputs"]):
                return False
            return all(item["passed"] for item in evaluate_assertions(checkpoint["success_assertions"], rendered))
        except (OSError, ValueError, KeyError, ConfigurationError):
            return False

    def execute(
        self,
        runtime_inputs: dict[str, str] | None,
        *,
        sample_id: str,
        run_id: str | None = None,
        threads: int | None = None,
        memory_gb: int | None = None,
        gpus: int | None = None,
        timeout_seconds: int | None = None,
        resume: bool = False,
        _batch: bool = False,
    ) -> dict[str, Any]:
        """Replay frozen commands. Failures are captured and never hot-patched."""
        run_id = run_id or f"run-{datetime.now(UTC).strftime('%Y%m%dT%H%M%S%fZ')}"
        execution_started = time.monotonic()
        preflight = self.preflight(
            runtime_inputs,
            sample_id=sample_id,
            run_id=run_id,
            threads=threads,
            memory_gb=memory_gb,
            gpus=gpus,
            _batch=_batch,
            _resume=resume,
        )
        pipeline, toolchain, database_lock, _validation = self._load_locks()
        from microbiome.pipeline.state import LifecycleState, ProjectStateMachine

        machine = ProjectStateMachine(self.project)
        runtime_inputs = dict(preflight["resolved_runtime_inputs"])
        run_root = self.project.runs_dir / run_id
        if run_root.exists() and not resume:
            raise ExecutionError(
                f"run directory already exists; use resume=True only for the same frozen run: {run_root}"
            )
        machine.transition(LifecycleState.PRODUCTION_RUNNING, reason=f"frozen replay started for {run_id}")
        logs_root = run_root / "logs"
        outputs_root = run_root / "outputs"
        checkpoints_root = run_root / "checkpoints"
        temp_root = run_root / "tmp"
        for path in (logs_root, outputs_root, checkpoints_root, temp_root):
            path.mkdir(parents=True, exist_ok=True)
        manifest_path = run_root / "run_manifest.yaml"
        if resume and manifest_path.is_file():
            previous = read_yaml(manifest_path)
            if previous.get("pipeline_version") != pipeline["pipeline_version"]:
                raise ExecutionError("cannot resume outputs from another pipeline version")

        manifest = {
            "objective": pipeline.get("objective"),
            "deliverables": pipeline.get("deliverables", []),
            "schema_version": 1,
            "run_id": run_id,
            "sample_id": sample_id,
            "pipeline_version": pipeline["pipeline_version"],
            "pipeline_hash": pipeline["pipeline_hash"],
            "pipeline_fingerprint": pipeline["manifest_fingerprint"],
            "requirements_version": pipeline["requirements_version"],
            "status": "RUNNING",
            "started_at": _utcnow(),
            "outputs_path": str(outputs_root),
            "preflight": {
                key: value
                for key, value in preflight.items()
                if key not in {"rendered_steps", "resolved_runtime_inputs"}
            },
            "steps": {},
            "failed_samples": [],
            "production_input_root": preflight["production_input_root"],
            "inputs": {name: str(canonical_path(value)) for name, value in runtime_inputs.items()},
            "tools": {
                step_id: {
                    "executable": tool["executable"],
                    "version": tool["version_output"],
                    "environment_prefix": tool.get("environment_prefix"),
                }
                for step_id, tool in toolchain["tools"].items()
            },
            "databases": {
                name: {
                    "runtime_entry": value.get("runtime_entry") or value["path"],
                    "fingerprint": value.get("fingerprint"),
                }
                for name, value in database_lock.get("databases", {}).items()
            },
        }
        write_yaml(manifest_path, manifest)
        ordered = topological_step_ids(pipeline["steps"])
        steps_by_id = {step["step_id"]: step for step in pipeline["steps"]}
        failed_steps: list[str] = []

        def execute_one(step_id):
            step = steps_by_id[step_id]
            rendered = preflight["rendered_steps"][step_id]
            input_failure = None
            try:
                _verify_run_scoped_paths(step, rendered, outputs_root)
            except PreflightError as exc:
                input_failure = str(exc)
            input_fingerprint_before = (
                {name: {"path": value, "not_checked": True} for name, value in rendered["inputs"].items()}
                if input_failure else fingerprint_existing_paths(rendered["inputs"])
            )
            missing_inputs = [value for value in rendered["inputs"].values()
                              if not input_failure and not canonical_path(value).exists()]
            if missing_inputs:
                input_failure = f"missing step inputs: {', '.join(missing_inputs)}"
            if input_failure:
                # Preflight can defer ancestor-produced artifacts; they must exist
                # now. No native command or native exit status exists in this case.
                record = {"status": "NOT_RUN", "exit_code": None, "stdout": "",
                          "stderr": input_failure,
                          "command": list(rendered["command"])}
                write_json(logs_root / f"{sample_id}.{step_id}.command.json", record)
            else:
                for output in rendered["outputs"].values():
                    canonical_path(output).parent.mkdir(parents=True, exist_ok=True)
                record = run_logged_command(
                    rendered,
                    logs_root / f"{sample_id}.{step_id}.command.json",
                    timeout_seconds=timeout_seconds,
                )
            assertions = []
            assertion_error = None
            if record["exit_code"] == 0:
                try:
                    assertions = evaluate_assertions(step["success_assertions"], rendered)
                except Exception as exc:
                    # Preserve the completed native command even if a frozen
                    # output check cannot be evaluated; never retry the command.
                    assertion_error = {"type": type(exc).__name__, "message": str(exc)}
                    assertions.append({
                        "type": "assertion_evaluation", "target": "success_assertions", "passed": False,
                        "detail": f"{type(exc).__name__}: {exc}",
                    })
            input_unchanged = not input_failure and input_fingerprint_before == fingerprint_existing_paths(rendered["inputs"])
            assertions.append(
                {
                    "type": "input_immutable",
                    "target": "all step inputs",
                    "passed": input_unchanged,
                    "detail": ("not checked: native command was not run because input verification failed"
                               if input_failure else
                               "input fingerprints unchanged" if input_unchanged else "an input was modified"),
                }
            )
            passed = record["exit_code"] == 0 and bool(assertions) and all(item["passed"] for item in assertions)
            return {"passed": passed, "record": record, "assertions": assertions,
                    "assertion_error": assertion_error,
                    "input_failure": input_failure, "input_fingerprint_before": input_fingerprint_before}

        def publish_one(step_id, result):
            step = steps_by_id[step_id]
            rendered = preflight["rendered_steps"][step_id]
            tool = toolchain["tools"][step_id]
            checkpoint_path = checkpoints_root / f"{sample_id}.{step_id}.json"
            passed = result["passed"]
            record = result.get("record", {"status": "NOT_RUN", "exit_code": None,
                                          "stdout": "", "stderr": result.get("worker_error", "worker failed")})
            assertions = result.get("assertions", [])
            execution_facts = {
                "execution_status": record["status"],
                "exit_code": record["exit_code"],
                "stdout_log": record.get("stdout_log"),
                "stderr_log": record.get("stderr_log"),
                "runtime_seconds": record.get("runtime_seconds"),
                "success_checks": assertions,
                "assertion_error": result.get("assertion_error"),
            }
            input_failure = result.get("input_failure") or result.get("worker_error")
            input_fingerprint_before = result.get("input_fingerprint_before", {})
            from microbiome.pipeline.knowledge import KnowledgeBase

            knowledge = KnowledgeBase(self.project)
            knowledge.record_invocation(
                step["tool"],
                command=list(rendered["command"]),
                success=passed,
                executable=tool["executable"],
                version=tool["version_output"],
                environment=tool.get("environment_prefix"),
                database=rendered["databases"],
                outputs=sorted(str(value) for value in rendered["outputs"].values()),
                exit_code=record["exit_code"],
                phase="PRODUCTION",
                validation_checks=assertions,
            )
            if not passed:
                failed_steps.append(step_id)
                failure = failure_record(
                    step=step_id,
                    sample=sample_id,
                    command=rendered["command"],
                    environment=tool.get("environment_prefix"),
                    tool_version=tool["version_output"],
                    database=rendered["databases"],
                    exit_code=record["exit_code"],
                    stdout=record.get("stdout", ""),
                    stderr=record.get("stderr", ""),
                    input_metadata=(input_fingerprint_before if input_failure
                                    else fingerprint_existing_paths(rendered["inputs"])),
                    assertion_failed=record["exit_code"] == 0,
                )
                failure.update(execution_facts)
                if input_failure:
                    failure.update(category=FailureCategory.INPUT_FAILURE.value, execution_status="NOT_RUN")
                failure["error_signature"] = knowledge.record_failure(step["tool"], failure)
                failure_path = logs_root / f"{sample_id}.{step_id}.failure.json"
                write_json(failure_path, failure)
                regression_path = (
                    self.project.pretest_dir
                    / "regression_cases"
                    / f"{datetime.now(UTC).strftime('%Y%m%dT%H%M%S%fZ')}-{sample_id}-{step_id}.yaml"
                )
                write_yaml(
                    regression_path,
                    {
                        "schema_version": 1,
                        "status": "NEEDS_MINIMIZATION",
                        "reason": "production failure candidate; minimize the failing input before repair validation",
                        "pipeline_version": pipeline["pipeline_version"],
                        "sample_id": sample_id,
                        "failed_step": step_id,
                        "runtime_inputs": {name: str(canonical_path(value)) for name, value in runtime_inputs.items()},
                        "failure_record": str(failure_path),
                        "required_revalidation": [
                            "original representative validation subset",
                            "minimized failing regression sample",
                        ],
                    },
                )
                manifest["steps"][step_id] = {
                    "status": "FAILED",
                    **execution_facts,
                    "resources": rendered["resources"],
                    "failure_category": failure["category"],
                    "failure_record": str(failure_path),
                    "regression_candidate": str(regression_path),
                }
                write_yaml(manifest_path, manifest)
                return
            checkpoint = {
                "step_id": step_id,
                "input_fingerprint": fingerprint_existing_paths(rendered["inputs"]),
                "pipeline_version": pipeline["pipeline_version"],
                "pipeline_hash": pipeline["pipeline_hash"],
                "tool_version": tool["version_output"],
                "database_fingerprint": object_fingerprint(database_lock.get("databases", {})),
                "output_fingerprint": fingerprint_existing_paths(rendered["outputs"]),
                "completion_status": "COMPLETED",
                "success_assertions": step["success_assertions"],
                "resources": rendered["resources"],
                "completed_at": _utcnow(),
            }
            write_json(checkpoint_path, checkpoint)
            manifest["steps"][step_id] = {
                "status": "COMPLETED",
                **execution_facts,
                "checkpoint": str(checkpoint_path),
                "resources": rendered["resources"],
            }
            write_yaml(manifest_path, manifest)

        def prepare_or_reuse(step_id, *, allow_reuse=True):
            step = steps_by_id[step_id]
            rendered = preflight["rendered_steps"][step_id]
            if step.get("script_template"):
                from microbiome.pipeline.commands import materialize_script_step
                materialize_script_step(step, rendered, sample_id=sample_id, temp_dir=temp_root)
            checkpoint_path = checkpoints_root / f"{sample_id}.{step_id}.json"
            if resume and allow_reuse and self._checkpoint_reusable(
                checkpoint_path, pipeline=pipeline, tool=toolchain["tools"][step_id],
                database_lock=database_lock, rendered=rendered,
            ):
                manifest["steps"][step_id] = {"status": "REUSED", "checkpoint": str(checkpoint_path),
                                               "resources": rendered["resources"]}
                write_yaml(manifest_path, manifest)
                return True
            return False

        from microbiome.pipeline.scheduler import live_scheduling, run_ready_dag, validate_parallel_paths
        policy = live_scheduling(pipeline.get("execution_scheduling"), preflight["resource_snapshot"])
        if policy["max_concurrent_steps"] > 1:
            validate_parallel_paths(pipeline["steps"], preflight["rendered_steps"])
            manifest["execution_scheduling"] = policy
            reused = set()
            for step_id in ordered:
                if prepare_or_reuse(step_id, allow_reuse=set(steps_by_id[step_id].get("dependencies", [])) <= reused):
                    reused.add(step_id)
            run_ready_dag(
                [steps_by_id[sid] for sid in ordered],
                {sid: preflight["rendered_steps"][sid]["resources"] for sid in ordered},
                policy, execute_one, publish_one, initial_completed=reused,
            )
            for step_id in ordered:
                if step_id not in manifest["steps"]:
                    blocked_by = [dep for dep in steps_by_id[step_id].get("dependencies", [])
                                  if manifest["steps"].get(dep, {}).get("status") in
                                  {"FAILED", "BLOCKED_BY_FAILURE", "NOT_RUN_AFTER_FAILURE"}]
                    manifest["steps"][step_id] = {
                        "status": "BLOCKED_BY_FAILURE" if blocked_by else "NOT_RUN_AFTER_FAILURE",
                        "blocked_by": blocked_by,
                        "reason": "parallel dispatch stopped after a failure; active steps were drained",
                    }
        else:
            # Preserve the existing serial policy: independent branches may finish
            # after another branch fails; only its descendants are blocked.
            for step_id in ordered:
                blocked_by = [dep for dep in steps_by_id[step_id].get("dependencies", [])
                              if manifest["steps"].get(dep, {}).get("status") in {"FAILED", "BLOCKED_BY_FAILURE"}]
                if blocked_by:
                    manifest["steps"][step_id] = {"status": "BLOCKED_BY_FAILURE", "blocked_by": blocked_by}
                    write_yaml(manifest_path, manifest)
                    continue
                if not prepare_or_reuse(step_id):
                    publish_one(step_id, execute_one(step_id))
        manifest["steps"] = {sid: manifest["steps"][sid] for sid in ordered}
        failed_steps.sort(key=ordered.index)

        failed_step = failed_steps[0] if failed_steps else None
        if failed_steps:
            manifest["status"] = "FAILED"
            manifest["failed_samples"] = [sample_id]
        else:
            manifest["status"] = "COMPLETED"
        manifest["completed_at"] = _utcnow()
        manifest["duration_seconds"] = round(time.monotonic() - execution_started, 3)
        manifest["summary"] = {
            "pipeline_version": pipeline["pipeline_version"],
            "completed_steps": sum(item["status"] in {"COMPLETED", "REUSED"} for item in manifest["steps"].values()),
            "failed_step": failed_step,
            "failed_steps": failed_steps,
            "failed_samples": manifest["failed_samples"],
            "silent_fallbacks": 0,
        }
        from microbiome.pipeline.reporting import FinalReportWriter

        manifest["final_report"] = FinalReportWriter(self.project).write(manifest, manifest_path)
        write_yaml(manifest_path, manifest)
        if _batch:
            return manifest
        if failed_steps:
            machine.transition(
                LifecycleState.PRODUCTION_FAILED,
                reason=f"production steps failed: {', '.join(failed_steps)}",
            )
            machine.transition(
                LifecycleState.REVALIDATION_REQUIRED,
                reason="production failure registered as a regression case",
            )
        else:
            machine.transition(LifecycleState.COMPLETED, reason=f"frozen replay completed for {run_id}")
        self.project.set_phase(PipelinePhase.PRODUCTION if not failed_step else PipelinePhase.DIAGNOSIS)
        return manifest
