"""Durable full-manifest scheduling and crash recovery for a frozen pipeline."""

from __future__ import annotations

import re
from datetime import UTC, datetime

from microbiome.pipeline.errors import ConfigurationError, PipelineError
from microbiome.pipeline.io import object_fingerprint, read_yaml, write_yaml
from microbiome.pipeline.state import LifecycleState, ProjectStateMachine


def execute_batch(
    project, executor, pipeline, resolver, *, run_id=None, resume=False, threads=None, memory_gb=None, gpus=None
):
    jobs = resolver.full_dataset_bindings()
    if not jobs:
        raise ConfigurationError("no declared production samples")
    batch_id = run_id or f"production-{datetime.now(UTC).strftime('%Y%m%dT%H%M%S%fZ')}"
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,47}", batch_id):
        raise ConfigurationError("invalid batch identifier")
    path = project.runs_dir / f"{batch_id}.production_batch.yaml"
    if path.exists():
        if not resume:
            raise ConfigurationError("batch already exists; resume this batch explicitly")
        batch = read_yaml(path)
        if (
            batch.get("batch_fingerprint")
            != object_fingerprint({k: v for k, v in batch.items() if k != "batch_fingerprint"})
            or batch.get("pipeline_hash") != pipeline["pipeline_hash"]
            or batch.get("jobs_fingerprint") != object_fingerprint(jobs)
        ):
            raise ConfigurationError("batch inputs, state or frozen pipeline changed")
        if any(row["status"] == "FAILED" for row in batch["runs"]):
            raise ConfigurationError("failed samples require regression validation before a new production version")
    else:
        if resume:
            raise ConfigurationError("requested resume batch does not exist")
        runs = []
        for index, job in enumerate(jobs, 1):
            safe_sample = re.sub(r"[^A-Za-z0-9_.-]+", "-", job["sample_id"]).strip(".-_")[:70] or f"sample-{index}"
            runs.append(
                {
                    "sample_id": job["sample_id"],
                    "sample_ids": job.get("sample_ids", [job["sample_id"]]),
                    "runtime_sample_id": safe_sample,
                    "run_id": batch_id if len(jobs) == 1 else f"{batch_id}-{index:04d}-{safe_sample}",
                    "status": "PENDING",
                    "source_files": job["source_files"],
                }
            )
        batch = {
            "schema_version": 1,
            "batch_id": batch_id,
            "status": "RUNNING",
            "pipeline_hash": pipeline["pipeline_hash"],
            "pipeline_version": pipeline["pipeline_version"],
            "objective": pipeline.get("objective"),
            "jobs_fingerprint": object_fingerprint(jobs),
            "production_input_root": str(resolver.raw_root),
            "input_binding_mode": resolver.contract["binding_mode"],
            "total_samples": sum(len(job.get("sample_ids", [job["sample_id"]])) for job in jobs),
            "runs": runs,
            "outputs_path": str(project.runs_dir),
            "batch_manifest_path": str(path),
            "preflight": {
                "input_rebinding": {
                    "status": "PASSED",
                    "binding_mode": resolver.contract["binding_mode"],
                    "raw_data_root": str(resolver.raw_root),
                }
            },
        }

    def persist():
        batch["completed_samples"] = sum(len(row.get("sample_ids", [row["sample_id"]]))
                                         for row in batch["runs"] if row["status"] == "COMPLETED")
        batch["failed_samples"] = [s for row in batch["runs"] if row["status"] == "FAILED"
                                   for s in row.get("sample_ids", [row["sample_id"]])]
        batch["pending_samples"] = [
            row["sample_id"] for row in batch["runs"] if row["status"] in {"PENDING", "RUNNING"}
        ]
        batch["batch_fingerprint"] = object_fingerprint({k: v for k, v in batch.items() if k != "batch_fingerprint"})
        write_yaml(path, batch)

    persist()
    machine = ProjectStateMachine(project)
    for job, row in zip(jobs, batch["runs"]):
        row["status"] = "RUNNING"
        persist()
        try:
            result = executor.execute(
                job["runtime_inputs"],
                sample_id=row["runtime_sample_id"],
                run_id=row["run_id"],
                threads=threads,
                memory_gb=memory_gb,
                gpus=gpus,
                resume=resume and (project.runs_dir / row["run_id"]).exists(),
                _batch=True,
            )
        except PipelineError as error:
            batch["status"] = "BLOCKED"
            row["status"] = "PENDING"
            batch["blocker"] = str(error)
            persist()
            break
        row.update(
            {
                "status": result["status"],
                "outputs_path": result["outputs_path"],
                "manifest_path": str(project.runs_dir / row["run_id"] / "run_manifest.yaml"),
                "final_report": result.get("final_report"),
            }
        )
        persist()
    else:
        batch["status"] = "FAILED" if batch["failed_samples"] else "COMPLETED"
        if batch["failed_samples"]:
            machine.transition(LifecycleState.PRODUCTION_FAILED, reason="sample failures recorded in batch manifest")
            machine.transition(LifecycleState.REVALIDATION_REQUIRED, reason="failed samples need regression validation")
        else:
            machine.transition(LifecycleState.COMPLETED, reason="all declared production samples completed")
        batch["completed_at"] = datetime.now(UTC).isoformat()
    from microbiome.pipeline.models import PipelinePhase

    if batch["status"] in {"FAILED", "COMPLETED"}:
        project.set_phase(PipelinePhase.PRODUCTION if batch["status"] == "COMPLETED" else PipelinePhase.DIAGNOSIS)
    from microbiome.pipeline.reporting import FinalReportWriter

    batch["final_report"] = FinalReportWriter(project).write_batch(batch)
    persist()
    return batch
