"""One input commit boundary for conversational and portable entry points.

Callers hold the project lock. A durable intent precedes each write; incomplete
commits fail closed until their requirements and manifest agree. Conversation
errors are historical only after the exact replacement has been verified.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import UTC, datetime
from pathlib import Path

from microbiome.pipeline.errors import ConfigurationError
from microbiome.pipeline.io import fast_file_fingerprint, object_fingerprint, read_json, read_yaml, write_json, write_yaml
from microbiome.pipeline.requirements import ConfirmationAction, RequirementManager


def input_file_snapshot(manifest):
    """Read and fingerprint local files without inventing remote acquisitions."""
    paths = set()
    for sample in manifest.get("samples", []):
        for role in ("r1", "r2", "fasta"):
            value = sample.get(role)
            path = value.get("path") if isinstance(value, dict) else value
            if path:
                paths.add(str(path))
    try:
        return {path: fast_file_fingerprint(path) for path in sorted(paths)}
    except (OSError, ValueError) as error:
        raise ConfigurationError("Confirmed local input is missing or unreadable; resolve it again") from error


def verify_input_manifest(project, manifest, *, expected_files=None):
    if (not isinstance(manifest, dict) or not isinstance(manifest.get("samples"), list)
            or not manifest["samples"]):
        raise ConfigurationError("Input manifest has no samples")
    fingerprint = object_fingerprint({key: value for key, value in manifest.items() if key != "manifest_fingerprint"})
    if manifest.get("manifest_fingerprint") != fingerprint:
        raise ConfigurationError("Input manifest fingerprint is invalid")
    identities = [sample.get("sample_id") for sample in manifest["samples"] if isinstance(sample, dict)]
    if (len(identities) != len(manifest["samples"]) or len(set(identities)) != len(identities)
            or any(not isinstance(value, str) or not value.strip() for value in identities)):
        raise ConfigurationError("Input manifest sample identities are invalid")
    if manifest.get("input_kind") == "completed_run_artifacts":
        from microbiome.pipeline.derived import verify_derived_manifest
        verify_derived_manifest(project, manifest)
    elif manifest.get("input_kind") == "external_cohort_tables":
        from microbiome.pipeline.external_cohort import verify_external_manifest
        verify_external_manifest(project, manifest)
    files = input_file_snapshot(manifest)
    if expected_files is not None and files != expected_files:
        raise ConfigurationError("INPUT_FILE_DRIFT: local input changed after resolution; resolve and review it again")
    return files


def _conditions(state):
    ledger = state.get("input_declarations") or {}
    return {"declaration_revision": ledger.get("revision", 0),
            "effective": object_fingerprint(ledger.get("effective")),
            "selection": (state.get("input_selection") or {}).get("selection_fingerprint"),
            "input_error": bool(state.get("input_error")),
            "blocker": object_fingerprint(state.get("input_blocker"))}


def _requirements_match(requirements, manifest):
    value = requirements.get("input", {})
    return (requirements.get("confirmed_fields", {}).get("input") is True
            and value.get("validation_status") != "UNVALIDATED"
            and value.get("manifest_fingerprint") in {
                manifest.get("manifest_fingerprint"), object_fingerprint(manifest)})


def _adopt_state(state, receipt):
    """Apply only the state whose failed condition this transaction supersedes."""
    if state.get("input_commit_id") == receipt["commit_id"]:
        return False
    if _conditions(state) != receipt["before_conditions"]:
        return False
    previous = {key: deepcopy(state[key]) for key in ("input_error", "input_blocker", "input_summary") if key in state}
    blocker = state.get("input_blocker") or {}
    last_blocker = state.get("last_workflow_blocker") or {}
    # The status projection has its own last-error pointer. Only retire it when
    # it identifies this same input failure, never a later or unrelated error.
    if (blocker.get("condition_fingerprint")
            and last_blocker.get("condition_fingerprint") == blocker["condition_fingerprint"]
            and last_blocker.get("code") == blocker.get("code")
            and blocker.get("affected_field") == "input_declaration"):
        previous["last_workflow_blocker"] = deepcopy(last_blocker)
        state.pop("last_workflow_blocker", None)
    if state.get("input_error") or state.get("input_blocker"):
        state.setdefault("input_diagnostic_history", []).append({
            "status": "SUPERSEDED_BY_VERIFIED_INPUT", "commit_id": receipt["commit_id"],
            "manifest_fingerprint": receipt["manifest_fingerprint"],
            "previous": previous, "timestamp": receipt["created_at"]})
    state["input_error"] = False
    state.pop("input_blocker", None)
    state["input_commit_id"] = receipt["commit_id"]
    state["input_manifest_fingerprint"] = receipt["manifest_fingerprint"]
    state["input_summary"] = receipt.get("summary") or (
        f"已核验持久输入清单：{receipt['sample_count']} 个样本；来源 {receipt['input_kind']}。")
    if receipt["confirmation"]:
        ledger = deepcopy(state.get("input_declarations") or {"revision": 0, "records": [], "effective": None})
        record = {"revision": ledger.get("revision", 0) + 1, "status": "CONFIRMED",
                  "validation_status": "VALID", "resume_ready": True,
                  "source_message_id": receipt["commit_id"], "source": receipt["source"],
                  "manifest_fingerprint": receipt["manifest_fingerprint"],
                  "history_boundary": len(state.get("history", [])),
                  "timestamp": receipt["created_at"],
                  "supersedes": (ledger.get("effective") or {}).get("revision")}
        ledger["records"].append(record)
        ledger["revision"] = record["revision"]
        ledger["effective"] = deepcopy(record)
        state["input_declarations"] = ledger
        # This typed manifest is the selection authority; old text stays in history.
        state.pop("input_selection", None)
    if receipt.get("semantic_changed"):
        state["draft"] = None
        for key in ("approved_draft", "approved_pretest", "compiler_repair", "planning_checkpoint"):
            state.pop(key, None)
    return True


def _finish(project, receipt, *, state=None):
    manifest = read_yaml(project.requirements_dir / "input_manifest.yaml")
    if manifest.get("manifest_fingerprint") != receipt["manifest_fingerprint"]:
        raise ConfigurationError("INPUT_COMMIT_INCOMPLETE: manifest write is incomplete; retry the reviewed input confirmation")
    verify_input_manifest(project, manifest, expected_files=receipt["local_files"])
    requirements = RequirementManager(project).load()
    if receipt["confirmation"] and (not receipt.get("confirmation_recorded")
            or not _requirements_match(requirements, manifest)
            or requirements["input"] != receipt["requirement_value"]):
        raise ConfigurationError("INPUT_COMMIT_INCOMPLETE: requirements confirmation is incomplete; review and confirm the input again")
    if not receipt["confirmation"] and requirements["requirements_fingerprint"] != receipt["requirements_before"]:
        raise ConfigurationError("INPUT_COMMIT_INCOMPLETE: requirements changed during input resolution")
    path = project.state_dir / "conversation.json"
    stored = read_json(path) if path.is_file() else {"history": [], "draft": None}
    if (stored.get("input_commit_id") != receipt["commit_id"]
            and _conditions(stored) != receipt["before_conditions"]):
        raise ConfigurationError("INPUT_COMMIT_CONFLICT: input declaration changed during commit; review it again")
    if _adopt_state(stored, receipt):
        write_json(path, stored)
    if state is not None:
        _adopt_state(state, receipt)
    completed = {**receipt, "status": "COMMITTED"}
    write_json(project.state_dir / "input_commits" / (receipt["commit_id"] + ".json"), completed)
    write_json(project.state_dir / "input_commit.json", completed)
    return manifest


def commit_input_manifest(project, manifest, *, requirement_value=None, decision_source=None,
                          workflow=None, summary=None, expected_files=None, revision_snapshot=False):
    """Persist validated input and reconcile blockers, without implicit approval.

    ``requirement_value`` is supplied only after a real reviewed CONFIRM decision.
    Omitting it records resolution facts, never requirement or execution approval.
    """
    from microbiome.agent.input_state import input_is_protected
    if input_is_protected(project) and not revision_snapshot:
        raise ConfigurationError("INPUT_CONTRACT_PROTECTED: 当前运行或冻结输入不能原地替换；请使用新项目或有版本快照的派生输入入口。")
    files = verify_input_manifest(project, manifest, expected_files=expected_files)
    if requirement_value is not None:
        if manifest.get("resolution_status") != "CONFIRMED":
            raise ConfigurationError("Cannot confirm unresolved input")
        declared = requirement_value.get("manifest_fingerprint")
        if declared not in {manifest["manifest_fingerprint"], object_fingerprint(manifest)}:
            raise ConfigurationError("Reviewed input requirement differs from its manifest")
    path = project.state_dir / "conversation.json"
    state = deepcopy(workflow.state) if workflow is not None else (read_json(path) if path.is_file() else {"history": [], "draft": None})
    before = RequirementManager(project).load()
    old_path = project.requirements_dir / "input_manifest.yaml"
    old_manifest = read_yaml(old_path) if old_path.is_file() else None
    marker = project.state_dir / "input_commit.json"
    previous_commit = read_json(marker) if marker.is_file() else {}
    files_changed = (old_manifest and previous_commit.get("manifest_fingerprint") == old_manifest.get("manifest_fingerprint")
                     and previous_commit.get("local_files") != files)
    receipt = {"schema_version": 1, "status": "PREPARED", "confirmation": requirement_value is not None,
               "manifest_fingerprint": manifest["manifest_fingerprint"], "local_files": files,
               "requirements_before": before["requirements_fingerprint"], "requirement_value": deepcopy(requirement_value),
               "before_conditions": _conditions(state), "previous_manifest": old_manifest,
               "previous_input_requirement": before.get("input"),
               "source": deepcopy(decision_source) or {"operation": "native_input_resolution" if requirement_value is None else "reviewed_input_confirmation"},
               "sample_count": len(manifest["samples"]), "input_kind": manifest.get("input_kind", manifest.get("overall_source")),
               "summary": summary, "created_at": datetime.now(UTC).isoformat(),
               "semantic_changed": bool(files_changed or (old_manifest and old_manifest.get("manifest_fingerprint") != manifest["manifest_fingerprint"]))}
    receipt["commit_id"] = object_fingerprint(receipt)
    if revision_snapshot:
        from microbiome.pipeline.derived import snapshot_revision
        snapshot_revision(project)
    write_json(project.state_dir / "input_commits" / (receipt["commit_id"] + ".json"), receipt)
    write_json(project.state_dir / "input_commit.json", receipt)
    write_yaml(old_path, manifest)
    result = None
    if requirement_value is not None:
        manager = RequirementManager(project)
        # A new input invalidates only input-dependent approvals; preserve goals.
        if receipt["semantic_changed"] and before["confirmed_fields"].get("dataset"):
            manager.decide("dataset", before["dataset"], action=ConfirmationAction.MODIFY,
                           decision_source={"operation": "input_commit", "commit_id": receipt["commit_id"]})
        if files_changed and before["confirmed_fields"].get("input") and before["input"] == requirement_value:
            manager.decide("input", requirement_value, action=ConfirmationAction.MODIFY,
                           decision_source={"operation": "input_commit", "commit_id": receipt["commit_id"]})
        result = manager.decide("input", requirement_value, action=ConfirmationAction.CONFIRM,
                                decision_source=decision_source)
    if requirement_value is not None:
        # A pre-existing matching requirement is not proof that this reviewed
        # confirmation completed. Persist its completion before reconciling chat.
        receipt["confirmation_recorded"] = True
        receipt["requirements_after"] = result["requirements_fingerprint"]
        write_json(project.state_dir / "input_commits" / (receipt["commit_id"] + ".json"), receipt)
        write_json(project.state_dir / "input_commit.json", receipt)
    _finish(project, receipt, state=workflow.state if workflow is not None else None)
    return result if requirement_value is not None else manifest


def reconcile_input_commit(project, state):
    """Recover post-confirmation interruption and legacy cross-entry blockers.

    Reconciliation never grants approval, guesses inputs or rewrites a lock.
    Files, manifest identity and confirmed requirements must still agree.
    """
    marker = project.state_dir / "input_commit.json"
    if marker.is_file():
        receipt = read_json(marker)
        manifest_path = project.requirements_dir / "input_manifest.yaml"
        manifest = read_yaml(manifest_path) if manifest_path.is_file() else {}
        same_manifest = manifest.get("manifest_fingerprint") == receipt["manifest_fingerprint"]
        if receipt["status"] != "COMMITTED":
            return _finish(project, receipt, state=state)
        if same_manifest:
            # Old receipts do not override a subsequent declaration repair.
            if (_conditions(state) == receipt["before_conditions"]
                    or (state.get("input_commit_id") == receipt["commit_id"] and not state.get("input_error"))):
                verify_input_manifest(project, manifest, expected_files=receipt["local_files"])
                if receipt["confirmation"] and not _requirements_match(RequirementManager(project).load(), manifest):
                    return None
                if _adopt_state(state, receipt):
                    write_json(project.state_dir / "conversation.json", state)
                return manifest
            # A newer failure on this same commit is not an obsolete legacy flag.
            return None
    # Compatibility for confirmations written by older portable releases.
    # Missing or invalid inputs never qualify, even when an obsolete flag exists.
    if state.get("input_error"):
        path = project.requirements_dir / "input_manifest.yaml"
        if not path.is_file():
            return None
        manifest = read_yaml(path)
        requirements = RequirementManager(project).load()
        if not _requirements_match(requirements, manifest):
            return None
        verify_input_manifest(project, manifest)
        from microbiome.agent.input_state import input_is_protected
        if input_is_protected(project):
            return None
        commit_input_manifest(project, manifest, requirement_value=requirements["input"],
                              decision_source={"operation": "reconcile_existing_input_confirmation"})
        receipt = read_json(marker)
        if _adopt_state(state, receipt):
            write_json(project.state_dir / "conversation.json", state)
        return manifest
    return None
