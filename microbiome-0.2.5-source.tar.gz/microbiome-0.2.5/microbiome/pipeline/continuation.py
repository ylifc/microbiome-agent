"""Audited same-root continuation of complete derived pilots; never an execution fact."""
from __future__ import annotations
import os
import re
from pathlib import Path
from datetime import UTC, datetime
from microbiome.pipeline.errors import ConfigurationError
from microbiome.pipeline.io import (read_json, read_yaml, write_json, write_yaml, object_fingerprint,
    fingerprint_existing_paths, fast_file_fingerprint, canonical_path)
from microbiome.pipeline.commands import evaluate_assertions

REVIEW_FIELDS = {"execution_scheduling", "plan_fingerprint", "requirements_version",
                "workflow_reference_evidence", "planning_evidence", "planning_context_receipt"}

def validate_validation_id(value):
    if not isinstance(value, str) or not re.fullmatch(r"validation-\d{8}T\d{12}Z", value):
        raise ConfigurationError("invalid resume_validation_id")
    return value

def science_compatible(source_plan, current_plan):
    old = {k:v for k,v in source_plan.items() if k not in REVIEW_FIELDS}
    new = {k:v for k,v in current_plan.items() if k not in REVIEW_FIELDS}
    if old != new:
        raise ConfigurationError("continuation permits only reviewed scheduling and review receipt changes")
    return True

def validate_checkpoint(step, checkpoint, command, ledger_entry, rendered, source_plan_fingerprint):
    """Require all three independent execution facts and current assertion/fingerprint checks."""
    from microbiome.pipeline.resources import locked_tool_command
    sid = step["step_id"]
    def require(condition, why):
        if not condition:
            raise ConfigurationError(f"checkpoint {sid}: {why}")
    require(checkpoint.get("step_id") == sid and checkpoint.get("status") == "COMPLETED", "not completed")
    require(checkpoint.get("plan_fingerprint") == source_plan_fingerprint, "source plan mismatch")
    require(command.get("status") == "SUCCEEDED" and command.get("exit_code") == 0 and not command.get("timed_out"), "command not successful")
    require(command.get("complete_command_argv") == locked_tool_command(list(rendered["command"]), rendered), "argv drift")
    for field, key in (("input","inputs"),("output","outputs"),("database","databases"),
                       ("resources","resources"),("resource_environment","resource_environment"),
                       ("runtime_environment","runtime_environment"),("environment_prefix","environment_prefix"),
                       ("runtime_launcher","runtime_launcher")):
        require(command.get(field) == rendered.get(key), f"{field} drift")
    require(command.get("working_directory") == rendered.get("working_directory"), "working directory drift")
    require(command.get("executable") == rendered["command"][0], "executable mismatch")
    require(command.get("software_version") == rendered.get("tool_version"), "tool version drift")
    require(ledger_entry.get("step_id") == sid and ledger_entry.get("status") == "PASSED"
            and ledger_entry.get("verified") is True and ledger_entry.get("exit_code") == 0
            and ledger_entry.get("phase") == "validation"
            and ledger_entry.get("plan_fingerprint") == source_plan_fingerprint
            and ledger_entry.get("output_validation",{}).get("passed") is True, "no matching verified ledger success")
    require(ledger_entry.get("command") == {"kind":"argv","argv":list(rendered["command"])}, "ledger argv drift")
    require(sorted(ledger_entry.get("inputs",[])) == sorted(rendered["inputs"].values()), "ledger input drift")
    require(sorted(ledger_entry.get("outputs",[])) == sorted(rendered["outputs"].values()), "ledger output drift")
    require(ledger_entry.get("tool",{}).get("executable") == command["executable"]
            and ledger_entry.get("tool",{}).get("version") == command["software_version"], "ledger tool drift")
    require(ledger_entry.get("environment") == {"conda_prefix":rendered.get("environment_prefix"), "conda_env":None}, "ledger environment drift")
    expected_db = [{"alias":alias,"path":str(value)} for alias,value in rendered["databases"].items()]
    require(sorted(ledger_entry.get("database_resources",[]),key=lambda x:x["alias"]) == sorted(expected_db,key=lambda x:x["alias"]), "ledger database drift")
    require(ledger_entry.get("parameters") == {"declared":step.get("parameters",[])}, "ledger parameters drift")
    require(type(ledger_entry.get("attempt")) is int and ledger_entry["attempt"] > 0 and bool(ledger_entry.get("record_id")), "ledger attempt identity missing")
    require(checkpoint.get("output_fingerprint") == fingerprint_existing_paths(rendered["outputs"]), "output fingerprint drift")
    if "input_fingerprint" in checkpoint:
        require(checkpoint["input_fingerprint"] == fingerprint_existing_paths(rendered["inputs"]), "input fingerprint drift")
    checks = evaluate_assertions(step["success_criteria"], rendered)
    require(bool(checks) and all(item["passed"] for item in checks), "current output assertions failed")
    return checks

def require_no_other_worker(project):
    """Read process identities without changing job state; public jobs also hold the project lock."""
    from microbiome.integrations.jobs import _process
    for file in (project.state_dir / "portable" / "jobs").glob("*/process.json"):
        record = read_json(file)
        pid = record.get("pid")
        if pid != os.getpid() and record.get("start_time") and _process(pid) == record["start_time"]:
            raise ConfigurationError("continuation refuses a live portable worker")

def _approved_resources(project, source_plan, bootstrap, database_report):
    """Recover immutable approved READY resource evidence for legacy checkpoints."""
    for path in sorted((project.state_dir / "portable" / "delegation" / "decisions").glob("*.json")):
        receipt = read_json(path)
        material = receipt.get("reviewed_material", {})
        artifact = material.get("artifact", {})
        if (receipt.get("status") != "applied" or receipt.get("action") != "CONFIRM"
                or receipt.get("topic") != "dependencies" or artifact.get("plan_fingerprint") != source_plan["plan_fingerprint"]):
            continue
        if receipt.get("project") != str(project.root):
            raise ConfigurationError("dependency receipt belongs to a different project")
        payload = {k:v for k,v in material.items() if k not in {"decision_fingerprint","approval_channel"}}
        if object_fingerprint(payload) != material.get("decision_fingerprint"):
            raise ConfigurationError("source dependency receipt fingerprint invalid")
        if object_fingerprint({k:v for k,v in artifact.items() if k != "report_fingerprint"}) != artifact.get("report_fingerprint"):
            raise ConfigurationError("source dependency report fingerprint invalid")
        tools = {t["step_id"]:t for t in artifact.get("tools",[])}
        for step in source_plan["steps"]:
            old = tools.get(step["step_id"],{})
            new = bootstrap["tools"][step["step_id"]]
            if (old.get("status") != "READY" or old.get("executable") != new["executable"]
                    or old.get("version") != new["version_output"]
                    or old.get("executable_fingerprint") != fast_file_fingerprint(new["executable"])):
                raise ConfigurationError(f"source tool approval or executable changed: {step['step_id']}")
        from microbiome.pipeline.resources import database_fingerprint
        checked_databases = {}
        for old in artifact.get("databases",[]):
            new = database_report["databases"].get(old["resource_id"],{})
            resource_id = old["resource_id"]
            if resource_id not in checked_databases:
                db_root = canonical_path(new.get("root_path") or new.get("path"), must_exist=True)
                checked_databases[resource_id] = database_fingerprint(db_root, list(new.get("expected_marker_files",[])))
            if (old.get("status") != "READY" or old.get("fingerprint") != new.get("fingerprint")
                    or checked_databases[resource_id] != old.get("fingerprint")):
                raise ConfigurationError(f"source database drift: {old['resource_id']}")
        return str(path)
    raise ConfigurationError("continuation requires original approved READY tool/database fingerprint evidence")

def audit_continuation(project, validation_id, plan, rendered_by_id, bootstrap, database_report, runtime_inputs):
    """Read-only audit. Completed steps may be adopted only with their full dependency closure."""
    from microbiome.pipeline.ledger import ExecutionLedger
    from microbiome.pipeline.models import topological_step_ids
    validate_validation_id(validation_id)
    require_no_other_worker(project)
    from microbiome.pipeline.derived import KIND, verify_derived_manifest
    current_manifest = read_yaml(project.requirements_dir / "input_manifest.yaml")
    if current_manifest.get("input_kind") != KIND:
        raise ConfigurationError("continuation requires an immutable derived input manifest")
    verify_derived_manifest(project, current_manifest)
    root = project.pretest_dir / validation_id
    if root.is_symlink() or not root.is_dir() or root.resolve().parent != project.pretest_dir.resolve():
        raise ConfigurationError("continuation validation root is missing or redirected")
    for name in ("pipeline", "input_subset", "outputs", "commands", "checkpoints"):
        if (root / name).is_symlink():
            raise ConfigurationError("continuation control directory is redirected")
    source = read_yaml(root / "pipeline" / "experiment_plan.yaml")
    if source.get("plan_fingerprint") != object_fingerprint({k:v for k,v in source.items() if k != "plan_fingerprint"}):
        raise ConfigurationError("source plan fingerprint invalid")
    science_compatible(source, plan)
    mapping = read_yaml(root / "input_subset" / "source_mapping.yaml")
    if mapping.get("manifest_fingerprint") != object_fingerprint({k:v for k,v in mapping.items() if k != "manifest_fingerprint"}):
        raise ConfigurationError("source mapping fingerprint invalid")
    expected = [{"sample_id":m["sample_id"], "source":{role:runtime_inputs[key] for role,key in m["runtime"].items()}}
                for m in plan.get("cohort_members",[])]
    actual = [{"sample_id":m["sample_id"], "source":m["source"]} for m in mapping.get("samples",[])]
    if actual != expected or mapping.get("fraction") is not None or any(m.get("source") != m.get("subset") for m in mapping.get("samples",[])):
        raise ConfigurationError("source sample artifact mapping changed")
    approval_path = _approved_resources(project, source, bootstrap, database_report)
    entries = ExecutionLedger.for_project(project).entries()
    adopted = {}
    steps = {s["step_id"]:s for s in plan["steps"]}
    for sid in topological_step_ids(plan["steps"]):
        cp_path = root / "checkpoints" / f"{sid}.json"
        if cp_path.is_symlink() or (root / "commands" / f"{sid}.command.json").is_symlink():
            raise ConfigurationError("continuation execution fact is redirected")
        if not cp_path.is_file():
            continue
        checkpoint = read_json(cp_path)
        # Previously adopted old checkpoints keep their original source plan provenance.
        source_fp = checkpoint.get("plan_fingerprint")
        if source_fp != source["plan_fingerprint"]:
            snapshots = list((root / "pipeline").glob("continuation-*.yaml"))
            matching = [read_yaml(p) for p in snapshots if read_yaml(p).get("plan_fingerprint") == source_fp]
            if not matching:
                raise ConfigurationError(f"unrecognized checkpoint plan provenance: {sid}")
            science_compatible(source, matching[-1])
        ledger = [e for e in entries if e.get("validation_id") == validation_id and e.get("step_id") == sid
                  and e.get("plan_fingerprint") == source_fp and e.get("status") == "PASSED" and e.get("verified") is True]
        if not ledger:
            raise ConfigurationError(f"completed checkpoint has no verified ledger: {sid}")
        rendered = rendered_by_id[sid]
        for name, fp in steps[sid].get("static_input_fingerprints",{}).items():
            if fast_file_fingerprint(steps[sid]["input"][name]) != fp:
                raise ConfigurationError(f"static input changed: {sid}.{name}")
        if not set(steps[sid].get("dependencies",[])) <= adopted.keys():
            raise ConfigurationError(f"completed checkpoint missing completed ancestor: {sid}")
        command = read_json(root / "commands" / f"{sid}.command.json")
        checks = validate_checkpoint(steps[sid], checkpoint, command, ledger[-1], rendered, source_fp)
        # Every input must be immutable parent/static data or covered by an adopted predecessor output fingerprint.
        owned = [Path(p).resolve() for dep in adopted.values() for p in dep["rendered"]["outputs"].values()]
        bound = [Path(p).resolve() for p in runtime_inputs.values()]
        bound += [Path(steps[sid]["input"][k]).resolve() for k in steps[sid].get("static_input_fingerprints",{})]
        for value in rendered["inputs"].values():
            target = Path(value).resolve()
            if not any(target == p or p in target.parents for p in owned + bound):
                raise ConfigurationError(f"legacy input has no immutable source/checkpoint provenance: {sid}: {target}")
        adopted[sid] = {"command_record":command,"assertions":checks,"ledger":ledger[-1],"rendered":rendered,
                        "input_fingerprint_before":fingerprint_existing_paths(rendered["inputs"]),"passed":True,
                        "source_checkpoint_fingerprint":object_fingerprint(checkpoint),
                        "source_command_fingerprint":object_fingerprint(command),
                        "source_ledger_fingerprint":object_fingerprint(ledger[-1])}
    if not adopted:
        raise ConfigurationError("no completed, corroborated checkpoints to continue")
    return {"source_plan_fingerprint":source["plan_fingerprint"], "target_plan_fingerprint":plan["plan_fingerprint"],
            "validation_id":validation_id,"resource_approval":approval_path,"adopted":adopted}

def publish_continuation(project, audit, plan, rendered_by_id):
    """Archive only incomplete owned outputs/logs after every adoption check succeeds."""
    import shutil
    root = project.pretest_dir / audit["validation_id"]
    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%S%fZ")
    archive = root / "continuations" / stamp
    archive.mkdir(parents=True, exist_ok=False)
    adopted = audit["adopted"]
    for sid, rendered in rendered_by_id.items():
        if sid in adopted:
            continue
        from microbiome.visualization.artifacts import owned_review_paths
        paths = sorted({canonical_path(p) for p in rendered["outputs"].values()}
                       | set(owned_review_paths(rendered["outputs"])), key=lambda p:len(p.parts))
        moved = []
        for path in paths:
            if any(p in path.parents for p in moved):
                continue
            if path.is_symlink() or not path.resolve().is_relative_to((root / "outputs").resolve()):
                raise ConfigurationError("incomplete output escaped continuation output root")
            if path.exists():
                destination = archive / "outputs" / path.relative_to(root / "outputs")
                destination.parent.mkdir(parents=True, exist_ok=True)
                was_directory = path.is_dir()
                shutil.move(str(path), str(destination)); moved.append(path)
                if was_directory:
                    path.mkdir()  # retain the pre-existing directory shell made by a completed layout step
        for path in (root / "commands").glob(f"{sid}.command.*"):
            destination = archive / "commands" / path.name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(path), str(destination))
    for path in (root / "reports" / "validation_report.json",):
        if path.exists():
            shutil.copy2(path, archive / path.name)
    write_yaml(root / "pipeline" / f"continuation-{plan['plan_fingerprint']}.yaml", plan)
    journal = {k:v for k,v in audit.items() if k != "adopted"}
    journal.update(created_at=datetime.now(UTC).isoformat(), source_validation_root=str(root),
                   reused_steps={sid:{"source_record_id":v["ledger"]["record_id"],
                       "source_attempt":v["ledger"]["attempt"],"assertions":v["assertions"],
                       "source_checkpoint_fingerprint":v["source_checkpoint_fingerprint"],
                       "source_command_fingerprint":v["source_command_fingerprint"],
                       "source_ledger_fingerprint":v["source_ledger_fingerprint"],
                       "input_fingerprint":v["input_fingerprint_before"]} for sid,v in adopted.items()},
                   incomplete_artifact_archive=str(archive))
    journal["journal_fingerprint"] = object_fingerprint(journal)
    target = archive / "continuation.json"
    write_json(target, journal)
    return {"journal_path":str(target),"journal_fingerprint":journal["journal_fingerprint"],
            "reused_steps":list(adopted),"source_plan_fingerprint":audit["source_plan_fingerprint"]}
