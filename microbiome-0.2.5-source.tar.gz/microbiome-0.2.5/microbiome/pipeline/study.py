"""Study-design requirements and a checked conversation-to-plan boundary."""

from __future__ import annotations

import json
import re
from copy import deepcopy

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage

from microbiome.pipeline.errors import ConfigurationError
from microbiome.pipeline.diagnostics import error_diagnostic, validation_violations
from microbiome.pipeline.models import (
    REQUIRED_STEP_FIELDS,
    database_alias_references,
    database_mapping_schema,
    resource_authoring_schema,
    validate_database_mapping,
    validate_experiment_plan,
)


class StudyCompilationError(ConfigurationError):
    """An internal candidate-format failure, distinct from missing user facts."""

    category = "INTERNAL_PLAN_COMPILATION"

    def __init__(self, error, *, candidate, attempts, diagnostics_path=None, details=None,
                 stop_reason="ATTEMPT_LIMIT"):
        self.last_error = str(error)
        self.candidate = candidate
        self.attempts = attempts
        self.diagnostics_path = str(diagnostics_path) if diagnostics_path is not None else None
        self.candidate_available = bool(candidate)
        self.stop_reason = stop_reason
        self.details = details or error_diagnostic(error, context="compiler", candidate=candidate)
        self.category = self.details["category"]
        self.details.update(stop_reason=stop_reason, attempts=attempts)
        super().__init__(
            f"内部方案编译未通过校验（{attempts} 次）：{error}。"
            "候选及对应诊断已保留，无需重新描述分析目标；请根据诊断修正后恢复规划。"
        )


def compiler_schema():
    """Machine-readable output shape, using the authoritative step field list.

    This is a generation contract, not a replacement for semantic validation.
    The existing plan validator and caller's input/resource checks always run.
    """
    from microbiome.pipeline.commands import output_assertion_schema
    nonempty_string = {"type": "string", "minLength": 1}
    mapping = {"type": "object"}
    metadata_row = {"type": "object", "properties": {"sample_id": nonempty_string}}
    dataset = {"type": "object", "minProperties": 1, "properties": {
        "sample_metadata": {
            "description": "Use rows with unique explicit sample_id values. An ID-keyed object is accepted only when every value is an object and any nested sample_id agrees with its key. Applies even without comparative analysis.",
            "anyOf": [
                {"type": "array", "items": {**metadata_row, "required": ["sample_id"]}},
                {"type": "object", "propertyNames": nonempty_string, "additionalProperties": metadata_row},
            ],
        },
    }}
    step = {
        "type": "object",
        "required": list(REQUIRED_STEP_FIELDS),
        "properties": {
            **dict.fromkeys(("step_id", "purpose", "tool", "tool_version_requirement"), nonempty_string),
            "tool_version_requirement": {**nonempty_string,
                "description": "Machine-checkable version constraint, for example ==9.4 or >=1.2,<2; any only if unrestricted. No tool name, executable path or explanatory prose."},
            "software_family": nonempty_string,
            "scope": {"enum": ["sample", "cohort"],
                      "description": "External cohort tables require cohort on every step; use the persisted input contract."},
            **{name: {"type": "array", "items": nonempty_string}
               for name in ("package_candidates", "required_packages", "channels")},
            "environment": {"anyOf": [nonempty_string, {"type": "object", "minProperties": 1}]},
            "input": {"type": "object", "additionalProperties": {"type": "string"}},
            "output": {"type": "object", "minProperties": 1,
                       "additionalProperties": {"type": "string", "pattern": "\\{run_dir\\}"}},
            "database": database_mapping_schema(allow_references=True),
            "command_template": {"type": "array", "minItems": 1,
                                 "prefixItems": [{"const": "{executable}"}], "items": nonempty_string,
                                 "description": "Only named pipeline placeholders may use braces; literal braces and doubled-brace escapes are unsupported. JSON-decode multiline argv to real line breaks, not literal backslash+n separators."},
            "parameters": {"type": ["object", "array"]},
            "success_criteria": {"type": "array", "minItems": 1,
                                 "items": output_assertion_schema()},
            "validation_method": {"type": "array", "minItems": 1, "items": output_assertion_schema()},
            "failure_criteria": {"type": "array", "items": {"type": ["string", "object"]}},
            "dependencies": {"type": "array", "items": nonempty_string},
            "threads_policy": {"type": "object", "properties": {
                key: {"type": "integer", "minimum": 1} for key in ("min", "max", "default")}},
            "memory_policy": mapping,
            "gpu_policy": {"type": "object", "properties": {"enabled": {"type": "boolean"}}},
        },
    }
    return {
        "type": "object",
        "required": ["requirements", "plan", "comparative_analysis", "research_query"],
        "properties": {
            "requirements": {"type": "object", "required": ["input", "dataset", "target", "analysis_goal"],
                             "properties": {**{key: {"type": "object", "minProperties": 1}
                                                for key in ("input", "target", "analysis_goal")},
                                            "dataset": dataset}},
            "comparative_analysis": {"type": "boolean"},
            "research_query": nonempty_string,
            "plan": {"type": "object", "required": ["objective", "steps", "deliverables"], "properties": {
                "objective": nonempty_string,
                "execution_scope": {"enum": ["sample", "cohort"]},
                "pilot_mode": {"enum": ["sequence_fraction", "complete_external_cohort", "complete_derived_samples"],
                               "description": "Required at plan top level for complete external or derived inputs; never put it in step.parameters."},
                "validation_strategy": {"const": "manifest_cases"},
                "resources": resource_authoring_schema(),
                "workflow_ids": {"type": "array", "items": nonempty_string},
                "workflow_decisions": {"type": "array", "items": {
                    "type": "object", "required": ["workflow_id", "disposition", "reason", "step_ids"],
                    "properties": {"workflow_id": nonempty_string, "reason": nonempty_string,
                                   "disposition": {"enum": ["use", "adapt", "not_applicable"]},
                                   "step_ids": {"type": "array", "items": nonempty_string}}}},
                "steps": {"type": "array", "minItems": 1, "items": step},
                "deliverables": {"type": "array", "minItems": 1, "items": {
                    "type": "object", "required": ["name", "step_id", "output", "purpose"],
                    "properties": dict.fromkeys(("name", "step_id", "output", "purpose"), nonempty_string)}},
            }},
        },
    }


def _database_reference(value):
    if isinstance(value, str):
        return "database." in value
    if isinstance(value, dict):
        return any("database" in str(key).casefold() or str(key).casefold() == "db"
                   or str(key).casefold().startswith("db_") or _database_reference(item)
                   for key, item in value.items())
    if isinstance(value, list):
        return any(_database_reference(item) for item in value)
    return False


def _normalize_candidate(payload):
    """Normalize unambiguous containers without fabricating resource facts."""
    checked = deepcopy(payload)
    plan = checked.get("plan")
    normalized = []
    requirements = checked.get("requirements")
    dataset = requirements.get("dataset") if isinstance(requirements, dict) else None
    if isinstance(dataset, dict) and isinstance(dataset.get("sample_metadata"), dict):
        dataset["sample_metadata"] = _sample_metadata_rows(dataset["sample_metadata"])
        normalized.append("requirements.dataset.sample_metadata converted from explicit sample-ID map to row array; metadata values unchanged")
    if isinstance(plan, dict) and isinstance(plan.get("steps"), list):
        for index, step in enumerate(plan["steps"]):
            if isinstance(step, dict) and "database" not in step and not _database_reference(step):
                step["database"] = {}
                normalized.append(f"plan.steps[{index}].database={{}} (no database namespace references)")
            if not isinstance(step, dict) or not isinstance(step.get("database"), dict):
                continue
            database = step["database"]
            descriptor_fields = database_mapping_schema()["additionalProperties"]["properties"]
            # A reference supplies the alias; logical_name is a resource identity,
            # not authority to guess or rewrite an executable binding.
            aliases = database_alias_references(step)
            if (len(aliases) == 1 and database and set(database) <= descriptor_fields.keys()
                    and any(not isinstance(value, dict) for value in database.values())):
                alias = next(iter(aliases))
                step["database"] = {alias: database}
                normalized.append(
                    f"plan.steps[{index}].database wrapped under explicit alias {alias!r}; resource facts unchanged"
                )
    return checked, normalized


def _sample_metadata_rows(metadata):
    """Use only explicit sample identities; preserve every supplied metadata value."""
    field = "requirements.dataset.sample_metadata"
    violations = []

    def reject(location, code, message):
        violations.append({"field": location, "code": code, "message": message})

    if isinstance(metadata, dict):
        rows = []
        for sample_id, row in metadata.items():
            location = field + "[" + json.dumps(sample_id, ensure_ascii=False) + "]"
            if not isinstance(sample_id, str) or not sample_id.strip():
                reject(location, "SAMPLE_ID_REQUIRED", "Map keys must be explicit nonempty sample identifiers.")
            elif not isinstance(row, dict):
                reject(location, "SAMPLE_METADATA_ROW_TYPE", "Each sample-ID map value must be a metadata object.")
            elif "sample_id" in row and row["sample_id"] != sample_id:
                reject(location + ".sample_id", "SAMPLE_ID_CONFLICT",
                       f"Nested sample_id must equal its explicit map key {sample_id!r}; do not guess which identity to keep.")
            else:
                rows.append({"sample_id": sample_id, **deepcopy(row)})
    elif isinstance(metadata, list):
        rows = deepcopy(metadata)
    else:
        rows = []
        reject(field, "SAMPLE_METADATA_TYPE", "Use a row array or an explicit sample-ID-to-object map.")
    seen = set()
    for index, row in enumerate(rows):
        location = f"{field}[{index}]"
        if not isinstance(row, dict):
            reject(location, "SAMPLE_METADATA_ROW_TYPE", "Each sample metadata row must be an object.")
            continue
        sample_id = row.get("sample_id")
        if not isinstance(sample_id, str) or not sample_id.strip():
            reject(location + ".sample_id", "SAMPLE_ID_REQUIRED", "Every row needs an explicit nonempty sample_id.")
        elif sample_id in seen:
            reject(location + ".sample_id", "DUPLICATE_SAMPLE_ID", "Sample identifiers must be unique.")
        else:
            seen.add(sample_id)
    if violations:
        error = ConfigurationError("Invalid sample metadata: " + "; ".join(
            item["field"] + ": " + item["message"] for item in violations))
        error.details = {"violations": violations, "next_action": "repair_candidate_sample_metadata"}
        raise error
    return rows


def _shape_errors(payload):
    """Report missing fields across every step, instead of fixing one per call."""
    plan = payload.get("plan") if isinstance(payload, dict) else None
    steps = plan.get("steps") if isinstance(plan, dict) else None
    if not isinstance(steps, list):
        return []
    issues = []
    for index, step in enumerate(steps):
        if not isinstance(step, dict):
            continue
        if missing := [name for name in REQUIRED_STEP_FIELDS if name not in step]:
            issues.append(f"plan.steps[{index}] missing required fields: {', '.join(missing)}")
        if "database" in step:
            try:
                validate_database_mapping(step["database"], str(step.get("step_id", index)))
            except ConfigurationError as error:
                issues.append(f"plan.steps[{index}]: {error}")
    return issues



def _dependency_report(payload):
    """Expose the whole graph to repair, without guessing or changing edges."""
    plan = payload.get("plan") if isinstance(payload, dict) else None
    steps = plan.get("steps") if isinstance(plan, dict) else None
    if not isinstance(steps, list):
        return {}
    ids = [s.get("step_id") for s in steps if isinstance(s, dict) and isinstance(s.get("step_id"), str)]
    declared = set(ids)
    edges = []
    for step in steps:
        if not isinstance(step, dict):
            continue
        deps = step.get("dependencies", [])
        if isinstance(deps, list):
            edges.extend({"step_id": step.get("step_id"), "missing_dependency": dep}
                         for dep in deps if isinstance(dep, str) and dep not in declared)
    return {"declared_step_ids": ids, "unknown_dependencies": edges,
            "duplicate_step_ids": sorted(key for key in declared if ids.count(key) > 1)}


def _step_validation_report(payload):
    """Collect independent step defects using the same validator, for feedback only.

    Edges are checked separately in the full graph. Removing them from each
    temporary one-step probe must never affect the candidate or acceptance.
    """
    plan = payload.get("plan") if isinstance(payload, dict) else None
    if not isinstance(plan, dict) or not isinstance(plan.get("steps"), list):
        return []
    issues = []
    for index, step in enumerate(plan["steps"]):
        if not isinstance(step, dict):
            continue
        probe = deepcopy(plan)
        probe["steps"] = [{**deepcopy(step), "dependencies": []}]
        try:
            validate_experiment_plan(probe)
        except (ConfigurationError, ValueError, TypeError, AttributeError, KeyError) as error:
            issues.append({"step_index": index, "step_id": step.get("step_id"), "error": str(error)})
    return issues


def _validate_command_template_syntax(plan):
    """Reject render-incompatible new candidates without reinterpreting locks.

    Reuse the renderer's exact placeholder grammar. This checks syntax only;
    actual names, values and resource bindings still require normal rendering.
    """
    from microbiome.pipeline.commands import PLACEHOLDER_RE

    violations = []
    for step_index, step in enumerate(plan["steps"]):
        for token_index, token in enumerate(step["command_template"]):
            remainder = PLACEHOLDER_RE.sub("", token)
            if "{" in remainder or "}" in remainder:
                violations.append({
                    "field": f"plan.steps[{step_index}].command_template[{token_index}]",
                    "code": "UNSUPPORTED_LITERAL_BRACE",
                    "message": "Only named pipeline placeholders may contain braces; literal or malformed braces (including doubled-brace escapes) are unsupported by the command renderer. Use an existing verified script for complex programs; do not invent an asset or script path.",
                })
    if violations:
        error = ConfigurationError("Unsupported literal or malformed brace in "
            + ", ".join(item["field"] for item in violations)
            + "; command argv supports named pipeline placeholders only, not literal braces.")
        error.details = {"violations": violations, "next_action": "repair_candidate_command_template"}
        raise error


def _validate_version_requirements(plan):
    """Keep new compiler constraints executable; leave legacy lock semantics intact."""
    from packaging.version import InvalidVersion, Version

    violations = []
    for index, step in enumerate(plan["steps"]):
        requirement = step["tool_version_requirement"].strip()
        valid = requirement in {"*", "any", "ANY"}
        if not valid:
            clauses = requirement.split(",")
            valid = bool(clauses)
            for clause in clauses:
                match = re.fullmatch(r"\s*(==|!=|>=|<=|>|<|~=)?\s*([0-9][^\s,]*)\s*", clause)
                try:
                    if not match:
                        valid = False
                        break
                    Version(match.group(2))
                except InvalidVersion:
                    valid = False
                    break
        if not valid:
            violations.append({"field": f"plan.steps[{index}].tool_version_requirement",
                "code": "VERSION_CONSTRAINT_FORMAT",
                "message": "Use a machine-checkable version constraint such as ==9.4 or >=1.2,<2; use any only when no version restriction was requested. Preserve the required version; put tool names, paths, probe results and explanatory prose in purpose or tool_choice.reason, not this constraint."})
    if violations:
        error = ConfigurationError("Invalid machine-checkable tool version constraint: "
            + "; ".join(item["field"] + ": " + item["message"] for item in violations))
        error.details = {"violations": violations, "next_action": "repair_candidate_version_constraint"}
        raise error


def validate_study(payload: dict) -> dict:
    if not isinstance(payload, dict):
        raise ConfigurationError("study design must be an object")
    questions = payload.get("questions", [])
    if questions:
        raise ConfigurationError("; ".join(str(question) for question in questions))
    if type(payload.get("comparative_analysis", False)) is not bool:
        raise ConfigurationError("comparative_analysis must be a JSON boolean: true or false.")
    requirements = deepcopy(payload.get("requirements", {}))
    if not isinstance(requirements, dict):
        raise ConfigurationError("study design requirements must be an object")
    for name in ("input", "dataset", "target", "analysis_goal"):
        if not isinstance(requirements.get(name), dict) or not requirements[name]:
            raise ConfigurationError(f"study design is missing {name}")
    dataset = requirements["dataset"]
    if "sample_metadata" in dataset:
        dataset["sample_metadata"] = _sample_metadata_rows(dataset["sample_metadata"])
    if payload.get("comparative_analysis"):
        samples = dataset.get("sample_metadata", [])
        groups = {}
        for sample in samples:
            if not sample.get("sample_id") or not sample.get("group"):
                raise ConfigurationError("comparative analysis requires sample identifiers and groups")
            groups.setdefault(sample["group"], set()).add(sample.get("biological_replicate") or sample["sample_id"])
        if len(groups) < 2 or any(len(replicates) < 2 for replicates in groups.values()):
            raise ConfigurationError("comparative inference requires an explicit design with biological replication")
        if not dataset.get("statistical_design") or not dataset.get("multiple_testing"):
            raise ConfigurationError("comparative inference requires a statistical design and multiple-testing policy")
        if payload.get("plan", {}).get("execution_scope") != "cohort":
            raise ConfigurationError("组间统计需要 execution_scope=cohort 的全样本输入适配流程")
    plan = validate_experiment_plan({**payload.get("plan", {}), "validation_strategy": "manifest_cases"})
    _validate_command_template_syntax(plan)
    _validate_version_requirements(plan)
    from microbiome.pipeline.commands import output_assertion_violations, output_assertion_schema
    violations = [item for index, step in enumerate(plan["steps"])
        for field in ("success_criteria", "validation_method")
        for position, criterion in enumerate(step[field])
        for item in output_assertion_violations(criterion,
            field=f"plan.steps[{index}].{field}[{position}]", step=step)]
    if violations:
        error = ConfigurationError("Invalid executable output assertions: " + "; ".join(
            item["field"] + ": " + item["message"] for item in violations))
        error.details = {"violations": violations, "next_action": "repair_candidate_output_assertions",
                         "supported_assertion_schema": output_assertion_schema()}
        raise error
    deliverables = plan.get("deliverables")
    if not isinstance(deliverables, list) or not deliverables:
        raise ConfigurationError("study design requires explicit deliverables")
    steps = {step["step_id"]: step for step in plan["steps"]}
    for item in deliverables:
        step = steps.get(item.get("step_id")) if isinstance(item, dict) else None
        if not step or item.get("output") not in step["output"] or not item.get("purpose"):
            raise ConfigurationError("every deliverable must name a declared step output and its purpose")
    for step in plan["steps"]:
        from microbiome.pipeline.commands import _criterion_parts

        checked_outputs = set()
        for criterion in step["success_criteria"]:
            _, target, _ = _criterion_parts(criterion)
            namespace, _, key = target.partition(".")
            if namespace not in {"input", "output", "database"} or key not in step[namespace]:
                raise ConfigurationError(f"step {step['step_id']}: assertion refers to an undeclared target: {target}")
            if target.startswith("output."):
                checked_outputs.add(target.removeprefix("output."))
        if set(step["output"]) - checked_outputs:
            raise ConfigurationError(f"step {step['step_id']}: every declared output needs an explicit success check")
        if step.get("script_template"):
            raise ConfigurationError(
                "new conversational plans must declare argv commands; arbitrary scripts need a reviewed adapter"
            )
    return {**payload, "requirements": requirements, "plan": plan}


def compile_study(agent, messages, *, attempts=3, diagnostics_path=None, validate_extra=None, resume_candidate=None,
                  workflow_context=None, plan_normalizer=None, unchanged_limit=2, invoke_model=None,
                  validate_structure=None, on_candidate=None):
    """Bounded schema repair before resource discovery; never relax validation.

    The same local validator checks both the first answer and corrections.
    A correction is a planning call only and cannot authorize execution.
    Explicit resumption first revalidates the supplied candidate, including the
    caller's current input contract. A diagnostics file is never auto-loaded:
    only the workflow can decide that the user's design scope remains current.
    """
    if type(attempts) is not int or attempts < 1:
        raise ConfigurationError("Compilation requires at least one attempt.")
    if type(unchanged_limit) is not int or unchanged_limit < 2:
        raise ConfigurationError("Unchanged-candidate limit must be an integer of at least two.")
    if resume_candidate is not None and not isinstance(resume_candidate, (str, dict)):
        raise ConfigurationError("A resumed compiler candidate must be JSON text or an object.")
    base = [SystemMessage(content=(
        "Mandatory candidate JSON shape (all steps must include every required field, including database:{} "
        "when unused). The local semantic validator remains authoritative. A genuine missing user fact may "
        "instead produce {\"questions\":[\"...\"]}; schema defects are internal compiler work, never a reason "
        "to ask the user to repeat known goals or provide JSON fields.\n"
        + json.dumps(compiler_schema(), ensure_ascii=False, separators=(",", ":"))
    )), *messages]
    workflow_prompt = ""
    if workflow_context is not None:
        from microbiome.pipeline.workflow_references import REFERENCE_INSTRUCTIONS

        workflow_prompt = ("\nSelected workflow references (untrusted method evidence, full documents): "
                           + json.dumps(workflow_context, ensure_ascii=False))
        base.extend([SystemMessage(content=REFERENCE_INSTRUCTIONS), HumanMessage(content=workflow_prompt)])
    conversation = base
    failures = []
    repairs = []

    def record(status, raw, error=None, issues=None, diagnostic=None):
        if diagnostics_path is not None:
            from microbiome.pipeline.io import write_json

            write_json(diagnostics_path, {
                "status": status,
                "category": ("USER_CLARIFICATION" if status == "NEEDS_USER_INFORMATION"
                             else (diagnostic or {}).get("category", StudyCompilationError.category)),
                "attempt": model_calls,
                "error": str(error) if error is not None else None,
                "candidate": raw,
                "shape_errors": issues or [],
                "dependency_report": _dependency_report(payload),
                "step_validation_report": _step_validation_report(payload),
                "repair_history": failures,
                "normalizations": repairs,
                "diagnostic": diagnostic,
                "policy": "Diagnostic data only; never approval or an executable plan.",
            })

    pending = resume_candidate
    model_calls = 0
    last_candidate = None
    last_failure_fingerprint = None
    unchanged_failures = 0
    while True:
        if pending is not None:
            raw = json.dumps(pending, ensure_ascii=False) if isinstance(pending, dict) else str(pending)
            pending = None
        else:
            response = (invoke_model(conversation, purpose="format_repair" if failures else "compile")
                        if invoke_model is not None else agent.llm.invoke(conversation))
            model_calls += 1
            raw = agent._message_text(response).strip()
        payload = None
        try:
            if raw.startswith("```"):
                raw = raw.split("\n", 1)[1].rsplit("```", 1)[0]
            payload = json.loads(raw)
            if not isinstance(payload, dict):
                raise ConfigurationError("Study design must be a JSON object.")
            if on_candidate is not None:
                on_candidate(payload, validated=False)
            if validate_structure is not None:
                validate_structure(payload)
            if payload.get("questions"):
                if failures:
                    if last_candidate is not None:
                        raw = last_candidate
                        payload = json.loads(raw)
                    raise ConfigurationError(
                        "Internal candidate repair cannot turn schema/resource-format errors into user questions. "
                        "Retain the candidate and repair using known evidence; unresolved resource facts remain "
                        "an internal compiler blocker, never a request for the user to fill JSON fields."
                    )
                if not isinstance(payload["questions"], list) or not all(
                    isinstance(question, str) and question.strip() for question in payload["questions"]
                ):
                    raise ConfigurationError("questions must be an array of nonempty strings.")
                if diagnostics_path is not None:
                    record("NEEDS_USER_INFORMATION", raw)
                return payload
            last_candidate = raw
            normalized, changes = _normalize_candidate(payload)
            repairs.extend(change for change in changes if change not in repairs)
            if plan_normalizer is not None and isinstance(normalized.get("plan"), dict):
                normalized["plan"] = plan_normalizer(deepcopy(normalized["plan"]))
            payload = normalized
            if validate_structure is not None:
                # Compact authoring references can expand into large trusted
                # descriptors. Check the actual plan before resource preview.
                validate_structure(normalized)
            issues = _shape_errors(normalized)
            if issues:
                raise ConfigurationError("; ".join(issues))
            checked = validate_study(normalized)
            if workflow_context is not None:
                from microbiome.pipeline.workflow_references import bind_reference_decisions

                checked["plan"] = validate_experiment_plan(bind_reference_decisions(
                    checked["plan"], workflow_context, receipt=workflow_context.get("full_evidence")))
            if validate_structure is not None:
                # Validation defaults and bound reference evidence also become
                # part of the persisted candidate and must fit the same limit.
                validate_structure(checked)
            if validate_extra is not None:
                validate_extra(checked)
            if on_candidate is not None:
                on_candidate(checked, validated=True)
            if diagnostics_path is not None:
                record("RESOLVED_MODEL_CANDIDATE", json.dumps(checked, ensure_ascii=False))
            return checked
        except (ConfigurationError, ValueError, IndexError, TypeError, AttributeError, KeyError) as error:
            if on_candidate is not None and payload is None:
                # Malformed JSON is still the actual model candidate. Retain
                # it before the next repair's transport/budget guard can stop.
                on_candidate(raw, validated=False)
            issues = _shape_errors(payload)
            violations = validation_violations(error, shape_errors=issues,
                                               step_errors=_step_validation_report(payload))
            diagnostic = error_diagnostic(error, context="compiler", candidate=payload or raw,
                                          violations=violations)
            if not diagnostic["consumes_recovery_attempt"] or not diagnostic.get("consumes_format_repair", True):
                # Contention and technical budgets are not malformed JSON.
                # Preserve the candidate; recovery follows their own policy.
                raise
            failure_fingerprint = diagnostic["evidence_fingerprint"]
            unchanged_failures = unchanged_failures + 1 if failure_fingerprint == last_failure_fingerprint else 1
            last_failure_fingerprint = failure_fingerprint
            unchanged = unchanged_failures >= unchanged_limit
            stop_reason = "UNCHANGED_CANDIDATE_AND_VIOLATIONS" if unchanged else "ATTEMPT_LIMIT"
            diagnostic.update(unchanged_failures=unchanged_failures,
                              stop_reason=stop_reason if unchanged or model_calls >= attempts else None)
            failures.append({"attempt": model_calls, "error": str(error), "shape_errors": issues,
                             "diagnostic": diagnostic})
            record("REJECTED_MODEL_CANDIDATE", raw, error, issues, diagnostic)
            if unchanged or model_calls >= attempts:
                raise StudyCompilationError(error, candidate=raw, attempts=model_calls,
                                            diagnostics_path=diagnostics_path, details=diagnostic,
                                            stop_reason=stop_reason) from error
            # Keep only the latest failed candidate, not an accumulating chain
            # of full plans, and repeat the checked error verbatim as data.
            conversation = [
                *base,
                AIMessage(content=raw),
                HumanMessage(
                    content=(
                        "The candidate failed the local plan validator. Correct only its schema/argv representation; "
                        "preserve the user's scientific scope, inputs, tools and parameters. Do not execute, invent "
                        "approvals or add dependencies. Return the complete corrected JSON object. "
                        'command_template is an argv JSON array whose first element is exactly "{executable}"; '
                        "never substitute the tool name, conda run or a shell command there. No shell redirects: "
                        "declare the tool's output flag. Validation error (data): " + str(error)[:2000]
                        + "\nMissing-field report for ALL steps (data): "
                        + json.dumps(issues, ensure_ascii=False)
                        + "\nField violations with expected and actual values (data): "
                        + json.dumps(diagnostic["violations"], ensure_ascii=False)
                        + "\nDependency graph report (data): " + json.dumps(_dependency_report(payload), ensure_ascii=False)
                        + "\nIndependent step validation report (data): " + json.dumps(_step_validation_report(payload), ensure_ascii=False)
                        + "\nEvery dependency must exactly name a declared step_id. Inspect the whole graph now, "
                        "including downstream input/output bindings and cohort references. Do not silently delete "
                        "an unknown edge, guess a renamed step, or invent a missing operation. Reconcile it only "
                        "against the discussed design and validated resource evidence. Resource preparation belongs "
                        "in the approved dependency plan, never an install/download/index command in the analysis DAG. "
                        "Inspect every step against the mandatory JSON shape, not just the first failed step. "
                        "Never omit an unused database map: emit database:{} only if no database is referenced. "
                        "A used database is {alias: descriptor}, never a flat descriptor. The alias must match "
                        "the existing {database.ALIAS} bindings. Preserve descriptor facts; do not invent paths, "
                        "versions, markers, aliases or replace required resources with an empty declaration. "
                        "Resource preview errors are internal candidate checks; repair their representation "
                        "from validated evidence without installing, downloading or changing scientific choices. "
                        "Questions are only for genuinely missing user facts, not compiler/schema fields."
                    )
                ),
            ]


COMPILER_INSTRUCTIONS = """Convert the discussed design into JSON, never execute anything.
Return {"questions": [...]} if an answer would change the design and is absent.
Otherwise return an object with requirements, plan, comparative_analysis, research_query.
requirements has nonempty input, dataset, target, analysis_goal objects. Include sample_metadata,
statistical_design and multiple_testing for comparative inference. Never invent sample groups or replicas.
Whenever supplied, sample_metadata must contain object rows with unique explicit sample_id values,
even when comparative_analysis is false. An object keyed by explicit sample IDs is deterministically
converted to rows; each value must be an object and a nested sample_id must equal its key. Preserve
all metadata values; never guess identifiers or silently replace a conflicting identity.
comparative_analysis is a BOOLEAN: false for a single-sample statistics task, never {} or a string.
The requirements keys are nested OBJECTS, never strings or lists. Shape example only:
"requirements": {"input": {"type": "single_end"}, "dataset": {"sample_count": 1},
"target": {"scope": "user's stated target"}, "analysis_goal": {"objective": "user's stated objective"}}.
Replace these example values with actual user facts. All four objects are mandatory even for a tiny engineering test.
research_query is a bibliographic methods query containing no private sample identifiers or local paths.
If the user supplies an explicit research keyword/query, use it exactly; do not add constraints.
Otherwise use a short software/method query, not a long description of the particular test dataset.
plan has objective, deliverables (list of {name, step_id, output, purpose}), and steps.
Every dependencies entry must exactly match a step_id declared in this same plan.steps array.
Check all dependency references, duplicate IDs and cycles before returning the complete plan.
Resource preparation is not an analysis step; bind validated persistent resource entrypoints instead.
Never leave dangling dependencies after removing or renaming a candidate step.
Each deliverable's output is the bare OUTPUT MAP KEY, NOT a filename, path, template or output.KEY.
For a step with step_id="stats_step" and output={"stats":"{run_dir}/stats.tsv"}, the deliverable is
{"name":"sequence statistics", "step_id":"stats_step", "output":"stats", "purpose":"inspect read statistics"}.
Each step has step_id, purpose, tool, tool_version_requirement, environment (name/prefix,
executable, packages, channels), input and output maps, database map, command_template (argv
starting with {executable}), parameters, success_criteria, failure_criteria, dependencies,
threads_policy {min:1,max:1,default:1}, memory_policy {max_gb:1}, gpu_policy {enabled:false}.
tool_version_requirement is a machine-checkable constraint, e.g. "==9.4" or ">=1.2,<2".
Use "any" only if the confirmed goal imposes no version restriction. Never use a sentence,
tool name, executable path, validation promise or evidence claim as a version constraint.
Keep the required version intact; put explanations in purpose or tool_choice.reason.
For newly discovered software, keep software_family, package_candidates (alternative packages),
required_packages (additional required dependencies) and channels as separate step fields.
Use verified metadata/help or official packaging evidence, never guess a package mapping from a tool name.
environment can declare name/prefix/install_prefix, executable, version_args and help_args when known.
A suggested environment name is not an instruction to install: all existing environments must be searched
first. Actual executable and Conda prefix are resolved by the application and frozen after validation.
Missing Skill documentation does not prove software absence. New installation requirements must be
included in the dependency plan and confirmed before BOOTSTRAP/PRETEST_REPAIR; never install in production.
command_template is a JSON array, e.g. ["{executable}", "stats", "-a", "-T", "-o", "{output.stats}", "{input.reads}"].
Its first item is LITERALLY "{executable}", never a tool name/path or "conda".
Use native output flags: shell redirects, pipes, wrappers and command strings are forbidden.
Braces inside command_template tokens are reserved for named pipeline placeholders such as
{input.NAME}, {output.NAME} and {threads}. Literal dictionary/set/regex braces, positional
format braces and doubled-brace escapes are unsupported by the existing renderer.
Complex programs must use an existing reviewed, verifiable script supported by resource evidence;
never invent an asset token, script path or new script file to work around this contract.
For multiline code in JSON argv, encode each line break once with the JSON newline escape.
After JSON decoding, code separators must be actual newline characters, not literal backslash+n
text from double escaping. Preserve any escapes needed inside the program's own string literals;
do not blindly replace all escaped sequences or change scientific operations.
Input/output map values are path strings, not nested objects; refer to their keys with {input.NAME}/{output.NAME}.
Use real resource budgets, not the example budgets. Multithreading needs a {threads} argument.
For raw sequence inputs use {runtime.reads}, {runtime.reads_1}/{runtime.reads_2} or {runtime.fasta}; output
paths MUST be under {run_dir}. Downstream input paths reference the same {run_dir} outputs.
For reads use e.g. "input":{"reads":"{runtime.reads}"}, never the original FASTQ absolute path;
the runner must bind the sampled inputs during pretest and full inputs during production.
success_criteria includes exists:output.NAME, non_empty:output.NAME and an appropriate
{type:parseable,target:output.NAME,format:FORMAT} when the format is supported.
success_criteria and failure_criteria are JSON ARRAYS, never mappings. Example:
"success_criteria":["exists:output.stats", "non_empty:output.stats", {"type":"parseable","target":"output.stats","format":"tsv"}],
"failure_criteria":["nonzero_exit"]. Replace stats with your declared output key; format names are lowercase.
success_criteria and validation_method use only these executable assertion types:
exists, non_empty, parseable, glob_non_empty, figure_manifest, visual_review,
table_columns, unique_column, row_count. Every mapping needs type and target;
table_columns needs a nonempty columns string array, unique_column needs column;
table checks optionally accept a single-character delimiter. row_count min/max are
nonnegative integers (never booleans) with min <= max. parseable formats are exactly
fastq, fasta, json, yaml, tsv; omit format only for a recognized file suffix.
glob_non_empty optionally takes pattern; figure_manifest/visual_review optionally
take contract_fingerprint. No other option fields or assertion kinds are supported.
sha256, checksum, equals and file-equality are NOT executable assertion types.
Do not invent them, silently drop the verification requirement, or substitute a
weaker check. Keep required verification in the goal and identify how existing
engine evidence or an already reviewed adapter can establish it; otherwise state
the missing verification capability. failure_criteria may describe failure policy
but free text there does not create a runnable output assertion.
database is an alias-to-descriptor mapping, never a flat descriptor. Shape only:
"database":{"reference":{"logical_name":"resource-id","expected_markers":["known-marker"]}}
binds the existing command token "{database.reference}". Do not copy the example values.
Each descriptor contains expected_markers and, when supported by actual resource evidence,
logical_name, root_path, runtime_entry, version, supported_tools and consumer validation contracts.
An alias is the command binding key; logical_name is the resource identity, which may differ.
Use database:{} only when unused. Never invent paths, versions, markers or resource identities.
No install/download/index
commands in the analysis DAG. Do not invent missing package mappings, references or evidence.
Keep scientific choices identical to the visible plan. Return JSON only, without fences.
For cross-sample analysis set plan.execution_scope="cohort" and mark each step.scope as
"sample" (run once per sample) or "cohort" (run once after all sample dependencies).
Cohort command argv can contain a standalone {cohort.STEP_ID.OUTPUT_NAME} token, expanded
to all per-sample output paths; {cohort.sample_ids} expands to aligned sample IDs.
{cohort.reads}, {cohort.reads_1}, {cohort.reads_2}, {cohort.fasta} expand raw input paths.
Declare a real, reviewed adapter; do not invent scripts. Cohort metadata and statistical
parameters must be explicit frozen parameters. For raw sequence input, all samples participate
in the pilot with reduced reads; sample count is never reduced for fitting statistical models.
The persisted input manifest and input_contract.plan_authoring determine the input adapter.
For input_kind="external_cohort_tables", set these fields directly on plan:
"pilot_mode":"complete_external_cohort", "execution_scope":"cohort", "validation_strategy":"manifest_cases".
Every external-table step has "scope":"cohort". Consume every manifest.cohort_artifacts role
through a step.input value "{runtime.cohort_ROLE}" with the exact declared role substituted;
e.g. role "records" means "{runtime.cohort_records}", NOT "{runtime.records}".
For input_kind="completed_run_artifacts", set plan.pilot_mode="complete_derived_samples",
plan.execution_scope="cohort" and plan.validation_strategy="manifest_cases". Shared artifact roles
use {runtime.cohort_ROLE}; per-sample artifact roles use {runtime.ROLE} in sample-scoped steps
or standalone {cohort.ROLE} argv tokens in cohort steps. Use only declared roles.
Both complete-input modes validate the entire declared artifact set without sequence sampling
or a read fraction. These are top-level plan fields, never requirements-only fields,
step.parameters or invented steps. manifest_cases is the engine's validation strategy, not
a tool name or a task to add to the DAG. The engine produces its own validation, freeze and
execution receipts; do not fabricate them as analysis step outputs. Preserve actual user
analysis deliverables, inputs, tools and parameters while correcting adapter fields.
"""
