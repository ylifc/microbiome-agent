"""Deterministic project maintenance, independent of planning and scientific runs.

Only controller-created draft/scratch files are mutable through this interface.
An artifact registration is a persistent, narrowly scoped grant; arbitrary paths
and model-supplied ownership assertions are never accepted as grants.  Existing
scientific outputs remain under the pipeline's own lifecycle services.
"""
from __future__ import annotations

import contextlib
import hashlib
import json
import os
import re
import stat
import uuid
from datetime import UTC, datetime
from pathlib import Path

from microbiome.pipeline.errors import ConfigurationError
from microbiome.pipeline.io import object_fingerprint
from microbiome.pipeline.locking import maintenance_registry_lock, project_operation_lock
from microbiome.pipeline.maintenance_contract import load_maintenance_contract, operation_schema, validate_maintenance_request
from microbiome.pipeline.maintenance_read import diagnostic_descriptors, effective_paths, list_directory, page_records, read_artifact, read_diagnostic
from microbiome.pipeline.project import PipelineProject
from microbiome.pipeline.state import LifecycleState, ProjectStateMachine

MAX_TEXT_BYTES = 4 * 1024 * 1024
MAX_EXPORT_BYTES = 32 * 1024 * 1024
_FROZEN = {
    "PRETEST_PASSED", "VALIDATED", "PRETEST_FINALIZING", "FROZEN", "PIPELINE_LOCK_VALIDATING",
    "PRODUCTION_READY", "AWAITING_PRODUCTION_APPROVAL", "PRODUCTION_APPROVED", "PRODUCTION_PREFLIGHT",
    "PRODUCTION_RUNNING", "PRODUCTION_FAILED", "COMPLETED",
}
_BUSY = {"PRETEST_RUNNING", "PRODUCTION_PREFLIGHT", "PRODUCTION_RUNNING", "PRETEST_FINALIZING"}
_READ_OPERATIONS = {"inspect", "list_directory", "read_artifact", "read_diagnostic"}


def _now():
    return datetime.now(UTC).isoformat()


def _reject(message):
    raise ConfigurationError(message)


@contextlib.contextmanager
def _parent_fd(path: Path, *, create=False):
    """Walk using openat/O_NOFOLLOW so checking a path does not grant its links."""
    path = Path(os.path.abspath(path))
    fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY)
    try:
        for part in path.parts[1:-1]:
            if create:
                try:
                    os.mkdir(part, mode=0o700, dir_fd=fd)
                except FileExistsError:
                    pass
            following = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = following
        yield fd, path.name
    except OSError as exc:
        raise ConfigurationError(f"UNSAFE_PATH: cannot safely access {path}: {exc.strerror}") from exc
    finally:
        os.close(fd)


def _file_info(path: Path):
    try:
        with _parent_fd(path) as (fd, name):
            try:
                info = os.stat(name, dir_fd=fd, follow_symlinks=False)
            except FileNotFoundError:
                return None
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                _reject(f"UNSAFE_PATH: expected a regular file with one link: {path}")
            return info
    except ConfigurationError:
        # A missing parent means a new file, but links and inaccessible parents
        # must remain errors. lstat each existing component to distinguish them.
        for parent in reversed(path.parents):
            if parent.is_symlink():
                raise
            if not parent.exists():
                return None
        raise


def _read_bytes(path: Path, *, limit=MAX_EXPORT_BYTES):
    with _parent_fd(path) as (parent, name):
        fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=parent)
        with os.fdopen(fd, "rb") as handle:
            info = os.fstat(handle.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size > limit:
                _reject(f"UNSAFE_FILE: unsupported or oversized file: {path}")
            content = handle.read(limit + 1)
            if len(content) > limit:
                _reject(f"FILE_TOO_LARGE: {path}")
            return content


def _atomic_bytes(path: Path, content: bytes, *, replace: bool):
    with _parent_fd(path, create=True) as (parent, name):
        temporary = f".{name}.{uuid.uuid4().hex}.tmp"
        fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=parent)
        try:
            with os.fdopen(fd, "wb") as handle:
                handle.write(content)
                handle.flush()
                os.fsync(handle.fileno())
            if replace:
                # Existing target has already been ownership/fingerprint checked.
                os.replace(temporary, name, src_dir_fd=parent, dst_dir_fd=parent)
            else:
                # link+unlink is a no-clobber publication on the same filesystem.
                os.link(temporary, name, src_dir_fd=parent, dst_dir_fd=parent, follow_symlinks=False)
                os.unlink(temporary, dir_fd=parent)
            os.fsync(parent)
        finally:
            try:
                os.unlink(temporary, dir_fd=parent)
            except FileNotFoundError:
                pass


def _save(path, value):
    if path.exists() or path.is_symlink():
        _file_info(path)
    _atomic_bytes(path, (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode(), replace=path.exists())


def _read_json(path):
    try:
        value = json.loads(_read_bytes(path, limit=3 * MAX_EXPORT_BYTES))
    except (ValueError, UnicodeError) as exc:
        raise ConfigurationError(f"INVALID_MAINTENANCE_RECORD: {path}") from exc
    if not isinstance(value, dict):
        _reject(f"INVALID_MAINTENANCE_RECORD: {path}")
    return value


def _sha(path):
    digest = hashlib.sha256()
    with _parent_fd(path) as (parent, name):
        descriptor = os.open(name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=parent)
        with os.fdopen(descriptor, "rb") as handle:
            info = os.fstat(handle.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                _reject(f"UNSAFE_FILE: {path}")
            while chunk := handle.read(1024 * 1024):
                digest.update(chunk)
    return digest.hexdigest()


def _registry(project):
    path = project.state_dir / "maintenance" / "registry.json"
    registry = _read_json(path) if path.exists() or path.is_symlink() else {
        "schema_version": 1, "project": str(project.root), "revision": 0,
        "artifacts": {}, "completed_requests": {},
    }
    if (registry.get("project") != str(project.root) or registry.get("schema_version") != 1
            or not isinstance(registry.get("artifacts"), dict)
            or type(registry.get("revision")) is not int):
        _reject("INVALID_MAINTENANCE_REGISTRY")
    return path, registry


def _live_jobs(project):
    """Do not equate a terminal receipt with the absence of surviving children."""
    from microbiome.integrations.jobs import _dead_worker_evidence
    active = []
    for path in sorted((project.state_dir / "portable" / "jobs").glob("*/status.json")):
        record = _read_json(path)
        process = path.parent / "process.json"
        if process.is_file():
            try:
                _dead_worker_evidence(_read_json(process))
            except ConfigurationError:
                active.append(path.parent.name)
        elif record.get("status") not in {"completed", "failed", "cancelled", "interrupted"}:
            active.append(path.parent.name)
    return active


def _policy(project, phase, active):
    frozen = phase in _FROZEN or project.pipeline_lock_path.exists()
    busy = phase in _BUSY or bool(active)
    return {
        "phase": phase, "frozen_contract": frozen, "active_jobs": active,
        "allowed_actions": {
            "inspect": True, "export": True, "write_draft": True,
            "list_directory": True, "read_artifact": True, "read_diagnostic": True,
            "write_scratch": not frozen and not busy,
            "cleanup": not busy, "repair_input": not busy,
            "planning_policy": True,
        },
        "protected_roles": ["raw_input", "ready_resource", "environment", "frozen_lock", "approval",
                            "registry", "scientific_result", "unregistered_file"],
        "write_roots": {"draft": str(project.output_root / ".agent-workspace" / "drafts"),
                        "scratch": str(project.output_root / ".agent-workspace" / "scratch")},
        "cleanup_scope": "registered unchanged drafts, workspace scratch and controller-owned failed-process scratch only; scratch may be purged; drafts may be quarantined/restored",
        "scientific_contract_changes": "Use versioned pipeline services and their existing approvals",
        "parameters": {name: list(operation_schema(name)["properties"])
                       for name in load_maintenance_contract()["operations"]},
    }


def permission_snapshot(project):
    """Expose the same effective stage policy used by maintenance execution."""
    if not isinstance(project, PipelineProject):
        project = PipelineProject(project)
    return _policy(project, ProjectStateMachine(project).current.value, _live_jobs(project))


def _inspect(project, args, registry, policy):
    """Compact current facts; larger sections and files have explicit readers."""
    conversation_path = project.state_dir / "conversation.json"
    conversation = _read_json(conversation_path) if conversation_path.is_file() else {}
    pending = []
    for path in sorted((project.state_dir / "maintenance" / "requests").glob("*.json")):
        entry = _read_json(path)
        if entry.get("status") == "PREPARED" and path.stem not in registry["completed_requests"]:
            item = {key: entry[key] for key in ("request_id", "operation", "created_at", "source_message_id", "session_id", "expected_revision") if key in entry}
            item["request"] = {"operation": "read_artifact", "arguments": {"root": "project", "path": str(path.relative_to(project.root))}}
            pending.append(item)
    descriptors = diagnostic_descriptors(project)
    blocker = conversation.get("input_blocker") or {}
    section = args.get("section", "summary")
    artifact_rows = sorted(registry["artifacts"].values(), key=lambda row: row["artifact_id"])
    result = {"ok": True, "operation": "inspect", "section": section, "project": str(project.root),
              "revision": registry["revision"], "phase": policy["phase"], "reused": False, "read_only": True}
    if section == "permissions":
        return {**result, "policy": policy, "operation_contracts": {name: operation_schema(name) for name in load_maintenance_contract()["operations"]}}
    from microbiome.pipeline.diagnostic_snapshot import diagnostic_snapshot, input_status_snapshot
    inputs = input_status_snapshot(project, conversation)
    input_state = {**inputs["state"], "input_blocker": {
        key: blocker[key] for key in ("code", "condition_fingerprint", "retryable", "retry_when", "supported_repair") if key in blocker
    } if descriptors["input_resolution"]["current"] else None}
    if section in {"artifacts", "pending", "input"}:
        rows = artifact_rows if section == "artifacts" else pending if section == "pending" else blocker.get("candidate_paths", []) if descriptors["input_resolution"]["current"] else inputs["rows"]
        return {**result, "input_state": input_state, "diagnostics": descriptors,
                **page_records(rows, args, binding=["inspect", str(project.root), section])}
    if args.get("cursor"):
        raise ConfigurationError("INVALID_CURSOR: summary has no continuation; select a paginated section")
    from microbiome.agent.recovery import planning_recovery_snapshot
    from microbiome.integrations.capabilities import runtime_capabilities

    capabilities = runtime_capabilities(project)
    # The host already receives full tool schemas. Keep this frequently read
    # summary compact; the capability endpoint remains the complete contract.
    for contract in capabilities["contracts"].values():
        contract.pop("operation_schemas", None)
    capabilities["detail_request"] = {"operation": "runtime.capabilities", "arguments": {"project": str(project.root)}}
    recovery = planning_recovery_snapshot(project)
    snapshot = diagnostic_snapshot(project, conversation=conversation, policy=policy,
                                   recovery=recovery, descriptors=descriptors, input_snapshot=inputs)
    limit = min(args.get("limit", 20), 20)
    return {**result, "policy": policy, "effective_paths": effective_paths(project), "diagnostics": descriptors,
            "runtime_capabilities": capabilities,
            "planning_recovery": recovery, "diagnostic_snapshot": snapshot,
            "input_state": input_state, "artifacts": {row["artifact_id"]: row for row in artifact_rows[:limit]},
            "artifact_count": len(artifact_rows), "artifacts_truncated": len(artifact_rows) > limit,
            "pending_operations": pending[:limit], "pending_count": len(pending), "pending_truncated": len(pending) > limit,
            "inventory": {"scope": str(project.root), "directory_deletion_authorized": False,
                          "read": {"operation": "list_directory", "arguments": {"root": "project", "path": "."}}},
            "next_actions": [snapshot["next_action"]]}


def _draft_path(project, args, policy):
    role = args.get("role", "draft")
    if role not in {"draft", "scratch"}:
        _reject("UNSUPPORTED_ROLE: only draft or scratch")
    if not policy["allowed_actions"]["write_scratch" if role == "scratch" else "write_draft"]:
        _reject("PHASE_DENIED: scratch writes are unavailable in this lifecycle")
    relative = Path(args.get("path", ""))
    if not str(relative) or str(relative) == "." or relative.is_absolute() or any(x in {".", ".."} for x in relative.parts):
        _reject("PATH_SCOPE_DENIED: path must be relative to the managed role directory")
    target = Path(policy["write_roots"][role]) / relative
    _file_info(target)
    content = args.get("content")
    if not isinstance(content, str) or len(content.encode()) > MAX_TEXT_BYTES:
        _reject("INVALID_CONTENT: expected UTF-8 text no larger than 4 MiB")
    return role, target, content.encode()


def _owned(registry, artifact_id, project):
    artifact = registry["artifacts"].get(artifact_id)
    if not artifact or artifact.get("owner_project") != str(project.root):
        _reject("OWNERSHIP_REQUIRED: unknown artifact")
    role = artifact.get("role")
    if role not in {"draft", "scratch", "export"}:
        _reject("PROTECTED_ARTIFACT: unsupported cleanup role")
    # Ownership records cannot grant access outside the designated workspace.
    if role in {"draft", "scratch"}:
        root = project.output_root / ".agent-workspace" / ("drafts" if role == "draft" else "scratch")
        runtime_failed = (artifact.get("origin") == "failed_process" and role == "scratch"
                          and Path(artifact["path"]).is_relative_to(project.output_root)
                          and "failed_process_outputs" in Path(artifact["path"]).relative_to(project.output_root).parts)
        if not Path(artifact["path"]).is_relative_to(root) and not runtime_failed:
            _reject("INVALID_ARTIFACT_SCOPE")
    return artifact


def _verify_file(path, artifact):
    if _file_info(path) is None or _sha(path) != artifact["sha256"]:
        _reject(f"ARTIFACT_DRIFT: expected unchanged owned file: {path}")


@contextlib.contextmanager
def created_artifact_scope(project, directory, *, role="scratch", run_id: str, attempt_id: str):
    """Trusted runner provenance for a freshly created failed-output directory.

    This is deliberately not an agent tool. The runner enters before creating
    its unique directory, and only files actually created within that scope
    gain cleanup ownership. Unknown pre-existing files can never be adopted.
    The controller's diagnostic logs remain outside this deletable directory.
    """
    if not isinstance(project, PipelineProject):
        project = PipelineProject(project)
    directory = Path(os.path.abspath(directory))
    if (role != "scratch" or not run_id or not attempt_id or not directory.is_relative_to(project.output_root)
            or "failed_process_outputs" not in directory.relative_to(project.output_root).parts):
        _reject("INVALID_RUNTIME_OWNERSHIP_SCOPE")
    if directory.exists() or directory.is_symlink():
        _reject("OWNERSHIP_REQUIRED: runtime directory must be new")
    _file_info(directory / ".ownership-probe")
    try:
        yield directory
    finally:
        if directory.exists():
            if directory.is_symlink():
                _reject("UNSAFE_RUNTIME_DIRECTORY")
            created = []
            for base, dirs, files in os.walk(directory, followlinks=False):
                dirs[:] = [name for name in dirs if not (Path(base) / name).is_symlink()]
                for name in sorted(files):
                    path = Path(base) / name
                    info = _file_info(path)
                    if info:
                        created.append((path, info.st_size, _sha(path)))
            if created:
                with maintenance_registry_lock(project):
                    registry_path, registry = _registry(project)
                    for path, size, digest in created:
                        identity = object_fingerprint([str(project.root), str(path)])[:32]
                        if identity in registry["artifacts"]:
                            _reject("RUNTIME_ARTIFACT_ALREADY_REGISTERED")
                        registry["artifacts"][identity] = {
                            "artifact_id": identity, "owner_project": str(project.root), "path": str(path),
                            "role": "scratch", "origin": "failed_process", "status": "ACTIVE", "sha256": digest,
                            "bytes": size, "updated_at": _now(), "run_id": run_id, "attempt_id": attempt_id,
                            "scope": ["quarantine", "restore", "purge"],
                        }
                    registry["revision"] += 1
                    _save(registry_path, registry)


def _active_artifact_references(project, artifact):
    """A scratch grant cannot override a live plan/checkpoint dependency."""
    from microbiome.pipeline.io import read_yaml
    records = []
    conversation = project.state_dir / "conversation.json"
    if conversation.is_file():
        state = _read_json(conversation)
        records.append((str(conversation), {key: state[key] for key in
            ("planning_checkpoint", "compiler_repair", "draft", "pending_candidate") if key in state}))
    for path in (project.plan_path, project.pipeline_lock_path):
        if path.is_file():
            records.append((str(path), read_yaml(path)))
    paths = project.load_config()["paths"]
    # Match only the fixed root variables accepted by render_step. Other
    # placeholders remain unresolved; this never evaluates arbitrary templates.
    roots = {"output_root": paths["output"], "raw_data_path": paths["raw_data"],
             "database_root": paths["database"]}
    targets = [Path(artifact[key]).resolve() for key in ("path", "quarantine_path") if artifact.get(key)]

    directory_fields = {
        "input", "input_template", "input_files", "runtime_inputs", "source_files",
        "input_directory", "input_root", "input_roots", "source_directory",
        "command", "command_template", "exact_command_line", "argv", "script_template",
        "parameters", "parameter_list", "runtime_environment",
        "evidence", "evidence_path", "evidence_dir", "path", "directory", "directories",
    }

    def references_path(value, *, directories):
        for name, root in roots.items():
            value = value.replace("{" + name + "}", root)
        if any(str(target) in value for target in targets):
            return True
        candidates = [value.strip().strip("\"'`"), value.split("=", 1)[-1].strip().strip("\"'`")]
        candidates.extend(match.group(2) for match in re.finditer(r'''(["'`])(/.*?)\1''', value))
        candidates.extend(re.findall(r'''/[^\s"'`<>{}\[\],;()]+''', value))
        for candidate in candidates:
            if not candidate.startswith("/") or "{" in candidate or "}" in candidate:
                continue
            normalized = Path(candidate).resolve()
            if any(normalized == target or (directories and normalized in target.parents) for target in targets):
                return True
        return False

    def mentions(value, *, directories=False):
        if isinstance(value, str):
            # Pending compiler candidates can be retained as JSON text,
            # including escaped slashes, rather than an already parsed object.
            if value.lstrip().startswith(("{", "[")):
                try:
                    decoded = json.loads(value)
                except (ValueError, RecursionError):
                    pass
                else:
                    if isinstance(decoded, (dict, list)) and mentions(decoded, directories=directories):
                        return True
            return references_path(value, directories=directories)
        if isinstance(value, dict):
            # Roots in project_paths/input_exclusion_roots are metadata, not
            # a dependency on every child. Exact artifact paths remain guarded
            # everywhere; ancestor-directory checks require a dependency field.
            return any(mentions(k, directories=directories)
                       or mentions(v, directories=directories or k in directory_fields) for k, v in value.items())
        if isinstance(value, list):
            return any(mentions(v, directories=directories) for v in value)
        return False
    return [path for path, record in records if mentions(record)]


def _prepare_cleanup(project, args, registry):
    action = args.get("action", "preview")
    if action not in {"preview", "quarantine", "restore", "purge"}:
        _reject("INVALID_CLEANUP_ACTION")
    ids = args.get("artifact_ids", [])
    paths = args.get("paths", [])
    if not isinstance(ids, list) or not isinstance(paths, list) or bool(ids) == bool(paths):
        _reject("Supply exactly one nonempty artifact_ids or paths list")
    if paths:
        mapping = {item["path"]: key for key, item in registry["artifacts"].items()}
        if any(not isinstance(value, str) or value not in mapping for value in paths):
            _reject("OWNERSHIP_REQUIRED: every path must exactly match a registered artifact")
        ids = [mapping[value] for value in paths]
    if any(not isinstance(value, str) for value in ids) or len(set(ids)) != len(ids) or len(ids) > 100:
        _reject("INVALID_ARTIFACT_SELECTION")
    plan = []
    for identity in ids:
        artifact = _owned(registry, identity, project)
        if action != "restore":
            references = _active_artifact_references(project, artifact)
            if references:
                _reject("ARTIFACT_IN_USE: active plan or checkpoint references this artifact: " + ", ".join(references))
        if artifact["role"] == "export" or artifact["status"] == "PURGED":
            _reject("PROTECTED_ARTIFACT: exports and purged artifacts cannot be cleaned")
        if action == "purge" and artifact["role"] != "scratch":
            _reject("PURGE_SCOPE_DENIED: only registered scratch files may be permanently deleted")
        quarantined = artifact["status"] == "QUARANTINED"
        if action == "restore" and not quarantined:
            _reject("RESTORE_REQUIRES_QUARANTINE")
        if action == "quarantine" and quarantined:
            _reject("ARTIFACT_ALREADY_QUARANTINED")
        source = Path(artifact["quarantine_path"] if quarantined else artifact["path"])
        _verify_file(source, artifact)
        destination = (Path(artifact["path"]) if action == "restore" else
                       project.output_root / ".agent-workspace" / "quarantine" / identity)
        if action in {"restore", "quarantine"} and _file_info(destination) is not None:
            _reject(f"DESTINATION_EXISTS: {destination}")
        if action in {"restore", "quarantine"}:
            parent = destination.parent
            while not parent.exists():
                parent = parent.parent
            if source.stat().st_dev != parent.stat().st_dev:
                _reject("CROSS_DEVICE_CLEANUP_UNSUPPORTED: quarantine requires the same filesystem; no files changed")
        plan.append({"artifact_id": identity, "source": str(source), "destination": str(destination),
                     "sha256": artifact["sha256"], "bytes": artifact["bytes"], "role": artifact["role"]})
    return action, plan


def _move_no_replace(source, destination):
    with _parent_fd(source) as (src, source_name), _parent_fd(destination, create=True) as (dst, dest_name):
        # Atomic no-overwrite publication; a crash between link/unlink is
        # explicitly recovered by the transaction's inode check below.
        os.link(source_name, dest_name, src_dir_fd=src, dst_dir_fd=dst, follow_symlinks=False)
        os.unlink(source_name, dir_fd=src)
        os.fsync(src)
        os.fsync(dst)


def _apply_cleanup(registry, action, plan):
    for item in plan:
        source, destination = Path(item["source"]), Path(item["destination"])
        artifact = registry["artifacts"][item["artifact_id"]]
        if action == "purge":
            if source.exists() or source.is_symlink():
                _verify_file(source, artifact)
                with _parent_fd(source) as (parent, name):
                    os.unlink(name, dir_fd=parent)
                    os.fsync(parent)
            artifact["status"] = "PURGED"
        else:
            if source.exists() and destination.exists():
                # The only allowed two-link object is our interrupted move,
                # proven by both endpoints sharing exactly the same inode.
                left, right = source.lstat(), destination.lstat()
                if (not stat.S_ISREG(left.st_mode) or (left.st_dev, left.st_ino) != (right.st_dev, right.st_ino)
                        or left.st_nlink != 2):
                    _reject("DESTINATION_EXISTS: refusing to overwrite during recovery")
                with _parent_fd(source) as (parent, name):
                    os.unlink(name, dir_fd=parent)
            if source.exists() or source.is_symlink():
                _verify_file(source, artifact)
                _move_no_replace(source, destination)
            _verify_file(destination, artifact)
            artifact["status"] = "ACTIVE" if action == "restore" else "QUARANTINED"
            artifact["quarantine_path"] = None if action == "restore" else str(destination)
        artifact["updated_at"] = _now()


_SENSITIVE_KEY = re.compile(r"(?:api[_-]?key|password|passwd|secret|access[_-]?token|refresh[_-]?token|authorization|credential|(?:^|[_-])tokens?$)", re.I)
_SECRET_VALUE = re.compile(r"(?i)((?:api[_-]?key|password|passwd|secret|access[_-]?token|refresh[_-]?token|token|authorization)[\"']?\s*[=:]\s*[\"']?)([^\s\"',;}]+)")


def _redact(value):
    if isinstance(value, dict):
        return {key: "[REDACTED]" if _SENSITIVE_KEY.search(str(key)) else _redact(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_redact(item) for item in value]
    if isinstance(value, str):
        value = re.sub(r"(?i)\b(Bearer|Basic)\s+\S+", r"\1 [REDACTED]", value)
        value = re.sub(r"([a-zA-Z][a-zA-Z0-9+.-]*://)[^/\s@]+@", r"\1[REDACTED]@", value)
        value = _SECRET_VALUE.sub(r"\1[REDACTED]", value)
        value = re.sub(r"\bsk-[A-Za-z0-9_-]{12,}\b", "[REDACTED]", value)
        value = re.sub(r"-----BEGIN [^-]*PRIVATE KEY-----.*?-----END [^-]*PRIVATE KEY-----", "[REDACTED PRIVATE KEY]", value, flags=re.S)
        return value
    return value


def _export_payload(project, host_events):
    paths = [project.state_dir / "conversation.json", project.decision_log_path,
             project.requirements_path, project.lifecycle_state_path]
    for pattern in ("harness/*.json", "portable/jobs/*/request.json", "portable/jobs/*/status.json",
                    "portable/jobs/*/result.json", "maintenance/requests/*.json"):
        paths.extend(sorted(project.state_dir.glob(pattern)))
    documents, omitted, total = [], [], 0
    for path in dict.fromkeys(paths):
        if not path.exists() and not path.is_symlink():
            continue
        try:
            raw = _read_bytes(path, limit=MAX_TEXT_BYTES)
            total += len(raw)
            if total > MAX_EXPORT_BYTES:
                omitted.append({"path": str(path), "reason": "export size limit"})
                continue
            text = raw.decode("utf-8")
            if path.suffix == ".json":
                content = _redact(json.loads(text))
            else:
                content = _redact(text)
            documents.append({"path": str(path), "content": content,
                              "export_content_sha256": object_fingerprint(content)})
        except (ConfigurationError, ValueError, UnicodeError) as exc:
            omitted.append({"path": str(path), "reason": str(exc)})
    integrity_events = [event for event in (host_events or [])
                        if isinstance(event, dict) and event.get("type") == "microbiome/export-integrity"]
    integrity = (integrity_events[-1].get("data", integrity_events[-1]) if integrity_events else {})
    integrity = integrity if isinstance(integrity, dict) else {}
    issues = list(integrity.get("issues", [])) if isinstance(integrity.get("issues", []), list) else ["Invalid host export-integrity issues"]
    if not integrity_events:
        issues.append("Host did not provide a visible-event export-integrity check")
    visible_complete = bool(integrity_events and integrity.get("complete") is True and not issues)
    exclusions = integrity.get("exclusions", [])
    exclusions = exclusions if isinstance(exclusions, list) else []
    excluded_types = integrity.get("excluded_types", [])
    excluded_types = [value for value in excluded_types if isinstance(value, str)] if isinstance(excluded_types, list) else []
    pending_calls = integrity.get("pending_calls", [])
    pending_calls = pending_calls if isinstance(pending_calls, list) else []
    snapshot_fingerprint = integrity.get("snapshot_fingerprint")
    snapshot_fingerprint = snapshot_fingerprint if isinstance(snapshot_fingerprint, str) and re.fullmatch(r"[a-f0-9]{64}", snapshot_fingerprint) else None
    return {"schema_version": 1, "created_at": _now(), "project": str(project.root),
            "coverage": {"project_records": "allowlisted conversation, requirement, lifecycle and tool/job receipts",
                         "host_events": "supported visible text/tool content and selected metadata supplied by the host; declared exclusions are not exported",
                         "complete": False,
                         "raw_event_complete": False,
                         "visible_host_events_complete": visible_complete,
                         "exported_scope_complete": visible_complete and not omitted,
                         "exclusions": _redact(exclusions), "excluded_types": _redact(excluded_types),
                         "pending_calls": _redact(pending_calls), "snapshot_fingerprint": snapshot_fingerprint,
                         "issues": _redact(issues),
                         "host_database_complete": False, "secrets_redacted": True,
                         "raw_data_and_environment_excluded": True, "omitted": omitted,
                         "consistency": "each available atomic project record at read time; a running job may append later events"},
            "project_records": documents, "host_events": _redact(host_events or [])}


def _export_path(project, args, user_message, identity):
    default = project.output_root / "exports" / f"conversation-{identity[:16]}.json"
    requested = args.get("destination")
    if requested is None:
        return default
    if not isinstance(requested, str) or not Path(requested).is_absolute() or ".." in Path(requested).parts:
        _reject("EXPORT_SCOPE_DENIED: destination must be an explicit absolute path")
    # This context is attributed by the calling host. Portable callers must
    # provide their actual user turn; this Python API is not an identity system.
    if requested not in user_message:
        _reject("EXPORT_SCOPE_DENIED: destination is absent from the actual user message")
    path = Path(requested)
    if path.is_dir():
        path = path / default.name
    elif path.suffix != ".json":
        _reject("EXPORT_DESTINATION: supply an existing directory or a new .json file")
    # Explicit export authorization must never open the scientific/control plane
    # to arbitrary writes, even when an output root is nested under raw inputs.
    protected = [project.state_dir, project.config_dir, project.pipeline_dir, project.requirements_dir,
                 project.runs_dir, project.pretest_dir]
    config = project.load_config()["paths"]
    protected.append(Path(config["database"]))
    raw = Path(config["raw_data"])
    if (any(path == base or path.is_relative_to(base) for base in protected)
            or (path.is_relative_to(raw) and not path.is_relative_to(project.output_root))
            or path in {project.config_path, project.plan_path, project.lifecycle_state_path}):
        _reject("EXPORT_SCOPE_DENIED: protected destination")
    _file_info(path)
    return path


def execute_maintenance(project, operation, arguments, *, user_message, message_id, session_id, host_events=None):
    """Execute one host-attributed maintenance request and return its durable receipt.

    ``expected_revision`` is an optional optimistic concurrency check. Retrying an
    identical request after interruption resumes its persisted operation manifest;
    changing its parameters requires a new request id. Cleanup accepts registered
    ``artifact_ids`` (preferred) or exact registered ``paths``. Export emits JSON.
    """
    if not isinstance(project, PipelineProject):
        project = PipelineProject(project)
    arguments = validate_maintenance_request(operation, arguments)
    for name, value in (("user_message", user_message), ("message_id", message_id), ("session_id", session_id)):
        if not isinstance(value, str) or not value.strip():
            _reject(f"USER_CONTEXT_REQUIRED: {name}")
    args = dict(arguments)
    request_id = args.pop("request_id", object_fingerprint([session_id, message_id, operation]))
    if not isinstance(request_id, str) or not 1 <= len(request_id) <= 200:
        _reject("INVALID_REQUEST_ID")
    expected = args.pop("expected_revision", None)
    if expected is not None and (type(expected) is not int or expected < 0):
        _reject("INVALID_EXPECTED_REVISION")
    # Explicit request ids remain usable after a host reconnect or a new user
    # turn. Original attribution/authorization is retained in the journal.
    identity = object_fingerprint([str(project.root), operation, request_id])
    request_hash = object_fingerprint({"operation": operation, "arguments": args, "expected_revision": expected})
    with contextlib.ExitStack() as locks:
        # Lock order is project operation, then disjoint maintenance metadata.
        # Drafts, exports and inspection are useful while a long job runs.
        if operation in {"cleanup", "repair_input"} or (operation == "write_draft" and args.get("role") == "scratch") or (operation == "planning_policy" and args.get("action") in {"apply", "rollback"}):
            locks.enter_context(project_operation_lock(project))
        locks.enter_context(maintenance_registry_lock(project))
        phase = ProjectStateMachine(project).current.value
        registry_path, registry = _registry(project)
        request_path = project.state_dir / "maintenance" / "requests" / f"{identity}.json"
        prior = _read_json(request_path) if request_path.exists() or request_path.is_symlink() else None
        if prior and prior["request_fingerprint"] != request_hash:
            _reject("REQUEST_ID_CONFLICT: request already identifies different arguments")
        completed = registry.get("completed_requests", {}).get(identity)
        if completed:
            return {**completed, "reused": True}
        if expected is not None and expected != registry["revision"] and prior is None:
            _reject(f"REVISION_CONFLICT: expected {expected}, current {registry['revision']}")
        active = _live_jobs(project)
        policy = _policy(project, phase, active)
        if not policy["allowed_actions"][operation]:
            _reject(f"PROJECT_BUSY: {operation} is unavailable while execution is active")
        if operation == "inspect":
            return _inspect(project, args, registry, policy)
        if operation == "planning_policy" and args.get("action", "inspect") in {"inspect", "estimate"}:
            from microbiome.pipeline.planning_policy import inspect_policy, estimate_policy
            view = estimate_policy(project) if args.get("action") == "estimate" else inspect_policy(project)
            if "revision" in view:
                view["policy_revision"] = view.pop("revision")
            return {"ok": True, "operation": operation, "project": str(project.root),
                    "revision": registry["revision"], "reused": False, "read_only": True, **view}
        if operation in _READ_OPERATIONS:
            result = (list_directory(project, args) if operation == "list_directory" else
                      read_artifact(project, args, redact=_redact) if operation == "read_artifact" else
                      read_diagnostic(project, args, redact=_redact))
            return {"ok": True, "operation": operation, "project": str(project.root),
                    "revision": registry["revision"], "reused": False, **result}
        # Prevent another mutation from invalidating an interrupted operation's
        # prepared manifest. Retrying the identical request remains authorized.
        for path in (project.state_dir / "maintenance" / "requests").glob("*.json"):
            if path == request_path:
                continue
            entry = _read_json(path)
            if entry.get("status") == "PREPARED" and path.stem not in registry["completed_requests"]:
                _reject(f"MAINTENANCE_RECOVERY_REQUIRED: retry request {entry.get('request_id')}")
        prepared = prior or {"schema_version": 1, "request_id": request_id, "request_fingerprint": request_hash,
                             "operation": operation, "status": "PREPARED", "phase": phase,
                             "source_message_id": message_id, "session_id": session_id, "created_at": _now(),
                             "user_message": user_message, "arguments": args, "expected_revision": expected}
        result = {}
        if operation == "planning_policy":
            from microbiome.pipeline.planning_policy import update_policy
            _save(request_path, prepared)
            try:
                result = update_policy(project, changes=args.get("changes"),
                    expected_policy_revision=args["expected_policy_revision"], request_id=identity,
                    rollback_revision=args.get("rollback_revision"))
                if "revision" in result:
                    result["policy_revision"] = result.pop("revision")
            except ConfigurationError as error:
                # A rejected technical adjustment must not strand the entire
                # maintenance journal in PREPARED state.
                prepared.update(status="REJECTED", diagnostic=getattr(error, "details", {"message": str(error)}))
                _save(request_path, prepared)
                raise
            result["next_action"] = {"operation": "inspect", "reason": "Refresh planning recovery token after an effective policy change"}
        elif operation == "write_draft":
            role, target, content = _draft_path(project, args, policy)
            artifact_id = object_fingerprint([str(project.root), str(target)])[:32]
            existing = registry["artifacts"].get(artifact_id)
            desired_sha = hashlib.sha256(content).hexdigest()
            if existing and existing["status"] != "ACTIVE":
                _reject("ARTIFACT_NOT_ACTIVE: restore before modifying")
            if target.exists():
                if existing:
                    if not (prior and _sha(target) == desired_sha):
                        _verify_file(target, existing)
                elif not (prior and prior.get("target") == str(target) and _sha(target) == desired_sha):
                    _reject("OWNERSHIP_REQUIRED: refusing to overwrite an unregistered file")
            prepared.update(target=str(target), sha256=desired_sha)
            _save(request_path, prepared)
            _atomic_bytes(target, content, replace=bool(existing) or bool(prior and target.exists()))
            registry["artifacts"][artifact_id] = {
                "artifact_id": artifact_id, "owner_project": str(project.root), "path": str(target), "role": role,
                "status": "ACTIVE", "sha256": desired_sha, "bytes": len(content), "updated_at": _now(),
                "source_message_id": message_id, "session_id": session_id,
                "scope": ["update", "quarantine", "restore"] + (["purge"] if role == "scratch" else []),
            }
            result = {"artifact_id": artifact_id, "path": str(target), "sha256": desired_sha}
        elif operation == "cleanup":
            if prior:
                action, plan = prior["action"], prior["plan"]
                if action != "restore":
                    for item in plan:
                        if _active_artifact_references(project, _owned(registry, item["artifact_id"], project)):
                            _reject("ARTIFACT_IN_USE: active plan or checkpoint references an interrupted cleanup target")
            else:
                action, plan = _prepare_cleanup(project, args, registry)
            if action == "preview":
                return {"ok": True, "operation": operation, "action": action, "plan": plan,
                        "revision": registry["revision"], "reused": False}
            prepared.update(action=action, plan=plan)
            _save(request_path, prepared)
            _apply_cleanup(registry, action, plan)
            result = {"action": action, "plan": plan, "recoverable": action != "purge"}
        elif operation == "repair_input":
            declaration = args.get("declaration")
            structured_input = args.get("selection")
            if declaration is not None and (not declaration.strip() or len(declaration.encode()) > 65536):
                _reject("INPUT_DECLARATION_REQUIRED")
            from microbiome.agent.workflow import ConversationWorkflow
            workflow = ConversationWorkflow(project)
            source_id = "maintenance:" + object_fingerprint([
                prepared["session_id"], prepared["source_message_id"], prepared["request_id"]])
            ledger = workflow.state.get("input_declarations") or {"revision": 0, "records": []}
            # Finish a pre-upgrade interrupted transaction under its original
            # provenance id; new attempts use the per-request revision id.
            if prior:
                legacy_id = "maintenance:" + object_fingerprint([prepared["session_id"], prepared["source_message_id"]])
                legacy = next((item for item in ledger["records"] if item["source_message_id"] == legacy_id), None)
                if (legacy and legacy.get("declaration") == (declaration.strip() if declaration is not None else None)
                        and legacy.get("structured_input") == structured_input):
                    source_id = legacy_id
            old = next((item for item in ledger["records"] if item["source_message_id"] == source_id), None)
            expected_input = args.get("expected_input_revision")
            if old and (old.get("declaration") != (declaration.strip() if declaration is not None else None)
                        or old.get("structured_input") != structured_input):
                _reject("INPUT_SOURCE_CONFLICT: one source message cannot submit different declarations")
            if not old and expected_input is not None and (type(expected_input) is not int or expected_input != ledger["revision"]):
                _reject(f"INPUT_REVISION_CONFLICT: current input revision is {ledger['revision']}")
            _save(request_path, prepared)
            # Its source-message revision is itself idempotent; the workflow
            # method owns all scientific state validation and invalidation.
            result = workflow.repair_input_declaration(
                declaration, selection=structured_input, source_message_id=source_id, expected_revision=expected_input)
            result = {"input_revision": result["revision"], **{key: value for key, value in result.items() if key != "revision"}}
            result["next_action"] = ({"operation": "inspect", "arguments": {"section": "input"},
                                      "reason": "pending_change", "requires_new_user_message": False}
                                     if result.get("status") == "PENDING_CHANGE" else
                                     {"operation": "resume_planning", "requires_new_user_message": False,
                                      "approval_replayed": False} if result.get("resume_ready") else
                                     {"operation": "read_diagnostic", "arguments": {"diagnostic_id": "input_resolution"},
                                      "requires_new_user_message": False})
        else:
            target = _export_path(project, args, prepared["user_message"], identity)
            if prior:
                content = bytes.fromhex(prior["payload_hex"])
            else:
                payload = _export_payload(project, host_events)
                content = (json.dumps(payload, ensure_ascii=False, indent=2) + "\n").encode()
                if len(content) > MAX_EXPORT_BYTES:
                    _reject("EXPORT_TOO_LARGE: narrow the visible host event selection")
            digest = hashlib.sha256(content).hexdigest()
            if target.exists() and not (prior and prior.get("target") == str(target) and _sha(target) == digest):
                _reject("DESTINATION_EXISTS: export never overwrites an existing file")
            prepared.update(target=str(target), payload_hex=content.hex(), sha256=digest)
            _save(request_path, prepared)
            if not target.exists():
                _atomic_bytes(target, content, replace=False)
            artifact_id = object_fingerprint([str(project.root), str(target)])[:32]
            registry["artifacts"][artifact_id] = {"artifact_id": artifact_id, "owner_project": str(project.root),
                "path": str(target), "role": "export", "status": "ACTIVE", "sha256": digest,
                "bytes": len(content), "scope": [], "source_message_id": message_id, "updated_at": _now()}
            result = {"artifact_id": artifact_id, "path": str(target), "sha256": digest,
                      "coverage": json.loads(content)["coverage"]}
        registry["revision"] += 1
        receipt = {"ok": True, "operation": operation, "project": str(project.root), "revision": registry["revision"],
                   "phase": phase, "request_id": request_id, "receipt": str(request_path),
                   "source_session_id": prepared["session_id"], "source_host_message_id": prepared["source_message_id"],
                   "finished_at": _now(), "reused": False, **result}
        registry["completed_requests"][identity] = receipt
        _save(registry_path, registry)
        prepared.pop("payload_hex", None)
        prepared.update(status="COMPLETED", result=receipt)
        _save(request_path, prepared)
        return receipt
