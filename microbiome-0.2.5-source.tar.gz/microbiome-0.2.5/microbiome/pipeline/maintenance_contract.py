"""Canonical operation contracts used by Python, MCP, CLI and the host plugin."""
from __future__ import annotations

import copy
import json
import re
from pathlib import Path

from microbiome.pipeline.errors import ConfigurationError

CONTRACT_PATH = Path(__file__).with_name("maintenance_contract.json")


def load_maintenance_contract():
    return json.loads(CONTRACT_PATH.read_text(encoding="utf-8"))


def operation_schema(operation):
    contract = load_maintenance_contract()
    definition = contract["operations"].get(operation)
    if definition is None:
        return None
    result = copy.deepcopy(definition["parameters"])
    result["properties"].update(contract["common_arguments"])
    return result


def maintenance_tool_schema():
    contract = load_maintenance_contract()
    return {"type": "object", "oneOf": [
        {"type": "object", "properties": {
            "operation": {"const": name, "description": definition["description"]},
            "arguments": operation_schema(name),
        }, "required": ["operation"] + (["arguments"] if definition["parameters"].get("required") or definition["parameters"].get("oneOf") else []),
         "additionalProperties": False}
        for name, definition in contract["operations"].items()
    ]}


class MaintenanceArgumentError(ConfigurationError):
    """Machine-readable validation error safe to return before scheduling work."""
    def __init__(self, details):
        self.details = details
        super().__init__("INVALID_MAINTENANCE_ARGUMENT: " + json.dumps(details, ensure_ascii=False))

    def as_dict(self):
        return dict(self.details)


def _validate(schema, value, location="arguments"):
    errors = []
    for keyword in ("oneOf", "anyOf", "allOf"):
        if keyword in schema:
            matches = sum(not _validate(branch, value, location) for branch in schema[keyword])
            valid_combination = (matches == 1 if keyword == "oneOf" else matches >= 1 if keyword == "anyOf" else matches == len(schema[keyword]))
            if not valid_combination:
                errors.append({"field": location, "issue": keyword,
                               "expected": schema[keyword], "matched_branches": matches})
    if "not" in schema and not _validate(schema["not"], value, location):
        errors.append({"field": location, "issue": "mutually exclusive fields", "forbidden": schema["not"]})
    expected = schema.get("type")
    valid = {"object": isinstance(value, dict), "array": isinstance(value, list),
             "string": isinstance(value, str), "integer": type(value) is int}.get(expected, True)
    if not valid:
        return [{"field": location, "expected": expected, "observed": type(value).__name__}]
    if "const" in schema and value != schema["const"]:
        errors.append({"field": location, "expected": schema["const"], "observed": value})
    if "enum" in schema and value not in schema["enum"]:
        errors.append({"field": location, "expected": schema["enum"], "observed": value})
    if isinstance(value, dict):
        properties = schema.get("properties", {})
        errors += [{"field": f"{location}.{key}", "issue": "required"}
                   for key in schema.get("required", []) if key not in value]
        for key, item in value.items():
            if key not in properties and schema.get("additionalProperties") is False:
                errors.append({"field": f"{location}.{key}", "issue": "unknown field"})
            elif key in properties:
                errors.extend(_validate(properties[key], item, f"{location}.{key}"))
    elif expected == "array":
        if len(value) < schema.get("minItems", 0) or len(value) > schema.get("maxItems", float("inf")):
            errors.append({"field": location, "issue": "invalid array length"})
        if schema.get("uniqueItems") and len({json.dumps(item, sort_keys=True) for item in value}) != len(value):
            errors.append({"field": location, "issue": "duplicate items"})
        for index, item in enumerate(value):
            errors.extend(_validate(schema.get("items", {}), item, f"{location}[{index}]"))
    elif expected == "integer":
        if value < schema.get("minimum", float("-inf")) or value > schema.get("maximum", float("inf")):
            errors.append({"field": location, "issue": "out of range", "minimum": schema.get("minimum"), "maximum": schema.get("maximum")})
    elif expected == "string":
        if len(value) < schema.get("minLength", 0) or len(value) > schema.get("maxLength", float("inf")):
            errors.append({"field": location, "issue": "invalid string length"})
        if "pattern" in schema and not re.search(schema["pattern"], value):
            errors.append({"field": location, "issue": "invalid format", "pattern": schema["pattern"]})
    return errors


def _suggested_call(operation, arguments, definition):
    """Translate only an unambiguous old inspect read, without inventing scope."""
    if operation == "inspect" and isinstance(arguments, dict):
        path = arguments.get("path", arguments.get("file"))
        if (sum(key in arguments for key in ("path", "file")) == 1
                and arguments.get("root", "project") == "project"
                and isinstance(path, str) and path and not Path(path).is_absolute()
                and ".." not in Path(path).parts
                and len(Path(path).parts) > 1
                and Path(path).parts[0] in {"config", "state", "requirements", "pipeline"}
                and Path(path).suffix):
            return {"operation": "read_artifact", "arguments": {"root": "project", "path": path}}
        root = arguments.get("root")
        if root not in {"raw_data", "database", "output", "download", "knowledge", "project"}:
            root = "project"
        return {"operation": "list_directory", "arguments": {"root": root, "path": "."}}
    return {"operation": operation, "arguments": definition.get("example", {})}


def validate_maintenance_request(operation, arguments):
    contract = load_maintenance_contract()
    schema = operation_schema(operation) if isinstance(operation, str) else None
    errors = _validate(schema, arguments) if schema else [{"field": "operation", "issue": "unsupported operation"}]
    if isinstance(arguments, dict):
        if operation == "cleanup" and bool(arguments.get("artifact_ids")) == bool(arguments.get("paths")):
            errors.append({"field": "arguments", "issue": "supply exactly one of artifact_ids or paths"})
        if arguments.get("cursor") and any(key in arguments for key in ("offset", "snapshot")):
            errors.append({"field": "arguments.cursor", "issue": "cursor includes offset/snapshot; omit those fields"})
    if errors:
        definition = contract["operations"].get(operation, {}) if isinstance(operation, str) else {}
        raise MaintenanceArgumentError({
            "code": "INVALID_ARGUMENT", "operation": operation,
            "supported_operations": list(contract["operations"]),
            "allowed_fields": list((schema or {}).get("properties", {})),
            "required_fields": (schema or {}).get("required", []),
            "field_errors": errors, "schema": schema,
            "suggested_call": _suggested_call(operation if schema else "inspect", arguments, definition),
        })
    return copy.deepcopy(arguments)
