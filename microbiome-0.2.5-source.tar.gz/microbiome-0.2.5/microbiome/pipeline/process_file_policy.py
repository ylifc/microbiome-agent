"""Kernel-enforced file scopes for native tools, probes and approved maintenance.

The controller remains trusted. Child processes see the host filesystem read-only;
only explicit scratch/maintenance roots are writable. Pipeline outputs are built in
an isolated view and published by the controller after successful execution. No
unsandboxed fallback exists, and this policy imposes no production resource limits.
"""
from __future__ import annotations

import os
import shutil
import stat
import subprocess
import tempfile
import uuid
from contextlib import nullcontext
from pathlib import Path
from typing import Any

from microbiome.pipeline.errors import ConfigurationError


class ProcessFilePolicyError(ConfigurationError):
    """The required execution boundary could not be established."""


def _inside(path: Path, root: Path) -> bool:
    return path == root or root in path.parents


def _checked_path(value: str | Path) -> Path:
    """Reject symlink traversal rather than normalizing a writable path through it."""
    path = Path(os.path.abspath(os.path.expanduser(str(value))))
    for component in (path, *path.parents):
        if component.is_symlink():
            raise ProcessFilePolicyError(f"FILE_POLICY_SYMLINK: {component}")
    return path


def _private_environment(environment: dict[str, str] | None, scratch: Path) -> dict[str, str]:
    result = dict(os.environ if environment is None else environment)
    for name, child in {
        "HOME": "home", "TMPDIR": "tmp", "TMP": "tmp", "TEMP": "tmp",
        "XDG_CACHE_HOME": "cache", "XDG_CONFIG_HOME": "config", "XDG_DATA_HOME": "data",
        "MPLCONFIGDIR": "matplotlib", "CONDA_PKGS_DIRS": "conda-pkgs",
        "PIP_CACHE_DIR": "pip-cache",
    }.items():
        destination = scratch / child
        destination.mkdir(exist_ok=True)
        result[name] = str(destination)
    result["PYTHONDONTWRITEBYTECODE"] = "1"
    return result


def _bubblewrap() -> str:
    executable = shutil.which("bwrap")
    if not executable:
        raise ProcessFilePolicyError(
            "FILE_POLICY_UNAVAILABLE: bubblewrap (bwrap) is required; unsandboxed execution is forbidden"
        )
    return executable


def _run(argv: list[str], *, scratch: Path, cwd: Path, env: dict[str, str] | None,
         writable_roots: tuple[Path, ...] = (), readonly_roots: tuple[Path, ...] = (),
         mounts: tuple[tuple[Path, Path], ...] = (), allow_network: bool = False,
         **kwargs: Any) -> subprocess.CompletedProcess:
    if kwargs.get("shell") or kwargs.get("pass_fds") or kwargs.get("preexec_fn"):
        raise ProcessFilePolicyError("FILE_POLICY_INVALID: shell, inherited descriptors and preexec hooks are forbidden")
    command = [_bubblewrap(), "--die-with-parent", "--new-session", "--unshare-user",
               "--unshare-pid", "--unshare-ipc", "--unshare-uts", "--cap-drop", "ALL",
               "--ro-bind", "/", "/", "--proc", "/proc", "--dev", "/dev"]
    if not allow_network:
        command.append("--unshare-net")
    command.extend(["--bind", str(scratch), str(scratch)])
    for root in writable_roots:
        command.extend(["--bind", str(root), str(root)])
    for source, destination in mounts:
        command.extend(["--bind", str(source), str(destination)])
    # Apply read-only overrides last: a reference inside an approved writable
    # maintenance tree remains immutable when declared as protected.
    for root in readonly_roots:
        command.extend(["--ro-bind", str(root), str(root)])
    command.extend(["--chdir", str(cwd), "--", *map(str, argv)])
    requested_check = kwargs.pop("check", False)
    result = subprocess.run(command, env=_private_environment(env, scratch), check=False, **kwargs)
    error = result.stderr or ""
    if isinstance(error, bytes):
        error = error.decode(errors="replace")
    if result.returncode and error.startswith("bwrap:"):
        raise ProcessFilePolicyError("FILE_POLICY_UNAVAILABLE: " + error[:1000])
    if requested_check:
        result.check_returncode()
    return result


def run_scoped_process(argv: list[str], *, cwd: str | Path | None = None,
                       writable_roots: tuple[str | Path, ...] | list[str | Path] = (),
                       readonly_roots: tuple[str | Path, ...] | list[str | Path] = (),
                       env: dict[str, str] | None = None, allow_network: bool = False,
                       **kwargs: Any) -> subprocess.CompletedProcess:
    """Run a probe, or an explicitly approved maintenance command in exact roots.

    Callers must authorize maintenance before supplying writable_roots. Root scopes
    such as /tmp, /home and /usr are never admitted. Production uses run_step_process.
    """
    _bubblewrap()  # Fail before making even an ephemeral execution directory.
    writable = tuple(_checked_path(value) for value in writable_roots)
    protected = tuple(_checked_path(value) for value in readonly_roots)
    for root in writable:
        if len(root.parts) < 3 or root in {Path.home(), Path.cwd()}:
            raise ProcessFilePolicyError(f"FILE_POLICY_BROAD_SCOPE: {root}")
        if not root.is_dir():
            raise ProcessFilePolicyError(f"FILE_POLICY_MISSING_SCOPE: {root}")
    with tempfile.TemporaryDirectory(prefix=".microbiome-process-", dir=writable[0].parent if writable else None) as temporary:
        scratch = Path(temporary)
        directory = Path(cwd).absolute() if cwd is not None else scratch
        return _run(argv, scratch=scratch, cwd=directory, env=env, writable_roots=writable,
                    readonly_roots=protected, allow_network=allow_network, **kwargs)


def _view(source: Path, target: Path, outputs: list[Path], mount_args: list[tuple[Path, Path]],
          destination: Path) -> None:
    """Mirror only output ancestors; existing unrelated entries are read-only binds."""
    target.mkdir(parents=True, exist_ok=True)
    for child in source.iterdir():
        if any(child == output for output in outputs):
            continue  # Existing exact outputs are rejected before this traversal.
        child_target = target / child.name
        if any(child in output.parents for output in outputs):
            if not child.is_dir() or child.is_symlink():
                raise ProcessFilePolicyError(f"FILE_POLICY_OUTPUT_PARENT: {child}")
            _view(child, child_target, outputs, mount_args, destination / child.name)
        else:
            # Symlinks remain visible, but their targets are still on the read-only
            # host mount; the process can never write through a reference symlink.
            if child.is_symlink():
                child_target.symlink_to(os.readlink(child))
            elif child.is_dir():
                child_target.mkdir()
                mount_args.append((child, destination / child.name))
            elif child.is_file():
                child_target.touch()
                mount_args.append((child, destination / child.name))


def _validate_artifact(path: Path, *, allow_links: bool = False) -> None:
    mode = path.lstat().st_mode
    if allow_links and stat.S_ISLNK(mode):
        return  # Approved environment publication copies links without following them.
    if stat.S_ISLNK(mode) or not (stat.S_ISREG(mode) or stat.S_ISDIR(mode)):
        raise ProcessFilePolicyError(f"FILE_POLICY_UNSAFE_OUTPUT: {path}")
    if not allow_links and stat.S_ISREG(mode) and path.stat().st_nlink != 1:
        raise ProcessFilePolicyError(f"FILE_POLICY_HARDLINK_OUTPUT: {path}")
    if path.is_dir():
        for child in path.iterdir():
            _validate_artifact(child, allow_links=allow_links)


def _publish(source: Path, target: Path, *, allow_links: bool = False) -> None:
    """Copy through a sibling temporary name; never overwrite an existing artifact."""
    _checked_path(target)
    if target.exists() or target.is_symlink():
        raise ProcessFilePolicyError(f"FILE_POLICY_EXISTING_OUTPUT: {target}; archive via approved repair first")
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.parent / (".publish-" + uuid.uuid4().hex)
    try:
        if source.is_dir():
            shutil.copytree(source, temporary, symlinks=allow_links)
        else:
            shutil.copy2(source, temporary, follow_symlinks=False)
        # Destination creation is exclusive; existing historical files are never
        # replaced. The project operation lock serializes controller operations.
        if source.is_dir():
            target.mkdir()
            for child in temporary.iterdir():
                child.rename(target / child.name)
            temporary.rmdir()
        else:
            os.link(temporary, target)
            temporary.unlink()
    finally:
        if temporary.is_dir():
            shutil.rmtree(temporary)
        elif temporary.exists():
            temporary.unlink()


def _preserve_failed(view, cwd, targets, diagnostic_directory, diagnostic_scope, *, allow_links=False):
    produced = [(view / path.relative_to(cwd), path) for path in targets]
    produced = [(source, target) for source, target in produced if source.exists() or source.is_symlink()]
    if diagnostic_directory is None or not produced:
        return None
    for source, _ in produced:
        _validate_artifact(source, allow_links=allow_links)
    diagnostics = _checked_path(diagnostic_directory) / ("failed-attempt-" + uuid.uuid4().hex)
    with diagnostic_scope(diagnostics) if diagnostic_scope else nullcontext():
        diagnostics.mkdir(parents=True)
        for source, target in produced:
            if not any(other != target and other in target.parents for _, other in produced):
                _publish(source, diagnostics / target.relative_to(cwd), allow_links=allow_links)
    return str(diagnostics)


def run_step_process(argv: list[str], *, working_directory: str | Path,
                     outputs: dict[str, str], inputs: dict[str, str] | None = None,
                     temp_directory: str | Path | None = None,
                     diagnostic_directory: str | Path | None = None,
                     diagnostic_scope=None,
                     allow_artifact_links: bool = False,
                     env: dict[str, str] | None = None, **kwargs: Any) -> subprocess.CompletedProcess:
    """Execute with an isolated output view and publish only declared artifacts.

    Unlisted files are scratch. Failed attempts publish no outputs; a separate
    diagnostic directory retains their staging tree for controlled repair.
    """
    _bubblewrap()
    if kwargs.get("shell") or kwargs.get("pass_fds") or kwargs.get("preexec_fn"):
        raise ProcessFilePolicyError("FILE_POLICY_INVALID: unsafe process launch options")
    cwd = _checked_path(working_directory)
    from microbiome.pipeline.io import fingerprint_existing_paths
    inputs_before = fingerprint_existing_paths(inputs or {})
    targets = list(dict.fromkeys(_checked_path(value) for value in outputs.values()))
    for target in targets:
        if target == cwd or not _inside(target, cwd):
            raise ProcessFilePolicyError(f"FILE_POLICY_OUTPUT_SCOPE: {target} must be below {cwd}")
        if target.exists() or target.is_symlink():
            raise ProcessFilePolicyError(f"FILE_POLICY_EXISTING_OUTPUT: {target}; archive via approved repair first")
        for value in (inputs or {}).values():
            source = Path(value).resolve()
            if _inside(target, source) or _inside(source, target):
                raise ProcessFilePolicyError(f"FILE_POLICY_INPUT_OUTPUT_OVERLAP: {source} / {target}")
    # Large tool outputs belong on the project's filesystem, not an implicitly
    # size-limited host /tmp. Sibling scratch also leaves the working view clear.
    with tempfile.TemporaryDirectory(prefix=".microbiome-step-", dir=cwd.parent) as temporary:
        scratch = Path(temporary)
        view = scratch / "work"
        readonly: list[tuple[Path, Path]] = []
        _view(cwd, view, targets, readonly, cwd)
        for target in targets:
            if any(other != target and other in target.parents for other in targets):
                continue
            (view / target.relative_to(cwd)).parent.mkdir(parents=True, exist_ok=True)
        mounts = [(view, cwd)]
        if temp_directory is not None:
            temp = _checked_path(temp_directory)
            if temp == cwd or _inside(cwd, temp):
                raise ProcessFilePolicyError("FILE_POLICY_TEMP_SCOPE: temp must not contain the working directory")
            if temp.parent != cwd.parent and not _inside(temp, cwd):
                raise ProcessFilePolicyError("FILE_POLICY_TEMP_SCOPE: temp must be a sibling or child of the working directory")
            temp.mkdir(parents=True, exist_ok=True)
            isolated_temp = scratch / "tool-tmp"
            isolated_temp.mkdir()
            mounts.append((isolated_temp, temp))
        # Read-only existing outputs/inputs in the staging view must be mounted
        # after its writable parent; outside paths are read-only from / already.
        command = [_bubblewrap(), "--die-with-parent", "--new-session", "--unshare-user", "--unshare-pid",
                   "--unshare-ipc", "--unshare-uts", "--unshare-net", "--cap-drop", "ALL",
                   "--ro-bind", "/", "/", "--proc", "/proc", "--dev", "/dev",
                   "--bind", str(scratch), str(scratch)]
        for source, destination in mounts:
            command.extend(["--bind", str(source), str(destination)])
        for source, destination in readonly:
            command.extend(["--ro-bind", str(source), str(destination)])
        command.extend(["--chdir", str(cwd), "--", *map(str, argv)])
        try:
            result = subprocess.run(command, env=_private_environment(env, scratch), **kwargs)
        except subprocess.TimeoutExpired as error:
            error.failed_output_artifacts = _preserve_failed(view, cwd, targets, diagnostic_directory, diagnostic_scope,
                                                            allow_links=allow_artifact_links)
            raise
        stderr = result.stderr or ""
        if isinstance(stderr, bytes):
            stderr = stderr.decode(errors="replace")
        if result.returncode and stderr.startswith("bwrap:"):
            raise ProcessFilePolicyError("FILE_POLICY_UNAVAILABLE: " + stderr[:1000])
        produced = [(view / path.relative_to(cwd), path) for path in targets]
        produced = [(source, target) for source, target in produced if source.exists() or source.is_symlink()]
        for source, _ in produced:
            _validate_artifact(source, allow_links=allow_artifact_links)
        if result.returncode == 0:
            if fingerprint_existing_paths(inputs or {}) != inputs_before:
                raise ProcessFilePolicyError("FILE_POLICY_INPUT_DRIFT: input changed before output publication")
            for source, target in produced:
                if not any(other != target and other in target.parents for _, other in produced):
                    _publish(source, target, allow_links=allow_artifact_links)
        elif produced:
            result.failed_output_artifacts = _preserve_failed(view, cwd, targets, diagnostic_directory, diagnostic_scope,
                                                             allow_links=allow_artifact_links)
        return result
