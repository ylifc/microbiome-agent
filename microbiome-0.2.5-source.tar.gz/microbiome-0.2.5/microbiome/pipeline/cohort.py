"""Compile sample templates and cohort steps into one deterministic frozen DAG."""
import copy
import re

from microbiome.pipeline.errors import ConfigurationError
from microbiome.pipeline.models import validate_experiment_plan


def expand_cohort_plan(plan, manifest):
    if plan.get("execution_scope") != "cohort":
        return plan
    if plan.get("cohort_members"):
        raise ConfigurationError("cohort membership is derived from the persisted input manifest")
    from microbiome.pipeline.cases import sample_inputs
    members = []
    for index, sample in enumerate(manifest["samples"], 1):
        prefix = f"s{index:04d}"
        members.append({"sample_id": sample["sample_id"], "prefix": prefix,
                        "runtime": {role: f"{prefix}_{role}" for role in sample_inputs(sample)}})
    sample_steps = [s for s in plan["steps"] if s.get("scope", "sample") == "sample"]
    cohort_steps = [s for s in plan["steps"] if s.get("scope") == "cohort"]
    if not cohort_steps or len(sample_steps) + len(cohort_steps) != len(plan["steps"]):
        raise ConfigurationError("cohort plan needs explicit sample/cohort scopes and at least one cohort step")
    sample_ids = {s["step_id"] for s in sample_steps}
    outputs = {}
    expanded = []
    shared_keys = {"cohort_" + role for role in manifest.get("cohort_artifacts", {})}
    def rewrite_runtime(key, member):
        if key in shared_keys:
            return "{runtime." + key + "}"
        return "{runtime." + member["runtime"][key] + "}"
    def rewrite(value, member):
        if isinstance(value, str):
            if manifest.get("input_kind") == "completed_run_artifacts":
                value = value.replace("{sample_id}", member["sample_id"])
            value = value.replace("{run_dir}", "{run_dir}/samples/" + member["prefix"])
            return re.sub(r"\{runtime\.([^}]+)\}",
                          lambda m: rewrite_runtime(m.group(1), member), value)
        if isinstance(value, list):
            return [rewrite(v, member) for v in value]
        if isinstance(value, dict):
            return {k: rewrite(v, member) for k, v in value.items()}
        return value
    for member in members:
        for original in sample_steps:
            if any(dep not in sample_ids for dep in original.get("dependencies", [])):
                raise ConfigurationError("sample steps cannot depend on cohort results")
            try:
                step = rewrite(copy.deepcopy(original), member)
            except KeyError as error:
                raise ConfigurationError(f"sample {member['sample_id']} lacks input role {error}") from error
            step["step_id"] = member["prefix"] + "__" + original["step_id"]
            step["dependencies"] = [member["prefix"] + "__" + dep for dep in original.get("dependencies", [])]
            expanded.append(step)
            for name, path in step["output"].items():
                outputs.setdefault(f"{original['step_id']}.{name}", []).append((step["step_id"], path))
    for original in cohort_steps:
        step = copy.deepcopy(original)
        tokens = []
        for token in step["command_template"]:
            if token == "{cohort.sample_ids}":
                tokens.extend(member["sample_id"] for member in members)
                continue
            match = re.fullmatch(r"\{cohort\.([^}]+)\}", token)
            if not match:
                tokens.append(token)
                continue
            name = match.group(1)
            if name in {"reads", "reads_1", "reads_2", "fasta"} or (
                    manifest.get("input_kind") == "completed_run_artifacts"
                    and all(name in member["runtime"] for member in members)):
                for member in members:
                    if name not in member["runtime"]:
                        raise ConfigurationError(f"cohort input {name} missing for {member['sample_id']}")
                    key = member["runtime"][name]
                    step["input"][key] = "{runtime." + key + "}"
                    tokens.append("{input." + key + "}")
            elif name in outputs:
                for index, (dep, path) in enumerate(outputs[name]):
                    key = f"cohort_{len(step['input'])}_{index}"
                    step["input"][key] = path
                    step.setdefault("dependencies", []).append(dep)
                    tokens.append("{input." + key + "}")
            else:
                raise ConfigurationError(f"unknown cohort input/output reference: {name}")
        step["command_template"] = tokens
        step["dependencies"] = list(dict.fromkeys(
            dep for d in step.get("dependencies", [])
            for dep in ([m["prefix"] + "__" + d for m in members] if d in sample_ids else [d])))
        expanded.append(step)
    deliverables = []
    for item in plan.get("deliverables", []):
        if item["step_id"] in sample_ids:
            deliverables.extend({**item, "name": f"{m['sample_id']}: {item['name']}",
                                 "step_id": m["prefix"] + "__" + item["step_id"]} for m in members)
        else:
            deliverables.append(item)
    reference_decisions = []
    declared_ids = {step["step_id"] for step in plan["steps"]}
    for decision in plan.get("workflow_decisions", []):
        ids = decision.get("step_ids") if isinstance(decision, dict) else None
        if not isinstance(ids, list) or any(not isinstance(key, str) or key not in declared_ids for key in ids):
            raise ConfigurationError("workflow decision must reference declared cohort template steps")
        reference_decisions.append({**decision, "step_ids": [
            expanded_id for key in ids
            for expanded_id in ([m["prefix"] + "__" + key for m in members] if key in sample_ids else [key])
        ]})
    reference_fields = {"workflow_decisions": reference_decisions} if "workflow_decisions" in plan else {}
    return validate_experiment_plan({**plan, **reference_fields, "steps": expanded, "deliverables": deliverables,
                                     "cohort_members": members})


def cohort_runtime_inputs(plan, manifest):
    from microbiome.pipeline.cases import sample_inputs
    samples = {s["sample_id"]: s for s in manifest["samples"]}
    members = plan.get("cohort_members", [])
    if len(members) != len(samples) or {m["sample_id"] for m in members} != set(samples):
        raise ConfigurationError("cohort membership differs from the confirmed input manifest")
    inputs = {key: sample_inputs(samples[m["sample_id"]])[role] for m in members for role, key in m["runtime"].items()}
    if manifest.get("input_kind") in {"completed_run_artifacts", "external_cohort_tables"}:
        inputs.update({"cohort_" + role: artifact["path"]
                       for role, artifact in manifest.get("cohort_artifacts", {}).items()})
    return inputs
