"""Enums and validation helpers for machine-readable pipeline manifests."""

from __future__ import annotations

import re
from enum import StrEnum
from typing import Any

from microbiome.pipeline.errors import ConfigurationError
from microbiome.pipeline.io import object_fingerprint

SCHEMA_VERSION = 1
STEP_ID_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_.-]{0,127}$")
DATABASE_ALIAS_RE = re.compile(r"^[A-Za-z0-9_][A-Za-z0-9_.-]{0,127}$")
ENVIRONMENT_NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
# Scientific runtime configuration may select a locked reference, but it must
# not replace the toolchain, interpreter, activation or scheduler contracts.
RESERVED_RUNTIME_ENVIRONMENT = {
    "PATH", "HOME", "SHELL", "ENV", "BASH_ENV", "IFS", "SHELLOPTS", "BASHOPTS",
    "R_HOME", "R_PROFILE", "R_PROFILE_USER", "R_ENVIRON", "R_ENVIRON_USER",
    "R_LIBS", "R_LIBS_USER", "R_LIBS_SITE", "PERL5LIB", "PERL5OPT", "RUBYOPT",
    "NODE_PATH", "NODE_OPTIONS", "CLASSPATH", "JAVA_TOOL_OPTIONS", "JDK_JAVA_OPTIONS",
}
RESERVED_RUNTIME_ENVIRONMENT_PREFIXES = (
    "PYTHON", "LD_", "DYLD_", "CONDA_", "MAMBA_", "MICROBIOME_", "OMP_",
    "OPENBLAS_", "MKL_", "NUMEXPR_", "RAYON_", "CUDA_",
)
DESTRUCTIVE_EXECUTABLES = {"dd", "mv", "rm", "shred", "truncate"}
PRODUCTION_FORBIDDEN_EXECUTABLES = {
    "aria2c",
    "bowtie2-build",
    "conda",
    "curl",
    "fasterq-dump",
    "hmmpress",
    "kraken2-build",
    "mamba",
    "makeblastdb",
    "micromamba",
    "pip",
    "pip3",
    "prefetch",
    "wget",
}
PRODUCTION_FORBIDDEN_SUBCOMMANDS = {
    ("bwa", "index"),
    ("diamond", "makedb"),
    ("samtools", "faidx"),
}
REQUIRED_STEP_FIELDS = (
    "step_id",
    "purpose",
    "tool",
    "tool_version_requirement",
    "environment",
    "input",
    "output",
    "database",
    "command_template",
    "parameters",
    "success_criteria",
    "failure_criteria",
    "threads_policy",
    "memory_policy",
    "gpu_policy",
)


class PipelinePhase(StrEnum):
    DISCOVERY = "DISCOVERY"
    PLANNING = "PLANNING"
    BOOTSTRAP = "BOOTSTRAP"
    DATABASE_RESOLUTION = "DATABASE_RESOLUTION"
    VALIDATION = "VALIDATION"
    FROZEN = "FROZEN"
    PRODUCTION = "PRODUCTION"
    DIAGNOSIS = "DIAGNOSIS"


class ResourceStatus(StrEnum):
    READY = "READY"
    MISSING = "MISSING"
    INCOMPLETE = "INCOMPLETE"
    CORRUPT = "CORRUPT"
    UNKNOWN = "UNKNOWN"


class FailureCategory(StrEnum):
    INPUT_FAILURE = "INPUT_FAILURE"
    PATH_FAILURE = "PATH_FAILURE"
    ENVIRONMENT_FAILURE = "ENVIRONMENT_FAILURE"
    ENVIRONMENT_DRIFT = "ENVIRONMENT_DRIFT"
    DEPENDENCY_FAILURE = "DEPENDENCY_FAILURE"
    DATABASE_FAILURE = "DATABASE_FAILURE"
    DATABASE_INDEX_FAILURE = "DATABASE_INDEX_FAILURE"
    COMMAND_SYNTAX_FAILURE = "COMMAND_SYNTAX_FAILURE"
    RESOURCE_FAILURE = "RESOURCE_FAILURE"
    FORMAT_FAILURE = "FORMAT_FAILURE"
    NETWORK_FAILURE = "NETWORK_FAILURE"
    SOFTWARE_FAILURE = "SOFTWARE_FAILURE"
    PARAMETER_FAILURE = "PARAMETER_FAILURE"
    PIPELINE_LOGIC_FAILURE = "PIPELINE_LOGIC_FAILURE"
    OUTPUT_VALIDATION_FAILURE = "OUTPUT_VALIDATION_FAILURE"
    UNKNOWN_FAILURE = "UNKNOWN_FAILURE"


def _mapping(value: Any, field: str, step_id: str) -> dict[str, Any]:
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise ConfigurationError(f"step {step_id}: {field} must be a mapping")
    return value


def resource_binding_schema() -> dict[str, Any]:
    text = {"type": "string", "minLength": 1}
    return {"type": "object", "required": ["consumer", "entrypoint", "kind"],
        "properties": {"consumer": text, "entrypoint": text,
            "kind": {"enum": ["directory", "file", "index_prefix"]},
            "suffix_sets": {"type": "array", "items": {"type": "array", "minItems": 1, "items": text}},
            "markers": {"type": "array", "items": text}},
        "additionalProperties": False,
        "allOf": [{"if": {"properties": {"kind": {"const": "index_prefix"}}},
                   "then": {"required": ["suffix_sets"], "properties": {"suffix_sets": {"minItems": 1}}}}]}


def resource_authoring_schema() -> dict[str, Any]:
    """Named plan resources are authoring references, never executable facts."""
    identity = {"type": "string", "pattern": STEP_ID_RE.pattern}
    digest = {"type": "string", "pattern": "^[a-f0-9]{64}$"}
    return {"type": "object", "propertyNames": identity, "additionalProperties": {"oneOf": [
        {"type": "object", "required": ["source", "resource_id", "fingerprint"],
         "properties": {"source": {"const": "registered"}, "resource_id": identity, "fingerprint": digest},
         "additionalProperties": False},
        {"type": "object", "required": ["source", "validation_id"],
         "properties": {"source": {"const": "validated_candidate"}, "validation_id": digest},
         "additionalProperties": False},
        {"type": "object", "required": ["source", "requirement"],
         "properties": {"source": {"const": "unresolved_requirement"},
                        "requirement": {"type": "string", "minLength": 1}},
         "additionalProperties": False}]}}


def database_mapping_schema(*, allow_references: bool = False) -> dict[str, Any]:
    """The plan-side database contract, before any filesystem discovery.

    Optional resource facts remain optional; validation never fills paths,
    versions or markers. Only the compiler-facing schema permits resource
    references; persisted and executable plans require their trusted expansion.
    """
    text = {"type": "string", "minLength": 1}
    strings = {"type": "array", "items": text}
    string_map = {"type": "object", "additionalProperties": text}
    suffix_sets = {"type": "array", "items": {**strings, "minItems": 1}}
    entry_kind = {"enum": ["existing", "directory", "file", "index_prefix"]}
    contract = {
        "type": ["object", "null"],
        "properties": {
            "component_manifest": text,
            "nonempty_globs": strings,
            "any_complete_set": {"type": "array", "items": {
                "type": "object", "required": ["suffixes"],
                "properties": {"suffixes": {**strings, "minItems": 1}}}},
            "consumers": {"type": "object", "additionalProperties": {
                "type": "object", "properties": {"parameter_files": {
                    "type": "array", "items": {
                        "type": "object", "required": ["flag", "pattern"],
                        "properties": {"flag": text, "pattern": text}}}}}},
        },
    }
    descriptor = {
        "type": "object", "required": ["expected_markers"],
        "not": {"anyOf": [{"required": ["resource_id"]}, {"required": ["resource"]}]},
        "properties": {
            "logical_name": {**text, "pattern": STEP_ID_RE.pattern},
            **{key: text for key in ("type", "root_path", "path", "runtime_entry", "purpose", "version")},
            "expected_markers": {**strings, "minItems": 1},
            **{key: strings for key in ("source_files", "supported_tools", "common_markers")},
            "documentation": {"anyOf": [text, strings]},
            "consumer_entrypoints": string_map,
            "consumer_markers": {"type": "object", "additionalProperties": strings},
            "validation_contract": contract,
            "runtime_kind": entry_kind,
            "runtime_suffix_sets": suffix_sets,
            "consumer_entrypoint_kinds": {"type": "object", "additionalProperties": entry_kind},
            "consumer_suffix_sets": {"type": "object", "additionalProperties": suffix_sets},
            "bindings": {"type": "object", "minProperties": 1,
                         "propertyNames": {"type": "string", "pattern": STEP_ID_RE.pattern},
                         "additionalProperties": resource_binding_schema()},
            "binding_id": {"type": "string", "pattern": STEP_ID_RE.pattern},
        },
    }
    reference = {
        "type": "object", "required": ["resource_id", "fingerprint", "consumer"],
        "properties": {
            "resource_id": {**text, "pattern": STEP_ID_RE.pattern},
            "fingerprint": {"type": "string", "pattern": "^[a-f0-9]{64}$"},
            "consumer": text,
            "binding_id": {"type": "string", "pattern": STEP_ID_RE.pattern},
        },
        "additionalProperties": False,
        "description": "Reference exact READY registry facts; the backend expands and verifies the consumer contract before validating the executable plan.",
    }
    return {
        "type": "object",
        "description": "Always present. Use {} when unused; otherwise map each command database alias to its descriptor, never a flat descriptor.",
        "propertyNames": {"type": "string", "pattern": DATABASE_ALIAS_RE.pattern},
        "additionalProperties": {"oneOf": [descriptor, reference,
            {"type": "object", "required": ["resource"], "properties": {
                "resource": {"type": "string", "pattern": STEP_ID_RE.pattern},
                "binding_id": {"type": "string", "pattern": STEP_ID_RE.pattern}},
             "additionalProperties": False}]} if allow_references else descriptor,
    }


def validate_database_mapping(value: Any, step_id: str) -> dict[str, Any]:
    """Reject malformed descriptors before resource consumers call .get()."""
    from jsonschema import Draft202012Validator

    errors = sorted(Draft202012Validator(database_mapping_schema()).iter_errors(value),
                    key=lambda error: tuple(map(str, error.absolute_path)))
    if errors:
        details = "; ".join(
            "database" + "".join(f"[{part!r}]" for part in error.absolute_path) + ": " + error.message
            for error in errors
        )
        raise ConfigurationError(
            f"step {step_id}: database must map aliases to resource descriptor objects; {details}"
        )
    return dict(value)


def database_alias_references(step: dict[str, Any]) -> set[str]:
    """Find explicit executable/assertion references, not names in prose/evidence."""
    aliases: set[str] = set()

    def scan(value):
        if isinstance(value, str):
            aliases.update(re.findall(r"\{database\.([A-Za-z0-9_][A-Za-z0-9_.-]{0,127})\}", value))
            target = value.rsplit(":", 1)[-1]
            if target.startswith("database.") and DATABASE_ALIAS_RE.fullmatch(target[9:]):
                aliases.add(target[9:])
        elif isinstance(value, dict):
            for item in value.values():
                scan(item)
        elif isinstance(value, list):
            for item in value:
                scan(item)

    for key in ("command_template", "input", "runtime_environment", "success_criteria", "failure_criteria"):
        scan(step.get(key))
    return aliases


def validate_runtime_environment(value: Any, step_id: str) -> dict[str, str]:
    """Validate explicit scientific environment strings without path coercion."""
    if not isinstance(value, dict):
        raise ConfigurationError(f"step {step_id}: runtime_environment must be a string mapping")
    for name, setting in value.items():
        if not isinstance(name, str) or not ENVIRONMENT_NAME_RE.fullmatch(name):
            raise ConfigurationError(f"step {step_id}: invalid runtime environment variable name: {name!r}")
        upper = name.upper()
        if (upper in RESERVED_RUNTIME_ENVIRONMENT
                or upper.startswith(RESERVED_RUNTIME_ENVIRONMENT_PREFIXES)):
            raise ConfigurationError(f"step {step_id}: reserved runtime environment variable: {name}")
        if not isinstance(setting, str) or any(char in setting for char in ("\0", "\r", "\n")):
            raise ConfigurationError(f"step {step_id}: runtime_environment.{name} must be a single-line string")
    return dict(value)


def _command_tokens(value: Any, step_id: str) -> list[str]:
    if not isinstance(value, list) or not value or not all(isinstance(item, str) and item for item in value):
        raise ConfigurationError(
            f"step {step_id}: command_template must be a non-empty argv list; shell strings are not accepted"
        )
    forbidden = {"|", "||", "&&", ";", ">", ">>", "<"}
    if any(token in forbidden for token in value):
        raise ConfigurationError(
            f"step {step_id}: shell control operators are forbidden; use an explicit validated wrapper script"
        )
    if value[0] != "{executable}":
        raise ConfigurationError(f"step {step_id}: command_template must start with '{{executable}}'")
    return value


def _criteria(value: Any, field: str, step_id: str, *, required: bool) -> list[Any]:
    if not isinstance(value, list):
        raise ConfigurationError(f"step {step_id}: {field} must be a list")
    if required and not value:
        raise ConfigurationError(f"step {step_id}: at least one output success assertion is required")
    for criterion in value:
        if not isinstance(criterion, (str, dict)):
            raise ConfigurationError(f"step {step_id}: {field} entries must be strings or mappings")
    return value


def topological_step_ids(steps: list[dict[str, Any]]) -> list[str]:
    by_id = {step["step_id"]: step for step in steps}
    dependencies: dict[str, set[str]] = {}
    for step_id, step in by_id.items():
        deps = step.get("dependencies", [])
        if not isinstance(deps, list) or not all(isinstance(item, str) for item in deps):
            raise ConfigurationError(f"step {step_id}: dependencies must be a list of step IDs")
        missing = set(deps) - by_id.keys()
        if missing:
            raise ConfigurationError(f"step {step_id}: unknown dependencies: {', '.join(sorted(missing))}")
        if step_id in deps:
            raise ConfigurationError(f"step {step_id}: a step cannot depend on itself")
        dependencies[step_id] = set(deps)

    ready = sorted(step_id for step_id, deps in dependencies.items() if not deps)
    result: list[str] = []
    while ready:
        current = ready.pop(0)
        result.append(current)
        for step_id in sorted(dependencies):
            if current in dependencies[step_id]:
                dependencies[step_id].remove(current)
                if not dependencies[step_id] and step_id not in result and step_id not in ready:
                    ready.append(step_id)
                    ready.sort()
    if len(result) != len(steps):
        cycle = sorted(set(by_id) - set(result))
        raise ConfigurationError(f"pipeline dependencies contain a cycle: {', '.join(cycle)}")
    return result


def validate_experiment_plan(plan: Any) -> dict[str, Any]:
    if not isinstance(plan, dict):
        raise ConfigurationError("experiment_plan.yaml must contain a mapping")
    if "resources" in plan:
        raise ConfigurationError("plan.resources requires project-aware resource expansion before executable plan validation")
    objective = plan.get("objective")
    if not isinstance(objective, str) or not objective.strip():
        raise ConfigurationError("experiment plan requires a non-empty objective")
    steps = plan.get("steps")
    if not isinstance(steps, list) or not steps:
        raise ConfigurationError("experiment plan requires at least one step")
    seen: set[str] = set()
    normalized_steps: list[dict[str, Any]] = []
    for raw_step in steps:
        if not isinstance(raw_step, dict):
            raise ConfigurationError("every experiment step must be a mapping")
        if {"database_path", "database_binding_version"} & raw_step.keys():
            raise ConfigurationError("experiment steps cannot supply frozen database binding fields; select a declared resource binding")
        missing = [field for field in REQUIRED_STEP_FIELDS if field not in raw_step]
        step_id = str(raw_step.get("step_id", "<unknown>"))
        if missing:
            raise ConfigurationError(f"step {step_id}: missing required fields: {', '.join(missing)}")
        if not STEP_ID_RE.fullmatch(step_id):
            raise ConfigurationError(f"invalid step_id: {step_id!r}")
        if step_id in seen:
            raise ConfigurationError(f"duplicate step_id: {step_id}")
        seen.add(step_id)
        for field in ("purpose", "tool", "tool_version_requirement"):
            if not isinstance(raw_step[field], str) or not raw_step[field].strip():
                raise ConfigurationError(f"step {step_id}: {field} must be a non-empty string")
        if raw_step["tool"].rsplit("/", 1)[-1].casefold() in DESTRUCTIVE_EXECUTABLES:
            raise ConfigurationError(
                f"step {step_id}: destructive filesystem executable {raw_step['tool']!r} is not allowed"
            )
        if raw_step["tool"].rsplit("/", 1)[-1].casefold() in PRODUCTION_FORBIDDEN_EXECUTABLES:
            raise ConfigurationError(
                f"step {step_id}: environment mutation or network-transfer executable {raw_step['tool']!r} "
                "belongs to bootstrap/acquisition, not a production pipeline"
            )
        environment = raw_step["environment"]
        if not isinstance(environment, (str, dict)) or not environment:
            raise ConfigurationError(f"step {step_id}: environment must name an environment or prefix")
        normalized = dict(raw_step)
        normalized["step_id"] = step_id
        if "runtime_environment" in raw_step:
            normalized["runtime_environment"] = validate_runtime_environment(raw_step["runtime_environment"], step_id)
        normalized["input"] = _mapping(raw_step["input"], "input", step_id)
        from pathlib import Path
        from microbiome.pipeline.io import fast_file_fingerprint
        static = {}
        for key, value in normalized["input"].items():
            if isinstance(value, str) and "{" not in value and Path(value).is_file():
                static[key] = fast_file_fingerprint(Path(value).resolve())
        if raw_step.get("static_input_fingerprints") and raw_step["static_input_fingerprints"] != static:
            raise ConfigurationError(f"step {step_id}: static input or parameter file changed")
        if static:
            normalized["static_input_fingerprints"] = static
        normalized["output"] = _mapping(raw_step["output"], "output", step_id)
        if not normalized["output"]:
            raise ConfigurationError(f"step {step_id}: output must declare at least one production artifact")
        for output_name, output_template in normalized["output"].items():
            if not isinstance(output_template, str) or "{run_dir}" not in output_template:
                raise ConfigurationError(
                    f"step {step_id}: output.{output_name} must be a path template under '{{run_dir}}'"
                )
        normalized["database"] = validate_database_mapping(raw_step["database"], step_id)
        from microbiome.resource_skills.contracts import catalog_contract
        normalized["database"] = {
            key: {**spec, "validation_contract": catalog_contract(str(spec.get("logical_name") or key))}
            if isinstance(spec, dict) and "validation_contract" not in spec else spec
            for key, spec in normalized["database"].items()
        }
        validate_database_mapping(normalized["database"], step_id)
        missing_aliases = database_alias_references(raw_step) - normalized["database"].keys()
        if missing_aliases:
            raise ConfigurationError(
                f"step {step_id}: unresolved placeholder: undeclared database aliases: {', '.join(sorted(missing_aliases))}"
            )
        normalized["command_template"] = _command_tokens(raw_step["command_template"], step_id)
        from microbiome.assets import resolve_asset_token
        normalized["command_template"] = [
            resolve_asset_token(token)
            for token in normalized["command_template"]
        ]
        command = normalized["command_template"]
        adapter = raw_step.get("adapter_path")
        if len(command) > 1 and Path(command[1]).suffix in {".py", ".R", ".sh"} and "{" not in command[1]:
            if adapter and Path(adapter).resolve() != Path(command[1]).resolve():
                raise ConfigurationError(f"step {step_id}: adapter_path differs from the executed script")
            adapter = command[1]
        if adapter:
            path = Path(adapter).expanduser().resolve()
            if not path.is_file():
                raise ConfigurationError(f"step {step_id}: reviewed adapter does not exist: {path}")
            fingerprint = fast_file_fingerprint(path)
            if raw_step.get("adapter_fingerprint") and raw_step["adapter_fingerprint"] != fingerprint:
                raise ConfigurationError(f"step {step_id}: reviewed adapter changed; revise and revalidate")
            normalized["adapter_path"] = str(path)
            normalized["adapter_fingerprint"] = fingerprint
            if len(command) > 1 and command[1] == adapter:
                command[1] = str(path)
        executable_name = raw_step["tool"].rsplit("/", 1)[-1].casefold()
        literal_arguments = [token.casefold() for token in normalized["command_template"][1:]]
        if any(
            executable_name == executable and subcommand in literal_arguments
            for executable, subcommand in PRODUCTION_FORBIDDEN_SUBCOMMANDS
        ) or (executable_name == "minimap2" and "-d" in literal_arguments):
            raise ConfigurationError(
                f"step {step_id}: database/index construction belongs to resource maintenance, "
                "not a production pipeline"
            )
        joined_command = " ".join(normalized["command_template"]).casefold()
        forbidden_fragments = ("http://", "https://", "download_database(", "requests.get(", "pip install")
        if any(fragment in joined_command for fragment in forbidden_fragments):
            raise ConfigurationError(
                f"step {step_id}: command_template contains a download or installation operation; "
                "stage it before validation"
            )
        if not isinstance(raw_step["parameters"], (list, dict)):
            raise ConfigurationError(f"step {step_id}: parameters must be a list or mapping")
        normalized["success_criteria"] = _criteria(
            raw_step["success_criteria"], "success_criteria", step_id, required=True
        )
        if "figure_contract" in raw_step:
            from microbiome.visualization.artifacts import validate_contract
            normalized["figure_contract"] = validate_contract(raw_step["figure_contract"], normalized["input"], normalized["output"])
            criterion = {"type": "figure_manifest", "target": "output." + normalized["figure_contract"]["manifest_output"],
                         "contract_fingerprint": object_fingerprint(normalized["figure_contract"])}
            normalized["success_criteria"] = [row for row in normalized["success_criteria"]
                                              if not (isinstance(row, dict) and row.get("type") == "figure_manifest")] + [criterion]
            for image_key in normalized["figure_contract"]["image_outputs"]:
                image_check = "non_empty:output." + image_key
                if image_check not in normalized["success_criteria"]:
                    normalized["success_criteria"].append(image_check)
        normalized["failure_criteria"] = _criteria(
            raw_step["failure_criteria"], "failure_criteria", step_id, required=False
        )
        tool_choice = raw_step.get("tool_choice") or {
            "selected": raw_step["tool"],
            "reason": ["explicitly selected in the persisted analysis plan"],
            "alternatives_considered": [],
        }
        if not isinstance(tool_choice, dict):
            raise ConfigurationError(f"step {step_id}: tool_choice must be a mapping")
        reasons = tool_choice.get("reason", [])
        alternatives = tool_choice.get("alternatives_considered", [])
        if tool_choice.get("selected") != raw_step["tool"]:
            raise ConfigurationError(f"step {step_id}: tool_choice.selected must match tool")
        if not isinstance(reasons, list) or not reasons or not all(isinstance(item, str) for item in reasons):
            raise ConfigurationError(f"step {step_id}: tool_choice.reason must be a non-empty string list")
        if not isinstance(alternatives, list) or not all(isinstance(item, str) for item in alternatives):
            raise ConfigurationError(f"step {step_id}: tool_choice.alternatives_considered must be a string list")
        normalized["tool_choice"] = {
            "selected": raw_step["tool"],
            "reason": reasons,
            "alternatives_considered": alternatives,
        }
        validation_method = raw_step.get("validation_method", normalized["success_criteria"])
        if not isinstance(validation_method, list) or not validation_method:
            raise ConfigurationError(f"step {step_id}: validation_method must be a non-empty list")
        normalized["validation_method"] = validation_method
        policy = raw_step.get("threads_policy", {"min": 1, "max": 1, "default": 1})
        if not isinstance(policy, dict):
            raise ConfigurationError(f"step {step_id}: threads_policy must be a mapping")
        try:
            minimum = int(policy.get("min", 1))
            maximum = int(policy.get("max", minimum))
            default = int(policy.get("default", minimum))
        except (TypeError, ValueError) as exc:
            raise ConfigurationError(f"step {step_id}: invalid threads_policy") from exc
        if minimum < 1 or maximum < minimum or not minimum <= default <= maximum:
            raise ConfigurationError(f"step {step_id}: threads_policy must satisfy 1 <= min <= default <= max")
        if policy.get("maximize", True) is not True:
            raise ConfigurationError(f"step {step_id}: threads_policy.maximize must be true")
        if maximum > 1 and not any("{threads}" in token for token in normalized["command_template"]):
            raise ConfigurationError(
                f"step {step_id}: a multithreaded policy requires a {{threads}} command placeholder"
            )
        normalized["threads_policy"] = {
            "min": minimum,
            "max": maximum,
            "default": default,
            "maximize": True,
        }
        memory = raw_step.get("memory_policy", {})
        if not isinstance(memory, dict):
            raise ConfigurationError(f"step {step_id}: memory_policy must be a mapping")
        try:
            minimum_memory = int(memory.get("min_gb", 0))
            maximum_memory_raw = memory.get("max_gb")
            maximum_memory = int(maximum_memory_raw) if maximum_memory_raw is not None else None
        except (TypeError, ValueError) as exc:
            raise ConfigurationError(f"step {step_id}: invalid memory_policy") from exc
        if minimum_memory < 0 or (maximum_memory is not None and maximum_memory < max(1, minimum_memory)):
            raise ConfigurationError(f"step {step_id}: memory_policy must satisfy 0 <= min_gb <= max_gb")
        if memory.get("maximize", True) is not True:
            raise ConfigurationError(f"step {step_id}: memory_policy.maximize must be true")
        memory_placeholders = any(
            placeholder in token
            for token in normalized["command_template"]
            for placeholder in ("{memory_gb}", "{memory_mb}", "{memory_bytes}")
        )
        normalized["memory_policy"] = {
            "min_gb": minimum_memory,
            "max_gb": maximum_memory,
            "maximize": True,
            "argument_supported": memory_placeholders,
        }
        gpu = raw_step.get("gpu_policy", {})
        if not isinstance(gpu, dict):
            raise ConfigurationError(f"step {step_id}: gpu_policy must be a mapping")
        gpu_placeholders = any(
            placeholder in token
            for token in normalized["command_template"]
            for placeholder in ("{gpus}", "{gpu_devices}", "{gpu_memory_gb}")
        )
        enabled = gpu.get("enabled", gpu_placeholders)
        if not isinstance(enabled, bool):
            raise ConfigurationError(f"step {step_id}: gpu_policy.enabled must be boolean")
        try:
            minimum_gpus = int(gpu.get("min", 0))
            maximum_gpus_raw = gpu.get("max")
            maximum_gpus = int(maximum_gpus_raw) if maximum_gpus_raw is not None else None
        except (TypeError, ValueError) as exc:
            raise ConfigurationError(f"step {step_id}: invalid gpu_policy") from exc
        if minimum_gpus < 0 or (maximum_gpus is not None and maximum_gpus < minimum_gpus):
            raise ConfigurationError(f"step {step_id}: gpu_policy must satisfy 0 <= min <= max")
        if gpu.get("maximize", True) is not True:
            raise ConfigurationError(f"step {step_id}: gpu_policy.maximize must be true")
        if not enabled and (minimum_gpus or (maximum_gpus not in (None, 0)) or gpu_placeholders):
            raise ConfigurationError(
                f"step {step_id}: GPU placeholders or a positive GPU range require gpu_policy.enabled: true"
            )
        normalized["gpu_policy"] = {
            "enabled": enabled,
            "min": minimum_gpus if enabled else 0,
            "max": maximum_gpus if enabled else 0,
            "maximize": True,
            "argument_supported": gpu_placeholders,
        }
        normalized["dependencies"] = list(raw_step.get("dependencies", []))
        normalized_steps.append(normalized)
    topological_step_ids(normalized_steps)
    normalized_plan = dict(plan)
    if "execution_scheduling" in plan:
        from microbiome.pipeline.scheduler import normalize_scheduling
        normalized_plan["execution_scheduling"] = normalize_scheduling(plan["execution_scheduling"])
    requirements_version = normalized_plan.get("requirements_version")
    if requirements_version is not None and (not isinstance(requirements_version, int) or requirements_version < 1):
        raise ConfigurationError("requirements_version must be a positive integer")
    normalized_plan["schema_version"] = SCHEMA_VERSION
    normalized_plan["steps"] = normalized_steps
    normalized_plan["plan_fingerprint"] = object_fingerprint(
        {key: value for key, value in normalized_plan.items() if key != "plan_fingerprint"}
    )
    return normalized_plan
