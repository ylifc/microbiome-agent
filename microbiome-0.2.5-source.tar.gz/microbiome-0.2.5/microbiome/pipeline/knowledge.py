"""Verified-only operational knowledge for tools and database resources."""

from __future__ import annotations

import json
import os
import re
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from microbiome.pipeline.errors import ConfigurationError
from microbiome.pipeline.io import object_fingerprint, read_json, read_yaml, write_yaml

if TYPE_CHECKING:
    from collections.abc import Callable
    from pathlib import Path

    from microbiome.pipeline.project import PipelineProject


def _utcnow() -> str:
    return datetime.now(UTC).isoformat()


def _safe_id(value: str) -> str:
    result = re.sub(r"[^A-Za-z0-9_.-]+", "-", value).strip("-.")
    if not result:
        raise ConfigurationError("knowledge record requires a safe non-empty identifier")
    return result[:128]


class KnowledgeBase:
    def __init__(self, project: PipelineProject):
        self.project = project

    def _tool_dir(self, tool_id: str) -> Path:
        path = self.project.knowledge_dir / "tools" / _safe_id(tool_id)
        path.mkdir(parents=True, exist_ok=True)
        return path

    def _database_dir(self, resource_id: str) -> Path:
        path = self.project.knowledge_dir / "databases" / _safe_id(resource_id)
        path.mkdir(parents=True, exist_ok=True)
        return path

    @staticmethod
    def _append_jsonl(path: Path, payload: dict[str, Any]) -> None:
        descriptor = os.open(path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o644)
        try:
            os.write(descriptor, (json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n").encode("utf-8"))
            os.fsync(descriptor)
        finally:
            os.close(descriptor)

    def record_tool_profile(self, step_id: str, entry: dict[str, Any]) -> None:
        tool_id = str(entry.get("tool") or step_id)
        directory = self._tool_dir(tool_id)
        profile = {
            "schema_version": 1,
            "tool_id": tool_id,
            "step_id": step_id,
            "executable": entry.get("executable"),
            "conda_prefix": entry.get("environment_prefix"),
            "version": entry.get("version_output"),
            "installation_source": entry.get("installation_source"),
            "last_validated": entry.get("validated_at") or _utcnow(),
        }
        write_yaml(directory / "tool_profile.yaml", profile)
        versions_path = directory / "validated_versions.yaml"
        versions = read_yaml(versions_path) if versions_path.is_file() else {"versions": []}
        version_record = {
            "version": entry.get("version_output"),
            "executable": entry.get("executable"),
            "environment": entry.get("environment_prefix"),
            "validated_at": entry.get("validated_at") or _utcnow(),
        }
        if version_record not in versions["versions"]:
            versions["versions"].append(version_record)
        write_yaml(versions_path, versions)

    def record_tool_validation(self, tool_id: str, entry: dict[str, Any]) -> None:
        """Append a validated executable/help smoke-test fact."""

        self._append_jsonl(
            self._tool_dir(tool_id) / "validation_history.jsonl",
            {
                "timestamp": entry.get("validated_at") or _utcnow(),
                "status": entry.get("validation_result", "PASSED"),
                "executable": entry.get("executable"),
                "environment": entry.get("environment_prefix") or entry.get("conda_prefix"),
                "version": entry.get("version_output") or entry.get("version"),
                "version_args": entry.get("version_args"),
                "help_args": entry.get("help_args"),
                "help_exit_code": entry.get("help_exit_code"),
                "source": entry.get("installation_source"),
            },
        )

    def record_installation_attempt(self, tool_id: str, attempt: dict[str, Any]) -> None:
        """Record every bounded install attempt; only validated successes become recipes."""

        payload = dict(attempt)
        payload.setdefault("timestamp", _utcnow())
        self._append_jsonl(self._tool_dir(tool_id) / "installation_history.jsonl", payload)
        if payload.get("validated") is True:
            write_yaml(
                self._tool_dir(tool_id) / "installation_recipe.yaml",
                {
                    "schema_version": 1,
                    "software_family": tool_id,
                    "successful_installation": payload,
                },
            )

    def record_invocation(
        self,
        tool_id: str,
        *,
        command: list[str] | str,
        success: bool,
        executable: str | None = None,
        version: str | None = None,
        environment: str | None = None,
        database: dict[str, Any] | None = None,
        outputs: list[str] | None = None,
        exit_code: int | None = None,
        phase: str | None = None,
        validation_checks: list[dict[str, Any]] | None = None,
    ) -> None:
        """Persist a real invocation result, separate from descriptive Skill text."""

        verified = bool(success and exit_code == 0 and validation_checks
                        and all(check.get("passed") is True for check in validation_checks))
        status = "SUCCESS" if verified else (
            "UNVERIFIED" if success and exit_code == 0 and validation_checks is None else "FAILED")
        self._append_jsonl(
            self._tool_dir(tool_id) / "invocations.jsonl",
            {
                "timestamp": _utcnow(),
                "status": status,
                "evidence_level": "OUTPUT_VALIDATED" if verified else "UNVERIFIED",
                "phase": phase,
                "command": command,
                "executable": executable,
                "software_version": version,
                "environment": environment,
                "database": database or {},
                "outputs": outputs or [],
                "exit_code": exit_code,
                "validation_checks": validation_checks,
            },
        )

    def record_database_profile(self, resource_id: str, entry: dict[str, Any]) -> None:
        directory = self._database_dir(resource_id)
        write_yaml(
            directory / "database_profile.yaml",
            {
                "schema_version": 1,
                "resource_id": resource_id,
                "root_path": entry.get("root_path"),
                "runtime_entry": entry.get("runtime_entry") or entry.get("path"),
                "expected_files": entry.get("expected_marker_files", []),
                "supported_tools": entry.get("supported_tools", []),
                "status": entry.get("status"),
                "version": entry.get("version") or entry.get("database_version"),
                "consumer_entrypoints": entry.get("consumer_entrypoints", {}),
                "fingerprint": entry.get("fingerprint"),
                "last_validation": _utcnow(),
            },
        )

    def record_database_event(self, resource_id: str, event: dict[str, Any]) -> None:
        """Append database discovery/acquisition/localization/validation history."""

        payload = dict(event)
        payload.setdefault("timestamp", _utcnow())
        self._append_jsonl(self._database_dir(resource_id) / "events.jsonl", payload)

    def record_failure(self, tool_id: str, failure: dict[str, Any]) -> str:
        stderr = str(failure.get("stderr", ""))[-8000:]
        normalized = re.sub(r"/(?:[^\s:]+/)*[^\s:]+", "<path>", stderr)
        normalized = re.sub(r"\b(?:pid|process)\s*[=:]?\s*\d+", "pid <id>", normalized, flags=re.I)
        signature = object_fingerprint(
            {
                "category": failure.get("category"),
                "tool": tool_id,
                "exit_code": failure.get("exit_code"),
                "stderr": normalized,
                "version": failure.get("tool_version"),
            }
        )
        self._append_jsonl(
            self._tool_dir(tool_id) / "known_errors.jsonl",
            {
                "timestamp": _utcnow(),
                "error_signature": signature,
                "software_version": failure.get("tool_version"),
                "environment": failure.get("environment"),
                "command": failure.get("command"),
                "database": failure.get("database"),
                "stderr_fingerprint": object_fingerprint(stderr),
                "stderr_excerpt": stderr,
                "category": failure.get("category"),
                "exit_code": failure.get("exit_code"),
                "input_metadata": failure.get("input_metadata"),
                "root_cause": failure.get("root_cause"),
                "fix": failure.get("fix"),
                "fix_status": failure.get("fix_status", "UNRESOLVED"),
                "validated_date": failure.get("validated_date"),
            },
        )
        return signature

    @staticmethod
    def _records(path):
        if not path.is_file():
            return []
        values = []
        for line in path.read_text(encoding="utf-8").splitlines():
            try:
                value = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(value, dict):
                values.append(value)
        return values

    @staticmethod
    def _validated_invocation(value):
        checks = value.get("validation_checks")
        return (value.get("status") == "SUCCESS" and value.get("exit_code") == 0
                and bool(checks) and all(c.get("passed") is True for c in checks))

    def query(self, tool_id: str, *, version: str | None = None, environment: str | None = None,
              database: dict | None = None, aliases: list[str] | None = None, limit: int = 10) -> dict[str, Any]:
        """Read verified uses, failures, fixes and installation history without writing."""
        limit = max(1, min(int(limit), 50))
        def records(filename):
            values = []
            for name in dict.fromkeys([tool_id, *(aliases or [])]):
                path = self.project.knowledge_dir / "tools" / _safe_id(name) / filename
                values.extend(self._records(path))
            return sorted(values, key=lambda v: v.get("timestamp", v.get("completed_at", "")))
        def compatible(v):
            return ((version is None or v.get("software_version", v.get("version")) == version)
                    and (environment is None or v.get("environment", v.get("environment_prefix")) == environment)
                    and (database is None or v.get("database") == database))
        invocations = records("invocations.jsonl")
        errors_by_signature = {}
        for event in records("known_errors.jsonl"):
            key = event.get("error_signature") or object_fingerprint(event)
            errors_by_signature[key] = {**errors_by_signature.get(key, {}), **event}
        errors = [v for v in errors_by_signature.values() if compatible(v)]
        return {"tool": tool_id, "version_filter": version,
                "other_context_errors": [v for v in errors_by_signature.values() if not compatible(v)][-limit:],
                "validated_invocations": [v for v in invocations if compatible(v) and self._validated_invocation(v)][-limit:],
                "unverified_history": [v for v in invocations if not self._validated_invocation(v) and v.get("status") != "FAILED"][-limit:],
                "failed_invocations": [v for v in invocations if compatible(v) and v.get("status") == "FAILED"][-limit:],
                "known_errors": [v for v in errors if v.get("fix_status") != "VERIFIED"
                                 or not self._valid_report(v.get("validation_report"))][-limit:],
                "verified_fixes": [v for v in errors if v.get("fix_status") == "VERIFIED" and self._valid_report(v.get("validation_report"))][-limit:],
                "installation_history": [v for v in records("installation_history.jsonl") if compatible(v)][-limit:]}

    def query_database(self, resource_id: str, *, version: str | None = None, fingerprint=None, limit=10):
        directory = self.project.knowledge_dir / "databases" / _safe_id(resource_id)
        profile_path = directory / "database_profile.yaml"
        profile = read_yaml(profile_path) if profile_path.is_file() else {}
        events = self._records(directory / "events.jsonl")
        applicable = [v for v in events if (version is None or v.get("version") == version)
                      and (fingerprint is None or v.get("fingerprint") == fingerprint)]
        return {"resource_id": resource_id, "profile": profile, "events": applicable[-max(1, min(limit, 50)):],
                "history_is_runtime_authority": False}

    @staticmethod
    def _valid_report(path):
        if not path:
            return False
        from pathlib import Path
        try:
            report = read_json(Path(path))
            return (report.get("status") == "PASSED" and bool(report.get("steps"))
                    and all(s.get("status") == "PASSED" for s in report["steps"])
                    and report.get("report_fingerprint") == object_fingerprint(
                        {k: v for k, v in report.items() if k != "report_fingerprint"}))
        except (OSError, ValueError, TypeError, KeyError):
            return False

    def record_fix(
        self,
        tool_id: str,
        *,
        error_signature: str,
        root_cause: str,
        fix: str,
        verified: bool,
        validation_report: str | None = None,
    ) -> None:
        verified = bool(verified and self._valid_report(validation_report))
        prior = next((v for v in reversed(self._records(
            self.project.knowledge_dir / "tools" / _safe_id(tool_id) / "known_errors.jsonl"))
                      if v.get("error_signature") == error_signature), {})
        self._append_jsonl(
            self._tool_dir(tool_id) / "known_errors.jsonl",
            {
                **{k: prior.get(k) for k in ("software_version", "environment", "database")},
                "timestamp": _utcnow(),
                "error_signature": error_signature,
                "root_cause": root_cause,
                "fix": fix,
                "fix_status": "VERIFIED" if verified else "FAILED_ATTEMPT",
                "validation_report": validation_report,
                "validated_date": _utcnow() if verified else None,
            },
        )

    def verified_fixes(self, tool_id: str, error_signature: str) -> list[dict[str, Any]]:
        return [v for v in self.query(tool_id, limit=50)["verified_fixes"]
                if v.get("error_signature") == error_signature]


class RepairEngine:
    """Bounded repair coordinator; failed attempts never become recommendations."""

    def __init__(self, knowledge: KnowledgeBase, *, max_repair_attempts: int = 3):
        if max_repair_attempts < 1:
            raise ValueError("max_repair_attempts must be positive")
        self.knowledge = knowledge
        self.max_repair_attempts = max_repair_attempts

    def run(
        self,
        tool_id: str,
        error_signature: str,
        attempts: list[tuple[str, str, Callable[[], bool]]],
    ) -> bool:
        for root_cause, fix, callback in attempts[: self.max_repair_attempts]:
            try:
                result = callback()
                report_path = result.get("report_path") if isinstance(result, dict) else None
                verified = self.knowledge._valid_report(report_path)
            except Exception:
                verified = False
                report_path = None
            self.knowledge.record_fix(
                tool_id,
                error_signature=error_signature,
                root_cause=root_cause,
                fix=fix,
                verified=verified,
                validation_report=report_path,
            )
            if verified:
                return True
        return False
