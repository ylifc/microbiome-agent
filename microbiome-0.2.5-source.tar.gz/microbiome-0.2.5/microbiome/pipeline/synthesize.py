"""Recover a reviewed legacy pipeline from verified execution facts.

Execution records establish commands, executable/environment bindings and output
validation. User-confirmed requirements and an explicitly approved recovery
proposal establish authorization and scope. Neither source can replace the other.
Missing management reports may be reconstructed from those persisted records;
missing approval requires review, and an existing production lock is immutable.
"""

from __future__ import annotations

import re
import shlex
import shutil
import subprocess

from microbiome.pipeline.process_file_policy import run_scoped_process
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from microbiome.path_policy import is_same_or_within
from microbiome.pipeline.errors import ExecutionFactMissingError, PipelineError
from microbiome.pipeline.io import (
    atomic_write_text,
    canonical_path,
    manifest_fingerprint,
    object_fingerprint,
    path_fingerprint,
    read_json,
    read_yaml,
    write_json,
    write_yaml,
)
from microbiome.pipeline.ledger import ExecutionLedger
from microbiome.pipeline.lock_schema import validate_pipeline_lock
from microbiome.pipeline.project import PipelineProject
from microbiome.pipeline.state import LifecycleState, ProjectStateMachine

_SUBSET_TOKENS = ("input_subset", "subset", "pilot_run", "pilot_")
_PATH_TOKEN_RE = re.compile(r"(?<![\w./{}-])(/[^\s\"'`<>|;&()]+)")
_KEY_SAFE_RE = re.compile(r"[^A-Za-z0-9_.-]+")
_SEQUENCE_SUFFIX_RE = re.compile(r"\.(?:fastq|fq|fasta|fa|fna|faa)(?:\.gz)?$", re.IGNORECASE)

_RESOURCE_POLICIES = {
    "threads_policy": {"min": 1, "max": 1, "default": 1},
    "memory_policy": {"min_gb": 0, "max_gb": None},
    "gpu_policy": {"enabled": False, "min": 0, "max": 0},
}

_ENV_SETUP_RE = re.compile(
    r"^\s*(?:conda|mamba|micromamba)\s+(?:create|install)|^\s*(?:pip|pip3)\s+install", re.IGNORECASE
)


def _utcnow() -> str:
    return datetime.now(UTC).isoformat()


def _inside(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def _is_subset_artifact(path: str) -> bool:
    text = str(path)
    return any(token in text for token in _SUBSET_TOKENS)


def _script_text(attempt: dict[str, Any], step_id: str) -> tuple[str, str]:
    """Return (kind, executable script text) from one verified ledger attempt."""
    command = attempt.get("command") or {}
    code = str(command.get("code") or "").strip()
    kind = command.get("kind")
    argv = [str(item) for item in (command.get("argv") or [])]
    if not code and argv:
        code = shlex.join(argv)
        kind = kind or "bash"
    if kind == "argv":
        kind = "bash"
    if not code:
        raise ExecutionFactMissingError(
            f"无法确定 {step_id} 最终成功使用的 command（执行账本中只有状态没有命令内容）/ Cannot determine the final successful command used by {step_id} (the execution ledger has only status, no command content)",
            step_id=step_id,
            fact="command",
        )
    code = re.sub(r"^#!(?:BASH|CLI|R)\b[^\n]*(?:\n|$)", "", code)
    code = re.sub(r"^#\s*(?:Bash script|R code|R script)[^\n]*(?:\n|$)", "", code)
    if not kind:
        kind = "python"  # agent ledger convention: unmarked code ran as python
    if kind not in {"bash", "python", "r"}:
        raise ExecutionFactMissingError(
            f"无法确定 {step_id} 实际使用的命令解释器（记录为 {kind!r}）/ Cannot determine the command interpreter actually used by {step_id} (recorded as {kind!r})",
            step_id=step_id,
            fact="interpreter",
        )
    return kind, code.strip()


def _interpreter(kind: str, step_id: str) -> str:
    candidate = {"bash": shutil.which("bash"), "python": sys.executable, "r": shutil.which("Rscript")}[kind]
    if not candidate:
        raise ExecutionFactMissingError(
            f"无法确定 {step_id} 实际使用的执行环境：解释器 {kind} 在当前系统不可用 / Cannot determine the execution environment actually used by {step_id}: interpreter {kind} is unavailable on this system",
            step_id=step_id,
            fact="interpreter",
        )
    return str(canonical_path(candidate, must_exist=True))


def _version_output(executable: str) -> str:
    """Capture the version banner of the exact interpreter used for replay."""
    try:
        result = run_scoped_process([executable, "--version"], capture_output=True, text=True, timeout=30, check=False)
    except (OSError, subprocess.TimeoutExpired):
        return ""
    return "\n".join(part.strip() for part in (result.stdout, result.stderr) if part.strip())[:4000]


def _usable_raw_file(path: Path, raw_root: Path, excluded_roots: tuple[Path, ...]) -> bool:
    return (
        _inside(path, raw_root) and path.is_file() and not any(is_same_or_within(path, root) for root in excluded_roots)
    )


def _subset_source_map(
    entries: list[dict[str, Any]],
    raw_root: Path,
    excluded_roots: tuple[Path, ...] = (),
) -> dict[str, str]:
    """Map pilot subset files back to their RAW_DATA_PATH sources.

    Derived only from recorded successful commands that read a raw input and
    wrote a subset artifact — a factual lineage, not a guess.
    """
    mapping: dict[str, str] = {}
    for entry in entries:
        if entry.get("status") != "PASSED":
            continue
        raw_inputs = [
            str(canonical_path(item))
            for item in entry.get("inputs") or []
            if _usable_raw_file(Path(str(item)), raw_root, excluded_roots)
        ]
        if not raw_inputs:
            continue
        for output in entry.get("outputs") or []:
            if _is_subset_artifact(str(output)):
                mapping[str(canonical_path(str(output)))] = raw_inputs[0]
    return mapping


def _validation_lineage(project: PipelineProject) -> tuple[dict[str, str], list[str]]:
    """Recover the subset -> full-source lineage from the validation report.

    This is the correct source of lineage: the sampler recorded exactly which
    full file produced each subset file. Pre-test commands consume SUBSET paths
    (not RAW_DATA_PATH), so lineage must come from this mapping, never from a
    requirement that the command string itself contain RAW_DATA_PATH.
    """
    subset_map: dict[str, str] = {}
    full_sources: list[str] = []
    if not project.validation_report_path.is_file():
        return subset_map, full_sources
    try:
        from microbiome.pipeline.io import read_json

        report = read_json(project.validation_report_path)
    except Exception:
        return subset_map, full_sources
    outputs = (report.get("representative_subset") or {}).get("outputs", []) or []
    for item in outputs:
        if isinstance(item, dict) and item.get("source") and item.get("pilot"):
            subset_map[str(canonical_path(item["pilot"]))] = str(canonical_path(item["source"]))
    for metadata in (report.get("runtime_input_source") or {}).values():
        if isinstance(metadata, dict) and metadata.get("path"):
            full_sources.append(str(canonical_path(metadata["path"])))
    return subset_map, full_sources


def _source_mapping_lineage(project: PipelineProject) -> tuple[dict[str, str], list[str]]:
    """Recover subset -> full-source lineage from a persisted source_mapping.yaml.

    This is the lineage produced by the conversational pilot's deterministic
    sampler (``A1._prepare_deterministic_subset``) and by the strict validator.
    It is a factual mapping, never a reverse-engineered guess.
    """
    from microbiome.pipeline.pretest_evidence import _load_subset_manifest

    payload = _load_subset_manifest(project.pretest_dir)
    mapping: dict[str, str] = {}
    full_sources: list[str] = []
    if not payload:
        return mapping, full_sources
    for sample in payload.get("samples", []) or []:
        if not isinstance(sample, dict):
            continue
        source = sample.get("source") or {}
        subset = sample.get("subset") or {}
        if not isinstance(source, dict) or not isinstance(subset, dict):
            continue
        for key in subset:
            src = source.get(key)
            pilot = subset.get(key)
            if src and pilot:
                try:
                    pilot_key = str(canonical_path(pilot))
                    source_value = str(canonical_path(src))
                except (OSError, RuntimeError):
                    continue
                mapping[pilot_key] = source_value
                full_sources.append(source_value)
    return mapping, full_sources


def _is_preparation(
    attempt: dict[str, Any],
    raw_root: Path,
    excluded_roots: tuple[Path, ...] = (),
) -> bool:
    """Preparation records stage subsets or environments; they never enter the lock."""
    command = attempt.get("command") or {}
    code = str(command.get("code") or "")
    if _ENV_SETUP_RE.search(code):
        return True  # environment installation belongs to the pre-test, never to production
    outputs = [str(item) for item in attempt.get("outputs") or []]
    raw_inputs = [
        item for item in attempt.get("inputs") or [] if _usable_raw_file(Path(str(item)), raw_root, excluded_roots)
    ]
    return bool(outputs) and all(_is_subset_artifact(item) for item in outputs) and bool(raw_inputs)


class _StepSynthesizer:
    """Turn verified ledger attempts into frozen, replayable step definitions."""

    def __init__(self, *, raw_root: Path, db_root: Path | None, results_root: Path):
        self.raw_root = raw_root
        self.db_root = db_root
        self.results_root = results_root
        self.input_exclusions = tuple(
            root for root in (results_root, db_root) if root is not None and is_same_or_within(root, raw_root)
        )
        self.subset_map: dict[str, str] = {}
        self.producer_outputs: dict[str, tuple[str, str]] = {}  # path -> (producer step_id, run-relative name)
        self.runtime_sources: list[str] = []  # ordered unique raw sources
        self.runtime_keys: dict[str, str] = {}  # source path -> runtime key
        self.databases: dict[str, dict[str, Any]] = {}  # logical name -> lock entry
        self.warnings: list[str] = []

    def collect_sources(self, attempts: list[dict[str, Any]]) -> None:
        for attempt in attempts:
            for item in attempt.get("inputs") or []:
                path = Path(str(item))
                # Manifests/READMEs/etc. (sample_list.txt) are not runtime inputs;
                # including them breaks paired-end key assignment (reads_1/reads_2).
                if not _SEQUENCE_SUFFIX_RE.search(path.name):
                    continue
                if _usable_raw_file(path, self.raw_root, self.input_exclusions):
                    source = str(canonical_path(path))
                    if source not in self.runtime_sources:
                        self.runtime_sources.append(source)
        for _subset, source in self.subset_map.items():
            # The source side of subset -> full lineage is always a sequence file.
            if _SEQUENCE_SUFFIX_RE.search(Path(str(source)).name) and source not in self.runtime_sources:
                self.runtime_sources.append(source)
        self.runtime_keys = self._assign_runtime_keys(self.runtime_sources)

    @staticmethod
    def _assign_runtime_keys(sources: list[str]) -> dict[str, str]:
        from microbiome.pipeline.inputs import _sample_and_mate

        if len(sources) == 1:
            return {sources[0]: "reads"}
        keys: dict[str, str] = {}
        mates: dict[str, str] = {}
        for source in sources:
            _sample, mate = _sample_and_mate(Path(source))
            mates[source] = mate or ""
        if all(mates[source] in {"1", "2"} for source in sources) and {mates[s] for s in sources} == {"1", "2"}:
            return {source: f"reads_{mates[source]}" for source in sources}
        used: set[str] = set()
        for source in sources:
            base = _KEY_SAFE_RE.sub("_", Path(source).name.split(".")[0]).strip("_") or "input"
            key = base
            suffix = 2
            while key in used:
                key = f"{base}_{suffix}"
                suffix += 1
            used.add(key)
            keys[source] = key
        return keys

    def _runtime_binding(self, path: str) -> tuple[str, str]:
        """Return (runtime key, source path) for a raw or subset input path."""
        canonical = str(canonical_path(path))
        source = self.subset_map.get(canonical)
        if source is None:
            source = canonical
        if source not in self.runtime_keys:
            raise ExecutionFactMissingError(f"无法确定输入 {path} 对应的 RAW_DATA_PATH 原始数据 / Cannot determine the RAW_DATA_PATH raw data corresponding to input {path}", fact="input_source")
        return self.runtime_keys[source], source

    def _database_entry(self, path: str) -> str:
        """Register a recorded database path and return its logical alias token name."""
        target = Path(path)
        if not target.exists():
            raise ExecutionFactMissingError(
                f"无法确定实际数据库文件：{path}（小试成功记录中引用的数据库现已不存在）/ Cannot determine the actual database file: {path} (the database referenced by the successful pilot record no longer exists)",
                fact="database_path",
            )
        if target.is_dir():
            root, runtime_entry, markers = target, target, []
        else:
            root, runtime_entry, markers = target.parent, target, [target.name]
        alias = _KEY_SAFE_RE.sub("_", root.name).strip("_") or "database"
        if not alias[0].isalpha():
            alias = f"db_{alias}"
        base_alias = alias
        suffix = 2
        while alias in self.databases and self.databases[alias]["root_path"] != str(canonical_path(root)):
            alias = f"{base_alias}_{suffix}"
            suffix += 1
        if alias not in self.databases:
            from microbiome.pipeline.resources import database_fingerprint

            self.databases[alias] = {
                "logical_name": alias,
                "path": str(canonical_path(runtime_entry)),
                "root_path": str(canonical_path(root)),
                "runtime_entry": str(canonical_path(runtime_entry)),
                "expected_marker_files": markers,
                "database_version": "UNKNOWN",
                "fingerprint": database_fingerprint(canonical_path(root), markers),
            }
        return alias

    def build_step(self, index: int, attempt: dict[str, Any]) -> dict[str, Any]:
        step_id = f"step_{index:02d}"
        kind, script = _script_text(attempt, step_id)
        interpreter = _interpreter(kind, step_id)
        version_output = _version_output(interpreter)
        # The interpreter is what actually executes the frozen step; the pilot's
        # inner tool invocation stays byte-for-byte inside the script template.
        tool_name = Path(interpreter).name
        recorded_tool = str((attempt.get("tool") or {}).get("name") or tool_name)

        recorded_inputs = {str(canonical_path(p)) for p in attempt.get("inputs") or [] if Path(str(p)).exists()}
        recorded_outputs = {str(canonical_path(p)) for p in attempt.get("outputs") or []}
        recorded_dbs = set()
        for item in attempt.get("database_resources") or []:
            value = item.get("path") if isinstance(item, dict) else item
            if value:
                # Keep recorded database paths even when they have since vanished:
                # a missing recorded database is a blocking execution-fact gap.
                recorded_dbs.add(str(canonical_path(str(value))))
        scanned = {
            str(canonical_path(token))
            for token in _PATH_TOKEN_RE.findall(script)
            if Path(token).is_absolute() and Path(token).exists()
        }

        inputs_spec: dict[str, str] = {}
        outputs_spec: dict[str, str] = {}
        db_spec: dict[str, dict[str, Any]] = {}
        assertions: list[str] = []
        dependencies: set[str] = set()
        replacements: list[tuple[str, str]] = []

        candidates = sorted(recorded_inputs | recorded_outputs | recorded_dbs | scanned, key=len, reverse=True)
        for path in candidates:
            if path in self.subset_map:
                # A mapped pilot-subset path is always a runtime input, even when
                # location-based fact inference also listed it among outputs.
                runtime_key, _source = self._runtime_binding(path)
                if runtime_key not in inputs_spec:
                    inputs_spec[runtime_key] = f"{{runtime.{runtime_key}}}"
                replacements.append((path, f"{{input.{runtime_key}}}"))
            elif path in self.producer_outputs:
                producer, rel = self.producer_outputs[path]
                key = f"in_{len(inputs_spec) + 1}"
                inputs_spec[key] = f"{{run_dir}}/{rel}"
                dependencies.add(producer)
                replacements.append((path, f"{{input.{key}}}"))
            elif _usable_raw_file(Path(path), self.raw_root, self.input_exclusions) and _SEQUENCE_SUFFIX_RE.search(
                Path(path).name
            ):
                # Only sequence files (FASTQ/FASTA) are runtime inputs. A manifest
                # (sample_list.txt) or README that sits inside RAW_DATA_PATH is a
                # reference file, not a runtime mate; binding it here would raise
                # "cannot determine the RAW_DATA_PATH raw data" because it was
                # deliberately excluded from runtime_sources in collect_sources.
                runtime_key, _source = self._runtime_binding(path)
                if runtime_key not in inputs_spec:
                    inputs_spec[runtime_key] = f"{{runtime.{runtime_key}}}"
                replacements.append((path, f"{{input.{runtime_key}}}"))
            elif path in recorded_dbs or (
                self.db_root is not None and _inside(Path(path), self.db_root) and Path(path).exists()
            ):
                alias = self._database_entry(path)
                db_spec[alias] = {"logical_name": alias}
                replacements.append((path, f"{{database.{alias}}}"))
            elif path in recorded_outputs:
                key = f"out_{len(outputs_spec) + 1}"
                rel = f"{step_id}_{Path(path).name}"
                outputs_spec[key] = f"{{run_dir}}/{rel}"
                self.producer_outputs[path] = (step_id, rel)
                assertions.extend((f"exists:output.{key}", f"non_empty:output.{key}"))
                replacements.append((path, f"{{output.{key}}}"))
            elif _inside(Path(path), self.results_root):
                # An output-tree path that was not recorded as an input: treat
                # it as this step's own output (directory outputs are not in the
                # recorded file list) so no pre-test path leaks into production.
                key = f"out_{len(outputs_spec) + 1}"
                rel = f"{step_id}_{Path(path).name}"
                outputs_spec[key] = f"{{run_dir}}/{rel}"
                self.producer_outputs[path] = (step_id, rel)
                assertions.append(f"exists:output.{key}")
                replacements.append((path, f"{{output.{key}}}"))
                self.warnings.append(f"{step_id}: inferred output from output-tree path {path}")
            # anything else stays byte-for-byte identical to the verified command

        for path, token in replacements:
            script = script.replace(path, token)

        extension = {"bash": "sh", "python": "py", "r": "R"}[kind]
        if not outputs_spec:
            # The materialized script itself is the declared artifact; it is
            # written before execution, so the assertion is genuinely checkable.
            outputs_spec["script"] = f"{{run_dir}}/.steps/{step_id}.{extension}"
            assertions.append("exists:output.script")
        step = {
            "step_id": step_id,
            "purpose": f"Replay the verified successful pre-test command recorded in the execution ledger (attempt {attempt.get('attempt')})",
            "tool": tool_name,
            "recorded_tool": recorded_tool,
            "tool_version": version_output,
            "absolute_executable": interpreter,
            "environment_prefix": None,
            "interpreter": interpreter,
            "command_template": ["{executable}", f"{{run_dir}}/.steps/{step_id}.{extension}"],
            "script_template": script,
            "input_template": inputs_spec,
            "output_template": outputs_spec,
            "database_path": {alias: self.databases[alias]["path"] for alias in db_spec},
            "parameter_list": [],
            "success_assertions": assertions,
            "failure_criteria": ["nonzero_exit"],
            "validation_method": "recorded exit code 0 plus output existence/non-emptiness from the successful pre-test",
            "tool_choice": "verified successful pre-test execution",
            "dependencies": sorted(dependencies),
            "validation": {
                "source_attempt": attempt.get("attempt", 1),
                "step_status": "PASSED",
                "ledger_record_id": attempt.get("record_id"),
            },
            "input": inputs_spec,
            "output": outputs_spec,
            "database": db_spec,
            **_RESOURCE_POLICIES,
        }
        return step


# ---------------------------------------------------------------------------
# Metadata backfill builders — representations of execution facts, never gates
# ---------------------------------------------------------------------------


def _ensure_project(results_root: Path, raw_root: Path, db_root: Path | None) -> PipelineProject:
    project = PipelineProject(results_root)
    if project.config_path.is_file():
        return project
    database_root = db_root or (results_root / "databases")
    database_root.mkdir(parents=True, exist_ok=True)
    return PipelineProject.initialize(
        results_root,
        raw_data_path=raw_root,
        database_path=database_root,
        output_path=results_root,
    )


def _backfill_requirements(project: PipelineProject, sources: list[str]) -> dict[str, Any]:
    """Restore a previously approved snapshot; execution never confers approval."""
    from microbiome.pipeline.requirements import RequirementManager

    receipt = project.state_dir / "legacy_recovery_approval.json"
    if not receipt.is_file():
        raise ExecutionFactMissingError("旧执行日志需要先展示并确认恢复方案；不能从成功日志推断用户授权", fact="user_approval")
    approved = read_json(receipt)
    if approved.get("receipt_fingerprint") != object_fingerprint({k: v for k, v in approved.items() if k != "receipt_fingerprint"}):
        raise ExecutionFactMissingError("恢复授权记录已改变", fact="user_approval")
    if not project.requirements_path.is_file():
        write_yaml(project.requirements_path, approved["requirements"])
    return RequirementManager(project).require_confirmed()


def approve_recovery(project: PipelineProject, proposal_fingerprint: str, message: str) -> dict[str, Any]:
    """Explicitly accept the exact persisted legacy proposal displayed to the user."""
    from microbiome.pipeline.approval import ProductionApprovalManager, ProductionIntent
    from microbiome.pipeline.requirements import ConfirmationAction, RequirementManager

    if ProductionApprovalManager.classify_intent(message) is not ProductionIntent.APPROVE_PRODUCTION:
        raise ExecutionFactMissingError("恢复方案尚未明确确认", fact="user_approval")
    proposal = read_json(project.state_dir / "legacy_recovery_proposal.json")
    if (proposal.get("proposal_fingerprint") != proposal_fingerprint or proposal_fingerprint !=
            object_fingerprint({k: v for k, v in proposal.items() if k != "proposal_fingerprint"})):
        raise ExecutionFactMissingError("恢复方案已改变，需要重新展示", fact="user_approval")
    ledger = ExecutionLedger(project.pretest_dir / "pipeline" / "execution_ledger.jsonl")
    if proposal["ledger_digest"] != ledger.digest():
        raise ExecutionFactMissingError("执行记录已改变，需要重新核对", fact="user_approval")
    manager = RequirementManager(project)
    for topic, value in proposal["topics"].items():
        manager.decide(topic, value, action=ConfirmationAction.CONFIRM)
    plan = proposal["plan"]
    if manager.load()["requirements_version"] != plan["requirements_version"]:
        raise ExecutionFactMissingError("需求版本已改变，需要重新核对", fact="user_approval")
    for name in ("analysis_plan", "dependencies"):
        manager.set_approval(name, {"status": "CONFIRM", "confirmed_at": _utcnow(),
            "plan_fingerprint": plan["plan_fingerprint"], "requirements_version": plan["requirements_version"],
            "source": "explicit_legacy_recovery_review", "user_message": message})
    receipt = {"plan": plan, "requirements": manager.load(), "user_message": message,
               "proposal_fingerprint": proposal_fingerprint, "ledger_digest": ledger.digest()}
    receipt["receipt_fingerprint"] = object_fingerprint(receipt)
    write_json(project.state_dir / "legacy_recovery_approval.json", receipt)
    return receipt


def _synthesize_plan(
    project: PipelineProject, steps: list[dict[str, Any]], requirements: dict[str, Any], *, persist: bool = True
) -> dict[str, Any]:
    """Backfill experiment_plan.yaml from the successful steps (never re-planned)."""
    from microbiome.pipeline.models import validate_experiment_plan

    plan_steps = []
    for step in steps:
        plan_steps.append(
            {
                "step_id": step["step_id"],
                "purpose": step["purpose"],
                "tool": step["tool"],
                "tool_version_requirement": "verified in pre-test execution",
                "environment": {
                    "prefix": str(Path(step["absolute_executable"]).parent.parent),
                    "executable": step["absolute_executable"],
                    "version_args": ["--version"],
                    "installation_source": "verified successful pre-test execution",
                },
                "input": step["input"],
                "output": step["output"],
                "database": step["database"],
                "command_template": step["command_template"],
                "script_template": step["script_template"],
                "interpreter": step["interpreter"],
                "parameters": [],
                "success_criteria": list(step["success_assertions"]),
                "failure_criteria": list(step["failure_criteria"]),
                "dependencies": list(step["dependencies"]),
                "threads_policy": step["threads_policy"],
                "memory_policy": step["memory_policy"],
                "gpu_policy": step["gpu_policy"],
                "validation_method": list(step["success_assertions"]),
                "tool_choice": {
                    "selected": step["tool"],
                    "reason": ["verified successful in the pre-test execution"],
                    "alternatives_considered": [],
                },
            }
        )
    candidate = {
        "objective": requirements.get("analysis_goal", {}).get("objective", "Reviewed legacy execution recovery"),
        "plan_source": "recovered_from_successful_pretest",
        "requirements_version": requirements["requirements_version"],
        "steps": plan_steps,
    }
    normalized = validate_experiment_plan(candidate)
    if persist:
        write_yaml(project.plan_path, normalized)
    return normalized


def _tool_lock_entries(steps: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    return {
        step["step_id"]: {
            "tool": step["tool"],
            "executable": step["absolute_executable"],
            "version_output": step["tool_version"],
            "version_args": ["--version"],
            "environment_prefix": step.get("environment_prefix"),
        }
        for step in steps
    }


def build_bootstrap_report(
    plan: dict[str, Any], requirements: dict[str, Any], steps: list[dict[str, Any]]
) -> dict[str, Any]:
    report = {
        "schema_version": 1,
        "status": "PASSED",
        "source": "successful_pretest_execution",
        "generated_at": _utcnow(),
        "plan_fingerprint": plan["plan_fingerprint"],
        "requirements_version": requirements["requirements_version"],
        "tools": _tool_lock_entries(steps),
    }
    report["report_fingerprint"] = object_fingerprint(report)
    return report


def build_database_report(
    plan: dict[str, Any], requirements: dict[str, Any], databases: dict[str, Any]
) -> dict[str, Any]:
    report = {
        "schema_version": 1,
        "status": "PASSED",
        "source": "successful_pretest_execution",
        "generated_at": _utcnow(),
        "plan_fingerprint": plan["plan_fingerprint"],
        "requirements_version": requirements["requirements_version"],
        "databases": databases,
    }
    report["report_fingerprint"] = object_fingerprint(report)
    return report


def build_dependency_report(
    plan: dict[str, Any], requirements: dict[str, Any], steps: list[dict[str, Any]], databases: dict[str, Any]
) -> dict[str, Any]:
    report = {
        "schema_version": 1,
        "status": "SATISFIED_BY_SUCCESSFUL_PRETEST",
        "generated_at": _utcnow(),
        "requirements_version": requirements["requirements_version"],
        "plan_fingerprint": plan["plan_fingerprint"],
        "tools": [
            {
                "step_id": step["step_id"],
                "tool": step["tool"],
                "status": "READY",
                "executable": step["absolute_executable"],
            }
            for step in steps
        ],
        "databases": [
            {"alias": alias, "resource_id": entry["logical_name"], "status": "READY", "path": entry["path"]}
            for alias, entry in databases.items()
        ],
        "summary": {"READY": len(steps) + len(databases)},
    }
    report["report_fingerprint"] = object_fingerprint(report)
    return report


def build_validation_report_from_ledger(
    project: PipelineProject,
    plan: dict[str, Any],
    requirements: dict[str, Any],
    attempts: list[dict[str, Any]],
    steps: list[dict[str, Any]],
    synthesizer: _StepSynthesizer,
    *,
    bootstrap: dict[str, Any],
    database_report: dict[str, Any],
) -> dict[str, Any]:
    """Persist the already-happened successful execution as a validation report."""
    step_reports = []
    for step, attempt in zip(steps, attempts, strict=True):
        step_reports.append(
            {
                "step_id": step["step_id"],
                "status": "PASSED",
                "exact_executable_path": step["absolute_executable"],
                "exact_software_version": step["tool_version"],
                "exact_environment": step.get("environment_prefix"),
                "exact_command_line": [step["absolute_executable"], f"<script:{step['step_id']}>"],
                "exact_parameters": [],
                "exact_resources": {},
                "exact_database_path": step["database_path"],
                "input_files": step["input"],
                "output_files": step["output"],
                "exit_code": attempt.get("exit_code", 0),
                "runtime_seconds": None,
                "success_checks": step["success_assertions"],
                "failure_criteria": step["failure_criteria"],
                "source_attempt": attempt.get("attempt", 1),
            }
        )
    subset_outputs = [{"source": source, "pilot": subset} for subset, source in synthesizer.subset_map.items()]
    report = {
        "schema_version": 1,
        "phase": "VALIDATION",
        "validation_id": f"ledger-{datetime.now(UTC).strftime('%Y%m%dT%H%M%S%fZ')}",
        "status": "PASSED",
        "source": "successful_pretest_execution",
        "started_at": attempts[0].get("recorded_at"),
        "completed_at": _utcnow(),
        "plan_fingerprint": plan["plan_fingerprint"],
        "requirements_version": requirements["requirements_version"],
        "bootstrap_report_fingerprint": bootstrap["report_fingerprint"],
        "database_report_fingerprint": database_report["report_fingerprint"],
        "representative_subset": {"outputs": subset_outputs},
        "resource_strategy": "MAXIMIZE_WITHIN_LIVE_AND_FROZEN_LIMITS",
        "resource_snapshot": None,
        "runtime_input_source": {key: path_fingerprint(source) for source, key in synthesizer.runtime_keys.items()},
        "validation_root": str(project.pretest_dir),
        "steps": step_reports,
        "failed_step": None,
        "failure": None,
    }
    report["report_path"] = str(project.validation_report_path)
    report["report_fingerprint"] = object_fingerprint(report)
    return report


def _write_registries(project: PipelineProject, steps: list[dict[str, Any]], databases: dict[str, Any]) -> None:
    config = project.load_config()
    tools = {}
    for step in steps:
        contract: Any = "none"
        if step["database"]:
            contract = {alias: {"resource_id": alias} for alias in step["database"]}
        tools[step["step_id"]] = {
            "tool_id": step["tool"],
            "conda_prefix": step.get("environment_prefix"),
            "executable": step["absolute_executable"],
            "version": step["tool_version"],
            "version_args": ["--version"],
            "allow_setup_in_production": False,
            "allow_db_build_in_production": False,
            "database_contract": contract,
        }
    tool_registry = {
        "schema_version": 1,
        "generated_at": _utcnow(),
        "source": "successful_pretest_execution",
        "tools": tools,
    }
    tool_registry["manifest_fingerprint"] = manifest_fingerprint(tool_registry)
    write_yaml(project.tool_registry_path, tool_registry)

    resources = {
        alias: {
            "status": "READY",
            "read_only": True,
            "root_path": entry["root_path"],
            "runtime_entry": entry["runtime_entry"],
            "consumer_entrypoints": dict(entry.get("consumer_entrypoints") or {}),
            "common_markers": list(entry.get("common_markers") or []),
            "consumer_markers": dict(entry.get("consumer_markers") or {}),
            "version": str(entry.get("database_version", "UNKNOWN")),
            "marker_files": list(entry["expected_marker_files"]),
            "fingerprint": entry["fingerprint"],
        }
        for alias, entry in databases.items()
    }
    database_registry = {
        "schema_version": 1,
        "generated_at": _utcnow(),
        "source": "successful_pretest_execution",
        "database_root": config["paths"]["database"],
        "resources": resources,
    }
    database_registry["manifest_fingerprint"] = manifest_fingerprint(database_registry)
    write_yaml(project.database_registry_path, database_registry)


def _write_locks(
    project: PipelineProject,
    *,
    plan: dict[str, Any],
    requirements: dict[str, Any],
    validation: dict[str, Any],
    steps: list[dict[str, Any]],
    databases: dict[str, Any],
    ledger: ExecutionLedger,
) -> dict[str, Any]:
    from microbiome.pipeline.inputs import build_production_input_contract

    if project.pipeline_lock_path.is_file():
        current = read_yaml(project.pipeline_lock_path)
        if (current.get("manifest_fingerprint") != manifest_fingerprint(current)
                or current.get("plan_fingerprint") != plan["plan_fingerprint"]):
            raise ExecutionFactMissingError("已冻结流程不能被恢复流程覆盖", fact="pipeline_lock")
        if current.get("execution_ledger", {}).get("sha256") != ledger.digest():
            raise ExecutionFactMissingError("冻结后的执行记录已改变", fact="pipeline_lock")
        return current

    toolchain_lock = {
        "schema_version": 1,
        "generated_at": _utcnow(),
        "source": "successful_pretest_execution",
        "tools": _tool_lock_entries(steps),
    }
    toolchain_lock["manifest_fingerprint"] = manifest_fingerprint(toolchain_lock)
    database_lock = {
        "schema_version": 1,
        "generated_at": _utcnow(),
        "source": "successful_pretest_execution",
        "databases": databases,
    }
    database_lock["manifest_fingerprint"] = manifest_fingerprint(database_lock)
    try:
        contract = build_production_input_contract(project, validation)
    except PipelineError as exc:
        raise ExecutionFactMissingError(f"成功流程无法绑定到完整数据：{exc} / The successful workflow cannot be bound to the full dataset: {exc}", fact="input_binding") from exc

    pipeline = {
        "schema_version": 1,
        "created_at": _utcnow(),
        "mode": "production replay; no LLM planning is permitted",
        "objective": plan["objective"],
        "requirements_version": requirements["requirements_version"],
        "requirements_fingerprint": requirements["requirements_fingerprint"],
        "plan_fingerprint": plan["plan_fingerprint"],
        "validation_status": "PASSED",
        "validation_report_fingerprint": validation["report_fingerprint"],
        "resource_strategy": "MAXIMIZE_WITHIN_LIVE_AND_FROZEN_LIMITS",
        "validated_resource_snapshot": validation.get("resource_snapshot"),
        "production_input_contract": contract,
        "toolchain_lock_fingerprint": toolchain_lock["manifest_fingerprint"],
        "database_lock_fingerprint": database_lock["manifest_fingerprint"],
        "execution_ledger": {
            "path": str(ledger.path),
            "records": len(ledger.entries()),
            "sha256": ledger.digest(),
        },
        "steps": steps,
    }
    pipeline["pipeline_hash"] = manifest_fingerprint(pipeline)
    pipeline["pipeline_version"] = f"r{requirements['requirements_version']}-{pipeline['pipeline_hash'][:16]}"
    pipeline["manifest_fingerprint"] = manifest_fingerprint(pipeline)

    if project.pipeline_lock_path.is_file():
        current = read_yaml(project.pipeline_lock_path)
        if current.get("manifest_fingerprint") == pipeline["manifest_fingerprint"]:
            return current
    write_yaml(project.toolchain_lock_path, toolchain_lock)
    write_yaml(project.database_lock_path, database_lock)
    write_yaml(project.pipeline_lock_path, pipeline)
    atomic_write_text(
        project.pipeline_dir / "run_pipeline.py",
        '#!/usr/bin/env python3\n"""Generated entry point for deterministic replay of this frozen project."""\nfrom microbiome.pipeline.cli import main\n\nif __name__ == "__main__":\n    raise SystemExit(main())\n',
    )
    (project.pipeline_dir / "run_pipeline.py").chmod(0o755)
    return pipeline


def _advance_without_backtrack(machine: ProjectStateMachine, target: LifecycleState, reason: str) -> None:
    """Advance the lifecycle toward ``target``; never move it backwards.

    Re-running finalization on an already-finalized project is idempotent:
    a project already at/behind the target stays where it is.
    """
    from microbiome.pipeline.state import CANONICAL_ORDER

    current = machine.current
    if current == LifecycleState.PRETEST_FINALIZATION_FAILED:
        machine.transition(LifecycleState.PRETEST_FINALIZING, reason="retrying auto-finalization")
        current = machine.current
    if current not in CANONICAL_ORDER or target not in CANONICAL_ORDER:
        return
    if CANONICAL_ORDER.index(current) < CANONICAL_ORDER.index(target):
        machine.advance_to(target, reason=reason)


def _analysis_attempts(
    entries: list[dict[str, Any]],
    raw_root: Path,
    excluded_roots: tuple[Path, ...] = (),
) -> list[dict[str, Any]]:
    """Final successful analysis attempts in execution order (retries: last wins)."""
    chosen: dict[str, tuple[int, dict[str, Any]]] = {}
    for index, entry in enumerate(entries):
        if entry.get("status") != "PASSED" or not entry.get("verified"):
            continue
        if _is_preparation(entry, raw_root, excluded_roots):
            continue
        command = entry.get("command") or {}
        code = str(command.get("code") or "").strip()
        if not code and command.get("argv"):
            code = shlex.join([str(item) for item in command["argv"]])
        if not code:
            continue
        chosen[code] = (index, entry)  # identical re-runs collapse; corrections supersede
    return [entry for _index, entry in sorted(chosen.values(), key=lambda pair: pair[0])]


def finalize_successful_pretest(
    results_root: str | Path,
    *,
    raw_root: str | Path | None = None,
    db_root: str | Path | None = None,
    review_requirements: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Review or finalize legacy execution with separately persisted authorization.

    ``review_requirements`` produces a proposal without confirming or freezing it.
    Otherwise a matching receipt from :func:`approve_recovery` is required.
    Missing execution facts and missing/stale authorization both block freezing.
    """
    results = canonical_path(results_root)
    if raw_root is None:
        raise ExecutionFactMissingError("不知道完整原始数据在哪里（RAW_DATA_PATH 未配置）/ The location of the complete raw data is unknown (RAW_DATA_PATH is not configured)", fact="raw_data_path")
    raw = canonical_path(raw_root, must_exist=True)
    db = canonical_path(db_root) if db_root else None

    ledger = ExecutionLedger(results / "pre_test_run" / "pipeline" / "execution_ledger.jsonl")
    entries = ledger.entries()
    excluded_roots = tuple(root for root in (results, db) if root is not None and is_same_or_within(root, raw))
    attempts = _analysis_attempts(entries, raw, excluded_roots)
    if not attempts:
        raise ExecutionFactMissingError(
            "execution ledger 中没有已验证成功的分析步骤，无法确定任何最终成功命令 / The execution ledger contains no verified successful analysis steps, so no final successful command can be determined",
            fact="successful_steps",
        )

    project = _ensure_project(results, raw, db)
    lineage_subset_map, lineage_full_sources = _validation_lineage(project)
    mapping_subset_map, mapping_full_sources = _source_mapping_lineage(project)
    lineage_subset_map.update(mapping_subset_map)

    synthesizer = _StepSynthesizer(raw_root=raw, db_root=db, results_root=results)
    synthesizer.subset_map = _subset_source_map(entries, raw, excluded_roots)
    synthesizer.subset_map.update(lineage_subset_map)
    synthesizer.collect_sources(attempts)
    for source in [*lineage_full_sources, *mapping_full_sources]:
        if source not in synthesizer.runtime_sources:
            synthesizer.runtime_sources.append(source)
    if synthesizer.runtime_sources:
        synthesizer.runtime_keys = synthesizer._assign_runtime_keys(synthesizer.runtime_sources)
    if not synthesizer.runtime_sources:
        # Forensic audit distinguishes a false pass (no subset files / no real
        # process execution) from a genuine lineage gap. Only a false pass may
        # send the lifecycle back to a real pre-test; a lineage gap is repaired
        # from the persisted input/subset manifest without re-running science.
        from microbiome.pipeline.pretest_evidence import classify_pretest_evidence

        evidence = classify_pretest_evidence(project)
        if evidence.is_false_pass:
            raise ExecutionFactMissingError(
                "此前记录的“小试通过”缺少真实运行证据：/ The previously recorded “pilot passed” lacks real execution evidence: " + "；".join(evidence.details),
                fact="false_pretest",
            )
        raise ExecutionFactMissingError(
            "成功流程无法绑定到完整数据：成功命令未读取任何 subset/原始输入（数据血缘缺失）/ The successful workflow cannot be bound to the full dataset: no successful command read any subset/raw input (data lineage missing)",
            fact="input_binding",
        )

    steps = [synthesizer.build_step(index, attempt) for index, attempt in enumerate(attempts, start=1)]
    if not any(step["output_template"] for step in steps):
        raise ExecutionFactMissingError(
            "关键输出没有验证：全部成功步骤都没有记录到可验证的输出文件 / Key outputs are unverified: none of the successful steps recorded a verifiable output file", fact="output_validation"
        )

    from microbiome.pipeline.requirements import RequirementManager
    manager = RequirementManager(project)
    if review_requirements is not None:
        if set(review_requirements) != {"input", "dataset", "target", "analysis_goal"} or not all(
                isinstance(value, dict) and value for value in review_requirements.values()):
            raise ExecutionFactMissingError("恢复方案需要明确输入、样本、分析对象和研究目标", fact="requirements")
        current = manager.load()
        version = current["requirements_version"] + sum(
            current.get(topic) != value or not current["confirmed_fields"].get(topic)
            for topic, value in review_requirements.items())
        candidate = _synthesize_plan(project, steps, {**review_requirements, "requirements_version": version}, persist=False)
        proposal = {"plan": candidate, "topics": review_requirements, "ledger_digest": ledger.digest(),
                    "paths": project.load_config()["paths"]}
        proposal["proposal_fingerprint"] = object_fingerprint(proposal)
        write_json(project.state_dir / "legacy_recovery_proposal.json", proposal)
        return proposal
    requirements = _backfill_requirements(project, synthesizer.runtime_sources)
    receipt = read_json(project.state_dir / "legacy_recovery_approval.json")
    if receipt["ledger_digest"] != ledger.digest():
        raise ExecutionFactMissingError("执行记录已改变，需要重新审核恢复方案", fact="user_approval")
    plan = receipt["plan"]
    candidate = _synthesize_plan(project, steps, requirements, persist=False)
    if candidate["plan_fingerprint"] != plan["plan_fingerprint"]:
        raise ExecutionFactMissingError("执行事实与已确认方案不一致", fact="user_approval")
    for name in ("analysis_plan", "dependencies"):
        approval = requirements.get("approvals", {}).get(name, {})
        if (approval.get("status") != "CONFIRM" or approval.get("plan_fingerprint") != plan["plan_fingerprint"]
                or approval.get("requirements_version") != requirements["requirements_version"]):
            raise ExecutionFactMissingError("需求或方案授权已过期", fact="user_approval")
    if project.plan_path.is_file() and read_yaml(project.plan_path) != plan:
        raise ExecutionFactMissingError("当前方案不同于已确认恢复方案", fact="user_approval")
    write_yaml(project.plan_path, plan)

    bootstrap_path = project.state_dir / "bootstrap_report.json"
    bootstrap = build_bootstrap_report(plan, requirements, steps)
    if not bootstrap_path.is_file():
        write_json(bootstrap_path, bootstrap)
    database_path = project.state_dir / "database_resolution.json"
    database_report = build_database_report(plan, requirements, synthesizer.databases)
    if not database_path.is_file():
        write_json(database_path, database_report)
    dependency_path = project.plans_dir / "dependency_gap_report.yaml"
    if not dependency_path.is_file():
        write_yaml(dependency_path, build_dependency_report(plan, requirements, steps, synthesizer.databases))
    if not project.validation_report_path.is_file():
        write_json(
            project.validation_report_path,
            build_validation_report_from_ledger(
                project,
                plan,
                requirements,
                attempts,
                steps,
                synthesizer,
                bootstrap=bootstrap,
                database_report=database_report,
            ),
        )
    validation = read_json(project.validation_report_path)
    _write_registries(project, steps, synthesizer.databases)
    lock = _write_locks(
        project,
        plan=plan,
        requirements=requirements,
        validation=validation,
        steps=steps,
        databases=synthesizer.databases,
        ledger=ledger,
    )
    validate_pipeline_lock(read_yaml(project.pipeline_lock_path))

    machine = ProjectStateMachine(project)
    if not project.lifecycle_state_path.is_file():
        machine.initialize(paths_confirmed=True)
    _advance_without_backtrack(
        machine,
        LifecycleState.FROZEN,
        "pipeline lock built from verified successful pre-test execution records",
    )

    from microbiome.pipeline.readiness import ProductionReadinessChecker

    readiness = ProductionReadinessChecker(project).check()
    if not readiness.get("ready"):
        error = ExecutionFactMissingError(
            "生产就绪检查未通过：/ Production readiness check failed: " + "；".join(readiness.get("missing_artifacts", [])),
            fact="readiness",
        )
        machine.record_finalization_failure(error.category, detail=str(error))
        if machine.current == LifecycleState.FROZEN:
            machine.transition(
                LifecycleState.PRETEST_FINALIZATION_FAILED,
                reason="; ".join(readiness.get("missing_artifacts", []))[:400],
            )
        raise error
    _advance_without_backtrack(
        machine,
        LifecycleState.AWAITING_PRODUCTION_APPROVAL,
        "production is ready; waiting for explicit user approval",
    )
    readiness["synthesized_from_ledger"] = True
    readiness["steps"] = len(steps)
    readiness["synthesis_warnings"] = synthesizer.warnings
    readiness["pipeline_version"] = lock["pipeline_version"]
    return readiness


def backfill_management_artifacts(project: PipelineProject) -> list[str]:
    """Rebuild missing management artifacts of a plan-based project from facts.

    Only missing files are written, and only from verified ledger records /
    registry facts — a plan step without a verified successful attempt cannot
    be backfilled and is left missing (the freeze then reports it honestly).
    Returns the list of backfilled artifact names.
    """
    from microbiome.pipeline.lifecycle import load_plan
    from microbiome.pipeline.requirements import RequirementManager

    if not project.plan_path.is_file():
        return []  # plan-less projects are handled by finalize_successful_pretest
    plan = load_plan(project)
    requirements = RequirementManager(project).require_confirmed()
    ledger = ExecutionLedger.for_project(project)
    records: dict[str, dict[str, Any]] = {}
    for entry in ledger.entries():
        if entry.get("status") == "PASSED" and entry.get("verified"):
            records[str(entry.get("step_id"))] = entry
    backfilled: list[str] = []

    bootstrap_path = project.state_dir / "bootstrap_report.json"
    if not bootstrap_path.is_file():
        tools: dict[str, Any] = {}
        for step in plan["steps"]:
            record = records.get(step["step_id"])
            if record is None:
                break
            tool = record.get("tool") or {}
            environment = record.get("environment") or {}
            tools[step["step_id"]] = {
                "tool": step["tool"],
                "executable": tool.get("executable"),
                "version_output": tool.get("version") or "",
                "version_args": ["--version"],
                "environment_prefix": environment.get("conda_prefix"),
            }
        else:
            report = {
                "schema_version": 1,
                "status": "PASSED",
                "source": "successful_pretest_execution",
                "generated_at": _utcnow(),
                "plan_fingerprint": plan["plan_fingerprint"],
                "requirements_version": requirements["requirements_version"],
                "tools": tools,
            }
            report["report_fingerprint"] = object_fingerprint(report)
            write_json(bootstrap_path, report)
            backfilled.append("bootstrap_report.json")

    database_path = project.state_dir / "database_resolution.json"
    if not database_path.is_file():
        logical_names = sorted(
            {
                str(spec.get("logical_name") or alias)
                for step in plan["steps"]
                for alias, spec in (step.get("database") or {}).items()
                if isinstance(spec, dict)
            }
        )
        databases: dict[str, Any] = {}
        if logical_names:
            from microbiome.pipeline.registry import load_database_registry

            registry = load_database_registry(
                project.database_registry_path,
                database_root=project.load_config()["paths"]["database"],
            )
            for name in logical_names:
                registered = (registry.get("resources") or {}).get(name)
                if not registered:
                    break
                databases[name] = {
                    "logical_name": name,
                    "path": registered.get("runtime_entry") or registered.get("root_path"),
                    "root_path": registered.get("root_path"),
                    "runtime_entry": registered.get("runtime_entry"),
                    "consumer_entrypoints": dict(registered.get("consumer_entrypoints") or {}),
                    "common_markers": list(registered.get("common_markers") or []),
                    "consumer_markers": dict(registered.get("consumer_markers") or {}),
                    "expected_marker_files": list(registered.get("marker_files") or []),
                    "database_version": registered.get("version", "UNKNOWN"),
                    "fingerprint": registered.get("fingerprint"),
                }
            else:
                report = {
                    "schema_version": 1,
                    "status": "PASSED",
                    "source": "successful_pretest_execution",
                    "generated_at": _utcnow(),
                    "plan_fingerprint": plan["plan_fingerprint"],
                    "requirements_version": requirements["requirements_version"],
                    "databases": databases,
                }
                report["report_fingerprint"] = object_fingerprint(report)
                write_json(database_path, report)
                backfilled.append("database_resolution.json")
        elif not logical_names:
            report = {
                "schema_version": 1,
                "status": "PASSED",
                "source": "successful_pretest_execution",
                "generated_at": _utcnow(),
                "plan_fingerprint": plan["plan_fingerprint"],
                "requirements_version": requirements["requirements_version"],
                "databases": {},
            }
            report["report_fingerprint"] = object_fingerprint(report)
            write_json(database_path, report)
            backfilled.append("database_resolution.json")

    dependency_path = project.plans_dir / "dependency_gap_report.yaml"
    if not dependency_path.is_file():
        report = {
            "schema_version": 1,
            "status": "SATISFIED_BY_SUCCESSFUL_PRETEST",
            "generated_at": _utcnow(),
            "requirements_version": requirements["requirements_version"],
            "plan_fingerprint": plan["plan_fingerprint"],
            "tools": [
                {
                    "step_id": step["step_id"],
                    "tool": step["tool"],
                    "status": "READY" if step["step_id"] in records else "UNKNOWN",
                    "executable": (records.get(step["step_id"], {}).get("tool") or {}).get("executable"),
                }
                for step in plan["steps"]
            ],
            "databases": [],
            "summary": {},
        }
        report["report_fingerprint"] = object_fingerprint(report)
        write_yaml(dependency_path, report)
        backfilled.append("dependency_gap_report.yaml")
    return backfilled
