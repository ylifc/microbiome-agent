"""Production input contracts and RAW_DATA_PATH rebinding."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any
from pathlib import Path

from microbiome.path_policy import is_same_or_within, iter_files_pruned
from microbiome.pipeline.errors import ConfigurationError, FreezeError, PreflightError
from microbiome.pipeline.io import canonical_path, fast_file_fingerprint, object_fingerprint, path_fingerprint, read_yaml

if TYPE_CHECKING:
    from pathlib import Path

    from microbiome.pipeline.project import PipelineProject


def _inside(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


SEQUENCE_SUFFIX_RE = re.compile(r"\.(?:fastq|fq|fasta|fa|fna|faa)(?:\.gz)?$", re.IGNORECASE)
FASTQ_SUFFIX_RE = re.compile(r"\.(?:fastq|fq)(?:\.gz)?$", re.IGNORECASE)
PAIR_TOKEN_RE = re.compile(r"(?i)(?:^|[._-])R?([12])(?:[._-]|$)")


def _sequence_family(path: Path) -> str | None:
    if FASTQ_SUFFIX_RE.search(path.name):
        return "FASTQ"
    if SEQUENCE_SUFFIX_RE.search(path.name):
        return "FASTA"
    return None


def _raw_dataset_inventory(
    raw_root: Path,
    *,
    excluded_roots: tuple[Path, ...] = (),
) -> list[dict[str, Any]]:
    targets = []
    for path in (
        item
        for item in iter_files_pruned(raw_root, excluded_roots=excluded_roots)
        if SEQUENCE_SUFFIX_RE.search(item.name)
    ):
        targets.append(
            {
                "path": str(path.resolve()),
                "relative_path": str(path.relative_to(raw_root)),
                "sequence_family": _sequence_family(path),
                "fingerprint": fast_file_fingerprint(path),
            }
        )
    if not targets:
        raise FreezeError(f"RAW_DATA_PATH contains no supported FASTA/FASTQ targets: {raw_root}")
    return targets


def _sample_and_mate(path: Path) -> tuple[str, str | None]:
    name = SEQUENCE_SUFFIX_RE.sub("", path.name)
    matches = list(PAIR_TOKEN_RE.finditer(name))
    if not matches:
        return name, None
    match = matches[-1]
    sample = f"{name[: match.start()]}_{name[match.end() :]}".strip("._-") or name
    return sample, match.group(1)


_RUNTIME_MATE1_KEYS = {"reads_1", "read_1", "r1", "forward"}
_RUNTIME_MATE2_KEYS = {"reads_2", "read_2", "r2", "reverse"}


def _runtime_mate_map(sequence_keys: list[str]) -> dict[str, str]:
    """Map frozen runtime keys to their mate roles ('1'/'2' or 'single')."""
    lowered = {key: key.casefold() for key in sequence_keys}
    mate1 = next((key for key in sequence_keys if lowered[key] in _RUNTIME_MATE1_KEYS), None)
    mate2 = next((key for key in sequence_keys if lowered[key] in _RUNTIME_MATE2_KEYS), None)
    if mate1 and mate2 and len(sequence_keys) == 2:
        return {"1": mate1, "2": mate2}
    if len(sequence_keys) == 1:
        return {"single": sequence_keys[0]}
    return {}


def _manifest_sample_path(sample: dict[str, Any], field: str) -> str | None:
    """Extract a sample file path from either the flat or nested manifest schema."""
    value = sample.get(field)
    if isinstance(value, dict):
        value = value.get("path")
    if isinstance(value, str) and value.strip():
        return value.strip()
    source = sample.get("source")
    if isinstance(source, dict):
        value = source.get(field)
        if isinstance(value, dict):
            value = value.get("path")
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


def _load_input_manifest_samples(
    project,
    raw_root: Path,
) -> tuple[list[dict[str, Any]] | None, str | None]:
    """Return the full sample list from input_manifest.yaml (single source of truth).

    Falls back to the original sample_list.txt only when the manifest is missing
    and a conventional manifest file actually exists under RAW_DATA_PATH. It
    never re-scans or re-guesses the whole RAW_DATA_PATH.
    """
    manifest_path = project.requirements_dir / "input_manifest.yaml"
    if manifest_path.is_file():
        try:
            payload = read_yaml(manifest_path)
        except Exception as exc:
            raise FreezeError(f"persisted input manifest cannot be read: {manifest_path}: {exc}") from exc
        if not isinstance(payload, dict) or not isinstance(payload.get("samples"), list):
            raise FreezeError(f"persisted input manifest has no valid samples list: {manifest_path}")
        digest = payload.get("manifest_fingerprint")
        if digest and digest != object_fingerprint({k: v for k, v in payload.items() if k != "manifest_fingerprint"}):
            raise FreezeError("persisted input manifest fingerprint is invalid")
        if payload.get("requires_raw_data_download"):
            raise FreezeError("input manifest still contains pending remote acquisition")
        source_label = "INPUT_MANIFEST"
    else:
        candidates = (
            raw_root / "sample_list.txt",
            raw_root / "samples.tsv",
            raw_root / "samples.csv",
            raw_root / "manifest.txt",
        )
        if not any(path.is_file() for path in candidates):
            return None, None
        try:
            from microbiome.input_resolution import InputSourceResolver

            result = InputSourceResolver(raw_root, output_root=project.output_root).resolve(
                "sample_list.txt", allow_sra_download=False
            )
            if not result.samples:
                raise FreezeError("sample_list.txt did not resolve any usable local samples")
            normalized = []
            for sample in result.samples:
                normalized.append(
                    {
                        "sample_id": sample.sample_id,
                        "r1": sample.r1,
                        "r2": sample.r2,
                        "fasta": sample.fasta,
                    }
                )
            if not normalized:
                raise FreezeError("sample_list.txt did not contain a valid sample record")
            return normalized, "SAMPLE_LIST"
        except FreezeError:
            raise
        except Exception as exc:
            raise FreezeError(f"sample_list.txt cannot be resolved for production: {exc}") from exc
    normalized = []
    identities = set()
    for sample in payload["samples"]:
        if not isinstance(sample, dict):
            raise FreezeError("input manifest contains an invalid sample record")
        sample_id = str(sample.get("sample_id") or sample.get("id") or "").strip()
        if not sample_id or sample_id in identities:
            raise FreezeError("input manifest contains missing or duplicate sample identifiers")
        identities.add(sample_id)
        if sample.get("error") or not any(_manifest_sample_path(sample, role) for role in ("r1", "fasta")):
            raise FreezeError(f"input manifest sample {sample_id!r} is not localized")
        normalized.append(
            {
                "sample_id": sample_id,
                "r1": _manifest_sample_path(sample, "r1"),
                "r2": _manifest_sample_path(sample, "r2"),
                "fasta": _manifest_sample_path(sample, "fasta"),
            }
        )
    if not normalized:
        raise FreezeError(f"persisted input manifest contains no usable samples: {manifest_path}")
    return normalized, source_label


def build_production_input_contract(
    project: PipelineProject,
    validation: dict[str, Any],
) -> dict[str, Any]:
    """Bind runtime keys to their full original inputs, never pilot artifacts."""
    manifest_path = project.requirements_dir / "input_manifest.yaml"
    manifest = read_yaml(manifest_path) if manifest_path.is_file() else {}
    if manifest.get("input_kind") == "completed_run_artifacts":
        from microbiome.pipeline.derived import derived_contract
        return derived_contract(project, validation, manifest, read_yaml(project.plan_path))
    if manifest.get("input_kind") == "external_cohort_tables":
        from microbiome.pipeline.external_cohort import external_contract
        return external_contract(project, validation, manifest, read_yaml(project.plan_path))
    raw_root = canonical_path(project.load_config()["paths"]["raw_data"], must_exist=True)
    path_policy = project.path_policy()
    excluded_roots = path_policy.input_exclusion_roots
    source_values = validation.get("runtime_input_source", {})
    if not isinstance(source_values, dict) or not source_values:
        raise FreezeError("validation report does not record original runtime inputs")
    subset_outputs = validation.get("representative_subset", {}).get("outputs", [])
    pilot_by_source = {
        str(canonical_path(item["source"])): str(canonical_path(item["pilot"]))
        for item in subset_outputs
        if isinstance(item, dict) and item.get("source") and item.get("pilot")
    }
    bindings: dict[str, Any] = {}
    samples, input_source = _load_input_manifest_samples(project, raw_root)
    declared = {str(canonical_path(sample[role])) for sample in samples or []
                for role in ("r1", "r2", "fasta") if sample.get(role)}
    for key, metadata in sorted(source_values.items()):
        if not isinstance(metadata, dict) or not metadata.get("path"):
            raise FreezeError(f"validation input {key!r} does not record an original path")
        source = canonical_path(metadata["path"], must_exist=True)
        if not _inside(source, raw_root) and str(source) not in declared:
            raise FreezeError(
                f"validation input {key!r} is outside RAW_DATA_PATH and cannot be frozen for production: {source}"
            )
        if any(is_same_or_within(source, root) for root in excluded_roots):
            raise FreezeError(
                f"validation input {key!r} points into an excluded output/database tree: {source}"
            )
        pilot = pilot_by_source.get(str(source))
        bindings[str(key)] = {
            "source_path": str(source),
            "source_fingerprint": metadata,
            "pilot_subset_path": pilot,
        }
    # The full sample list is the single source of truth for which full raw
    # files belong to which sample. When input_manifest.yaml exists (or can be
    # recovered from sample_list.txt) we use it directly and do not re-scan or
    # re-guess the whole RAW_DATA_PATH.
    sample_files = {}
    for path in sorted(declared):
        target = canonical_path(path)
        if not target.is_file() or any(is_same_or_within(target, root) for root in excluded_roots):
            raise FreezeError(f"manifest input is not a usable raw file: {target}")
        sample_files[path] = fast_file_fingerprint(target)
    payload = {
        "binding_mode": "RAW_DATA_ROOT_RUNTIME_REBIND",
        "raw_data_root": str(raw_root),
        "input_exclusion_roots": [str(path) for path in excluded_roots],
        "bindings": bindings,
        "samples": samples,
        "sample_file_fingerprints": sample_files,
        "project_paths": {key: project.load_config()["paths"].get(key) for key in
                          ("raw_data", "download", "database", "output", "knowledge")},
        "input_source": input_source or "FROZEN_RAW_INVENTORY",
        "full_dataset_targets": (
            None
            if samples is not None
            else _raw_dataset_inventory(raw_root, excluded_roots=excluded_roots)
        ),
        "forbid_pretest_inputs": True,
    }
    plan = read_yaml(project.plan_path) if project.plan_path.is_file() else {}
    if plan.get("execution_scope") == "cohort":
        from microbiome.pipeline.cohort import cohort_runtime_inputs
        manifest = read_yaml(project.requirements_dir / "input_manifest.yaml")
        expected_inputs = cohort_runtime_inputs(plan, manifest)
        if {key: value["source_path"] for key, value in bindings.items()} != expected_inputs:
            raise FreezeError("cohort validation did not use every declared sample and mate")
        payload["binding_mode"] = "COHORT_MANIFEST"
        payload["cohort_members"] = plan["cohort_members"]
    payload["contract_fingerprint"] = object_fingerprint(payload)
    return payload


class ProductionInputResolver:
    """Resolve production inputs under RAW_DATA_PATH and reject subset leakage."""

    def __init__(self, project: PipelineProject, pipeline: dict[str, Any]):
        self.project = project
        self.pipeline = pipeline
        self.contract = pipeline.get("production_input_contract")
        if not isinstance(self.contract, dict):
            raise PreflightError("pipeline lock has no production RAW_DATA_PATH input contract")
        expected = object_fingerprint(
            {key: value for key, value in self.contract.items() if key != "contract_fingerprint"}
        )
        if self.contract.get("contract_fingerprint") != expected:
            raise PreflightError("production input contract fingerprint is invalid")
        configured_root = canonical_path(project.load_config()["paths"]["raw_data"], must_exist=True)
        locked_root = canonical_path(self.contract.get("raw_data_root", ""), must_exist=True)
        if configured_root != locked_root:
            raise PreflightError(
                f"RAW_DATA_PATH changed after validation: locked={locked_root}, configured={configured_root}"
            )
        self.raw_root = locked_root
        policy = project.path_policy()
        self.excluded_roots = policy.input_exclusion_roots
        locked_exclusions = self.contract.get("input_exclusion_roots")
        if isinstance(locked_exclusions, list):
            expected_exclusions = {str(path) for path in self.excluded_roots}
            actual_exclusions = {str(canonical_path(path)) for path in locked_exclusions}
            if actual_exclusions != expected_exclusions:
                raise PreflightError(
                    "configured input exclusion roots changed after validation: "
                    f"locked={sorted(actual_exclusions)}, configured={sorted(expected_exclusions)}"
                )
        samples = self.contract.get("samples")
        self.samples = samples if isinstance(samples, list) else None
        locked_paths = self.contract.get("project_paths")
        if locked_paths and locked_paths != {key: project.load_config()["paths"].get(key) for key in locked_paths}:
            raise PreflightError("project paths changed after validation")

    def _allowed_input(self, path: Path) -> bool:
        if self._is_excluded(path):
            return False
        files = self.contract.get("sample_file_fingerprints", {})
        if files:
            metadata = files.get(str(path))
            if metadata is not None:
                return path.is_file() and metadata == fast_file_fingerprint(path)
            # Non-sequence auxiliary inputs must match their original binding.
            if metadata is None:
                metadata = next((value.get("source_fingerprint") for value in self.bindings.values()
                                 if value.get("source_path") == str(path)), None)
            return bool(metadata and metadata == path_fingerprint(path))
        return _inside(path, self.raw_root)

    def _is_excluded(self, path: Path) -> bool:
        return any(is_same_or_within(path, root) for root in self.excluded_roots)

    @property
    def bindings(self) -> dict[str, dict[str, Any]]:
        bindings = self.contract.get("bindings", {})
        if not isinstance(bindings, dict) or not bindings:
            raise PreflightError("production input contract has no runtime bindings")
        return bindings

    def _verified_targets(self) -> list[Path]:
        targets = self.contract.get("full_dataset_targets")
        if not isinstance(targets, list) or not targets:
            raise PreflightError("production input contract has no frozen full-dataset target inventory")
        verified = []
        for item in targets:
            if not isinstance(item, dict) or not item.get("path"):
                raise PreflightError("production target inventory contains an invalid entry")
            path = canonical_path(item["path"], must_exist=True)
            if not path.is_file() or not _inside(path, self.raw_root) or self._is_excluded(path):
                raise PreflightError(f"frozen production target escaped RAW_DATA_PATH: {path}")
            if item.get("fingerprint") != fast_file_fingerprint(path):
                raise PreflightError(f"frozen production target drifted after validation: {path}")
            verified.append(path)
        live_targets = {
            path.resolve()
            for path in iter_files_pruned(self.raw_root, excluded_roots=self.excluded_roots)
            if SEQUENCE_SUFFIX_RE.search(path.name)
        }
        if live_targets != set(verified):
            added = sorted(str(path) for path in live_targets - set(verified))
            removed = sorted(str(path) for path in set(verified) - live_targets)
            raise PreflightError(
                "RAW_DATA_PATH target inventory changed after validation; revalidation is required"
                f" (added={added}, removed={removed})"
            )
        return verified

    def _manifest_bindings(self, sequence_keys: list[str], static: dict[str, str]) -> list[dict[str, Any]]:
        """Build one production job per full sample from the persisted manifest.

        This is the corrected path: full sample identity and file paths come from
        input_manifest.yaml, never from re-scanning and re-guessing RAW_DATA_PATH.
        """
        mate_map = _runtime_mate_map(sequence_keys)
        jobs: list[dict[str, Any]] = []
        missing: list[str] = []
        for sample in self.samples or []:
            if not isinstance(sample, dict):
                continue
            sample_id = str(sample.get("sample_id") or "").strip()
            if not sample_id:
                continue
            r1 = sample.get("r1")
            r2 = sample.get("r2")
            fasta = sample.get("fasta")
            if mate_map.get("1") and mate_map.get("2") and r1 and r2:
                r1_path = canonical_path(r1)
                r2_path = canonical_path(r2)
                for label, path in (("R1", r1_path), ("R2", r2_path)):
                    if not path.is_file():
                        missing.append(f"{sample_id} {label} = missing ({path})")
                    elif not self._allowed_input(path):
                        missing.append(f"{sample_id} {label} = outside usable RAW_DATA_PATH ({path})")
                if missing:
                    continue
                jobs.append(
                    {
                        "sample_id": sample_id,
                        "runtime_inputs": {**static, mate_map["1"]: str(r1_path), mate_map["2"]: str(r2_path)},
                        "source_files": [str(r1_path), str(r2_path)],
                    }
                )
            elif mate_map.get("single") and (r1 or fasta) and not r2:
                path = canonical_path(r1 or fasta)
                expected_family = _sequence_family(canonical_path(self.bindings[mate_map["single"]]["source_path"]))
                if _sequence_family(path) != expected_family:
                    missing.append(f"{sample_id} = sequence format does not match the validated plan")
                    continue
                if not path.is_file():
                    missing.append(f"{sample_id} = missing ({path})")
                    continue
                if not self._allowed_input(path):
                    missing.append(f"{sample_id} = outside usable RAW_DATA_PATH ({path})")
                    continue
                jobs.append(
                    {
                        "sample_id": sample_id,
                        "runtime_inputs": {**static, mate_map["single"]: str(path)},
                        "source_files": [str(path)],
                    }
                )
            else:
                missing.append(f"{sample_id} = layout does not match the validated runtime contract")
        if missing:
            raise PreflightError(
                "full input files referenced by input_manifest.yaml are missing: " + "; ".join(missing)
            )
        return jobs

    def full_dataset_bindings(self) -> list[dict[str, Any]]:
        """Expand the frozen sample list into deterministic production jobs.

        Prefers the persisted full sample manifest (input_manifest.yaml); only
        when no manifest was recorded does it fall back to a RAW_DATA_PATH scan.
        """
        bindings = self.bindings
        if self.contract.get("binding_mode") in {"COHORT_MANIFEST", "DERIVED_COHORT", "EXTERNAL_COHORT"}:
            inputs, _ = self.resolve(None)
            return [{"sample_id": "cohort", "sample_ids": [s["sample_id"] for s in self.samples],
                     "runtime_inputs": inputs, "source_files": list(inputs.values())}]
        source_paths = {
            key: canonical_path(binding["source_path"], must_exist=True)
            for key, binding in bindings.items()
        }
        sequence_keys = [key for key, path in source_paths.items() if _sequence_family(path)]
        static = {key: str(path) for key, path in source_paths.items() if key not in sequence_keys}
        if self.samples:
            return self._manifest_bindings(sequence_keys, static)
        targets = self._verified_targets()
        if len(sequence_keys) == 1:
            key = sequence_keys[0]
            family = _sequence_family(source_paths[key])
            selected = [path for path in targets if _sequence_family(path) == family]
            return [
                {
                    "sample_id": _sample_and_mate(path)[0],
                    "runtime_inputs": {**static, key: str(path)},
                    "source_files": [str(path)],
                }
                for path in selected
            ]

        paired_roles: dict[str, str] = {}
        for key in sequence_keys:
            lowered = key.casefold()
            if lowered in {"reads_1", "read_1", "r1", "forward"}:
                paired_roles["1"] = key
            elif lowered in {"reads_2", "read_2", "r2", "reverse"}:
                paired_roles["2"] = key
        if set(paired_roles) == {"1", "2"} and len(sequence_keys) == 2:
            groups: dict[str, dict[str, Path]] = {}
            for path in targets:
                if _sequence_family(path) != "FASTQ":
                    continue
                sample, mate = _sample_and_mate(path)
                if mate:
                    if mate in groups.setdefault(sample, {}):
                        raise PreflightError(f"multiple R{mate} files map to production sample {sample!r}")
                    groups[sample][mate] = path
            incomplete = sorted(sample for sample, values in groups.items() if set(values) != {"1", "2"})
            if incomplete:
                raise PreflightError(f"incomplete paired-end samples in RAW_DATA_PATH: {', '.join(incomplete)}")
            return [
                {
                    "sample_id": sample,
                    "runtime_inputs": {
                        **static,
                        paired_roles["1"]: str(values["1"]),
                        paired_roles["2"]: str(values["2"]),
                    },
                    "source_files": [str(values["1"]), str(values["2"])],
                }
                for sample, values in sorted(groups.items())
            ]

        if set(targets) == {source_paths[key] for key in sequence_keys}:
            return [
                {
                    "sample_id": "full-data",
                    "runtime_inputs": {key: str(path) for key, path in source_paths.items()},
                    "source_files": [str(path) for path in source_paths.values()],
                }
            ]
        raise PreflightError(
            "the frozen plan has multiple sequence input keys whose full RAW_DATA_PATH pairing is ambiguous"
        )

    def resolve(self, runtime_inputs: dict[str, str] | None) -> tuple[dict[str, str], dict[str, Any]]:
        bindings = self.bindings
        supplied = dict(runtime_inputs or {})
        if self.contract.get("binding_mode") == "DERIVED_COHORT":
            from microbiome.pipeline.derived import verify_derived_contract
            try:
                expected = verify_derived_contract(self.project, self.contract)
            except (ConfigurationError, OSError, ValueError, KeyError) as error:
                raise PreflightError(str(error)) from error
            if runtime_inputs is not None and supplied != expected:
                raise PreflightError("derived runtime inputs must exactly match frozen sample artifact roles")
            return expected, {"status": "PASSED", "binding_mode": "DERIVED_COHORT",
                              "raw_data_root": str(self.raw_root),
                              "input_root": str(Path(self.contract["derived_manifest"]["parent"]["run_manifest"]).parent / "outputs"),
                              "parent_run_id": self.contract["derived_manifest"]["parent"]["run_id"],
                              "events": [{"key": k, "resolved": v, "reason": "completed parent artifact verified"}
                                         for k, v in expected.items()]}
        if self.contract.get("binding_mode") == "EXTERNAL_COHORT":
            from microbiome.pipeline.external_cohort import verify_external_contract
            try:
                expected = verify_external_contract(self.project, self.contract)
            except (ConfigurationError, OSError, ValueError, KeyError) as error:
                raise PreflightError(str(error)) from error
            if runtime_inputs is not None and supplied != expected:
                raise PreflightError("external runtime inputs must exactly match the frozen declared cohort artifacts")
            return expected, {"status": "PASSED", "binding_mode": "EXTERNAL_COHORT",
                              "raw_data_root": str(self.raw_root),
                              "input_roots": self.contract["external_manifest"]["local_roots"],
                              "events": [{"key": k, "resolved": v, "reason": "external cohort file and SHA256 verified"}
                                         for k, v in expected.items()]}
        missing = sorted(set(bindings) - set(supplied)) if supplied else []
        extra = sorted(set(supplied) - set(bindings))
        if missing:
            raise PreflightError(f"runtime inputs are missing locked keys: {', '.join(missing)}")
        if extra:
            raise PreflightError(f"runtime inputs contain undeclared keys: {', '.join(extra)}")

        resolved: dict[str, str] = {}
        events: list[dict[str, Any]] = []
        for key, binding in sorted(bindings.items()):
            if not isinstance(binding, dict) or not binding.get("source_path"):
                raise PreflightError(f"production input binding {key!r} is invalid")
            source = canonical_path(binding["source_path"], must_exist=True)
            if not self._allowed_input(source):
                raise PreflightError(f"locked production input escaped RAW_DATA_PATH: {source}")
            pilot = canonical_path(binding["pilot_subset_path"]) if binding.get("pilot_subset_path") else None
            if not supplied:
                chosen = source
                reason = "locked original input restored from validation source"
            else:
                candidate = canonical_path(supplied[key], must_exist=True)
                is_pretest = _inside(candidate, self.project.pretest_dir)
                is_recorded_pilot = pilot is not None and candidate == pilot
                if is_pretest or is_recorded_pilot:
                    chosen = source
                    reason = "pre-test subset was replaced by its locked original RAW_DATA_PATH source"
                elif self._allowed_input(candidate):
                    chosen = candidate
                    reason = "caller input verified under RAW_DATA_PATH"
                else:
                    raise PreflightError(
                        f"production input {key!r} is outside RAW_DATA_PATH and is not a recorded pilot subset: "
                        f"{candidate}"
                    )
            if _inside(chosen, self.project.pretest_dir) or self._is_excluded(chosen):
                raise PreflightError(
                    f"production input {key!r} still points into an excluded output/pre-test tree: {chosen}"
                )
            resolved[key] = str(chosen)
            events.append(
                {
                    "key": key,
                    "supplied": supplied.get(key),
                    "resolved": str(chosen),
                    "raw_data_root": str(self.raw_root),
                    "reason": reason,
                }
            )
        if self.contract.get("binding_mode") == "COHORT_MANIFEST":
            if any(value != bindings[key]["source_path"] for key, value in resolved.items()):
                raise PreflightError("cohort input roles or members changed after validation")
        elif self.samples:
            sequence_keys = [key for key, binding in bindings.items() if _sequence_family(canonical_path(binding["source_path"]))]
            roles = _runtime_mate_map(sequence_keys)
            if "1" in roles and "2" in roles:
                valid = any((sample.get("r1"), sample.get("r2")) == (resolved[roles["1"]], resolved[roles["2"]])
                            for sample in self.samples)
            elif "single" in roles:
                key = roles["single"]
                valid = (_sequence_family(canonical_path(resolved[key])) == _sequence_family(canonical_path(bindings[key]["source_path"]))
                         and any(not sample.get("r2") and (sample.get("r1") or sample.get("fasta")) == resolved[key]
                                 for sample in self.samples))
            else:
                valid = False
            valid = valid and all(value == bindings[key]["source_path"] for key, value in resolved.items() if key not in sequence_keys)
            if not valid:
                raise PreflightError("runtime inputs mix files or mate roles from different declared samples")
        return resolved, {
            "status": "PASSED",
            "binding_mode": self.contract["binding_mode"],
            "raw_data_root": str(self.raw_root),
            "events": events,
        }
