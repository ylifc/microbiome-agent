"""Explicit, checkpoint-bound reuse of completed-run artifacts.

This is a new input contract, not an exception to raw input exclusion rules.
Only sample-owned outputs of a completed cohort run can be bound. Full derived
samples are replayed during validation; neither contigs nor genomes are sampled.
"""
from __future__ import annotations

import copy
import hashlib
import re
from pathlib import Path

from microbiome.pipeline.errors import ConfigurationError, FreezeError
from microbiome.pipeline.io import (object_fingerprint, path_fingerprint, read_json,
                                    read_yaml, write_json)

KIND = "completed_run_artifacts"
MODE = "complete_derived_samples"
IDENTIFIER = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$")
ROLE = re.compile(r"^[A-Za-z][A-Za-z0-9_]{0,63}$")


def _inside(path, root):
    path, root = Path(path).resolve(strict=True), Path(root).resolve(strict=True)
    if not path.is_relative_to(root):
        raise ConfigurationError(f"derived artifact escaped completed parent run: {path}")
    return path


def _digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(4 * 1024**2), b""):
            h.update(block)
    return h.hexdigest()


def _regular_tree(path):
    if path.is_symlink():
        raise ConfigurationError("derived artifact symlinks are not supported")
    if path.is_file():
        return [path]
    if not path.is_dir():
        raise ConfigurationError("derived artifact must be a regular file or directory")
    files = []
    for item in sorted(path.rglob("*")):
        if item.is_symlink() or not (item.is_file() or item.is_dir()):
            raise ConfigurationError("derived artifact tree contains a symlink or special file")
        if item.is_file():
            files.append(item)
    if not files:
        raise ConfigurationError("derived artifact directory is empty")
    return files


def artifact_fingerprint(path, *, checkpoint_file=False):
    """Whole SHA256 for files/trees; checkpoint-proven FASTQ uses drift fingerprint.

    Head/tail hashes are explicitly labelled non-adversarial drift detection.
    They are allowed only for exact FASTQ outputs already checked by the parent
    engine, never arbitrary files or descendants of directory outputs.
    """
    path = Path(path)
    before = path_fingerprint(path)
    files = _regular_tree(path)
    fastq = str(path).lower().endswith((".fastq", ".fq", ".fastq.gz", ".fq.gz"))
    if checkpoint_file and path.is_file() and fastq:
        result = {"method": "parent_checkpoint_head_tail_drift", "value": before}
    elif path.is_file():
        result = {"method": "sha256", "path": str(path), "bytes": path.stat().st_size,
                  "sha256": _digest(path)}
    else:
        result = {"method": "sha256_tree", "path": str(path), "files": [
            {"relative_path": str(f.relative_to(path)), "bytes": f.stat().st_size,
             "sha256": _digest(f)} for f in files]}
    if before != path_fingerprint(path):
        raise ConfigurationError("derived artifact changed while fingerprinting")
    return result


def _parent(project, run_id):
    if not isinstance(run_id, str) or not IDENTIFIER.fullmatch(run_id):
        raise ConfigurationError("invalid completed parent run_id")
    root = _inside(project.runs_dir / run_id, project.runs_dir)
    manifest_path = _inside(root / "run_manifest.yaml", root)
    run = read_yaml(manifest_path)
    steps = run.get("steps") or {}
    if (run.get("run_id") != run_id or run.get("status") != "COMPLETED" or not steps
            or any(v.get("status") != "COMPLETED" for v in steps.values())):
        raise ConfigurationError("derived inputs require an entirely completed parent run")
    output = _inside(run.get("outputs_path", ""), root)
    return root, output, run, manifest_path


def _artifact(root, output, run, member, selector):
    if (not isinstance(selector, dict) or set(selector) - {"step_id", "output", "relative_path"}
            or not isinstance(selector.get("step_id"), str) or not isinstance(selector.get("output"), str)):
        raise ConfigurationError("artifact selector requires step_id/output and optional relative_path")
    step_id = selector["step_id"]
    if member.get("scope") == "cohort":
        if any(step_id.startswith(prefix + "__") for prefix in member["sample_prefixes"]):
            raise ConfigurationError("cohort artifact cannot claim a sample-owned producer")
    elif not step_id.startswith(member["prefix"] + "__"):
        raise ConfigurationError("derived artifact producer belongs to a different sample")
    step = run["steps"].get(step_id)
    if not step:
        raise ConfigurationError("derived artifact producer is not in parent run")
    checkpoint = _inside(step.get("checkpoint", ""), root / "checkpoints")
    receipt = read_json(checkpoint)
    if (receipt.get("completion_status") != "COMPLETED" or receipt.get("step_id") != step_id
            or receipt.get("pipeline_hash") != run["pipeline_hash"]):
        raise ConfigurationError("derived producer checkpoint is not a completed parent step")
    fact = (receipt.get("output_fingerprint") or {}).get(selector["output"])
    if not isinstance(fact, dict) or not fact.get("path"):
        raise ConfigurationError("derived selector output has no checkpoint fingerprint")
    declared = Path(fact["path"])
    _regular_tree(declared)  # reject symlinks before canonicalizing
    declared = _inside(declared, output)
    if path_fingerprint(declared) != fact:
        raise ConfigurationError("parent output changed since its completed checkpoint")
    relative = selector.get("relative_path")
    if relative is not None:
        if (not isinstance(relative, str) or not relative or Path(relative).is_absolute()
                or ".." in Path(relative).parts or not declared.is_dir()):
            raise ConfigurationError("relative_path must select a child of a directory output")
        selected = _inside(declared / relative, declared)
    else:
        selected = declared
    return {"path": str(selected), "selector": copy.deepcopy(selector),
            "checkpoint": str(checkpoint), "checkpoint_sha256": _digest(checkpoint),
            "fingerprint": artifact_fingerprint(selected, checkpoint_file=selected == declared)}


def _matching_parent_lock(project, run):
    version = run.get("pipeline_version")
    if not isinstance(version, str) or not IDENTIFIER.fullmatch(version):
        raise ConfigurationError("invalid completed parent pipeline version")
    candidates = [project.pipeline_lock_path, project.state_dir / "history" /
                  version / "pipeline.lock.yaml"]
    from microbiome.pipeline.lock_schema import validate_pipeline_lock
    for path in candidates:
        if not path.is_file():
            continue
        lock = read_yaml(path)
        if lock.get("pipeline_hash") != run["pipeline_hash"]:
            continue
        validate_pipeline_lock(lock)
        if lock.get("pipeline_version") != version:
            raise ConfigurationError("completed parent pipeline version changed")
        if set(run["steps"]) != {step["step_id"] for step in lock["steps"]}:
            raise ConfigurationError("completed parent steps differ from its frozen pipeline")
        return lock
    raise ConfigurationError("completed parent pipeline lock is unavailable")


def resolve_derived_manifest(project, parent_run_id, samples, cohort_artifacts=None):
    root, output, run, parent_path = _parent(project, parent_run_id)
    parent_lock = _matching_parent_lock(project, run)
    members = parent_lock.get("cohort_members") or []
    if not members:
        raise ConfigurationError("derived artifact input currently requires a completed cohort parent")
    expected = [m["sample_id"] for m in members]
    if (not isinstance(samples, list) or len(samples) != len(expected)
            or any(not isinstance(s, dict) or set(s) != {"sample_id", "artifacts"} for s in samples)
            or {s["sample_id"] for s in samples} != set(expected)):
        raise ConfigurationError("derived samples must match every parent biological sample exactly once")
    shared = {} if cohort_artifacts is None else cohort_artifacts
    if not isinstance(shared, dict) or any(not isinstance(k, str) or not ROLE.fullmatch(k) for k in shared):
        raise ConfigurationError("cohort artifact roles must be valid identifiers")
    cohort = {"scope": "cohort", "sample_prefixes": [m["prefix"] for m in members]}
    shared = {role: _artifact(root, output, run, cohort, spec) for role, spec in sorted(shared.items())}
    by_id = {s["sample_id"]: s for s in samples}
    rows, roles = [], None
    for member in members:
        artifacts = by_id[member["sample_id"]]["artifacts"]
        if (not isinstance(artifacts, dict) or (not artifacts and not shared)
                or any(not isinstance(k, str) or not ROLE.fullmatch(k) for k in artifacts)):
            raise ConfigurationError("derived artifact roles must be nonempty valid runtime identifiers")
        if roles is not None and set(artifacts) != roles:
            raise ConfigurationError("all derived samples must expose the same artifact roles")
        roles = set(artifacts)
        rows.append({"sample_id": member["sample_id"], "source_type": KIND,
                     "artifacts": {role: _artifact(root, output, run, member, spec)
                                   for role, spec in sorted(artifacts.items())}})
    requirements = read_yaml(project.requirements_path)
    metadata = requirements.get("dataset", {}).get("sample_metadata", [])
    if metadata and (len(metadata) != len(expected) or {r["sample_id"] for r in metadata} != set(expected)):
        raise ConfigurationError("current metadata differs from completed parent biological samples")
    manifest = {"schema_version": 1, "resolution_status": "CONFIRMED", "overall_source": KIND,
                "input_kind": KIND, "layout": "DERIVED_ARTIFACTS", "pilot_mode": MODE,
                "parent": {"run_id": parent_run_id, "run_manifest": str(parent_path),
                           "run_manifest_sha256": _digest(parent_path),
                           "pipeline_hash": run["pipeline_hash"], "pipeline_version": run["pipeline_version"],
                           "cohort_members": copy.deepcopy(members)},
                "sample_metadata": copy.deepcopy(metadata), "samples": rows, "cohort_artifacts": shared}
    manifest["manifest_fingerprint"] = object_fingerprint(manifest)
    return manifest


def verify_derived_manifest(project, manifest):
    if manifest.get("input_kind") != KIND or manifest.get("pilot_mode") != MODE:
        raise ConfigurationError("invalid derived input mode")
    if manifest.get("manifest_fingerprint") != object_fingerprint(
            {k: v for k, v in manifest.items() if k != "manifest_fingerprint"}):
        raise ConfigurationError("derived manifest fingerprint is invalid")
    parent = manifest["parent"]
    root, output, run, path = _parent(project, parent["run_id"])
    if (str(path) != parent["run_manifest"] or _digest(path) != parent["run_manifest_sha256"]
            or run["pipeline_hash"] != parent["pipeline_hash"]):
        raise ConfigurationError("completed parent run changed after derived input review")
    lock = _matching_parent_lock(project, run)
    if parent["cohort_members"] != lock.get("cohort_members"):
        raise ConfigurationError("derived parent sample ownership differs from frozen pipeline")
    members = {m["sample_id"]: m for m in parent["cohort_members"]}
    if (len(manifest["samples"]) != len(members)
            or {s["sample_id"] for s in manifest["samples"]} != set(members)):
        raise ConfigurationError("derived biological sample membership changed")
    shared_member = {"scope": "cohort", "sample_prefixes": [m["prefix"] for m in members.values()]}
    for artifact in manifest.get("cohort_artifacts", {}).values():
        if _artifact(root, output, run, shared_member, artifact["selector"]) != artifact:
            raise ConfigurationError("derived cohort artifact changed after input review")
    for sample in manifest["samples"]:
        for artifact in sample["artifacts"].values():
            actual = _artifact(root, output, run, members[sample["sample_id"]], artifact["selector"])
            if actual != artifact:
                raise ConfigurationError("derived artifact changed after input review")
    return manifest


def validate_derived_plan(plan, manifest):
    derived = manifest.get("input_kind") == KIND
    if not derived:
        if plan.get("pilot_mode") == MODE:
            raise ConfigurationError("complete derived pilot requires a confirmed derived manifest")
        return
    if (plan.get("pilot_mode") != MODE or plan.get("execution_scope") != "cohort"
            or plan.get("validation_strategy") != "manifest_cases"):
        raise ConfigurationError("derived plan requires explicit complete_derived_samples cohort manifest_cases validation")


def derived_contract(project, validation, manifest, plan):
    from microbiome.pipeline.cohort import cohort_runtime_inputs
    verify_derived_manifest(project, manifest)
    validate_derived_plan(plan, manifest)
    inputs = cohort_runtime_inputs(plan, manifest)
    actual = {k: v["path"] for k, v in validation["runtime_input_source"].items()}
    if actual != inputs or validation.get("pilot_mode") != MODE or validation.get("pretest_fraction") is not None:
        raise FreezeError("derived validation must use every complete original artifact without subsampling")
    subset = validation.get("representative_subset", {})
    if subset.get("mode") != MODE or subset.get("sampling_performed") is not False:
        raise FreezeError("derived validation lacks explicit complete-input evidence")
    payload = {"binding_mode": "DERIVED_COHORT", "project_paths": project.load_config()["paths"],
               "raw_data_root": project.load_config()["paths"]["raw_data"],
               "derived_manifest": copy.deepcopy(manifest), "samples": manifest["samples"],
               "cohort_members": plan["cohort_members"],
               "bindings": {k: {"source_path": v, "pilot_subset_path": None} for k, v in inputs.items()}}
    payload["contract_fingerprint"] = object_fingerprint(payload)
    return payload


def verify_derived_contract(project, contract):
    from microbiome.pipeline.cohort import cohort_runtime_inputs
    manifest = verify_derived_manifest(project, contract["derived_manifest"])
    expected = cohort_runtime_inputs({"cohort_members": contract["cohort_members"]}, manifest)
    if expected != {k: v["source_path"] for k, v in contract["bindings"].items()}:
        raise ConfigurationError("derived frozen artifact roles or samples changed")
    current = read_yaml(project.requirements_dir / "input_manifest.yaml")
    if current != manifest:
        raise ConfigurationError("derived inputs differ from the frozen confirmed manifest")
    return expected


def snapshot_revision(project):
    """Preserve all current evidence before any new input replaces old contracts."""
    if not project.pipeline_lock_path.is_file():
        return
    lock = read_yaml(project.pipeline_lock_path)
    paths = [project.pipeline_lock_path, project.toolchain_lock_path, project.database_lock_path,
             project.validation_report_path, project.pipeline_dir / "production_approval.yaml",
             project.pipeline_dir / "validation_suite.json", project.requirements_path,
             project.requirements_dir / "input_manifest.yaml", project.plan_path]
    if not IDENTIFIER.fullmatch(lock["pipeline_version"]):
        raise ConfigurationError("invalid revision pipeline version")
    files = {str(p): {"sha256": _digest(p), "content": p.read_bytes().decode("utf-8")}
             for p in paths if p.is_file()}
    evidence = {"pipeline_version": lock["pipeline_version"], "files": files}
    destination = project.state_dir / "revision_snapshots" / (lock["pipeline_version"] + ".json")
    if destination.exists():
        # Existing snapshot is deliberately never refreshed from mutable current files.
        original = read_json(destination)
        if original.get("pipeline_version") != lock["pipeline_version"]:
            raise ConfigurationError("existing revision snapshot has inconsistent identity")
        for record in original.get("files", {}).values():
            if hashlib.sha256(record["content"].encode()).hexdigest() != record["sha256"]:
                raise ConfigurationError("existing immutable revision snapshot changed")
    else:
        write_json(destination, evidence)
