"""Natural-language production approval bound to one frozen pipeline."""

from __future__ import annotations

import json
import math
import os
import re
import uuid
from datetime import UTC, datetime
from enum import StrEnum
from typing import TYPE_CHECKING, Any

from microbiome.pipeline.errors import ConfigurationError, PreflightError
from microbiome.pipeline.io import manifest_fingerprint, object_fingerprint, read_json, read_yaml, write_yaml
from microbiome.pipeline.requirements import RequirementManager
from microbiome.pipeline.state import LifecycleState, ProjectStateMachine

if TYPE_CHECKING:
    from microbiome.pipeline.project import PipelineProject


def _utcnow() -> str:
    return datetime.now(UTC).isoformat()


def _production_scope_text(pipeline: dict[str, Any], validation: dict[str, Any]) -> tuple[str, str, str, str]:
    """Describe the validated input mode without inventing a sampling fraction."""
    from microbiome.pipeline.derived import MODE

    from microbiome.pipeline.external_cohort import MODE as EXTERNAL_MODE
    external = pipeline.get("production_input_contract", {}).get("binding_mode") == "EXTERNAL_COHORT"
    if external or validation.get("pilot_mode") == EXTERNAL_MODE:
        subset = validation.get("representative_subset", {})
        if (not external or validation.get("pilot_mode") != EXTERNAL_MODE
                or validation.get("pretest_fraction", "absent") is not None or not isinstance(subset, dict)
                or subset.get("mode") != EXTERNAL_MODE or subset.get("sampling_performed") is not False):
            raise ConfigurationError("complete external production review requires matching complete-input evidence without subsampling")
        return (
            "[microbiome-run] 完整外部队列表格试运行验证完成 / Complete external-cohort pilot validation complete",
            "全部已确认记录组列及完整外部文件已完成端到端验证，未进行序列或矩阵抽样；记录组的具体含义以输入来源声明为准。 / All confirmed record-group columns and complete external files passed end-to-end validation without subsampling; their meaning follows the declared input provenance.",
            "正式阶段将重新核对冻结外部文件的格式与 SHA256，并使用相同完整记录组列写入新运行目录；这些是外部来源，不宣称由父运行生成。 / Production rechecks frozen external files and SHA256, uses all record-group columns, and writes into a new run directory; no parent-run provenance is claimed.",
            "是否开始对全部已确认记录组的完整外部队列数据进行正式分析？ / Start production on the complete confirmed external cohort?",
        )
    derived = pipeline.get("production_input_contract", {}).get("binding_mode") == "DERIVED_COHORT"
    mode = validation.get("pilot_mode", "sequence_fraction")
    if derived or mode == MODE:
        subset = validation.get("representative_subset", {})
        if (not derived or mode != MODE or "pretest_fraction" not in validation
                or validation["pretest_fraction"] is not None or not isinstance(subset, dict)
                or subset.get("mode") != MODE or subset.get("sampling_performed") is not False):
            raise ConfigurationError("complete derived production review requires matching complete-input evidence without subsampling")
        return (
            "[microbiome-run] 完整派生产物试运行验证完成 / Complete derived-artifact pilot validation complete",
            "已对全部已确认样本的完整派生产物完成端到端验证，未进行抽样。 / All confirmed samples' complete derived artifacts passed end-to-end validation without subsampling.",
            "正式阶段将使用冻结输入契约中的全部已确认样本及其完整派生产物，并写入新的运行目录。 / Production uses all confirmed samples and their complete derived artifacts from the frozen input contract, and writes into a new run directory.",
            "是否开始对全部已确认样本的完整派生产物进行正式分析？ / Start production on all confirmed samples' complete derived artifacts?",
        )
    if mode != "sequence_fraction":
        raise ConfigurationError(f"unsupported pilot mode for production review: {mode!r}")
    fraction = validation.get("pretest_fraction", 0.10)
    if (type(fraction) not in (int, float) or not math.isfinite(fraction) or not 0 < fraction <= 1):
        raise ConfigurationError("sequence-fraction production review requires a finite numeric fraction in (0, 1]")
    return (
        "[microbiome-run] 小数据验证完成 / Pilot validation complete",
        f"已完成代表样本的端到端验证，配置采样比例 {fraction:.0%}（实际条数与限额见 subset manifest）。 / Representative samples passed end-to-end validation; actual record counts are in the subset manifest.",
        "全量阶段只会把运行时输入重新绑定到 RAW_DATA_PATH 下的完整原始数据，并写入新的运行目录。 / The full run only rebinds runtime inputs to the complete raw data and writes into a new run directory.",
        "是否开始使用全部原始数据进行正式分析？ / Start the full analysis on all raw data?",
    )


class ProductionIntent(StrEnum):
    APPROVE_PRODUCTION = "APPROVE_PRODUCTION"
    REJECT_PRODUCTION = "REJECT_PRODUCTION"
    MODIFY_PLAN = "MODIFY_PLAN"
    QUESTION = "QUESTION"
    AMBIGUOUS = "AMBIGUOUS"


class ProductionApprovalManager:
    """Classify, persist, and validate approval; never design or run a pipeline."""

    def __init__(self, project: PipelineProject):
        self.project = project
        self.path = project.pipeline_dir / "production_approval.yaml"

    @staticmethod
    def classify_intent(message: str) -> ProductionIntent:
        if not isinstance(message, str) or not message.strip():
            return ProductionIntent.AMBIGUOUS
        lowered = message.strip().casefold()
        compact = re.sub(r"[\s，。！？、；：,.!?;:'\"`()]+", "", lowered)
        english = re.sub(r"[^a-z]+", " ", lowered).strip()

        modify_markers = (
            "修改",
            "调整",
            "增加一个",
            "新增步骤",
            "换软件",
            "换数据库",
            "change the plan",
            "modify the plan",
            "add a step",
        )
        if any(marker in lowered for marker in modify_markers):
            return ProductionIntent.MODIFY_PLAN

        reject_phrases = {
            "先不要开始",
            "暂时不要全量执行",
            "不要运行",
            "先等等",
            "不确认",
            "还不能开始",
            "不运行",
            "取消",
            "暂不执行",
            "暂时不执行",
            "以后再说",
        }
        reject_markers = ("不要全量", "不要开始", "先别", "暂缓", "暂停", "取消全量")
        if compact in {re.sub(r"\s+", "", item) for item in reject_phrases} or any(
            marker in lowered for marker in reject_markers
        ):
            return ProductionIntent.REJECT_PRODUCTION
        if english in {
            "do not start",
            "don t start",
            "not yet",
            "cancel",
            "pause",
            "do not run production",
        }:
            return ProductionIntent.REJECT_PRODUCTION

        question_markers = (
            "为什么",
            "是不是",
            "是什么",
            "干嘛",
            "多久",
            "多大",
            "哪个",
            "哪些",
            "最新吗",
            "解释",
            "why",
            "what",
            "which",
            "how long",
            "how much",
            "explain",
        )
        if "?" in lowered or "？" in lowered or any(marker in lowered for marker in question_markers):
            return ProductionIntent.QUESTION

        approvals = {
            "确认全量执行",
            "确认执行",
            "开始全量执行",
            "可以开始全量执行",
            "可以开始全量运行",
            "开始跑全部数据",
            "继续",
            "继续运行",
            "可以开始了",
            "可以开始分析全部数据",
            "确认",
            "开始正式分析",
            "按照刚才验证好的流程跑全部数据",
            "没有问题运行全部样本",
            "按这个方案执行全部数据",
            "继续全量分析",
            "可以开始正式运行",
            "确认全量运行",
        }
        if compact in approvals:
            return ProductionIntent.APPROVE_PRODUCTION
        if english in {
            "confirm",
            "start production",
            "run all data",
            "proceed",
            "yes run the full dataset",
            "confirm production",
            "start the full analysis",
        }:
            return ProductionIntent.APPROVE_PRODUCTION
        return ProductionIntent.AMBIGUOUS

    def _load_pipeline(self) -> dict[str, Any]:
        if not self.project.pipeline_lock_path.is_file():
            raise ConfigurationError("validated frozen pipeline is not available for production approval")
        pipeline = read_yaml(self.project.pipeline_lock_path)
        if pipeline.get("manifest_fingerprint") != manifest_fingerprint(pipeline):
            raise ConfigurationError("pipeline lock fingerprint is invalid")
        hash_payload = {
            key: value
            for key, value in pipeline.items()
            if key not in {"pipeline_hash", "pipeline_version", "manifest_fingerprint"}
        }
        if pipeline.get("pipeline_hash") != object_fingerprint(hash_payload):
            raise ConfigurationError("pipeline content hash is invalid")
        expected_version = f"r{pipeline.get('requirements_version')}-{pipeline['pipeline_hash'][:16]}"
        if pipeline.get("pipeline_version") != expected_version:
            raise ConfigurationError("pipeline version does not match its content hash")
        return pipeline

    def _append_decision(self, payload: dict[str, Any]) -> None:
        record = {
            "timestamp": _utcnow(),
            "decision_id": str(uuid.uuid4()),
            "decision_type": "production_approval",
            **payload,
        }
        self.project.decision_log_path.parent.mkdir(parents=True, exist_ok=True)
        descriptor = os.open(self.project.decision_log_path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o644)
        try:
            os.write(descriptor, (json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n").encode())
            os.fsync(descriptor)
        finally:
            os.close(descriptor)

    def _write_approval(self, payload: dict[str, Any]) -> dict[str, Any]:
        value = {"schema_version": 1, **payload}
        value["approval_fingerprint"] = object_fingerprint(value)
        write_yaml(self.path, value)
        return value

    def render_validation_summary(self) -> str:
        pipeline = self._load_pipeline()
        # The summary is the approval question; it may only be shown once
        # production readiness for this exact lock is on record.
        from microbiome.pipeline.readiness import load_current_readiness

        load_current_readiness(self.project, pipeline)
        toolchain = read_yaml(self.project.toolchain_lock_path)
        databases = read_yaml(self.project.database_lock_path)
        validation = read_json(self.project.validation_report_path)
        if validation.get("status") != "PASSED":
            raise ConfigurationError("the current validation report did not pass")
        heading, pilot_summary, production_scope, production_question = _production_scope_text(pipeline, validation)
        tools = toolchain.get("tools", {})
        database_items = databases.get("databases", {})
        lines = [
            heading,
            "",
            pilot_summary,
            "验证结果：✓ 通过 / Result: PASSED",
            f"验证结果目录 / Validation dir：{validation.get('validation_root')}",
            "",
            "软件环境 / Software environments",
        ]
        for step in validation.get("steps", []):
            tool = tools.get(step.get("step_id"), {})
            lines.extend(
                [
                    f"✓ {tool.get('tool') or step.get('step_id')}",
                    f"  版本：{tool.get('version_output') or step.get('exact_software_version')} / Version: {tool.get('version_output') or step.get('exact_software_version')}",
                    f"  环境：{tool.get('environment_prefix') or 'system/PATH'} / Environment: {tool.get('environment_prefix') or 'system/PATH'}",
                    "  状态：验证通过 / Status: passed validation",
                ]
            )
        if not tools:
            lines.append("✓ 未声明外部软件；验证步骤已通过 / No external software declared; steps passed")
        lines.extend(["", "数据库 / Databases"])
        for resource_id, database in sorted(database_items.items()):
            lines.extend(
                [
                    f"✓ {resource_id}",
                    f"  路径 / path：{database.get('runtime_entry') or database.get('path')}",
                    f"  状态 / status：{database.get('status')} / fingerprint verified",
                ]
            )
        if not database_items:
            lines.append("✓ 本流程不需要外部数据库 / This workflow needs no external database")
        lines.extend(["", "已经验证成功的分析流程 / Validated analysis workflow"])
        for index, step in enumerate(pipeline.get("steps", []), start=1):
            lines.append(f"{index}. {step.get('purpose')}（{step.get('tool')}）")
        lines.extend(
            [
                "",
                "以下内容已经固定：软件及版本、环境、数据库及路径、参考数据、参数、命令模板和流程顺序。 / The following are frozen: software & versions, environments, databases & paths, reference data, parameters, command templates, and step order.",
                production_scope,
                "不会重新安装软件、下载数据库、选择软件或修改分析参数。 / No software reinstall, database download, tool reselection, or parameter change.",
                "",
                production_question,
                "确认时可直接回复“确认全量执行”或“开始跑全部数据”；暂不运行或需要修改也可直接说明。 / Reply 确认全量执行 or 开始跑全部数据 to confirm; otherwise just describe what to change or pause.",
            ]
        )
        return "\n".join(lines)

    def handle(self, message: str, *, decision_source: dict[str, Any] | None = None) -> dict[str, Any]:
        intent = self.classify_intent(message)
        actor = "user" if decision_source is None else "delegated host"
        machine = ProjectStateMachine(self.project)
        if machine.current == LifecycleState.PAUSED and intent is ProductionIntent.APPROVE_PRODUCTION:
            machine.transition(
                LifecycleState.AWAITING_PRODUCTION_APPROVAL,
                reason=f"{actor} resumed the paused production approval gate",
            )
        machine.require(LifecycleState.AWAITING_PRODUCTION_APPROVAL)
        pipeline = self._load_pipeline()
        requirements = RequirementManager(self.project).require_confirmed()
        common = {
            "requirements_version": requirements["requirements_version"],
            "pipeline_version": pipeline["pipeline_version"],
            "pipeline_hash": pipeline["pipeline_hash"],
            "user_message": message if decision_source is None else decision_source.get("user_request"),
            "source": {"type": "natural_language_confirmation"} if decision_source is None else decision_source,
        }
        if decision_source is not None:
            common["delegate_action"] = intent.value
        if intent is ProductionIntent.APPROVE_PRODUCTION:
            approval = self._write_approval(
                {
                    "approved": True,
                    "approved_at": _utcnow(),
                    **common,
                }
            )
            self._append_decision({"decision": "approved", **common})
            machine.transition(LifecycleState.PRODUCTION_APPROVED, reason=f"{actor} approved frozen production")
            return {"intent": intent.value, "approval": approval, "state": machine.current.value}
        if intent is ProductionIntent.REJECT_PRODUCTION:
            self._write_approval({"approved": False, "rejected_at": _utcnow(), **common})
            self._append_decision({"decision": "paused", **common})
            machine.transition(LifecycleState.PAUSED, reason=f"{actor} paused production")
            return {"intent": intent.value, "state": machine.current.value}
        if intent is ProductionIntent.MODIFY_PLAN:
            self._write_approval({"approved": False, "invalidated_at": _utcnow(), **common})
            self._append_decision({"decision": "modify_plan", **common})
            machine.transition(LifecycleState.PLAN_MODIFICATION, reason=f"{actor} requested a plan change")
            return {"intent": intent.value, "state": machine.current.value}
        return {"intent": intent.value, "state": machine.current.value}

    def require_valid_approval(self) -> dict[str, Any]:
        if not self.path.is_file():
            raise PreflightError("production has not been approved by the user")
        approval = read_yaml(self.path)
        expected = object_fingerprint(
            {key: value for key, value in approval.items() if key != "approval_fingerprint"}
        )
        if approval.get("approval_fingerprint") != expected or approval.get("approved") is not True:
            raise PreflightError("production approval is invalid or was not granted")
        pipeline = self._load_pipeline()
        requirements = RequirementManager(self.project).require_confirmed()
        if approval.get("requirements_version") != requirements["requirements_version"]:
            raise PreflightError("production approval was invalidated by a requirements change")
        if approval.get("pipeline_hash") != pipeline.get("pipeline_hash"):
            raise PreflightError("production approval was invalidated by a pipeline change")
        if approval.get("pipeline_version") != pipeline.get("pipeline_version"):
            raise PreflightError("production approval references another pipeline version")
        # Production readiness must have been established for exactly this lock;
        # confirmation loads artifacts only and never rebuilds or repairs them.
        from microbiome.pipeline.readiness import load_current_readiness

        load_current_readiness(self.project, pipeline)
        return approval


class ProductionController:
    """Turn one approved natural-language event into deterministic execution."""

    def __init__(self, project: PipelineProject):
        self.project = project
        self.approvals = ProductionApprovalManager(project)

    def handle_user_message(
        self,
        message: str,
        *,
        runtime_inputs: dict[str, str] | None = None,
        sample_id: str = "full-data",
        run_id: str | None = None,
        threads: int | None = None,
        memory_gb: int | None = None,
        gpus: int | None = None,
        resume: bool = False,
    ) -> dict[str, Any]:
        if resume:
            if self.approvals.classify_intent(message) is not ProductionIntent.APPROVE_PRODUCTION:
                raise ConfigurationError("batch resume requires an explicit execution request")
            decision = {"intent": ProductionIntent.APPROVE_PRODUCTION.value,
                        "approval": self.approvals.require_valid_approval()}
        else:
            machine = ProjectStateMachine(self.project)
            if machine.current == LifecycleState.COMPLETED and self.approvals.classify_intent(message) is ProductionIntent.APPROVE_PRODUCTION:
                machine.transition(LifecycleState.AWAITING_PRODUCTION_APPROVAL, reason="user requested another frozen full-data run")
            decision = self.approvals.handle(message)
        if decision["intent"] != ProductionIntent.APPROVE_PRODUCTION.value:
            return {"status": "NOT_STARTED", **decision}
        self.approvals.require_valid_approval()
        from microbiome.pipeline.execution import FrozenPipelineExecutor
        from microbiome.pipeline.inputs import ProductionInputResolver

        executor = FrozenPipelineExecutor(self.project)
        if runtime_inputs is not None:
            manifest = executor.execute(
                runtime_inputs,
                sample_id=sample_id,
                run_id=run_id,
                threads=threads,
                memory_gb=memory_gb,
                gpus=gpus,
                resume=resume,
            )
            return {
                "status": manifest["status"],
                "intent": decision["intent"],
                "approval": decision["approval"],
                "manifest": manifest,
            }

        from microbiome.pipeline.batch import execute_batch
        pipeline = self.approvals._load_pipeline()
        resolver = ProductionInputResolver(self.project, pipeline)
        batch_manifest = execute_batch(self.project, executor, pipeline, resolver, run_id=run_id,
            resume=resume, threads=threads, memory_gb=memory_gb, gpus=gpus)
        return {"status": batch_manifest["status"], "intent": decision["intent"],
                "approval": decision["approval"], "manifest": batch_manifest}
