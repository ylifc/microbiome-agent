"""One reentrant process lock shared by every project control-plane adapter.

The primary lock lives outside the project so that a project operation cannot
unlink its own coordination primitive.  The legacy lock is retained during
upgrades to coordinate with older, already running workers.
"""
from __future__ import annotations

import contextlib
import fcntl
import hashlib
import os
import stat
import threading
from pathlib import Path

from microbiome.pipeline.errors import ConfigurationError

_HELD = threading.local()


def project_lock_path(project) -> Path:
    root = Path(project if isinstance(project, (str, os.PathLike)) else project.root).expanduser().resolve()
    identity = hashlib.sha256(str(root).encode()).hexdigest()
    return Path.home() / ".local" / "state" / "microbiome" / "project-locks" / f"{identity}.lock"


def _open_lock(path: Path):
    if path.is_symlink():
        raise ConfigurationError(f"Unsafe symbolic lock path: {path}")
    fd = os.open(path, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    info = os.fstat(fd)
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_uid != os.getuid():
        os.close(fd)
        raise ConfigurationError(f"Unsafe project lock: {path}")
    return os.fdopen(fd, "a")


@contextlib.contextmanager
def maintenance_registry_lock(project):
    """Disjoint controller metadata lock; never wait while holding it for a run.

    Callers needing both locks must acquire project_operation_lock first.
    Draft/export operations need only this lock and can run alongside a job.
    """
    path = project_lock_path(project).with_suffix(".maintenance.lock")
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    if any(item.is_symlink() for item in (path.parent, *path.parent.parents)):
        raise ConfigurationError("Unsafe stable project lock directory")
    with _open_lock(path) as handle:
        try:
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise ConfigurationError("MAINTENANCE_BUSY: another maintenance operation is active") from exc
        yield


@contextlib.contextmanager
def project_operation_lock(project, *, blocking: bool = False, reentrant: bool = False):
    root = Path(project if isinstance(project, (str, os.PathLike)) else project.root).expanduser().resolve()
    key = str(root)
    held = getattr(_HELD, "projects", set())
    if key in held:
        if reentrant:
            yield
            return
        raise ConfigurationError("PROJECT_BUSY: another operation owns this project")
    stable = project_lock_path(project)
    stable.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    # Refuse symlinks in the stable lock directory as well as the lock file.
    if any(item.is_symlink() for item in (stable.parent, *stable.parent.parents)):
        raise ConfigurationError("Unsafe stable project lock directory")
    with contextlib.ExitStack() as stack:
        for path in (stable, root / ".microbiome-operation.lock"):
            handle = stack.enter_context(_open_lock(path))
            try:
                fcntl.flock(handle, fcntl.LOCK_EX | (0 if blocking else fcntl.LOCK_NB))
            except BlockingIOError as exc:
                raise ConfigurationError("PROJECT_BUSY: another operation owns this project") from exc
        _HELD.projects = held | {key}
        try:
            yield
        finally:
            _HELD.projects = held
