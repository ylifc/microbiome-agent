"""Bounded, paginated read capabilities rooted in persisted project bindings.

Reading a user file does not require write ownership. These helpers never start
commands, change a registry or resolve scientific inputs. Every page identifies
its source snapshot; subsequent pages fail if the source has changed.
"""
from __future__ import annotations

import base64
import contextlib
import hashlib
import json
import os
import stat
from pathlib import Path

from microbiome.pipeline.errors import ConfigurationError
from microbiome.pipeline.io import object_fingerprint

MAX_ARTIFACT_BYTES = 16 * 1024 * 1024
MAX_DIRECTORY_ENTRIES = 100000
_ROOTS = ("raw_data", "database", "output", "download", "knowledge", "project")
_PRIVATE_PARTS = {".ssh", ".aws", ".azure", ".gnupg", ".git", ".kube", "credentials", "secrets"}
_PRIVATE_SUFFIXES = {".pem", ".key", ".p12", ".pfx", ".jks", ".keystore"}
_PRIVATE_NAMES = {"credentials.json", "credentials.yaml", "credentials.yml", "credentials.toml", "id_rsa", "id_ed25519", "token", "token.json", "tokens.json", "auth.json", ".netrc", ".npmrc", ".pypirc"}


class MaintenanceReadError(ConfigurationError):
    def __init__(self, code, message, **details):
        self.details = {"code": code, "message": message, **details}
        super().__init__(code + ": " + message)


def effective_paths(project):
    config = project.load_config()
    paths = config["paths"]
    provenance = config.get("path_provenance", paths.get("provenance", {}))
    result = {}
    for role in _ROOTS:
        configured = paths.get(role) if role != "project" else str(project.root)
        if role == "knowledge" and not configured:
            value, origin = str(project.output_root / "knowledge"), "default"
        elif role == "download" and not configured:
            value, origin = paths["raw_data"], "legacy_default"
        else:
            value = configured
            recorded = provenance.get(role)
            origin = recorded.get("origin", "recorded") if isinstance(recorded, dict) else recorded or (
                "project_identity" if role == "project" else "persisted_origin_unrecorded")
        result[role] = {"path": str(value), "origin": origin,
                        "source": "project.root" if role == "project" else f"project_config.paths.{role}",
                        "exists": Path(value).exists() if value else False,
                        "read_allowed": bool(value) and not _private(Path(os.path.abspath(value))),
                        "write_permission_implied": False}
    return result


def _private(relative):
    for part in relative.parts:
        name = part.casefold()
        if (name in _PRIVATE_PARTS or name in _PRIVATE_NAMES or name == ".env" or name.startswith(".env.")
                or Path(name).suffix in _PRIVATE_SUFFIXES):
            return True
    return False


def _target(project, root, value="."):
    if root not in _ROOTS:
        raise MaintenanceReadError("READ_SCOPE_DENIED", "Unknown bound root")
    relative = Path(value)
    if relative.is_absolute() or ".." in relative.parts or "\x00" in str(relative):
        raise MaintenanceReadError("READ_SCOPE_DENIED", "Use a relative path without parent traversal")
    if _private(relative):
        raise MaintenanceReadError("CREDENTIAL_PATH_DENIED", "Credential stores are not readable through project maintenance")
    binding = effective_paths(project)[root]
    target = Path(os.path.abspath(Path(binding["path"]) / relative))
    if _private(target):
        raise MaintenanceReadError("CREDENTIAL_PATH_DENIED", "Credential stores are not readable through project maintenance")
    return target


@contextlib.contextmanager
def _open(path, *, directory=False):
    absolute = Path(os.path.abspath(path))
    parent = os.open("/", os.O_RDONLY | os.O_DIRECTORY)
    descriptor = None
    try:
        for part in absolute.parts[1:-1]:
            following = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
            os.close(parent)
            parent = following
        # Nonblocking open lets fstat reject a FIFO without waiting for a writer.
        descriptor = os.open(absolute.name or ".", os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | (os.O_DIRECTORY if directory else 0), dir_fd=parent)
        info = os.fstat(descriptor)
        if not directory and (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1):
            raise MaintenanceReadError("LINK_OR_SPECIAL_FILE_DENIED", "Only regular files with one link may be read")
        yield descriptor, info
    except FileNotFoundError as exc:
        raise MaintenanceReadError("READ_NOT_FOUND", "The requested path does not exist", path=str(path)) from exc
    except OSError as exc:
        raise MaintenanceReadError("UNSAFE_OR_INACCESSIBLE_PATH", "The path is inaccessible, linked, or not the requested type", path=str(path)) from exc
    finally:
        if descriptor is not None:
            os.close(descriptor)
        os.close(parent)


def _content(path):
    with _open(path) as (descriptor, before):
        if before.st_size > MAX_ARTIFACT_BYTES:
            raise MaintenanceReadError("ARTIFACT_TOO_LARGE", "Text preview is limited to 16 MiB; use a dedicated data-inspection service", bytes=before.st_size)
        chunks, size = [], 0
        while chunk := os.read(descriptor, 1024 * 1024):
            size += len(chunk)
            if size > MAX_ARTIFACT_BYTES:
                raise MaintenanceReadError("ARTIFACT_TOO_LARGE", "The file grew beyond the text-preview limit")
            chunks.append(chunk)
        after = os.fstat(descriptor)
        if (before.st_size, before.st_mtime_ns, before.st_ino) != (after.st_size, after.st_mtime_ns, after.st_ino):
            raise MaintenanceReadError("SNAPSHOT_CHANGED", "The file changed while being read; restart the read")
    raw = b"".join(chunks)
    if b"\x00" in raw:
        raise MaintenanceReadError("BINARY_ARTIFACT", "Binary files are not returned as text", bytes=len(raw))
    try:
        return raw, raw.decode("utf-8-sig")
    except UnicodeError as exc:
        raise MaintenanceReadError("BINARY_ARTIFACT", "The file is not UTF-8 text", bytes=len(raw)) from exc


def _cursor(payload):
    return base64.urlsafe_b64encode(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode()).decode()


def _position(arguments, binding, snapshot):
    expected = arguments.get("snapshot")
    offset = arguments.get("offset", 0)
    if arguments.get("cursor"):
        try:
            token = json.loads(base64.urlsafe_b64decode(arguments["cursor"].encode()))
        except (ValueError, UnicodeError) as exc:
            raise MaintenanceReadError("INVALID_CURSOR", "Malformed continuation cursor") from exc
        if (not isinstance(token, dict) or set(token) != {"binding", "snapshot", "offset"}
                or token["binding"] != binding or type(token["offset"]) is not int or token["offset"] < 0):
            raise MaintenanceReadError("INVALID_CURSOR", "The cursor belongs to another resource or view")
        expected, offset = token["snapshot"], token["offset"]
    if expected is not None and expected != snapshot:
        raise MaintenanceReadError("SNAPSHOT_CHANGED", "The source changed; restart without the old cursor", current_snapshot=snapshot)
    return offset


def page_records(records, arguments, *, binding):
    snapshot = object_fingerprint(records)
    start = _position(arguments, binding, snapshot)
    if start > len(records):
        raise MaintenanceReadError("OFFSET_OUT_OF_RANGE", "The cursor is past the end of this view")
    end = min(len(records), start + arguments.get("limit", 20))
    return {"entries": records[start:end], "snapshot": snapshot, "total_entries": len(records),
            "start_offset": start, "end_offset": end, "truncated": end < len(records),
            "next_cursor": _cursor({"binding": binding, "snapshot": snapshot, "offset": end}) if end < len(records) else None}


def list_directory(project, arguments):
    root, relative = arguments["root"], arguments.get("path", ".")
    target = _target(project, root, relative)
    records, hidden = [], 0
    with _open(target, directory=True) as (descriptor, before):
        with os.scandir(descriptor) as scan:
            for entry in scan:
                if len(records) + hidden >= MAX_DIRECTORY_ENTRIES:
                    raise MaintenanceReadError("DIRECTORY_TOO_LARGE", "Narrow the path before listing this directory")
                if _private(Path(relative) / entry.name):
                    hidden += 1
                    continue
                try:
                    info = entry.stat(follow_symlinks=False)
                except FileNotFoundError as exc:
                    raise MaintenanceReadError("SNAPSHOT_CHANGED", "Directory entries changed while being listed") from exc
                kind = "directory" if stat.S_ISDIR(info.st_mode) else "symlink" if stat.S_ISLNK(info.st_mode) else "file" if stat.S_ISREG(info.st_mode) else "special"
                records.append({"name": entry.name, "path": str(Path(relative) / entry.name), "kind": kind,
                                "bytes": info.st_size, "mtime_ns": info.st_mtime_ns,
                                "inode": info.st_ino, "readable": kind in {"file", "directory"} and (kind == "directory" or info.st_nlink == 1)})
        after = os.fstat(descriptor)
        if before.st_mtime_ns != after.st_mtime_ns:
            raise MaintenanceReadError("SNAPSHOT_CHANGED", "The directory changed while being listed")
    records.sort(key=lambda item: item["name"])
    page = page_records(records, {"limit": 50, **arguments}, binding=["directory", str(project.root), root, str(Path(relative))])
    return {"root": root, "path": str(Path(relative)), "absolute_path": str(target),
            "hidden_sensitive_entries": hidden, "recursive": False, "read_only": True, **page}


def read_artifact(project, arguments, *, redact):
    root, relative = arguments["root"], arguments["path"]
    target = _target(project, root, relative)
    raw, text = _content(target)
    snapshot = hashlib.sha256(raw).hexdigest()
    try:
        structured = json.loads(text)
    except ValueError:
        structured = None
    if structured is not None:
        text = json.dumps(redact(structured), ensure_ascii=False, indent=2) + "\n"
        representation = "redacted_json"
    else:
        text = redact(text)
        representation = "redacted_text"
    binding = ["text", str(project.root), root, str(Path(relative)), representation, 1]
    start = _position(arguments, binding, snapshot)
    if start > len(text):
        raise MaintenanceReadError("OFFSET_OUT_OF_RANGE", "The offset is past the end of the redacted text")
    end = min(len(text), start + arguments.get("limit", 4096))
    return {"root": root, "path": str(Path(relative)), "absolute_path": str(target),
            "snapshot": snapshot, "source_bytes": len(raw), "representation": representation,
            "content": text[start:end], "total_characters": len(text), "start_offset": start, "end_offset": end,
            "truncated": end < len(text), "read_only": True, "credentials_redacted": True,
            "next_cursor": _cursor({"binding": binding, "snapshot": snapshot, "offset": end}) if end < len(text) else None}


def _json_or_empty(path):
    if not path.exists():
        return {}
    _, text = _content(path)
    value = json.loads(text)
    return value if isinstance(value, dict) else {}


def diagnostic_descriptors(project):
    try:
        conversation = _json_or_empty(project.state_dir / "conversation.json")
    except (ConfigurationError, ValueError):
        conversation = {}
    result = {}
    for identity, target in {
        "input_resolution": project.requirements_dir / "input_resolution_errors.json",
        "compiler_failure": project.plans_dir / "compiler_last_failure.json",
    }.items():
        exists = target.exists()
        source_snapshot = None
        try:
            if exists:
                raw, text = _content(target)
                source_snapshot = hashlib.sha256(raw).hexdigest()
                document = json.loads(text)
                if not isinstance(document, dict):
                    raise ValueError("Diagnostic must be a JSON object")
            else:
                document = {}
        except (ConfigurationError, ValueError) as exc:
            result[identity] = {"diagnostic_id": identity, "available": exists, "current": False,
                                "status": "UNREADABLE", "path": str(target), "error": str(exc), "snapshot": source_snapshot,
                                "read": {"operation": "read_diagnostic", "arguments": {"diagnostic_id": identity}}}
            continue
        current, status = False, "NOT_AVAILABLE"
        if exists and identity == "input_resolution":
            blocker = conversation.get("input_blocker") or {}
            recorded = document.get("blocker") or {}
            current = bool(conversation.get("input_error") and blocker.get("condition_fingerprint")
                           and blocker.get("condition_fingerprint") == recorded.get("condition_fingerprint"))
            status = "CURRENT" if current else "HISTORICAL_RESOLVED" if not conversation.get("input_error") else "HISTORICAL_UNVERIFIED"
        elif exists:
            if document.get("status") == "RESOLVED_MODEL_CANDIDATE":
                status = "RESOLVED"
            elif document.get("status") == "NEEDS_USER_INFORMATION":
                status = "NEEDS_USER_INFORMATION" if conversation.get("pending_questions") else "HISTORICAL"
            else:
                repair = conversation.get("compiler_repair") or {}
                blocker = conversation.get("compiler_blocker") or {}
                current = bool(document.get("status") == "REJECTED_MODEL_CANDIDATE"
                               and ((repair.get("candidate") == document.get("candidate") and bool(repair))
                                    or blocker.get("diagnostics_path") == str(target)))
                status = "CURRENT" if current else "HISTORICAL_UNVERIFIED"
        result[identity] = {"diagnostic_id": identity, "available": exists, "current": current,
                            "status": status, "path": str(target), "snapshot": source_snapshot,
                            "read": {"operation": "read_diagnostic", "arguments": {"diagnostic_id": identity}}}
    return result


def read_diagnostic(project, arguments, *, redact):
    descriptor = diagnostic_descriptors(project)[arguments["diagnostic_id"]]
    if not descriptor["available"]:
        raise MaintenanceReadError("DIAGNOSTIC_NOT_FOUND", "No recorded diagnostic exists for this identifier", diagnostic_id=arguments["diagnostic_id"])
    target = Path(descriptor["path"])
    params = {key: value for key, value in arguments.items() if key != "diagnostic_id"}
    params.update(root="output", path=str(target.relative_to(project.output_root)))
    content = read_artifact(project, params, redact=redact)
    if descriptor.get("snapshot") != content["snapshot"]:
        raise MaintenanceReadError("SNAPSHOT_CHANGED", "The diagnostic changed between classification and reading; retry")
    return {**content, "diagnostic": descriptor}
