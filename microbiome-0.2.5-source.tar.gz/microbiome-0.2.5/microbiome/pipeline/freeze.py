"""Freeze a completely passed validation into immutable production manifests."""

from __future__ import annotations

import shutil
from copy import deepcopy
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from microbiome.pipeline.errors import FreezeError, ConfigurationError
from microbiome.pipeline.inputs import build_production_input_contract
from microbiome.pipeline.io import (
    atomic_write_text,
    manifest_fingerprint,
    object_fingerprint,
    read_json,
    read_yaml,
    write_yaml,
)
from microbiome.pipeline.lifecycle import load_plan
from microbiome.pipeline.lock_schema import validate_pipeline_lock
from microbiome.pipeline.models import PipelinePhase, topological_step_ids

if TYPE_CHECKING:
    from microbiome.pipeline.project import PipelineProject


def _utcnow() -> str:
    return datetime.now(UTC).isoformat()


def _verified_report(path: Path, plan: dict[str, Any]) -> dict[str, Any]:
    if not path.is_file():
        raise FreezeError(f"validation report does not exist: {path}")
    report = read_json(path)
    if report.get("status") != "PASSED":
        raise FreezeError("pipeline freeze requires validation_report status == PASSED")
    if report.get("plan_fingerprint") != plan["plan_fingerprint"]:
        raise FreezeError("validation report does not match the current experiment plan")
    expected = object_fingerprint({key: value for key, value in report.items() if key != "report_fingerprint"})
    if report.get("report_fingerprint") != expected:
        raise FreezeError("validation report fingerprint is invalid")
    statuses = {step.get("step_id"): step.get("status") for step in report.get("steps", [])}
    missing = [step["step_id"] for step in plan["steps"] if statuses.get(step["step_id"]) != "PASSED"]
    if missing:
        raise FreezeError(f"not every planned step passed validation: {', '.join(missing)}")
    return report


def _phase_report(
    project: PipelineProject,
    filename: str,
    plan: dict[str, Any],
    requirements_version: int,
) -> dict[str, Any]:
    path = project.state_dir / filename
    if not path.is_file():
        raise FreezeError(f"required phase report does not exist: {path}")
    report = read_json(path)
    if report.get("status") != "PASSED" or report.get("plan_fingerprint") != plan["plan_fingerprint"]:
        raise FreezeError(f"stale or failed phase report: {path}")
    if report.get("requirements_version") != requirements_version:
        raise FreezeError(f"phase report has a stale requirements version: {path}")
    expected = object_fingerprint({key: value for key, value in report.items() if key != "report_fingerprint"})
    if report.get("report_fingerprint") != expected:
        raise FreezeError(f"phase report fingerprint is invalid: {path}")
    return report


def _verify_backfilled_bootstrap(project: PipelineProject, report: dict[str, Any], plan: dict[str, Any]) -> None:
    """Accept an auto-backfilled bootstrap report only when it agrees with the ledger.

    The execution ledger is the authority: an auto-backfilled report whose
    executables match the verified successful records (and still exist) is a
    faithful representation; anything else stays a hard failure.
    """
    if report.get("source") != "successful_pretest_execution":
        raise FreezeError("validation used a different toolchain bootstrap report")
    from microbiome.pipeline.ledger import ExecutionLedger

    records: dict[str, dict[str, Any]] = {}
    for entry in ExecutionLedger.for_project(project).entries():
        if entry.get("status") == "PASSED" and entry.get("verified"):
            records[str(entry.get("step_id"))] = entry
    tools = report.get("tools") or {}
    for step in plan["steps"]:
        entry = tools.get(step["step_id"]) or {}
        executable = entry.get("executable")
        if not executable or not Path(str(executable)).is_file():
            raise FreezeError(f"backfilled bootstrap report has an unverifiable executable for {step['step_id']}")
        record = records.get(step["step_id"])
        recorded = (record.get("tool") or {}).get("executable") if record else None
        if recorded and str(recorded) != str(executable):
            raise FreezeError(
                f"backfilled bootstrap report executable disagrees with the execution ledger for {step['step_id']}"
            )


def _verify_backfilled_database_report(report: dict[str, Any]) -> None:
    if report.get("source") != "successful_pretest_execution":
        raise FreezeError("validation used a different database resolution report")
    for name, entry in (report.get("databases") or {}).items():
        path = entry.get("path") or entry.get("root_path")
        if not path or not Path(str(path)).exists():
            raise FreezeError(f"backfilled database report has an unverifiable path for {name}")


def _advance_after_freeze(machine) -> None:
    """Move the lifecycle to FROZEN; readiness and approval are the finalizer's job."""
    from microbiome.pipeline.state import LifecycleState

    if machine.current in {LifecycleState.PRETEST_PASSED, LifecycleState.VALIDATED}:
        machine.transition(
            LifecycleState.PRETEST_FINALIZING,
            reason="validated pre-test is being finalized into production manifests",
        )
    if machine.current == LifecycleState.PRETEST_FINALIZING:
        machine.transition(
            LifecycleState.FROZEN,
            reason="validated manifests frozen into an immutable production lock",
        )


def _archive_current(project: PipelineProject) -> None:
    current = read_yaml(project.pipeline_lock_path)
    version = str(current.get("pipeline_version") or "unknown").replace("/", "_")
    destination = project.state_dir / "history" / version
    if destination.exists():
        raise FreezeError(f"immutable history version already exists: {destination}")
    destination.mkdir(parents=True)
    for path in (
        project.pipeline_lock_path,
        project.toolchain_lock_path,
        project.database_lock_path,
        project.validation_report_path,
        project.pipeline_dir / "production_approval.yaml",
    ):
        if path.is_file():
            shutil.copy2(path, destination / path.name)


class PipelineFreezer:
    def __init__(self, project: PipelineProject):
        self.project = project

    def freeze(self, *, validation_report_path: str | Path | None = None, new_version: bool = False) -> dict[str, Any]:
        """Write locks once; a changed lock requires an explicit new pipeline version."""
        self.project.require_layout()
        from microbiome.pipeline.requirements import RequirementManager
        from microbiome.pipeline.state import LifecycleState, ProjectStateMachine

        machine = ProjectStateMachine(self.project)
        machine.require(
            LifecycleState.PRETEST_PASSED,
            LifecycleState.VALIDATED,
            LifecycleState.PRETEST_FINALIZING,
            LifecycleState.FROZEN,
            LifecycleState.AWAITING_PRODUCTION_APPROVAL,
        )
        requirements = RequirementManager(self.project).require_confirmed()
        plan = load_plan(self.project)
        for name in ("analysis_plan", "dependencies"):
            approval = requirements.get("approvals", {}).get(name, {})
            if (approval.get("status") != "CONFIRM" or approval.get("plan_fingerprint") != plan["plan_fingerprint"]
                    or approval.get("requirements_version") != requirements["requirements_version"]
                    or approval.get("source") == "auto_backfilled_from_successful_pretest"):
                raise FreezeError(f"freeze requires explicit current {name} approval")
        if plan.get("requirements_version") != requirements["requirements_version"]:
            raise FreezeError("analysis plan requirements version is stale")
        validation_path = (
            Path(validation_report_path) if validation_report_path else self.project.validation_report_path
        )
        validation = _verified_report(validation_path, plan)
        from microbiome.pipeline.cases import verify_validation_suite
        suite = verify_validation_suite(self.project, plan)
        from microbiome.visualization.artifacts import verify_pilot_figures
        try:
            figure_reports = {validation["validation_id"]: validation}
            for case in (suite or {}).get("cases", []):
                figure_reports[case["validation_id"]] = read_json(
                    self.project.pretest_dir / case["validation_id"] / "reports" / "validation_report.json")
            visual_reviews = [item for report in figure_reports.values() for item in verify_pilot_figures(plan, report)]
        except (ConfigurationError, ValueError, OSError, KeyError) as error:
            raise FreezeError(f"Pilot figure review failed: {error}") from error
        if validation.get("requirements_version") != requirements["requirements_version"]:
            raise FreezeError("validation report requirements version is stale")
        bootstrap = _phase_report(
            self.project,
            "bootstrap_report.json",
            plan,
            requirements["requirements_version"],
        )
        database_report = _phase_report(
            self.project,
            "database_resolution.json",
            plan,
            requirements["requirements_version"],
        )
        if validation.get("bootstrap_report_fingerprint") != bootstrap["report_fingerprint"]:
            _verify_backfilled_bootstrap(self.project, bootstrap, plan)
        if validation.get("database_report_fingerprint") != database_report["report_fingerprint"]:
            _verify_backfilled_database_report(database_report)

        if self.project.pipeline_lock_path.exists():
            current = read_yaml(self.project.pipeline_lock_path)
            if (
                current.get("manifest_fingerprint") == manifest_fingerprint(current)
                and current.get("plan_fingerprint") == plan["plan_fingerprint"]
                and current.get("validation_report_fingerprint") == validation["report_fingerprint"]
            ):
                validate_pipeline_lock(current)
                _advance_after_freeze(machine)
                return current

        toolchain_lock = {
            "schema_version": 1,
            "created_at": _utcnow(),
            "plan_fingerprint": plan["plan_fingerprint"],
            "requirements_version": requirements["requirements_version"],
            "tools": bootstrap["tools"],
        }
        toolchain_lock["manifest_fingerprint"] = manifest_fingerprint(toolchain_lock)
        database_lock = {
            "schema_version": 1,
            "created_at": _utcnow(),
            "plan_fingerprint": plan["plan_fingerprint"],
            "requirements_version": requirements["requirements_version"],
            "databases": database_report["databases"],
        }
        database_lock["manifest_fingerprint"] = manifest_fingerprint(database_lock)

        steps_by_id = {step["step_id"]: step for step in plan["steps"]}
        validated_steps = {step["step_id"]: step for step in validation.get("steps", [])}
        frozen_steps = []
        for step_id in topological_step_ids(plan["steps"]):
            step = steps_by_id[step_id]
            tool = bootstrap["tools"][step_id]
            from microbiome.pipeline.commands import step_database_paths
            database_paths = step_database_paths(step, database_report["databases"])
            validated_step = validated_steps.get(step_id, {})
            if "exact_database_path" in validated_step:
                validated_paths = validated_step["exact_database_path"]
            else:
                # Old validation reports predate exact consumer-path evidence.
                # Their renderer used the resource's generic path. A newly
                # selected entry is valid only after a new actual pre-test.
                validated_paths = {
                    alias: str(database_report["databases"][str(spec.get("logical_name") or alias)]["path"])
                    for alias, spec in step["database"].items()
                }
            if validated_paths != database_paths:
                raise FreezeError(f"step {step_id}: consumer resource binding differs from the actual validated entry; revalidate before freezing")
            frozen = {
                "step_id": step_id,
                "purpose": step["purpose"],
                "tool": step["tool"],
                "absolute_executable": tool["executable"],
                "environment_prefix": tool.get("environment_prefix"),
                "tool_version": tool["version_output"],
                "version_args": tool["version_args"],
                "input_template": step["input"],
                "output_template": step["output"],
                "database_path": database_paths,
                "database_binding_version": 1,
                "parameter_list": deepcopy(step["parameters"]),
                "command_template": step["command_template"],
                "threads_policy": step["threads_policy"],
                "memory_policy": step["memory_policy"],
                "gpu_policy": step["gpu_policy"],
                "success_assertions": step["success_criteria"],
                "failure_criteria": step["failure_criteria"],
                "validation_method": step["validation_method"],
                "tool_choice": step["tool_choice"],
                "dependencies": step["dependencies"],
                # Link every frozen step back to the verified execution attempt it
                # was built from; a lock without an execution lineage is invalid.
                "validation": {
                    "validation_id": validation["validation_id"],
                    "validation_report_fingerprint": validation["report_fingerprint"],
                    "source_attempt": validated_steps.get(step_id, {}).get("source_attempt", 1),
                    "step_status": validated_steps.get(step_id, {}).get("status"),
                },
                **({"script_template": step["script_template"]} if step.get("script_template") else {}),
                **({"interpreter": step["interpreter"]} if step.get("interpreter") else {}),
                # Runtime code consumes these aliases; they intentionally duplicate the
                # human-facing lock field names above and are covered by the lock hash.
                "input": step["input"],
                "output": step["output"],
                "database": step["database"],
                "static_input_fingerprints": step.get("static_input_fingerprints", {}),
                **({"figure_contract": step["figure_contract"]} if step.get("figure_contract") else {}),
                **({"runtime_environment": step["runtime_environment"]}
                   if "runtime_environment" in step else {}),
                **({"adapter_path": step["adapter_path"], "adapter_fingerprint": step["adapter_fingerprint"]}
                   if step.get("adapter_path") else {}),
            }
            frozen_steps.append(frozen)

        from microbiome.pipeline.ledger import ExecutionLedger
        from microbiome.pipeline.planning_policy import get_effective_policy

        ledger = ExecutionLedger.for_project(self.project)
        planning_policy = get_effective_policy(self.project)
        pipeline = {
            "execution_scope": plan.get("execution_scope", "sample"),
            "cohort_members": plan.get("cohort_members", []),
            "deliverables": plan.get("deliverables", []),
            "validation_suite_fingerprint": suite.get("suite_fingerprint") if suite else None,
            "schema_version": 1,
            "created_at": _utcnow(),
            "mode": "production replay; no LLM planning is permitted",
            "objective": plan["objective"],
            # Provenance is copied at freeze time. Production never reads a
            # newer catalog or replans when a guide is updated.
            "workflow_references": plan.get("workflow_references", []),
            "visualization_reference": plan.get("visualization_reference"),
            "visualization_decision": plan.get("visualization_decision"),
            "pilot_visual_reviews": visual_reviews,
            "workflow_decisions": plan.get("workflow_decisions", []),
            "workflow_reference_evidence": plan.get("workflow_reference_evidence", {}),
            "requirements_version": requirements["requirements_version"],
            "requirements_fingerprint": requirements["requirements_fingerprint"],
            "plan_fingerprint": plan["plan_fingerprint"],
            # Audit provenance only: replay never consults a newer planning
            # budget or policy, and the existing-lock fast path stays unchanged.
            "planning_provenance": {
                "policy_fingerprint": planning_policy["policy_fingerprint"],
                "policy_revision": planning_policy["revision"],
                "policy_schema_version": planning_policy["schema_version"],
                "message_builder_version": planning_policy["message_builder_version"],
            },
            "validation_status": "PASSED",
            "validation_report_fingerprint": validation["report_fingerprint"],
            "resource_strategy": "MAXIMIZE_WITHIN_LIVE_AND_FROZEN_LIMITS",
            "validated_resource_snapshot": validation.get("resource_snapshot"),
            "production_input_contract": build_production_input_contract(self.project, validation),
            "toolchain_lock_fingerprint": toolchain_lock["manifest_fingerprint"],
            "database_lock_fingerprint": database_lock["manifest_fingerprint"],
            "execution_ledger": {
                "path": str(ledger.path),
                "records": len(ledger.entries()),
                "sha256": ledger.digest(),
            },
            "steps": frozen_steps,
        }
        if "execution_scheduling" in plan:
            from microbiome.pipeline.scheduler import normalize_scheduling
            pipeline["execution_scheduling"] = normalize_scheduling(plan["execution_scheduling"])
        if validation.get("continuation"):
            pipeline["validation_continuation"] = validation["continuation"]
        pipeline_hash = manifest_fingerprint(pipeline)
        pipeline["pipeline_hash"] = pipeline_hash
        pipeline["pipeline_version"] = f"r{requirements['requirements_version']}-{pipeline_hash[:16]}"
        pipeline["manifest_fingerprint"] = manifest_fingerprint(pipeline)

        # Validate the complete candidate before archiving or publishing any
        # lock. A schema failure must leave existing frozen bytes untouched.
        validate_pipeline_lock(pipeline)

        if self.project.pipeline_lock_path.exists():
            current = read_yaml(self.project.pipeline_lock_path)
            if current.get("manifest_fingerprint") == pipeline["manifest_fingerprint"]:
                return current
            if not new_version:
                raise FreezeError(
                    "a different immutable pipeline lock already exists; rerun freeze with new_version=True "
                    "after the original and regression validation cases pass"
                )
            _archive_current(self.project)

        write_yaml(self.project.toolchain_lock_path, toolchain_lock)
        write_yaml(self.project.database_lock_path, database_lock)
        write_yaml(self.project.pipeline_lock_path, pipeline)
        atomic_write_text(
            self.project.pipeline_dir / "run_pipeline.py",
            """#!/usr/bin/env python3
\"\"\"Generated entry point for deterministic replay of this frozen project.\"\"\"
from microbiome.pipeline.cli import main

if __name__ == \"__main__\":
    raise SystemExit(main())
""",
        )
        (self.project.pipeline_dir / "run_pipeline.py").chmod(0o755)
        if validation_path.resolve() != self.project.validation_report_path.resolve():
            shutil.copy2(validation_path, self.project.validation_report_path)
        # A lock is only trustworthy once it has been re-read from disk and
        # passed schema/fingerprint validation; writing bytes is not evidence.
        validate_pipeline_lock(read_yaml(self.project.pipeline_lock_path))
        _advance_after_freeze(machine)
        self.project.set_phase(PipelinePhase.FROZEN)
        return pipeline
