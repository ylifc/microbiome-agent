"""Explicit local cohort imports; never impersonate reads or completed engine runs."""
from __future__ import annotations

import copy
import csv
import gzip
import json
import math
import re
from pathlib import Path

from microbiome.pipeline.errors import ConfigurationError, FreezeError
from microbiome.pipeline.io import object_fingerprint, read_yaml
from microbiome.pipeline.derived import artifact_fingerprint

KIND = "external_cohort_tables"
MODE = "complete_external_cohort"
BINDING = "EXTERNAL_COHORT"
_IDENTIFIER = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$")
_ROLE = re.compile(r"^[A-Za-z][A-Za-z0-9_]{0,63}$")
_FORMATS = {"tsv", "fasta", "json", "gff"}


def _require(value, message):
    if not value:
        raise ConfigurationError(message)


def _local_path(value, *, directory=False):
    _require(isinstance(value, str) and value and "\x00" not in value,
             "external cohort path must be an explicit local absolute path")
    p = Path(value)
    _require(p.is_absolute() and ".." not in p.parts, "external cohort path must be absolute without traversal")
    _require(not any(x.is_symlink() for x in (p, *p.parents)), "external cohort symlinks are forbidden")
    _require(p.is_dir() if directory else p.is_file(), "external cohort path is not an existing regular " + ("directory" if directory else "file"))
    p = p.resolve(strict=True)
    _require(p != Path('/'), "filesystem root cannot be an external input root")
    return p


def _open(path):
    return gzip.open(path, 'rt', encoding='utf-8', errors='strict') if path.suffix == '.gz' else path.open(encoding='utf-8', errors='strict')


def _validate_format(path, fmt, schema, samples):
    """Small schema contract, streaming tables; no annotation/model execution."""
    _require(fmt in _FORMATS, "unsupported external cohort file format")
    _require(isinstance(schema, dict), "external cohort schema must be an object")
    if fmt == 'tsv':
        allowed = {'header', 'id_column', 'unique_ids', 'sample_columns', 'integer'}
        _require(not set(schema) - allowed and 'id_column' in schema,
                 "TSV schema requires id_column and only supported fields")
        header = schema.get('header', True)
        unique = schema.get('unique_ids', True)
        integer = schema.get('integer', False)
        _require(type(header) is bool and type(unique) is bool and type(integer) is bool, "TSV flags must be booleans")
        columns = schema.get('sample_columns')
        if columns is not None:
            _require(isinstance(columns, dict) and set(columns) == set(samples), "matrix sample_columns must bind every declared biological sample exactly once")
            _require(all(type(x) is (str if header else int) for x in columns.values()), "matrix sample column selectors have the wrong type")
            _require(len(set(columns.values())) == len(samples), "matrix sample columns must be unique")
        with _open(path) as f:
            rows = csv.reader(f, delimiter='\t')
            first = next(rows, None)
            _require(first, "external TSV is empty")
            width = len(first)
            if header:
                _require(all(first) and len(set(first)) == width, "TSV header names must be nonempty and unique")
                lookup = {name: i for i, name in enumerate(first)}
                _require(isinstance(schema['id_column'], str) and schema['id_column'] in lookup, "TSV id_column absent from header")
                id_index = lookup[schema['id_column']]
                if columns is not None:
                    _require(all(isinstance(x, str) and x in lookup for x in columns.values()), "matrix sample column absent from header")
                    indices = [lookup[columns[s]] for s in samples]
                else:
                    indices = []
            else:
                _require(type(schema['id_column']) is int and 0 <= schema['id_column'] < width, "headerless TSV requires a valid integer id_column")
                id_index = schema['id_column']
                if columns is not None:
                    _require(all(type(x) is int and 0 <= x < width for x in columns.values()), "headerless sample columns must be valid indices")
                    indices = [columns[s] for s in samples]
                else:
                    indices = []
                import itertools
                rows = itertools.chain([first], rows)
            _require(id_index not in indices, "gene identifier cannot also be a numeric sample column")
            seen, count = set(), 0
            for row in rows:
                _require(len(row) == width, "external TSV row has inconsistent column count")
                identity = row[id_index]
                _require(identity and (not unique or identity not in seen), "external TSV has empty or duplicate identifiers")
                seen.add(identity)
                for idx in indices:
                    try:
                        number = float(row[idx])
                    except ValueError as error:
                        raise ConfigurationError("matrix value is not numeric") from error
                    _require(math.isfinite(number) and number >= 0, "matrix values must be finite and nonnegative")
                    _require(not integer or number.is_integer(), "count matrix contains fractional values")
                count += 1
            _require(count > 0, "external TSV has no data rows")
            return {'rows': count, 'columns': width, 'unique_ids': len(seen), 'sample_columns': copy.deepcopy(columns)}
    _require(not schema, "schema fields are currently only supported for TSV")
    if fmt == 'json':
        with _open(path) as f:
            def invalid_constant(value):
                raise ConfigurationError("nonfinite JSON number")
            value = json.load(f, parse_constant=invalid_constant)
        _require(isinstance(value, (dict, list)) and value, "external JSON must be a nonempty object or list")
        try:
            json.dumps(value, allow_nan=False)
        except ValueError as error:
            raise ConfigurationError("external JSON contains a nonfinite number") from error
        return {'json_type': type(value).__name__}
    if fmt == 'gff':
        count = 0
        with _open(path) as f:
            for line in f:
                if line.startswith('#') or not line.strip():
                    continue
                row = line.rstrip('\n\r').split('\t')
                _require(len(row) == 9, "external GFF requires nine columns")
                try:
                    _require(0 < int(row[3]) <= int(row[4]), "invalid GFF coordinates")
                except ValueError as error:
                    raise ConfigurationError("invalid GFF coordinates") from error
                count += 1
        _require(count, "external GFF is empty")
        return {'features': count}
    ids, length, total = set(), 0, 0
    with _open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if line.startswith('>'):
                _require(not ids or length > 0, "FASTA contains an empty sequence")
                parts = line[1:].split()
                _require(parts and parts[0] not in ids, "FASTA contains empty or duplicate identifiers")
                ids.add(parts[0]); length = 0
            else:
                _require(ids and re.fullmatch(r'[A-Za-z*?.-]+', line), "invalid FASTA sequence content")
                length += len(line); total += len(line)
    _require(ids and length, "FASTA is empty or has an empty final sequence")
    return {'sequences': len(ids), 'sequence_characters': total}


def resolve_external_manifest(project, local_roots, samples, cohort_artifacts, provenance=None):
    _require(isinstance(local_roots, list) and local_roots, "explicit local_roots are required")
    roots = [_local_path(x, directory=True) for x in local_roots]
    _require(len(roots) == len(set(roots)), "duplicate external local roots")
    _require(isinstance(samples, list) and samples, "external cohort requires biological samples")
    metadata, sample_ids = [], []
    for sample in samples:
        _require(isinstance(sample, dict) and not set(sample) - {'sample_id', 'metadata'}, "external sample accepts sample_id and optional metadata only")
        sid = sample.get('sample_id')
        _require(isinstance(sid, str) and _IDENTIFIER.fullmatch(sid) and sid not in sample_ids, "missing, invalid or duplicate sample_id")
        info = sample.get('metadata', {})
        _require(isinstance(info, dict) and 'sample_id' not in info, "sample metadata must be an object without a duplicate sample_id")
        metadata.append({'sample_id': sid, **copy.deepcopy(info)}); sample_ids.append(sid)
    _require(isinstance(cohort_artifacts, dict) and cohort_artifacts, "shared cohort_artifacts are required")
    _require(all(isinstance(k, str) and _ROLE.fullmatch(k) for k in cohort_artifacts), "invalid cohort artifact role")
    _require(provenance is None or isinstance(provenance, dict), "external provenance must be an object")
    try:
        json.dumps([metadata, provenance], allow_nan=False)
    except (ValueError, TypeError) as error:
        raise ConfigurationError("external metadata/provenance must be finite JSON values") from error
    shared, locations, matrices = {}, set(), 0
    forbidden = [Path(project.output_root).resolve(), Path(project.state_dir).resolve()]
    for role, spec in sorted(cohort_artifacts.items()):
        _require(isinstance(spec, dict) and not set(spec) - {'path','format','schema'} and {'path','format'} <= set(spec), "external artifact accepts path/format/schema only; parent selectors and caller fingerprints are forbidden")
        p = _local_path(spec['path'])
        _require(any(p.is_relative_to(r) for r in roots), "external artifact is outside declared local roots")
        _require(not any(p.is_relative_to(r) for r in forbidden), "external artifact cannot come from this project's output/state tree")
        _require(p not in locations, "same external file cannot masquerade as multiple artifact roles")
        locations.add(p)
        before = artifact_fingerprint(p)
        schema = copy.deepcopy(spec.get('schema', {}))
        facts = _validate_format(p, spec['format'], schema, sample_ids)
        _require(before == artifact_fingerprint(p), "external file changed during format validation")
        matrices += spec['format'] == 'tsv' and schema.get('sample_columns') is not None
        shared[role] = {'path': str(p), 'format': spec['format'], 'schema': schema, 'format_facts': facts, 'fingerprint': before}
    _require(matrices > 0, "external cohort requires at least one matrix binding every biological sample")
    manifest = {'schema_version':1, 'resolution_status':'CONFIRMED', 'overall_source':KIND, 'input_kind':KIND,
                'layout':'EXTERNAL_COHORT_TABLES', 'pilot_mode':MODE, 'local_roots':[str(x) for x in roots],
                'samples':[{'sample_id':s, 'source_type':KIND, 'artifacts':{}} for s in sample_ids],
                'sample_metadata':metadata, 'cohort_artifacts':shared, 'external_provenance':copy.deepcopy(provenance or {})}
    manifest['manifest_fingerprint'] = object_fingerprint(manifest)
    return manifest


def verify_external_manifest(project, manifest):
    _require(manifest.get('input_kind') == KIND and manifest.get('pilot_mode') == MODE and 'parent' not in manifest, "invalid external cohort mode or fake parent provenance")
    _require(manifest.get('manifest_fingerprint') == object_fingerprint({k:v for k,v in manifest.items() if k != 'manifest_fingerprint'}), "external manifest fingerprint is invalid")
    metadata = manifest.get('sample_metadata', [])
    samples = [{'sample_id':r['sample_id'], 'metadata':{k:v for k,v in r.items() if k != 'sample_id'}} for r in metadata]
    specs = {role:{k:spec[k] for k in ('path','format','schema')} for role,spec in manifest.get('cohort_artifacts',{}).items()}
    expected = resolve_external_manifest(project, manifest['local_roots'], samples, specs, manifest.get('external_provenance'))
    _require(expected == manifest, "external files, sample ownership or schema changed after review")
    return manifest


def validate_external_plan(plan, manifest):
    external = manifest.get('input_kind') == KIND
    if not external:
        _require(plan.get('pilot_mode') != MODE, "complete external pilot requires a confirmed external cohort manifest")
        return
    from microbiome.pipeline.planning_inputs import input_planning_contract
    contract = input_planning_contract(manifest)
    violations = [{"field": "plan." + key, "code": "INPUT_ADAPTER_FIELD_REQUIRED",
                   "expected": expected, "actual": plan.get(key),
                   "message": f"Set plan.{key}={expected!r} at the plan top level; requirements and step.parameters do not satisfy this field."}
                  for key, expected in contract['required_plan_fields'].items() if plan.get(key) != expected]
    violations.extend({"field": f"plan.steps[{index}].scope", "code": "INPUT_ADAPTER_SCOPE_REQUIRED",
                       "expected": "cohort", "actual": step.get('scope'),
                       "message": "External cohort tables require scope='cohort' on every analysis step."}
                      for index, step in enumerate(plan['steps']) if step.get('scope') != 'cohort')
    bound = {value for step in plan['steps'] for value in step.get('input', {}).values()
             if isinstance(value, str)}
    missing = [role for role in manifest['cohort_artifacts'] if '{runtime.cohort_' + role + '}' not in bound]
    violations.extend({"field": "plan.steps[*].input", "code": "INPUT_ADAPTER_BINDING_REQUIRED",
                       "expected": contract['cohort_runtime_bindings'][role], "role": role,
                       "message": "Consume this declared role through an exact step.input runtime binding; do not use a literal path or runtime.ROLE."}
                      for role in missing)
    if violations:
        error = ConfigurationError("External cohort input contract is incomplete: " + '; '.join(
            f"{row['field']} requires {row['expected']!r}" for row in violations)
            + ". Correct these fields on the existing plan; do not add a manifest_cases validation step.")
        error.details = {"violations": violations, "next_action": "repair_candidate_input_adapter"}
        raise error


def external_contract(project, validation, manifest, plan):
    from microbiome.pipeline.cohort import cohort_runtime_inputs
    verify_external_manifest(project, manifest); validate_external_plan(plan, manifest)
    inputs = cohort_runtime_inputs(plan, manifest)
    actual = {k:v['path'] for k,v in validation.get('runtime_input_source', {}).items()}
    subset = validation.get('representative_subset', {})
    if (actual != inputs or validation.get('pilot_mode') != MODE or validation.get('pretest_fraction', 'absent') is not None
            or subset.get('mode') != MODE or subset.get('sampling_performed') is not False):
        raise FreezeError("external validation must use every complete declared artifact without sequence sampling")
    payload = {'binding_mode':BINDING, 'project_paths':project.load_config()['paths'],
               'raw_data_root':project.load_config()['paths']['raw_data'], 'external_manifest':copy.deepcopy(manifest),
               'samples':manifest['samples'], 'cohort_members':plan['cohort_members'],
               'bindings':{k:{'source_path':v, 'pilot_subset_path':None} for k,v in inputs.items()}}
    payload['contract_fingerprint'] = object_fingerprint(payload)
    return payload


def verify_external_contract(project, contract):
    from microbiome.pipeline.cohort import cohort_runtime_inputs
    manifest = verify_external_manifest(project, contract['external_manifest'])
    _require(contract.get('samples') == manifest['samples'], "external frozen biological samples differ from the manifest")
    expected = cohort_runtime_inputs({'cohort_members':contract['cohort_members']}, manifest)
    _require(contract.get('bindings') == {k:{'source_path':v, 'pilot_subset_path':None} for k,v in expected.items()},
             "external frozen artifact roles, subsets or samples changed")
    _require(read_yaml(project.requirements_dir/'input_manifest.yaml') == manifest, "external inputs differ from the frozen confirmed manifest")
    return expected
