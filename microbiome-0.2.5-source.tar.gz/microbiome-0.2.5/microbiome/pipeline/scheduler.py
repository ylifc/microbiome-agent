"""Bounded DAG dispatch; only the coordinator publishes shared execution facts."""
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
from pathlib import Path
from microbiome.pipeline.errors import ConfigurationError

FIELDS = {"max_concurrent_steps", "max_total_threads", "max_total_memory_gb"}

def normalize_scheduling(value):
    if value is None:
        return {"max_concurrent_steps": 1, "max_total_threads": 2**31-1, "max_total_memory_gb": 2**31-1}
    if not isinstance(value, dict) or set(value) != FIELDS:
        raise ConfigurationError("execution_scheduling requires exactly the concurrency, threads and memory budgets")
    if any(type(v) is not int or v < 1 for v in value.values()):
        raise ConfigurationError("execution_scheduling budgets must be positive integers")
    if value["max_concurrent_steps"] > 256:
        raise ConfigurationError("execution_scheduling max_concurrent_steps must be <=256")
    return dict(value)

def live_scheduling(value, snapshot):
    """Respect reviewed aggregate ceilings and the currently usable machine budget."""
    policy = normalize_scheduling(value)
    live = snapshot if isinstance(snapshot, dict) else snapshot.as_dict()
    policy["max_total_threads"] = min(policy["max_total_threads"], live["cpu_threads"])
    policy["max_total_memory_gb"] = min(policy["max_total_memory_gb"], live["memory_budget_gb"])
    return policy

def validate_parallel_paths(steps, rendered):
    by_id = {s["step_id"]: s for s in steps}
    def ancestors(sid, seen=None):
        seen = set() if seen is None else seen
        for dep in by_id[sid].get("dependencies", []):
            if dep not in seen:
                seen.add(dep); ancestors(dep, seen)
        return seen
    ancestry = {sid: ancestors(sid) for sid in by_id}
    def overlaps(a, b):
        a, b = Path(a).resolve(), Path(b).resolve()
        return a == b or a in b.parents or b in a.parents
    for i, left in enumerate(by_id):
        for right in list(by_id)[i+1:]:
            if any(overlaps(a,b) for a in rendered[left]["outputs"].values() for b in rendered[right]["outputs"].values()):
                raise ConfigurationError(f"distinct steps own overlapping output paths: {left}, {right}")
            for producer, consumer in ((left,right),(right,left)):
                if any(overlaps(a,b) for a in rendered[producer]["outputs"].values() for b in rendered[consumer]["inputs"].values()):
                    if producer not in ancestry[consumer]:
                        raise ConfigurationError(f"undeclared producer dependency: {producer} -> {consumer}")
    return True

def run_ready_dag(steps, resources_by_id, policy, execute, on_result, *, initial_completed=()):
    policy = normalize_scheduling(policy)
    order = [s["step_id"] for s in steps]
    by_id = {s["step_id"]: s for s in steps}
    if len(by_id) != len(steps):
        raise ConfigurationError("duplicate scheduler step IDs")
    completed = set(initial_completed)
    if not completed <= by_id.keys():
        raise ConfigurationError("unknown initial completed steps")
    for sid in by_id:
        deps = set(by_id[sid].get("dependencies", []))
        if not deps <= by_id.keys() or (sid in completed and not deps <= completed):
            raise ConfigurationError("invalid or incomplete initial dependency closure")
        r = resources_by_id[sid]
        if any(type(r.get(k)) is not int or r[k] < 1 for k in ("threads","memory_gb")):
            raise ConfigurationError("scheduler resources must be positive integers")
        if type(r.get("gpus",0)) is not int or r.get("gpus",0) < 0:
            raise ConfigurationError("scheduler GPU count must be a nonnegative integer")
        if r["threads"] > policy["max_total_threads"] or r["memory_gb"] > policy["max_total_memory_gb"]:
            raise ConfigurationError(f"step cannot fit scheduling budget: {sid}")
    pending = set(order) - completed
    active, results = {}, {}
    stopped = False
    callback_error = None
    with ThreadPoolExecutor(max_workers=policy["max_concurrent_steps"], thread_name_prefix="microbiome-step") as pool:
        while pending or active:
            used_threads = sum(resources_by_id[s]["threads"] for s in active.values())
            used_memory = sum(resources_by_id[s]["memory_gb"] for s in active.values())
            gpu_busy = any(resources_by_id[s].get("gpus",0) for s in active.values())
            if not stopped:
                for sid in order:
                    if sid not in pending or not set(by_id[sid].get("dependencies", [])) <= completed:
                        continue
                    r = resources_by_id[sid]
                    if (len(active) >= policy["max_concurrent_steps"] or used_threads+r["threads"] > policy["max_total_threads"]
                            or used_memory+r["memory_gb"] > policy["max_total_memory_gb"] or (gpu_busy and r.get("gpus",0))):
                        continue
                    pending.remove(sid)
                    active[pool.submit(execute,sid)] = sid
                    used_threads += r["threads"]; used_memory += r["memory_gb"]
                    gpu_busy = gpu_busy or bool(r.get("gpus",0))
            if not active:
                if pending and not stopped:
                    raise ConfigurationError("DAG has unsatisfied dependencies or a cycle")
                break
            done, _ = wait(active, return_when=FIRST_COMPLETED)
            for future in sorted(done, key=lambda f: order.index(active[f])):
                sid = active.pop(future)
                try:
                    result = future.result()
                    if not isinstance(result,dict) or type(result.get("passed")) is not bool:
                        raise ConfigurationError("worker must return a passed boolean")
                except Exception as error:
                    result = {"passed":False,"worker_error":f"{type(error).__name__}: {error}"}
                results[sid] = result
                if result["passed"]:
                    completed.add(sid)
                else:
                    stopped = True
                try:
                    on_result(sid,result)
                except Exception as error:
                    stopped = True
                    callback_error = callback_error or error
        if callback_error:
            raise callback_error
    return {sid:results[sid] for sid in order if sid in results}
