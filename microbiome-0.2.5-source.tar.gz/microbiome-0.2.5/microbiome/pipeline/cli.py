"""Command-line lifecycle for validated and frozen pipelines."""

from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Any

from microbiome.pipeline.dependencies import DependencyResolver, confirm_plan
from microbiome.pipeline.errors import PipelineError
from microbiome.pipeline.execution import FrozenPipelineExecutor
from microbiome.pipeline.freeze import PipelineFreezer
from microbiome.pipeline.io import read_json, read_yaml
from microbiome.pipeline.lifecycle import bootstrap_toolchain, load_plan, resolve_databases, save_experiment_plan
from microbiome.pipeline.project import PipelineProject, discover_project
from microbiome.pipeline.registry import generate_resource_catalog
from microbiome.pipeline.requirements import ConfirmationAction, RequirementManager
from microbiome.pipeline.state import ProjectStateMachine
from microbiome.pipeline.validation import SmallScaleValidator


def _key_values(values: list[str]) -> dict[str, str]:
    result: dict[str, str] = {}
    for value in values:
        key, separator, path = value.partition("=")
        if not separator or not key or not path:
            raise argparse.ArgumentTypeError(f"expected KEY=PATH, got: {value}")
        if key in result:
            raise argparse.ArgumentTypeError(f"duplicate input key: {key}")
        result[key] = path
    return result


def _emit(value: Any) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True))


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="microbiome-pipeline",
        description="Validate, freeze, and deterministically replay microbial bioinformatics pipelines.",
    )
    parser.add_argument("--project", default=".", help="Pipeline project root (default: current directory).")
    subparsers = parser.add_subparsers(dest="command", required=True)

    init = subparsers.add_parser("init", help="Create project_config.yaml and persistent state directories.")
    init.add_argument("--raw-data", required=True)
    init.add_argument("--database", required=True)
    init.add_argument("--output", required=True)

    subparsers.add_parser("discover", help="Generate a read-only input/database/environment inventory.")
    requirements = subparsers.add_parser("requirements", help="Show or update persistent confirmed requirements.")
    requirements.add_argument("--topic", choices=("input", "dataset", "target", "analysis_goal"))
    requirements.add_argument("--action", choices=tuple(action.value for action in ConfirmationAction))
    requirements.add_argument("--value-json", help="JSON object for CONFIRM or MODIFY.")
    requirements.add_argument("--summary", help="Optional compact conversation summary.")
    subparsers.add_parser("plan-check", help="Validate experiment_plan.yaml without executing it.")
    subparsers.add_parser("plan-save", help="Persist the current plan and evidence against confirmed requirements.")
    plan_decision = subparsers.add_parser("plan-decision", help="Explicitly CONFIRM, MODIFY, or CANCEL the plan.")
    plan_decision.add_argument("--action", required=True, choices=tuple(action.value for action in ConfirmationAction))
    subparsers.add_parser("dependency-review", help="Compare the confirmed plan with installed resources.")
    dependency_decision = subparsers.add_parser(
        "dependency-decision", help="Explicitly approve, modify, or cancel the dependency plan."
    )
    dependency_decision.add_argument(
        "--action", required=True, choices=tuple(action.value for action in ConfirmationAction)
    )
    subparsers.add_parser("bootstrap", help="Resolve and smoke-test existing executables; never analyze data.")
    subparsers.add_parser("resolve-databases", help="Validate local database markers/fingerprints; never download.")
    catalog = subparsers.add_parser("catalog", help="Generate RESOURCE_CATALOG.md from the YAML registries.")
    catalog.add_argument("--check", action="store_true", help="Fail if the generated catalog is stale.")

    validate = subparsers.add_parser("validate", help="Run every planned step on deterministic representative data.")
    validate.add_argument("--input", action="append", default=[], metavar="KEY=PATH", required=True)
    validate.add_argument("--sample-id", default="validation")
    validate.add_argument("--max-records", type=int)
    validate.add_argument("--fraction", type=float, help="Pre-test logical-record fraction (default: 0.10).")
    validate.add_argument("--seed", type=int, help="Deterministic pre-test sampling seed.")
    validate.add_argument("--timeout", type=int)
    validate.add_argument("--threads", type=int, help="Optional CPU upper bound; default uses the live maximum.")
    validate.add_argument("--memory-gb", type=int, help="Optional RAM upper bound; default uses the live maximum.")
    validate.add_argument("--gpus", type=int, help="Optional GPU upper bound; default uses all visible GPUs.")
    validate.add_argument(
        "--new-version",
        action="store_true",
        help="Write a candidate validation report for an explicitly new frozen version.",
    )

    repair = subparsers.add_parser(
        "repair-validate",
        help="Run the original validation case plus one minimized READY regression case.",
    )
    repair.add_argument("--regression-manifest", required=True)
    repair.add_argument("--timeout", type=int)
    repair.add_argument("--threads", type=int, help="Optional CPU upper bound; default uses the live maximum.")
    repair.add_argument("--memory-gb", type=int, help="Optional RAM upper bound; default uses the live maximum.")
    repair.add_argument("--gpus", type=int, help="Optional GPU upper bound; default uses all visible GPUs.")

    freeze = subparsers.add_parser("freeze", help="Create immutable toolchain/database/pipeline locks.")
    freeze.add_argument("--validation-report")
    freeze.add_argument("--new-version", action="store_true")

    finalize = subparsers.add_parser(
        "finalize",
        help="Freeze the passed pre-test, re-validate the written lock, and run production readiness checks.",
    )
    finalize.add_argument("--validation-report")
    finalize.add_argument("--new-version", action="store_true")

    recover = subparsers.add_parser(
        "recover-pretest",
        help="Recover machine-readable pre-test state from a legacy results directory (never guesses).",
    )
    recover.add_argument("--root", help="Results/project root to recover; defaults to the project root.")

    preflight = subparsers.add_parser("preflight", help="Read-only production drift check.")
    preflight.add_argument("--input", action="append", default=[], metavar="KEY=PATH", required=True)
    preflight.add_argument("--sample-id", required=True)
    preflight.add_argument("--run-id", required=True)
    preflight.add_argument("--threads", type=int, help="Optional CPU upper bound; default uses the live maximum.")
    preflight.add_argument("--memory-gb", type=int, help="Optional RAM upper bound; default uses the live maximum.")
    preflight.add_argument("--gpus", type=int, help="Optional GPU upper bound; default uses all visible GPUs.")

    run = subparsers.add_parser("run", help="Replay only pipeline.lock.yaml; no planning or repair.")
    run.add_argument("--input", action="append", default=[], metavar="KEY=PATH", required=True)
    run.add_argument("--sample-id", required=True)
    run.add_argument("--run-id")
    run.add_argument("--threads", type=int, help="Optional CPU upper bound; default uses the live maximum.")
    run.add_argument("--memory-gb", type=int, help="Optional RAM upper bound; default uses the live maximum.")
    run.add_argument("--gpus", type=int, help="Optional GPU upper bound; default uses all visible GPUs.")
    run.add_argument("--timeout", type=int)
    run.add_argument("--resume", action="store_true")

    subparsers.add_parser("status", help="Report current artifacts and latest validation/run state.")
    return parser


def _status(project: PipelineProject) -> dict[str, Any]:
    artifacts = {
        "project_config": project.config_path,
        "lifecycle_state": project.lifecycle_state_path,
        "requirements": project.requirements_path,
        "decision_log": project.decision_log_path,
        "conversation_summary": project.conversation_summary_path,
        "experiment_plan": project.plan_path,
        "discovery_inventory": project.discovery_inventory_path,
        "bootstrap_report": project.state_dir / "bootstrap_report.json",
        "database_resolution": project.state_dir / "database_resolution.json",
        "database_registry": project.database_registry_path,
        "tool_registry": project.tool_registry_path,
        "resource_catalog": project.resource_catalog_path,
        "validation_report": project.validation_report_path,
        "toolchain_lock": project.toolchain_lock_path,
        "database_lock": project.database_lock_path,
        "pipeline_lock": project.pipeline_lock_path,
        "execution_ledger": project.pretest_dir / "pipeline" / "execution_ledger.jsonl",
        "production_readiness": project.pipeline_dir / "production_readiness.json",
    }
    result: dict[str, Any] = {
        "project": str(project.root),
        "artifacts": {name: {"path": str(path), "exists": path.is_file()} for name, path in artifacts.items()},
    }
    if project.config_path.is_file():
        result["phase"] = project.load_config().get("phase")
        if project.lifecycle_state_path.is_file():
            result["lifecycle"] = ProjectStateMachine(project).load()
        if project.requirements_path.is_file():
            requirements = RequirementManager(project).load()
            result["requirements"] = {
                "version": requirements["requirements_version"],
                "confirmed_fields": requirements["confirmed_fields"],
                "unresolved_questions": requirements["unresolved_questions"],
            }
    if project.validation_report_path.is_file():
        validation = read_json(project.validation_report_path)
        result["validation"] = {
            "status": validation.get("status"),
            "validation_id": validation.get("validation_id"),
            "failed_step": validation.get("failed_step"),
        }
    if project.pipeline_lock_path.is_file():
        lock = read_yaml(project.pipeline_lock_path)
        result["pipeline"] = {
            "version": lock.get("pipeline_version"),
            "fingerprint": lock.get("manifest_fingerprint"),
            "validation_status": lock.get("validation_status"),
        }
    readiness_path = project.pipeline_dir / "production_readiness.json"
    if readiness_path.is_file():
        readiness = read_json(readiness_path)
        result["production_readiness"] = {
            "ready": readiness.get("ready"),
            "checked_at": readiness.get("checked_at"),
            "missing_artifacts": readiness.get("missing_artifacts", []),
        }
    manifests = sorted(project.runs_dir.glob("*/run_manifest.yaml"), key=lambda path: path.stat().st_mtime)
    if manifests:
        latest = read_yaml(manifests[-1])
        result["latest_run"] = {
            "path": str(manifests[-1]),
            "run_id": latest.get("run_id"),
            "status": latest.get("status"),
            "pipeline_version": latest.get("pipeline_version"),
            "failed_samples": latest.get("failed_samples", []),
        }
    return result


def main(argv: list[str] | None = None) -> int:
    parser = _parser()
    args = parser.parse_args(argv)
    project = PipelineProject(args.project)
    try:
        if args.command == "init":
            project = PipelineProject.initialize(
                args.project,
                raw_data_path=args.raw_data,
                database_path=args.database,
                output_path=args.output,
            )
            _emit({"status": "READY", "project_config": str(project.config_path)})
        elif args.command == "discover":
            _emit(discover_project(project))
        elif args.command == "requirements":
            manager = RequirementManager(project)
            if args.action:
                if not args.topic:
                    raise ValueError("--topic is required when --action is used")
                value = json.loads(args.value_json) if args.value_json else None
                _emit(
                    manager.decide(
                        args.topic,
                        value,
                        action=ConfirmationAction(args.action),
                        conversation_summary=args.summary,
                    )
                )
            else:
                _emit(manager.load())
        elif args.command == "plan-check":
            plan = load_plan(project)
            _emit(
                {
                    "status": "VALID",
                    "plan_fingerprint": plan["plan_fingerprint"],
                    "steps": [step["step_id"] for step in plan["steps"]],
                }
            )
        elif args.command == "plan-save":
            _emit(save_experiment_plan(project, read_yaml(project.plan_path)))
        elif args.command == "plan-decision":
            _emit(confirm_plan(project, ConfirmationAction(args.action)))
        elif args.command == "dependency-review":
            _emit(DependencyResolver(project).review())
        elif args.command == "dependency-decision":
            _emit(DependencyResolver(project).approve(ConfirmationAction(args.action)))
        elif args.command == "bootstrap":
            _emit(bootstrap_toolchain(project))
        elif args.command == "resolve-databases":
            _emit(resolve_databases(project))
        elif args.command == "catalog":
            project.require_layout()
            _emit(generate_resource_catalog(project, check=args.check))
        elif args.command == "validate":
            _emit(
                SmallScaleValidator(project).validate(
                    _key_values(args.input),
                    sample_id=args.sample_id,
                    max_records=args.max_records,
                    fraction=args.fraction,
                    seed=args.seed,
                    timeout_seconds=args.timeout,
                    new_version=args.new_version,
                    threads=args.threads,
                    memory_gb=args.memory_gb,
                    gpus=args.gpus,
                )
            )
        elif args.command == "repair-validate":
            _emit(
                SmallScaleValidator(project).validate_repair(
                    args.regression_manifest,
                    timeout_seconds=args.timeout,
                    threads=args.threads,
                    memory_gb=args.memory_gb,
                    gpus=args.gpus,
                )
            )
        elif args.command == "freeze":
            _emit(
                PipelineFreezer(project).freeze(
                    validation_report_path=args.validation_report,
                    new_version=args.new_version,
                )
            )
        elif args.command == "finalize":
            if project.plan_path.is_file():
                from microbiome.pipeline.finalizer import ValidationFinalizer

                _emit(
                    ValidationFinalizer(project).finalize_pretest(
                        validation_report_path=args.validation_report,
                        new_version=args.new_version,
                    )
                )
            else:
                # Ledger-first path: build the pipeline from verified execution
                # facts; every management artifact is auto-backfilled.
                from microbiome.pipeline.synthesize import finalize_successful_pretest

                config = project.load_config() if project.config_path.is_file() else {}
                paths = config.get("paths", {})
                _emit(
                    finalize_successful_pretest(
                        project.root,
                        raw_root=paths.get("raw_data") or os.environ.get("MICROBIOME_DATA_DIR"),
                        db_root=paths.get("database") or os.environ.get("MICROBIOME_DB_ROOT"),
                    )
                )
        elif args.command == "recover-pretest":
            from microbiome.pipeline.migrate import recover_legacy_pretest

            _emit(recover_legacy_pretest(args.root or project.root))
        elif args.command == "preflight":
            _emit(
                FrozenPipelineExecutor(project).preflight(
                    _key_values(args.input),
                    sample_id=args.sample_id,
                    run_id=args.run_id,
                    threads=args.threads,
                    memory_gb=args.memory_gb,
                    gpus=args.gpus,
                )
            )
        elif args.command == "run":
            _emit(
                FrozenPipelineExecutor(project).execute(
                    _key_values(args.input),
                    sample_id=args.sample_id,
                    run_id=args.run_id,
                    threads=args.threads,
                    memory_gb=args.memory_gb,
                    gpus=args.gpus,
                    timeout_seconds=args.timeout,
                    resume=args.resume,
                )
            )
        elif args.command == "status":
            _emit(_status(project))
        return 0
    except (PipelineError, OSError, ValueError) as exc:
        print(f"microbiome-pipeline: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
