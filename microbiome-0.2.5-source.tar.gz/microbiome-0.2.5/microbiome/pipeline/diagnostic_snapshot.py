"""Bounded, read-only operator facts from fixed project control records.

This is a display projection, not an authorization or a new filesystem reader.
No path supplied inside a diagnostic is followed, and no resource discovery or
model request is performed. Detailed evidence stays in existing bounded readers.
"""
from __future__ import annotations

import json

import yaml

from microbiome.pipeline.errors import ConfigurationError
from microbiome.pipeline.io import object_fingerprint

MAX_SNAPSHOT_BYTES = 16 * 1024
MAX_RECORD_BYTES = 1024 * 1024


def _record(path, evidence, issues):
    from microbiome.pipeline.maintenance import _read_bytes

    descriptor = {"path": str(path), "available": path.exists() or path.is_symlink()}
    evidence.append(descriptor)
    if not descriptor["available"]:
        return {}
    try:
        raw = _read_bytes(path, limit=MAX_RECORD_BYTES)
        value = json.loads(raw) if path.suffix == ".json" else yaml.safe_load(raw)
        if not isinstance(value, dict):
            raise ValueError("Expected an object")
        descriptor["snapshot"] = object_fingerprint(value)
        return value
    except (ConfigurationError, OSError, ValueError, UnicodeError, yaml.YAMLError) as exc:
        descriptor["status"] = "UNREADABLE_OR_OVERSIZED"
        issues.append({"path": str(path), "code": type(exc).__name__})
        return {}


def input_status_snapshot(project, conversation):
    """One bounded projection of authoritative records, never a confirmation.

    Conversation selection is a resolution cache and may be absent for external
    or derived adapters. It cannot supersede a persisted manifest/confirmation.
    This inspects record seals only; it does not recheck raw file contents.
    """
    from microbiome.pipeline.input_commit import _requirements_match

    evidence, issues = [], []
    requirements = _record(project.requirements_path, evidence, issues)
    manifest = _record(project.requirements_dir / "input_manifest.yaml", evidence, issues)
    requirements_valid = bool(requirements and isinstance(requirements.get("confirmed_fields"), dict)
        and isinstance(requirements.get("input"), dict)
        and requirements.get("requirements_fingerprint") == object_fingerprint(
            {k: v for k, v in requirements.items() if k != "requirements_fingerprint"}))
    manifest_valid = bool(manifest and isinstance(manifest.get("samples"), list)
        and all(isinstance(row, dict) for row in manifest["samples"])
        and manifest.get("manifest_fingerprint") == object_fingerprint(
            {k: v for k, v in manifest.items() if k != "manifest_fingerprint"}))
    if requirements and not requirements_valid:
        issues.append({"code": "REQUIREMENTS_FINGERPRINT_INVALID"})
    if manifest and not manifest_valid:
        issues.append({"code": "INPUT_MANIFEST_FINGERPRINT_INVALID"})
    matched = bool(requirements_valid and manifest_valid and _requirements_match(requirements, manifest))
    confirmed = matched and manifest.get("resolution_status") == "CONFIRMED"
    if not evidence[1]["available"]:
        status = "MISSING_MANIFEST"
    elif not manifest_valid:
        status = "INVALID_MANIFEST"
    elif confirmed:
        status = "CONFIRMED"
    elif requirements_valid and requirements["confirmed_fields"].get("input") is True and not matched:
        status = "CONFIRMATION_MISMATCH"
    else:
        status = "UNCONFIRMED"
    ledger = conversation.get("input_declarations") or {}
    state = {
        "source": "persisted_input_manifest", "declaration_revision": ledger.get("revision", 0),
        "validation_status": "UNRESOLVED" if conversation.get("input_error") else status,
        "persisted_validation_status": status, "input_confirmed": bool(confirmed),
        "manifest_verified": manifest_valid, "requirements_verified": requirements_valid,
        "confirmation_matches_manifest": matched,
        "sample_count": len(manifest["samples"]) if manifest_valid else None,
        "input_kind": manifest.get("input_kind", "raw_sequences") if manifest_valid else None,
        "details": {"operation": "read_artifact", "arguments": {"root": "project", "path": "requirements/input_manifest.yaml"}},
        "confirmation_details": {"operation": "read_artifact", "arguments": {"root": "project", "path": "requirements/requirements.yaml"}},
        "verification_scope": "Persisted record fingerprints and confirmation binding only; no fresh input-file verification.",
    }
    return {"state": state, "requirements": requirements, "manifest": manifest,
            "rows": manifest["samples"] if manifest_valid else [], "evidence": evidence, "issues": issues}


def diagnostic_snapshot(project, *, conversation, policy, recovery, descriptors, input_snapshot=None):
    from microbiome.pipeline.maintenance import _redact
    from microbiome.pipeline.planning_policy import inspect_policy

    inputs = input_snapshot if input_snapshot is not None else input_status_snapshot(project, conversation)
    evidence, issues, truncated = list(inputs["evidence"]), list(inputs["issues"]), []

    def record(path):
        return _record(path, evidence, issues)

    def select(value, keys):
        return {key: value[key] for key in keys if key in value} if isinstance(value, dict) else {}

    requirements, manifest = inputs["requirements"], inputs["manifest"]
    host = record(project.state_dir / "host_model_profile.json")
    measured = record(project.state_dir / "last_host_budget.json")
    requirements_valid = inputs["state"]["requirements_verified"]
    manifest_valid = inputs["state"]["manifest_verified"]
    try:
        budget = inspect_policy(project)
        budget.pop("changes", None)
    except ConfigurationError as exc:
        budget = {"available": False, "error": str(exc), "can_adjust": False}
    matches_policy = bool(measured and measured.get("policy_fingerprint") == budget.get("policy_fingerprint"))
    host_missing = [] if host.get("context_window_tokens") else ["verified_context_window_tokens"]
    blocker = conversation.get("last_workflow_blocker") or {}
    if not isinstance(blocker, dict):
        blocker = {}
    if conversation.get("input_error"):
        blocker = conversation.get("input_blocker") or {"code": "INPUT_UNRESOLVED", "category": "LOCAL_INPUT"}
    elif isinstance(conversation.get("compiler_repair"), dict) and conversation["compiler_repair"]:
        blocker = conversation["compiler_repair"].get("blocker") or {"code": "CANDIDATE_FORMAT_INVALID", "category": "INTERNAL_PLAN_COMPILATION"}
    elif matches_policy and measured.get("fits") is False:
        blocker = {"code": "MODEL_CONTEXT_LIMIT", "category": "PLANNING_POLICY"}

    next_action = {"owner": "controller", "action": "continue_current_stage", "reason": "No current blocker is recorded; follow the current phase and existing approvals."}
    phase_actions = {
        "PATH_CONFIRMATION": {"owner": "user", "action": "review_path_bindings"},
        "PLAN_CONFIRMATION": {"owner": "user", "action": "review_current_plan"},
        "AWAITING_PRODUCTION_APPROVAL": {"owner": "user", "action": "review_frozen_production_contract"},
        "COMPLETED": {"owner": "controller", "action": "present_validated_reports"},
    }
    next_action = phase_actions.get(policy["phase"], next_action)
    if policy["active_jobs"]:
        next_action = {"owner": "controller", "action": "query_active_task", "job_ids": policy["active_jobs"]}
    elif blocker:
        if blocker.get("requires_user_information"):
            next_action = {"owner": "user", "action": "resolve_recorded_missing_information", "reason": "Use the recorded questions or concrete input candidates; preserve already confirmed facts."}
        elif blocker.get("code") in {"MODEL_CONTEXT_LIMIT", "HOST_MODEL_CAPACITY_UNKNOWN", "MODEL_CAPACITY_UNKNOWN"} and host_missing:
            next_action = {"owner": "host_adapter", "action": "resolve_model_capacity",
                           "reason": "Read actual host model metadata and persist a verified capacity profile; changing evidence budgets alone cannot repair missing host capacity."}
        elif blocker.get("category") == "PLANNING_POLICY":
            next_action = {"owner": "controller", "tool": "microbiome_maintenance", "operation": "planning_policy",
                           "arguments": {"action": "estimate"}, "reason": "Inspect the measured request and allowed technical limits before a bounded adjustment."}
        elif conversation.get("input_error"):
            next_action = {"owner": "controller", "tool": "microbiome_maintenance", "operation": "repair_input",
                           "reason": "Repair the explicit input declaration using the recorded candidates; do not reinterpret the goal or invent remote acquisition."}
        elif recovery.get("available"):
            next_action = {"owner": "controller", "tool": "microbiome_resume_planning", "recovery_token_source": "planning_recovery.recovery_token",
                           "reason": "Resume the persisted task at its recorded checkpoint."}
        else:
            next_action = {"owner": "controller", "action": "change_failed_condition_before_retry",
                           "reason": recovery.get("reason"), "supported_repair": blocker.get("supported_repair")}
    elif conversation.get("pending_questions"):
        next_action = {"owner": "user", "action": "answer_recorded_questions", "questions": conversation["pending_questions"]}
    goal = conversation.get("goal_contract") or {}
    confirmed = requirements.get("confirmed_fields", {}) if requirements_valid else {}
    confirmed = confirmed if isinstance(confirmed, dict) else {}
    payload = {
        "schema_version": 1, "read_only": True,
        "boundary": "Fixed project control records only; no raw file contents, credentials, environment enumeration, resource discovery or execution authorization. Persisted confirmation is not a fresh file-integrity check.",
        "current_blocker": select(blocker, ("code", "category", "recoverable", "requires_user_information", "condition_fingerprint", "fingerprint", "checkpoint", "candidate_available")) or None,
        "completed_repairs": {"historical_resolved_diagnostics": [key for key, row in descriptors.items() if row.get("status") in {"RESOLVED", "HISTORICAL_RESOLVED"}],
                              "technical_adjustments": budget.get("technical_adjustments", 0)},
        "effective_facts": {"phase": policy["phase"], "frozen_contract": policy["frozen_contract"],
                            "requirements_verified": requirements_valid, "confirmed_fields": confirmed,
                            "manifest_verified": manifest_valid, "input_confirmed": inputs["state"]["input_confirmed"],
                            "candidate_available": bool(recovery.get("candidate_available")), "checkpoint": recovery.get("checkpoint")},
        "input": select(manifest, ("input_kind", "resolution_status", "manifest_fingerprint", "pilot_mode", "requires_raw_data_download")) if manifest_valid else {},
        "input_state": inputs["state"],
        "requirements": {"version": requirements.get("requirements_version"), "target": requirements.get("target") if confirmed.get("target") else None,
                         "dataset": requirements.get("dataset") if confirmed.get("dataset") else None,
                         "analysis_goal": requirements.get("analysis_goal") if confirmed.get("analysis_goal") else None,
                         "unresolved_questions": requirements.get("unresolved_questions", [])},
        "goal": select(goal, ("fingerprint", "accepted_scope", "required_outputs")),
        "budget": budget,
        "host_capabilities": {"profile": select(host, ("provider", "model", "source", "profile_kind", "context_window_tokens", "output_reserve_tokens")), "missing": host_missing},
        "last_request": {**select(measured, ("fits", "capacity_source", "context_window_tokens", "project_context_window_tokens", "estimated_input_tokens", "output_reserve_tokens", "reserved_tokens", "protocol_margin_tokens", "token_count_method", "model_request_dispatched")), "matches_current_policy": matches_policy},
        "call_observation": {"backend_planning": conversation.get("planning_ledger"), "host_outer_model": "Not counted by the backend planning ledger; use host session usage events."},
        "allowed_repair_scope": "Bounded evidence/guidance/history policy, explicit input declarations, owned drafts and scratch; no model route, fee ceiling, input contents, READY resources, approvals or frozen locks.",
        "next_action": next_action, "evidence": evidence, "issues": issues,
    }
    if manifest_valid:
        payload["input"]["record_group_count"] = len(manifest["samples"]) if isinstance(manifest.get("samples"), list) else None

    def compact(value, location="$", depth=0):
        if isinstance(value, str) and len(value.encode("utf-8")) > 1200:
            truncated.append(location)
            return value.encode("utf-8")[:1200].decode("utf-8", errors="ignore") + "…"
        if depth > 7:
            truncated.append(location)
            return "[detail omitted]"
        if isinstance(value, dict):
            if len(value) > 32:
                truncated.append(location)
            return {str(key)[:120]: compact(item, location + "." + str(key)[:120], depth + 1) for key, item in list(value.items())[:32]}
        if isinstance(value, list):
            if len(value) > 12:
                truncated.append(location)
            return [compact(item, f"{location}[{i}]", depth + 1) for i, item in enumerate(value[:12])]
        return value

    def redact(value):
        if isinstance(value, dict):
            # These numeric capacity measurements are not credentials. Keep
            # the normal secret-key policy for all other nested project text.
            metrics = {"context_window_tokens", "project_context_window_tokens", "project_context_limit_tokens", "output_reserve_tokens",
                       "estimated_input_tokens", "protocol_margin_tokens", "reserved_tokens"}
            return {key: item if key in metrics and (type(item) is int or item is None) else
                    "[REDACTED]" if _redact({key: None})[key] == "[REDACTED]" else redact(item)
                    for key, item in value.items()}
        if isinstance(value, list):
            return [redact(item) for item in value]
        return _redact(value)

    # Redact before truncation so a cut cannot split and expose a credential.
    payload = compact(redact(payload))
    if isinstance(payload.get("next_action"), dict) and next_action.get("recovery_token_source"):
        payload["next_action"]["recovery_token_source"] = "planning_recovery.recovery_token"
    for key in ("requirements", "goal", "evidence", "budget", "completed_repairs"):
        if len(json.dumps(payload, ensure_ascii=False).encode("utf-8")) <= MAX_SNAPSHOT_BYTES - 1024:
            break
        payload[key] = {"detail_omitted": True}
        truncated.append("$." + key)
    payload["limits"] = {"max_bytes": MAX_SNAPSHOT_BYTES, "record_max_bytes": MAX_RECORD_BYTES,
                         "truncated": bool(truncated), "truncated_fields": truncated[:20]}
    if len(json.dumps(payload, ensure_ascii=False).encode("utf-8")) > MAX_SNAPSHOT_BYTES:
        # Hostile or unexpectedly verbose control records must never defeat
        # the advertised output ceiling or hide which detail was omitted.
        for key in tuple(payload):
            if key not in {"schema_version", "read_only", "boundary", "current_blocker", "effective_facts", "next_action", "limits"}:
                payload.pop(key)
        payload["current_blocker"] = {key: value[:160] if isinstance(value, str) else value
                                      for key, value in (payload.get("current_blocker") or {}).items()
                                      if isinstance(value, (str, bool, int))}
        payload["effective_facts"] = {key: value[:160] if isinstance(value, str) else value
                                      for key, value in payload["effective_facts"].items()
                                      if isinstance(value, (str, bool, int))}
        payload["next_action"] = {"owner": "controller", "action": "read_bounded_diagnostic", "reason": "Oversized details omitted; use existing read_diagnostic or read_artifact pagination."}
        payload["limits"].update(truncated=True, truncated_fields=["$ (oversized control-record details)"])
    return payload
