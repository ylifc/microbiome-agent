"""Append-only, machine-readable execution ledger for pre-test/production facts.

Every real command execution during a pre-test is recorded immediately as one
JSON line in ``OUTPUT_ROOT/pre_test_run/pipeline/execution_ledger.jsonl``. The
ledger is the only factual source a freeze may be built from: Markdown
playbooks, chat logs, and free-text summaries are never lock-eligible.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shlex
import shutil
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from microbiome.pipeline.io import canonical_path

if TYPE_CHECKING:
    from microbiome.pipeline.project import PipelineProject

SCHEMA_VERSION = 1

_PATH_TOKEN_RE = re.compile(r"(?<![\w./-])(/[^\s\"'`<>|;&()]+)")
_CONDA_RUN_RE = re.compile(
    r"\bconda\s+run\s+(?:--no-capture-output\s+)?(?:-n\s+(?P<name>\S+)|-p\s+(?P<prefix>\S+))"
)


def _utcnow() -> str:
    return datetime.now(UTC).isoformat()


def _inside(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def infer_command_facts(
    code: str,
    *,
    raw_root: str | os.PathLike[str] | None = None,
    db_root: str | os.PathLike[str] | None = None,
    output_root: str | os.PathLike[str] | None = None,
) -> dict[str, Any]:
    """Extract only verifiable facts from an executed code payload.

    Nothing is guessed: tool executables are resolved on PATH, paths are only
    recorded when they exist on disk, and the conda environment is reported
    exactly as invoked. Fields that cannot be verified stay ``None``/empty.
    """
    text = (code or "").strip()
    lowered = text.lower()
    if lowered.startswith("#!r") or lowered.startswith("# r code") or lowered.startswith("# r script"):
        kind = "r"
    elif (
        lowered.startswith("#!bash")
        or lowered.startswith("# bash")
        or lowered.startswith("#!cli")
        or re.match(r"#![^\n]*\b(?:ba)?sh\b", lowered)
    ):
        # Also recognize standard shebangs (#!/bin/bash, #!/usr/bin/env bash,
        # #!/bin/sh) that local models emit instead of the #!BASH marker.
        kind = "bash"
    else:
        kind = "python"

    conda_env = None
    conda_prefix = None
    executable = None
    tool_name = None
    if kind in {"bash", "r"}:
        for line in text.splitlines():
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            conda = _CONDA_RUN_RE.search(stripped)
            if conda:
                conda_env = conda.group("name")
                conda_prefix = conda.group("prefix")
                remainder = stripped[conda.end() :].strip()
            else:
                remainder = stripped
            try:
                tokens = shlex.split(remainder, posix=True)
            except ValueError:
                tokens = remainder.split()
            token = next((item for item in tokens if item and not item.startswith("-")), None)
            if token:
                tool_name = Path(token).name
                resolved = token if Path(token).is_absolute() else shutil.which(token)
                executable = str(canonical_path(resolved)) if resolved and Path(resolved).exists() else None
            break

    candidates = [token for token in _PATH_TOKEN_RE.findall(text) if len(token) > 1]
    raw = canonical_path(raw_root) if raw_root else None
    db = canonical_path(db_root) if db_root else None
    out = canonical_path(output_root) if output_root else None
    inputs: list[str] = []
    outputs: list[str] = []
    databases: list[str] = []
    for token in candidates:
        path = Path(token)
        if not path.is_absolute():
            continue
        try:
            resolved = canonical_path(path, must_exist=True)
        except (OSError, RuntimeError):
            continue
        if resolved.is_dir():
            continue
        value = str(resolved)
        if db and _inside(resolved, db):
            databases.append(value)
        elif out and _inside(resolved, out):
            # Role precedence matters when OUTPUT_PATH is nested below
            # RAW_DATA_PATH: generated/pilot files are outputs, never raw
            # sources merely because the broader raw root contains them.
            outputs.append(value)
        elif raw and _inside(resolved, raw):
            inputs.append(value)

    # Relative / bare filenames: local models frequently reference inputs and
    # outputs by basename or relative path. Resolve filename-like tokens against
    # the known roots so lineage is still captured — but only when the file
    # actually exists, which makes a false positive effectively impossible.
    for token in re.split(r"[\s;|&]+", text):
        token = token.strip().strip("'\"`")
        if not token or token.startswith("-") or token.startswith(("/", "http://", "https://")):
            continue
        if "." not in token or len(token) <= 2:
            continue
        for root_value, bucket in ((db, "db"), (out, "out"), (raw, "raw")):
            if not root_value:
                continue
            candidate = Path(root_value) / token
            try:
                if not candidate.is_file():
                    continue
                resolved = canonical_path(candidate, must_exist=True)
            except (OSError, RuntimeError):
                continue
            if resolved.is_dir():
                continue
            if bucket == "db":
                databases.append(str(resolved))
            elif bucket == "out":
                outputs.append(str(resolved))
            else:
                inputs.append(str(resolved))
            break
    return {
        "kind": kind,
        "tool_name": tool_name,
        "executable": executable,
        "conda_env": conda_env,
        "conda_prefix": conda_prefix,
        "inputs": sorted(set(inputs)),
        "outputs": sorted(set(outputs)),
        "database_resources": sorted(set(databases)),
    }


class ExecutionLedger:
    """Structured, append-only facts about every real pre-test command execution."""

    def __init__(self, path: str | Path):
        self.path = canonical_path(path)

    @classmethod
    def for_project(cls, project: PipelineProject) -> ExecutionLedger:
        return cls(project.pretest_dir / "pipeline" / "execution_ledger.jsonl")

    def record(
        self,
        *,
        phase: str,
        source: str,
        status: str,
        step_id: str | None = None,
        attempt: int | None = None,
        tool: dict[str, Any] | None = None,
        environment: dict[str, Any] | None = None,
        command: dict[str, Any] | None = None,
        inputs: list[str] | None = None,
        outputs: list[str] | None = None,
        database_resources: list[dict[str, Any]] | list[str] | None = None,
        parameters: dict[str, Any] | None = None,
        exit_code: int | None = None,
        output_validation: dict[str, Any] | None = None,
        error_excerpt: str = "",
        verified: bool | None = None,
        extra: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Append one execution fact immediately (append + fsync, no buffering)."""
        if status not in {"PASSED", "FAILED", "UNKNOWN"}:
            raise ValueError(f"ledger status must be PASSED/FAILED/UNKNOWN, got {status!r}")
        key = step_id or "unattributed"
        if attempt is None:
            attempt = sum(1 for entry in self.entries() if entry.get("step_id") == key) + 1
        record = {
            "schema_version": SCHEMA_VERSION,
            "record_id": uuid.uuid4().hex,
            "recorded_at": _utcnow(),
            "phase": phase,
            "source": source,
            "step_id": key,
            "attempt": attempt,
            "status": status,
            "tool": dict(tool or {"name": None, "version": None, "executable": None}),
            "environment": dict(environment or {"conda_prefix": None, "conda_env": None}),
            "command": dict(command or {}),
            "inputs": list(inputs or []),
            "outputs": list(outputs or []),
            "database_resources": list(database_resources or []),
            "parameters": dict(parameters or {}),
            "exit_code": exit_code,
            "output_validation": dict(output_validation or {"passed": status == "PASSED", "detail": ""}),
            "error_excerpt": (error_excerpt or "")[-500:],
            # A record is lock-eligible only when it reflects a real, verified execution.
            "verified": (status == "PASSED") if verified is None else bool(verified),
        }
        if extra:
            record.update(extra)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        line = json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n"
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(line)
            handle.flush()
            os.fsync(handle.fileno())
        return record

    def entries(self) -> list[dict[str, Any]]:
        if not self.path.is_file():
            return []
        records = []
        with self.path.open(encoding="utf-8") as handle:
            for line in handle:
                text = line.strip()
                if not text:
                    continue
                try:
                    value = json.loads(text)
                except json.JSONDecodeError:
                    continue
                if isinstance(value, dict):
                    records.append(value)
        return records

    def final_successful_attempts(self) -> list[dict[str, Any]]:
        """Return the last PASSED, verified attempt per step, in first-seen order."""
        chosen: dict[str, dict[str, Any]] = {}
        order: list[str] = []
        seen: set[str] = set()
        for entry in self.entries():
            key = str(entry.get("step_id") or "unattributed")
            if key not in seen:
                seen.add(key)
                order.append(key)
            if entry.get("status") == "PASSED" and entry.get("verified"):
                chosen[key] = entry
        return [chosen[key] for key in order if key in chosen]

    def digest(self) -> str | None:
        if not self.path.is_file():
            return None
        return hashlib.sha256(self.path.read_bytes()).hexdigest()
