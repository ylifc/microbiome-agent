"""Typed errors used to stop unsafe phase transitions."""

from enum import StrEnum


class InputErrorCategory(StrEnum):
    """Machine-readable input/error classification for production dispatch.

    Each category has a distinct recovery policy; a binding error is a file
    management issue and must never trigger re-running the bioinformatics
    pre-test.
    """

    INPUT_MANIFEST_MISSING = "INPUT_MANIFEST_MISSING"
    INPUT_FILE_MISSING = "INPUT_FILE_MISSING"
    INPUT_BINDING_ERROR = "INPUT_BINDING_ERROR"
    TOOL_BINDING_ERROR = "TOOL_BINDING_ERROR"
    DATABASE_BINDING_ERROR = "DATABASE_BINDING_ERROR"
    PIPELINE_VALIDATION_ERROR = "PIPELINE_VALIDATION_ERROR"


class FinalizationFailureCategory(StrEnum):
    """Recovery policy for failures after a successful pre-test.

    Management-state failures are repaired and finalized again without
    executing scientific steps.  Only categories that prove the scientific
    execution itself was never validated may send the lifecycle back to a
    pre-test.
    """

    PATH_CONFIGURATION_ERROR = "PATH_CONFIGURATION_ERROR"
    MANIFEST_ERROR = "MANIFEST_ERROR"
    METADATA_ERROR = "METADATA_ERROR"
    STATE_ERROR = "STATE_ERROR"
    INPUT_BINDING_ERROR = "INPUT_BINDING_ERROR"
    SOFTWARE_VALIDATION_ERROR = "SOFTWARE_VALIDATION_ERROR"
    DATABASE_VALIDATION_ERROR = "DATABASE_VALIDATION_ERROR"
    SCIENTIFIC_PARAMETER_ERROR = "SCIENTIFIC_PARAMETER_ERROR"
    PIPELINE_VALIDATION_ERROR = "PIPELINE_VALIDATION_ERROR"

    @property
    def requires_pretest(self) -> bool:
        return self in {
            FinalizationFailureCategory.SOFTWARE_VALIDATION_ERROR,
            FinalizationFailureCategory.DATABASE_VALIDATION_ERROR,
            FinalizationFailureCategory.SCIENTIFIC_PARAMETER_ERROR,
            FinalizationFailureCategory.PIPELINE_VALIDATION_ERROR,
        }


class PipelineError(RuntimeError):
    """Base error for the deterministic pipeline subsystem."""


class ConfigurationError(PipelineError):
    """A project or experiment plan is invalid."""


class ResourceNotReadyError(PipelineError):
    """A tool, environment, database, or input has not passed validation."""


class FreezeError(PipelineError):
    """A pipeline cannot be frozen from the current validation state."""


class PreflightError(PipelineError):
    """Production replay was stopped because validated state drifted."""


class ExecutionError(PipelineError):
    """A frozen production node failed or its outputs did not validate."""


class LockValidationError(PipelineError):
    """A written pipeline lock failed schema or fingerprint validation."""


class FinalizationError(PipelineError):
    """A passed pre-test could not be finalized into a ready production pipeline."""

    def __init__(
        self,
        message: str,
        *,
        missing_artifacts: list[str] | None = None,
        category: FinalizationFailureCategory = FinalizationFailureCategory.METADATA_ERROR,
    ):
        super().__init__(message)
        self.missing_artifacts = list(missing_artifacts or [])
        self.category = category

    @property
    def requires_pretest(self) -> bool:
        return self.category.requires_pretest


class ExecutionFactMissingError(FinalizationError):
    """A blocking execution fact (not a metadata file) could not be determined.

    Only these stop production: unknown RAW_DATA_PATH, unknown final successful
    command/executable/parameters/database for a step, a step that never passed,
    unverified key outputs, or an input binding that cannot target the full data.
    The message must name the exact step and fact — never a YAML filename.
    """

    def __init__(self, message: str, *, step_id: str | None = None, fact: str | None = None):
        category = _execution_fact_category(fact)
        super().__init__(
            message,
            missing_artifacts=[fact] if fact else [],
            category=category,
        )
        self.step_id = step_id
        self.fact = fact


def _execution_fact_category(fact: str | None) -> FinalizationFailureCategory:
    normalized = str(fact or "").casefold()
    if any(token in normalized for token in ("raw_data", "path_configuration")):
        return FinalizationFailureCategory.PATH_CONFIGURATION_ERROR
    if any(token in normalized for token in ("input", "binding")):
        return FinalizationFailureCategory.INPUT_BINDING_ERROR
    if any(token in normalized for token in ("database", "index")):
        return FinalizationFailureCategory.DATABASE_VALIDATION_ERROR
    if any(token in normalized for token in ("parameter", "argument")):
        return FinalizationFailureCategory.SCIENTIFIC_PARAMETER_ERROR
    if any(token in normalized for token in ("executable", "interpreter", "environment", "software", "tool")):
        return FinalizationFailureCategory.SOFTWARE_VALIDATION_ERROR
    return FinalizationFailureCategory.PIPELINE_VALIDATION_ERROR


def classify_finalization_failure(error: BaseException) -> FinalizationFailureCategory:
    """Classify arbitrary finalization failures conservatively and repeatably."""
    if isinstance(error, FinalizationError):
        return error.category
    text = str(error).casefold()
    if any(token in text for token in ("validated executable", "environment prefix", "could not verify executable")):
        return FinalizationFailureCategory.SOFTWARE_VALIDATION_ERROR
    if any(token in text for token in ("validated database", "database drift", "database resource")):
        return FinalizationFailureCategory.DATABASE_VALIDATION_ERROR
    if any(token in text for token in ("scientific parameter", "parameter drift")):
        return FinalizationFailureCategory.SCIENTIFIC_PARAMETER_ERROR
    if any(token in text for token in ("no verified attempt", "execution ledger", "requirements changed")):
        return FinalizationFailureCategory.PIPELINE_VALIDATION_ERROR
    if "path_configuration_error" in text or any(
        token in text for token in ("output_path", "paths must", "path roles")
    ):
        return FinalizationFailureCategory.PATH_CONFIGURATION_ERROR
    if "raw_data_path" in text or (
        "input" in text and any(token in text for token in ("bind", "manifest", "raw", "missing", "outside"))
    ):
        return FinalizationFailureCategory.INPUT_BINDING_ERROR
    if any(token in text for token in ("state_fingerprint", "lifecycle state", "project_state")):
        return FinalizationFailureCategory.STATE_ERROR
    if any(token in text for token in ("pipeline.lock", "manifest_fingerprint", "lock fingerprint")):
        return FinalizationFailureCategory.MANIFEST_ERROR
    # Unknown errors during Freeze/Finalize are management errors by default.
    # They must not discard a verified pre-test or silently execute it again.
    return FinalizationFailureCategory.METADATA_ERROR
