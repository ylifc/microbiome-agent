"""Finalize a passed pre-test into a validated, ready-to-approve frozen pipeline.

This is the single bridge between the legacy pilot state ("小试 PASS") and the
strict production state (a validated ``pipeline.lock.yaml``). It runs
automatically at the end of a successful pre-test — never at user-confirmation
time — and only when it succeeds may the lifecycle enter
``AWAITING_PRODUCTION_APPROVAL`` and the user be asked about full execution.
"""

from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import TYPE_CHECKING, Any

from microbiome.pipeline.errors import (
    FinalizationError,
    FinalizationFailureCategory,
    PipelineError,
    classify_finalization_failure,
)
from microbiome.pipeline.io import read_json, read_yaml
from microbiome.pipeline.ledger import ExecutionLedger
from microbiome.pipeline.lock_schema import validate_pipeline_lock
from microbiome.pipeline.readiness import ProductionReadinessChecker, load_current_readiness
from microbiome.pipeline.state import LifecycleState, ProjectStateMachine

if TYPE_CHECKING:
    from microbiome.pipeline.project import PipelineProject


class ValidationFinalizer:
    """Orchestrate Freeze → lock reload/validate → readiness → approval gate."""

    def __init__(self, project: PipelineProject):
        self.project = project

    def finalize_pretest(
        self,
        *,
        validation_report_path: str | Path | None = None,
        new_version: bool = False,
    ) -> dict[str, Any]:
        """Freeze the passed pre-test and prove production readiness.

        Returns the readiness report. Raises :class:`FinalizationError` — with
        the exact missing/invalid artifacts — whenever any step fails, leaving
        the lifecycle in ``PRETEST_FINALIZATION_FAILED`` so the approval
        question cannot be asked.
        """
        machine = ProjectStateMachine(self.project)
        current = machine.current
        if current == LifecycleState.AWAITING_PRODUCTION_APPROVAL:
            # Idempotent: the gate is already open; prove readiness is still current.
            pipeline = read_yaml(self.project.pipeline_lock_path)
            try:
                return load_current_readiness(self.project, pipeline)
            except PipelineError as exc:
                raise FinalizationError(str(exc)) from exc
        if current not in {
            LifecycleState.PRETEST_PASSED,
            LifecycleState.VALIDATED,
            LifecycleState.PRETEST_FINALIZATION_FAILED,
        }:
            raise FinalizationError(
                f"cannot finalize a pre-test from lifecycle state {current.value}; "
                "a passed pre-test (PRETEST_PASSED) is required first"
            )
        machine.transition(
            LifecycleState.PRETEST_FINALIZING,
            reason="pre-test passed; finalizing production manifests from executed records",
        )
        try:
            if new_version and validation_report_path is None:
                # Revision pilots deliberately preserve the current immutable
                # validation report. Select the new passed suite's report,
                # rather than accidentally reusing the parent version.
                from microbiome.pipeline.io import object_fingerprint
                suite_path = self.project.pipeline_dir / "validation_suite.json"
                plan = read_yaml(self.project.plan_path)
                if suite_path.is_file():
                    suite = read_json(suite_path)
                    if (suite.get("status") != "PASSED" or not suite.get("cases")
                            or suite.get("plan_fingerprint") != plan["plan_fingerprint"]
                            or suite.get("suite_fingerprint") != object_fingerprint(
                                {k: v for k, v in suite.items() if k != "suite_fingerprint"})):
                        raise FinalizationError("new-version validation suite is missing, stale or invalid")
                    report = (self.project.pretest_dir / suite["cases"][-1]["validation_id"] /
                              "reports" / "validation_report.json").resolve()
                    if not report.is_relative_to(self.project.pretest_dir.resolve()):
                        raise FinalizationError("new-version validation report escaped pretest directory")
                    validation_report_path = report
            self._ensure_ledger(validation_report_path)
            # Management artifacts are representations of execution facts: any
            # that are missing are auto-backfilled from the verified ledger —
            # their absence never blocks a genuinely successful pre-test.
            from microbiome.pipeline.freeze import PipelineFreezer
            from microbiome.pipeline.synthesize import backfill_management_artifacts

            backfill_management_artifacts(self.project)
            lock = PipelineFreezer(self.project).freeze(
                validation_report_path=validation_report_path,
                new_version=new_version,
            )
            if machine.current == LifecycleState.PRETEST_FINALIZING:
                machine.transition(
                    LifecycleState.FROZEN,
                    reason="existing immutable pipeline lock was reused",
                )
            machine.transition(
                LifecycleState.PIPELINE_LOCK_VALIDATING,
                reason="reloading and validating the written pipeline lock",
            )
            reloaded = validate_pipeline_lock(read_yaml(self.project.pipeline_lock_path))
            if reloaded.get("pipeline_hash") != lock.get("pipeline_hash"):
                raise FinalizationError("reloaded pipeline lock does not match the frozen lock")
            readiness = ProductionReadinessChecker(self.project).check()
            if not readiness.get("ready"):
                missing = readiness.get("missing_artifacts", [])
                raise FinalizationError(
                    "production readiness check failed; the approval question stays closed",
                    missing_artifacts=missing,
                    category=self._readiness_failure_category(missing),
                )
        except FinalizationError as exc:
            self._fail(machine, exc)
        except PipelineError as exc:
            self._fail(
                machine,
                FinalizationError(str(exc), category=classify_finalization_failure(exc)),
            )
        machine.transition(
            LifecycleState.PRODUCTION_READY,
            reason="frozen pipeline lock passed schema, fingerprint, and readiness checks",
        )
        machine.transition(
            LifecycleState.AWAITING_PRODUCTION_APPROVAL,
            reason="production is provably ready; waiting for explicit user approval",
        )
        return readiness

    @staticmethod
    def _fail(machine: ProjectStateMachine, error: FinalizationError) -> None:
        machine.record_finalization_failure(error.category, detail=str(error))
        current = machine.current
        if current in {
            LifecycleState.PRETEST_FINALIZING,
            LifecycleState.FROZEN,
            LifecycleState.PIPELINE_LOCK_VALIDATING,
        }:
            machine.transition(
                LifecycleState.PRETEST_FINALIZATION_FAILED,
                reason=str(error)[:400],
            )
        raise error

    @staticmethod
    def _readiness_failure_category(missing: list[str]) -> FinalizationFailureCategory:
        text = " ".join(str(item) for item in missing).casefold()
        if "input_binding_error" in text or "input_binding" in text:
            return FinalizationFailureCategory.INPUT_BINDING_ERROR
        if "executable" in text or "environment" in text:
            return FinalizationFailureCategory.SOFTWARE_VALIDATION_ERROR
        if "database" in text or "index" in text:
            return FinalizationFailureCategory.DATABASE_VALIDATION_ERROR
        if "execution ledger" in text or "execution_ledger" in text or "output" in text:
            return FinalizationFailureCategory.PIPELINE_VALIDATION_ERROR
        if "state" in text:
            return FinalizationFailureCategory.STATE_ERROR
        return FinalizationFailureCategory.MANIFEST_ERROR

    def _ensure_ledger(self, validation_report_path: str | Path | None) -> None:
        """Guarantee the execution ledger reflects the verified validation.

        New pre-tests record the ledger natively during validation. Projects
        validated before the ledger existed get their fingerprint-verified
        validation report transcribed — verified facts only, never guesses.
        """
        ledger = ExecutionLedger.for_project(self.project)
        if ledger.final_successful_attempts():
            return
        candidates: list[Path] = []
        if validation_report_path:
            candidates.append(Path(validation_report_path))
        candidates.append(self.project.validation_report_path)
        for candidate in candidates:
            if not candidate.is_file():
                continue
            try:
                report = read_json(candidate)
            except (OSError, ValueError):
                continue
            if report.get("status") != "PASSED":
                continue
            from microbiome.pipeline.freeze import _verified_report
            from microbiome.pipeline.lifecycle import load_plan
            report = _verified_report(candidate, load_plan(self.project))
            for step in report.get("steps", []):
                executable = step.get("exact_executable_path")
                ledger.record(
                    phase="validation",
                    source="validation-report-transcription",
                    step_id=str(step.get("step_id") or "unknown"),
                    attempt=int(step.get("source_attempt") or 1),
                    status="PASSED",
                    tool={
                        "name": Path(str(executable)).name if executable else None,
                        "version": step.get("exact_software_version"),
                        "executable": executable,
                    },
                    environment={"conda_prefix": step.get("exact_environment"), "conda_env": None},
                    command={"kind": "argv", "argv": list(step.get("exact_command_line") or [])},
                    inputs=sorted(str(value) for value in (step.get("input_files") or {}).values()),
                    outputs=sorted(str(value) for value in (step.get("output_files") or {}).values()),
                    database_resources=[
                        {"alias": alias, "path": str(path)}
                        for alias, path in (step.get("exact_database_path") or {}).items()
                    ],
                    parameters={"declared": deepcopy(step.get("exact_parameters", []))},
                    exit_code=step.get("exit_code"),
                    output_validation={"passed": True, "detail": "transcribed from a fingerprint-verified validation report"},
                    verified=True,
                    extra={"validation_id": report.get("validation_id"),
                           "plan_fingerprint": report.get("plan_fingerprint"),
                           "requirements_version": report.get("requirements_version")},
                )
            return
