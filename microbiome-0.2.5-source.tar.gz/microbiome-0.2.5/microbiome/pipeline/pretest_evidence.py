"""Evidence-based pre-test validation: tell real, partial, and fake passes apart.

Only the evidence recorded here (subset files, subset manifest, execution
ledger process records, and output validation) may justify PRETEST_PASSED.
A playbook file or an execution-ledger file *existing* is never evidence that
a real pipeline ran.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

import yaml

if TYPE_CHECKING:
    from microbiome.pipeline.project import PipelineProject

FASTQ_SUFFIXES = (".fastq", ".fq", ".fastq.gz", ".fq.gz")
SUBSET_DIR_NAME = "input_subset"
LEDGER_NAME = "execution_ledger.jsonl"
MANIFEST_NAMES = ("source_mapping.yaml", "subset_manifest.yaml")

REAL_PASS = "REAL_PASS"
PARTIAL_PASS = "PARTIAL_PASS"
FALSE_PASS = "FALSE_PASS"


@dataclass
class PretestEvidence:
    classification: str
    checks: dict[str, bool] = field(default_factory=dict)
    details: list[str] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return self.classification == REAL_PASS

    @property
    def is_false_pass(self) -> bool:
        return self.classification == FALSE_PASS


def _is_fastq(path: Path) -> bool:
    return path.name.lower().endswith((*FASTQ_SUFFIXES, ".fasta", ".fa", ".fna", ".faa", ".fasta.gz", ".fa.gz", ".fna.gz"))


def _iter_ledger_paths(pretest_dir: Path) -> list[Path]:
    if not pretest_dir.is_dir():
        return []
    return sorted(path for path in pretest_dir.rglob(LEDGER_NAME) if path.is_file())


def _iter_subset_files(pretest_dir: Path) -> list[Path]:
    if not pretest_dir.is_dir():
        return []
    found: list[Path] = []
    for path in pretest_dir.rglob("*"):
        if path.is_file() and _is_fastq(path) and SUBSET_DIR_NAME in path.parts:
            found.append(path)
    return sorted(found)


def _load_subset_manifest(pretest_dir: Path) -> dict[str, Any] | None:
    if not pretest_dir.is_dir():
        return None
    for name in MANIFEST_NAMES:
        for path in pretest_dir.rglob(name):
            if path.is_file():
                try:
                    payload = yaml.safe_load(path.read_text(encoding="utf-8"))
                except (OSError, yaml.YAMLError):
                    continue
                if isinstance(payload, dict):
                    return payload
    return None


def _subset_paths(payload: dict[str, Any] | None) -> set[str]:
    if payload is None:
        return set()
    paths: set[str] = set()
    for sample in payload.get("samples", []) or []:
        if not isinstance(sample, dict):
            continue
        subset = sample.get("subset")
        if isinstance(subset, dict):
            for inner in subset.values():
                if isinstance(inner, str):
                    paths.add(str(Path(inner).resolve()))
    return paths


class PretestEvidenceValidator:
    """Audit the pre-test directory for real, partial, or fake execution evidence."""

    def __init__(self, project: PipelineProject):
        self.project = project
        self.pretest_dir = project.pretest_dir

    def classify(self) -> PretestEvidence:
        checks: dict[str, bool] = {}
        details: list[str] = []

        input_manifest = self.project.requirements_dir / "input_manifest.yaml"
        raw_root = (
            Path(self.project.load_config()["paths"]["raw_data"])
            if self.project.config_path.is_file()
            else Path(".")
        )
        sample_list = raw_root / "sample_list.txt"
        checks["input_manifest"] = input_manifest.is_file() or sample_list.is_file()
        if not checks["input_manifest"]:
            details.append("no input_manifest.yaml or sample_list.txt")

        subset_files = _iter_subset_files(self.pretest_dir)
        non_empty = [path for path in subset_files if path.stat().st_size > 0]
        checks["subset_files"] = bool(non_empty)
        if not non_empty:
            details.append(f"no non-empty subset FASTQ/FASTA under {self.pretest_dir}")

        subset_manifest = _load_subset_manifest(self.pretest_dir)
        checks["subset_manifest"] = subset_manifest is not None
        if subset_manifest is None:
            details.append("no source_mapping.yaml / subset_manifest.yaml")

        ledger_entries: list[dict[str, Any]] = []
        for ledger_path in _iter_ledger_paths(self.pretest_dir):
            try:
                from microbiome.pipeline.ledger import ExecutionLedger

                ledger_entries.extend(ExecutionLedger(ledger_path).entries())
            except Exception:
                continue
        checks["execution_ledger"] = bool(ledger_entries)
        # Never combine independent validation runs to manufacture a complete pass.
        validation_ids = [entry.get("validation_id") for entry in ledger_entries if entry.get("validation_id")]
        if validation_ids:
            ledger_entries = [entry for entry in ledger_entries if entry.get("validation_id") == validation_ids[-1]]
        if not ledger_entries:
            details.append("no execution ledger records")

        executed = [
            entry for entry in ledger_entries if isinstance(entry, dict) and entry.get("exit_code") is not None
        ]
        checks["real_process_execution"] = bool(executed)
        if not executed:
            details.append("no ledger record captured a process exit code")

        subset_path_set = _subset_paths(subset_manifest)
        consumed = [entry for entry in executed if self._entry_consumes_subset(entry, subset_path_set)]
        checks["commands_consume_subset"] = bool(consumed)
        if not consumed:
            details.append("no executed command read a subset input")

        validated = [
            entry for entry in ledger_entries
            if entry.get("status") == "PASSED" and entry.get("verified")
            and entry.get("exit_code") == 0 and entry.get("output_validation", {}).get("passed") is True
        ]
        checks["outputs_validated"] = bool(validated)
        if not validated:
            details.append("no verified PASSED step with output validation")

        plan_path = self.project.plan_path
        expected_steps = set()
        if plan_path.is_file():
            plan = yaml.safe_load(plan_path.read_text(encoding="utf-8"))
            expected_steps = {step["step_id"] for step in plan.get("steps", [])}
            validated = [entry for entry in validated if not entry.get("plan_fingerprint")
                         or entry["plan_fingerprint"] == plan.get("plan_fingerprint")]
        latest = {entry.get("step_id"): entry for entry in ledger_entries}
        successful = {entry.get("step_id") for entry in validated
                      if latest.get(entry.get("step_id")) == entry}
        checks["planned_steps_covered"] = bool(expected_steps) and expected_steps <= successful
        if not checks["planned_steps_covered"]:
            details.append("approved plan coverage is missing: " + ", ".join(sorted(expected_steps - successful)))

        required = (
            checks["input_manifest"]
            and checks["subset_files"]
            and checks["subset_manifest"]
            and checks["execution_ledger"]
            and checks["real_process_execution"]
            and checks["commands_consume_subset"]
            and checks["outputs_validated"]
            and checks["planned_steps_covered"]
        )
        if required:
            classification = REAL_PASS
        elif not checks["subset_files"] or not checks["commands_consume_subset"]:
            # No real 10% subset was sampled, or no executed command actually
            # consumed the subset -> the claimed pre-test pass is not real.
            classification = FALSE_PASS
        else:
            classification = PARTIAL_PASS
        return PretestEvidence(classification=classification, checks=checks, details=details)

    @staticmethod
    def _entry_consumes_subset(entry: dict[str, Any], subset_path_set: set[str]) -> bool:
        inputs = entry.get("inputs") or []
        for item in inputs:
            path = Path(str(item))
            if str(path.resolve()) in subset_path_set:
                return True
            if SUBSET_DIR_NAME in path.parts and path.suffix.lower() in {".fastq", ".fq", ".gz", ".fasta", ".fa"}:
                return True
        return False


def classify_pretest_evidence(project: PipelineProject) -> PretestEvidence:
    """Convenience entry point for forensics on an existing project."""
    return PretestEvidenceValidator(project).classify()
