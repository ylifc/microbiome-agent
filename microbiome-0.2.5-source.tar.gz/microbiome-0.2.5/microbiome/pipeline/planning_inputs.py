"""Require conversational plans to consume the sampled runtime input bindings."""

from __future__ import annotations

import re
from pathlib import Path

from microbiome.pipeline.errors import ConfigurationError


def input_planning_contract(manifest):
    """Describe the existing input adapter without granting or inferring inputs.

    These fields guide authoring only. The input-kind validators remain the
    acceptance boundary and never fill missing candidate fields from this view.
    """
    kind = manifest.get("input_kind", "raw_sequences")
    sample_roles = sorted({role for sample in manifest.get("samples", [])
                           for role in sample.get("artifacts", {})})
    cohort_roles = sorted(manifest.get("cohort_artifacts", {}))
    contract = {"sample_artifact_roles": sample_roles, "cohort_artifact_roles": cohort_roles}
    modes = {"external_cohort_tables": "complete_external_cohort",
             "completed_run_artifacts": "complete_derived_samples"}
    if kind in modes:
        contract.update(
            required_plan_fields={"pilot_mode": modes[kind], "execution_scope": "cohort",
                                  "validation_strategy": "manifest_cases"},
            step_scopes=["cohort"] if kind == "external_cohort_tables" else ["sample", "cohort"],
            cohort_runtime_bindings={role: "{runtime.cohort_" + role + "}" for role in cohort_roles},
            sample_runtime_bindings={role: "{runtime." + role + "}" for role in sample_roles},
            sampling_performed=False,
            pretest_fraction=None,
            authoring_rule="Set required_plan_fields directly on plan, never in requirements, step.parameters or a new validation step. Bind declared artifact roles in step.input; engine validation is not an analysis DAG step.")
    return contract


def validate_conversation_input_bindings(plan, manifest, project):
    """Reject literal declared samples without rejecting unrelated static references.

    The generic pipeline schema permits static inputs. A conversational pilot
    has a stronger contract: raw samples must be supplied through runtime
    bindings, so the same command receives subsets during validation and the
    complete sample during production. This is a read-only boundary check.
    """
    paths = project.load_config()["paths"]
    raw = Path(paths["raw_data"]).resolve()
    protected = {raw, (project.requirements_dir / "input_manifest.yaml").resolve()}
    for sample in manifest["samples"]:
        for role in ("r1", "r2", "fasta"):
            value = sample.get(role)
            value = value.get("path") if isinstance(value, dict) else value
            if value:
                path = Path(value).expanduser()
                protected.add((path if path.is_absolute() else raw / path).resolve())
    source_manifest = manifest.get("manifest_path") or (manifest.get("source_manifest") or {}).get("path")
    if source_manifest:
        path = Path(source_manifest).expanduser()
        protected.add((path if path.is_absolute() else raw / path).resolve())
    if manifest.get("input_kind") == "completed_run_artifacts":
        from microbiome.pipeline.derived import validate_derived_plan
        validate_derived_plan(plan, manifest)
        protected.add(Path(manifest["parent"]["run_manifest"]).parent.resolve())
        protected.update(Path(a["path"]).resolve() for a in manifest.get("cohort_artifacts", {}).values())
        for sample in manifest["samples"]:
            for artifact in sample["artifacts"].values():
                protected.add(Path(artifact["path"]).resolve())
    external_roots = []
    if manifest.get("input_kind") == "external_cohort_tables":
        from microbiome.pipeline.external_cohort import validate_external_plan
        validate_external_plan(plan, manifest)
        external_roots = [Path(p).resolve() for p in manifest["local_roots"]]
        protected.update(external_roots)
        protected.update(Path(a["path"]).resolve() for a in manifest["cohort_artifacts"].values())
    identities = set()
    for path in protected:
        if path.is_file():
            stat = path.stat()
            identities.add((stat.st_dev, stat.st_ino))

    def strings(value, location):
        if isinstance(value, str):
            yield location, value
        elif isinstance(value, dict):
            for key, item in value.items():
                yield from strings(item, f"{location}.{key}")
        elif isinstance(value, list):
            for index, item in enumerate(value):
                yield from strings(item, f"{location}[{index}]")

    def is_protected(value, *, input_position=False):
        # Expand only real project facts; runtime/step references remain bound
        # by the executor. Resolve aliases so symlinks cannot bypass this check.
        for key, field in (("raw_data_path", "raw_data"), ("database_root", "database"),
                           ("output_root", "output")):
            value = value.replace("{" + key + "}", str(paths[field]))
        variants = [value]
        if "{sample_id}" in value:
            variants = [value.replace("{sample_id}", row["sample_id"]) for row in manifest["samples"]]
        for variant in variants:
            candidates = [variant, variant.partition("=")[2],
                          *re.findall(r'''["']([^"'\n]+)["']''', variant),
                          *re.split(r"[\s,;=\"']+", variant)]
            for candidate in candidates:
                if not candidate or "{" in candidate or "}" in candidate or "\x00" in candidate:
                    continue
                try:
                    path = Path(candidate).expanduser()
                    # argv flags, numbers and prose are not paths just because
                    # raw/candidate would be under a protected external root.
                    # Relative names need an input slot, explicit ./ ../ ~/ syntax,
                    # or an existing filesystem object at one of the two anchors.
                    # Absolute paths (also extracted from code/--flag=path) and
                    # existing aliases still receive the same identity checks.
                    if not (path.is_absolute() or (input_position and candidate == variant)
                            or candidate.startswith(("./", "../", "~/"))
                            or path.exists() or (raw / path).exists()):
                        continue
                    resolved_paths = [path.resolve()]
                    if candidate not in {".", ".."}:
                        resolved_paths.append((raw / path).resolve())
                except (OSError, RuntimeError):
                    continue
                for resolved in resolved_paths:
                    if any(resolved.is_relative_to(p) for p in external_roots):
                        return True
                    if resolved in protected or (manifest.get("input_kind") == "completed_run_artifacts"
                            and resolved.is_relative_to(Path(manifest["parent"]["run_manifest"]).parent.resolve())):
                        return True
                    try:
                        if resolved.is_file():
                            stat = resolved.stat()
                            if (stat.st_dev, stat.st_ino) in identities:
                                return True
                    except OSError:
                        # A long non-path command argument is not a file input.
                        continue
        return False

    for step in plan["steps"]:
        for field in ("input", "command_template", "parameters", "database"):
            for location, value in strings(step.get(field, {}), field):
                if is_protected(value, input_position=field == "input"):
                    if external_roots:
                        raise ConfigurationError(f"step {step['step_id']}: {location} statically references external cohort data; use declared runtime.cohort_ROLE bindings")
                    raise ConfigurationError(
                        f"step {step['step_id']}: {location} statically references a declared raw sample, "
                        "raw-data directory or input manifest and would bypass the 5%–10% pilot. "
                        "Bind sample inputs with {runtime.reads}, {runtime.reads_1}, {runtime.reads_2}, "
                        "{runtime.fasta}, or the corresponding cohort runtime placeholders; keep "
                        "only non-sample reference/configuration files as static inputs."
                    )
    return plan
