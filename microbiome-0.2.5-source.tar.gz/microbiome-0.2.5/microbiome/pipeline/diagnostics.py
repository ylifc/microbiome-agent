"""Stable, actionable error contracts shared by planning and tool adapters.

Diagnostics describe failures; they never authorize retries, resource mutation,
or execution. A stable evidence key prevents timestamps and JSON formatting
from making an unchanged failure look like progress.
"""
from __future__ import annotations

import json
import re

from microbiome.pipeline.errors import ResourceNotReadyError
from microbiome.pipeline.io import canonical_json, object_fingerprint


def normalized_candidate(candidate):
    if isinstance(candidate, str):
        text = candidate.strip()
        if text.startswith("```") and "\n" in text:
            text = text.split("\n", 1)[1].rsplit("```", 1)[0].strip()
        try:
            return json.loads(text)
        except (ValueError, TypeError):
            return text
    return candidate


def normalized_violations(violations):
    """Keep field and rule identities while ignoring repetition and ordering."""
    normalized = {}
    for value in violations or []:
        item = dict(value) if isinstance(value, dict) else {"field": "$", "message": str(value)}
        item.setdefault("field", "$")
        item.setdefault("code", "VALIDATION_FAILED")
        normalized[canonical_json(item)] = item
    return [normalized[key] for key in sorted(normalized)]


def validation_violations(error, *, shape_errors=(), step_errors=()):
    details = getattr(error, "details", {})
    supplied = details.get("violations") if isinstance(details, dict) else None
    if supplied:
        return normalized_violations(supplied)
    issues = []
    for text in shape_errors:
        match = re.match(r"(plan\.steps\[\d+\])", text)
        field = match.group(1) if match else "plan"
        missing = re.search(r"missing required fields: (.+)$", text)
        if missing:
            issues.extend({"field": f"{field}.{name.strip()}", "code": "REQUIRED_FIELD_MISSING",
                           "message": f"Required field {name.strip()} is missing"}
                          for name in missing.group(1).split(","))
        else:
            issues.append({"field": field, "code": "INVALID_FIELD", "message": str(text)})
    for item in step_errors:
        issues.append({"field": f"plan.steps[{item['step_index']}]", "code": "STEP_CONTRACT_INVALID",
                       "message": item["error"]})
    if not issues:
        message = str(error)
        match = re.search(r"(plan(?:\.[A-Za-z_]+|\[\d+\])*)", message)
        issues.append({"field": match.group(1) if match else "$", "code": "VALIDATION_FAILED",
                       "message": message})
    return normalized_violations(issues)


def error_diagnostic(error, *, context=None, candidate=None, violations=None, evidence=None):
    """Classify failures and admission policy, never infer recorded model usage.

    ``consumes_*`` are legacy controller admission flags, not ledger counters.
    Only an explicit compiler context can admit a candidate-format repair.
    A transport boundary merely reports an exception and admits neither a
    repair nor a durable recovery receipt. Actual usage belongs to the planning
    ledger and actual recovery consumption belongs to its persisted receipt.
    """
    supplied = getattr(error, "details", {})
    supplied = supplied if isinstance(supplied, dict) else {}
    text = str(error)
    supplied_code = str(supplied.get("code", ""))
    resource_binding_codes = {"DATABASE_BINDING_MISMATCH", "AMBIGUOUS_DATABASE_BINDING",
        "DATABASE_CONSUMER_UNDECLARED", "UNSUPPORTED_DATABASE_BINDING_VERSION", "FROZEN_DATABASE_BINDING_DRIFT",
        "LEGACY_DATABASE_BINDING_REVALIDATION_REQUIRED"}
    prefix = text.split(":", 1)[0]
    if not supplied_code and prefix in resource_binding_codes | {"CHECKPOINT_PHASE_DENIED"}:
        supplied_code = prefix
    if supplied_code == "PROJECT_BUSY" or "PROJECT_BUSY" in text:
        category, code, action = "OPERATION_BUSY", "PROJECT_BUSY", "query_active_task"
    elif supplied_code in {"PLANNING_EVIDENCE_LIMIT", "PLANNING_GUIDANCE_LIMIT", "PLANNING_HISTORY_LIMIT", "MODEL_CONTEXT_LIMIT",
                           "PLANNING_STRUCTURE_LIMIT", "PLANNING_ADJUSTMENT_LIMIT", "MODEL_OUTPUT_LIMIT",
                           "PLANNING_CALL_LIMIT"}:
        category, code, action = "PLANNING_POLICY", supplied_code, "inspect_planning_policy"
    elif supplied_code in {"RESOURCE_NOT_READY", "RESOURCE_DRIFT", "INCOMPLETE_RESOURCE", "CORRUPT_RESOURCE",
                         "INCOMPLETE_RESOURCE_MANIFEST", "INCOMPLETE_CONSUMER_CONTRACT",
                         "CONTRACT_REQUIRED", "VERSION_EVIDENCE_REQUIRED", "UNKNOWN_RESOURCE_VERSION",
                         "RESOURCE_REQUIREMENT_UNRESOLVED"} or supplied_code in resource_binding_codes:
        category, code, action = "RESOURCE_INCOMPLETE", supplied_code, "validate_resource_candidate"
    elif supplied_code in {"RESOURCE_SCOPE_DENIED", "RESOURCE_PHASE_DENIED", "FROZEN_RESOURCE_MUTATION_DENIED",
                           "DEPENDENCY_SCOPE_REQUIRED", "CHECKPOINT_PHASE_DENIED"}:
        category, code, action = "PHASE_PERMISSION", supplied_code, "inspect_phase_permissions"
    elif supplied_code in {"STALE_RESOURCE_REFERENCE", "STALE_REGISTRY_REVISION", "STALE_VALIDATION",
                           "SNAPSHOT_CHANGED"}:
        category, code, action = "STALE_EVIDENCE", supplied_code, "refresh_resource_evidence"
    elif supplied_code in {"INVALID_RESOURCE_DECLARATION", "RESOURCE_DECLARATION_MISSING", "RESOURCE_SOURCE_CONFLICT",
                           "UNUSED_RESOURCE_DECLARATION", "RESOURCE_REFERENCE_OVERRIDE", "INVALID_RESOURCE_REFERENCE"}:
        category, code, action = "INTERNAL_PLAN_COMPILATION", supplied_code, "repair_resource_declaration"
    elif context == "compiler":
        category, code, action = "INTERNAL_PLAN_COMPILATION", "CANDIDATE_FORMAT_INVALID", "repair_candidate"
    elif isinstance(error, PermissionError):
        category, code, action = "ACCESS_DENIED", "FILE_ACCESS_DENIED", "inspect_bound_root_permissions"
    elif isinstance(error, FileNotFoundError):
        category, code, action = "LOCAL_INPUT", "FILE_NOT_FOUND", "resolve_local_path"
    elif isinstance(error, ResourceNotReadyError):
        category, code, action = "RESOURCE_INCOMPLETE", "RESOURCE_NOT_READY", "validate_resource_candidate"
    elif supplied.get("code") in {"UNSUPPORTED_MAINTENANCE_ARGUMENT", "INVALID_MAINTENANCE_ARGUMENT", "INVALID_ARGUMENT"}:
        category, code, action = "TOOL_ARGUMENT", supplied["code"], "correct_tool_arguments"
    elif context == "input":
        category, code, action = "LOCAL_INPUT", "INPUT_UNRESOLVED", "inspect_input_diagnostic"
    else:
        category, code, action = "INTERNAL_WORKFLOW", "WORKFLOW_ERROR", "inspect_diagnostic"
    category = supplied.get("category", category)
    code = supplied.get("code", code)
    violations = normalized_violations(violations or supplied.get("violations") or validation_violations(error))
    fingerprint = object_fingerprint({"category": category, "code": code,
        "candidate": normalized_candidate(candidate), "violations": violations, "evidence": evidence})
    no_admission = context in {"read_only", "checkpoint", "worker_boundary"}
    format_repair_eligible = context == "compiler" and category not in {
        "PLANNING_POLICY", "OPERATION_BUSY", "PHASE_PERMISSION", "TOOL_ARGUMENT",
        "INTERNAL_WORKFLOW", "CONFIGURATION", "PLANNING_STATE"}
    return {**{key: supplied[key] for key in ("measured", "limit", "breakdown", "policy_fingerprint", "receipt",
                "before_compaction_bytes", "allowed_maximum", "preserved", "exact_token_count", "token_count_method") if key in supplied},
            "code": code, "category": category, "violations": violations,
            "evidence_fingerprint": fingerprint, "fingerprint": fingerprint,
            "recoverable": bool(supplied.get("recoverable", True)),
            "requires_user_information": False, "next_action": supplied.get("next_action") or action,
            "consumes_recovery_attempt": not no_admission and code != "PROJECT_BUSY",
            "format_repair_eligible": format_repair_eligible,
            "consumes_format_repair": format_repair_eligible,
            "accounting_scope": "admission_policy_not_recorded_usage"}


from typing import Any

from microbiome.pipeline.models import FailureCategory


def classify_failure(
    *,
    exit_code: int | None,
    stdout: str = "",
    stderr: str = "",
    assertion_failed: bool = False,
    preflight_kind: str | None = None,
) -> FailureCategory:
    text = f"{stdout}\n{stderr}".casefold()
    if preflight_kind == "input":
        return FailureCategory.INPUT_FAILURE
    if preflight_kind == "environment":
        return FailureCategory.ENVIRONMENT_FAILURE
    if preflight_kind == "database":
        return FailureCategory.DATABASE_FAILURE
    if preflight_kind == "resource":
        return FailureCategory.RESOURCE_FAILURE
    if assertion_failed:
        return FailureCategory.OUTPUT_VALIDATION_FAILURE
    if any(marker in text for marker in ("truncated fastq", "invalid fasta", "invalid fastq", "parse error")):
        return FailureCategory.FORMAT_FAILURE
    if any(marker in text for marker in ("no such file", "file not found", "path does not exist")):
        return FailureCategory.PATH_FAILURE
    if any(marker in text for marker in ("connection reset", "network is unreachable", "timed out", "http error")):
        return FailureCategory.NETWORK_FAILURE
    if any(marker in text for marker in ("syntax error", "unexpected token", "usage:")):
        return FailureCategory.COMMAND_SYNTAX_FAILURE
    if any(marker in text for marker in ("missing dependency", "module not found", "no module named")):
        return FailureCategory.DEPENDENCY_FAILURE
    if "index" in text and any(marker in text for marker in ("missing", "not found", "corrupt", "incompatible")):
        return FailureCategory.DATABASE_INDEX_FAILURE
    if any(marker in text for marker in ("input file", "empty input")):
        return FailureCategory.INPUT_FAILURE
    if any(marker in text for marker in ("not a conda environment", "environmentlocationnotfound", "shared libraries")):
        return FailureCategory.ENVIRONMENT_FAILURE
    if "database" in text and any(marker in text for marker in ("missing", "not found", "corrupt", "index")):
        return FailureCategory.DATABASE_FAILURE
    if any(marker in text for marker in ("out of memory", "cannot allocate memory", "disk quota", "no space left")):
        return FailureCategory.RESOURCE_FAILURE
    if any(
        marker in text
        for marker in ("unrecognized option", "unrecognized argument", "invalid option", "illegal option")
    ):
        return FailureCategory.PARAMETER_FAILURE
    if any(
        marker in text for marker in ("command not found", "permission denied", "segmentation fault", "core dumped")
    ):
        return FailureCategory.SOFTWARE_FAILURE
    if exit_code not in (None, 0):
        return FailureCategory.SOFTWARE_FAILURE
    return FailureCategory.UNKNOWN_FAILURE


def failure_record(
    *,
    step: str,
    sample: str,
    command: list[str],
    environment: str | None,
    tool_version: str,
    database: dict[str, str],
    exit_code: int | None,
    stdout: str,
    stderr: str,
    input_metadata: dict[str, Any],
    assertion_failed: bool = False,
) -> dict[str, Any]:
    category = classify_failure(exit_code=exit_code, stdout=stdout, stderr=stderr, assertion_failed=assertion_failed)
    return {
        "category": category.value,
        "step": step,
        "sample": sample,
        "command": command,
        "environment": environment,
        "tool_version": tool_version,
        "database": database,
        "exit_code": exit_code,
        "stdout": stdout,
        "stderr": stderr,
        "input_metadata": input_metadata,
        "action": "STOP_AFFECTED_BRANCH; diagnose in repair-validation mode; do not hot-patch production",
    }
