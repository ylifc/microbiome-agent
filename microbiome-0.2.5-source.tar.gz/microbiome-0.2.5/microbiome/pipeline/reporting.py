"""Durable human- and machine-readable final reports for frozen runs."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from microbiome.pipeline.io import atomic_write_text, object_fingerprint, read_json, write_json

if TYPE_CHECKING:
    from pathlib import Path

    from microbiome.pipeline.project import PipelineProject


def _utcnow() -> str:
    return datetime.now(UTC).isoformat()


def _resources_text(resources: Any) -> str:
    """Render a compact, human-readable resource summary (defensive)."""
    if not resources:
        return "n/a"
    if isinstance(resources, dict):
        parts = []
        for key in ("threads", "memory_gb", "gpus"):
            value = resources.get(key)
            if value is not None:
                label = {"threads": "threads", "memory_gb": "mem_gb", "gpus": "gpus"}[key]
                parts.append(f"{label}={value}")
        if parts:
            return ", ".join(parts)
        return ", ".join(f"{k}={v}" for k, v in resources.items())
    return str(resources)


def _table_cell(value: Any, *, first_line: bool = False) -> str:
    """Keep human tables intact; exact values remain in the JSON report."""
    text = str(value if value is not None else "n/a")
    if first_line:
        text = next((line.strip() for line in text.splitlines() if line.strip()), "n/a")
    return text.replace("|", "\\|").replace("`", "&#96;").replace("\r", "").replace("\n", "<br>")


class FinalReportWriter:
    """Write a run summary that is complete without reinterpreting scientific results.

    The Markdown report now surfaces the information most operators need — inputs,
    per-step tool version and resource allocation, database fingerprints, and a
    status summary — while leaving raw commands, logs, and exact fingerprints to the
    linked run manifest and run directory.
    """

    def __init__(self, project: PipelineProject):
        self.project = project

    def write_batch(self, batch: dict[str, Any]) -> dict[str, str]:
        path = self.project.reports_dir / f"{batch['batch_id']}-batch-report.md"
        index_path = self.project.reports_dir / f"{batch['batch_id']}-artifact-index.json"
        index = []
        lines = [f"# 全量分析报告：{batch['batch_id']}", "", f"研究目标：{batch.get('objective') or '见已确认方案'}",
                 f"执行状态：{batch['status']}", f"完成样本：{batch['completed_samples']}/{batch['total_samples']}",
                 f"流程版本：{batch['pipeline_version']}", "", "| 样本 | 状态 | 结果报告 |", "| --- | --- | --- |"]
        for row in batch['runs']:
            report = row.get('final_report') or {}
            lines.append(f"| {row['sample_id']} | {row['status']} | {report.get('markdown', '尚未生成')} |")
            if report.get('json'):
                index.append({"sample_id": row['sample_id'], "status": row['status'],
                              "artifacts": read_json(report['json']).get('artifacts', [])})
        lines.extend(["", f"未完成样本：{', '.join(batch.get('pending_samples', [])) or '无'}",
                      f"失败样本：{', '.join(batch.get('failed_samples', [])) or '无'}",
                      f"交付文件索引：{index_path}",
                      "本报告汇总计算结果及其验证状态。组间推断需要已验证的组间分析步骤，不能从逐样本成功推断统计结论。"])
        if batch.get('blocker'):
            lines.append(f"阻塞原因：{batch['blocker']}")
        write_json(index_path, {"pipeline_hash": batch['pipeline_hash'], "samples": index})
        atomic_write_text(path, '\n'.join(lines) + '\n')
        return {"markdown": str(path), "artifact_index": str(index_path)}

    def write(self, manifest: dict[str, Any], manifest_path: Path) -> dict[str, Any]:
        run_id = str(manifest["run_id"])
        json_path = self.project.reports_dir / f"{run_id}-final-report.json"
        markdown_path = self.project.reports_dir / f"{run_id}-final-report.md"
        tools = manifest.get("tools", {}) or {}
        databases = manifest.get("databases", {}) or {}
        inputs = manifest.get("inputs", {}) or {}
        summary = manifest.get("summary", {}) or {}

        step_rows = []
        artifacts = []
        for step_id, value in manifest.get("steps", {}).items():
            checkpoint = value.get("checkpoint")
            if checkpoint and value.get("status") in {"COMPLETED", "REUSED"}:
                for name, metadata in read_json(checkpoint).get("output_fingerprint", {}).items():
                    if metadata.get("missing"):
                        continue
                    artifacts.append({"step_id": step_id, "output": name, "validated": True, **metadata})
            tool_info = tools.get(step_id, {}) if isinstance(tools, dict) else {}
            step_rows.append(
                {
                    "step_id": step_id,
                    "status": value.get("status"),
                    "resources": value.get("resources"),
                    "tool_version": tool_info.get("version"),
                    "failure_category": value.get("failure_category"),
                    "failure_record": value.get("failure_record"),
                    **{key: value[key] for key in (
                        "execution_status", "exit_code", "stdout_log", "stderr_log",
                        "runtime_seconds", "success_checks", "assertion_error",
                    ) if key in value},
                }
            )

        payload = {
            "objective": manifest.get("objective"),
            "artifacts": artifacts,
            "deliverables": [{**item, "status": "AVAILABLE" if any(
                artifact["step_id"] == item["step_id"] and artifact["output"] == item["output"]
                for artifact in artifacts) else "MISSING"} for item in manifest.get("deliverables", [])],
            "schema_version": 1,
            "generated_at": _utcnow(),
            "run_id": run_id,
            "sample_id": manifest.get("sample_id"),
            "status": manifest.get("status"),
            "requirements_version": manifest.get("requirements_version"),
            "pipeline_version": manifest.get("pipeline_version"),
            "pipeline_hash": manifest.get("pipeline_hash"),
            "inputs": inputs,
            "outputs_path": manifest.get("outputs_path"),
            "tools": tools,
            "databases": databases,
            "duration_seconds": manifest.get("duration_seconds"),
            "failed_samples": manifest.get("failed_samples", []),
            "summary": summary,
            "steps": step_rows,
            "run_manifest": str(manifest_path),
        }
        payload["report_fingerprint"] = object_fingerprint(payload)
        write_json(json_path, payload)

        lines = [
            f"# Frozen pipeline run report: {run_id}",
            "",
            f"研究目标：{payload.get('objective') or '见已确认方案'}",
            f"- Status: **{payload['status']}**",
            f"- Sample: `{payload['sample_id']}`",
            f"- Requirements version: `{payload['requirements_version']}`",
            f"- Pipeline version: `{payload['pipeline_version']}`",
            f"- Pipeline hash: `{payload['pipeline_hash']}`",
            f"- Duration: `{payload['duration_seconds']}` seconds",
            f"- Outputs: `{payload['outputs_path']}`",
            f"- Run manifest: `{payload['run_manifest']}`",
            "",
        ]
        lines.extend(["## Deliverables", ""])
        for item in payload["deliverables"]:
            lines.append(f"- {item.get('name', item['output'])}: {item['status']} — {item.get('purpose', '')}")
        for item in artifacts:
            lines.append(f"- {item['step_id']}/{item['output']}: `{item.get('path')}`")
        lines.append("")

        if summary:
            lines.extend(
                [
                    "## Summary",
                    "",
                    f"- Completed steps: `{summary.get('completed_steps', 'n/a')}`",
                    f"- Failed step: `{summary.get('failed_step') or 'none'}`",
                    f"- Failed samples: `{', '.join(str(s) for s in payload['failed_samples']) or 'none'}`",
                    "",
                ]
            )

        if inputs:
            lines.extend(["## Inputs", ""])
            for name, path in inputs.items():
                lines.append(f"- `{name}`: `{path}`")
            lines.append("")

        if tools:
            lines.extend(["## Tools", "", "| Step | Executable | Version |", "| --- | --- | --- |"])
            for step_id, tool in tools.items():
                executable = tool.get("executable", "n/a") if isinstance(tool, dict) else tool
                version = tool.get("version", "n/a") if isinstance(tool, dict) else "n/a"
                lines.append(f"| {_table_cell(step_id)} | `{_table_cell(executable)}` | {_table_cell(version, first_line=True)} |")
            lines.append("")

        if databases:
            lines.extend(["## Databases", "", "| Name | Runtime entry | Fingerprint |", "| --- | --- | --- |"])
            for name, entry in databases.items():
                runtime_entry = entry.get("runtime_entry", "n/a") if isinstance(entry, dict) else entry
                fingerprint = entry.get("fingerprint", "n/a") if isinstance(entry, dict) else "n/a"
                lines.append(f"| {name} | `{runtime_entry}` | `{fingerprint}` |")
            lines.append("")

        lines.extend(
            [
                "## Step results",
                "",
                "| Step | Status | Tool version | Resources | Failure category |",
                "| --- | --- | --- | --- | --- |",
            ]
        )
        for row in step_rows:
            lines.append(
                f"| {_table_cell(row['step_id'])} | {_table_cell(row['status'])} | {_table_cell(row.get('tool_version'), first_line=True)} | "
                f"{_table_cell(_resources_text(row.get('resources')))} | {_table_cell(row.get('failure_category') or 'none')} |"
            )
        if not step_rows:
            lines.append("| none | NOT_RUN | n/a | n/a | none |")

        lines.extend(
            [
                "",
                "## Reproducibility contract",
                "",
                "This report describes a deterministic replay of the frozen pipeline. "
                "Raw commands, per-step logs, checkpoints, input fingerprints, exact tool/database "
                "versions, and precise resource allocations remain in the linked run manifest and run directory.",
                "",
            ]
        )
        atomic_write_text(markdown_path, "\n".join(lines))
        return {
            "json": str(json_path),
            "markdown": str(markdown_path),
            "report_fingerprint": payload["report_fingerprint"],
        }
