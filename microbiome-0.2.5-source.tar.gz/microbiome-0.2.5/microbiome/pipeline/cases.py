"""Representative or all-sample pre-tests bound to one plan and full manifest."""

from __future__ import annotations

import math

from microbiome.pipeline.errors import ConfigurationError, FreezeError
from microbiome.pipeline.io import object_fingerprint, read_json, read_yaml, write_json
from microbiome.pipeline.state import LifecycleState, ProjectStateMachine
from microbiome.pipeline.validation import SmallScaleValidator


def sample_inputs(sample):
    if sample.get("source_type") in {"completed_run_artifacts", "external_cohort_tables"}:
        return {role: value["path"] for role, value in sample["artifacts"].items()}
    def path(name):
        value = sample.get(name)
        return value.get("path") if isinstance(value, dict) else value

    if path("r1") and path("r2"):
        return {"reads_1": path("r1"), "reads_2": path("r2")}
    if path("fasta"):
        return {"fasta": path("fasta")}
    if path("r1"):
        return {"reads": path("r1")}
    raise ConfigurationError(f"sample {sample.get('sample_id')} has no localized sequence input")


def representative_samples(manifest, requirements, plan=None, *, all_samples=False):
    if (plan or {}).get("execution_scope") == "cohort":
        from microbiome.pipeline.cohort import cohort_runtime_inputs
        return [({"sample_id": "cohort"}, cohort_runtime_inputs(plan, manifest))]
    if all_samples:
        return [(sample, sample_inputs(sample)) for sample in manifest["samples"]]
    metadata = {row["sample_id"]: row for row in requirements.get("dataset", {}).get("sample_metadata", [])}
    representatives = {}
    for sample in manifest["samples"]:
        inputs = sample_inputs(sample)
        group = metadata.get(sample["sample_id"], {}).get("group", "all")
        representatives.setdefault((tuple(sorted(inputs)), group), (sample, inputs))
    return list(representatives.values())


def validate_pretest_fraction(fraction):
    """Validate a guided pre-test choice before preparing any scientific resource."""
    if isinstance(fraction, bool) or not isinstance(fraction, (int, float)):
        raise ConfigurationError("小数据验证采样比例必须为 5%–10% 的数值。")
    if not math.isfinite(fraction) or not 0.05 <= fraction <= 0.10:
        raise ConfigurationError("小数据验证采样比例必须在 5%–10% 之间。")
    return float(fraction)


def validate_manifest_cases(project, manifest, *, fraction=None, all_samples=False, resume_validation_id=None, repair_validation_id=None):
    """Validate a complete DAG for representative cases or every declared sample."""
    from microbiome.pipeline.derived import KIND, MODE, validate_derived_plan, verify_derived_manifest
    if resume_validation_id is not None and repair_validation_id is not None:
        raise ConfigurationError("resume_validation_id and repair_validation_id are mutually exclusive")
    from microbiome.pipeline.external_cohort import KIND as EXTERNAL_KIND, validate_external_plan, verify_external_manifest
    derived = manifest.get("input_kind") == KIND
    external = manifest.get("input_kind") == EXTERNAL_KIND
    if external and (fraction is not None or resume_validation_id is not None or repair_validation_id is not None):
        raise ConfigurationError("complete_external_cohort rejects fraction and validation reuse")
    if derived and fraction is not None:
        raise ConfigurationError("complete_derived_samples rejects fraction; complete artifacts are mandatory")
    if fraction is not None:
        fraction = validate_pretest_fraction(fraction)
    if not isinstance(all_samples, bool):
        raise ConfigurationError("pre-test all_samples must be a boolean")
    plan = read_yaml(project.plan_path)
    requirements = read_yaml(project.requirements_path)
    validate_derived_plan(plan, manifest)
    validate_external_plan(plan, manifest)
    if external:
        verify_external_manifest(project, manifest)
    if derived:
        verify_derived_manifest(project, manifest)
    if (resume_validation_id is not None or repair_validation_id is not None) and (not derived or plan.get("execution_scope") != "cohort"):
        raise ConfigurationError("continuation requires a complete derived cohort pilot")
    representatives = representative_samples(manifest, requirements, plan, all_samples=all_samples)
    if not representatives:
        raise ConfigurationError("pre-test requires at least one representative sample")
    machine = ProjectStateMachine(project)
    machine.require(LifecycleState.PRETEST_PREPARATION, LifecycleState.PRETEST_REPAIR)
    machine.transition(LifecycleState.PRETEST_RUNNING, reason="representative case suite started")
    reports = []
    try:
        for sample, inputs in representatives:
            report = SmallScaleValidator(project).validate(
                inputs,
                sample_id=sample["sample_id"],
                **({"fraction": fraction} if fraction is not None else {}),
                **({"resume_validation_id": resume_validation_id} if resume_validation_id is not None else {}),
                **({"repair_validation_id": repair_validation_id} if repair_validation_id is not None else {}),
                _manage_state=False,
                new_version=project.pipeline_lock_path.is_file(),
            )
            write_json(project.pretest_dir / report["validation_id"] / "reports" / "validation_report.json", report)
            reports.append(report)
            if report["status"] != "PASSED":
                break
    except Exception:
        machine.transition(LifecycleState.PRETEST_REPAIR, reason="representative case execution failed")
        raise
    passed = len(reports) == len(representatives) and all(report["status"] == "PASSED" for report in reports)
    suite = {
        "status": "PASSED" if passed else "FAILED",
        "plan_fingerprint": plan["plan_fingerprint"],
        "input_fingerprint": object_fingerprint(manifest),
        "sampling_scope": "cohort" if plan.get("execution_scope") == "cohort" else (
            "all_samples" if all_samples else "representative"
        ),
        "pretest_fraction": reports[0]["pretest_fraction"],
        "expected_cases": len(representatives),
        "cases": [
            {
                "validation_id": report["validation_id"],
                "status": report["status"],
                "sample_id": sample["sample_id"],
                "report_fingerprint": report["report_fingerprint"],
            }
            for (sample, _inputs), report in zip(representatives, reports)
        ],
    }
    suite["suite_fingerprint"] = object_fingerprint(suite)
    previous_path = project.pipeline_dir / "validation_suite.json"
    if previous_path.is_file():
        previous = read_json(previous_path)
        write_json(project.state_dir / "validation_suites" / f"{previous['suite_fingerprint']}.json", previous)
    write_json(project.pipeline_dir / "validation_suite.json", suite)
    machine.transition(
        LifecycleState.PRETEST_PASSED if passed else LifecycleState.PRETEST_REPAIR,
        reason="representative case suite finished",
    )
    return reports[-1]


def verify_validation_suite(project, plan):
    """An approved representative suite is a freeze gate, not an optional summary."""
    required = plan.get("validation_strategy") == "manifest_cases"
    path = project.pipeline_dir / "validation_suite.json"
    if not path.is_file():
        if required:
            raise FreezeError("representative validation suite is missing")
        return None
    suite = read_json(path)
    if not required and suite.get("plan_fingerprint") != plan["plan_fingerprint"]:
        return None
    if suite.get("suite_fingerprint") != object_fingerprint(
        {k: v for k, v in suite.items() if k != "suite_fingerprint"}
    ):
        raise FreezeError("representative validation suite fingerprint is invalid")
    manifest = read_yaml(project.requirements_dir / "input_manifest.yaml")
    scope = suite.get("sampling_scope", "cohort" if plan.get("execution_scope") == "cohort" else "representative")
    if scope not in {"representative", "all_samples", "cohort"} or (
        (scope == "cohort") != (plan.get("execution_scope") == "cohort")
    ):
        raise FreezeError("validation suite sampling scope is invalid")
    expected = {
        sample["sample_id"]: inputs
        for sample, inputs in representative_samples(
            manifest, read_yaml(project.requirements_path), plan, all_samples=scope == "all_samples"
        )
    }
    if (
        suite.get("status") != "PASSED"
        or suite.get("plan_fingerprint") != plan["plan_fingerprint"]
        or suite.get("input_fingerprint") != object_fingerprint(manifest)
        or not suite.get("cases")
        or len(suite["cases"]) != suite.get("expected_cases")
        or suite.get("expected_cases") != len(expected)
        or {case.get("sample_id") for case in suite["cases"]} != set(expected)
    ):
        raise FreezeError("representative validation suite is incomplete or stale")
    from microbiome.pipeline.freeze import _verified_report

    for case in suite["cases"]:
        report = _verified_report(
            project.pretest_dir / case["validation_id"] / "reports" / "validation_report.json", plan
        )
        if report["report_fingerprint"] != case["report_fingerprint"]:
            raise FreezeError("representative validation case changed")
        if "pretest_fraction" in suite and report.get("pretest_fraction") != suite["pretest_fraction"]:
            raise FreezeError("validation case used a different pre-test fraction")
        if {name: data["path"] for name, data in report["runtime_input_source"].items()} != expected[case["sample_id"]]:
            raise FreezeError("representative case used different source inputs")
    return suite
