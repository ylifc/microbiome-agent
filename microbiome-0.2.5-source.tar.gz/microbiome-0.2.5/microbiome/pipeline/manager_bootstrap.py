"""Review and execute a pinned package-manager dependency within approved bootstrap."""

from __future__ import annotations

import os
from pathlib import Path
import re
import tempfile

import requests

from microbiome.conda_bootstrap import installer_filename
from microbiome.conda_discovery import find_conda_manager
from microbiome.pipeline.errors import ConfigurationError
from microbiome.pipeline.io import fast_file_fingerprint, object_fingerprint, write_yaml
from microbiome.pipeline.process_file_policy import run_scoped_process, run_step_process


def preview_manager(project, *, session=None):
    existing = find_conda_manager()
    if existing:
        return None
    session = session or requests.Session()
    response = session.get("https://api.github.com/repos/conda-forge/miniforge/releases/latest", timeout=15)
    response.raise_for_status()
    release = response.json()
    name = installer_filename()
    asset = next((item for item in release.get("assets", []) if item.get("name") == name), None)
    if not asset:
        raise ConfigurationError("no official Miniforge installer is available for this platform")
    url = asset.get("browser_download_url", "")
    digest = asset.get("digest", "")
    if not re.fullmatch(r"sha256:[0-9a-fA-F]{64}", digest or ""):
        checksum = session.get(url + ".sha256", timeout=15)
        checksum.raise_for_status()
        digest = "sha256:" + checksum.text.split()[0]
    if not url.startswith("https://github.com/conda-forge/miniforge/releases/download/") or not re.fullmatch(
        r"sha256:[0-9a-fA-F]{64}", digest
    ):
        raise ConfigurationError("package-manager source and checksum could not be verified")
    proposal = {
        "resource_id": "conda-manager",
        "release": release.get("tag_name"),
        "url": url,
        "checksum": digest,
        "prefix": str(project.root / ".biomni" / "manager"),
    }
    proposal["fingerprint"] = object_fingerprint(proposal)
    return proposal


def install_approved_manager(project, plan):
    proposal = plan.get("manager_bootstrap")
    if not proposal or find_conda_manager():
        return
    from microbiome.pipeline.dependencies import require_bootstrap_approval
    from microbiome.pipeline.knowledge import KnowledgeBase
    from microbiome.resource_skills.acquisition import download_file_with_resume
    from microbiome.resource_skills.locking import resource_lock

    require_bootstrap_approval(project, plan)
    if proposal.get("fingerprint") != object_fingerprint({k: v for k, v in proposal.items() if k != "fingerprint"}):
        raise ConfigurationError("package-manager proposal changed")
    prefix = Path(proposal["prefix"]).resolve()
    if prefix != (project.root / ".biomni" / "manager").resolve():
        raise ConfigurationError("package-manager destination is outside the approved project prefix")
    executable = prefix / "bin" / "conda"
    knowledge = KnowledgeBase(project)
    with resource_lock(project.root / ".biomni", "manager"):
        # Recover a completed installation after interruption without downloading again.
        if not executable.is_file():
            if prefix.exists():
                raise ConfigurationError("manager prefix exists but is incomplete; inspect it in a new repair plan")
            with tempfile.TemporaryDirectory(prefix="microbiome-manager-") as temporary:
                installer = Path(temporary) / "installer.sh"
                download_file_with_resume(proposal["url"], installer, checksum=proposal["checksum"], retries=3)
                # Build a new prefix in an isolated view of its parent. Existing
                # sibling environments and project files remain read-only.
                result = run_step_process(
                    ["bash", str(installer), "-b", "-p", str(prefix)],
                    working_directory=prefix.parent,
                    inputs={"installer": str(installer)},
                    outputs={"manager": str(prefix)},
                    allow_artifact_links=True,
                    capture_output=True,
                    text=True,
                    timeout=900,
                    check=False,
                )
                if result.returncode:
                    knowledge.record_installation_attempt(
                        "conda-manager",
                        {
                            **proposal,
                            "validated": False,
                            "returncode": result.returncode,
                            "output_excerpt": result.stderr[-2000:],
                        },
                    )
                    raise ConfigurationError("approved package-manager installation failed; see Knowledge")
        checks = [
            run_scoped_process([str(executable), flag], capture_output=True, text=True, timeout=30, check=False)
            for flag in ("--version", "--help")
        ]
        if any(item.returncode != 0 or not item.stdout.strip() for item in checks):
            raise ConfigurationError("package-manager version/help validation failed")
        os.environ["PATH"] = str(prefix / "bin") + os.pathsep + os.environ.get("PATH", "")
        knowledge.record_installation_attempt(
            "conda-manager",
            {**proposal, "validated": True, "version": checks[0].stdout.strip(), "executable": str(executable)},
        )
        from microbiome.resource_skills.resolver import SoftwareSkillBuilder, ToolBinding

        binding = ToolBinding(
            logical_tool="conda-manager",
            executable=str(executable),
            software_family="conda-manager",
            environment_prefix=str(prefix),
            environment_name="project-manager",
            version_output=checks[0].stdout.strip(),
            version_args=["--version"],
            help_args=["--help"],
            help_exit_code=0,
            source=proposal["url"],
            package_candidates=["conda"],
            family_executables=["conda"],
            installed=True,
            reused=False,
        )
        skill = SoftwareSkillBuilder(project.resource_skills_dir).build(
            binding, version_text=checks[0].stdout, help_text=checks[1].stdout
        )
        record = {
            **binding.as_dict(),
            "executable_fingerprint": fast_file_fingerprint(executable),
            "skill_id": skill.skill_id,
            "installation": proposal,
        }
        write_yaml(project.config_dir / "manager_registry.yaml", record)
        knowledge.record_tool_profile("conda-manager", record)
