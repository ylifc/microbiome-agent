"""Local database discovery, evidence validation and approval-scoped binding.

The service never downloads, executes a database command, repairs data, writes
Skills or treats resource metadata as instructions. Read/validation operations
are available independently of model planning. Only bind changes the registry.
"""
from __future__ import annotations

import base64
import copy
import hashlib
import json
import os
import stat
from datetime import date
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from microbiome.pipeline.errors import ConfigurationError
from microbiome.pipeline.io import object_fingerprint, read_json, read_yaml
from microbiome.pipeline.locking import project_operation_lock
from microbiome.pipeline.maintenance_read import _content, _open, _private, _target, list_directory, page_records
from microbiome.pipeline.project import PipelineProject
from microbiome.pipeline.registry import load_database_registry, update_database_registry
from microbiome.pipeline.resources import DatabaseResolver
from microbiome.pipeline.state import LifecycleState, ProjectStateMachine

MAX_CANDIDATE_ENTRIES = 100000


class DatabaseOperationError(ConfigurationError):
    def __init__(self, code, message, *, next_action=None, **details):
        self.details = {"code": code, "message": message, "next_action": next_action, **details}
        super().__init__(f"{code}: {message}")


def load_database_contract():
    return json.loads(Path(__file__).with_name("database_contract.json").read_text(encoding="utf-8"))


def database_tool_schema():
    return {"type": "object", "oneOf": [
        {"type": "object", "properties": {"operation": {"const": name, "description": spec["description"]},
            "arguments": spec["parameters"]}, "required": ["operation"] +
            (["arguments"] if spec["parameters"].get("required") else []), "additionalProperties": False}
        for name, spec in load_database_contract()["operations"].items()]}


def validate_database_request(operation, arguments):
    definition = load_database_contract()["operations"].get(operation) if isinstance(operation, str) else None
    errors = list(Draft202012Validator(definition["parameters"]).iter_errors(arguments)) if definition else []
    if definition is None or errors:
        raise DatabaseOperationError("INVALID_ARGUMENT", "Use the database operation's declared argument schema",
            operation=operation, field_errors=[{"field": list(e.absolute_path), "issue": e.message} for e in errors],
            schema=definition["parameters"] if definition else None,
            next_action={"operation": operation if definition else "discover", "arguments": definition["example"] if definition else {}})
    return copy.deepcopy(arguments)


def _registry(project):
    with _open(project.database_registry_path):
        pass
    return load_database_registry(project.database_registry_path, database_root=project.load_config()["paths"]["database"])


def _candidate_id(project, path):
    return base64.urlsafe_b64encode(json.dumps({"project": str(project.root), "path": str(path)},
        sort_keys=True, separators=(",", ":")).encode()).decode()


def _candidate_path(project, token):
    try:
        value = json.loads(base64.urlsafe_b64decode(token.encode()))
        if not isinstance(value, dict) or set(value) != {"project", "path"} or value["project"] != str(project.root):
            raise ValueError()
        return _target(project, "database", value["path"])
    except (ValueError, TypeError, UnicodeError) as error:
        raise DatabaseOperationError("INVALID_CANDIDATE", "Candidate belongs to another project or is invalid",
                                     next_action={"operation": "discover", "arguments": {}}) from error


def _safe_relative(value):
    if not isinstance(value, str) or not value or Path(value).is_absolute() or ".." in Path(value).parts or "\x00" in value or _private(Path(value)):
        raise DatabaseOperationError("RESOURCE_SCOPE_DENIED", "Resource components must be non-sensitive relative paths")
    return value


def _tree_snapshot(root):
    """Reject links/special files before any path-based resource consumer reads."""
    with _open(root, directory=True):
        pass
    rows = []
    for parent, dirs, names in os.walk(root, followlinks=False):
        for name in sorted(dirs + names):
            path = Path(parent) / name
            relative = path.relative_to(root)
            info = path.lstat()
            if _private(relative) or stat.S_ISLNK(info.st_mode) or not (stat.S_ISREG(info.st_mode) or stat.S_ISDIR(info.st_mode)) or (stat.S_ISREG(info.st_mode) and info.st_nlink != 1):
                raise DatabaseOperationError("RESOURCE_SCOPE_DENIED", "Resource contains a linked, sensitive or unsupported entry", path=str(relative))
            rows.append((str(relative), info.st_mode, info.st_size, info.st_mtime_ns, info.st_ino))
            if len(rows) > MAX_CANDIDATE_ENTRIES:
                raise DatabaseOperationError("VALIDATION_LIMIT", "Candidate exceeds bounded validation inventory; use a narrower resource root")
    return object_fingerprint(sorted(rows))


def _safe_contract(spec):
    for key in ("expected_markers", "source_files", "common_markers"):
        for value in spec.get(key, []):
            _safe_relative(value)
    for values in spec.get("consumer_markers", {}).values():
        for value in values:
            _safe_relative(value)
    suffix_sets = [spec.get("runtime_suffix_sets", [])]
    suffix_sets.extend(spec.get("consumer_suffix_sets", {}).values())
    contract = spec.get("validation_contract") or {}
    suffix_sets.append([group.get("suffixes", []) for group in contract.get("any_complete_set", [])])
    for groups in suffix_sets:
        for suffixes in groups:
            for suffix in suffixes:
                if not isinstance(suffix, str) or not suffix or "/" in suffix or "\\" in suffix or suffix in {".", ".."}:
                    raise DatabaseOperationError("RESOURCE_SCOPE_DENIED", "Index suffixes cannot contain directory traversal")
    if contract.get("component_manifest"):
        _safe_relative(contract["component_manifest"])
    for value in contract.get("nonempty_globs", []):
        _safe_relative(value)
    for consumer in contract.get("consumers", {}).values():
        for rule in consumer.get("parameter_files", []):
            _safe_relative(rule["pattern"])


def _descriptor(entry):
    keys = ("type", "root_path", "runtime_entry", "source_files", "purpose", "supported_tools", "documentation",
        "consumer_entrypoints", "common_markers", "consumer_markers", "validation_contract", "runtime_kind",
        "runtime_suffix_sets", "consumer_entrypoint_kinds", "consumer_suffix_sets", "bindings")
    return {"logical_name": entry["resource_id"], "version": entry["version"],
            "expected_markers": entry["marker_files"], **{k: copy.deepcopy(entry[k]) for k in keys if k in entry}}


def _manifest_spec(root, relative, resource_id, consumer):
    """Convert local declarative inventory facts, never model strings, to a spec."""
    path = root / _safe_relative(relative)
    _, text = _content(path)
    import yaml
    value = yaml.safe_load(text)
    if not isinstance(value, dict):
        raise DatabaseOperationError("INVALID_RESOURCE_MANIFEST", "Resource manifest must be a mapping")
    text_schema = {"type": "string", "minLength": 1}
    from microbiome.pipeline.models import resource_binding_schema
    manifest_schema = {"type": "object", "required": ["files", "provenance"],
        "anyOf": [{"required": ["consumer_entrypoints", "consumer_entrypoint_kinds"]}, {"required": ["bindings"]}],
        "properties": {"files": {"type": "array", "minItems": 1, "maxItems": MAX_CANDIDATE_ENTRIES,
            "items": {"anyOf": [text_schema, {"type": "object", "required": ["path"], "properties": {
                "path": text_schema, "sha256": {"type": "string", "pattern": "^[a-f0-9]{64}$"}}}]}},
            "consumer_entrypoints": {"type": "object", "minProperties": 1, "additionalProperties": text_schema},
            "consumer_entrypoint_kinds": {"type": "object", "additionalProperties": {"enum": ["file", "directory", "index_prefix"]}},
            "bindings": {"type": "object", "minProperties": 1, "additionalProperties": resource_binding_schema()}}}
    errors = list(Draft202012Validator(manifest_schema).iter_errors(value))
    if errors:
        raise DatabaseOperationError("INVALID_RESOURCE_MANIFEST", "Local resource metadata does not satisfy its declared format",
            field_errors=[{"field": list(error.absolute_path), "issue": error.message} for error in errors])
    identity = value.get("resource_id", value.get("logical_name"))
    version = value.get("version", value.get("release"))
    entries = value.get("consumer_entrypoints", {})
    kinds = value.get("consumer_entrypoint_kinds", {})
    bindings = value.get("bindings", {})
    files = value.get("files")
    if identity != resource_id or not isinstance(version, (str, int, float, date)) or isinstance(version, bool) or str(version).strip().upper() in {"", "UNKNOWN", "UNSPECIFIED"} or not value.get("provenance") or not isinstance(files, list) or not files or not isinstance(entries, dict) or not (consumer in entries or any(binding["consumer"] == consumer for binding in bindings.values())):
        raise DatabaseOperationError("INCOMPLETE_RESOURCE_MANIFEST", "Manifest needs matching resource_id, known version/release, provenance, files and an explicit consumer entrypoint",
            manifest_path=str(path), next_action={"action": "inspect_candidate_manifest", "relative_manifest": relative})
    markers = []
    for item in files:
        component = _safe_relative(item.get("path") if isinstance(item, dict) else item)
        target = root / component
        with _open(target) as (fd, info):
            if not info.st_size:
                raise DatabaseOperationError("INCOMPLETE_RESOURCE", "Resource component is empty", component=component)
            expected = item.get("sha256") if isinstance(item, dict) else None
            if expected:
                digest = hashlib.sha256()
                while chunk := os.read(fd, 1024 * 1024):
                    digest.update(chunk)
                if digest.hexdigest() != expected:
                    raise DatabaseOperationError("CORRUPT_RESOURCE", "Component checksum disagrees with its local manifest", component=component)
        markers.append(component)
    for name, entrypoint in entries.items():
        _safe_relative(entrypoint)
        if kinds.get(name) not in {"file", "directory", "index_prefix"}:
            raise DatabaseOperationError("INCOMPLETE_CONSUMER_CONTRACT", "Manifest must declare each consumer entrypoint kind", consumer=name)
        if kinds[name] == "file" and entrypoint not in markers:
            raise DatabaseOperationError("INCOMPLETE_CONSUMER_CONTRACT", "Consumer file must be included in the component inventory", consumer=name)
    for name, binding in bindings.items():
        _safe_relative(binding["entrypoint"])
        if binding["kind"] == "file" and binding["entrypoint"] not in markers:
            raise DatabaseOperationError("INCOMPLETE_CONSUMER_CONTRACT", "Binding file must be included in the component inventory", binding_id=name)
    return {"logical_name": resource_id, "root_path": str(root), "runtime_entry": str(root), "version": str(version),
        "expected_markers": list(dict.fromkeys([relative, *markers])), "runtime_kind": "directory",
        "supported_tools": sorted(set(entries) | {binding["consumer"] for binding in bindings.values()}), "consumer_entrypoints": entries,
        "consumer_entrypoint_kinds": kinds, "consumer_suffix_sets": value.get("consumer_suffix_sets", {}),
        "validation_contract": value.get("validation_contract", {}), "source_files": markers,
        "documentation": [str(path)], **({"bindings": bindings} if bindings else {})}, {"kind": "local_resource_manifest", "path": str(path), "version": str(version)}


def _version_evidence(root, spec, origin):
    source = (spec.get("validation_contract") or {}).get("component_manifest")
    if source:
        runtime = Path(str(spec.get("runtime_entry") or root).replace("{root_path}", str(root)))
        runtime = runtime if runtime.is_absolute() else root / runtime
        target = runtime / _safe_relative(source)
        if not target.is_relative_to(root):
            raise DatabaseOperationError("RESOURCE_SCOPE_DENIED", "Version evidence must be within the candidate")
        _, text = _content(target)
        import yaml
        metadata = yaml.safe_load(text)
        actual = metadata.get("version", metadata.get("release")) if isinstance(metadata, dict) else None
        if actual is not None and str(actual) == str(spec.get("version")):
            return {"kind": origin, "version": str(actual), "version_observed": True, "path": str(target)}
    return {"kind": origin, "version": spec.get("version"), "version_observed": False}


def _plan_steps(project):
    if project.plan_path.is_file():
        from microbiome.pipeline.lifecycle import load_plan
        return load_plan(project)["steps"], "saved_plan"
    state_path = project.state_dir / "conversation.json"
    if state_path.is_file():
        state = read_json(state_path)
        draft = state.get("draft") or {}
        return draft.get("plan", {}).get("steps", []), "pending_draft"
    return [], "missing"


def _find_spec(project, root, resource_id, consumer, manifest=None):
    if manifest or (root / "resource-manifest.json").is_file():
        spec, evidence = _manifest_spec(root, manifest or "resource-manifest.json", resource_id, consumer)
        return spec, {"tool": consumer, "parameters": {}, "command_template": []}, evidence
    entry = _registry(project)["resources"].get(resource_id)
    if entry:
        return _descriptor(entry), {"tool": consumer, "parameters": {}, "command_template": []}, {"kind": "validated_registry"}
    steps, origin = _plan_steps(project)
    found = []
    for step in steps:
        if step.get("tool") != consumer:
            continue
        for alias, spec in step.get("database", {}).items():
            if isinstance(spec, dict) and str(spec.get("logical_name") or alias) == resource_id:
                found.append((spec, step))
    if not found:
        raise DatabaseOperationError("CONTRACT_REQUIRED", "No local resource manifest or saved consumer contract is available",
            next_action={"operation": "list_directory", "arguments": {"root": "database", "path": str(root.relative_to(Path(project.load_config()["paths"]["database"]))) }},
            required_evidence=["version source", "complete required components", "consumer runtime entry and kind"],
            user_configuration_required=False)
    if len({object_fingerprint({k: v for k, v in spec.items() if k != "binding_id"}) for spec, _ in found}) != 1:
        raise DatabaseOperationError("AMBIGUOUS_RESOURCE_CONTRACT", "Saved steps disagree on the resource contract")
    spec, step = found[0]
    spec = {**copy.deepcopy(spec), "logical_name": resource_id}
    if len({candidate.get("binding_id") for candidate, _ in found}) > 1:
        spec.pop("binding_id", None)
    return spec, step, _version_evidence(root, spec, origin)


def _resolve(project, root, spec, step):
    from microbiome.pipeline.models import validate_database_mapping
    validate_database_mapping({"candidate": spec}, "database_validation")
    _safe_contract(spec)
    consumer = step["tool"]
    if str(spec.get("version", "UNKNOWN")).strip().upper() in {"", "UNKNOWN", "UNSPECIFIED"}:
        raise DatabaseOperationError("UNKNOWN_RESOURCE_VERSION", "A known version is needed for reusable validation; dates and release tags are supported")
    resolver = DatabaseResolver(project.load_config()["paths"]["database"])
    normalized = resolver._normalize(spec["logical_name"], spec)
    from microbiome.pipeline.resources import select_database_binding
    selected = select_database_binding(normalized, consumer, normalized.get("binding_id"))
    if selected["kind"] not in {"directory", "file", "index_prefix"} or not (
            selected["binding_id"] or consumer in spec.get("consumer_entrypoints", {})):
        raise DatabaseOperationError("INCOMPLETE_CONSUMER_CONTRACT", "Resource needs an explicit consumer runtime entry and kind", consumer=consumer)
    if normalized["root_path"] != root:
        raise DatabaseOperationError("CANDIDATE_CONTRACT_MISMATCH", "Candidate root differs from the resource contract")
    before = _tree_snapshot(root)
    observed = resolver.resolve_plan([{**step, "database": {"candidate": spec}}], require_ready=False)[spec["logical_name"]]
    if before != _tree_snapshot(root):
        raise DatabaseOperationError("SNAPSHOT_CHANGED", "Database changed during validation; repeat discovery/validation")
    if observed["status"] != "READY":
        raise DatabaseOperationError("INCOMPLETE_RESOURCE", "Candidate failed its complete consumer contract", observation=observed)
    if observed.get("fingerprint", {}).get("root_inventory", {}).get("inventory_truncated"):
        raise DatabaseOperationError("VALIDATION_LIMIT", "Resource inventory exceeds the full fingerprint limit; use a narrower consumer resource root")
    return observed


def _validate(project, arguments):
    root = _candidate_path(project, arguments["candidate_id"])
    _tree_snapshot(root)
    spec, step, provenance = _find_spec(project, root, arguments["resource_id"], arguments["consumer"], arguments.get("manifest"))
    if "binding_id" in arguments:
        spec["binding_id"] = arguments["binding_id"]
    observed = _resolve(project, root, spec, step)
    if provenance.get("version_observed") is False:
        raise DatabaseOperationError("VERSION_EVIDENCE_REQUIRED", "A plan declaration is not evidence of the resource version; inspect existing local metadata",
                                     proposed_descriptor=spec, next_action={"operation": "discover", "arguments": {"path": str(root.relative_to(Path(project.load_config()["paths"]["database"])))}})
    revision = _registry(project)["manifest_fingerprint"]
    receipt = {"schema_version": 1, "project": str(project.root), "candidate_id": arguments["candidate_id"],
        "resource_id": arguments["resource_id"], "consumer": arguments["consumer"], "registry_revision": revision,
        "descriptor": spec, "step_context": {k: step.get(k, {}) if k == "parameters" else step.get(k, []) for k in ("parameters", "command_template")},
        "observation": observed, "provenance": provenance, "manifest": arguments.get("manifest") or ("resource-manifest.json" if provenance["kind"] == "local_resource_manifest" else None)}
    validation_id = object_fingerprint(receipt)
    from microbiome.pipeline.maintenance import _save
    _save(project.state_dir / "database" / "validations" / f"{validation_id}.json", receipt)
    return {"status": "VALIDATED_UNBOUND", "validation_id": validation_id, "registry_revision": revision,
        "resource_id": arguments["resource_id"], "consumer": arguments["consumer"], "proposed_descriptor": spec,
        "fingerprint": object_fingerprint(observed["fingerprint"]), "provenance": provenance,
        "next_action": {"operation": "bind", "arguments": {"validation_id": validation_id, "registry_revision": revision},
                        "requires": "current dependency approval covering this exact resource in BOOTSTRAP or PRETEST_REPAIR"}}


def database_permissions(project):
    """Read-only capability snapshot; binding rechecks approval under its lock."""
    from microbiome.pipeline.dependencies import require_bootstrap_approval
    from microbiome.pipeline.lifecycle import load_plan
    project = project if isinstance(project, PipelineProject) else PipelineProject(project)
    phase = ProjectStateMachine(project).current
    frozen = project.pipeline_lock_path.exists() or project.pipeline_lock_path.is_symlink() or phase in {
        LifecycleState.FROZEN, LifecycleState.PRETEST_PASSED, LifecycleState.VALIDATED,
        LifecycleState.PRETEST_FINALIZING, LifecycleState.PIPELINE_LOCK_VALIDATING,
        LifecycleState.PRODUCTION_READY, LifecycleState.AWAITING_PRODUCTION_APPROVAL,
        LifecycleState.PRODUCTION_APPROVED, LifecycleState.PRODUCTION_PREFLIGHT,
        LifecycleState.PRODUCTION_RUNNING, LifecycleState.PRODUCTION_FAILED, LifecycleState.COMPLETED}
    phase_allowed = not frozen and phase in {LifecycleState.BOOTSTRAP, LifecycleState.PRETEST_REPAIR}
    approved = False
    reason = "FROZEN_RESOURCE_MUTATION_DENIED" if frozen else "RESOURCE_PHASE_DENIED"
    if phase_allowed:
        try:
            require_bootstrap_approval(project, load_plan(project),
                allowed_states=(LifecycleState.BOOTSTRAP, LifecycleState.PRETEST_REPAIR))
            approved = True
            reason = "VALIDATED_CANDIDATE_AND_CURRENT_SCOPE_REQUIRED"
        except (ConfigurationError, OSError, KeyError, TypeError):
            reason = "CURRENT_DEPENDENCY_APPROVAL_REQUIRED"
    return {"phase": phase.value, "frozen_contract": frozen, "discover": True, "inspect": True,
        "validate": True, "bind": phase_allowed and approved, "bind_phase_allowed": phase_allowed,
        "current_dependency_approval": approved, "reason": reason,
        "validation_writes": "controller validation receipts only",
        "binding_scope": "matching resource and consumer in the currently approved dependency plan",
        "lock_required": True, "snapshot_is_authorization": False}


def _bind(project, arguments, source):
    from microbiome.pipeline.dependencies import require_bootstrap_approval
    from microbiome.pipeline.lifecycle import load_plan
    from microbiome.pipeline.maintenance import _read_json, _save
    policy = database_permissions(project)
    if policy["frozen_contract"]:
        raise DatabaseOperationError("FROZEN_RESOURCE_MUTATION_DENIED", "Frozen production cannot change database bindings")
    phase = ProjectStateMachine(project).current
    if not policy["bind_phase_allowed"]:
        raise DatabaseOperationError("RESOURCE_PHASE_DENIED", "Binding requires BOOTSTRAP or PRETEST_REPAIR", phase=phase.value)
    plan = load_plan(project)
    require_bootstrap_approval(project, plan, allowed_states=(LifecycleState.BOOTSTRAP, LifecycleState.PRETEST_REPAIR))
    receipt_path = project.state_dir / "database" / "validations" / f"{arguments['validation_id']}.json"
    if not receipt_path.exists():
        raise DatabaseOperationError("VALIDATION_RECEIPT_NOT_FOUND", "Validate the candidate before attempting to bind it",
                                     next_action={"operation": "discover", "arguments": {}})
    receipt = _read_json(receipt_path)
    if object_fingerprint(receipt) != arguments["validation_id"] or receipt.get("project") != str(project.root):
        raise DatabaseOperationError("INVALID_VALIDATION_RECEIPT", "Validation receipt was changed or belongs to another project")
    if arguments["registry_revision"] != receipt["registry_revision"]:
        raise DatabaseOperationError("STALE_REGISTRY_REVISION", "Binding revision must match its validation receipt")
    matched = []
    for step in plan["steps"]:
        if step["tool"] != receipt["consumer"]:
            continue
        for alias, spec in step.get("database", {}).items():
            if str(spec.get("logical_name") or alias) == receipt["resource_id"]:
                matched.append((spec, step))
    if not matched:
        raise DatabaseOperationError("DEPENDENCY_SCOPE_REQUIRED", "Resource and consumer are not in the current approved dependency plan",
            next_action={"action": "revise_dependency_plan", "resource_id": receipt["resource_id"]})
    root = _candidate_path(project, receipt["candidate_id"])
    if receipt.get("manifest"):
        spec, provenance = _manifest_spec(root, receipt["manifest"], receipt["resource_id"], receipt["consumer"])
        if "binding_id" in receipt["descriptor"]:
            spec["binding_id"] = receipt["descriptor"]["binding_id"]
        if spec != receipt["descriptor"]:
            raise DatabaseOperationError("STALE_VALIDATION", "Resource manifest changed after validation")
    observations = [_resolve(project, root, spec, step) for spec, step in matched]
    expected = receipt["observation"]
    for observed in observations:
        if {k: v for k, v in observed.items() if k not in {"size"}} != {k: v for k, v in expected.items() if k not in {"size"}}:
            raise DatabaseOperationError("STALE_VALIDATION", "Approved resource contract or files differ from the validated candidate; validate again")
    registry = _registry(project)
    registered = registry["resources"].get(receipt["resource_id"])
    if registered and registered.get("status") == "READY" and _descriptor(registered) == _descriptor_from_observation(expected) and registered.get("fingerprint") == expected["fingerprint"]:
        return {"status": "REUSED_READY", "resource_id": receipt["resource_id"], "registry_revision": registry["manifest_fingerprint"], "registry_changed": False}
    if registered and registered.get("status") == "READY":
        raise DatabaseOperationError("RESOURCE_DRIFT", "An existing READY binding cannot be replaced or weakened; use a separately approved resource identity")
    if registry["manifest_fingerprint"] != receipt["registry_revision"]:
        raise DatabaseOperationError("STALE_REGISTRY_REVISION", "Registry changed after validation; revalidate against the current registry")
    updated, _, events = update_database_registry(project.database_registry_path,
        database_root=project.load_config()["paths"]["database"], resolved={receipt["resource_id"]: expected})
    from microbiome.pipeline.registry import generate_resource_catalog
    generate_resource_catalog(project)
    result = {"source": source, "status": "REGISTERED_READY", "resource_id": receipt["resource_id"], "registry_revision": updated["manifest_fingerprint"], "registry_changed": True, "events": events}
    _save(project.state_dir / "database" / "bindings" / f"{arguments['validation_id']}.json", result)
    return result


def _descriptor_from_observation(observed):
    from microbiome.pipeline.registry import _database_contract
    return _descriptor(_database_contract(observed))


def expand_resource_references(project, plan):
    """Expand authoring resources using verified facts; never register candidates."""
    from microbiome.pipeline.models import database_mapping_schema, resource_authoring_schema
    project = project if isinstance(project, PipelineProject) else PipelineProject(project)
    result = copy.deepcopy(plan)
    declarations = result.pop("resources", None)
    if declarations is not None:
        errors = list(Draft202012Validator(resource_authoring_schema()).iter_errors(declarations))
        if errors:
            raise DatabaseOperationError("INVALID_RESOURCE_DECLARATION", "plan.resources must distinguish registered resources, validated candidates and unresolved requirements",
                field_errors=[{"field": list(error.absolute_path), "issue": error.message} for error in errors])
    declarations = declarations or {}
    registry = None
    used = set()
    candidates = {}
    reference_validator = Draft202012Validator(database_mapping_schema(allow_references=True))

    def validate_reference(alias, reference):
        errors = list(reference_validator.iter_errors({alias: reference}))
        if errors:
            raise DatabaseOperationError("INVALID_RESOURCE_REFERENCE", "Resource references must satisfy the published authoring schema",
                field_errors=[{"field": list(error.absolute_path), "issue": error.message} for error in errors])

    for step in result.get("steps", []):
        for alias, raw_reference in list(step.get("database", {}).items()):
            if not isinstance(raw_reference, dict):
                continue
            reference = raw_reference
            if "resource" in reference:
                if not {"resource"} <= set(reference) <= {"resource", "binding_id"}:
                    raise DatabaseOperationError("RESOURCE_REFERENCE_OVERRIDE", "A named reference may contain only resource and binding_id")
                validate_reference(alias, reference)
                name = reference["resource"]
                if name not in declarations:
                    raise DatabaseOperationError("RESOURCE_DECLARATION_MISSING", f"Named resource {name!r} is not declared")
                used.add(name)
                declaration = declarations[name]
                if declaration["source"] == "unresolved_requirement":
                    raise DatabaseOperationError("RESOURCE_REQUIREMENT_UNRESOLVED", "Resource evidence is still unresolved; discover and validate a candidate before compiling an executable plan",
                        resource=name, next_action={"operation": "discover", "arguments": {}}, user_configuration_required=False)
                if declaration["source"] == "validated_candidate":
                    validation_id = declaration["validation_id"]
                    if validation_id not in candidates:
                        from microbiome.pipeline.maintenance import _read_json
                        path = project.state_dir / "database" / "validations" / f"{validation_id}.json"
                        if not path.is_file():
                            raise DatabaseOperationError("VALIDATION_RECEIPT_NOT_FOUND", "Candidate reference needs an existing validation receipt")
                        receipt = _read_json(path)
                        if object_fingerprint(receipt) != validation_id or receipt.get("project") != str(project.root):
                            raise DatabaseOperationError("INVALID_VALIDATION_RECEIPT", "Candidate receipt does not match this project")
                        registry = registry or _registry(project)
                        if receipt["registry_revision"] != registry["manifest_fingerprint"]:
                            raise DatabaseOperationError("STALE_REGISTRY_REVISION", "Candidate validation predates the current registry; validate again")
                        if receipt["resource_id"] in registry["resources"]:
                            raise DatabaseOperationError("RESOURCE_SOURCE_CONFLICT", "Use a registered reference for a resource that already has a registry identity")
                        candidates[validation_id] = receipt
                    receipt = candidates[validation_id]
                    spec = copy.deepcopy(receipt["descriptor"])
                    # A receipt establishes resource evidence. This step still
                    # selects and revalidates its own declared consumer binding.
                    spec.pop("binding_id", None)
                    if "binding_id" in reference:
                        spec["binding_id"] = reference["binding_id"]
                    root = _candidate_path(project, receipt["candidate_id"])
                    observed = _resolve(project, root, spec, step)
                    if observed["fingerprint"] != receipt["observation"]["fingerprint"]:
                        raise DatabaseOperationError("STALE_VALIDATION", "Candidate files changed since validation")
                    step["database"][alias] = spec
                    continue
                reference = {"resource_id": declaration["resource_id"], "fingerprint": declaration["fingerprint"],
                    "consumer": step.get("tool"), **({"binding_id": reference["binding_id"]} if "binding_id" in reference else {})}
            if "resource_id" not in reference:
                continue
            if not {"resource_id", "fingerprint", "consumer"} <= set(reference) <= {"resource_id", "fingerprint", "consumer", "binding_id"}:
                raise DatabaseOperationError("RESOURCE_REFERENCE_OVERRIDE", "Resource reference may contain only resource_id, fingerprint and consumer, with an optional binding_id")
            validate_reference(alias, reference)
            registry = registry or _registry(project)
            entry = registry["resources"].get(reference["resource_id"])
            if not entry or entry.get("status") != "READY":
                raise DatabaseOperationError("RESOURCE_NOT_READY", "Referenced resource is not registered READY")
            if reference["fingerprint"] != object_fingerprint(entry["fingerprint"]):
                raise DatabaseOperationError("STALE_RESOURCE_REFERENCE", "Reference does not match the current registry fingerprint")
            if reference["consumer"] != step.get("tool"):
                raise DatabaseOperationError("CONSUMER_MISMATCH", "Reference must match this step's registered consumer")
            spec = _descriptor(entry)
            if "binding_id" in reference:
                spec["binding_id"] = reference["binding_id"]
            observed = _resolve(project, Path(entry["root_path"]), spec, step)
            if observed["fingerprint"] != entry["fingerprint"]:
                raise DatabaseOperationError("RESOURCE_DRIFT", "Registered resource files have changed; explicit maintenance is required")
            step["database"][alias] = spec
    pending = [name for name in sorted(set(declarations) - used)
               if declarations[name]["source"] == "unresolved_requirement"]
    if pending:
        raise DatabaseOperationError("RESOURCE_REQUIREMENT_UNRESOLVED", "Unresolved resource requirements must remain visible before compiling an executable plan",
            resources=pending, next_action={"operation": "discover", "arguments": {}}, user_configuration_required=False)
    return result


def database_operation(project, operation, arguments=None, *, user_message="", message_id="", session_id="default"):
    arguments = validate_database_request(operation, {} if arguments is None else arguments)
    project = project if isinstance(project, PipelineProject) else PipelineProject(project)
    project.load_config()
    if operation == "discover":
        page = list_directory(project, {"root": "database", **arguments})
        for entry in page["entries"]:
            if entry.get("kind") == "directory":
                entry["candidate_id"] = _candidate_id(project, str(Path(arguments.get("path", ".")) / entry["name"]))
                entry["status"] = "DISCOVERED_UNVALIDATED"
        return {**page, "candidate_id": _candidate_id(project, arguments.get("path", ".")), "status": "DISCOVERED_UNVALIDATED"}
    if operation == "inspect":
        registry = _registry(project)
        resources = registry["resources"]
        if arguments.get("resource_id"):
            resources = {k: v for k, v in resources.items() if k == arguments["resource_id"]}
        records = []
        for key, entry in sorted(resources.items()):
            choices = [{"consumer": binding["consumer"], "binding_id": name}
                       for name, binding in sorted(entry.get("bindings", {}).items())]
            bound_consumers = {choice["consumer"] for choice in choices}
            choices.extend({"consumer": consumer} for consumer in entry.get("consumer_entrypoints", {})
                           if consumer not in bound_consumers)
            for choice in choices or [{"consumer": None}]:
                reference = {"resource_id": key, "fingerprint": object_fingerprint(entry.get("fingerprint")), **choice}
                records.append({**entry, "reference": reference if choice["consumer"] and entry.get("status") == "READY" else None})
        page = page_records(records, {"limit": 20, **arguments},
                            binding=["database_registry", str(project.root), arguments.get("resource_id")])
        return {"registry_revision": registry["manifest_fingerprint"], "resources": page.pop("entries"),
                **page, "filesystem_revalidated": False}
    with project_operation_lock(project, reentrant=True):
        if operation == "validate":
            return _validate(project, arguments)
        return _bind(project, arguments, {"session_id": session_id, "message_id": message_id, "user_message_sha256": hashlib.sha256(user_message.encode()).hexdigest()})
