"""Plan and dependency confirmation gates before any bootstrap mutation."""

from __future__ import annotations

import os
import shutil
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from microbiome.pipeline.errors import ConfigurationError, ResourceNotReadyError
from microbiome.pipeline.io import canonical_path, fast_file_fingerprint, object_fingerprint, read_yaml, write_yaml
from microbiome.pipeline.lifecycle import load_plan
from microbiome.pipeline.registry import load_database_registry, load_tool_registry
from microbiome.pipeline.requirements import ConfirmationAction, RequirementManager
from microbiome.pipeline.state import LifecycleState, ProjectStateMachine

if TYPE_CHECKING:
    from microbiome.pipeline.project import PipelineProject


def _utcnow() -> str:
    return datetime.now(UTC).isoformat()


def confirm_plan(project: PipelineProject, action: ConfirmationAction, *,
                 decision_source: dict[str, Any] | None = None) -> dict[str, Any]:
    machine = ProjectStateMachine(project)
    machine.require(LifecycleState.PLAN_CONFIRMATION)
    plan = load_plan(project)
    requirements = RequirementManager(project).require_confirmed()
    payload = {
        "status": action.value,
        "confirmed_at": _utcnow(),
        "requirements_version": requirements["requirements_version"],
        "plan_fingerprint": plan["plan_fingerprint"],
    }
    if decision_source is not None:
        payload["source"] = decision_source
    RequirementManager(project).set_approval("analysis_plan", payload)
    if action is ConfirmationAction.CONFIRM:
        machine.transition(LifecycleState.DEPENDENCY_REVIEW, reason="analysis plan explicitly confirmed")
    elif action is ConfirmationAction.MODIFY:
        machine.transition(LifecycleState.PLAN_DRAFTING, reason="user requested plan modification")
    else:
        machine.transition(LifecycleState.CANCELLED, reason="user cancelled analysis plan")
    return payload


class DependencyResolver:
    def __init__(self, project: PipelineProject):
        self.project = project
        self.report_path = project.plans_dir / "dependency_gap_report.yaml"

    @staticmethod
    def _configured_executable(step: dict[str, Any]) -> Path | None:
        environment = step.get("environment")
        configured = environment.get("executable") if isinstance(environment, dict) else None
        executable = str(configured or step["tool"])
        if Path(executable).is_absolute():
            path = canonical_path(executable)
            return path if path.is_file() and os.access(path, os.X_OK) else None
        if isinstance(environment, dict) and environment.get("prefix"):
            candidate = canonical_path(environment["prefix"]) / "bin" / executable
            if candidate.is_file() and os.access(candidate, os.X_OK):
                return candidate
        found = shutil.which(executable)
        return canonical_path(found, must_exist=True) if found else None

    def review(self, *, preview_plan: dict[str, Any] | None = None) -> dict[str, Any]:
        machine = ProjectStateMachine(self.project)
        if preview_plan is not None:
            self.report_path = self.project.plans_dir / "dependency_preview.yaml"
        if preview_plan is None:
            machine.require(LifecycleState.DEPENDENCY_REVIEW)
        requirements = (RequirementManager(self.project).require_confirmed() if preview_plan is None
                        else RequirementManager(self.project).load())
        plan = load_plan(self.project) if preview_plan is None else preview_plan
        approval = requirements.get("approvals", {}).get("analysis_plan", {})
        if preview_plan is None and (
            approval.get("status") != ConfirmationAction.CONFIRM.value
            or approval.get("plan_fingerprint") != plan["plan_fingerprint"]
            or approval.get("requirements_version") != requirements["requirements_version"]
        ):
            raise ConfigurationError("dependency review requires the current analysis plan to be explicitly confirmed")

        tool_registry = load_tool_registry(self.project.tool_registry_path)
        database_registry = load_database_registry(
            self.project.database_registry_path,
            database_root=requirements["paths"]["database_root"],
        )
        from microbiome.resource_skills.resolver import ToolResolver

        resolver = ToolResolver(
            self.project.root,
            phase="BOOTSTRAP",
            approved_tools=set(),
            project=self.project,
            mutable=False,
        )
        tools: list[dict[str, Any]] = []
        databases: list[dict[str, Any]] = []
        from microbiome.pipeline.resources import DatabaseResolver
        local_databases = DatabaseResolver(requirements["paths"]["database_root"]).resolve_plan(
            plan["steps"], require_ready=False)
        for step in plan["steps"]:
            registered = tool_registry["tools"].get(step["step_id"])
            probe_error = None
            try:
                discovered = resolver.probe_step(step)
            except ResourceNotReadyError as error:
                discovered = None
                probe_error = str(error)
            alias = resolver.alias_registry.resolve(step["tool"]) or {}
            request = resolver.dependency_request(step)
            package_candidates = request["package_candidates"]
            if registered and Path(registered["executable"]).is_file() and discovered:
                status = "READY"
                reason = "validated tool contract already exists"
                executable_path = discovered["executable"]
            elif discovered:
                status = "READY"
                reason = "existing executable discovered and smoke-tested; Skill/Registry writeback is pending"
                executable_path = discovered["executable"]
            elif package_candidates:
                status = "NEEDS_INSTALL"
                reason = (
                    "no validated executable is available; declared package mapping requires installation approval"
                )
                executable_path = None
            else:
                status = "NEEDS_PACKAGE_MAPPING"
                reason = "no executable or verified package mapping is available"
                executable_path = None
            tools.append(
                {
                    "step_id": step["step_id"],
                    "tool": step["tool"],
                    "status": status,
                    "reason": reason,
                    "executable": executable_path,
                    "environment": step["environment"],
                    "version": discovered.get("version_output") if discovered else None,
                    "resolved_environment": discovered.get("environment_prefix") if discovered else None,
                    "executable_fingerprint": fast_file_fingerprint(executable_path) if executable_path else None,
                    "software_family": request["software_family"],
                    "package_candidates": package_candidates,
                    "required_packages": request["required_packages"],
                    "channels": request["channels"],
                    "installation_request": request,
                    "skill_id": alias.get("skill_id"),
                    "probe_error": probe_error,
                }
            )
            for alias, spec in step.get("database", {}).items():
                resource_id = str(spec.get("logical_name") or alias)
                resource = database_registry["resources"].get(resource_id)
                observed = local_databases.get(resource_id, {})
                if observed.get("status") == "READY" and (
                    not resource or resource.get("fingerprint") == observed.get("fingerprint")
                ):
                    db_status = "READY"
                elif resource and resource.get("status") == "READY":
                    db_status = "NEEDS_REPAIR"
                elif resource and resource.get("status") == "INCOMPLETE":
                    db_status = "NEEDS_INDEX_BUILD"
                elif resource and resource.get("status") in {"CORRUPT", "UNKNOWN"}:
                    db_status = "NEEDS_REPAIR"
                else:
                    db_status = "NEEDS_DATABASE"
                databases.append(
                    {
                        "step_id": step["step_id"],
                        "alias": alias,
                        "resource_id": resource_id,
                        "status": db_status,
                        "path": observed.get("runtime_entry") or observed.get("path"),
                        "observed_status": observed.get("status"),
                        "specification": spec,
                        "fingerprint": observed.get("fingerprint"),
                    }
                )
        scope = {
            "acquisitions": plan.get("dependency_acquisitions", {}),
            "manager_bootstrap": plan.get("manager_bootstrap"),
            "tools": [
                {
                    "step_id": item["step_id"],
                    "tool": item["tool"],
                    "status": item["status"],
                    "package_candidates": item["package_candidates"],
                    "installation_request": item["installation_request"],
                    "executable": item["executable"],
                    "environment": item["environment"],
                    "version": item["version"],
                    "resolved_environment": item["resolved_environment"],
                    "executable_fingerprint": item["executable_fingerprint"],
                }
                for item in tools
            ],
            "databases": [
                {
                    "step_id": item["step_id"],
                    "resource_id": item["resource_id"],
                    "status": item["status"],
                    "path": item["path"],
                    "specification": item["specification"],
                    "fingerprint": item["fingerprint"],
                }
                for item in databases
            ],
        }
        previous_version = 0
        previous_scope = None
        if self.report_path.is_file():
            try:
                previous = read_yaml(self.report_path)
                previous_version = int(previous.get("dependency_plan_version", 1))
                previous_scope = previous.get("scope_fingerprint")
            except Exception:
                previous_version = 0
        scope_fingerprint = object_fingerprint(scope)
        payload = {
            "schema_version": 1,
            "dependency_plan_version": (
                max(1, previous_version) if previous_scope == scope_fingerprint else previous_version + 1
            ),
            "generated_at": _utcnow(),
            "requirements_version": requirements["requirements_version"],
            "plan_fingerprint": plan["plan_fingerprint"],
            "tools": tools,
            "databases": databases,
            "scope_fingerprint": scope_fingerprint,
            "summary": {
                status: sum(item["status"] == status for item in [*tools, *databases])
                for status in (
                    "READY",
                    "NEEDS_INSTALL",
                    "NEEDS_PACKAGE_MAPPING",
                    "NEEDS_DATABASE",
                    "NEEDS_INDEX_BUILD",
                    "NEEDS_REPAIR",
                )
            },
        }
        payload["report_fingerprint"] = object_fingerprint(
            {key: item for key, item in payload.items() if key != "report_fingerprint"}
        )
        write_yaml(self.report_path, payload)
        if preview_plan is None:
            machine.transition(LifecycleState.INSTALL_APPROVAL, reason="dependency gap report generated")
        return payload

    def approve(self, action: ConfirmationAction, *,
                decision_source: dict[str, Any] | None = None) -> dict[str, Any]:
        machine = ProjectStateMachine(self.project)
        machine.require(LifecycleState.INSTALL_APPROVAL)
        if not self.report_path.is_file():
            raise ConfigurationError("dependency gap report is missing")
        report = read_yaml(self.report_path)
        if report.get("report_fingerprint") != object_fingerprint({k: v for k, v in report.items() if k != "report_fingerprint"}):
            raise ConfigurationError("dependency report fingerprint is invalid")
        requirements = RequirementManager(self.project).require_confirmed()
        if report.get("plan_fingerprint") != load_plan(self.project)["plan_fingerprint"] or report.get("requirements_version") != requirements["requirements_version"]:
            raise ConfigurationError("dependency report is stale")
        payload = {
            "status": action.value,
            "confirmed_at": _utcnow(),
            "requirements_version": requirements["requirements_version"],
            "plan_fingerprint": report["plan_fingerprint"],
            "dependency_report_fingerprint": report["report_fingerprint"],
            "dependency_plan_version": report.get("dependency_plan_version", 1),
            "dependency_scope_fingerprint": report.get("scope_fingerprint"),
        }
        if decision_source is not None:
            payload["source"] = decision_source
        RequirementManager(self.project).set_approval("dependencies", payload)
        if action is ConfirmationAction.CONFIRM:
            machine.transition(LifecycleState.BOOTSTRAP, reason="dependency plan explicitly approved")
        elif action is ConfirmationAction.MODIFY:
            machine.transition(LifecycleState.DEPENDENCY_REVIEW, reason="dependency plan modification requested")
        else:
            machine.transition(LifecycleState.CANCELLED, reason="dependency preparation cancelled")
        return payload


def require_bootstrap_approval(
    project: PipelineProject,
    plan: dict[str, Any],
    *,
    allowed_states: tuple[LifecycleState, ...] = (LifecycleState.BOOTSTRAP,),
) -> dict[str, Any]:
    requirements = RequirementManager(project).require_confirmed()
    report_path = project.plans_dir / "dependency_gap_report.yaml"
    if not report_path.is_file():
        raise ConfigurationError("bootstrap requires the current dependency gap report")
    report = read_yaml(report_path)
    if report.get("report_fingerprint") != object_fingerprint({k: v for k, v in report.items() if k != "report_fingerprint"}):
        raise ConfigurationError("dependency report changed after approval")
    approval = requirements.get("approvals", {}).get("dependencies", {})
    if (
        approval.get("status") != ConfirmationAction.CONFIRM.value
        or approval.get("requirements_version") != requirements["requirements_version"]
        or approval.get("plan_fingerprint") != plan["plan_fingerprint"]
        or approval.get("dependency_report_fingerprint") != report.get("report_fingerprint")
        or approval.get("dependency_plan_version") != report.get("dependency_plan_version", 1)
        or approval.get("dependency_scope_fingerprint") != report.get("scope_fingerprint")
        or report.get("plan_fingerprint") != plan["plan_fingerprint"]
        or report.get("requirements_version") != requirements["requirements_version"]
    ):
        raise ConfigurationError("bootstrap requires explicit approval of the current dependency gap report")
    ProjectStateMachine(project).require(*allowed_states)
    return requirements
