"""Explicit planning, bootstrap, and database-resolution phase transitions."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from microbiome.pipeline.io import atomic_write_text, object_fingerprint, read_yaml, write_json, write_yaml
from microbiome.pipeline.models import PipelinePhase, validate_experiment_plan
from microbiome.pipeline.registry import (
    generate_resource_catalog,
    update_database_registry,
    update_tool_registry,
)
from microbiome.pipeline.resources import DatabaseResolver

if TYPE_CHECKING:
    from microbiome.pipeline.project import PipelineProject


def _utcnow() -> str:
    return datetime.now(UTC).isoformat()


def load_plan(project: PipelineProject) -> dict[str, Any]:
    return validate_experiment_plan(read_yaml(project.plan_path))


def save_experiment_plan(project: PipelineProject, plan: dict[str, Any]) -> dict[str, Any]:
    """Validate and persist an editable experimental plan (never a production lock)."""
    from microbiome.pipeline.evidence import EvidenceManager
    from microbiome.pipeline.requirements import RequirementManager
    from microbiome.pipeline.state import LifecycleState, ProjectStateMachine

    machine = ProjectStateMachine(project)
    machine.require(LifecycleState.REQUIREMENTS_CONFIRMED, LifecycleState.REVALIDATION_REQUIRED,
                    LifecycleState.PLAN_DRAFTING, LifecycleState.PLAN_CONFIRMATION)
    requirements = RequirementManager(project).require_confirmed()
    candidate = dict(plan)
    candidate["requirements_version"] = requirements["requirements_version"]
    normalized = validate_experiment_plan(candidate)
    write_yaml(project.plan_path, normalized)
    version = requirements["requirements_version"]
    yaml_path = project.plans_dir / f"analysis_plan_v{version}.yaml"
    markdown_path = project.plans_dir / f"analysis_plan_v{version}.md"
    write_yaml(yaml_path, normalized)
    markdown_lines = [
        f"# Analysis plan v{version}",
        "",
        f"Objective: {normalized['objective']}",
        "",
        f"Plan fingerprint: `{normalized['plan_fingerprint']}`",
        "",
        "## Pipeline DAG",
        "",
    ]
    for step in normalized["steps"]:
        databases = (
            ", ".join(str(spec.get("logical_name") or alias) for alias, spec in step.get("database", {}).items())
            or "none"
        )
        markdown_lines.extend(
            [
                f"### {step['step_id']}",
                "",
                f"- Purpose: {step['purpose']}",
                f"- Tool: {step['tool']} ({step['tool_version_requirement']})",
                f"- Databases: {databases}",
                f"- Dependencies: {', '.join(step['dependencies']) or 'none'}",
                f"- Success assertions: {len(step['success_criteria'])}",
                "",
            ]
        )
    atomic_write_text(markdown_path, "\n".join(markdown_lines))
    EvidenceManager(project).collect_local_plan_evidence(normalized)
    machine = ProjectStateMachine(project)
    if machine.current == LifecycleState.REQUIREMENTS_CONFIRMED:
        machine.advance_to(LifecycleState.PLAN_CONFIRMATION, reason="resources/evidence reviewed and plan persisted")
    elif machine.current == LifecycleState.REVALIDATION_REQUIRED:
        machine.transition(LifecycleState.PLAN_DRAFTING, reason="production failure requires a revised plan")
        machine.transition(LifecycleState.PLAN_CONFIRMATION, reason="revised repair plan persisted")
    elif machine.current == LifecycleState.PLAN_DRAFTING:
        machine.transition(LifecycleState.PLAN_CONFIRMATION, reason="revised plan persisted")
    else:
        machine.require(LifecycleState.PLAN_CONFIRMATION)
    project.set_phase(PipelinePhase.PLANNING)
    return normalized


def bootstrap_toolchain(project: PipelineProject) -> dict[str, Any]:
    """Resolve, approved-install if needed, smoke-test, learn and register tools."""
    project.require_layout()
    plan = load_plan(project)
    from microbiome.pipeline.dependencies import require_bootstrap_approval

    requirements = require_bootstrap_approval(project, plan)
    from microbiome.pipeline.manager_bootstrap import install_approved_manager
    install_approved_manager(project, plan)
    from microbiome.pipeline.io import read_yaml
    from microbiome.pipeline.knowledge import KnowledgeBase
    from microbiome.resource_skills.resolver import ResourceBootstrapManager

    knowledge = KnowledgeBase(project)
    dependency_report = read_yaml(project.plans_dir / "dependency_gap_report.yaml")
    approved_tools = {str(item["tool"]) for item in dependency_report.get("tools", [])}
    approved_databases = {str(item["resource_id"]) for item in dependency_report.get("databases", [])}
    manager = ResourceBootstrapManager(
        project,
        phase=PipelinePhase.BOOTSTRAP.value,
        approved_tools=approved_tools,
        approved_databases=approved_databases,
        knowledge=knowledge,
    )
    tools = manager.resolve_tools(plan["steps"])
    tool_registry = update_tool_registry(project.tool_registry_path, steps=plan["steps"], resolved=tools)
    catalog = generate_resource_catalog(project)
    report = {
        "schema_version": 1,
        "phase": PipelinePhase.BOOTSTRAP.value,
        "status": "PASSED",
        "generated_at": _utcnow(),
        "plan_fingerprint": plan["plan_fingerprint"],
        "requirements_version": requirements["requirements_version"],
        "conda_manager": manager.tool_resolver.discovery.conda_manager,
        "tools": tools,
        "tool_registry": str(project.tool_registry_path),
        "tool_registry_fingerprint": tool_registry["manifest_fingerprint"],
        "resource_catalog": catalog["path"],
    }
    report["report_fingerprint"] = object_fingerprint(report)
    write_json(project.state_dir / "bootstrap_report.json", report)
    project.set_phase(PipelinePhase.BOOTSTRAP)
    return report


def resolve_databases(project: PipelineProject) -> dict[str, Any]:
    """Validate local databases and marker fingerprints; never download them."""
    project.require_layout()
    plan = load_plan(project)
    config = project.load_config()
    from microbiome.pipeline.dependencies import require_bootstrap_approval
    from microbiome.pipeline.state import LifecycleState, ProjectStateMachine

    requirements = require_bootstrap_approval(
        project,
        plan,
        allowed_states=(LifecycleState.BOOTSTRAP, LifecycleState.PRETEST_PREPARATION),
    )
    observed = DatabaseResolver(config["paths"]["database"]).resolve_plan(plan["steps"], require_ready=False)
    database_registry, databases, events = update_database_registry(
        project.database_registry_path,
        database_root=config["paths"]["database"],
        resolved=observed,
    )
    from microbiome.pipeline.knowledge import KnowledgeBase

    knowledge = KnowledgeBase(project)
    from microbiome.resource_skills.registry import PACKAGE_SKILL_ROOT, ResourceSkillRegistry
    from microbiome.resource_skills.resolver import DatabaseSkillBuilder

    skill_registry = ResourceSkillRegistry(
        skill_roots=[PACKAGE_SKILL_ROOT, project.resource_skills_dir],
        db_root=config["paths"]["database"],
        environment_catalog={},
    )
    for resource_id, entry in databases.items():
        knowledge.record_database_profile(resource_id, entry)
        if skill_registry.find_skill("database", resource_id) is None:
            DatabaseSkillBuilder(project.resource_skills_dir).build(resource_id, entry)
            skill_registry.reload()
    catalog = generate_resource_catalog(project)
    report = {
        "schema_version": 1,
        "phase": PipelinePhase.DATABASE_RESOLUTION.value,
        "status": "PASSED",
        "generated_at": _utcnow(),
        "plan_fingerprint": plan["plan_fingerprint"],
        "requirements_version": requirements["requirements_version"],
        "databases": databases,
        "events": events,
        "database_registry": str(project.database_registry_path),
        "database_registry_fingerprint": database_registry["manifest_fingerprint"],
        "resource_catalog": catalog["path"],
    }
    report["report_fingerprint"] = object_fingerprint(report)
    write_json(project.state_dir / "database_resolution.json", report)
    machine = ProjectStateMachine(project)
    if machine.current == LifecycleState.BOOTSTRAP:
        machine.transition(
            LifecycleState.PRETEST_PREPARATION,
            reason="approved toolchain and database contracts are READY",
        )
    project.set_phase(PipelinePhase.DATABASE_RESOLUTION)
    return report
