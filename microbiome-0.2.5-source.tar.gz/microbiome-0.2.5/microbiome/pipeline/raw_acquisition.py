"""Explicit per-record ENA FASTQ acquisition, separate from database preparation."""

from __future__ import annotations

from pathlib import Path
from urllib.parse import urlsplit
import re

import requests

from microbiome.pipeline.errors import ConfigurationError
from microbiome.pipeline.io import object_fingerprint, read_yaml, write_yaml


def preview_manifest_inputs(project, manifest, *, session=None):
    session = session or requests.Session()
    transfers = []
    root = Path(project.load_config()["paths"].get("download", project.load_config()["paths"]["raw_data"]))
    for sample in manifest["samples"]:
        if sample.get("source_type") != "REMOTE_SRA_RUN":
            if sample.get("source_type") == "REMOTE_URL":
                raise ConfigurationError("远程 URL 需要明确大小、校验和及格式后才能加入下载计划。")
            continue
        accession = sample.get("accession", "")
        if not re.fullmatch(r"(?:SRR|ERR|DRR)\d+", accession):
            raise ConfigurationError("remote input requires an explicit run accession")
        response = session.get(
            "https://www.ebi.ac.uk/ena/portal/api/filereport",
            params={
                "accession": accession,
                "result": "read_run",
                "format": "json",
                "fields": "run_accession,library_layout,fastq_ftp,fastq_md5,fastq_bytes",
            },
            timeout=20,
        )
        response.raise_for_status()
        records = response.json()
        records = [row for row in records if row.get("run_accession") == accession]
        if len(records) != 1:
            raise ConfigurationError(f"cannot resolve exact remote record {accession}")
        row = records[0]
        urls = row.get("fastq_ftp", "").split(";")
        checksums = row.get("fastq_md5", "").split(";")
        sizes = row.get("fastq_bytes", "").split(";")
        expected = 2 if row.get("library_layout") == "PAIRED" else 1
        if len(urls) != expected or len(checksums) != expected or len(sizes) != expected:
            raise ConfigurationError(f"{accession}: ambiguous FASTQ layout; review the remote record")
        for index, (url, checksum, size) in enumerate(zip(urls, checksums, sizes), 1):
            url = url if url.startswith("https://") else "https://" + url.removeprefix("ftp://")
            host = urlsplit(url).hostname or ""
            if not host.endswith(".ebi.ac.uk") or not re.fullmatch(r"[a-fA-F0-9]{32}", checksum) or int(size) <= 0:
                raise ConfigurationError(f"{accession}: invalid ENA URL, size or checksum")
            transfers.append(
                {
                    "sample_id": sample["sample_id"],
                    "accession": accession,
                    "role": f"r{index}",
                    "url": url,
                    "checksum": checksum,
                    "bytes": int(size),
                    "path": str(root.resolve() / accession / f"{accession}_R{index}.fastq.gz"),
                }
            )
    manifest = {**manifest, "remote_transfers": transfers}
    manifest.pop("manifest_fingerprint", None)
    manifest["manifest_fingerprint"] = object_fingerprint(manifest)
    write_yaml(project.requirements_dir / "input_manifest.yaml", manifest)
    return manifest


def acquire_manifest_inputs(project):
    from microbiome.pipeline.dependencies import require_bootstrap_approval
    from microbiome.pipeline.lifecycle import load_plan
    from microbiome.resource_skills.acquisition import download_file_with_resume
    from microbiome.resource_skills.locking import resource_lock

    require_bootstrap_approval(project, load_plan(project))
    path = project.requirements_dir / "input_manifest.yaml"
    manifest = read_yaml(path)
    approved_input = read_yaml(project.requirements_path)["input"]["manifest_fingerprint"]
    if object_fingerprint(manifest) != approved_input:
        raise ConfigurationError("remote acquisition input scope changed after approval")
    transfers = manifest.get("remote_transfers")
    if not transfers:
        raise ConfigurationError("remote input has no reviewed transfer records")
    for transfer in transfers:
        target = Path(transfer["path"])
        with resource_lock(target.parent, "raw-" + transfer["accession"]):
            download_file_with_resume(
                transfer["url"],
                target,
                expected_size=transfer["bytes"],
                checksum="md5:" + transfer["checksum"],
                retries=3,
            )
    for sample in manifest["samples"]:
        selected = [item for item in transfers if item["sample_id"] == sample["sample_id"]]
        if selected:
            sample["original_source_type"] = sample["source_type"]
            sample["source_type"] = "LOCAL_PAIRED_FASTQ" if len(selected) == 2 else "LOCAL_SINGLE_FASTQ"
            for item in selected:
                sample[item["role"]] = {"path": item["path"], "exists": True}
            sample["validation"] = {"readable": True, "paired": len(selected) == 2}
    manifest["requires_raw_data_download"] = False
    manifest["resolution_status"] = "CONFIRMED"
    manifest["acquisition_approval_input_fingerprint"] = approved_input
    manifest.pop("manifest_fingerprint", None)
    manifest["manifest_fingerprint"] = object_fingerprint(manifest)
    write_yaml(path, manifest)
    return manifest
