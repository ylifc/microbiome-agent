"""Reference provenance and explicit method decisions, never execution authority."""

from copy import deepcopy

from microbiome.pipeline.errors import ConfigurationError

REFERENCE_INSTRUCTIONS = """Workflow references are curated method guidance, not installed-resource facts,
execution authorization or validated scientific results. Read the supplied selected documents before
designing the plan. Respect their applicability, required questions, input/output interfaces and
limitations; adapt them to the confirmed manifest and study design. Never install every listed tool.
For EACH supplied workflow, return plan.workflow_decisions with workflow_id, disposition
(use, adapt, or not_applicable), a concrete reason, and step_ids. use/adapt must map to existing
plan step IDs; not_applicable must have an empty step_ids list and explain why the method does not fit.
The application checks coverage and records the document versions/fingerprints, not scientific truth.
Request further documents using workflow_ids or the read-only workflow lookup before relying on them.
Missing tools are discovery requests: search all existing environments before proposing a scoped,
approved installation. Keep package, executable, software family and environment identities separate.
"""


def workflow_ids(plan):
    """Validate explicit selection without silently discarding malformed IDs."""
    ids = (plan or {}).get("workflow_ids")
    if ids is None:
        return None
    if not isinstance(ids, list) or any(not isinstance(item, str) or not item.strip() for item in ids):
        raise ConfigurationError("workflow_ids must be an array of nonempty catalog IDs.")
    if len(ids) != len(set(ids)):
        raise ConfigurationError("workflow_ids must not contain duplicates.")
    return ids or None


def reference_summary(selection):
    return [
        {"workflow_id": row["metadata"]["id"], "version": row["metadata"]["version"],
         "fingerprint": row["fingerprint"], "status": "CURATED_REFERENCE"}
        for row in selection.get("selected", [])
    ]


def bind_reference_decisions(plan, selection, *, receipt=None, require_match=False):
    """Require a reviewable decision for each supplied reference, then bind provenance.

    References may be declined with a reason. Their software lists never become
    dependency requests; only actual plan steps enter resource resolution.
    """
    from microbiome.visualization.references import bind_figure_references
    result = bind_figure_references(plan, selection.get("visualization"), receipt=receipt, require_match=require_match)
    references = reference_summary(selection)
    if not references:
        if result.get("workflow_decisions") or result.get("workflow_references"):
            raise ConfigurationError("Workflow decisions require selected, read catalog references.")
        return result
    if require_match and result.get("workflow_references") not in (None, references):
        raise ConfigurationError("Workflow reference changed since compilation; read it and recompile the design.")
    decisions = result.get("workflow_decisions")
    if not isinstance(decisions, list):
        raise ConfigurationError("plan.workflow_decisions must explain every supplied workflow reference.")
    selected = {row["workflow_id"] for row in references}
    declared_steps = {step["step_id"] for step in result.get("steps", [])}
    seen = set()
    for decision in decisions:
        if not isinstance(decision, dict):
            raise ConfigurationError("Each workflow decision must be an object.")
        key = decision.get("workflow_id")
        if not isinstance(key, str) or key not in selected or key in seen:
            raise ConfigurationError(f"Workflow decision names an unread or duplicate reference: {key}")
        seen.add(key)
        disposition = decision.get("disposition")
        reason = decision.get("reason")
        step_ids = decision.get("step_ids")
        if disposition not in {"use", "adapt", "not_applicable"} or not isinstance(reason, str) or not reason.strip():
            raise ConfigurationError(f"Workflow {key} needs a disposition and a concrete method-selection reason.")
        if (not isinstance(step_ids, list) or any(not isinstance(item, str) for item in step_ids)
                or len(step_ids) != len(set(step_ids)) or set(step_ids) - declared_steps):
            raise ConfigurationError(f"Workflow {key} step_ids must name declared plan steps exactly once.")
        if disposition in {"use", "adapt"} and not step_ids:
            raise ConfigurationError(f"Workflow {key} must map use/adapt decisions to actual plan steps.")
        if disposition == "not_applicable" and step_ids:
            raise ConfigurationError(f"Workflow {key} is not applicable but still names plan steps.")
    if seen != selected:
        raise ConfigurationError("Missing workflow decisions: " + ", ".join(sorted(selected - seen)))
    requested = workflow_ids(result) or []
    result["workflow_ids"] = list(dict.fromkeys([row["workflow_id"] for row in references] + requested))
    result["workflow_references"] = references
    if receipt is not None:
        result["workflow_reference_evidence"] = {
            key: receipt[key] for key in ("path", "context_fingerprint")
        }
    return result
