"""Bounded technical planning policy, independent of scientific execution locks.

Only presentation budgets are model-adjustable. Administrator ceilings,
model routes and execution parameters are deliberately outside this interface.
Unknown tokenizers use a labelled UTF-8 byte upper estimate, never an invented
bytes/token ratio. The host transport must also check its final request.
"""
from __future__ import annotations

import copy
import json
from datetime import UTC, datetime

from microbiome.pipeline.errors import ConfigurationError
from microbiome.pipeline.io import object_fingerprint
from microbiome.pipeline.locking import project_operation_lock
from microbiome.pipeline.state import ProjectStateMachine

POLICY_VERSION = 1
MESSAGE_BUILDER_VERSION = 3
DEFAULT_SETTINGS = {"evidence_bytes": 65536, "guidance_bytes": 131072, "history_bytes": 16384}
DEFAULT_LIMITS = {
    "max_evidence_bytes": 262144, "max_guidance_bytes": 262144,
    "max_history_bytes": 65536,
    "max_model_calls": 24, "max_format_repairs": 3, "max_technical_adjustments": 3,
    "context_window_tokens": 65536, "output_reserve_tokens": 8192,
    "protocol_margin_tokens": 2048, "max_plan_steps": 256,
    "max_field_chars": 65536, "max_depth": 32, "max_plan_nodes": 50000,
}
MUTABLE_PHASES = {"NEW", "PATH_CONFIRMATION", "DATA_DISCOVERY", "DATA_CHARACTERIZATION", "GOAL_DEFINITION",
                  "REQUIREMENTS_CONFIRMED", "RESOURCE_DISCOVERY", "EVIDENCE_REVIEW", "PLAN_DRAFTING",
                  "PLAN_CONFIRMATION", "PLAN_MODIFICATION", "REVALIDATION_REQUIRED"}


class PlanningPolicyError(ConfigurationError):
    def __init__(self, code, message, **details):
        self.details = {"code": code, "category": "PLANNING_POLICY", "recoverable": True,
                        "next_action": {"tool": "microbiome_maintenance", "operation": "planning_policy",
                                        "arguments": {"action": "inspect"}}, **details}
        super().__init__(f"{code}: {message}")


def _read(project):
    from microbiome.pipeline.maintenance import _read_json
    path = project.state_dir / "planning_policy.json"
    if not path.exists() and not path.is_symlink():
        return {"schema_version": POLICY_VERSION, "revision": 0, "overrides": {}, "changes": []}
    value = _read_json(path)
    if (value.get("schema_version") != POLICY_VERSION or type(value.get("revision")) is not int
            or not isinstance(value.get("overrides"), dict) or not isinstance(value.get("changes"), list)):
        raise PlanningPolicyError("INVALID_PLANNING_POLICY", "Invalid persisted planning policy")
    return value


def get_effective_policy(project):
    """Read only; revision is not part of the semantic recovery fingerprint."""
    config = project.load_config().get("planning_policy", {})
    if not isinstance(config, dict) or set(config) - {"limits", "settings"}:
        raise PlanningPolicyError("INVALID_PLANNING_POLICY", "Unknown administrator policy fields")
    if any(not isinstance(config.get(key, {}), dict) for key in ("limits", "settings")):
        raise PlanningPolicyError("INVALID_PLANNING_POLICY", "Settings and limits must be objects")
    limits = {**DEFAULT_LIMITS, **config.get("limits", {})}
    if set(limits) != set(DEFAULT_LIMITS) or any(type(v) is not int or v < 1 for v in limits.values()):
        raise PlanningPolicyError("INVALID_PLANNING_POLICY", "Limits must be known positive integers")
    from microbiome.pipeline.maintenance import _read_json
    profile_path = project.state_dir / "host_model_profile.json"
    profile = _read_json(profile_path) if profile_path.exists() or profile_path.is_symlink() else {}
    administrator_capacity = config.get("limits", {}).get("context_window_tokens")
    capacity_source = "administrator_configured" if administrator_capacity else "conservative_fallback"
    if profile.get("context_window_tokens"):
        limits["context_window_tokens"] = min(limits["context_window_tokens"], profile["context_window_tokens"]) if capacity_source == "administrator_configured" else profile["context_window_tokens"]
        capacity_source = "host_declared_capacity"
    elif profile.get("source") == "host_capacity_unavailable" and not administrator_capacity:
        capacity_source = "host_capacity_unavailable"
    limits["output_reserve_tokens"] = max(limits["output_reserve_tokens"], profile.get("output_reserve_tokens", 0))
    state = _read(project)
    settings = {**DEFAULT_SETTINGS, **config.get("settings", {}), **state["overrides"]}
    _validate_settings(settings, limits)
    effective = {"schema_version": POLICY_VERSION, "message_builder_version": MESSAGE_BUILDER_VERSION,
                 "settings": settings, "limits": limits,
                 "project_context_limit_tokens": administrator_capacity,
                 "host_profile_fingerprint": object_fingerprint(profile), "capacity_source": capacity_source}
    return {**effective, "policy_fingerprint": object_fingerprint(effective), "revision": state["revision"],
            "technical_adjustments": len(state["changes"])}


def policy_fingerprint(project):
    return get_effective_policy(project)["policy_fingerprint"]


def record_host_profile(project, profile):
    """Accept only host adapter metadata, never model tool arguments or secrets."""
    from microbiome.pipeline.maintenance import _save, _read_json
    if project.pipeline_lock_path.exists():
        return
    if not isinstance(profile, dict) or set(profile) - {"provider", "model", "source", "profile_kind", "context_window_tokens", "output_reserve_tokens", "capacity_metadata_source"}:
        raise PlanningPolicyError("INVALID_HOST_PROFILE", "Unexpected host profile fields")
    for key in ("context_window_tokens", "output_reserve_tokens"):
        if key in profile and (type(profile[key]) is not int or not 1 <= profile[key] <= 10_000_000):
            raise PlanningPolicyError("INVALID_HOST_PROFILE", "Host capacities must be positive bounded integers")
    if any(not isinstance(profile.get(key), str) or not profile[key] or len(profile[key]) > 512 for key in ("provider", "model")):
        raise PlanningPolicyError("INVALID_HOST_PROFILE", "A host route identity is required")
    for key in ("source", "profile_kind", "capacity_metadata_source"):
        if key in profile and (not isinstance(profile[key], str) or not profile[key] or len(profile[key]) > 128):
            raise PlanningPolicyError("INVALID_HOST_PROFILE", "Host metadata provenance must be a bounded string")
    path = project.state_dir / "host_model_profile.json"
    if path.exists():
        previous = _read_json(path)
        if all(previous.get(key) == profile.get(key) for key in ("provider", "model")):
            # Model-info and prepared-call metadata are two observations of the
            # same route. Equivalent values must not invalidate recovery tokens
            # merely because a different host API supplied the observation.
            if (profile.get("context_window_tokens") and previous.get("context_window_tokens")
                    and (previous.get("capacity_metadata_source") or not profile.get("capacity_metadata_source"))
                    and all(previous.get(key) == profile.get(key) for key in
                            ("context_window_tokens", "output_reserve_tokens", "source"))):
                return
            if previous.get("profile_kind") == "prepared_request" and profile.get("profile_kind") == "session_route":
                return
            # Session headers may omit capacities resolved by prepareCall.
            # Such omissions must not downgrade a verified request profile or
            # invalidate a recovery token just before it is checked.
            if profile.get("profile_kind") == "session_route":
                for key in ("context_window_tokens", "output_reserve_tokens", "capacity_metadata_source"):
                    if key not in profile and key in previous:
                        profile = {**profile, key: previous[key]}
                if profile.get("context_window_tokens") and previous.get("source") == "host_declared_capacity":
                    profile = {**profile, "source": "host_declared_capacity"}
        if previous == profile:
            return
    _save(path, profile)


def _validate_settings(settings, limits):
    if set(settings) != set(DEFAULT_SETTINGS):
        raise PlanningPolicyError("INVALID_PLANNING_POLICY", "Only evidence_bytes, guidance_bytes and history_bytes may change")
    for key, value in settings.items():
        if type(value) is not int or not 1024 <= value <= limits["max_" + key]:
            raise PlanningPolicyError("PLANNING_POLICY_OUT_OF_RANGE", f"{key} is outside the permitted range",
                                      field=key, minimum=1024, maximum=limits["max_" + key])


def inspect_policy(project):
    policy = get_effective_policy(project)
    phase = ProjectStateMachine(project).current.value
    mutable = phase in MUTABLE_PHASES and not project.pipeline_lock_path.exists()
    return {**policy, "phase": phase, "can_adjust": mutable,
            "adjustable_fields": {key: {"minimum": 1024, "maximum": policy["limits"]["max_" + key]}
                                  for key in DEFAULT_SETTINGS},
            "changes": _read(project)["changes"],
            "scope": "Presentation budgets only; no route, fee ceiling, input, resource, approval or lock changes"}


def estimate_policy(project):
    from microbiome.pipeline.maintenance import _read_json
    reports = list((project.plans_dir / "planning_budget").glob("*.json"))
    reports.sort(key=lambda p: p.stat().st_mtime_ns, reverse=True)
    latest = _read_json(reports[0]) if reports else None
    final_path = project.state_dir / "last_host_budget.json"
    final = _read_json(final_path) if final_path.exists() else None
    policy = get_effective_policy(project)
    return {"effective_policy": policy, "last_measured_request": final or latest,
            "python_preflight_or_evidence": latest, "final_host_request": final,
            "measurement_source": "final_host_request" if final else "python_preflight_or_evidence" if latest else None,
            "measurement_available": final is not None or latest is not None,
            "measurement_matches_policy": (final or latest or {}).get("policy_fingerprint") == policy["policy_fingerprint"],
            "input_token_allowance": max(0, policy["limits"]["context_window_tokens"]
                 - policy["limits"]["output_reserve_tokens"] - policy["limits"]["protocol_margin_tokens"]),
            "note": "Recorded measurements of identified requests, not a prediction that a future request will fit; final host checks include rejected requests."}


def update_policy(project, *, changes=None, expected_policy_revision, request_id, rollback_revision=None):
    """Atomic, revision-checked and idempotent even across interrupted maintenance."""
    from microbiome.pipeline.maintenance import _save
    with project_operation_lock(project, reentrant=True):
        before = get_effective_policy(project)
        state = _read(project)
        intent = object_fingerprint({"changes": changes, "rollback_revision": rollback_revision,
                                     "expected_policy_revision": expected_policy_revision})
        previous = next((row for row in state["changes"] if row["request_id"] == request_id), None)
        if previous:
            if previous["intent_fingerprint"] != intent:
                raise PlanningPolicyError("REQUEST_ID_CONFLICT", "Planning policy request changed")
            return {**previous, "reused": True, "effective_policy": before}
        if not inspect_policy(project)["can_adjust"]:
            raise PlanningPolicyError("PLANNING_POLICY_PHASE_DENIED", "Planning policy is immutable in this phase")
        if type(expected_policy_revision) is not int or expected_policy_revision != state["revision"]:
            raise PlanningPolicyError("PLANNING_POLICY_REVISION_CONFLICT", "Inspect the current policy before adjusting",
                                      current_revision=state["revision"])
        if rollback_revision is not None:
            row = next((r for r in state["changes"] if r["revision"] == rollback_revision), None)
            if row is None:
                raise PlanningPolicyError("PLANNING_POLICY_UNKNOWN_REVISION", "Rollback receipt was not found")
            changes = row["before_settings"]
        if not isinstance(changes, dict) or not changes or set(changes) - set(DEFAULT_SETTINGS):
            raise PlanningPolicyError("INVALID_PLANNING_POLICY", "Supply only permitted presentation settings")
        after_settings = {**before["settings"], **changes}
        _validate_settings(after_settings, before["limits"])
        if after_settings == before["settings"]:
            return {"changed": False, "reused": False, "effective_policy": before}
        if len(state["changes"]) >= before["limits"]["max_technical_adjustments"]:
            raise PlanningPolicyError("PLANNING_ADJUSTMENT_LIMIT", "Technical adjustment allowance is exhausted")
        after = {key: before[key] for key in ("schema_version", "message_builder_version", "limits", "capacity_source", "host_profile_fingerprint", "project_context_limit_tokens")}
        after["settings"] = after_settings
        receipt = {"revision": state["revision"] + 1, "request_id": request_id, "intent_fingerprint": intent,
                   "before_settings": before["settings"], "after_settings": after_settings,
                   "before_fingerprint": before["policy_fingerprint"], "after_fingerprint": object_fingerprint(after),
                   "rollback_of_revision": rollback_revision, "changed": True,
                   "created_at": datetime.now(UTC).isoformat()}
        state.update(revision=receipt["revision"], overrides=after_settings)
        state["changes"].append(receipt)
        _save(project.state_dir / "planning_policy.json", state)
        return {**receipt, "reused": False, "effective_policy": get_effective_policy(project)}


def serialized_bytes(value):
    return len(json.dumps(value, ensure_ascii=False, sort_keys=True, default=str).encode("utf-8"))


def _wire(messages):
    result = []
    for message in messages:
        if isinstance(message, dict):
            result.append(copy.deepcopy(message))
        else:
            row = {"role": getattr(message, "type", "unknown"), "content": getattr(message, "content", str(message))}
            for key in ("tool_calls", "tool_call_id", "name"):
                if getattr(message, key, None):
                    row[key] = getattr(message, key)
            result.append(row)
    return result


def preflight_model_messages(project, messages, *, purpose, tools=None):
    """Check the complete caller request; no semantic text truncation is allowed."""
    from microbiome.pipeline.maintenance import _save
    policy = get_effective_policy(project)
    wire = _wire(messages)
    request = {"messages": wire, "tools": tools or []}
    counts = [{"index": index, "role": item.get("role"), "bytes": serialized_bytes(item),
               "content_fingerprint": object_fingerprint(item)} for index, item in enumerate(wire)]
    total = serialized_bytes(request)
    # UTF-8 byte fallback is deliberately pessimistic for unsupported tokenizers.
    estimated = total + 16 * len(wire)
    limit = policy["limits"]["context_window_tokens"]
    reserved = policy["limits"]["output_reserve_tokens"] + policy["limits"]["protocol_margin_tokens"]
    report = {"schema_version": 1, "purpose": purpose, "policy_fingerprint": policy["policy_fingerprint"],
              "request_fingerprint": object_fingerprint(request), "serialized_bytes": total,
              "estimated_input_tokens": estimated, "token_count_method": "conservative_utf8_byte_upper_estimate",
              "exact_token_count": False, "capacity_source": policy["capacity_source"],
              "context_window_tokens": limit if policy["capacity_source"] != "host_capacity_unavailable" else None,
              "project_context_limit_tokens": policy["project_context_limit_tokens"],
              "reserved_tokens": reserved, "output_reserve_tokens": policy["limits"]["output_reserve_tokens"],
              "protocol_margin_tokens": policy["limits"]["protocol_margin_tokens"], "breakdown": counts,
              "tool_schema_bytes": serialized_bytes(tools or []),
              "duplicate_message_indices": [r["index"] for i, r in enumerate(counts)
                  if r["content_fingerprint"] in {v["content_fingerprint"] for v in counts[:i]}],
              "fits": policy["capacity_source"] != "host_capacity_unavailable" and estimated + reserved <= limit}
    path = project.plans_dir / "planning_budget" / f"{object_fingerprint(report)}.json"
    _save(path, report)
    report["receipt"] = str(path)
    if policy["capacity_source"] == "host_capacity_unavailable":
        raise PlanningPolicyError("MODEL_CONTEXT_METADATA_MISSING", "Host model context capacity is unavailable",
                                  **report, model_request_dispatched=False, transport_attempts=0,
                                  missing_metadata=["contextWindow"],
                                  next_action={"owner": "host_adapter", "reason":
                                      "Expose verified model context metadata or an administrator-configured limit; fragment budget changes cannot supply host metadata"})
    if not report["fits"]:
        raise PlanningPolicyError("MODEL_CONTEXT_LIMIT", "Complete model request exceeds the context allowance",
                                  **report, measured=estimated + reserved, limit=limit,
                                  model_request_dispatched=False, transport_attempts=0,
                                  preserved=["input_manifest", "candidate", "execution_parameters"],
                                  next_action={"operation": "planning_policy", "arguments": {"action": "estimate"},
                                               "owner": "controller", "reason": "Remove duplicate optional context or configure verified host capacity"})
    return report


def validate_plan_structure(project, payload):
    policy = get_effective_policy(project)
    limits = policy["limits"]
    plan = payload.get("plan", payload) if isinstance(payload, dict) else {}
    steps = plan.get("steps", []) if isinstance(plan, dict) else []
    nodes = 0
    def visit(value, depth):
        nonlocal nodes
        nodes += 1
        if depth > limits["max_depth"] or nodes > limits["max_plan_nodes"]:
            raise PlanningPolicyError("PLANNING_STRUCTURE_LIMIT", "Plan nesting or node count exceeds the structural limit")
        if isinstance(value, str) and len(value) > limits["max_field_chars"]:
            raise PlanningPolicyError("PLANNING_STRUCTURE_LIMIT", "A plan field exceeds the structural limit")
        if isinstance(value, dict):
            for key, item in value.items():
                visit(key, depth + 1)
                visit(item, depth + 1)
        elif isinstance(value, list):
            for item in value:
                visit(item, depth + 1)
    if isinstance(steps, list) and len(steps) > limits["max_plan_steps"]:
        raise PlanningPolicyError("PLANNING_STRUCTURE_LIMIT", "Plan step count exceeds the structural limit")
    visit(payload, 0)
