"""Persistent lifecycle state machine for long-running bioinformatics projects."""

from __future__ import annotations

from datetime import UTC, datetime
from enum import StrEnum
from typing import TYPE_CHECKING, Any

from microbiome.pipeline.errors import ConfigurationError, FinalizationFailureCategory
from microbiome.pipeline.io import object_fingerprint, read_yaml, write_yaml

if TYPE_CHECKING:
    from microbiome.pipeline.project import PipelineProject


class LifecycleState(StrEnum):
    NEW = "NEW"
    PATH_CONFIRMATION = "PATH_CONFIRMATION"
    DATA_DISCOVERY = "DATA_DISCOVERY"
    DATA_CHARACTERIZATION = "DATA_CHARACTERIZATION"
    GOAL_DEFINITION = "GOAL_DEFINITION"
    REQUIREMENTS_CONFIRMED = "REQUIREMENTS_CONFIRMED"
    RESOURCE_DISCOVERY = "RESOURCE_DISCOVERY"
    EVIDENCE_REVIEW = "EVIDENCE_REVIEW"
    PLAN_DRAFTING = "PLAN_DRAFTING"
    PLAN_CONFIRMATION = "PLAN_CONFIRMATION"
    DEPENDENCY_REVIEW = "DEPENDENCY_REVIEW"
    INSTALL_APPROVAL = "INSTALL_APPROVAL"
    BOOTSTRAP = "BOOTSTRAP"
    PRETEST_PREPARATION = "PRETEST_PREPARATION"
    PRETEST_RUNNING = "PRETEST_RUNNING"
    PRETEST_REPAIR = "PRETEST_REPAIR"
    PRETEST_PASSED = "PRETEST_PASSED"
    # VALIDATED is retained for projects produced by the previous schema.
    VALIDATED = "VALIDATED"
    PRETEST_FINALIZING = "PRETEST_FINALIZING"
    PRETEST_FINALIZATION_FAILED = "PRETEST_FINALIZATION_FAILED"
    FROZEN = "FROZEN"
    PIPELINE_LOCK_VALIDATING = "PIPELINE_LOCK_VALIDATING"
    PRODUCTION_READY = "PRODUCTION_READY"
    AWAITING_PRODUCTION_APPROVAL = "AWAITING_PRODUCTION_APPROVAL"
    PRODUCTION_APPROVED = "PRODUCTION_APPROVED"
    PAUSED = "PAUSED"
    PLAN_MODIFICATION = "PLAN_MODIFICATION"
    PRODUCTION_PREFLIGHT = "PRODUCTION_PREFLIGHT"
    PRODUCTION_RUNNING = "PRODUCTION_RUNNING"
    PRODUCTION_FAILED = "PRODUCTION_FAILED"
    REVALIDATION_REQUIRED = "REVALIDATION_REQUIRED"
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"


CANONICAL_ORDER = (
    LifecycleState.NEW,
    LifecycleState.PATH_CONFIRMATION,
    LifecycleState.DATA_DISCOVERY,
    LifecycleState.DATA_CHARACTERIZATION,
    LifecycleState.GOAL_DEFINITION,
    LifecycleState.REQUIREMENTS_CONFIRMED,
    LifecycleState.RESOURCE_DISCOVERY,
    LifecycleState.EVIDENCE_REVIEW,
    LifecycleState.PLAN_DRAFTING,
    LifecycleState.PLAN_CONFIRMATION,
    LifecycleState.DEPENDENCY_REVIEW,
    LifecycleState.INSTALL_APPROVAL,
    LifecycleState.BOOTSTRAP,
    LifecycleState.PRETEST_PREPARATION,
    LifecycleState.PRETEST_RUNNING,
    LifecycleState.PRETEST_PASSED,
    LifecycleState.PRETEST_FINALIZING,
    LifecycleState.FROZEN,
    LifecycleState.PIPELINE_LOCK_VALIDATING,
    LifecycleState.PRODUCTION_READY,
    LifecycleState.AWAITING_PRODUCTION_APPROVAL,
    LifecycleState.PRODUCTION_APPROVED,
    LifecycleState.PRODUCTION_PREFLIGHT,
    LifecycleState.PRODUCTION_RUNNING,
    LifecycleState.COMPLETED,
)

ALLOWED_TRANSITIONS: dict[LifecycleState, set[LifecycleState]] = {
    state: {CANONICAL_ORDER[index + 1]}
    for index, state in enumerate(CANONICAL_ORDER[:-1])
}
ALLOWED_TRANSITIONS.update(
    {
        LifecycleState.PLAN_CONFIRMATION: {
            LifecycleState.DEPENDENCY_REVIEW,
            LifecycleState.PLAN_DRAFTING,
            LifecycleState.CANCELLED,
        },
        LifecycleState.INSTALL_APPROVAL: {
            LifecycleState.BOOTSTRAP,
            LifecycleState.DEPENDENCY_REVIEW,
            LifecycleState.CANCELLED,
        },
        LifecycleState.PRETEST_RUNNING: {
            LifecycleState.PRETEST_REPAIR,
            LifecycleState.PRETEST_PASSED,
            LifecycleState.VALIDATED,
        },
        LifecycleState.PRETEST_REPAIR: {
            LifecycleState.PRETEST_RUNNING,
            LifecycleState.PRETEST_PASSED,
            LifecycleState.VALIDATED,
            LifecycleState.CANCELLED,
        },
        LifecycleState.PRETEST_PASSED: {LifecycleState.PRETEST_FINALIZING},
        LifecycleState.VALIDATED: {LifecycleState.PRETEST_FINALIZING},
        LifecycleState.PRETEST_FINALIZING: {
            LifecycleState.FROZEN,
            LifecycleState.PRETEST_FINALIZATION_FAILED,
        },
        LifecycleState.PRETEST_FINALIZATION_FAILED: {
            LifecycleState.PRETEST_FINALIZING,
            LifecycleState.PRETEST_REPAIR,
            LifecycleState.CANCELLED,
        },
        LifecycleState.FROZEN: {
            LifecycleState.PIPELINE_LOCK_VALIDATING,
            LifecycleState.PRETEST_FINALIZATION_FAILED,
        },
        LifecycleState.PIPELINE_LOCK_VALIDATING: {
            LifecycleState.PRODUCTION_READY,
            LifecycleState.PRETEST_FINALIZATION_FAILED,
        },
        LifecycleState.PRODUCTION_READY: {LifecycleState.AWAITING_PRODUCTION_APPROVAL},
        LifecycleState.AWAITING_PRODUCTION_APPROVAL: {
            LifecycleState.PRODUCTION_APPROVED,
            LifecycleState.PAUSED,
            LifecycleState.PLAN_MODIFICATION,
            LifecycleState.CANCELLED,
        },
        LifecycleState.PRODUCTION_APPROVED: {
            LifecycleState.PRODUCTION_PREFLIGHT,
            LifecycleState.PRETEST_FINALIZATION_FAILED,
            LifecycleState.REVALIDATION_REQUIRED,
        },
        LifecycleState.PRODUCTION_PREFLIGHT: {
            LifecycleState.PRODUCTION_RUNNING,
            LifecycleState.PRETEST_FINALIZATION_FAILED,
            LifecycleState.REVALIDATION_REQUIRED,
        },
        LifecycleState.PAUSED: {
            LifecycleState.AWAITING_PRODUCTION_APPROVAL,
            LifecycleState.CANCELLED,
        },
        LifecycleState.PLAN_MODIFICATION: {LifecycleState.GOAL_DEFINITION},
        LifecycleState.PRODUCTION_RUNNING: {
            LifecycleState.PRODUCTION_FAILED,
            LifecycleState.COMPLETED,
        },
        LifecycleState.PRODUCTION_FAILED: {LifecycleState.REVALIDATION_REQUIRED},
        LifecycleState.REVALIDATION_REQUIRED: {
            LifecycleState.PLAN_DRAFTING,
            LifecycleState.PRETEST_PREPARATION,
        },
        LifecycleState.COMPLETED: {
            LifecycleState.GOAL_DEFINITION,
            LifecycleState.AWAITING_PRODUCTION_APPROVAL,
            LifecycleState.PRODUCTION_PREFLIGHT,
        },
        LifecycleState.CANCELLED: {LifecycleState.GOAL_DEFINITION},
    }
)
for _state in LifecycleState:
    if _state not in {LifecycleState.CANCELLED, LifecycleState.PRODUCTION_RUNNING}:
        ALLOWED_TRANSITIONS.setdefault(_state, set()).add(LifecycleState.CANCELLED)


def _utcnow() -> str:
    return datetime.now(UTC).isoformat()


class ProjectStateMachine:
    """Validate transitions and store the authoritative state outside chat context."""

    def __init__(self, project: PipelineProject):
        self.project = project
        self.path = project.lifecycle_state_path

    def initialize(self, *, paths_confirmed: bool) -> dict[str, Any]:
        if self.path.is_file():
            return self.load()
        now = _utcnow()
        history = [
            {"timestamp": now, "from": None, "to": LifecycleState.NEW.value, "reason": "project created"}
        ]
        current = LifecycleState.NEW
        if paths_confirmed:
            history.extend(
                [
                    {
                        "timestamp": now,
                        "from": LifecycleState.NEW.value,
                        "to": LifecycleState.PATH_CONFIRMATION.value,
                        "reason": "explicit paths supplied",
                    },
                    {
                        "timestamp": now,
                        "from": LifecycleState.PATH_CONFIRMATION.value,
                        "to": LifecycleState.DATA_DISCOVERY.value,
                        "reason": "path bindings confirmed",
                    },
                ]
            )
            current = LifecycleState.DATA_DISCOVERY
        payload = {
            "schema_version": 1,
            "current_state": current.value,
            "requirements_version": 1,
            "invalidated_artifacts": [],
            "history": history,
            "updated_at": now,
        }
        payload["state_fingerprint"] = self._fingerprint(payload)
        write_yaml(self.path, payload)
        return payload

    @staticmethod
    def _fingerprint(value: dict[str, Any]) -> str:
        return object_fingerprint({key: item for key, item in value.items() if key != "state_fingerprint"})

    def load(self) -> dict[str, Any]:
        if not self.path.is_file():
            raise ConfigurationError(f"project lifecycle state is missing: {self.path}")
        value = read_yaml(self.path)
        if not isinstance(value, dict) or value.get("schema_version") != 1:
            raise ConfigurationError(f"invalid project lifecycle state: {self.path}")
        try:
            LifecycleState(value.get("current_state"))
        except ValueError as exc:
            raise ConfigurationError(f"unknown project lifecycle state: {value.get('current_state')}") from exc
        if value.get("state_fingerprint") != self._fingerprint(value):
            raise ConfigurationError(f"project lifecycle state fingerprint is invalid: {self.path}")
        return value

    @property
    def current(self) -> LifecycleState:
        return LifecycleState(self.load()["current_state"])

    def transition(self, target: LifecycleState, *, reason: str) -> dict[str, Any]:
        value = self.load()
        current = LifecycleState(value["current_state"])
        if current == target:
            return value
        if target not in ALLOWED_TRANSITIONS.get(current, set()):
            raise ConfigurationError(f"invalid lifecycle transition: {current.value} -> {target.value}")
        if current == LifecycleState.PRETEST_FINALIZATION_FAILED and target == LifecycleState.PRETEST_REPAIR:
            failure = value.get("last_finalization_failure")
            if isinstance(failure, dict) and failure.get("requires_pretest") is False:
                category = failure.get("category") or FinalizationFailureCategory.METADATA_ERROR.value
                raise ConfigurationError(
                    f"{category} is a management-state failure; retry Finalize without re-running the pre-test"
                )
        value["history"].append(
            {"timestamp": _utcnow(), "from": current.value, "to": target.value, "reason": reason}
        )
        value["current_state"] = target.value
        value["updated_at"] = _utcnow()
        value["state_fingerprint"] = self._fingerprint(value)
        write_yaml(self.path, value)
        return value

    def record_finalization_failure(
        self,
        category: FinalizationFailureCategory,
        *,
        detail: str,
    ) -> dict[str, Any]:
        """Persist the post-pretest recovery policy before changing state."""
        value = self.load()
        value["last_finalization_failure"] = {
            "timestamp": _utcnow(),
            "category": category.value,
            "requires_pretest": category.requires_pretest,
            "recovery": "RERUN_PRETEST" if category.requires_pretest else "REPAIR_AND_REFINALIZE",
            "detail": detail[:1000],
        }
        value["updated_at"] = _utcnow()
        value["state_fingerprint"] = self._fingerprint(value)
        write_yaml(self.path, value)
        return value

    def advance_to(self, target: LifecycleState, *, reason: str) -> dict[str, Any]:
        """Advance along the canonical pre-production path without skipping gates."""
        value = self.load()
        current = LifecycleState(value["current_state"])
        if current == target:
            return value
        try:
            current_index = CANONICAL_ORDER.index(current)
            target_index = CANONICAL_ORDER.index(target)
        except ValueError as exc:
            raise ConfigurationError(f"cannot canonically advance from {current.value} to {target.value}") from exc
        if target_index < current_index:
            raise ConfigurationError(f"cannot move lifecycle backwards: {current.value} -> {target.value}")
        for state in CANONICAL_ORDER[current_index + 1 : target_index + 1]:
            value = self.transition(state, reason=reason)
        return value

    def require(self, *allowed: LifecycleState) -> dict[str, Any]:
        value = self.load()
        current = LifecycleState(value["current_state"])
        if current not in set(allowed):
            choices = ", ".join(state.value for state in allowed)
            raise ConfigurationError(f"operation requires lifecycle state {choices}; current state is {current.value}")
        return value

    def invalidate_for_requirements(self, requirements_version: int, *, reason: str) -> dict[str, Any]:
        """Invalidate derived artifacts without deleting their audit history."""
        value = self.load()
        current = LifecycleState(value["current_state"])
        invalidated = list(value.get("invalidated_artifacts", []))
        invalidated.append(
            {
                "timestamp": _utcnow(),
                "reason": reason,
                "previous_state": current.value,
                "requirements_version": requirements_version,
                "artifacts": ["analysis_plan", "dependency_review", "validation", "pipeline_lock"],
            }
        )
        value["invalidated_artifacts"] = invalidated
        value["requirements_version"] = requirements_version
        value["current_state"] = LifecycleState.GOAL_DEFINITION.value
        value["history"].append(
            {
                "timestamp": _utcnow(),
                "from": current.value,
                "to": LifecycleState.GOAL_DEFINITION.value,
                "reason": reason,
            }
        )
        value["updated_at"] = _utcnow()
        value["state_fingerprint"] = self._fingerprint(value)
        write_yaml(self.path, value)
        return value

    def mark_requirements_confirmed(self, requirements_version: int) -> dict[str, Any]:
        value = self.load()
        value["requirements_version"] = requirements_version
        value["state_fingerprint"] = self._fingerprint(value)
        write_yaml(self.path, value)
        current = LifecycleState(value["current_state"])
        if current == LifecycleState.DATA_DISCOVERY:
            self.advance_to(LifecycleState.GOAL_DEFINITION, reason="input characterization started")
        elif current == LifecycleState.DATA_CHARACTERIZATION:
            self.transition(LifecycleState.GOAL_DEFINITION, reason="input characterization confirmed")
        return self.transition(LifecycleState.REQUIREMENTS_CONFIRMED, reason="all required fields confirmed")
