"""Global resource configuration for Microbiome tools.

Centralizes CPU/GPU thread control so every tool respects user-specified limits.
Usage:

    from microbiome.resource_config import get_config, set_config
    cfg = get_config()          # -> ResourceConfig instance
    cfg.threads                 # effective CPU threads
    cfg.gpu                     # effective GPU count
    set_config(threads=16, gpu=0)   # override globally

Environment variables:
    MICROBIOME_THREADS     – default CPU threads (overridden by set_config)
    MICROBIOME_GPU         – default GPU count (overridden by set_config)
    MICROBIOME_MEMORY_GB   – default RAM budget in GB (overridden by set_config)

Resource maximization:
    get_config().utilization_directive() returns a concrete, Chinese-language
    directive (exact thread counts, RAM budget, GPU/VRAM, parallel samples)
    that the agent's pilot and full-run execution prompts embed, so every
    pilot validation and every full run exploits ALL usable CPU, RAM and VRAM
    instead of idling server resources.
"""

import multiprocessing
import os
from dataclasses import asdict, dataclass, field


def _detect_cpus():
    """Return (min_reasonable, max_available) CPU count."""
    n = multiprocessing.cpu_count()
    try:
        n = min(n, len(os.sched_getaffinity(0)))
    except (AttributeError, OSError):
        pass
    try:
        with open("/sys/fs/cgroup/cpu.max", encoding="utf-8") as handle:
            quota, period = handle.read().split()[:2]
        if quota != "max":
            n = min(n, max(1, int(quota) // int(period)))
    except (OSError, ValueError, ZeroDivisionError):
        pass
    return max(1, n // 4), n


def _detect_gpus():
    """Return number of visible GPUs (0 if none / not determinable)."""
    try:
        import subprocess

        res = subprocess.run(
            ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
            capture_output=True,
            text=True,
            check=False,
            timeout=5,
        )
        if res.returncode == 0:
            return max(0, len(res.stdout.strip().splitlines()))
    except Exception:
        pass
    return 0


def _detect_memory_gb():
    """Return (total_gb, available_gb) of system RAM (0, 0 if undeterminable)."""
    try:
        info = {}
        with open("/proc/meminfo") as fh:
            for line in fh:
                parts = line.split()
                if parts and parts[0].rstrip(":") in ("MemTotal", "MemAvailable"):
                    info[parts[0].rstrip(":")] = int(parts[1])  # kB
        if info.get("MemTotal"):
            return round(info["MemTotal"] / 1024**2), round(info.get("MemAvailable", 0) / 1024**2)
    except Exception:
        pass
    try:  # macOS fallback
        import subprocess

        res = subprocess.run(["sysctl", "-n", "hw.memsize"], capture_output=True, text=True, check=False, timeout=5)
        if res.returncode == 0 and res.stdout.strip().isdigit():
            total = round(int(res.stdout.strip()) / 1024**3)
            return total, total
    except Exception:
        pass
    return 0, 0


def _detect_gpu_memory_gb():
    """Return total VRAM in GB across all visible GPUs (0 if undeterminable)."""
    try:
        import subprocess

        res = subprocess.run(
            ["nvidia-smi", "--query-gpu=memory.total", "--format=csv,noheader,nounits"],
            capture_output=True,
            text=True,
            check=False,
            timeout=5,
        )
        if res.returncode == 0:
            mib = sum(int(x.strip()) for x in res.stdout.strip().splitlines() if x.strip().isdigit())
            return round(mib / 1024)
    except Exception:
        pass
    return 0


@dataclass(frozen=True)
class ResourceSnapshot:
    """Live resources that may safely be allocated to one pipeline node."""

    cpu_threads: int
    memory_total_gb: int
    memory_available_gb: int
    memory_budget_gb: int
    gpu_count: int
    gpu_memory_gb: int
    gpu_devices: str
    max_parallel_samples: int
    memory_utilization_fraction: float = 0.9

    def as_dict(self):
        return asdict(self)


@dataclass
class ResourceConfig:
    """Mutable global resource configuration."""

    threads: int = field(default_factory=lambda: int(os.environ.get("MICROBIOME_THREADS", 0)) or _detect_cpus()[1])
    gpu: int = field(
        default_factory=lambda: (
            _detect_gpus() if os.environ.get("MICROBIOME_GPU") in (None, "") else max(0, int(os.environ["MICROBIOME_GPU"]))
        )
    )
    max_parallel_samples: int = field(default_factory=lambda: int(os.environ.get("MICROBIOME_MAX_PARALLEL", 4)))
    # RAM budget in GB; defaults to total system memory so runs never under-use RAM.
    memory_gb: int = field(default_factory=lambda: int(os.environ.get("MICROBIOME_MEMORY_GB", 0)) or _detect_memory_gb()[0])

    @property
    def cpu_range(self):
        """(min_reasonable, max_available) for prompting."""
        return _detect_cpus()

    def clamp_threads(self, value, user_specified=False):
        """Clamp a requested thread count to the available range.

        When user_specified=True, only cap at the maximum (don't enforce a minimum).
        """
        lo, hi = self.cpu_range
        v = int(value)
        if user_specified:
            return max(1, min(hi, v))
        return max(lo, min(hi, v))

    def summary(self):
        lo, hi = self.cpu_range
        _, avail_ram = _detect_memory_gb()
        mem = f"RAM: {self.memory_gb} GB"
        if avail_ram:
            mem += f" (available: {avail_ram} GB)"
        gpu_part = f"GPUs: {self.gpu}"
        vram = _detect_gpu_memory_gb()
        if self.gpu and vram:
            gpu_part += f" (VRAM: {vram} GB)"
        return (
            f"CPUs: {self.threads} (system: {lo}-{hi}) | {mem} | {gpu_part} | "
            f"Max parallel samples: {self.max_parallel_samples}"
        )

    def snapshot(self, *, threads_cap=None, memory_cap_gb=None, gpu_cap=None):
        """Return one consistent, live allocation snapshot.

        Optional values are upper bounds.  The result always respects process CPU
        affinity, current free RAM, visible GPUs, and the global configuration.
        Ninety percent of currently usable RAM is exposed to a node so the OS and
        command logging remain responsive under a maximal analysis workload.
        """
        _, detected_threads = _detect_cpus()
        selected_threads = min(max(1, int(self.threads)), detected_threads)
        if threads_cap is not None:
            if int(threads_cap) < 1:
                raise ValueError("threads_cap must be at least 1")
            selected_threads = min(selected_threads, int(threads_cap))

        total_ram, available_ram = _detect_memory_gb()
        configured_ram = max(1, int(self.memory_gb))
        usable_ram = min(configured_ram, available_ram) if available_ram else configured_ram
        if memory_cap_gb is not None:
            if int(memory_cap_gb) < 1:
                raise ValueError("memory_cap_gb must be at least 1")
            usable_ram = min(usable_ram, int(memory_cap_gb))
        memory_budget = max(1, int(usable_ram * 0.9))

        detected_gpus = _detect_gpus()
        selected_gpus = min(max(0, int(self.gpu)), detected_gpus)
        if gpu_cap is not None:
            if int(gpu_cap) < 0:
                raise ValueError("gpu_cap cannot be negative")
            selected_gpus = min(selected_gpus, int(gpu_cap))
        visible = os.environ.get("CUDA_VISIBLE_DEVICES")
        if visible is None:
            device_ids = [str(index) for index in range(selected_gpus)]
        elif visible.strip().casefold() in {"", "-1", "none", "nodevfiles"}:
            device_ids = []
            selected_gpus = 0
        else:
            device_ids = [item.strip() for item in visible.split(",") if item.strip()][:selected_gpus]
            selected_gpus = min(selected_gpus, len(device_ids))
        total_vram = _detect_gpu_memory_gb()
        selected_vram = round(total_vram * selected_gpus / detected_gpus) if detected_gpus else 0
        return ResourceSnapshot(
            cpu_threads=selected_threads,
            memory_total_gb=total_ram,
            memory_available_gb=available_ram,
            memory_budget_gb=memory_budget,
            gpu_count=selected_gpus,
            gpu_memory_gb=selected_vram,
            gpu_devices=",".join(device_ids),
            max_parallel_samples=max(1, min(int(self.max_parallel_samples), selected_threads)),
        )

    def utilization_directive(self):
        """Concrete instructions so pilot and full runs exploit ALL server resources.

        Embedded into the agent's execution prompts; uses the *configured* limits
        (post prompt_resources()/set_config()) and live-detected availability.
        """
        _, avail_ram = _detect_memory_gb()
        # Budget: ~90% of what is usable right now, never above the configured cap.
        usable = min(self.memory_gb, avail_ram) if avail_ram else self.memory_gb
        mem_budget = max(1, int(usable * 0.9))
        lines = [
            "【服务器资源利用要求】本机资源必须全部用起来，严禁浪费 CPU、内存和显存：",
            f"- CPU：共 {self.threads} 线程可用。每条支持多线程的命令都必须显式带上线程参数"
            f"（按软件实际参数名，如 -t {self.threads}、--threads {self.threads}、-p {self.threads}、"
            f"-nt {self.threads}、--cpus {self.threads}），禁止省略参数默认单线程运行。",
            f"- 内存：共 {self.memory_gb} GB"
            + (f"（当前可用约 {avail_ram} GB）" if avail_ram else "")
            + f"。支持内存参数的软件（如 SPAdes -m、MEGAHIT --memory、Kraken2/Kaiju 等加载大型数据库的工具）"
            f"应把内存预算设为约 {mem_budget} GB，而不是保守的小数值。",
        ]
        if self.gpu > 0:
            vram = _detect_gpu_memory_gb()
            lines.append(
                f"- GPU：检测到 {self.gpu} 个 GPU"
                + (f"，显存共约 {vram} GB" if vram else "")
                + "。支持 GPU 的软件必须显式启用其 GPU 选项（如 --gpu、--device cuda、-g 等），不得闲置显卡。"
            )
        per_sample = max(1, self.threads // self.max_parallel_samples)
        lines.append(
            f"- 并行：有多个样本/输入文件时最多并行处理 {self.max_parallel_samples} 个"
            f"（每样本约 {per_sample} 线程，按总线程数 {self.threads} 合理分配，避免超售）。"
        )
        lines.append(
            "- 上述要求同样适用于小数据试跑和全量运行：试跑只缩小数据量，线程、内存和 GPU 投入保持不变，"
            "以便准确估计全量运行的资源需求。"
        )
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Singleton
# ---------------------------------------------------------------------------
_DEFAULT = None


def get_config():
    """Return the global ResourceConfig singleton."""
    global _DEFAULT
    if _DEFAULT is None:
        _DEFAULT = ResourceConfig()
    return _DEFAULT


def set_config(threads=None, gpu=None, max_parallel_samples=None, memory_gb=None):
    """Update the global configuration."""
    cfg = get_config()
    if threads is not None:
        cfg.threads = cfg.clamp_threads(threads, user_specified=True)
    if gpu is not None:
        cfg.gpu = max(0, int(gpu))
    if max_parallel_samples is not None:
        cfg.max_parallel_samples = max(1, int(max_parallel_samples))
    if memory_gb is not None:
        cfg.memory_gb = max(1, int(memory_gb))
    return cfg


def prompt_resources():
    """Interactively ask the user for resource limits. Returns ResourceConfig.

    Skips the prompt silently when stdin is not a TTY (e.g. in pytest or
    non-interactive shells).
    """
    import sys

    cfg = get_config()
    lo, hi = cfg.cpu_range
    gpu_detected = _detect_gpus()
    total_ram, avail_ram = _detect_memory_gb()
    vram_gb = _detect_gpu_memory_gb()

    if not sys.stdin.isatty():
        print(f"[microbiome] 非交互环境，使用当前资源配置: {cfg.summary()}")
        return cfg

    print("=" * 50)
    print("Microbiome 资源配置")
    print("=" * 50)
    print(f"检测到 CPU: {hi} 核 (建议范围 {lo}-{hi})")
    if total_ram:
        print(f"检测到内存: {total_ram} GB (当前可用 {avail_ram} GB)")
    print(f"检测到 GPU: {gpu_detected} 个" + (f" (显存共约 {vram_gb} GB)" if gpu_detected and vram_gb else ""))
    print("默认已按最大化利用设置：全部 CPU 线程、全部内存、全部 GPU 都会投入使用。")
    print(f"当前设置: {cfg.summary()}")
    print()

    try:
        t = input(f"最大 CPU 线程数 [{cfg.threads}]: ").strip()
        if t:
            cfg.threads = cfg.clamp_threads(int(t))
    except (EOFError, ValueError):
        pass

    try:
        g = input(f"GPU 数量 [{cfg.gpu}]: ").strip()
        if g:
            cfg.gpu = max(0, int(g))
    except (EOFError, ValueError):
        pass

    try:
        p = input(f"最大并行样本数 [{cfg.max_parallel_samples}]: ").strip()
        if p:
            cfg.max_parallel_samples = max(1, int(p))
    except (EOFError, ValueError):
        pass

    print(f"\n已设置: {cfg.summary()}")
    print("=" * 50)
    return cfg


# Convenience alias for tools
def threads(default=None):
    """Return the effective thread count, optionally overriding the global default."""
    cfg = get_config()
    return cfg.threads if default is None else cfg.clamp_threads(default)
