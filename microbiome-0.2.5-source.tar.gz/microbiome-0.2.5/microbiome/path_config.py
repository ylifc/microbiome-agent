"""Global path configuration for Microbiome: raw data, databases, and results.

At startup the CLI runs a short three-round dialogue (三轮询问) asking the user for:

1. 原始数据存放的地址       -> PathConfig.raw_data_dir  (the program finds/operates raw data here)
2. 数据库的位置             -> PathConfig.db_root       (the program finds/calls databases here)
3. 生成数据和结果的存放路径 -> PathConfig.results_dir   (all generated data/results go here)

Usage:

    from microbiome.path_config import get_path_config, set_paths, prompt_paths
    cfg = get_path_config()        # -> PathConfig singleton
    cfg.raw_data_dir               # raw-data directory
    cfg.db_root                    # database root
    cfg.results_dir                # results directory
    set_paths(raw_data_dir="/x")   # override globally
    prompt_paths()                 # three-round interactive dialogue

The answers are also exported as environment variables so that every tool —
including ones that resolve paths at import time (e.g. DEFAULT_DB_ROOT in
microbiome.tool.microbial_databases) — sees the user-chosen locations, as long as
set_paths()/prompt_paths() runs before those modules are imported (the CLI does
this at the very start of main()).

Environment variables:
    MICROBIOME_DATA_DIR     – default raw-data directory (overridden by set_paths/prompt)
    MICROBIOME_DOWNLOAD_DIR – downloaded input-data directory (defaults to raw-data directory)
    MICROBIOME_DB_ROOT      – default database root      (overridden by set_paths/prompt)
    MICROBIOME_RESULTS_DIR  – default results directory  (overridden by set_paths/prompt)
"""

import os
from dataclasses import dataclass, field

# Project root (the folder containing the microbiome/ package), used to anchor the
# default Database/ root exactly like microbiome.tool.microbial_databases does.
_PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def _normalize(p):
    """Expand ~ and environment vars, and make a path absolute."""
    return os.path.abspath(os.path.expandvars(os.path.expanduser(p.strip())))


def _default_raw_data_dir():
    return os.environ.get("MICROBIOME_DATA_DIR") or "./data"


def _default_db_root():
    return os.environ.get("MICROBIOME_DB_ROOT") or os.path.join(_PROJECT_ROOT, "Database")


def _default_download_dir():
    return os.environ.get("MICROBIOME_DOWNLOAD_DIR") or _default_raw_data_dir()


def _default_results_dir():
    return os.environ.get("MICROBIOME_RESULTS_DIR") or "./out"


def _default_software_memory_dir():
    return os.environ.get("MICROBIOME_SOFTWARE_MEMORY_DIR") or os.path.join(
        os.path.dirname(_default_db_root()), "software_memory"
    )


@dataclass
class PathConfig:
    """Mutable global path configuration (raw data / databases / results / memory)."""

    raw_data_dir: str = field(default_factory=lambda: _normalize(_default_raw_data_dir()))
    download_dir: str = field(default_factory=lambda: _normalize(_default_download_dir()))
    db_root: str = field(default_factory=lambda: _normalize(_default_db_root()))
    results_dir: str = field(default_factory=lambda: _normalize(_default_results_dir()))
    software_memory_dir: str = field(default_factory=lambda: _normalize(_default_software_memory_dir()))

    def summary(self):
        return (
            f"原始数据目录: {self.raw_data_dir} | "
            f"下载数据目录: {self.download_dir} | "
            f"数据库目录: {self.db_root} | "
            f"结果目录: {self.results_dir} | "
            f"软件记忆目录: {self.software_memory_dir}"
        )


# ---------------------------------------------------------------------------
# Singleton
# ---------------------------------------------------------------------------
_DEFAULT = None


def get_path_config():
    """Return the global PathConfig singleton."""
    global _DEFAULT
    if _DEFAULT is None:
        _DEFAULT = PathConfig()
    return _DEFAULT


def _export_env(cfg):
    """Export the configured paths as env vars so subprocesses and tools see them.

    MICROBIOME_DATA_ROOT is exported as an alias of MICROBIOME_DOWNLOAD_DIR because
    staged data acquisitions resolve their destination from that variable.
    """
    os.environ["MICROBIOME_DATA_DIR"] = cfg.raw_data_dir
    os.environ["MICROBIOME_DOWNLOAD_DIR"] = cfg.download_dir
    os.environ["MICROBIOME_DATA_ROOT"] = cfg.download_dir
    os.environ["MICROBIOME_DB_ROOT"] = cfg.db_root
    os.environ["MICROBIOME_RESULTS_DIR"] = cfg.results_dir
    os.environ["MICROBIOME_SOFTWARE_MEMORY_DIR"] = cfg.software_memory_dir


def set_paths(raw_data_dir=None, download_dir=None, db_root=None, results_dir=None, software_memory_dir=None):
    """Update the global path configuration and export MICROBIOME_* env vars."""
    cfg = get_path_config()
    if raw_data_dir:
        cfg.raw_data_dir = _normalize(raw_data_dir)
        if download_dir is None:
            cfg.download_dir = cfg.raw_data_dir
    if download_dir:
        cfg.download_dir = _normalize(download_dir)
    if db_root:
        cfg.db_root = _normalize(db_root)
    if results_dir:
        cfg.results_dir = _normalize(results_dir)
    if software_memory_dir:
        cfg.software_memory_dir = _normalize(software_memory_dir)
    _export_env(cfg)
    return cfg


def _ask(question, default):
    """input() wrapper.

    Returns the user's answer, or `default` when the user just presses Enter,
    or None on EOF/KeyboardInterrupt (caller should fall back to the default
    and stop asking).
    """
    try:
        ans = input(f"{question} [{default}]: ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return None
    return ans or default


def _confirm(question):
    """Yes/no question; defaults to No on empty answer or EOF."""
    try:
        return input(question).strip().lower() in ("y", "yes", "是")
    except (EOFError, KeyboardInterrupt):
        print()
        return False


def _ask_dir(round_no, title, hint, question, default, must_exist):
    """One round of the dialogue: ask for a directory with validation.

    must_exist=True  -> warn and re-ask when the directory does not exist
                        (the user may still confirm a missing path explicitly).
    must_exist=False -> create the directory when missing (results dir).
    Empty answer / EOF falls back to `default`.
    """
    print(f"\n🤖 第 {round_no}/4 轮 · Round {round_no}/4：{title}")
    print(f"   {hint}")
    while True:
        ans = _ask(question, default)
        if ans is None:  # EOF / Ctrl-C: accept the default and stop asking
            return default
        cand = _normalize(ans)
        if cand == default or os.path.isdir(cand):
            return cand
        if must_exist:
            print(f"   ⚠️ 路径不存在 / Path not found：{cand}")
            if _confirm("   仍然使用该路径？ Use it anyway? (y/N): "):
                return cand
            print("   请重新输入（直接回车使用默认路径）/ Re-enter, or press Enter for the default.")
        else:
            try:
                os.makedirs(cand, exist_ok=True)
                print(f"   📁 已创建目录 / Created directory：{cand}")
                return cand
            except OSError as e:
                print(f"   ⚠️ 无法创建目录 / Cannot create directory {cand}：{e}")
                print("   请重新输入（直接回车使用默认路径）/ Re-enter, or press Enter for the default.")


def prompt_paths(
    raw_data_default=None,
    download_default=None,
    db_default=None,
    results_default=None,
    software_memory_default=None,
):
    """Four-round interactive dialogue asking for raw-data, database, results and memory paths.

    Round 1: where the raw data lives     -> the program searches/operates raw data there.
    Round 2: where the databases live     -> the program finds/calls databases there.
    Round 3: where generated data/results -> the program writes results there.
    Round 4: software memory directory    -> per-software validated usage/failure records.

    The answers update the global PathConfig and are exported as MICROBIOME_DATA_DIR /
    MICROBIOME_DB_ROOT / MICROBIOME_RESULTS_DIR / MICROBIOME_SOFTWARE_MEMORY_DIR. Returns the
    PathConfig.

    Skips the dialogue silently (using defaults / env vars) when stdin is not a
    TTY (e.g. in pytest or non-interactive shells), mirroring prompt_resources().
    """
    import sys

    cfg = get_path_config()
    explicit_download_default = download_default is not None
    raw_default = _normalize(raw_data_default) if raw_data_default else cfg.raw_data_dir
    download_default = _normalize(download_default) if explicit_download_default else raw_default
    db_default = _normalize(db_default) if db_default else cfg.db_root
    results_default = _normalize(results_default) if results_default else cfg.results_dir
    memory_default = _normalize(software_memory_default) if software_memory_default else cfg.software_memory_dir

    if not sys.stdin.isatty():
        set_paths(
            raw_data_dir=raw_default,
            download_dir=download_default,
            db_root=db_default,
            results_dir=results_default,
            software_memory_dir=memory_default,
        )
        print(f"[microbiome] 非交互环境，使用路径配置 / Non-interactive, using path config: {cfg.summary()}")
        return cfg

    print("=" * 50)
    print("Microbiome 路径配置（四轮询问 / Four-round path setup）")
    print("=" * 50)

    # --- Round 1: raw data location ---
    raw_data_dir = _ask_dir(
        1,
        "请问您的【原始数据】存放在哪个路径？ / Where is your raw data located?",
        "程序将从该路径寻找和操作原始数据。 / The program reads and operates on raw data from this directory.",
        "原始数据路径 / Raw data path",
        raw_default,
        must_exist=True,
    )

    # --- Round 2: database location ---
    db_root = _ask_dir(
        2,
        "请问您要调用的【数据库】存放在哪个路径？ / Where are your databases located?",
        "程序将从该路径寻找和调用数据库（swissprot、genomad、checkv、gtdbtk 等）。 / The program finds and calls databases (swissprot, genomad, checkv, gtdbtk, etc.) from here.",
        "数据库路径 / Database path",
        db_default,
        must_exist=True,
    )

    # --- Round 3: results location ---
    results_dir = _ask_dir(
        3,
        "请问【生成的数据和结果】要存放到哪个路径？ / Where should generated data and results be saved?",
        "程序运行产生的所有文件和结果将写入该路径（不存在时会自动创建）。 / All generated files and results are written here (auto-created if missing).",
        "结果存放路径 / Results path",
        results_default,
        must_exist=False,
    )

    # --- Round 4: software memory location ---
    software_memory_dir = _ask_dir(
        4,
        "请问【软件记忆】要存放到哪个路径？ / Where should the software memory be stored?",
        "记录每个软件已验证的成功用法与失败记录（默认与数据库同级的 software_memory/）。 / Stores each software's validated usage and failure records (default: software_memory/ next to the database).",
        "软件记忆路径 / Software memory path",
        memory_default,
        must_exist=False,
    )

    set_paths(
        raw_data_dir=raw_data_dir,
        download_dir=download_default if explicit_download_default else raw_data_dir,
        db_root=db_root,
        results_dir=results_dir,
        software_memory_dir=software_memory_dir,
    )
    print(f"\n✅ 路径设置完成 / Path configuration done：{cfg.summary()}")
    print("=" * 50)
    return cfg
