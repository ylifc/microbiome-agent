"""Task-level analysis experience: proven/failed workflows and nested workflows.

Captures the full analysis path used for a task (including nested/sub-workflows)
together with its outcome, so later planning can reuse proven paths and avoid
repeating failed ones. This complements the per-software ``software_memory``
and the per-invocation execution ledger: this layer is the *workflow* grain.

Storage
-------
``MICROBIOME_ANALYSIS_EXPERIENCE_DIR`` (default ``<project>/analysis_experience/``).
Records append to ``experience.jsonl``; a human-readable ``index.md`` is kept
alongside. Disable with ``MICROBIOME_ANALYSIS_EXPERIENCE=0``.

Stdlib-only, so it can be imported from the agent and the pipeline alike.
"""

from __future__ import annotations

import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path

_ENV_DIR = "MICROBIOME_ANALYSIS_EXPERIENCE_DIR"
_ENV_DISABLE = "MICROBIOME_ANALYSIS_EXPERIENCE"
_JSONL_NAME = "experience.jsonl"
_INDEX_NAME = "index.md"
_DEFAULT_LIMIT = 5
_DEFAULT_MAX_CHARS = 2600


def enabled() -> bool:
    return os.environ.get(_ENV_DISABLE, "1").strip().lower() not in {"0", "false", "no", "off"}


def experience_root() -> Path:
    override = os.environ.get(_ENV_DIR, "").strip()
    if override:
        return Path(override).expanduser()
    try:
        from microbiome.path_config import get_path_config

        return Path(get_path_config().results_dir).expanduser().resolve() / "analysis_experience"
    except Exception:
        return Path(os.environ.get("MICROBIOME_RESULTS_DIR", ".")) / "analysis_experience"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _records(path: Path) -> list[dict]:
    if not path.is_file():
        return []
    records: list[dict] = []
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            try:
                item = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(item, dict):
                records.append(item)
    return records


def record_experience(
    task: str,
    workflow: str,
    outcome: str,
    *,
    nested: list[str] | None = None,
    summary: str = "",
    phase: str = "",
    root: Path | None = None,
) -> Path | None:
    """Append one analysis-experience record.

    Parameters
    ----------
    task : str
        The natural-language task this workflow served.
    workflow : str
        The analysis path / workflow (e.g. the numbered plan).
    nested : list[str], optional
        Nested or per-sample / per-family sub-workflows.
    outcome : str
        One of ``success`` / ``partial`` / ``failed``.
    summary : str, optional
        A short reusable lesson (what worked, what to avoid).
    phase : str, optional
        ``pilot`` or ``full``.
    """
    if not enabled():
        return None
    root = root or experience_root()
    try:
        root.mkdir(parents=True, exist_ok=True)
    except OSError:
        return None

    record = {
        "timestamp": _now(),
        "task": (task or "").strip()[:2000],
        "workflow": (workflow or "").strip()[:8000],
        "nested": [str(n).strip()[:1000] for n in (nested or []) if str(n).strip()],
        "outcome": outcome if outcome in {"success", "partial", "failed"} else "partial",
        "phase": (phase or "").strip()[:40],
        "summary": (summary or "").strip()[:2000],
    }
    try:
        with (root / _JSONL_NAME).open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")
        _append_index(root / _INDEX_NAME, record)
    except OSError:
        return None
    return root / _JSONL_NAME


def _append_index(path: Path, record: dict) -> None:
    try:
        nested_block = ""
        if record.get("nested"):
            nested_block = "\n- 嵌套子流程: " + "；".join(record["nested"])
        phase = f" [{record['phase']}]" if record.get("phase") else ""
        text = (
            f"\n## {record['timestamp']} — {record['outcome'].upper()}{phase}\n"
            f"- 任务: {record['task']}\n"
            f"- 工作流: {record['workflow']}"
            f"{nested_block}\n"
            f"- 小结: {record['summary'] or '（无）'}\n"
        )
        if not path.exists():
            path.write_text("# 分析经验索引（自动维护）\n", encoding="utf-8")
        with path.open("a", encoding="utf-8") as handle:
            handle.write(text)
    except OSError:
        pass


# ---------------------------------------------------------------------------
# 检索（注入规划提示词）
# ---------------------------------------------------------------------------


def _tokens(text: str) -> set[str]:
    lowered = (text or "").lower()
    tokens: set[str] = set()
    # CJK：连续的汉字串按 2-4 字滑窗拆词，兼顾词组匹配
    for run in re.findall(r"[\u4e00-\u9fff]+", lowered):
        for size in (2, 3, 4):
            for i in range(0, max(1, len(run) - size + 1)):
                tokens.add(run[i : i + size])
    # 拉丁/数字：2+ 字符的普通词元
    for token in re.findall(r"[a-z0-9][a-z0-9_.+-]{1,}", lowered):
        tokens.add(token)
    return tokens


def _score(query_tokens: set[str], record: dict) -> float:
    if not query_tokens:
        return 0.0
    haystack = " ".join(
        [record.get("task", ""), record.get("workflow", ""), record.get("summary", "")]
        + list(record.get("nested") or [])
    )
    rec_tokens = _tokens(haystack)
    overlap = query_tokens & rec_tokens
    return len(overlap) / max(1, len(query_tokens))


def relevant_experience(
    task: str,
    *,
    max_chars: int = _DEFAULT_MAX_CHARS,
    limit: int = _DEFAULT_LIMIT,
    root: Path | None = None,
) -> str:
    """Return a condensed brief of past workflows relevant to ``task`` ('' when none)."""
    if not enabled() or not (task or "").strip():
        return ""
    root = root or experience_root()
    records = _records(root / _JSONL_NAME)
    if not records:
        return ""
    query_tokens = _tokens(task)
    scored = sorted(
        ((_score(query_tokens, r), r) for r in records),
        key=lambda pair: pair[0],
        reverse=True,
    )
    chosen = [r for s, r in scored if s > 0][:limit]
    if not chosen:
        return ""

    blocks: list[str] = []
    for r in chosen:
        lines = [f"- [{r.get('timestamp', '')}] {r.get('outcome', '').upper()} — {r.get('task', '')}"]
        workflow = (r.get("workflow") or "").strip()
        if workflow:
            lines.append("  工作流: " + " ".join(workflow.split())[:600])
        if r.get("nested"):
            lines.append("  嵌套子流程: " + "；".join(r["nested"])[:400])
        if r.get("summary"):
            lines.append("  小结: " + r["summary"][:400])
        blocks.append("\n".join(lines))

    text = "本次任务可参考的历史分析经验（优先复用已验证路径，避免重复失败路径）：\n" + "\n\n".join(blocks)
    return text[:max_chars] + ("\n…（经验已截断）" if len(text) > max_chars else "")


def query_analysis_experience(
    task: str,
    max_chars: int = _DEFAULT_MAX_CHARS,
    limit: int = _DEFAULT_LIMIT,
) -> str:
    """Read-only lookup of past analysis experience relevant to ``task``.

    Exposed to the agent's planning read-only tool allowlist so the planner can
    explicitly consult proven/failed workflows before drafting a plan. Returns a
    human-readable brief, or a clear "no records" message when none match.
    """
    brief = relevant_experience(task, max_chars=max_chars, limit=limit)
    if not brief:
        return "无相关的历史分析经验记录。\nNo relevant prior analysis experience found."
    return brief
