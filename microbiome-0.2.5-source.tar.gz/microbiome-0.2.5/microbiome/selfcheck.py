"""Fresh-install self-check for Microbiome.

Verifies that the package, its agent, the DeepSeek Harness driver, the frozen
pipeline, and the data-bearing subsystems (resource skills, know-how, software
memory) all import and load. Returns exit code 0 when every check passes, or 1
when any check fails, so it can gate a deployment.
"""

from __future__ import annotations

import argparse
import importlib
import os
import sys
from collections import Counter
from pathlib import Path

import yaml

_MODULE_CHECKS = (
    ("microbiome", "core package"),
    ("microbiome.cli", "CLI entry (microbiome-run)"),
    ("microbiome.agent", "conversational A1 agent"),
    ("microbiome.dsh_driver", "DeepSeek Harness driver"),
    ("microbiome.pipeline", "frozen production pipeline"),
    ("microbiome.input_resolution", "local-first input resolver"),
    ("microbiome.resource_skills", "resource skill registry"),
    ("microbiome.know_how", "know-how loader"),
    ("microbiome.software_memory", "per-software execution memory"),
    ("microbiome.analysis_experience", "task-level analysis experience"),
    ("microbiome.tool.sra_retrieval", "staged SRA retrieval"),
    ("microbiome.pipeline.pretest_evidence", "pre-test evidence validator"),
)


def _check_module(module: str, label: str) -> bool:
    try:
        importlib.import_module(module)
        print(f"  [OK]   {label:<34} {module}")
        return True
    except Exception as exc:
        print(f"  [FAIL] {label:<34} {module}: {type(exc).__name__}: {exc}")
        return False


def _check_data() -> bool:
    ok = True
    try:
        from microbiome.resource_skills import ResourceSkillRegistry

        registry = ResourceSkillRegistry()
        registry.reload()
        count = len(registry.skills)
        print(f"  [OK]   resource skills loaded                     {count} skills")
    except Exception as exc:
        print(f"  [FAIL] resource skills load: {type(exc).__name__}: {exc}")
        ok = False

    try:
        from microbiome.know_how import KnowHowLoader

        docs = KnowHowLoader().documents
        print(f"  [OK]   know-how documents loaded                  {len(docs)} docs")
    except Exception as exc:
        print(f"  [FAIL] know-how load: {type(exc).__name__}: {exc}")
        ok = False

    try:
        from microbiome.analysis_experience import _records, experience_root

        root = experience_root()
        records = _records(root / "experience.jsonl")
        if records:
            print(f"  [OK]   analysis experience records               {len(records)} records")
        else:
            print("  [OK]   analysis experience storage ready         0 records (accumulates as tasks run)")
    except Exception as exc:
        print(f"  [WARN] analysis experience: {type(exc).__name__}: {exc}")

    # DSH integration files must ship with the package.
    package_dir = Path(__file__).resolve().parent
    for name in ("dsh_driver.py", "dsh_preset_plugin.mjs"):
        path = package_dir / name
        if path.is_file():
            print(f"  [OK]   DSH integration file                      {name}")
        else:
            print(f"  [FAIL] DSH integration file missing              {name}")
            ok = False
    return ok


def _check_conda() -> bool:
    """Detect conda/mamba without installing or changing the server."""
    try:
        from microbiome.conda_discovery import find_conda_manager

        manager = find_conda_manager()
        if manager:
            print(f"  [OK]   conda/mamba manager                        {manager}")
            return True
        print("  [WARN] conda/mamba 未找到（只读自检不会自动安装）")
        return False
    except Exception as exc:
        print(f"  [FAIL] conda/mamba discovery: {type(exc).__name__}: {exc}")
        return False


def _tool_registry_path() -> Path:
    from microbiome.resource_skills.registry import DEFAULT_CUSTOM_SKILL_ROOT

    return DEFAULT_CUSTOM_SKILL_ROOT / "tool_registry.yaml"


def _compact_failure_reason(reason: str, limit: int = 500) -> str:
    """Keep the first actionable runtime error instead of a trailing help banner."""
    compact = " ".join(reason.split())
    if len(compact) <= limit:
        return compact
    lowered = compact.casefold()
    markers = (
        "fatal error",
        "command not found",
        "未找到命令",
        "unrecognized tool",
        "error while loading shared libraries",
    )
    offsets = [lowered.find(marker) for marker in markers if lowered.find(marker) >= 0]
    start = max(0, min(offsets) - 100) if offsets else 0
    excerpt = compact[start : start + limit]
    return f"{'… ' if start else ''}{excerpt}{' …' if start + limit < len(compact) else ''}"


def _probe_registered_tools(entries: list[dict], *, verbose: bool) -> tuple[list[str], list[tuple[str, str]]]:
    """Re-run read-only version probes for persisted READY tool contracts."""
    from microbiome.pipeline.errors import ResourceNotReadyError
    from microbiome.pipeline.resources import ToolchainResolver
    from microbiome.resource_skills.registry import PROJECT_ROOT

    resolver = ToolchainResolver(
        PROJECT_ROOT,
        version_probe_timeout=30,
        include_package_inventory=False,
    )
    ready: list[str] = []
    failed: list[tuple[str, str]] = []
    for entry in entries:
        resource_id = str(entry.get("resource_id") or entry.get("tool_id") or "unknown")
        executable = str(entry.get("executable") or "")
        prefix = str(entry.get("conda_prefix") or "") or None
        stored_args = entry.get("version_args")
        candidates: list[list[str]] = []
        if isinstance(stored_args, list):
            candidates.append([str(value) for value in stored_args])
        else:
            candidates.append(["--version"])
        candidates.append([])
        candidates = [candidate for index, candidate in enumerate(candidates) if candidate not in candidates[:index]]
        errors: list[str] = []
        result = None
        for version_args in candidates:
            try:
                result = resolver.resolve_step(
                    {
                        "step_id": f"selfcheck-{resource_id}",
                        "tool": resource_id,
                        "tool_version_requirement": "any",
                        "environment": {
                            "prefix": prefix,
                            "executable": executable,
                            "version_args": version_args,
                        },
                        "version_args": version_args,
                    }
                )
                break
            except ResourceNotReadyError as exc:
                errors.append(str(exc))
        if result is None:
            preferred = next(
                (
                    error
                    for error in errors
                    if any(
                        marker in error.casefold()
                        for marker in (
                            "fatal error",
                            "command not found",
                            "未找到命令",
                            "unrecognized tool",
                            "error while loading shared libraries",
                        )
                    )
                ),
                errors[-1] if errors else "no executable candidate was found",
            )
            failed.append((resource_id, preferred))
            continue
        ready.append(resource_id)
        if verbose:
            version = str(result.get("version_output") or "").splitlines()[0][:120]
            print(f"    [OK]   {resource_id:<24} {version}")
    return ready, failed


def _check_runtime_inventory(*, db_root: str | None, verify_tools: bool, verbose: bool) -> bool:
    """Report executable environments and marker-ready databases without mutation."""
    try:
        from microbiome.resource_skills import ResourceSkillRegistry

        registry = ResourceSkillRegistry(db_root=db_root, tolerate_invalid=True)
    except Exception as exc:
        print(f"  [FAIL] runtime inventory: {type(exc).__name__}: {exc}")
        return False

    software_rows = [(skill, registry.software_status(skill.skill_id)) for skill in registry.list_skills("software")]
    database_rows = [(skill, registry.database_status(skill.skill_id)) for skill in registry.list_skills("database")]
    software_counts = Counter(status.status for _, status in software_rows)
    database_counts = Counter(status.status for _, status in database_rows)
    executable_present = sorted(skill.skill_id for skill, status in software_rows if status.status == "ready")
    marker_ready = sorted(skill.skill_id for skill, status in database_rows if status.status == "ready")
    software_ready_by_id = {skill.skill_id: status.status == "ready" for skill, status in software_rows}
    ready_consumers_by_database: dict[str, list[str]] = {}
    for skill, _status in database_rows:
        compatible = [str(value) for value in skill.metadata.get("compatible_software", [])]
        ready_consumers_by_database[skill.skill_id] = [
            software_id for software_id in compatible if software_ready_by_id.get(software_id, False)
        ]
    directly_usable_databases = sorted(
        skill.skill_id
        for skill, status in database_rows
        if status.status == "ready" and ready_consumers_by_database[skill.skill_id]
    )

    print(f"  [OK]   Conda environments catalogued              {len(registry.environment_catalog)}")
    print(
        "  [INFO] software skills with all executables       "
        f"{len(executable_present)}/{len(software_rows)} "
        f"({', '.join(f'{key}={value}' for key, value in sorted(software_counts.items()))})"
    )
    print(
        "  [INFO] databases satisfying readiness markers     "
        f"{len(marker_ready)}/{len(database_rows)} "
        f"({', '.join(f'{key}={value}' for key, value in sorted(database_counts.items()))})"
    )
    print(f"  [INFO] marker-ready DBs with ready consumers       {len(directly_usable_databases)}/{len(marker_ready)}")
    print(f"  [INFO] database root                               {registry.db_root}")

    if verbose:
        print("\n  软件环境明细 / Software environment details:")
        for skill, status in software_rows:
            suffix = status.path or status.environment or "—"
            missing = f"; missing={','.join(status.missing)}" if status.missing else ""
            print(f"    [{status.status.upper():<20}] {skill.skill_id:<20} {suffix}{missing}")
        print("\n  数据库明细 / Database details:")
        for skill, status in database_rows:
            compatible = ",".join(str(value) for value in skill.metadata.get("compatible_software", []))
            ready_consumers = ",".join(ready_consumers_by_database[skill.skill_id])
            missing = f"; missing={','.join(status.missing)}" if status.missing else ""
            print(
                f"    [{status.status.upper():<20}] {skill.skill_id:<20} {status.path}; "
                f"software={compatible or '—'}; ready_consumer={ready_consumers or '—'}{missing}"
            )

    path = _tool_registry_path()
    entries: list[dict] = []
    if path.is_file():
        try:
            payload = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
            entries = [
                value
                for value in (payload.get("tools") or {}).values()
                if isinstance(value, dict)
                and value.get("status") == "READY"
                and value.get("validation_result") == "PASSED"
            ]
        except (OSError, yaml.YAMLError) as exc:
            print(f"  [FAIL] persisted tool registry                    {type(exc).__name__}: {exc}")
            return False
    if entries:
        existing = [entry for entry in entries if os.access(str(entry.get("executable") or ""), os.X_OK)]
        print(
            "  [INFO] persisted validated tool contracts         "
            f"{len(existing)}/{len(entries)} executable paths still present"
        )
    else:
        print(f"  [INFO] persisted validated tool contracts         none at {path}")

    if not verify_tools:
        print("  [INFO] current version smoke tests                 skipped (use --verify-tools)")
        return not registry.load_errors

    print("\n  当前版本烟测 / Current version smoke tests:")
    ready, failed = _probe_registered_tools(entries, verbose=verbose)
    print(f"  [INFO] current runnable validated contracts       {len(ready)}/{len(entries)}")
    for resource_id, reason in failed:
        print(f"    [FAIL] {resource_id:<24} {_compact_failure_reason(reason)}")
    return not failed and not registry.load_errors


def _parse_args(argv) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="microbiome-selfcheck",
        description="Read-only module, software-environment, and database readiness check.",
    )
    parser.add_argument(
        "--db-root",
        default=os.environ.get("MICROBIOME_DB_ROOT"),
        help="Database root to inspect (default: MICROBIOME_DB_ROOT or project Database/).",
    )
    parser.add_argument(
        "--verify-tools", action="store_true", help="Re-run read-only version smoke tests for persisted READY tools."
    )
    parser.add_argument("--verbose", action="store_true", help="Print every software environment and database status.")
    return parser.parse_args(argv)


def main(argv=None) -> int:
    args = _parse_args(argv)
    print("=" * 72)
    print("  Microbiome 自检 / Self-check — 微生物生物信息分析 Agent")
    print("  Microbial Bioinformatics Analysis Agent")
    print("=" * 72)

    ok = True
    print("\n模块导入 / Module imports:")
    for module, label in _MODULE_CHECKS:
        ok = _check_module(module, label) and ok

    print("\n数据与集成资源 / Data & integration resources:")
    ok = _check_data() and ok

    print("\n运行环境 / Runtime environment:")
    _check_conda()

    print("\n可直接运行资源 / Directly runnable resources:")
    ok = (
        _check_runtime_inventory(
            db_root=args.db_root,
            verify_tools=args.verify_tools,
            verbose=args.verbose,
        )
        and ok
    )

    print("\n" + "=" * 72)
    if ok:
        print("  ✅ 全部通过 / All checks passed")
        print("=" * 72)
        return 0
    print("  ❌ 存在失败项 / Some checks failed")
    print("=" * 72)
    return 1


if __name__ == "__main__":
    sys.exit(main())
