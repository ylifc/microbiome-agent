"""Explicit legacy standalone runner; normal use goes through the existing host.

Run a natural-language bioinformatics task without writing any Python:

    microbiome-legacy-run "对 dna_R1.fq 和 dna_R2.fq 做宏基因组拼接、基因预测和分箱"

or enter an interactive chat loop:

    microbiome-legacy-run            # then type tasks at the prompt; Ctrl-D / 'exit' to quit

The model defaults to the local Ollama model in MICROBIOME_OLLAMA_MODEL (default
"qwen3.6:latest"). Set MICROBIOME_DATA_DIR for the working/data directory.

At startup a short three-round dialogue asks for (1) the raw-data directory the
program should find and operate on, (2) the database root the program should
find and call databases from, and (3) the directory where generated data and
results are stored. Answers are exported as MICROBIOME_DATA_DIR / MICROBIOME_DB_ROOT /
MICROBIOME_RESULTS_DIR; skip the dialogue with --no-prompt-paths (it also skips
itself automatically when stdin is not a TTY).
"""

import argparse
import os
import sys

from microbiome.capabilities import welcome_banner


def _setup_env():
    """Make the process network env work for BOTH local Ollama and remote downloads.

    不再无脑清空代理（那会让必须走代理的网络无法下载）：

    - localhost/127.0.0.1/::1 加入 no_proxy，本地 Ollama 永远直连
      （socks 形式的 all_proxy 会让 httpx 在未装 socksio 时直接崩溃）；
    - socks:// 代理归一化为可用形式（socks5h 或同端口 http 代理）；
    - auto 模式（默认）：代理全部不可达且直连可用时才清空代理（修复"残留坏代理"
      环境）；代理可达则保留，供下载走代理；
    - MICROBIOME_PROXY_MODE=direct/proxy 可强制指定，MICROBIOME_PROXY 可显式指定代理。

    只影响本进程，不改动用户 shell。下载侧另有 microbiome.proxy_config 的
    直连↔代理自动轮换兜底。
    """
    from microbiome.proxy_config import sanitize_process_proxy_env

    sanitize_process_proxy_env(log=print)


def _ensure_conda():
    """Discover the manager; installation belongs to an approved dependency plan."""
    try:
        from microbiome.conda_bootstrap import ensure_conda_manager

        manager = ensure_conda_manager(install_if_missing=False)
        if manager:
            print(f"[microbiome-legacy-run] ✅ conda/mamba 就绪：{manager}", flush=True)
        else:
            print(
                "[microbiome-legacy-run] 未检测到 conda/mamba；如分析需要，将列入依赖计划供您确认。",
                flush=True,
            )
    except Exception as exc:
        print(f"[microbiome-legacy-run] ⚠️ conda/mamba 自检跳过：{exc}", flush=True)


def _check_ollama(model, base_url=None):
    """Verify the local Ollama server is reachable and the model is available.

    Prints a clear, immediate OK/FAIL line so the user isn't left waiting silently.
    Returns True if connected (model present), else False.
    """
    import json
    import urllib.request

    base = (base_url or os.environ.get("OLLAMA_BASE_URL") or "http://localhost:11434").rstrip("/")
    base = base[: -len("/v1")] if base.endswith("/v1") else base
    print(f"[microbiome-legacy-run] 正在连接本地 Ollama ({base}) ...", flush=True)
    try:
        with urllib.request.urlopen(base + "/api/tags", timeout=8) as r:
            data = json.loads(r.read().decode())
        models = [m.get("name", "") for m in data.get("models", [])]
        short = model.split(":")[0]
        ok = any(model in m or short in m for m in models)
        if ok:
            print(f"[microbiome-legacy-run] ✅ 已顺利接入模型：{model}（Ollama 在线）", flush=True)
        else:
            print(
                f"[microbiome-legacy-run] ⚠️ Ollama 在线，但未找到模型 {model}；已有：{models}。请 `ollama pull {model}`。",
                flush=True,
            )
        return ok
    except Exception as e:
        print(f"[microbiome-legacy-run] ❌ 未能连接 Ollama（{e}）。请先 `ollama serve` 并 `ollama pull {model}`。", flush=True)
        return False


def _make_agent(data_dir, model, base_url=None, source=None, api_key=None, no_datalake=True, auto_install=True):
    previous = os.environ.get("MICROBIOME_LEGACY_MODEL_CONFIG")
    os.environ.setdefault("MICROBIOME_LEGACY_MODEL_CONFIG", "1")
    try:
        from microbiome.agent import A1

        kwargs = {
            "path": data_dir,
            "llm": model,
            "source": source or "Ollama",
            "auto_install": auto_install,
            "enable_datalake_download": not no_datalake,
        }
        if base_url:
            kwargs["base_url"] = base_url
        if api_key:
            kwargs["api_key"] = api_key
        if no_datalake:
            # Skip downloading the official Microbiome data lake / benchmark (human/clinical,
            # not used by the microbial toolset) so startup is fast.
            kwargs["expected_data_lake_files"] = []
        return A1(**kwargs)
    finally:
        if previous is None:
            os.environ.pop("MICROBIOME_LEGACY_MODEL_CONFIG", None)
        else:
            os.environ["MICROBIOME_LEGACY_MODEL_CONFIG"] = previous


_WELCOME_BANNER = welcome_banner()


def _print_welcome() -> None:
    """Print the bilingual microbial-bioinformatics welcome banner."""
    try:
        print(_WELCOME_BANNER, flush=True)
    except OSError:
        pass


def main(argv=None):
    p = argparse.ArgumentParser(
        prog="microbiome-legacy-run",
        description="Legacy standalone A1 runner; normal use belongs in your existing host with microbiome.",
    )
    p.add_argument(
        "task", nargs="?", default=None, help="Natural-language task. If omitted, starts an interactive loop."
    )
    p.add_argument("--project", help="Resume an existing project with its persisted paths and workflow state.")
    p.add_argument(
        "-m", "--model", default=os.environ.get("MICROBIOME_OLLAMA_MODEL", "qwen3.6:latest"), help="Ollama model name."
    )
    p.add_argument(
        "-d", "--data", default=os.environ.get("MICROBIOME_DATA_DIR", "./data"), help="Data/working directory."
    )
    p.add_argument(
        "--download-dir",
        default=os.environ.get("MICROBIOME_DOWNLOAD_DIR"),
        help="Directory for downloaded input data (default: --data).",
    )
    p.add_argument(
        "--db-dir", default=os.environ.get("MICROBIOME_DB_ROOT"), help="Directory containing downloaded databases."
    )
    p.add_argument(
        "--results-dir", default=os.environ.get("MICROBIOME_RESULTS_DIR"), help="Directory for generated results."
    )
    p.add_argument(
        "--base-url",
        default=os.environ.get("OLLAMA_BASE_URL"),
        help="Optional Ollama base URL (default http://localhost:11434).",
    )
    p.add_argument(
        "--source",
        default=os.environ.get("MICROBIOME_SOURCE") or "Ollama",
        help="LLM source: Ollama (default), DeepSeek, OpenAI, Anthropic, Custom, ...",
    )
    # This explicitly selected compatibility command may use the caller's legacy
    # environment configuration. It never reads a host's private credential store.
    p.add_argument(
        "--datalake",
        dest="no_datalake",
        action="store_false",
        help="Also download the official Microbiome data lake/benchmark (human/clinical; off by default).",
    )
    p.add_argument("--threads", type=int, default=None, help="Max CPU threads for tools (default: system CPUs).")
    p.add_argument("--gpu", type=int, default=None, help="Number of GPUs to use (default: auto-detect).")
    p.add_argument("--max-parallel", type=int, default=None, help="Max samples to process in parallel (default: 4).")
    p.add_argument("--no-prompt-resources", action="store_true", help="Skip interactive resource prompt.")
    p.add_argument(
        "--no-auto-install",
        action="store_true",
        help="Do not automatically create/repair software environments declared by a confirmed plan.",
    )
    p.add_argument(
        "--no-prompt-paths",
        action="store_true",
        help="Skip the three-round path prompt (raw data / databases / results) and use -d/--data plus env defaults.",
    )
    p.set_defaults(no_datalake=True)
    args = p.parse_args(argv)

    # The product greeting is the first normal-run output. Argument parsing comes
    # first so `microbiome-legacy-run --help` remains a fast, side-effect-free query.
    _print_welcome()
    _setup_env()
    _ensure_conda()

    # --- three-round path dialogue: raw data / databases / results ---
    # Runs first so the chosen MICROBIOME_DB_ROOT is exported before any tool module
    # (which may resolve database paths at import time) gets imported.
    from microbiome.path_config import prompt_paths, set_paths

    if args.project:
        from microbiome.pipeline.project import PipelineProject
        from microbiome.path_config import get_path_config
        project = PipelineProject(args.project)
        project.export_paths()
        paths = get_path_config()
        print(f"[microbiome-legacy-run] 已恢复项目路径: {paths.summary()}", flush=True)
    elif not args.no_prompt_paths:
        paths = prompt_paths(
            raw_data_default=args.data,
            download_default=args.download_dir,
            db_default=args.db_dir,
            results_default=args.results_dir,
        )
    else:
        paths = set_paths(
            raw_data_dir=args.data,
            download_dir=args.download_dir or args.data,
            db_root=args.db_dir,
            results_dir=args.results_dir,
        )
        print(f"[microbiome-legacy-run] 路径配置: {paths.summary()}", flush=True)
    args.data = paths.raw_data_dir
    os.environ["MICROBIOME_RESULTS_DIR"] = paths.results_dir

    # --- auto-configure local databases (set GENOMAD_DB, CHECKVDB, etc.) ---
    try:
        from microbiome.tool.db_inventory import auto_configure_databases

        _resolved_dbs = auto_configure_databases(db_root=paths.db_root)
        if _resolved_dbs:
            names = ", ".join(f"{k}→{v}" for k, v in _resolved_dbs.items())
            print(f"[microbiome-legacy-run] 🗄️  已自动检测到 {len(_resolved_dbs)} 个本地数据库：{names}", flush=True)
    except Exception as _e:
        print(f"[microbiome-legacy-run] ⚠️ 数据库自动检测失败（可忽略）: {_e}", flush=True)

    # --- resource configuration ---
    from microbiome.resource_config import get_config, prompt_resources, set_config

    if args.threads is not None or args.gpu is not None or args.max_parallel is not None:
        set_config(threads=args.threads, gpu=args.gpu, max_parallel_samples=args.max_parallel)
    if not args.no_prompt_resources:
        prompt_resources()
    else:
        cfg = get_config()
        print(f"[microbiome-legacy-run] 资源配置: {cfg.summary()}", flush=True)

    _resource_cfg = get_config()
    _resource_line = (
        f"CPU 线程 {_resource_cfg.threads}、内存约 {_resource_cfg.memory_gb} GB、GPU {_resource_cfg.gpu} 个"
    )

    os.makedirs(args.data, exist_ok=True)
    os.makedirs(paths.download_dir, exist_ok=True)
    os.makedirs(paths.db_root, exist_ok=True)
    os.makedirs(paths.results_dir, exist_ok=True)
    # Immediate connectivity feedback so the user isn't left waiting silently.
    if (args.source or "Ollama").lower() == "ollama":
        _check_ollama(args.model, args.base_url)
    print(
        "[microbiome-legacy-run] 正在初始化智能体（加载工具表，请稍候）... / Initializing the agent (loading tools, please wait)...",
        flush=True,
    )
    try:
        agent = _make_agent(
            args.data,
            args.model,
            args.base_url,
            source=args.source,
            no_datalake=args.no_datalake,
            auto_install=not args.no_auto_install,
        )
    except Exception as e:
        hint = (
            "确认 Ollama 在跑（ollama list）且已 pip install langchain-ollama。"
            if (args.source or "Ollama").lower() == "ollama"
            else "确认网络可用、模型来源配置正确，且已 pip install langchain-openai。"
        )
        print(f"[microbiome-legacy-run] 初始化 agent 失败：{e}\n提示：{hint}", file=sys.stderr)
        return 2
    print("[microbiome-legacy-run] ✅ 智能体就绪 / Agent ready.\n", flush=True)

    _first_task = [True]

    def _run_task(task):
        if _first_task[0]:
            # Tell the agent once where raw data lives, where databases are, and
            # where generated data/results must be written (from the 3-round dialogue).
            _first_task[0] = False
            task = (
                f"【路径设置】原始数据目录：{paths.raw_data_dir}（从这里寻找和读取原始数据）；"
                f"下载数据目录：{paths.download_dir}（需要获取的输入数据必须保存到这里）；"
                f"数据库目录：{paths.db_root}（从这里寻找和调用数据库）；"
                f"结果输出目录：{paths.results_dir}（所有生成的数据和结果文件都保存到这里；"
                f"写入文件前先用 os.makedirs(..., exist_ok=True) 确保目录存在）。\n\n"
                f"【可用资源】{_resource_line}；每次小数据试跑和全量运行都必须充分利用全部 CPU 线程、"
                f"内存和 GPU/显存，严禁闲置浪费。\n\n"
                f"用户任务：{task}"
            )
        event_labels = {
            "plan": "方案",
            "resource_blocked": "资源未就绪",
            "progress": "进度",
            "status": "状态",
            "action": "执行",
            "observation": "结果",
            "result": "完成",
        }
        for event in agent.go_stream(task):
            content = event.get("content") or event.get("output") or ""
            if not isinstance(content, str) or not content.strip():
                continue
            label = event_labels.get(event.get("type"), "消息")
            print(f"\n[microbiome-legacy-run] {label}\n{content.strip()}", flush=True)

        if getattr(agent, "awaiting_clarification", False):
            print("\n[microbiome-legacy-run] 请根据上方说明补充输入信息或修订方案。", flush=True)
        elif getattr(agent, "awaiting_resource_preparation", False):
            print(
                "\n[microbiome-legacy-run] 当前方案包含不能自动获取的未就绪资源。按上方说明准备后可输入“重新规划”，"
                "也可修改方案改用本地 READY 资源；当前无需输入“确认执行”。"
                "\nThe plan contains resources that cannot be auto-acquired; prepare them, or switch to local READY resources — no need to confirm execution yet.",
                flush=True,
            )
        elif getattr(agent, "awaiting_plan_confirmation", False):
            print(
                "\n[microbiome-legacy-run] 可继续补充或修改方案；确认无误后请明确输入：确认执行"
                "\nYou may refine the plan; when ready, reply exactly: 确认执行 (confirm execution).",
                flush=True,
            )
        elif getattr(agent, "awaiting_download_confirmation", False):
            print(
                "\n[microbiome-legacy-run] 有下载请求待确认：回复“确认下载”下载全部，“下载 1,3”选择编号，或“跳过下载”拒绝。"
                "\nDownloads pending confirmation: reply 确认下载 (download all), 下载 1,3 (select numbers), or 跳过下载 (skip).",
                flush=True,
            )
        elif getattr(agent, "awaiting_full_confirmation", False):
            print(
                "\n[microbiome-legacy-run] 小数据验证已通过。确认处理全部原始数据可直接回复：确认全量执行"
                "\nThe pilot passed; to process all raw data, reply exactly: 确认全量执行 (confirm full run).",
                flush=True,
            )
        elif getattr(agent, "production_state", "") == "PRETEST_FINALIZATION_FAILED":
            print(
                "\n[microbiome-legacy-run] 小试已通过；当前仅修复路径/清单/元数据/状态/绑定并重新 Finalize，"
                "不会重跑生信分析。可回复：重试冻结"
                "\nThe pilot passed; only path/manifest/state/binding is being repaired and re-finalized (no re-run). Reply: 重试冻结.",
                flush=True,
            )
        elif getattr(agent, "production_state", "") == "REVALIDATION_REQUIRED":
            print(
                "\n[microbiome-legacy-run] 软件、数据库、科学参数或 Pipeline 的实际验证事实不完整，"
                "需要针对相关步骤重新进行小试验证。"
                "\nSoftware/database/parameters/pipeline validation evidence is incomplete; the relevant steps must be re-validated.",
                flush=True,
            )

    def _interactive_loop():
        while True:
            if getattr(agent, "awaiting_download_confirmation", False):
                prompt = "microbiome(dl-confirm)> "
            elif getattr(agent, "awaiting_full_confirmation", False):
                prompt = "microbiome(full-confirm)> "
            elif getattr(agent, "awaiting_resource_preparation", False):
                prompt = "microbiome(resources)> "
            elif getattr(agent, "awaiting_plan_confirmation", False):
                prompt = "microbiome(plan)> "
            else:
                prompt = "microbiome> "
            try:
                task = input(prompt).strip()
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if not task or task.lower() in ("exit", "quit"):
                break
            try:
                _run_task(task)
            except Exception as e:
                print(f"[microbiome-legacy-run] 任务处理出错 / Task error：{e}", file=sys.stderr)

    if args.task:
        _run_task(args.task)
        if (
            getattr(agent, "awaiting_plan_confirmation", False)
            or getattr(agent, "awaiting_clarification", False)
            or getattr(agent, "awaiting_resource_preparation", False)
            or getattr(agent, "awaiting_full_confirmation", False)
        ):
            if sys.stdin.isatty():
                _interactive_loop()
            else:
                print(
                    "[microbiome-legacy-run] 当前输入不可交互；请运行 `microbiome-legacy-run` 进入方案讨论与确认。 / Non-interactive input; run `microbiome-legacy-run` to discuss and confirm.",
                    flush=True,
                )
        return 0

    print(
        f"[microbiome-legacy-run] 交互模式 / Interactive mode（model={args.model}，raw data={paths.raw_data_dir}，"
        f"download={paths.download_dir}，"
        f"database={paths.db_root}，results={paths.results_dir}）。"
        "\n输入任务后先讨论方案；“确认执行”只运行资源准备和小数据试跑，试跑通过后“确认全量执行”才处理完整数据。"
        "\nEnter a task to discuss the plan first; 确认执行 runs resource prep + pilot; 确认全量执行 runs the full dataset after the pilot passes."
        "\n输入 exit/quit 或 Ctrl-D 退出 / Type exit/quit or Ctrl-D to quit."
    )
    _interactive_loop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
