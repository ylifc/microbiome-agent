"""Auto-install conda/mamba (Miniforge) when the project starts without one.

Discovery reuses :mod:`microbiome.conda_discovery` (PATH first, then common install
roots). When no conda/mamba/micromamba is found, this module downloads and runs
the Miniforge installer in non-interactive ``-b`` batch mode, which provides both
``conda`` and ``mamba`` (plus ``micromamba``) under one prefix.

The install is idempotent and bounded: it is a no-op when a manager is already
found, and it never re-downloads when ``<root>/bin/mamba`` exists.

Environment knobs
-----------------
``MICROBIOME_CONDA_ROOT``        Install root (default ``~/miniforge3``).
``MICROBIOME_NO_CONDA_BOOTSTRAP`` Set to ``1`` to disable auto-install entirely.

This module is stdlib-only (like :mod:`microbiome.conda_discovery`) so it can run
before any third-party dependency or Conda itself is available.
"""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from microbiome.conda_discovery import find_conda_manager

DEFAULT_INSTALL_ROOT = os.environ.get("MICROBIOME_CONDA_ROOT", "~/miniforge3")
_MINIFORGE_RELEASES = "https://github.com/conda-forge/miniforge/releases/latest/download"
_NO_BOOTSTRAP_ENV = "MICROBIOME_NO_CONDA_BOOTSTRAP"


def _default_log(message: str) -> None:
    print(message, file=sys.stderr, flush=True)


def installer_filename() -> str:
    """Return the Miniforge installer filename for the current platform/arch."""
    system = platform.system()
    machine = platform.machine().lower()
    if system == "Linux":
        if machine in {"x86_64", "amd64"}:
            arch = "x86_64"
        elif machine in {"aarch64", "arm64"}:
            arch = "aarch64"
        else:
            raise RuntimeError(f"unsupported Linux architecture: {machine}")
        return f"Miniforge3-Linux-{arch}.sh"
    if system == "Darwin":
        arch = "arm64" if machine in {"arm64", "aarch64"} else "x86_64"
        return f"Miniforge3-MacOSX-{arch}.sh"
    raise RuntimeError(f"unsupported platform for auto-install: {system} ({machine})")


def _download(url: str, dest: Path) -> bool:
    """Download ``url`` to ``dest`` using curl, then wget, then urllib."""
    curl = shutil.which("curl")
    if curl:
        res = subprocess.run([curl, "-fL", "--retry", "3", "-o", str(dest), url], check=False)
        if res.returncode == 0 and dest.is_file() and dest.stat().st_size > 0:
            return True
    wget = shutil.which("wget")
    if wget:
        res = subprocess.run([wget, "-q", "-O", str(dest), url], check=False)
        if res.returncode == 0 and dest.is_file() and dest.stat().st_size > 0:
            return True
    try:
        import urllib.request

        req = urllib.request.Request(url, headers={"User-Agent": "microbiome-conda-bootstrap/1"})
        with urllib.request.urlopen(req, timeout=300) as response, open(dest, "wb") as out:
            shutil.copyfileobj(response, out)
    except Exception:  # noqa: BLE001
        return False
    return dest.is_file() and dest.stat().st_size > 0


def install_miniforge(dest: str | Path | None = None, log=None) -> str | None:
    """Install Miniforge to ``dest`` and return the ``mamba`` path, or None.

    Idempotent: returns immediately when ``<dest>/bin/mamba`` already exists.
    """
    log = log or _default_log
    dest = Path(dest or DEFAULT_INSTALL_ROOT).expanduser()
    mamba = dest / "bin" / "mamba"
    if mamba.is_file():
        log(f"[microbiome] conda/mamba 已就绪：{mamba}")
        return str(mamba)

    try:
        filename = installer_filename()
    except RuntimeError as exc:
        log(f"[microbiome] 无法自动安装 conda/mamba：{exc}")
        return None

    dest.parent.mkdir(parents=True, exist_ok=True)
    url = f"{_MINIFORGE_RELEASES}/{filename}"
    log(f"[microbiome] 未检测到 conda/mamba，自动安装 Miniforge 到 {dest} ...")
    try:
        with tempfile.TemporaryDirectory(prefix="microbiome-miniforge-") as tmp:
            installer = Path(tmp) / filename
            if not _download(url, installer):
                log(f"[microbiome] 下载 Miniforge 安装器失败：{url}")
                return None
            res = subprocess.run(
                ["bash", str(installer), "-b", "-p", str(dest)],
                check=False,
            )
            if res.returncode != 0:
                log(f"[microbiome] Miniforge 安装失败（exit {res.returncode}）")
                return None
    except Exception as exc:  # noqa: BLE001
        log(f"[microbiome] Miniforge 安装异常：{exc}")
        return None

    if mamba.is_file():
        log(f"[microbiome] Miniforge 安装完成：{mamba}")
        return str(mamba)
    log(f"[microbiome] Miniforge 安装后未找到 {mamba}")
    return None


def ensure_conda_manager(install_if_missing: bool = True, log=None) -> str | None:
    """Return a conda/mamba executable, auto-installing Miniforge if absent.

    This is the single hook used by project startup paths. When a manager is
    already discoverable (PATH or a known install root) it returns it without
    touching the filesystem.
    """
    log = log or _default_log
    manager = find_conda_manager()
    if manager:
        return manager
    if os.environ.get(_NO_BOOTSTRAP_ENV) == "1":
        log(f"[microbiome] 未检测到 conda/mamba，且 {_NO_BOOTSTRAP_ENV}=1，跳过自动安装")
        return None
    if not install_if_missing:
        return None
    return install_miniforge(log=log)
