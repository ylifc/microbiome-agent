"""Shared, user-visible progress reporting for Microbiome operations.

The execution layer uses this module to describe *what* is happening, *why* it
is necessary, where outputs go, and how far the current operation has moved.
Progress percentages are exact when a tool reports them (for example HTTP byte
counts) and otherwise represent explicit workflow milestones.
"""

from __future__ import annotations

import re
import shlex
from collections.abc import Callable
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Literal

OperationKind = Literal["environment", "software", "download", "analysis", "verification", "task"]
ProgressCallback = Callable[[dict], None]


@dataclass(frozen=True)
class OperationInfo:
    """Human-readable description of one executable operation."""

    kind: OperationKind
    title: str
    purpose: str
    reason: str
    target: str = ""


def clamp_percent(percent: float | int) -> int:
    """Normalize a percentage for rendering and event consumers."""

    return max(0, min(100, int(round(float(percent)))))


def progress_bar(percent: float | int, width: int = 24) -> str:
    """Render a stable text progress bar that works in terminals and web UIs."""

    value = clamp_percent(percent)
    completed = round(width * value / 100)
    return f"[{'█' * completed}{'░' * (width - completed)}] {value:3d}%"


def progress_event(
    percent: float | int,
    operation: OperationInfo,
    *,
    status: str = "running",
    detail: str = "",
) -> dict:
    """Build a serializable semantic event and its complete visible text."""

    value = clamp_percent(percent)
    status_labels = {
        "pending": "等待",
        "running": "进行中",
        "retrying": "正在重试",
        "completed": "已完成",
        "failed": "失败",
        "skipped": "已跳过",
    }
    lines = [
        progress_bar(value),
        f"当前操作：{operation.title}",
        f"目的：{operation.purpose}",
        f"原因：{operation.reason}",
    ]
    if operation.target:
        lines.append(f"目标位置：{operation.target}")
    lines.append(f"状态：{status_labels.get(status, status)}")
    if detail:
        lines.append(f"说明：{detail}")
    return {
        "type": "progress",
        "content": "\n".join(lines),
        "progress": {
            "percent": value,
            "status": status,
            **asdict(operation),
            "detail": detail,
        },
    }


def emit_progress(callback: ProgressCallback | None, event: dict) -> None:
    """Send an event to a callback; default callers may simply print content."""

    if callback is not None:
        callback(event)


def print_progress(event: dict) -> None:
    """Default callback for direct Python and subprocess usage."""

    content = event.get("content", "")
    if content:
        print(f"\n{content}", flush=True)


def _flag_value(code: str, flags: tuple[str, ...]) -> str:
    try:
        tokens = shlex.split(code.replace("\n", " "))
    except ValueError:
        tokens = code.replace("\n", " ").split()
    for index, token in enumerate(tokens[:-1]):
        if token in flags:
            return tokens[index + 1]
        if any(token.startswith(f"{flag}=") for flag in flags):
            return token.split("=", 1)[1]
    return ""


def _heading(text: str, names: tuple[str, ...]) -> str:
    for name in names:
        match = re.search(rf"(?im)^\s*(?:【?{re.escape(name)}】?)\s*[:：]\s*(.+)$", text or "")
        if match:
            return match.group(1).strip()
    return ""


def infer_operation(code: str, rationale: str = "", target_hint: str = "") -> OperationInfo:
    """Infer a safe user-facing purpose/reason from an execution payload."""

    text = f"{rationale}\n{code}".strip()
    lowered = text.lower()
    explicit_title = _heading(rationale, ("当前步骤", "操作", "任务"))
    explicit_purpose = _heading(rationale, ("目的", "目标"))
    explicit_reason = _heading(rationale, ("原因", "依据"))
    explicit_target = _heading(rationale, ("目标目录", "输出目录", "保存位置"))
    target = explicit_target or target_hint or _flag_value(
        code,
        ("--output", "--out", "--outdir", "--output-dir", "--directory", "--dir", "-o", "-d"),
    )

    env_create = re.search(
        r"\b(?:conda|mamba|micromamba)\s+(?:env\s+)?create\b[^\n]*(?:-n|--name|-p|--prefix)\s+([^\s]+)",
        lowered,
    )
    env_install = re.search(
        r"\b(?:conda|mamba|micromamba)\s+install\b[^\n]*(?:-n|--name|-p|--prefix)\s+([^\s]+)",
        lowered,
    )
    if env_create:
        environment = env_create.group(1).strip("'\"")
        return OperationInfo(
            "environment",
            explicit_title or f"创建独立软件环境 {environment}",
            explicit_purpose or "准备本任务所需的软件及其隔离依赖",
            explicit_reason or "独立环境可避免依赖冲突，并防止修改 base/当前 Python 环境",
            explicit_target or environment,
        )
    if env_install or re.search(r"\bpython\s+-m\s+pip\s+install\b|\bpip\s+install\b", lowered):
        environment = env_install.group(1).strip("'\"") if env_install else _flag_value(code, ("-n", "--name", "-p", "--prefix"))
        return OperationInfo(
            "software",
            explicit_title or f"安装或修复软件依赖{f'（环境 {environment}）' if environment else ''}",
            explicit_purpose or "确保后续分析命令所需的软件可以实际调用",
            explicit_reason or "预检发现软件缺失、版本不可用或环境不完整",
            explicit_target or environment,
        )
    if re.search(
        r"\b(?:wget|curl|aria2c|prefetch|fasterq-dump)\b|https?://|download_(?:file|database|reference|virus|sra)",
        lowered,
    ):
        return OperationInfo(
            "download",
            explicit_title or "下载任务所需数据",
            explicit_purpose or "把已确认的数据或数据库准备到本地供后续分析使用",
            explicit_reason or "本地目标目录尚未包含任务要求的完整数据",
            target,
        )
    if re.search(
        r"\b(?:command\s+-v|which|--version|--help|test\s+-[efs]|sha256sum|md5sum)\b|"
        r"microbiome_(?:preflight_complete|pilot_verified|result_verified)",
        lowered,
    ):
        return OperationInfo(
            "verification",
            explicit_title or "验证输入、软件环境和输出结果",
            explicit_purpose or "确认下一阶段运行条件满足且结果文件真实有效",
            explicit_reason or "只有通过实际命令验收后才能安全继续或宣布任务完成",
            target,
        )
    return OperationInfo(
        "analysis",
        explicit_title or "执行当前分析任务",
        explicit_purpose or rationale.strip() or "按照已确认方案生成可验证的分析结果",
        explicit_reason or "该操作是已确认分析流程中的必要环节",
        target,
    )


def parse_reported_percent(line: str) -> int | None:
    """Extract a tool-reported 0-100 percentage from one output line."""

    matches = re.findall(r"(?<!\d)(100|[1-9]?\d(?:\.\d+)?)\s*%", line or "")
    if not matches:
        return None
    return clamp_percent(float(matches[-1]))


def destination_label(path: str | Path) -> str:
    """Return a normalized absolute target for visible progress messages."""

    return str(Path(path).expanduser().resolve())
