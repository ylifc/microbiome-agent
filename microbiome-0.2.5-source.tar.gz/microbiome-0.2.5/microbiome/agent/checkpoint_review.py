"""Review existing native checkpoints under an existing, scoped host delegation.

This module cannot create grants or user messages. Inspection returns complete
review material; confirmation binds its fingerprint to the current grant.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import UTC, datetime
from pathlib import Path
import re
import uuid

from microbiome.integrations.delegation import load_authorization
from microbiome.pipeline.errors import ConfigurationError
from microbiome.pipeline.io import object_fingerprint, read_json, read_yaml, write_json
from microbiome.pipeline.locking import project_operation_lock
from microbiome.pipeline.project import PipelineProject

TOPICS = {"pretest": ["input", "dataset", "target", "analysis_goal", "analysis_plan", "dependencies"],
          "production": ["production"]}


def _now():
    return datetime.now(UTC).isoformat()


def _project(project):
    return project if isinstance(project, PipelineProject) else PipelineProject(project)


def _directory(project):
    return project.state_dir / "native_checkpoint_review"


def _seal(value, field):
    return {**value, field: object_fingerprint(value)}


def _check_seal(value, field):
    if not isinstance(value, dict) or value.get(field) != object_fingerprint({k: v for k, v in value.items() if k != field}):
        raise ConfigurationError("Checkpoint review/receipt fingerprint is invalid")


def _grant(project, checkpoint, fingerprint):
    if checkpoint not in TOPICS:
        raise ConfigurationError("checkpoint must be pretest or production")
    grant = load_authorization(project)
    if grant["mode"] != "host_delegated":
        raise ConfigurationError("HOST_DELEGATION_REQUIRED: 当前项目没有委托授权；请通过原生工作流取得真实用户确认。")
    if grant["authorization_fingerprint"] != fingerprint:
        raise ConfigurationError("STALE_AUTHORIZATION: delegation was changed or revoked")
    if not set(TOPICS[checkpoint]).issubset(grant["topics"]):
        raise ConfigurationError("Checkpoint requires decision topics outside the delegated scope")
    return grant


def _finalization_recovery(workflow):
    """Verify a passed execution for metadata-only recovery, without approval."""
    from microbiome.agent.input_state import validate_confirmed_goal_contract
    from microbiome.harness.workflow_status import _draft, _execution_approval
    from microbiome.pipeline.cases import verify_validation_suite
    from microbiome.pipeline.errors import FinalizationFailureCategory
    from microbiome.pipeline.execution import FrozenPipelineExecutor
    from microbiome.pipeline.freeze import _phase_report, _verified_report
    from microbiome.pipeline.io import fast_file_fingerprint
    from microbiome.pipeline.state import LifecycleState, ProjectStateMachine

    project = workflow.project
    state = ProjectStateMachine(project).load()
    if state["current_state"] != LifecycleState.PRETEST_FINALIZATION_FAILED.value:
        raise ConfigurationError("CHECKPOINT_PHASE_DENIED: finalization recovery requires a failed finalization")
    failure = state.get("last_finalization_failure") or {}
    try:
        category = FinalizationFailureCategory(failure.get("category"))
    except (TypeError, ValueError) as error:
        raise ConfigurationError("FINALIZATION_RECOVERY_DENIED: missing classified failure") from error
    if failure.get("requires_pretest") is not False or category.requires_pretest:
        raise ConfigurationError("FINALIZATION_RECOVERY_DENIED: this failure requires a new verified pretest")
    manifest = workflow._manifest()
    draft = _draft(project, manifest, workflow.state)
    validate_confirmed_goal_contract(workflow, draft)
    plan, requirements = _execution_approval(project, workflow.state, draft)
    approval = read_json(project.state_dir / "user_execution_approval.json")
    decision = require_checkpoint_source(project, approval.get("source"), draft=draft, checkpoint="pretest")
    if (approval.get("input_fingerprint") != object_fingerprint(manifest)
            or approval.get("local_input_fingerprints") != workflow._local_input_snapshot(manifest)
            or approval.get("pretest") != workflow._pretest_options()):
        raise ConfigurationError("CHECKPOINT_INPUT_DRIFT: approved inputs or sampling changed")
    dependencies = read_yaml(project.plans_dir / "dependency_gap_report.yaml")
    _check_seal(dependencies, "report_fingerprint")
    if dependencies.get("scope_fingerprint") != approval.get("dependency_scope"):
        raise ConfigurationError("CHECKPOINT_DEPENDENCY_DRIFT: approved dependency scope changed")
    validation_path = Path(workflow.state.get("validation_report_path") or project.validation_report_path).resolve()
    if not (validation_path == project.validation_report_path.resolve()
            or validation_path.is_relative_to(project.pretest_dir.resolve())):
        raise ConfigurationError("FINALIZATION_RECOVERY_DENIED: validation report outside project")
    validation = _verified_report(validation_path, plan)
    if validation.get("requirements_version") != requirements["requirements_version"]:
        raise ConfigurationError("FINALIZATION_RECOVERY_DENIED: validation requirements changed")
    suite = verify_validation_suite(project, plan)
    resources = {}
    for filename, field in (("bootstrap_report.json", "tools"), ("database_resolution.json", "databases")):
        report = _phase_report(project, filename, plan, requirements["requirements_version"])
        report_field = "bootstrap_report_fingerprint" if field == "tools" else "database_report_fingerprint"
        if report["report_fingerprint"] != validation.get(report_field):
            raise ConfigurationError("FINALIZATION_RECOVERY_DENIED: validated resource report changed")
        for entry in report[field].values():
            if field == "tools":
                # Fingerprint verification is sufficient here; the finalizer's
                # readiness gate performs the existing version smoke tests.
                executable = Path(entry["executable"])
                if not entry.get("executable_fingerprint") or fast_file_fingerprint(executable) != entry["executable_fingerprint"]:
                    raise ConfigurationError("FINALIZATION_RECOVERY_DENIED: validated executable changed")
                if entry.get("virtual_environment_fingerprint"):
                    config = Path(entry["environment_prefix"]) / "pyvenv.cfg"
                    if fast_file_fingerprint(config) != entry["virtual_environment_fingerprint"]:
                        raise ConfigurationError("FINALIZATION_RECOVERY_DENIED: validated environment changed")
            else:
                FrozenPipelineExecutor._verify_database(entry, plan["steps"])
        resources[field] = report
    return {"operation": "finalize_only", "approval_reused": True, "requires_pretest": False,
            "original_review": decision["reviewed_material"], "approval": approval,
            "failure": failure, "validation_report_path": str(validation_path),
            "validation": validation, "validation_suite": suite, "resources": resources,
            "plan_fingerprint": plan["plan_fingerprint"], "input_fingerprint": object_fingerprint(manifest),
            "requirements_fingerprint": requirements["requirements_fingerprint"],
            "next_action": "execute pretest with the existing review_fingerprint and a new host request; no new approval, planner or pretest execution"}


def inspect_checkpoint(project, checkpoint="pretest"):
    """Return all current review facts, never an abbreviated approval summary."""
    from microbiome.agent.workflow import ConversationWorkflow
    from microbiome.integrations.service import decision_snapshot
    from microbiome.pipeline.dependencies import DependencyResolver
    from microbiome.pipeline.requirements import RequirementManager
    from microbiome.agent.input_state import input_is_protected, validate_confirmed_goal_contract
    instance = _project(project)
    if checkpoint not in TOPICS:
        raise ConfigurationError("checkpoint must be pretest or production")
    with project_operation_lock(instance, reentrant=True):
        grant = load_authorization(instance)
        if checkpoint == "pretest":
            from microbiome.pipeline.state import LifecycleState, ProjectStateMachine
            if ProjectStateMachine(instance).current == LifecycleState.PRETEST_FINALIZATION_FAILED:
                recovery = _finalization_recovery(ConversationWorkflow(instance))
                original = recovery["original_review"]
                # The executable fingerprint is the already approved review;
                # the new inspection has its own seal and cannot grant approval.
                return _seal({"schema_version": 1, "project": str(instance.root), "checkpoint": checkpoint,
                    "review_fingerprint": original["review_fingerprint"], "authorization": original["authorization"],
                    "complete": True, "material": recovery, "action": "finalize_only"}, "inspection_fingerprint")
            if input_is_protected(instance):
                raise ConfigurationError("CHECKPOINT_PHASE_DENIED: a running or frozen contract cannot be reapproved implicitly")
            workflow = ConversationWorkflow(instance)
            draft = workflow.state.get("draft")
            if draft is None:
                # A compiled candidate is a planning checkpoint, not the sealed
                # draft shown for approval. Inspection must neither stage it nor
                # misreport an unfinished stage as a damaged approval artifact.
                pending = workflow.state.get("planning_checkpoint")
                stage = pending.get("stage") if isinstance(pending, dict) else None
                stage = stage if isinstance(stage, str) else "not recorded"
                phase = ProjectStateMachine(instance).current.value
                message = (f"CHECKPOINT_PLAN_NOT_READY: no reviewable draft is available; "
                           f"planning is incomplete (phase={phase}, checkpoint={stage}). "
                           "Inspect planning_recovery before resuming planning; no approval or execution occurred.")
                error = ConfigurationError(message)
                error.details = {
                    "code": "CHECKPOINT_PLAN_NOT_READY", "category": "PLANNING_STATE",
                    "recoverable": True,
                    "violations": [{"field": "state.conversation.draft", "code": "DRAFT_NOT_READY",
                                    "message": message, "phase": phase, "planning_checkpoint": stage}],
                    "next_action": {"tool": "microbiome_maintenance",
                        "arguments": {"operation": "inspect", "arguments": {"section": "summary"}},
                        "follow_up": "Use microbiome_resume_planning only when planning_recovery.available is true, "
                                     "with its current recovery_token. Otherwise follow the recorded blocker. "
                                     "Inspect the pretest checkpoint again after a reviewable draft is saved."}}
                raise error
            _check_seal(draft, "draft_fingerprint")
            validate_confirmed_goal_contract(workflow, draft)
            manifest = workflow._manifest()
            if draft["input_fingerprint"] != object_fingerprint(manifest):
                raise ConfigurationError("CHECKPOINT_INPUT_DRIFT: native draft no longer matches verified input")
            dependencies = read_yaml(instance.plans_dir / "dependency_preview.yaml")
            _check_seal(dependencies, "report_fingerprint")
            if dependencies["scope_fingerprint"] != draft["dependency_scope"]:
                raise ConfigurationError("CHECKPOINT_DEPENDENCY_DRIFT: show a revised native draft before approval")
            material = {"draft": deepcopy(draft), "input_manifest": manifest,
                        "local_input_fingerprints": workflow._local_input_snapshot(manifest),
                        "requirements": RequirementManager(instance).load(),
                        "pretest": workflow._pretest_options(),
                        "validation_policy": instance.load_config().get("validation", {}),
                        "dependencies": dependencies}
        else:
            material = {"public_decision": decision_snapshot(str(instance.root), "production")}
        value = {"schema_version": 1, "project": str(instance.root), "checkpoint": checkpoint,
                 "required_topics": TOPICS[checkpoint], "authorization": grant,
                 "project_paths": instance.load_config()["paths"], "material": material,
                 "complete": True}
        return _seal(value, "review_fingerprint")


def require_checkpoint_source(project, source, *, draft=None, allow_attempted=False, checkpoint=None):
    """Validate a backend-created source, including current grant revocation."""
    if not isinstance(source, dict) or source.get("type") != "host_delegation" or source.get("bridge") != "native_checkpoint":
        raise ConfigurationError("A recorded native checkpoint delegation is required")
    identity = source.get("record_id", "")
    if not isinstance(identity, str) or not re.fullmatch(r"[a-f0-9]{32}", identity):
        raise ConfigurationError("Invalid checkpoint decision identity")
    record = read_json(_directory(project) / "decisions" / (identity + ".json"))
    _check_seal(record, "receipt_fingerprint")
    if (record.get("project") != str(project.root) or record.get("source") != source
            or record.get("status") not in ({"attempted", "applied"} if allow_attempted else {"applied"})):
        raise ConfigurationError("Checkpoint decision was not applied to this project")
    review = record["reviewed_material"]
    _check_seal(review, "review_fingerprint")
    if checkpoint is not None and review["checkpoint"] != checkpoint:
        raise ConfigurationError("Delegated source belongs to another checkpoint")
    if review["review_fingerprint"] != source.get("decision_fingerprint"):
        raise ConfigurationError("Checkpoint source differs from reviewed material")
    grant = _grant(project, review["checkpoint"], source.get("authorization_fingerprint"))
    if grant != review["authorization"] or project.load_config()["paths"] != review["project_paths"]:
        raise ConfigurationError("Checkpoint authorization scope or paths changed")
    if review["checkpoint"] == "pretest":
        if draft is not None and draft.get("draft_fingerprint") != review["material"]["draft"]["draft_fingerprint"]:
            raise ConfigurationError("Checkpoint decision belongs to another native draft")
        if project.load_config().get("validation", {}) != review["material"]["validation_policy"]:
            raise ConfigurationError("Checkpoint sampling policy changed after review")
    return record


def validate_execution_approval(project, receipt, *, draft=None):
    """Recognize actual user text or a validated delegation, never a model flag."""
    from microbiome.pipeline.approval import ProductionApprovalManager, ProductionIntent
    _check_seal(receipt, "approval_fingerprint")
    source = receipt.get("source")
    if source and source.get("type") == "host_delegation":
        require_checkpoint_source(project, source, draft=draft, checkpoint="pretest")
        if receipt.get("user_message") is not None:
            raise ConfigurationError("Delegated execution must not impersonate a user confirmation")
    elif ProductionApprovalManager.classify_intent(receipt.get("user_message", "")) is not ProductionIntent.APPROVE_PRODUCTION:
        raise ConfigurationError("缺少用户实际执行确认或有效委托审阅回执。")
    return receipt


def confirm_checkpoint(project, *, review_fingerprint, authorization_fingerprint, reason, checkpoint="pretest"):
    """Confirm the complete current artifact, using only a pre-existing grant."""
    from microbiome.agent.workflow import ConversationWorkflow
    from microbiome.integrations.service import _apply_reviewed_decision
    from microbiome.pipeline.requirements import ConfirmationAction
    instance = _project(project)
    if not isinstance(reason, str) or not reason.strip() or len(reason.encode()) > 8192:
        raise ConfigurationError("A review reason of 1–8192 bytes is required")
    next_action = {"tool": "microbiome_checkpoint", "arguments": {"action": "execute",
                   "checkpoint": checkpoint, "review_fingerprint": review_fingerprint}}
    with project_operation_lock(instance, reentrant=True):
        grant = _grant(instance, checkpoint, authorization_fingerprint)
        from microbiome.pipeline.state import LifecycleState, ProjectStateMachine
        if checkpoint == "pretest" and ProjectStateMachine(instance).current == LifecycleState.PRETEST_FINALIZATION_FAILED:
            recovery = _finalization_recovery(ConversationWorkflow(instance))
            if recovery["original_review"]["review_fingerprint"] != review_fingerprint:
                raise ConfigurationError("STALE_REVIEW: finalization only reuses the existing approved review")
        # A repeated confirm only returns the same applied receipt after checking
        # its authorization. It never repeats a transition or a run.
        for path in (_directory(instance) / "decisions").glob("*.json"):
            old = read_json(path)
            if (old.get("status") == "applied" and old.get("checkpoint") == checkpoint
                    and old.get("source", {}).get("decision_fingerprint") == review_fingerprint
                    and old["source"].get("authorization_fingerprint") == authorization_fingerprint):
                if checkpoint == "pretest":
                    from microbiome.harness.workflow_status import _execution_approval
                    workflow = ConversationWorkflow(instance)
                    _execution_approval(instance, workflow.state, workflow.state.get("draft") or {})
                    require_checkpoint_source(instance, old["source"], draft=workflow.state.get("draft"))
                else:
                    from microbiome.pipeline.approval import ProductionApprovalManager
                    current = ProductionApprovalManager(instance).require_valid_approval()
                    if current.get("source") != old["source"]:
                        raise ConfigurationError("A later production decision superseded this checkpoint")
                    require_checkpoint_source(instance, old["source"])
                return {"checkpoint": checkpoint, "review_fingerprint": review_fingerprint,
                        "source": old["source"], "receipt_path": str(path), "reused": True,
                        "next_action": next_action}
        review = inspect_checkpoint(instance, checkpoint)
        if review["review_fingerprint"] != review_fingerprint:
            raise ConfigurationError("STALE_REVIEW: inspect and review the changed checkpoint before confirming")
        identity = uuid.uuid4().hex
        source = {"type": "host_delegation", "bridge": "native_checkpoint", "actor": "host_agent",
                  "record_id": identity, "authorization_id": grant["authorization_id"],
                  "authorization_fingerprint": authorization_fingerprint,
                  "user_request": grant["user_request"], "host_source": grant["source"], "scope": grant["scope"],
                  "decision_fingerprint": review_fingerprint, "reason": reason.strip()}
        record = {"schema_version": 1, "project": str(instance.root), "checkpoint": checkpoint,
                  "record_id": identity, "action": "CONFIRM", "created_at": _now(),
                  "source": source, "reviewed_material": review, "status": "attempted"}
        path = _directory(instance) / "decisions" / (identity + ".json")
        write_json(path, _seal(record, "receipt_fingerprint"))
        try:
            if checkpoint == "pretest":
                workflow = ConversationWorkflow(instance)
                workflow.approve(None, decision_source=source)
                result = read_json(instance.state_dir / "user_execution_approval.json")
            else:
                # Reuse the exact public production gate and its source-aware audit.
                result = _apply_reviewed_decision(instance, review["material"]["public_decision"],
                                                  ConfirmationAction.CONFIRM, decision_source=source)
        except Exception as error:
            record.update(status="failed", finished_at=_now(), error=str(error))
            write_json(path, _seal(record, "receipt_fingerprint"))
            raise
        record.update(status="applied", finished_at=_now(), result_fingerprint=object_fingerprint(result))
        write_json(path, _seal(record, "receipt_fingerprint"))
        return {"checkpoint": checkpoint, "review_fingerprint": review_fingerprint,
                "source": source, "receipt_path": str(path), "approval": result, "reused": False,
                "next_action": next_action}


def execute_checkpoint(workflow, agent, *, checkpoint, request_id, review_fingerprint):
    """Execute an approved checkpoint once; replay completed requests as facts."""
    from microbiome.pipeline.approval import ProductionApprovalManager
    from microbiome.pipeline.state import LifecycleState, ProjectStateMachine
    project = workflow.project
    if checkpoint not in TOPICS or not isinstance(request_id, str) or not 1 <= len(request_id) <= 256:
        raise ConfigurationError("A supported checkpoint and host request_id are required")
    request = {"project": str(project.root), "checkpoint": checkpoint, "request_id": request_id,
               "review_fingerprint": review_fingerprint}
    identity = object_fingerprint({"project": str(project.root), "request_id": request_id})
    path = _directory(project) / "executions" / (identity + ".json")
    with project_operation_lock(project, reentrant=True):
        if path.is_file():
            previous = read_json(path)
            _check_seal(previous, "receipt_fingerprint")
            if previous["request"] != request:
                raise ConfigurationError("request_id already identifies another checkpoint execution")
            if previous["status"] in {"completed", "failed"} and previous.get("finished_at"):
                for event in previous["events"]:
                    yield {**event, "reused": True}
                return
            raise ConfigurationError("CHECKPOINT_EXECUTION_RECORDED: prior attempt is running, failed or interrupted; inspect its evidence before a new request")
        # Refresh the caller's object: approval may have been performed by an
        # independent adapter since it loaded conversation.json.
        workflow.state = read_json(workflow.path)
        pretest = workflow.state.get("approved_pretest") or {}
        workflow.pretest_fraction = pretest.get("fraction")
        workflow.pretest_all_samples = pretest.get("all_samples", False)
        if checkpoint == "pretest":
            approval = read_json(project.state_dir / "user_execution_approval.json")
            validate_execution_approval(project, approval, draft=workflow.state.get("draft"))
        else:
            approval = ProductionApprovalManager(project).require_valid_approval()
            require_checkpoint_source(project, approval.get("source"), checkpoint="production")
            ProjectStateMachine(project).require(LifecycleState.PRODUCTION_APPROVED)
        if approval.get("source", {}).get("decision_fingerprint") != review_fingerprint:
            raise ConfigurationError("Execution does not match the approved checkpoint review")
        recovery = None
        if checkpoint == "pretest" and ProjectStateMachine(project).current == LifecycleState.PRETEST_FINALIZATION_FAILED:
            recovery = _finalization_recovery(workflow)
        elif checkpoint == "pretest":
            ProjectStateMachine(project).require(LifecycleState.BOOTSTRAP, LifecycleState.PRETEST_PREPARATION,
                                                 LifecycleState.PRETEST_RUNNING, LifecycleState.PRETEST_REPAIR)
        record = {"schema_version": 1, "request": request, "status": "running", "started_at": _now(), "events": []}
        if recovery:
            record["technical_recovery"] = recovery
        write_json(path, _seal(record, "receipt_fingerprint"))
        try:
            if recovery:
                from microbiome.pipeline.finalizer import ValidationFinalizer
                readiness = ValidationFinalizer(project).finalize_pretest(
                    validation_report_path=recovery["validation_report_path"], new_version=False)
                if (workflow.state.get("last_workflow_blocker") or {}).get("code") == "PRETEST_FINALIZATION_FAILED":
                    workflow.state.pop("last_workflow_blocker", None)
                events = iter([{"type": "plan", "stage": 5, "status": "FINALIZATION_RECOVERED",
                    "operation": "finalize_only", "pretest_reused": True, "readiness": readiness,
                    "content": ProductionApprovalManager(project).render_validation_summary()}])
            elif checkpoint == "pretest":
                events = workflow.retry_pilot(agent)
            else:
                from microbiome.pipeline.batch import execute_batch
                from microbiome.pipeline.execution import FrozenPipelineExecutor
                from microbiome.pipeline.inputs import ProductionInputResolver
                pipeline = ProductionApprovalManager(project)._load_pipeline()
                manifest = execute_batch(project, FrozenPipelineExecutor(project), pipeline,
                    ProductionInputResolver(project, pipeline), run_id="checkpoint-" + identity[:24])
                successful = manifest["status"] == "COMPLETED"
                events = iter([{"type": "result" if successful else "workflow_blocked",
                                "stage": 6 if successful else 5,
                                "status": manifest["status"], "manifest": manifest,
                                **({} if successful else {"blocker": {"code": "PRODUCTION_EXECUTION_FAILED",
                                    "category": "execution", "retryable": False,
                                    "next_action": "Inspect the failed batch before an explicit recovery request"}}),
                                "content": f"冻结生产状态：{manifest['status']}；运行记录与报告已保存。"}])
            stage = workflow._conversation_stage()
            failed = False
            for event in events:
                event = workflow._event_progress(event, stage)
                stage = event["stage"]
                failed = failed or event.get("type") in {"error", "validation_failed", "workflow_blocked"}
                if isinstance(event.get("content"), str) and event["content"]:
                    workflow.state["history"].append({"role": "assistant", "content": event["content"],
                        "event": event.get("type", "result"), "stage": stage,
                        "highest_stage": event["highest_stage"], "input_verified": event["input_verified"],
                        "source": "checkpoint_execution", "checkpoint": checkpoint,
                        "request_id": request_id, "timestamp": _now()})
                # run_pilot may set failed_design before yielding validation_failed.
                # Persist those control-plane facts just as workflow.handle does.
                workflow.save()
                record["events"].append(event)
                write_json(path, _seal(record, "receipt_fingerprint"))
                yield event
            record.update(status="failed" if failed else "completed", finished_at=_now())
            write_json(path, _seal(record, "receipt_fingerprint"))
        except BaseException as error:
            record.update(status="failed", finished_at=_now(), error=type(error).__name__)
            from microbiome.pipeline.errors import FinalizationError
            if isinstance(error, FinalizationError):
                blocker = {"code": "PRETEST_FINALIZATION_FAILED", "category": error.category.value,
                    "requires_pretest": error.requires_pretest, "detail": str(error),
                    "missing_artifacts": error.missing_artifacts, "retryable": not error.requires_pretest,
                    "next_action": "Inspect pretest for finalization-only recovery" if not error.requires_pretest
                                   else "Inspect failed validation facts before a new pretest"}
            else:
                blocker = {"code": "CHECKPOINT_EXECUTION_INTERRUPTED", "category": "execution",
                    "retryable": False, "next_action": "Inspect the saved attempt before requesting recovery"}
            event = {"type": "workflow_blocked", "status": "FAILED",
                "content": f"检查点执行中断（{type(error).__name__}）；已有运行事实已保留。", "blocker": blocker}
            record["events"].append(event)
            workflow.state["last_workflow_blocker"] = blocker
            write_json(path, _seal(record, "receipt_fingerprint"))
            workflow.save()
            if isinstance(error, FinalizationError):
                yield event
            raise
