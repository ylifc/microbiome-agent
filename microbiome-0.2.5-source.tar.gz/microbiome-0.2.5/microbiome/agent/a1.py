import glob
import inspect
import json
import os
import re
import shutil
from collections.abc import Generator
from datetime import datetime
from pathlib import Path
from typing import Any, Literal, TypedDict

import pandas as pd
from dotenv import load_dotenv
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage
from langchain_core.prompts import ChatPromptTemplate
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, START, StateGraph

from microbiome.agent.download_gate import (
    downloads_runtime_approved,
    extract_download_items,
    format_download_inquiry,
    parse_download_reply,
)
from microbiome.capabilities import planning_capability_catalog
from microbiome.config import default_config
from microbiome.environment_manager import SoftwareEnvironmentRunner
from microbiome.input_resolution import (
    InputSourceResolver,
    inspect_local_input_sources,
    strip_sra_acquisition,
    summarize_resolution,
)
from microbiome.know_how import KnowHowLoader
from microbiome.llm import SourceType, get_llm
from microbiome.model.retriever import ToolRetriever
from microbiome.progress import OperationInfo, infer_operation, progress_event
from microbiome.resource_skills import ResourceSkillRegistry
from microbiome.resource_skills.acquisition import DatabaseAcquisitionRunner
from microbiome.resource_skills.resolver import ToolResolver
from microbiome.tool.sra_retrieval import (
    DEFAULT_DATA_ROOT,
    SRADataAcquisitionRunner,
    bind_sra_data_acquisition,
    planned_sra_data_acquisition,
)
from microbiome.tool.support_tools import run_python_repl
from microbiome.tool.tool_registry import ToolRegistry
from microbiome.utils import (
    check_and_download_s3_files,
    clean_message_content,
    convert_markdown_to_pdf,
    create_parsing_error_html,
    find_matching_execution,
    format_execute_tags_in_content,
    format_lists_in_text,
    format_observation_as_terminal,
    function_to_api_schema,
    has_execution_results,
    inject_custom_functions_to_repl,
    parse_tool_calls_from_code,
    parse_tool_calls_with_modules,
    pretty_print,
    read_module2api,
    run_bash_script,
    run_r_code,
    run_with_timeout,
    should_skip_message,
    textify_api_dict,
)

if os.environ.get("MICROBIOME_LEGACY_MODEL_CONFIG") == "1" and os.environ.get("MICROBIOME_LLM_TRANSPORT") != "harness" and os.path.exists(".env"):
    load_dotenv(".env", override=False)
    print("Loaded environment variables from .env")


_UNAUTHORIZED_DOWNLOAD_MSG = (
    "检测到未授权的数据资源下载。只有已确认方案中带 "
    "[MICROBIOME_DB_ACQUISITION:<database-id>] 标记的数据库才可获取和本地化。\n"
    "Unauthorized data-resource download detected. Only databases marked "
    "[MICROBIOME_DB_ACQUISITION:<database-id>] in the confirmed plan may be acquired and localized."
)
_UNPLANNED_NETWORK_DOWNLOAD_MSG = "检测到计划外数据库网络下载命令；请只使用已确认方案中的数据库获取提案。 / Unplanned database network download command detected; please use only the database acquisition proposals from the confirmed plan."
_UNPLANNED_DATA_DOWNLOAD_MSG = "检测到尚未确认的输入数据下载；请先向用户展示数据名称、来源和目标目录。 / Unconfirmed input-data download detected; first show the user the data name, source, and target directory."


_MARKER_PRINT_RE = re.compile(
    r"^(?:echo|printf)\s+['\"]?\[MICROBIOME_[A-Z_]+\]['\"]?$"
    r"|^print\s*\(\s*['\"]\[MICROBIOME_[A-Z_]+\]['\"]\s*\)$",
    re.IGNORECASE | re.DOTALL,
)


def _is_marker_print(code: str) -> bool:
    """True when a command is only a control marker print, not real analysis.

    Such commands must not enter the execution ledger as analysis steps, or they
    would be replayed verbatim as (noise) production steps.
    """
    return bool(_MARKER_PRINT_RE.match((code or "").strip()))


def _extract_exit_code(result: str) -> int | None:
    """Best-effort numeric exit code from an execution result string."""
    match = re.search(r"(?:exit|return)\s*code:?\s*(\d+)", result or "", re.IGNORECASE)
    return int(match.group(1)) if match else None


# A standard shebang (#!/bin/bash, #!/usr/bin/env bash, #!/bin/sh, ...) that local
# models often emit instead of the executor's #!BASH marker. It must be normalized
# to #!BASH so bash payloads are not misclassified as Python (the recurring
# "invalid syntax (<string>, line 2)" loop). The word boundary keeps #!/bin/fish
# and #!/bin/zsh from being treated as bash.
_BASH_SHEBANG_RE = re.compile(r"^#![^\n]*\b(?:ba)?sh\b", re.IGNORECASE)

# Fullwidth ASCII punctuation that Chinese-context LLMs emit into code; map back
# to ASCII so generated shell/Python payloads stay executable over long sessions.
_FULLWIDTH_TO_ASCII = str.maketrans(
    {
        "｜": "|",
        "＜": "<",
        "＞": ">",
        "＝": "=",
        "＋": "+",
        "－": "-",
        "＊": "*",
        "／": "/",
        "＼": "\\",
        "（": "(",
        "）": ")",
        "［": "[",
        "］": "]",
        "｛": "{",
        "｝": "}",
        "！": "!",
        "？": "?",
        "；": ";",
        "：": ":",
        "，": ",",
        "．": ".",
        "　": " ",
        "＂": '"',
        "＇": "'",
        "～": "~",
        "＾": "^",
        "％": "%",
        "＃": "#",
        "＠": "@",
        "＆": "&",
    }
)


class AgentState(TypedDict):
    messages: list[BaseMessage]
    next_step: str | None


class A1:
    PREFLIGHT_MARKER = "[MICROBIOME_PREFLIGHT_COMPLETE]"
    PILOT_VERIFIED_MARKER = "[MICROBIOME_PILOT_VERIFIED]"
    RESULT_VERIFIED_MARKER = "[MICROBIOME_RESULT_VERIFIED]"
    EXECUTION_GUARD_MARKER = "[MICROBIOME_EXECUTION_GUARD]"
    TOOL_OBSERVATION_MARKER = "[MICROBIOME_TOOL_OBSERVATION]"
    RESOURCE_BLOCKED_MARKER = "[MICROBIOME_RESOURCE_BLOCKED]"
    MAX_EXECUTION_GUARD_RETRIES = 8
    MAX_PLANNING_READ_ONLY_CALLS = 4

    def __init__(
        self,
        path: str | None = None,
        llm: str | None = None,
        source: SourceType | None = None,
        use_tool_retriever: bool | None = None,
        timeout_seconds: int | None = None,
        base_url: str | None = None,
        api_key: str | None = None,
        commercial_mode: bool | None = None,
        expected_data_lake_files: list | None = None,
        enable_datalake_download: bool = False,
        resource_skill_dirs: list[str] | None = None,
        auto_install: bool | None = None,
        require_frozen_production: bool = True,
        model_client=None,
    ):
        """Initialize the microbiome agent.

        Args:
            path: Path to the data
            llm: LLM to use for the agent
            source (str): Source provider: "OpenAI", "AzureOpenAI", "Anthropic", "Ollama", "Gemini", "Bedrock", or "Custom"
            use_tool_retriever: If True, use a tool retriever
            timeout_seconds: Timeout for code execution in seconds
            base_url: Base URL for custom model serving (e.g., "http://localhost:8000/v1")
            api_key: API key for the custom LLM
            commercial_mode: If True, excludes datasets that require commercial licenses or are non-commercial only
            enable_datalake_download: Explicitly opt in to downloading the optional legacy biomedical
                data lake/benchmark during initialization. It is disabled by default and is separate
                from microbial raw-sample and database acquisition.
            resource_skill_dirs: Optional roots containing extensible software/database SKILL.md files
            auto_install: Automatically create/repair confirmed resource-skill environments
            require_frozen_production: Strict-by-default deployment mode that blocks conversational
                full-scale execution and automatically freezes/uses validated microbiome-pipeline
                artifacts. Set False only for explicit legacy compatibility.
            model_client: Already connected host/endpoint model. Bypasses provider
                construction and credential lookup. Wrap calls in use_host_model()
                when helper tools also require the same model.

        """
        # Use default_config values for unspecified parameters
        if path is None:
            path = default_config.path
        if llm is None:
            llm = default_config.llm
        if source is None and model_client is None:
            source = default_config.source
        if use_tool_retriever is None:
            use_tool_retriever = default_config.use_tool_retriever
        if timeout_seconds is None:
            timeout_seconds = default_config.timeout_seconds
        if base_url is None and model_client is None:
            base_url = default_config.base_url
        if api_key is None and model_client is None:
            api_key = default_config.api_key
        if commercial_mode is None:
            commercial_mode = default_config.commercial_mode

        # Resolve the model before creating directories or preparing resources.
        self.llm = model_client if model_client is not None else get_llm(
            llm,
            stop_sequences=["</execute>", "</solution>"],
            source=source,
            base_url=base_url,
            api_key=api_key,
            config=default_config,
        )

        # Import appropriate env_desc based on commercial_mode
        if commercial_mode:
            from microbiome.env_desc_cm import data_lake_dict, library_content_dict

            print("🏢 Commercial mode: Using commercial-licensed datasets only")
        else:
            from microbiome.env_desc import data_lake_dict, library_content_dict

            print("🎓 Academic mode: Using all datasets (including non-commercial)")

        # Store as instance attributes for later use
        self.data_lake_dict = data_lake_dict
        self.library_content_dict = library_content_dict
        self.commercial_mode = commercial_mode
        self.auto_install = (
            os.environ.get("MICROBIOME_AUTO_INSTALL", "1").strip().lower() not in {"0", "false", "no", "off"}
            if auto_install is None
            else bool(auto_install)
        )
        self.require_frozen_production = bool(require_frozen_production)
        self._use_persistent_workflow = bool(require_frozen_production)

        # Display configuration in a nice, readable format
        print("\n" + "=" * 50)
        print("🔧 Microbiome — 微生物生物信息分析 Agent | Microbial Bioinformatics Analysis Agent")
        print("   配置总览 Configuration")
        print("=" * 50)

        # Get the actual LLM values that will be used by the agent
        agent_llm = llm if llm is not None else default_config.llm
        agent_source = source if source is not None else default_config.source

        print("📋 Execution configuration:")
        config_dict = default_config.to_dict()
        for key, value in config_dict.items():
            if key in {"api_key", "base_url", "llm", "source"}:
                continue
            if value is not None:
                # Special formatting for commercial_mode
                if key == "commercial_mode":
                    mode_text = "Commercial (licensed datasets only)" if value else "Academic (all datasets)"
                    print(f"  {key.replace('_', ' ').title()}: {mode_text}")
                else:
                    print(f"  {key.replace('_', ' ').title()}: {value}")

        if model_client is not None:
            print("  Model connection: attached host/endpoint client")
        elif agent_llm != default_config.llm or agent_source != default_config.source:
            print("\n🤖 AGENT LLM (Constructor Override):")
            print(f"  LLM Model: {agent_llm}")
            if agent_source is not None:
                print(f"  Source: {agent_source}")

        print("=" * 50 + "\n")

        self.path = path

        if not os.path.exists(path):
            os.makedirs(path)
            print(f"Created directory: {path}")

        # --- Begin custom folder/file checks ---
        benchmark_dir = os.path.join(path, "microbiome_data", "benchmark")
        data_lake_dir = os.path.join(path, "microbiome_data", "data_lake")

        # Create the microbiome_data directory structure
        os.makedirs(benchmark_dir, exist_ok=True)
        os.makedirs(data_lake_dir, exist_ok=True)

        if enable_datalake_download:
            selected_data_lake_files = (
                list(self.data_lake_dict.keys())
                if expected_data_lake_files is None
                else list(expected_data_lake_files)
            )

            # Check and download missing data lake files
            print("Checking and downloading missing data lake files...")
            check_and_download_s3_files(
                s3_bucket_url="https://biomni-release.s3.amazonaws.com",
                local_data_lake_path=data_lake_dir,
                expected_files=selected_data_lake_files,
                folder="data_lake",
            )

            # Check if benchmark directory structure is complete
            benchmark_ok = False
            if os.path.isdir(benchmark_dir):
                patient_gene_detection_dir = os.path.join(benchmark_dir, "hle")
                if os.path.isdir(patient_gene_detection_dir):
                    benchmark_ok = True

            if not benchmark_ok:
                print("Checking and downloading benchmark files...")
                check_and_download_s3_files(
                    s3_bucket_url="https://biomni-release.s3.amazonaws.com",
                    local_data_lake_path=benchmark_dir,
                    expected_files=[],  # Empty list - will download entire folder
                    folder="benchmark",
                )
        else:
            print("Skipping optional legacy biomedical data-lake download (explicit opt-in required).")
            print("Microbial raw samples and databases are resolved separately through their approval gates.")

        self.path = os.path.join(path, "microbiome_data")
        module2api = read_module2api()

        self.module2api = module2api
        self.use_tool_retriever = use_tool_retriever

        if self.use_tool_retriever:
            self.tool_registry = ToolRegistry(module2api)
            self.retriever = ToolRetriever()

        # Initialize know-how loader
        self.know_how_loader = KnowHowLoader()
        self.resource_skill_registry = ResourceSkillRegistry(tolerate_invalid=True)
        # Softwares that failed during this run; a later success is recorded as the proven fix
        self._session_software_failures: set[str] = set()
        if resource_skill_dirs:
            existing_roots = set(self.resource_skill_registry.skill_roots)
            for skill_dir in resource_skill_dirs:
                resolved = Path(skill_dir).expanduser().resolve()
                if resolved not in existing_roots:
                    self.resource_skill_registry.skill_roots.append(resolved)
            self.resource_skill_registry.reload()

        # Filter know-how documents based on commercial mode
        if commercial_mode:
            self._filter_know_how_for_commercial_mode()

        print(f"📚 Loaded {len(self.know_how_loader.documents)} know-how documents")
        print(f"🧭 Loaded {len(self.resource_skill_registry.skills)} resource skills")

        # Add timeout parameter
        # 3600s default (1 hour) so heavy steps like metagenome assembly can finish;
        # override via MICROBIOME_TIMEOUT_SECONDS or the constructor.
        self.timeout_seconds = timeout_seconds or int(os.environ.get("MICROBIOME_TIMEOUT_SECONDS", 3600))
        self._reset_planning_session()
        self.configure()

    def add_tool(self, api):
        """Add a new tool to the agent's tool registry and make it available for retrieval.

        Args:
            api: A callable function to be added as a tool

        """
        try:
            # Get function information
            function_code = inspect.getsource(api)
            module_name = api.__module__ if hasattr(api, "__module__") else "custom_tools"
            function_name = api.__name__ if hasattr(api, "__name__") else str(api)

            # Generate API schema using the existing utility function
            schema = function_to_api_schema(function_code, self.llm)

            # Ensure the schema has all required fields for the tool registry
            if not isinstance(schema, dict):
                raise ValueError("Generated schema is not a dictionary")

            # Validate and enhance the schema

            # Set default values if missing
            if "name" not in schema:
                schema["name"] = function_name
            if "description" not in schema:
                schema["description"] = f"Custom tool: {function_name}"
            if "required_parameters" not in schema:
                # Try to extract from parameters if available
                if "parameters" in schema and isinstance(schema["parameters"], dict):
                    required_params = []
                    params = schema["parameters"]
                    if "properties" in params:
                        for param_name in params["properties"]:
                            if param_name in params.get("required", []):
                                required_params.append(param_name)
                    schema["required_parameters"] = required_params
                else:
                    schema["required_parameters"] = []

            # Add module information to the schema
            schema["module"] = module_name

            # Add the tool to the tool registry if it exists
            if hasattr(self, "tool_registry") and self.tool_registry is not None:
                try:
                    self.tool_registry.register_tool(schema)
                    print(f"Successfully registered tool '{schema['name']}' in tool registry")
                except Exception as e:
                    print(f"Warning: Failed to register tool in registry: {e}")
                    # Continue with adding to module2api even if registry fails

            # Add the tool to module2api structure for system prompt generation
            if not hasattr(self, "module2api") or self.module2api is None:
                self.module2api = {}

            if module_name not in self.module2api:
                self.module2api[module_name] = []

            # Check if tool already exists in module2api to avoid duplicates
            existing_tool = None
            for existing in self.module2api[module_name]:
                if existing.get("name") == schema["name"]:
                    existing_tool = existing
                    break

            if existing_tool:
                # Update existing tool
                existing_tool.update(schema)
                print(f"Updated existing tool '{schema['name']}' in module '{module_name}'")
            else:
                # Add new tool
                self.module2api[module_name].append(schema)
                print(f"Added new tool '{schema['name']}' to module '{module_name}'")

            # Update the tool registry's document dataframe if it exists
            if hasattr(self, "tool_registry") and self.tool_registry is not None:
                try:
                    # Rebuild the document dataframe
                    docs = []
                    for tool_id in range(len(self.tool_registry.tools)):
                        docs.append(
                            [
                                int(tool_id),
                                self.tool_registry.get_tool_by_id(int(tool_id)),
                            ]
                        )
                    self.tool_registry.document_df = pd.DataFrame(docs, columns=["docid", "document_content"])
                except Exception as e:
                    print(f"Warning: Failed to update tool registry document dataframe: {e}")

            # Store the original function for potential future use
            if not hasattr(self, "_custom_functions"):
                self._custom_functions = {}
            self._custom_functions[schema["name"]] = api

            # Also store in _custom_tools for highlighting
            if not hasattr(self, "_custom_tools"):
                self._custom_tools = {}
            self._custom_tools[schema["name"]] = {
                "name": schema["name"],
                "description": schema["description"],
                "module": module_name,
            }

            # Make the function available in the global namespace for execution
            import builtins

            if not hasattr(builtins, "_microbiome_custom_functions"):
                builtins._microbiome_custom_functions = {}
            builtins._microbiome_custom_functions[schema["name"]] = api

            print(
                f"Tool '{schema['name']}' successfully added and ready for use in both direct execution and retrieval"
            )
            self.configure()
            return schema

        except Exception as e:
            print(f"Error adding tool: {e}")
            import traceback

            traceback.print_exc()
            raise

    def add_mcp(self, config_path: str | Path = "./tutorials/examples/mcp_config.yaml") -> None:
        """
        Add MCP (Model Context Protocol) tools from configuration file.

        This method dynamically registers MCP server tools as callable functions within
        the microbiome agent system. Each MCP server is loaded as an independent module
        with its tools exposed as synchronous wrapper functions.

        Supports both manual tool definitions and automatic tool discovery from MCP servers.

        Args:
            config_path: Path to the MCP configuration YAML file containing server
                        definitions and tool specifications.

        Raises:
            FileNotFoundError: If the config file doesn't exist
            yaml.YAMLError: If the config file is malformed
            RuntimeError: If MCP server initialization fails
        """
        import asyncio
        import os
        import sys
        import types
        from pathlib import Path

        import nest_asyncio
        import yaml
        from mcp import ClientSession
        from mcp.client.stdio import StdioServerParameters, stdio_client

        nest_asyncio.apply()

        def discover_mcp_tools_sync(server_params: StdioServerParameters) -> list[dict]:
            """Discover available tools from MCP server synchronously."""
            try:

                async def _discover_async():
                    async with stdio_client(server_params) as (reader, writer):
                        async with ClientSession(reader, writer) as session:
                            await session.initialize()

                            # Get available tools
                            tools_result = await session.list_tools()
                            tools = tools_result.tools if hasattr(tools_result, "tools") else tools_result

                            discovered_tools = []
                            for tool in tools:
                                if hasattr(tool, "name"):
                                    discovered_tools.append(
                                        {
                                            "name": tool.name,
                                            "description": tool.description,
                                            "inputSchema": tool.inputSchema,
                                        }
                                    )
                                else:
                                    print(f"Warning: Skipping tool with no name attribute: {tool}")

                            return discovered_tools

                return asyncio.run(_discover_async())
            except Exception as e:
                print(f"Failed to discover tools: {e}")
                return []

        def make_mcp_wrapper(cmd: str, args: list[str], tool_name: str, doc: str, env_vars: dict = None):
            """Create a synchronous wrapper for an async MCP tool call."""

            def sync_tool_wrapper(**kwargs):
                """Synchronous wrapper for MCP tool execution."""
                try:
                    server_params = StdioServerParameters(command=cmd, args=args, env=env_vars)

                    async def async_tool_call():
                        async with stdio_client(server_params) as (reader, writer):
                            async with ClientSession(reader, writer) as session:
                                await session.initialize()
                                result = await session.call_tool(tool_name, kwargs)
                                content = result.content[0]
                                if hasattr(content, "json"):
                                    return content.json()
                                return content.text

                    try:
                        loop = asyncio.get_running_loop()
                        return loop.create_task(async_tool_call())
                    except RuntimeError:
                        return asyncio.run(async_tool_call())

                except Exception as e:
                    raise RuntimeError(f"MCP tool execution failed for '{tool_name}': {e}") from e

            sync_tool_wrapper.__name__ = tool_name
            sync_tool_wrapper.__doc__ = doc
            return sync_tool_wrapper

        # Initialize registries if they don't exist
        self._custom_functions = getattr(self, "_custom_functions", {})
        self._custom_tools = getattr(self, "_custom_tools", {})

        # Load and validate configuration
        try:
            config_content = Path(config_path).read_text(encoding="utf-8")
            cfg: dict[str, Any] = yaml.safe_load(config_content) or {}
        except FileNotFoundError:
            raise FileNotFoundError(f"MCP config file not found: {config_path}") from None
        except yaml.YAMLError as e:
            raise yaml.YAMLError(f"Invalid YAML in MCP config: {e}") from e

        mcp_servers: dict[str, Any] = cfg.get("mcp_servers", {})
        if not mcp_servers:
            print("Warning: No MCP servers found in configuration")
            return

        # Process each MCP server configuration
        for server_name, server_meta in mcp_servers.items():
            if not server_meta.get("enabled", True):
                continue

            # Validate command configuration
            cmd_list = server_meta.get("command", [])
            if not cmd_list or not isinstance(cmd_list, list):
                print(f"Warning: Invalid command configuration for server '{server_name}'")
                continue

            cmd, *args = cmd_list

            # Process environment variables
            env_vars = server_meta.get("env", {})
            if env_vars:
                processed_env = {}
                for key, value in env_vars.items():
                    if isinstance(value, str) and value.startswith("${") and value.endswith("}"):
                        var_name = value[2:-1]
                        processed_env[key] = os.getenv(var_name, "")
                    else:
                        processed_env[key] = value
                env_vars = processed_env

            # Create module namespace for this MCP server
            mcp_module_name = f"mcp_servers.{server_name}"
            if mcp_module_name not in sys.modules:
                sys.modules[mcp_module_name] = types.ModuleType(mcp_module_name)
            server_module = sys.modules[mcp_module_name]

            tools_config = server_meta.get("tools", [])

            if not tools_config:
                try:
                    server_params = StdioServerParameters(command=cmd, args=args, env=env_vars)
                    tools_config = discover_mcp_tools_sync(server_params)

                    if tools_config:
                        print(f"Discovered {len(tools_config)} tools from {server_name} MCP server")
                    else:
                        print(f"Warning: No tools discovered from {server_name} MCP server")
                        continue

                except Exception as e:
                    print(f"Failed to discover tools for {server_name}: {e}")
                    continue

            # Register each tool
            for tool_meta in tools_config:
                if isinstance(tool_meta, dict) and "microbiome_name" in tool_meta:
                    # Manual tool definition
                    tool_name = tool_meta.get("microbiome_name")
                    description = tool_meta.get("description", f"MCP tool: {tool_name}")
                    parameters = tool_meta.get("parameters", {})
                    # For manual tools, check if each parameter has a "required" field
                    required_param_names = []
                    for param_name, param_spec in parameters.items():
                        if param_spec.get("required", False):
                            required_param_names.append(param_name)
                else:
                    # Auto-discovered tool
                    tool_name = tool_meta.get("name")
                    description = tool_meta.get("description", f"MCP tool: {tool_name}")
                    input_schema = tool_meta.get("inputSchema", {})
                    parameters = input_schema.get("properties", {})
                    # For auto-discovered tools, get required list from inputSchema top level
                    required_param_names = input_schema.get("required", [])

                if not tool_name:
                    print(f"Warning: Skipping tool with no name in {server_name}")
                    continue

                # Create wrapper function
                wrapper_function = make_mcp_wrapper(cmd, args, tool_name, description, env_vars)

                # Add to module namespace
                setattr(server_module, tool_name, wrapper_function)

                # Build parameter lists
                required_params, optional_params = [], []
                for param_name, param_spec in parameters.items():
                    param_info = {
                        "name": param_name,
                        "type": str(param_spec.get("type", "string")),
                        "description": param_spec.get("description", ""),
                        "default": param_spec.get("default", None),
                    }

                    # Check if parameter is required based on the required_param_names list
                    if param_name in required_param_names:
                        required_params.append(param_info)
                    else:
                        optional_params.append(param_info)

                # Create tool schema
                tool_schema = {
                    "name": tool_name,
                    "description": description,
                    "parameters": parameters,
                    "required_parameters": required_params,
                    "optional_parameters": optional_params,
                    "module": mcp_module_name,
                    "fn": wrapper_function,
                }

                # Register in tool registry
                self.tool_registry.register_tool(tool_schema)

                # Add to module2api mapping
                if mcp_module_name not in self.module2api:
                    self.module2api[mcp_module_name] = []
                self.module2api[mcp_module_name].append(tool_schema)

                # Add to instance registries
                self._custom_functions[tool_name] = wrapper_function
                self._custom_tools[tool_name] = {
                    "name": tool_name,
                    "description": description,
                    "module": mcp_module_name,
                }

        # Update agent configuration
        self.configure()

    def get_custom_tool(self, name):
        """Get a custom tool by name.

        Args:
            name: The name of the custom tool

        Returns:
            The custom tool function if found, None otherwise

        """
        if hasattr(self, "_custom_functions") and name in self._custom_functions:
            return self._custom_functions[name]
        return None

    def list_custom_tools(self):
        """List all custom tools that have been added.

        Returns:
            A list of custom tool names

        """
        if hasattr(self, "_custom_functions"):
            return list(self._custom_functions.keys())
        return []

    def remove_custom_tool(self, name):
        """Remove a custom tool.

        Args:
            name: The name of the custom tool to remove

        Returns:
            True if the tool was removed, False if it wasn't found

        """
        removed = False

        # Remove from custom functions
        if hasattr(self, "_custom_functions") and name in self._custom_functions:
            del self._custom_functions[name]
            removed = True

        # Remove from custom tools (for highlighting)
        if hasattr(self, "_custom_tools") and name in self._custom_tools:
            del self._custom_tools[name]
            removed = True

        # Remove from global namespace
        import builtins

        if hasattr(builtins, "_microbiome_custom_functions") and name in builtins._microbiome_custom_functions:
            del builtins._microbiome_custom_functions[name]

        # Remove from tool registry
        if hasattr(self, "tool_registry") and self.tool_registry is not None:
            if self.tool_registry.remove_tool_by_name(name):
                removed = True
                # Rebuild the document dataframe
                try:
                    docs = []
                    for tool_id in range(len(self.tool_registry.tools)):
                        docs.append(
                            [
                                int(tool_id),
                                self.tool_registry.get_tool_by_id(int(tool_id)),
                            ]
                        )
                    self.tool_registry.document_df = pd.DataFrame(docs, columns=["docid", "document_content"])
                except Exception as e:
                    print(f"Warning: Failed to update tool registry document dataframe: {e}")

        # Remove from module2api
        if hasattr(self, "module2api"):
            for tools in self.module2api.values():
                for i, tool in enumerate(tools):
                    if tool.get("name") == name:
                        del tools[i]
                        removed = True
                        break

        if removed:
            print(f"Custom tool '{name}' has been removed")
        else:
            print(f"Custom tool '{name}' was not found")

        return removed

    def add_data(self, data):
        """Add new data to the data lake.

        Args:
            data: Dictionary with file path as key and description as value
                  e.g., {'my_dataset.csv': 'A dataset containing gene expression data'}
                  or {'path/to/file.txt': 'Description of the file'}

        """
        try:
            if not isinstance(data, dict):
                raise ValueError("Data must be a dictionary with file path as key and description as value")

            # Initialize custom data storage if it doesn't exist
            if not hasattr(self, "_custom_data"):
                self._custom_data = {}

            # Add each data item
            for file_path, description in data.items():
                if not isinstance(file_path, str) or not isinstance(description, str):
                    print("Warning: Skipping invalid data entry - file_path and description must be strings")
                    continue

                # Extract filename from path for storage
                filename = os.path.basename(file_path) if "/" in file_path else file_path

                # Store the data with both the full path and description
                self._custom_data[filename] = {
                    "path": file_path,
                    "description": description,
                }

                # Also add to the data_lake_dict for consistency
                self.data_lake_dict[filename] = description

                print(f"Added data item '{filename}': {description}")
            self.configure()
            print(f"Successfully added {len(data)} data item(s) to the data lake")
            return True

        except Exception as e:
            print(f"Error adding data: {e}")
            import traceback

            traceback.print_exc()
            return False

    def get_custom_data(self, name):
        """Get a custom data item by name.

        Args:
            name: The name of the custom data item

        Returns:
            The custom data item info if found, None otherwise

        """
        if hasattr(self, "_custom_data") and name in self._custom_data:
            return self._custom_data[name]
        return None

    def list_custom_data(self):
        """List all custom data items that have been added.

        Returns:
            A list of custom data item names and descriptions

        """
        if hasattr(self, "_custom_data"):
            return [(name, info["description"]) for name, info in self._custom_data.items()]
        return []

    def remove_custom_data(self, name):
        """Remove a custom data item.

        Args:
            name: The name of the custom data item to remove

        Returns:
            True if the data item was removed, False if it wasn't found

        """
        removed = False

        # Remove from custom data
        if hasattr(self, "_custom_data") and name in self._custom_data:
            del self._custom_data[name]
            removed = True

        # Remove from data_lake_dict
        if hasattr(self, "data_lake_dict") and name in self.data_lake_dict:
            del self.data_lake_dict[name]
            removed = True

        if removed:
            print(f"Custom data item '{name}' has been removed")
        else:
            print(f"Custom data item '{name}' was not found")

        return removed

    def add_software(self, software):
        """Add new software to the software library.

        Args:
            software: Dictionary with software name as key and description as value
                     e.g., {'custom_tool': 'A custom analysis tool for processing data'}
                     or {'my_package': 'Description of the package functionality'}

        """
        try:
            if not isinstance(software, dict):
                raise ValueError("Software must be a dictionary with software name as key and description as value")

            # Initialize custom software storage if it doesn't exist
            if not hasattr(self, "_custom_software"):
                self._custom_software = {}

            # Add each software item
            for software_name, description in software.items():
                if not isinstance(software_name, str) or not isinstance(description, str):
                    print("Warning: Skipping invalid software entry - software_name and description must be strings")
                    continue

                # Store the software with description
                self._custom_software[software_name] = {
                    "name": software_name,
                    "description": description,
                }

                # Also add to the library_content_dict for consistency
                self.library_content_dict[software_name] = description

                print(f"Added software '{software_name}': {description}")

            print(f"Successfully added {len(software)} software item(s) to the library")
            self.configure()
            return True

        except Exception as e:
            print(f"Error adding software: {e}")
            import traceback

            traceback.print_exc()
            return False

    def get_custom_software(self, name):
        """Get a custom software item by name.

        Args:
            name: The name of the custom software item

        Returns:
            The custom software item info if found, None otherwise

        """
        if hasattr(self, "_custom_software") and name in self._custom_software:
            return self._custom_software[name]
        return None

    def list_custom_software(self):
        """List all custom software items that have been added.

        Returns:
            A list of custom software item names and descriptions

        """
        if hasattr(self, "_custom_software"):
            return [(name, info["description"]) for name, info in self._custom_software.items()]
        return []

    def remove_custom_software(self, name):
        """Remove a custom software item.

        Args:
            name: The name of the custom software item to remove

        Returns:
            True if the software item was removed, False if it wasn't found

        """
        removed = False

        # Remove from custom software
        if hasattr(self, "_custom_software") and name in self._custom_software:
            del self._custom_software[name]
            removed = True

        # Remove from library_content_dict
        if hasattr(self, "library_content_dict") and name in self.library_content_dict:
            del self.library_content_dict[name]
            removed = True

        if removed:
            print(f"Custom software item '{name}' has been removed")
        else:
            print(f"Custom software item '{name}' was not found")

        return removed

    def _filter_know_how_for_commercial_mode(self):
        """Filter out know-how documents that don't allow commercial use.

        This method removes documents from the know-how loader that have
        commercial use restrictions when the agent is in commercial mode.
        """
        docs_to_remove = []

        for doc_id, doc in self.know_how_loader.documents.items():
            metadata = doc.get("metadata", {})
            commercial_use = metadata.get("commercial_use", "")

            # Check if commercial use is NOT allowed
            if "❌" in commercial_use or "Not Allowed" in commercial_use or "Non-Commercial" in commercial_use:
                docs_to_remove.append(doc_id)

        # Remove documents that don't allow commercial use
        for doc_id in docs_to_remove:
            doc_name = self.know_how_loader.documents[doc_id]["name"]
            self.know_how_loader.remove_document(doc_id)
            print(f"  ⚠️  Excluded know-how '{doc_name}' (non-commercial license)")

    def _generate_system_prompt(
        self,
        tool_desc,
        data_lake_content,
        library_content_list,
        self_critic=False,
        is_retrieval=False,
        custom_tools=None,
        custom_data=None,
        custom_software=None,
        know_how_docs=None,
    ):
        """Generate the system prompt based on the provided resources.

        Args:
            tool_desc: Dictionary of tool descriptions
            data_lake_content: List of data lake items
            library_content_list: List of libraries
            self_critic: Whether to include self-critic instructions
            is_retrieval: Whether this is for retrieval (True) or initial configuration (False)
            custom_tools: List of custom tools to highlight
            custom_data: List of custom data items to highlight
            custom_software: List of custom software items to highlight
            know_how_docs: List of know-how documents with best practices and protocols

        Returns:
            The generated system prompt

        """

        def format_item_with_description(name, description):
            """Format an item with its description in a readable way."""
            # Handle None or empty descriptions
            if not description:
                description = f"Data lake item: {name}"

            # Check if the item is already formatted (contains a colon)
            if isinstance(name, str) and ": " in name:
                return name

            # Wrap long descriptions to make them more readable
            max_line_length = 80
            if len(description) > max_line_length:
                # Simple wrapping for long descriptions
                wrapped_desc = []
                words = description.split()
                current_line = ""

                for word in words:
                    if len(current_line) + len(word) + 1 <= max_line_length:
                        if current_line:
                            current_line += " " + word
                        else:
                            current_line = word
                    else:
                        wrapped_desc.append(current_line)
                        current_line = word

                if current_line:
                    wrapped_desc.append(current_line)

                # Join with newlines and proper indentation
                formatted_desc = f"{name}:\n  " + "\n  ".join(wrapped_desc)
                return formatted_desc
            else:
                return f"{name}: {description}"

        # Separate custom and default resources
        default_data_lake_content = []
        default_library_content_list = []

        # Filter out custom items from default lists
        custom_data_names = set()
        custom_software_names = set()

        if custom_data:
            custom_data_names = {item.get("name") if isinstance(item, dict) else item for item in custom_data}
        if custom_software:
            custom_software_names = {item.get("name") if isinstance(item, dict) else item for item in custom_software}

        # Separate default data lake items
        for item in data_lake_content:
            if isinstance(item, dict):
                name = item.get("name", "")
                if name not in custom_data_names:
                    default_data_lake_content.append(item)
            elif item not in custom_data_names:
                default_data_lake_content.append(item)

        # Separate default library items
        for lib in library_content_list:
            if isinstance(lib, dict):
                name = lib.get("name", "")
                if name not in custom_software_names:
                    default_library_content_list.append(lib)
            elif lib not in custom_software_names:
                default_library_content_list.append(lib)

        # Format the default data lake content
        if isinstance(default_data_lake_content, list) and all(
            isinstance(item, str) for item in default_data_lake_content
        ):
            # Simple list of strings - check if they already have descriptions
            data_lake_formatted = []
            for item in default_data_lake_content:
                # Check if the item already has a description (contains a colon)
                if ": " in item:
                    data_lake_formatted.append(item)
                else:
                    description = self.data_lake_dict.get(item, f"Data lake item: {item}")
                    data_lake_formatted.append(format_item_with_description(item, description))
        else:
            # List with descriptions
            data_lake_formatted = []
            for item in default_data_lake_content:
                if isinstance(item, dict):
                    name = item.get("name", "")
                    description = self.data_lake_dict.get(name, f"Data lake item: {name}")
                    data_lake_formatted.append(format_item_with_description(name, description))
                # Check if the item already has a description (contains a colon)
                elif isinstance(item, str) and ": " in item:
                    data_lake_formatted.append(item)
                else:
                    description = self.data_lake_dict.get(item, f"Data lake item: {item}")
                    data_lake_formatted.append(format_item_with_description(item, description))

        # Format the default library content
        if isinstance(default_library_content_list, list) and all(
            isinstance(item, str) for item in default_library_content_list
        ):
            if (
                len(default_library_content_list) > 0
                and isinstance(default_library_content_list[0], str)
                and "," not in default_library_content_list[0]
            ):
                # Simple list of strings
                libraries_formatted = []
                for lib in default_library_content_list:
                    description = self.library_content_dict.get(lib, f"Software library: {lib}")
                    libraries_formatted.append(format_item_with_description(lib, description))
            else:
                # Already formatted string
                libraries_formatted = default_library_content_list
        else:
            # List with descriptions
            libraries_formatted = []
            for lib in default_library_content_list:
                if isinstance(lib, dict):
                    name = lib.get("name", "")
                    description = self.library_content_dict.get(name, f"Software library: {name}")
                    libraries_formatted.append(format_item_with_description(name, description))
                else:
                    description = self.library_content_dict.get(lib, f"Software library: {lib}")
                    libraries_formatted.append(format_item_with_description(lib, description))

        # Format custom resources with highlighting
        custom_tools_formatted = []
        if custom_tools:
            for tool in custom_tools:
                if isinstance(tool, dict):
                    name = tool.get("name", "Unknown")
                    desc = tool.get("description", "")
                    module = tool.get("module", "custom_tools")
                    custom_tools_formatted.append(f"🔧 {name} (from {module}): {desc}")
                else:
                    custom_tools_formatted.append(f"🔧 {str(tool)}")

        custom_data_formatted = []
        if custom_data:
            for item in custom_data:
                if isinstance(item, dict):
                    name = item.get("name", "Unknown")
                    desc = item.get("description", "")
                    custom_data_formatted.append(f"📊 {format_item_with_description(name, desc)}")
                else:
                    desc = self.data_lake_dict.get(item, f"Custom data: {item}")
                    custom_data_formatted.append(f"📊 {format_item_with_description(item, desc)}")

        custom_software_formatted = []
        if custom_software:
            for item in custom_software:
                if isinstance(item, dict):
                    name = item.get("name", "Unknown")
                    desc = item.get("description", "")
                    custom_software_formatted.append(f"⚙️ {format_item_with_description(name, desc)}")
                else:
                    desc = self.library_content_dict.get(item, f"Custom software: {item}")
                    custom_software_formatted.append(f"⚙️ {format_item_with_description(item, desc)}")

        # Format know-how documents - include FULL content (metadata already stripped)
        know_how_formatted = []
        if know_how_docs:
            for doc in know_how_docs:
                if isinstance(doc, dict):
                    name = doc.get("name", "Unknown")
                    content = doc.get("content", "")
                    # Include full content in system prompt (metadata already removed)
                    know_how_formatted.append(f"📚 {name}:\n{content}")

        # Base prompt
        prompt_modifier = """
You are a microbial-bioinformatics AI agent developed by Dr. Li on top of Microbiome. 我是由李博士基于 Microbiome 开发的、面向微生物生物信息学分析的智能体。
Your mission is to help users with microbial bioinformatics analyses — quality control, assembly, gene prediction, binning, annotation, resistance/virulence screening, plasmid & mobile-element identification, HGT detection, phylogenetics/molecular dating, amplicon & virome analysis, and database management — so they can spend more time on experiments and scientific questions. 我能帮您完成针对微生物的多种生物信息学分析（质控、拼接、基因预测、分箱、注释、耐药/毒力筛查、质粒与移动元件鉴定、水平基因转移检测、系统发育/分子定年、扩增子与病毒组分析、数据库管理），节省您的时间，让您更专注于实验与科学问题。

When introducing yourself or greeting the user, answer bilingually (中文 + English) and present a *complete but concise* self-introduction: (a) who you are, (b) the analysis families you can plan and run, (c) the plan → 确认执行 → 确认全量执行 workflow, and (d) 2-3 concrete example tasks the user can paste directly. Do NOT reduce the greeting to a generic "How can I help?" / 自我介绍或问候用户时，请用中英双语给出完整而简洁的介绍：(a) 你是谁，(b) 你能规划和运行哪些分析家族，(c) 方案→确认执行→确认全量执行的工作流程，(d) 2-3 个可直接粘贴的具体示例任务。不要只说“有什么可以帮您”。示例任务可参考 / Example tasks you may offer: “对本地 Illumina 双端菌株样本做组装、质控、Bakta 注释、MLST 和 AMR 分析”；“对 sample_list.txt 中的 shotgun 样本做物种组成、功能通路和 MAG 重建”；“对本地 16S FASTQ 做引物感知 ASV、SILVA 分类和多样性分析”。

CAPABILITIES / 完整功能：
1. 本地优先解析 FASTQ、FASTA、目录和样本清单；逐样本区分本地文件与明确的 SRA/ENA 远程编号，远程获取单独列出并等待授权。/ Resolve local FASTQ, FASTA, directories and manifests first; classify each sample independently and gate explicit remote acquisition.
2. 设计并运行微生物质控、拼接、基因预测、分箱、注释、耐药/毒力、质粒/移动元件/HGT、系统发育/分子定年、扩增子、宏基因组/宏转录组和病毒组流程。/ Design and run microbial QC, assembly, gene prediction, binning, annotation, AMR/virulence, plasmid/mobile-element/HGT, phylogeny/dating, amplicon, metagenome/metatranscriptome and virome workflows.
3. 在规划前只读扫描所有现有 Conda/PATH 环境和数据库，优先复用已经验证 READY 的资源；以 Registry、Skill、Knowledge 三层保存位置、版本、入口、使用条件、故障与修复。/ Read-only scan and reuse validated Conda/PATH software and READY databases, preserving Registry, Skill and Knowledge contracts.
4. 持久化需求、方案、输入清单、运行日志、验证证据、冻结 DAG/参数/工具链/数据库锁和最终报告。/ Persist requirements, plans, input manifests, logs, validation evidence, frozen DAG/parameter/toolchain/database locks and reports.
5. 查阅 analysis_experience，用新数据重放已经验证的流程，并从安全检查点恢复失败任务。/ Reuse validated analysis experience on new data and recover failed tasks from safe checkpoints.
6. 在显式维护阶段新增软件/数据库/流程，或更新框架、参数和版本；冻结生产阶段绝不安装、下载、建库或改变科学参数。/ Add or update resources only in an explicit maintenance phase; frozen production never installs, downloads, builds databases or changes scientific parameters.

WORKFLOW / 工作流程：
路径设置（原始数据、下载、数据库、结果、软件记忆） → 逐样本输入解析与只读资源盘点 → 提交可修改的分析/依赖方案 → 用户输入“确认执行”后仅准备已批准资源并运行确定性的 10% 端到端小试 → 验证输出与资源事实并冻结输入清单、DAG、参数、工具链和数据库锁 → 用户输入“确认全量执行”后在完整原始数据上按锁确定性重放 → 生成报告、诊断、审计记录和可复用 analysis_experience。/ Configure paths → resolve every sample and inventory resources read-only → revise the analysis/dependency plan → “确认执行” authorizes only approved preparation plus a deterministic 10% end-to-end pilot → validate and freeze manifests, DAG, parameters, toolchain and database locks → “确认全量执行” deterministically replays the full raw dataset → emit reports, diagnostics, audit records and reusable analysis experience.

SUPPORTED MICROBIAL WORKFLOW CATALOG / 支持的微生物工作流目录：
{capability_catalog}

Before planning, check which local databases are READY (list_available_databases / auto_configure_databases)：swissprot、cog、card、checkm、genomad、checkv、gtdbtk、tcdb、bakta、kraken2、kegg、nr、qiime2、vfdb。READY 的数据库直接复用，绝不重复下载或重建。/ Before planning, check which local databases are READY and reuse them; never re-download or rebuild a READY database.

To solve tasks, you use an interactive coding environment equipped with a variety of tool functions, data, and softwares.
Bilingual output (中英双语输出)：你在执行阶段输出的所有观察、状态、结果、报告、提问和回答，都必须同时包含中文和英文（先中文后英文）。Every observation, status, result, report, question, and answer you emit during execution must be bilingual — Chinese first, then English.

Scope boundary: this is computational sequence analysis only. Do not expand an operation into pathogen engineering, modification of virulence/transmissibility, design or synthesis of novel pathogens, culture instructions, or wet-lab optimization. If one requested operation crosses that boundary, stop only that operation while continuing ordinary QC, assembly, alignment, classification, database management, and debugging that remain in scope.

Planning and execution are separate phases. Before this execution loop starts, Microbiome presents a plan, discusses and revises it with the user, and waits for explicit confirmation. Never execute code or tools before that confirmation. A confirmed request contains the marker [MICROBIOME_PLAN_CONFIRMED] or an unambiguous user confirmation in the conversation.

If the conversation does not yet contain a confirmed plan, provide or revise the plan inside <solution>...</solution>, ask the user to continue discussing it or explicitly reply “确认执行”, and stop. Do not emit <execute> in that situation.

During execution, follow the confirmed plan without restating it as a numbered checklist. Do not report "Step 1", "Step 2", "第 1 步", or similar counters. Before every <execute>, provide concise user-visible fields named 当前步骤、目的、原因、目标目录; these are operational explanations, not private chain-of-thought. Report only meaningful actions, observations, errors, and the final result.

At each execution turn, use the conversation history and confirmed plan to choose the next action.
After that, you have two options:

1) Interact with a programming environment and receive the corresponding output within <observe></observe>. Your code should be enclosed using "<execute>" tag, for example: <execute> print("Hello World!") </execute>. IMPORTANT: You must end the code block with </execute> tag.
   - For Python code (default): <execute> print("Hello World!") </execute>
   - For R code: <execute> #!R\nlibrary(ggplot2)\nprint("Hello from R") </execute>
   - For Bash scripts and commands: <execute> #!BASH\necho "Hello from Bash"\nls -la </execute>
   - For CLI softwares, use Bash scripts.

2) When you think it is ready, directly provide a solution that adheres to the required format for the given task to the user. Your solution should be enclosed using "<solution>" tag, for example: The answer is <solution> A </solution>. IMPORTANT: You must end the solution block with </solution> tag.

You may interact with the environment repeatedly to receive observations, but do not present those internal cycles as numbered steps.
Don't overcomplicate the code. Keep it simple and easy to understand.
When writing code, print only useful command results in a clear and concise research log; do not print numbered progress counters.
When calling the existing python functions in the function dictionary, YOU MUST SAVE THE OUTPUT and PRINT OUT the result.
For example, result = understand_scRNA(XXX) print(result)
Otherwise the system will not be able to know what has been done.

For R code, use the #!R marker at the beginning of your code block to indicate it's R code.
For Bash scripts and commands, use the #!BASH marker at the beginning of your code block. This allows for both simple commands and multi-line scripts with variables, loops, conditionals, loops, and other Bash features.

In each response, you must include EITHER <execute> or <solution> tag. Not both at the same time. Do not respond with messages without any tags. No empty messages.
"""

        # Add self-critic instructions if needed
        if self_critic:
            prompt_modifier += """
You may or may not receive feedbacks from human. If so, address the feedbacks by following the same procedure of multiple rounds of thinking, execution, and then coming up with a new solution.
"""

        # Add custom resources section first (highlighted)
        has_custom_resources = any(
            [custom_tools_formatted, custom_data_formatted, custom_software_formatted, know_how_formatted]
        )

        if has_custom_resources:
            prompt_modifier += """

PRIORITY CUSTOM RESOURCES
===============================
IMPORTANT: The following custom resources have been specifically added for your use.
    PRIORITIZE using these resources as they are directly relevant to your task.
    Always consider these FIRST and in the meantime using default resources.

"""

            if know_how_formatted:
                prompt_modifier += """
📚 KNOW-HOW DOCUMENTS (BEST PRACTICES & PROTOCOLS - ALREADY LOADED):
{know_how_docs}

IMPORTANT: These documents are ALREADY AVAILABLE in your context. You do NOT need to
retrieve them or "review" them as a separate step. You can DIRECTLY reference and use
the information from these documents to answer questions, provide protocols, suggest
parameters, and offer troubleshooting guidance.

These documents contain expert knowledge, protocols, and troubleshooting guidance.
Reference them directly for experimental design, methodology, and problem-solving.

"""

            if custom_tools_formatted:
                prompt_modifier += """
🔧 CUSTOM TOOLS (USE THESE FIRST):
{custom_tools}

"""

            if custom_data_formatted:
                prompt_modifier += """
📊 CUSTOM DATA (PRIORITIZE THESE DATASETS):
{custom_data}

"""

            if custom_software_formatted:
                prompt_modifier += """
⚙️ CUSTOM SOFTWARE (USE THESE LIBRARIES):
{custom_software}

"""

            prompt_modifier += """===============================
"""

        # Add environment resources
        prompt_modifier += """

Environment Resources:

- Function Dictionary:
{function_intro}
---
{tool_desc}
---

{import_instruction}

- Biological data lake
You can access a biological data lake at the following path: {data_lake_path}.
{data_lake_intro}
Each item is listed with its description to help you understand its contents.
----
{data_lake_content}
----

- Software Library:
{library_intro}
Each library is listed with its description to help you understand its functionality.
----
{library_content_formatted}
----

- Note on using R packages and Bash scripts:
  - R packages: Use subprocess.run(['Rscript', '-e', 'your R code here']) in Python, or use the #!R marker in your execute block.
  - Bash scripts and commands: Use the #!BASH marker in your execute block for both simple commands and complex shell scripts with variables, loops, conditionals, etc.
        """

        # Set appropriate text based on whether this is initial configuration or after retrieval
        if is_retrieval:
            function_intro = "Based on your query, I've identified the following most relevant functions that you can use in your code:"
            data_lake_intro = "Based on your query, I've identified the following most relevant datasets:"
            library_intro = (
                "Based on your query, I've identified the following most relevant libraries that you can use:"
            )
            import_instruction = "IMPORTANT: When using any function, you MUST first import it from its module. For example:\nfrom [module_name] import [function_name]"
        else:
            function_intro = "In your code, you will need to import the function location using the following dictionary of functions:"
            data_lake_intro = "You can write code to understand the data, process and utilize it for the task. Here is the list of datasets:"
            library_intro = "The environment supports a list of libraries that can be directly used. Do not forget the import statement:"
            import_instruction = ""

        # Format the content consistently for both initial and retrieval cases
        library_content_formatted = "\n".join(libraries_formatted)
        data_lake_content_formatted = "\n".join(data_lake_formatted)

        # Format the prompt with the appropriate values
        format_dict = {
            "capability_catalog": planning_capability_catalog(),
            "function_intro": function_intro,
            "tool_desc": textify_api_dict(tool_desc) if isinstance(tool_desc, dict) else tool_desc,
            "import_instruction": import_instruction,
            "data_lake_path": self.path + "/data_lake",
            "data_lake_intro": data_lake_intro,
            "data_lake_content": data_lake_content_formatted,
            "library_intro": library_intro,
            "library_content_formatted": library_content_formatted,
        }

        # Add custom resources to format dict if they exist
        if know_how_formatted:
            format_dict["know_how_docs"] = "\n\n".join(know_how_formatted)
        if custom_tools_formatted:
            format_dict["custom_tools"] = "\n".join(custom_tools_formatted)
        if custom_data_formatted:
            format_dict["custom_data"] = "\n".join(custom_data_formatted)
        if custom_software_formatted:
            format_dict["custom_software"] = "\n".join(custom_software_formatted)

        formatted_prompt = prompt_modifier.format(**format_dict)

        return formatted_prompt

    def configure(self, self_critic=False, test_time_scale_round=0):
        """Configure the agent with the initial system prompt and workflow.

        Args:
            self_critic: Whether to enable self-critic mode
            test_time_scale_round: Number of rounds for test time scaling

        """
        # Store self_critic for later use
        self.self_critic = self_critic

        # Get data lake content
        data_lake_path = self.path + "/data_lake"
        data_lake_content = glob.glob(data_lake_path + "/*")
        data_lake_items = [x.split("/")[-1] for x in data_lake_content]

        # data_lake_dict and library_content_dict are already set in __init__

        # Prepare tool descriptions
        tool_desc = {i: [x for x in j if x["name"] != "run_python_repl"] for i, j in self.module2api.items()}

        # Prepare data lake items with descriptions
        data_lake_with_desc = []
        for item in data_lake_items:
            description = self.data_lake_dict.get(item, f"Data lake item: {item}")
            data_lake_with_desc.append({"name": item, "description": description})

        # Add custom data items if they exist
        if hasattr(self, "_custom_data") and self._custom_data:
            for name, info in self._custom_data.items():
                data_lake_with_desc.append({"name": name, "description": info["description"]})

        # Prepare library content list including custom software
        library_content_list = list(self.library_content_dict.keys())
        if hasattr(self, "_custom_software") and self._custom_software:
            for name in self._custom_software:
                if name not in library_content_list:  # Avoid duplicates
                    library_content_list.append(name)

        # Generate the system prompt for initial configuration (is_retrieval=False)
        # Prepare custom resources for highlighting
        custom_tools = []
        if hasattr(self, "_custom_tools") and self._custom_tools:
            for name, info in self._custom_tools.items():
                custom_tools.append(
                    {
                        "name": name,
                        "description": info["description"],
                        "module": info["module"],
                    }
                )

        custom_data = []
        if hasattr(self, "_custom_data") and self._custom_data:
            for name, info in self._custom_data.items():
                custom_data.append({"name": name, "description": info["description"]})

        custom_software = []
        if hasattr(self, "_custom_software") and self._custom_software:
            for name, info in self._custom_software.items():
                custom_software.append({"name": name, "description": info["description"]})

        # Load ALL know-how documents into initial system prompt
        # This makes best practices always available, not just when retrieved
        know_how_docs = []
        if hasattr(self, "know_how_loader") and self.know_how_loader.documents:
            for _doc_id, doc in self.know_how_loader.documents.items():
                # Use content without metadata for efficiency
                know_how_docs.append(
                    {
                        "id": doc["id"],
                        "name": doc["name"],
                        "description": doc["description"],
                        "content": doc["content_without_metadata"],
                        "metadata": doc["metadata"],
                    }
                )
            print(f"📚 Loading {len(know_how_docs)} know-how documents into system prompt")

        self.system_prompt = self._generate_system_prompt(
            tool_desc=tool_desc,
            data_lake_content=data_lake_with_desc,
            library_content_list=library_content_list,
            self_critic=self_critic,
            is_retrieval=False,
            custom_tools=custom_tools if custom_tools else None,
            custom_data=custom_data if custom_data else None,
            custom_software=custom_software if custom_software else None,
            know_how_docs=know_how_docs if know_how_docs else None,
        )

        # Define the nodes
        def generate(state: AgentState) -> AgentState:
            system_prompt = self.system_prompt
            execution_authorized = self._execution_is_authorized(state["messages"])
            if execution_authorized:
                system_prompt += self._execution_mode_prompt(getattr(self, "_execution_phase", "full") or "full")
            # Local / smaller models (Ollama qwen, etc.) need an explicit, forceful format reminder,
            # otherwise they reply without <execute>/<solution> and trigger a parsing-retry loop.
            system_prompt += (
                "\n\nCRITICAL FORMAT RULE: EVERY response MUST end with EITHER an <execute>...</execute> block "
                "OR a <solution>...</solution> block (never both, never neither). Do NOT use markdown ``` code fences. "
                "If you are just answering a question or greeting, wrap the final answer in <solution>...</solution>."
            )

            messages = [SystemMessage(content=system_prompt)] + state["messages"]
            response = self.llm.invoke(messages)

            msg = self._message_text(response)

            # Enhanced parsing for better OpenAI compatibility
            # Check for incomplete tags and fix them
            if "<execute>" in msg and "</execute>" not in msg:
                msg += "</execute>"
            if "<solution>" in msg and "</solution>" not in msg:
                msg += "</solution>"
            if "<think>" in msg and "</think>" not in msg:
                msg += "</think>"

            # Some local models ignore the XML instruction and return a Markdown
            # code fence. Convert it to the exact format consumed by execute().
            msg = self._normalize_code_fence_response(msg)

            # More flexible pattern matching for different LLM styles
            think_match = re.search(r"<think>(.*?)</think>", msg, re.DOTALL | re.IGNORECASE)
            execute_match = re.search(r"<execute>(.*?)</execute>", msg, re.DOTALL | re.IGNORECASE)
            answer_match = re.search(r"<solution>(.*?)</solution>", msg, re.DOTALL | re.IGNORECASE)

            # The CLI/API use a separate planning gate, while the Gradio UI calls
            # this graph directly. Enforce the same gate here so a local model
            # cannot execute merely by ignoring the planning prompt.
            if execute_match and not execution_authorized:
                plan_text = msg[: execute_match.start()].strip()
                if not plan_text:
                    plan_text = "方案尚未得到明确确认，当前不会运行任何命令。 / The plan has not been explicitly confirmed, so no commands will run."
                msg = f"<solution>{plan_text}\n\n请继续补充或修改方案；确认无误后请明确回复“确认执行”。\nPlease continue to refine or modify the plan; once it is correct, reply exactly “确认执行” to confirm execution.</solution>"
                execute_match = None
                answer_match = re.search(r"<solution>(.*?)</solution>", msg, re.DOTALL | re.IGNORECASE)

            if execute_match and execution_authorized:
                command_blocker = self._execution_command_blocker(
                    execute_match.group(1),
                    getattr(self, "_pending_plan", "") or "",
                    getattr(self, "_execution_phase", "pilot") or "pilot",
                    runtime_approved=frozenset(getattr(self, "_runtime_approved_downloads", set()) or set()),
                    registry=getattr(self, "resource_skill_registry", None),
                )
                if command_blocker:
                    # 交互式下载确认门：小数据试跑阶段遇到计划外下载时，保存整体计划、
                    # 列出待下载清单（名称/归属物种/SRA 号）并暂停，等待用户确认。
                    download_items = extract_download_items(execute_match.group(1))
                    gate_phase = getattr(self, "_execution_phase", "pilot") or "pilot"
                    if (
                        download_items
                        and gate_phase == "pilot"
                        and command_blocker
                        in (_UNAUTHORIZED_DOWNLOAD_MSG, _UNPLANNED_NETWORK_DOWNLOAD_MSG, _UNPLANNED_DATA_DOWNLOAD_MSG)
                    ):
                        self._pending_download_items = download_items
                        self.awaiting_download_confirmation = True
                        plan_path = self._save_plan_snapshot()
                        self._pending_download_notice = format_download_inquiry(download_items, plan_path, gate_phase)
                        state["messages"].append(AIMessage(content=msg.strip()))
                        state["next_step"] = "end"
                        return state
                    state["messages"].append(AIMessage(content=msg.strip()))
                    state["messages"].append(
                        HumanMessage(
                            content=(
                                f"{self.EXECUTION_GUARD_MARKER}\n{command_blocker}\n"
                                "Do not repeat the blocked command. Return a compliant <execute> command. "
                                f"If a required database is unavailable, print {self.RESOURCE_BLOCKED_MARKER} "
                                "and then explain its Database/<id>/ placement and localization instructions."
                            )
                        )
                    )
                    state["next_step"] = "generate"
                    return state

            if answer_match and execution_authorized:
                solution_text = answer_match.group(1).strip()
                blocker = self._execution_solution_blocker(
                    state["messages"],
                    solution_text,
                    getattr(self, "_execution_phase", "full") or "full",
                )
                if blocker:
                    state["messages"].append(AIMessage(content=msg.strip()))
                    guard_count = sum(
                        1
                        for message in state["messages"]
                        if isinstance(message, HumanMessage) and self.EXECUTION_GUARD_MARKER in message.content
                    )
                    if guard_count >= self.MAX_EXECUTION_GUARD_RETRIES:
                        state["messages"].append(
                            AIMessage(
                                content=(
                                    "<solution>执行代理连续未能满足运行状态门，已停止以避免无限循环。\n"
                                    "The execution agent repeatedly failed the runtime state gate and stopped to avoid an infinite loop.\n"
                                    f"最后阻塞原因：{blocker}\nLast blocking reason: {blocker}</solution>"
                                )
                            )
                        )
                        state["next_step"] = "end"
                    else:
                        state["messages"].append(
                            HumanMessage(
                                content=(
                                    f"{self.EXECUTION_GUARD_MARKER}\n{blocker}\n"
                                    "用户已经确认执行。不要再次请求确认，也不要返回最终答案。"
                                    "分析当前观察，使用一个 <execute> 块给出并运行下一条具体命令。"
                                )
                            )
                        )
                        state["next_step"] = "generate"
                    return state

            # Add the message to the state before checking for errors
            state["messages"].append(AIMessage(content=msg.strip()))

            if answer_match:
                state["next_step"] = "end"
            elif execute_match:
                state["next_step"] = "execute"
            elif think_match:
                state["next_step"] = "generate"
            else:
                print("parsing error...")

                # Count how many times we've already nudged the model to fix the format. These nudges are
                # appended as HumanMessage below (they contain the format-correction marker), so count those.
                error_count = sum(
                    1
                    for m in state["messages"]
                    if isinstance(m, HumanMessage)
                    and (
                        "no tags in the current response" in m.content
                        or "did not contain the required XML tags" in m.content
                    )
                )

                if error_count >= 2:
                    # If we've already tried to correct the model twice, just end the conversation
                    print("Detected repeated parsing errors, ending conversation")
                    state["next_step"] = "end"
                    # Add a final message explaining the termination
                    state["messages"].append(
                        AIMessage(
                            content="Execution terminated due to repeated parsing errors. Please check your input and try again."
                        )
                    )
                else:
                    # Try to correct it with a clearer, more explicit prompt
                    state["messages"].append(
                        HumanMessage(
                            content=(
                                "Your previous response did not contain the required XML tags. "
                                "You MUST respond with EXACTLY ONE of the following formats:\n\n"
                                "Option 1 - to run code:\n"
                                "<execute>\n"
                                "your python/bash code here\n"
                                "</execute>\n\n"
                                "Option 2 - to give final answer:\n"
                                "<solution>\n"
                                "your final answer here\n"
                                "</solution>\n\n"
                                "Do NOT include any text outside these tags. "
                                "Do NOT explain. Just output the tags with content. "
                                "Please regenerate your response now."
                            )
                        )
                    )
                    state["next_step"] = "generate"
            return state

        def execute(state: AgentState) -> AgentState:
            last_message = state["messages"][-1].content
            # Only add the closing tag if it's not already there
            if "<execute>" in last_message and "</execute>" not in last_message:
                last_message += "</execute>"

            execute_match = re.search(r"<execute>(.*?)</execute>", last_message, re.DOTALL)
            if execute_match:
                code = self._sanitize_execute_code(execute_match.group(1))
                execution_rationale = last_message[: execute_match.start()].strip()

                # Set timeout duration (10 minutes = 600 seconds)
                timeout = self.timeout_seconds

                # Check if the code is R code
                if (
                    code.strip().startswith("#!R")
                    or code.strip().startswith("# R code")
                    or code.strip().startswith("# R script")
                ):
                    # Remove the R marker and run as R code
                    r_code = re.sub(r"^#!R|^# R code|^# R script", "", code, count=1).strip()
                    result = run_with_timeout(
                        run_r_code,
                        [r_code],
                        {"show_progress": True, "rationale": execution_rationale},
                        timeout=timeout,
                    )
                # Check if the code is a Bash script or CLI command
                elif (
                    code.strip().startswith("#!BASH")
                    or code.strip().startswith("# Bash script")
                    or code.strip().startswith("#!CLI")
                ):
                    # Handle both Bash scripts and CLI commands with the same function
                    if code.strip().startswith("#!CLI"):
                        # For CLI commands, extract the command and run it as a simple bash script
                        cli_command = re.sub(r"^#!CLI", "", code, count=1).strip()
                        # Remove any newlines to ensure it's a single command
                        cli_command = cli_command.replace("\n", " ")
                        result = run_with_timeout(
                            run_bash_script,
                            [cli_command],
                            {"show_progress": True, "rationale": execution_rationale},
                            timeout=timeout,
                        )
                    else:
                        # For Bash scripts, remove the marker and run as a bash script
                        bash_script = re.sub(r"^#!BASH|^# Bash script", "", code, count=1).strip()
                        result = run_with_timeout(
                            run_bash_script,
                            [bash_script],
                            {"show_progress": True, "rationale": execution_rationale},
                            timeout=timeout,
                        )
                # Otherwise, run as Python code
                else:
                    # Clear any previous plots before execution
                    self._clear_execution_plots()

                    # Inject custom functions into the Python execution environment
                    self._inject_custom_functions_to_repl()
                    result = run_with_timeout(run_python_repl, [code], timeout=timeout)

                    # Plots are now captured directly in the execution entry above

                if not isinstance(result, str):
                    result = str(result)
                if len(result) > 10000:
                    result = (
                        "The output is too long to be added to context. Here are the first 10K characters...\n"
                        + result[:10000]
                    )

                # Store the execution result with the triggering message
                if not hasattr(self, "_execution_results"):
                    self._execution_results = []

                # Get any plots that were generated during this execution
                execution_plots = []
                try:
                    from microbiome.tool.support_tools import get_captured_plots

                    current_plots = get_captured_plots()
                    execution_plots = current_plots.copy()
                except Exception as e:
                    print(f"Warning: Could not capture plots from execution: {e}")
                    execution_plots = []

                # Store the execution result with metadata
                execution_entry = {
                    "triggering_message": last_message,  # The AI message that contained <execute>
                    "images": execution_plots,  # Base64 encoded images from this execution
                    "timestamp": datetime.now().isoformat(),
                    "code": (code or "")[:8000],  # The exact payload that ran
                    "failed": self._observation_failed(result),  # Real outcome verdict
                }
                self._execution_results.append(execution_entry)
                self._record_execution_ledger(code, execution_entry["failed"], result)

                observation = f"{self.TOOL_OBSERVATION_MARKER}\n<observation>{result}</observation>"
                observation += self._failure_hint(result)
                observation += self._environment_repair_note(result)
                observation += self._output_dir_repair_note(code, result)
                observation += self._software_memory_note(code, result)
                state["messages"].append(HumanMessage(content=observation))

            return state

        def routing_function(
            state: AgentState,
        ) -> Literal["execute", "generate", "end"]:
            next_step = state.get("next_step")
            if next_step == "execute":
                return "execute"
            elif next_step == "generate":
                return "generate"
            elif next_step == "end":
                return "end"
            else:
                raise ValueError(f"Unexpected next_step: {next_step}")

        def routing_function_self_critic(
            state: AgentState,
        ) -> Literal["generate", "end"]:
            next_step = state.get("next_step")
            if next_step == "generate":
                return "generate"
            elif next_step == "end":
                return "end"
            else:
                raise ValueError(f"Unexpected next_step: {next_step}")

        def execute_self_critic(state: AgentState) -> AgentState:
            if self.critic_count < test_time_scale_round:
                # Generate feedback based on message history
                messages = state["messages"]
                feedback_prompt = f"""
                Here is a reminder of what is the user requested: {self.user_task}
                Examine the previous executions, reaosning, and solutions.
                Critic harshly on what could be improved?
                Be specific and constructive.
                Think hard what are missing to solve the task.
                No question asked, just feedbacks.
                """
                feedback = self.llm.invoke(messages + [HumanMessage(content=feedback_prompt)])

                # Add feedback as a new message
                state["messages"].append(
                    HumanMessage(
                        content=f"Wait... this is not enough to solve the task. Here are some feedbacks for improvement:\n{feedback.content}"
                    )
                )
                self.critic_count += 1
                state["next_step"] = "generate"
            else:
                state["next_step"] = "end"

            return state

        # Create the workflow
        workflow = StateGraph(AgentState)

        # Add nodes
        workflow.add_node("generate", generate)
        workflow.add_node("execute", execute)

        if self_critic:
            workflow.add_node("self_critic", execute_self_critic)
            # Add conditional edges
            workflow.add_conditional_edges(
                "generate",
                routing_function,
                path_map={
                    "execute": "execute",
                    "generate": "generate",
                    "end": "self_critic",
                },
            )
            workflow.add_conditional_edges(
                "self_critic",
                routing_function_self_critic,
                path_map={"generate": "generate", "end": END},
            )
        else:
            # Add conditional edges
            workflow.add_conditional_edges(
                "generate",
                routing_function,
                path_map={"execute": "execute", "generate": "generate", "end": END},
            )
        workflow.add_edge("execute", "generate")
        workflow.add_edge(START, "generate")

        # Compile the workflow
        self.app = workflow.compile()
        self.checkpointer = MemorySaver()
        self.app.checkpointer = self.checkpointer
        # display(Image(self.app.get_graph().draw_mermaid_png()))

    def _prepare_resources_for_retrieval(self, prompt):
        """Prepare resources for retrieval and return selected resource names.

        Args:
            prompt: The user's query

        Returns:
            dict: Dictionary containing selected resource names for tools, data_lake, and libraries
        """
        if not self.use_tool_retriever:
            return None

        # Gather all available resources
        # 1. Tools from the registry
        all_tools = self.tool_registry.tools if hasattr(self, "tool_registry") else []

        # 2. Data lake items with descriptions
        data_lake_path = self.path + "/data_lake"
        data_lake_content = glob.glob(data_lake_path + "/*")
        data_lake_items = [x.split("/")[-1] for x in data_lake_content]

        # Create data lake descriptions for retrieval
        data_lake_descriptions = []
        for item in data_lake_items:
            description = self.data_lake_dict.get(item, f"Data lake item: {item}")
            data_lake_descriptions.append({"name": item, "description": description})

        # Add custom data items to retrieval if they exist
        if hasattr(self, "_custom_data") and self._custom_data:
            for name, info in self._custom_data.items():
                data_lake_descriptions.append({"name": name, "description": info["description"]})

        # 3. Libraries with descriptions - use library_content_dict directly
        library_descriptions = []
        for lib_name, lib_desc in self.library_content_dict.items():
            library_descriptions.append({"name": lib_name, "description": lib_desc})

        # Add custom software items to retrieval if they exist
        if hasattr(self, "_custom_software") and self._custom_software:
            for name, info in self._custom_software.items():
                # Check if it's not already in the library descriptions to avoid duplicates
                if not any(lib["name"] == name for lib in library_descriptions):
                    library_descriptions.append({"name": name, "description": info["description"]})

        # 4. Know-how documents
        know_how_summaries = self.know_how_loader.get_document_summaries()

        # Use retrieval to get relevant resources
        resources = {
            "tools": all_tools,
            "data_lake": data_lake_descriptions,
            "libraries": library_descriptions,
            "know_how": know_how_summaries,
        }

        # Use prompt-based retrieval with the agent's LLM
        selected_resources = self.retriever.prompt_based_retrieval(prompt, resources, llm=self.llm)
        print("\n" + "=" * 60)
        print("🔍 RESOURCE RETRIEVAL")
        print("=" * 60)
        print("Using prompt-based retrieval with the agent's LLM")

        # Extract the names from the selected resources for the system prompt
        selected_resources_names = {
            "tools": selected_resources["tools"],
            "data_lake": [],
            "libraries": [lib["name"] if isinstance(lib, dict) else lib for lib in selected_resources["libraries"]],
            "know_how": [],
        }

        # Process data lake items to extract just the names
        for item in selected_resources["data_lake"]:
            if isinstance(item, dict):
                selected_resources_names["data_lake"].append(item["name"])
            elif isinstance(item, str) and ": " in item:
                # If the item already has a description, extract just the name
                name = item.split(": ")[0]
                selected_resources_names["data_lake"].append(name)
            else:
                selected_resources_names["data_lake"].append(item)

        # Process know-how documents - get the full content for selected documents
        if "know_how" in selected_resources and selected_resources["know_how"]:
            print("\n📚 Know-How Documents Retrieved:")
            for item in selected_resources["know_how"]:
                if isinstance(item, dict):
                    doc_id = item["id"]
                    doc = self.know_how_loader.get_document_by_id(doc_id)
                    if doc:
                        print(f"  ✓ {doc['name']}")
                        # Create a copy with content_without_metadata for agent context
                        doc_for_agent = {
                            "id": doc["id"],
                            "name": doc["name"],
                            "description": doc["description"],
                            "content": doc["content_without_metadata"],  # Use stripped version for agent
                            "metadata": doc["metadata"],
                        }
                        selected_resources_names["know_how"].append(doc_for_agent)
        else:
            print("\n📚 Know-How: None retrieved for this query")

        # Print summary of what was retrieved
        print("\n" + "-" * 60)
        print("📊 RETRIEVAL SUMMARY:")
        print(f"  🔧 Tools: {len(selected_resources_names['tools'])} selected")
        print(f"  📊 Data Lake: {len(selected_resources_names['data_lake'])} selected")
        print(f"  ⚙️  Libraries: {len(selected_resources_names['libraries'])} selected")
        print(f"  📚 Know-How: {len(selected_resources_names['know_how'])} selected")
        print("=" * 60 + "\n")

        return selected_resources_names

    def _reset_planning_session(self):
        """Clear the plan gate so the next user request starts a new task."""
        self.awaiting_plan_confirmation = False
        self.awaiting_resource_preparation = False
        self.awaiting_full_confirmation = False
        self.production_state = "NEW"
        self._pending_task = None
        self._pending_plan = None
        self._direct_answer = None
        self._pending_missing_databases = []
        self._pending_database_acquisitions = []
        self._pending_data_acquisitions = []
        # Deterministic input-source resolution state (local-first).
        self._input_resolution = None
        self._input_manifest_path = None
        self._input_summary = ""
        self._local_input_confirmed = False
        self._allow_sra_download = True
        self._sra_user_confirmed = False
        self._input_summary_injected = False
        self._sra_decline_injected = False
        self._pilot_summary = ""
        self._pilot_playbook = ""
        self._acquisition_only_completed = False
        self._execution_phase = None
        self._planning_history = []
        self._production_controller = None
        # 交互式下载确认门状态：暂停中标志、待确认清单、询问文案、用户已运行时批准的 token
        self.awaiting_download_confirmation = False
        self._pending_download_items = []
        self._pending_download_notice = ""
        self._runtime_approved_downloads = set()
        # A task just finished; the next turn starts a fresh transcript. The existing
        # `_conversation_turns` are deliberately preserved so a call to
        # save_conversation_history() after completion still renders the full history.
        self._task_cycle_complete = True

    def _record_conversation_turn(self, role: str, content: str) -> None:
        """Append one (role, content) pair to the durable turn transcript.

        The transcript is the source of truth for Markdown/PDF conversation history.
        It is kept separate from `self.log` (a flat list of strings) and from the
        planning-only `_planning_history`, so the renderer always has user turns and
        agent replies in order, regardless of which internal branch produced them.
        """
        turns = getattr(self, "_conversation_turns", None)
        if turns is None:
            self._conversation_turns = []
        if not isinstance(content, str) or not content.strip():
            return
        self._conversation_turns.append({"role": role, "content": content})

    def _ensure_planning_session(self):
        """Initialize planning fields for older/deserialized A1 instances."""
        if not hasattr(self, "awaiting_plan_confirmation") or not hasattr(self, "awaiting_full_confirmation"):
            self._reset_planning_session()
        elif not hasattr(self, "awaiting_resource_preparation"):
            self.awaiting_resource_preparation = False
        if not hasattr(self, "awaiting_download_confirmation"):
            self.awaiting_download_confirmation = False
            self._pending_download_items = []
            self._pending_download_notice = ""
            self._runtime_approved_downloads = set()
        if not hasattr(self, "_direct_answer"):
            self._direct_answer = None
        if not hasattr(self, "production_state"):
            self.production_state = "NEW"
        if not hasattr(self, "_production_controller"):
            self._production_controller = None
        # Backfill input-source resolution state for deserialized/older instances.
        for attr, default in (
            ("_input_resolution", None),
            ("_input_manifest_path", None),
            ("_input_summary", ""),
            ("_local_input_confirmed", False),
            ("_allow_sra_download", True),
            ("_sra_user_confirmed", False),
            ("_input_summary_injected", False),
            ("_sra_decline_injected", False),
        ):
            if not hasattr(self, attr):
                setattr(self, attr, default)

    @staticmethod
    def is_execution_confirmation(text: str) -> bool:
        """Return True only for an explicit, unambiguous execution confirmation."""
        if not isinstance(text, str):
            return False

        lowered = text.strip().lower()
        if not lowered:
            return False
        negative_markers = ("不要", "不执行", "没有确认", "未确认", "先别", "取消", "do not", "don't", "not yet")
        if any(marker in lowered for marker in negative_markers):
            return False

        compact = re.sub(r"[\s，。！？、；：,.!?;:'\"`]+", "", lowered)
        chinese_confirmations = {
            "确认执行",
            "确认并执行",
            "方案确认",
            "方案确认开始执行",
            "按此方案执行",
            "按照此方案执行",
            "同意执行",
            "开始执行",
            "可以开始执行",
            "请开始执行",
        }
        if compact in chinese_confirmations:
            return True

        english = re.sub(r"[^a-z]+", " ", lowered).strip()
        return english in {
            "confirm execution",
            "execute the plan",
            "proceed with execution",
            "start execution",
            "approved execute",
        }

    @staticmethod
    def is_full_execution_confirmation(text: str) -> bool:
        """Recognize explicit authorization to leave the verified pilot and run all data."""
        from microbiome.pipeline.approval import ProductionApprovalManager, ProductionIntent

        return ProductionApprovalManager.classify_intent(text) is ProductionIntent.APPROVE_PRODUCTION

    def _find_pipeline_project(self):
        """Locate the strict pipeline project bound to this session, if any."""
        candidates = []
        # Prefer the agent's own bound path over a possibly-stale global env var;
        # real runs fall through to MICROBIOME_RESULTS_DIR when self.path is the data
        # directory rather than a project root.
        if getattr(self, "path", None):
            candidates.append(Path(self.path) / "project_config.yaml")
        results_root = os.environ.get("MICROBIOME_RESULTS_DIR")
        if results_root:
            candidates.append(Path(results_root) / "project_config.yaml")
        for config_path in candidates:
            if not config_path.is_file():
                continue
            try:
                from microbiome.pipeline.project import PipelineProject

                project = PipelineProject(config_path.resolve().parent)
                if project.lifecycle_state_path.is_file():
                    return project
            except (OSError, RuntimeError, ValueError):
                continue
        return None

    def _get_production_controller(self):
        """Load the deterministic controller without exposing its CLI to users.

        This only ever loads an existing, validated pipeline lock. Freezing is
        the finalizer's job and happens at the end of a passed pre-test, never
        on demand at summary/confirmation time.
        """
        configured = getattr(self, "_production_controller", None)
        if configured is not None:
            return configured
        project = self._find_pipeline_project()
        if project is None or not project.pipeline_lock_path.is_file():
            return None
        try:
            from microbiome.pipeline.approval import ProductionController

            self._production_controller = ProductionController(project)
            return self._production_controller
        except (OSError, RuntimeError, ValueError):
            return None

    def _record_execution_ledger(self, code: str, failed: bool, result: str) -> None:
        """Append one structured fact about this real execution to the ledger.

        The ledger is written during the pre-test itself; it must never depend
        on later reconstruction from playbooks or chat logs. Telemetry failures
        must not break the conversational run, so recording is best-effort.
        """
        phase = getattr(self, "_execution_phase", None)
        if phase not in {"pilot", "full"}:
            return
        if _is_marker_print(code or ""):
            # Pure control-marker commands are not analysis facts; they must not
            # become replayable production steps.
            return
        root_value = os.environ.get("MICROBIOME_RESULTS_DIR") or getattr(self, "path", None)
        if not root_value:
            return
        try:
            from microbiome.pipeline.ledger import ExecutionLedger, infer_command_facts

            results_root = Path(root_value)
            ledger = ExecutionLedger(results_root / "pre_test_run" / "pipeline" / "execution_ledger.jsonl")
            facts = infer_command_facts(
                code or "",
                raw_root=os.environ.get("MICROBIOME_DATA_DIR"),
                db_root=os.environ.get("MICROBIOME_DB_ROOT"),
                output_root=os.environ.get("MICROBIOME_RESULTS_DIR"),
            )
            exit_code = _extract_exit_code(result or "")
            if exit_code is None:
                # Fall back to the observation verdict so the evidence validator
                # still sees a real process exit signal (0 vs non-zero).
                exit_code = 1 if failed else 0
            ledger.record(
                phase=phase,
                source="agent-react",
                status="FAILED" if failed else "PASSED",
                command={"kind": facts["kind"], "code": (code or "")[:4000]},
                tool={"name": facts["tool_name"], "version": None, "executable": facts["executable"]},
                environment={"conda_prefix": facts["conda_prefix"], "conda_env": facts["conda_env"]},
                inputs=facts["inputs"],
                outputs=facts["outputs"],
                database_resources=facts["database_resources"],
                exit_code=exit_code,
                output_validation={"passed": not failed, "detail": "agent observation verdict"},
                error_excerpt=(result or "")[-500:] if failed else "",
            )
        except Exception:
            pass

    def _record_analysis_experience(self, outcome: str, summary: str = "") -> None:
        """Record this task's workflow as reusable analysis experience.

        Best-effort and deduplicated per (phase, outcome): a persistence error
        must never break the conversational run, and re-entrant message builders
        must not append duplicate records.
        """
        try:
            from microbiome.analysis_experience import record_experience

            task = getattr(self, "_pending_task", "") or ""
            workflow = getattr(self, "_pending_plan", "") or ""
            if not task or not workflow:
                return
            phase = getattr(self, "_execution_phase", "") or ""
            key = f"{phase}:{outcome}"
            recorded = getattr(self, "_analysis_experiences_recorded", None)
            if recorded is None:
                recorded = set()
                self._analysis_experiences_recorded = recorded
            if key in recorded:
                return
            record_experience(task, workflow, outcome, summary=summary, phase=phase)
            recorded.add(key)
        except Exception:
            pass

    def _production_validation_summary(self) -> str:
        controller = self._get_production_controller()
        if controller is not None:
            try:
                return controller.approvals.render_validation_summary()
            except Exception:
                pass
        validation_root = Path(os.environ.get("MICROBIOME_RESULTS_DIR", ".")) / "pre_test_run"
        playbook_path = Path(os.environ.get("MICROBIOME_RESULTS_DIR", ".")) / "pilot_playbook.md"
        return "\n".join(
            [
                "[microbiome-run] 小数据验证完成 / Pilot validation complete",
                "",
                "已完成端到端小数据分析并通过真实输出验收。\nThe end-to-end pilot analysis is complete and accepted based on real output.",
                "验证结果：✓ 通过 / Validation result: ✓ Passed",
                f"验证记录目录：{validation_root} / Validation record directory: {validation_root}",
                f"详细执行记录：{playbook_path} / Detailed execution record: {playbook_path}",
                "",
                "全量分析将沿用小试验证成功的软件、环境、数据库、参数、命令结构和流程顺序。\nThe full run will reuse the software, environments, databases, parameters, command structure, and workflow order validated by the pilot.",
                "全量输入会重新绑定到 RAW_DATA_PATH 下的完整原始数据，不会使用 pre_test_run/input_subset。\nFull inputs will be re-bound to the complete raw data under RAW_DATA_PATH, not pre_test_run/input_subset.",
                "本阶段不会重新安装软件、下载数据库、选择软件或修改科学参数。\nThis stage will not reinstall software, download databases, select software, or change scientific parameters.",
                "",
                "是否开始使用全部原始数据进行正式分析？\nShall we start the formal analysis using all the raw data?",
                "可回复“确认全量执行”“开始跑全部数据”或“继续全量分析”。\nYou can reply “确认全量执行”, “开始跑全部数据”, or “继续全量分析” to proceed.",
                "暂不运行或需要修改方案也可以直接说明。\nYou may also tell us if you prefer not to run now or need to modify the plan.",
            ]
        )

    @staticmethod
    def _is_resource_acquisition_only_task(task: str, resource_ids: list[str]) -> bool:
        """Return whether the confirmed goal contains data acquisition but no current analysis."""
        if not resource_ids or not isinstance(task, str):
            return False
        primary_intent = re.split(
            r"(?:用于后续|供后续|以便后续|for\s+(?:later|downstream)\b)",
            task.casefold(),
            maxsplit=1,
        )[0]
        acquisition = re.search(
            r"(?:下载|获取|拉取|本地化|准备|download|retrieve|fetch|acquire|locali[sz]e|prepare|get\b)",
            primary_intent,
        )
        analysis = re.search(
            r"(?:分析|比对|组装|注释|建树|系统发育|质控|分箱|分类|预测|鉴定|筛选|可视化|统计|"
            r"定量|检测|变异|进化|聚类|analy[sz]|align|assembl|annotat|phylogen|quality\s+control|"
            r"binning|classif|predict|visuali[sz]|quantif|variant|cluster|mapping)",
            primary_intent,
        )
        return bool(acquisition and not analysis)

    @classmethod
    def _execution_is_authorized(cls, messages: list[BaseMessage]) -> bool:
        """Require an internal marker or a prior plan followed by confirmation."""
        for message in messages:
            if isinstance(message, HumanMessage) and "[MICROBIOME_PLAN_CONFIRMED]" in cls._message_text(message):
                return True

        has_prior_plan = any(isinstance(message, AIMessage) and cls._message_text(message) for message in messages)
        has_confirmation = any(
            isinstance(message, HumanMessage) and cls.is_execution_confirmation(cls._message_text(message))
            for message in messages
        )
        return has_prior_plan and has_confirmation

    @staticmethod
    def _normalize_code_fence_response(text: str) -> str:
        """Convert a standalone Markdown code fence into executable XML."""
        if "<execute>" in text.lower() or "<solution>" in text.lower():
            return text
        match = re.search(r"```([A-Za-z0-9_+-]*)\s*\n?(.*?)```", text, re.DOTALL)
        if not match:
            return text

        language = match.group(1).lower()
        code = match.group(2).strip()
        if language in ("bash", "sh", "shell") and not code.startswith("#!BASH"):
            code = f"#!BASH\n{code}"
        elif language == "r" and not code.startswith("#!R"):
            code = f"#!R\n{code}"

        prefix = text[: match.start()].strip()
        suffix = text[match.end() :].strip()
        parts = [part for part in (prefix, f"<execute>{code}</execute>", suffix) if part]
        return "\n".join(parts)

    @staticmethod
    def _sanitize_execute_code(code: str) -> str:
        """Strip Markdown fences / stray language tags from an <execute> payload.

        Local models often wrap the payload in ```bash / ```python fences or leave a
        bare ``bash``/``python`` tag line. Left in place, those fragments crash the
        Python REPL with ``invalid syntax (<string>, line 2)``. Returns cleaned code,
        routing shell/R payloads through the #!BASH / #!R markers the executor expects.
        """
        text = (code or "").strip()
        language = ""
        for _ in range(3):
            match = re.match(r"^```([A-Za-z0-9_+-]*)[ \t]*\n?(.*?)\n?```$", text, re.DOTALL)
            if not match:
                break
            language = language or match.group(1).strip().lower()
            text = match.group(2).strip()
        # Bare language-tag line left by a broken fence (e.g. "python\nimport os...").
        first_line, _, rest = text.partition("\n")
        tag = first_line.strip().lower()
        if rest.strip() and tag in ("python", "python3", "bash", "sh", "shell", "zsh", "r"):
            language = language or tag
            text = rest.strip()
        # Standard shebang (#!/bin/bash, #!/usr/bin/env bash, #!/bin/sh) -> #!BASH.
        if _BASH_SHEBANG_RE.match(text):
            language = "bash"
            text = _BASH_SHEBANG_RE.sub("", text, count=1).lstrip("\n")
        if not text.startswith(("#!BASH", "#!CLI", "#!R", "# Bash script", "# R code", "# R script")):
            if language in ("bash", "sh", "shell", "zsh", "cli"):
                text = f"#!BASH\n{text}"
            elif language == "r":
                text = f"#!R\n{text}"
        text = A1._normalize_code_text(text)
        return text

    @staticmethod
    def _normalize_code_text(text: str) -> str:
        """Normalize LLM code output that degrades over long conversations.

        Chinese-context models (e.g. deepseek-chat) increasingly emit fullwidth
        ASCII punctuation (｜ ＜ ＞ ＝ （ ） …) into generated code, and collapse
        repeated ``</execute>`` closing tags into garbage runs such as
        ``</\u200b></\u200b>…`` or ``</||DSML||></||DSML||>…``. All of these are
        always corrupting in code, so convert the fullwidth forms to ASCII and
        truncate at the first closing-tag corruption signature. ``</`` followed by
        a non-whitespace, non-slash byte is never produced by the valid pipelines
        (they use ``<<`` heredocs, not ``< /path`` input redirection), so it is a
        safe truncation point.
        """
        text = str(text or "")
        text = text.translate(_FULLWIDTH_TO_ASCII)
        cut = text.find("\u200b")
        if cut != -1:
            text = text[:cut]
        match = re.search(r"</[^ \t\n/]", text)
        if match is not None:
            text = text[: match.start()]
        return text.strip()

    @staticmethod
    def _observation_texts(messages: list[BaseMessage]) -> list[str]:
        observations = []
        for message in messages:
            content = A1._message_text(message)
            match = re.search(r"<observation>(.*?)</observation>", content, re.DOTALL | re.IGNORECASE)
            if match:
                observations.append(match.group(1).strip())
        return observations

    @staticmethod
    def _observation_failed(observation: str) -> bool:
        lowered = observation.lower()
        failure_patterns = (
            "traceback (most recent call last)",
            "command not found",
            "no such file or directory",
            "permission denied",
            "timed out",
            "timeout:",
            "## error",
            "error:",
            "exception:",
            "fatal:",
            "unrecognized option",
            "invalid option",
            "illegal option",
            "unrecognized arguments",
            "segmentation fault",
            "core dumped",
            "cannot allocate memory",
            "out of memory",
            "error while loading shared libraries",
            "not a conda environment",
            "environmentlocationnotfound",
            "could not find conda environment",
            "no such environment",
        )
        if any(pattern in lowered for pattern in failure_patterns):
            return True
        return bool(re.search(r"(?:exit|return)\s*code:?\s*[1-9]\d*", lowered)) or bool(
            re.search(r"\bfailed(?:\s|$)", lowered)
        )

    @classmethod
    def _phase_verification(
        cls,
        messages: list[BaseMessage],
        observations: list[str],
        phase: str,
        execution_results: list[dict],
    ) -> tuple[bool, str]:
        """Decide whether an execution phase was factually verified.

        The literal marker is the primary signal. When it is missing we fall back
        to real execution facts — at least one successful command and a successful
        final command — so a local model that forgets the marker does not strand an
        otherwise-successful pilot/full run.
        """
        marker = cls.PILOT_VERIFIED_MARKER if phase == "pilot" else cls.RESULT_VERIFIED_MARKER
        if any(marker in observation for observation in observations):
            return True, ""
        if any(marker in cls._message_text(message) for message in messages):
            return True, "验收标记出现在非 observation 文本中 / Verification marker appears outside observation text"
        results = list(execution_results or [])
        if not results:
            return False, ""
        any_success = any(not bool(entry.get("failed")) for entry in results)
        last_success = not bool(results[-1].get("failed"))
        if any_success and last_success:
            return True, (
                "未打印验收标记，但本阶段至少一条命令成功执行且最后一条命令也成功；"
                "已按真实执行记录判定通过\n"
                "The verification marker was not printed, but at least one command succeeded and the final command also succeeded; "
                "judged as passed based on the real execution record"
            )
        return False, ""

    @classmethod
    def _failure_hint(cls, observation: str) -> str:
        """Remediation guidance appended to a failed observation ('' when it did not fail)."""
        if not observation or not cls._observation_failed(observation):
            return ""
        return (
            "\n执行自愈要求：上一条命令失败。禁止停止、禁止返回最终答案、禁止原样重复同一条命令；"
            "按以下方向定位并修复（允许安装缺失软件、创建或修复 conda 环境、修正路径/参数），"
            "然后立即用下一条 <execute> 重试并验证：\n"
            "Execution self-healing requirement: the previous command failed. Do not stop, do not return a final answer, "
            "and do not repeat the same command verbatim; diagnose and fix it (you may install missing software, create or "
            "repair a conda environment, or correct paths/parameters), then immediately retry and verify with the next <execute>:\n"
            + cls._pilot_fix_suggestions(observation)
        )

    _ENV_MISSING_MARKERS = (
        "environmentlocationnotfound",
        "not a conda environment",
        "could not find conda environment",
        "no such environment",
        "environment does not exist",
        "prefix does not exist",
    )
    _ENV_PATH_NAME_RE = re.compile(r"/envs/([a-zA-Z0-9_.-]+)")
    _ENV_NAMED_RE = re.compile(r"conda environment:\s*['\"]?([a-zA-Z0-9_.-]+)", re.IGNORECASE)
    _ENV_REPAIR_BUDGET = 2  # per-environment automatic rebuild attempts per session

    def _environment_repair_note(self, observation: str) -> str:
        """Deterministically rebuild the conda environment a failed command referenced.

        执行阶段自愈钩子：当观测里出现 `EnvironmentLocationNotFound` 等"环境不存在或
        已损坏"签名时，不再依赖模型自己摸索安装——直接把环境名映射回注册的 software
        skill，调用 SoftwareEnvironmentRunner.ensure() 重建并验证，然后把回执写进
        观测，让模型立即用绝对前缀 `conda run -p <prefix>` 重试原命令。
        每个环境每个会话最多自动重建 _ENV_REPAIR_BUDGET 次，防止死循环。永不抛异常。
        """

        try:
            if not observation:
                return ""
            lowered = observation.lower()
            if not any(marker in lowered for marker in self._ENV_MISSING_MARKERS):
                return ""
            if getattr(self, "_execution_phase", None) == "full":
                return (
                    "\n检测到生产环境漂移。全量执行不得创建、修复或更新环境；停止受影响分支，"
                    "返回 repair-validation 模式，验证后冻结新的 pipeline 版本。\n"
                    "Production environment drift detected. The full run must not create, repair, or update environments; "
                    "stop the affected branch, return to repair-validation mode, and freeze a new pipeline version after validation."
                )
            names: list[str] = []
            for match in [*self._ENV_PATH_NAME_RE.findall(observation), *self._ENV_NAMED_RE.findall(observation)]:
                if match not in names and match.lower() not in {"base", "root"}:
                    names.append(match)
            if not names:
                return ""
            hint = (
                "\n环境自愈：上一条命令引用的 conda 环境不存在或已损坏。"
                "修复后请用绝对前缀形式 `conda run -p <prefix> --no-capture-output ...` 重试原命令"
                "（避免按名 -n 在不同 conda 根之间解析失败）。\n"
                "Environment self-healing: the conda environment referenced by the previous command is missing or broken. "
                "After repairing it, retry the original command with the absolute-prefix form "
                "`conda run -p <prefix> --no-capture-output ...` (avoid -n name resolution failing across different conda roots)."
            )
            registry = getattr(self, "resource_skill_registry", None)
            if registry is None or not getattr(self, "auto_install", True):
                return (
                    hint + "当前未启用自动环境安装：请执行 `mamba create -y -n <env> -c conda-forge -c bioconda <包>` "
                    "创建后重试。\n"
                    "Automatic environment installation is currently disabled: create it with "
                    "`mamba create -y -n <env> -c conda-forge -c bioconda <包>` and retry."
                )
            if not hasattr(self, "_session_env_repairs"):
                self._session_env_repairs = {}
            notes = [hint]
            for name in names[:2]:
                attempts = self._session_env_repairs.get(name, 0)
                if attempts >= self._ENV_REPAIR_BUDGET:
                    notes.append(
                        f"- {name}: 本会话已自动重建 {self._ENV_REPAIR_BUDGET} 次仍未成功，停止重复重建；"
                        "请检查镜像源/网络/磁盘后手动创建，再继续任务。\n"
                        f"- {name}: automatic rebuild has already failed {self._ENV_REPAIR_BUDGET} times this session; "
                        "stopping repeated rebuilds. Check the mirror/network/disk and create it manually before continuing."
                    )
                    continue
                skills = [
                    skill
                    for skill in registry.list_skills("software")
                    if str(skill.metadata.get("environment") or "") == name
                ]
                if not skills:
                    notes.append(
                        (
                            f"- {name}: 注册表中没有声明该环境的软件 skill，无法确定性重建；"
                            "按方案声明的包用 `mamba create -y -n {0} -c conda-forge -c bioconda <包>` 创建后重试。\n"
                            "- {0}: no software skill declares this environment in the registry, so it cannot be rebuilt "
                            "deterministically; create it with `mamba create -y -n {0} -c conda-forge -c bioconda <包>` "
                            "using the packages declared in the plan, then retry."
                        ).format(name)
                    )
                    continue
                self._session_env_repairs[name] = attempts + 1
                runner = SoftwareEnvironmentRunner(
                    registry,
                    project_root=Path(__file__).resolve().parents[2],
                    timeout_seconds=max(int(getattr(self, "timeout_seconds", 3600)), 7200),
                )
                result = runner.ensure(skills[0].skill_id)
                if result.success:
                    prefix = (getattr(registry, "environment_catalog", None) or {}).get(name, f".../envs/{name}")
                    notes.append(
                        f"- {name}: 环境已自动重建并验证可用（skill: {skills[0].skill_id}）。"
                        f"现在用 `conda run -p {prefix} --no-capture-output ...` 重试刚才失败的原命令。\n"
                        f"- {name}: the environment was rebuilt and verified (skill: {skills[0].skill_id}). "
                        f"Now retry the previously failed command with `conda run -p {prefix} --no-capture-output ...`."
                    )
                else:
                    notes.append(
                        f"- {name}: 自动重建失败（{result.error or result.status}）。"
                        "请根据该错误修复镜像源/网络后重试创建，不要直接重跑会再次失败的原命令。\n"
                        f"- {name}: automatic rebuild failed ({result.error or result.status}). Fix the mirror/network "
                        "according to that error and retry the creation; do not directly re-run the original command, which would fail again."
                    )
            return "\n".join(notes)
        except Exception:
            return ""  # 自愈钩子绝不能影响正常执行

    _OUTPUT_DIR_EXISTS_RE = re.compile(
        r"output\s+directory\s+['\"]?(\S+?)['\"]?\s+already\s+exists", re.IGNORECASE
    )
    _OUTPUT_DIR_REMOVE_BUDGET = 3

    def _output_dir_repair_note(self, code: str, observation: str) -> str:
        """Deterministically remove a stale assembly output directory on retry.

        megahit/SPAdes refuse to overwrite an existing ``-o`` directory, and the
        model's retry keeps reusing the same (often hardcoded) directory name, so
        the same "Output directory ... already exists" error loops forever. Here we
        extract the exact directory, remove it under strict path safety, and tell
        the model to retry the identical command. Never raises.
        """
        try:
            if not observation or "already exists" not in observation.lower():
                return ""
            match = self._OUTPUT_DIR_EXISTS_RE.search(observation)
            if not match:
                return ""
            path = Path(match.group(1))
            if not path.is_absolute() or not path.is_dir():
                return ""
            resolved = path.resolve()
            # Safety: never touch home/root, system dirs, or resource trees.
            forbidden = {str(Path.home().resolve()), "/", "/home", "/usr", "/etc", "/bin", "/opt"}
            if str(resolved) in forbidden or str(resolved.parent) == "/":
                return ""
            if any(part in resolved.parts for part in ("envs", "Database", "raw", "data_lake", ".git")):
                return ""
            results_root = Path(os.environ.get("MICROBIOME_RESULTS_DIR") or getattr(self, "path", "") or ".").resolve()
            try:
                resolved.relative_to(results_root)
            except ValueError:
                # Still allow assembly-output-looking dirs outside results_root (e.g. out2/),
                # but require an explicit assembly/analysis name to stay safe.
                if not re.search(r"(?:megahit|spades|asm|assembly|contigs|metaspades|rnaspades)", path.name, re.IGNORECASE):
                    return ""
            if not hasattr(self, "_session_removed_output_dirs"):
                self._session_removed_output_dirs = {}
            key = str(resolved)
            attempts = self._session_removed_output_dirs.get(key, 0)
            if attempts >= self._OUTPUT_DIR_REMOVE_BUDGET:
                return (
                    "\n输出目录自愈：该残留目录已自动删除多次但命令仍失败。请更换一个全新的 -o 路径"
                    "（如追加 `_$(date +%s%N)` 后缀）后重试，严禁原样重复同一条命令。\n"
                    "Output-directory self-healing: the stale directory was removed multiple times but the command still failed. "
                    "Use a brand-new -o path (e.g. append a `_$(date +%s%N)` suffix) and retry; never repeat the same command verbatim."
                )
            self._session_removed_output_dirs[key] = attempts + 1
            shutil.rmtree(resolved, ignore_errors=True)
            if resolved.exists():
                return ""
            return (
                f"\n输出目录自愈：已自动删除上一次失败运行的残留输出目录 `{resolved}`。"
                "请用同一条命令重试（该输出目录现已不存在，可正常写入）。\n"
                f"Output-directory self-healing: the stale output directory `{resolved}` from the previous failed run has been removed. "
                "Retry the same command (the output directory no longer exists and can be written normally)."
            )
        except Exception:
            return ""

    def _software_memory_note(self, code: str, observation: str, *, execution_evidence: dict | None = None) -> str:
        """Record failures/successes into per-software memory and surface past learnings.

        On failure: persist the failing command with a classified reason, then attach the
        software's archive (past failures + proven commands + web-search notes) and require
        a web search for the correct usage. On success after a recorded failure: persist the
        working command as the proven fix. Never raises; returns '' when nothing applies.
        """
        try:
            from microbiome import software_memory
        except Exception:
            return ""
        if not software_memory.enabled():
            return ""
        try:
            registry = getattr(self, "resource_skill_registry", None)
            softwares = software_memory.detect_software(code or "", registry=registry)
            failed = self._observation_failed(observation)
            if not hasattr(self, "_session_software_failures"):
                self._session_software_failures = set()
            if failed:
                if not softwares:
                    unknown = software_memory.extract_unknown_executable(observation)
                    softwares = [unknown] if unknown else []
                for software in softwares:
                    software_memory.record_failure(software, code, observation)
                    self._session_software_failures.add(software)
                if not softwares:
                    return ""
                brief = software_memory.memory_brief(softwares)
                query = software_memory.suggest_query(softwares[0], observation)
                names = ", ".join(softwares)
                return (
                    f"\n软件使用记忆（自动学习档案）：本次失败已记入 {names} 的专属档案。\n"
                    + (brief + "\n" if brief else "")
                    + f"学习要求：先用 advanced_web_search_claude 联网检索该软件针对当前任务的正确用法"
                    f'（建议查询："{query}"），结合上方历史记录修正命令；检索结论用 python 执行 '
                    f"from microbiome.software_memory import record_web_note; "
                    f"record_web_note(<软件名>, query=..., summary=...) 写入档案；"
                    "禁止原样重复任何已记录的失败命令。修复并验证成功后，系统会自动把成功命令写入该软件档案。\n"
                    f"Software usage memory (auto-learned archive): this failure has been recorded in the archive for {names}. "
                    "Learning requirement: first search the web with advanced_web_search_claude for the correct usage of this "
                    "software for the current task, fix the command using the history above, and record the search conclusion via "
                    "python with record_web_note(<software>, query=..., summary=...); never repeat any recorded failed command "
                    "verbatim. Once fixed and verified, the system automatically writes the successful command into the archive."
                )
            evidence = execution_evidence or {}
            if not (evidence.get("exit_code") == 0 and evidence.get("output_validation", {}).get("passed") is True
                    and evidence.get("verified") is True and evidence.get("command") == code):
                return ""
            resolved = [sw for sw in softwares if sw in self._session_software_failures]
            historical = [sw for sw in softwares if sw not in resolved and software_memory.has_failure_history(sw)]
            for software in resolved + historical:
                software_memory.record_success(software, code, note="失败后修复验证成功")
                self._session_software_failures.discard(software)
            if resolved:
                return (
                    "\n软件使用记忆：本次成功命令已记入 "
                    + ", ".join(resolved)
                    + " 的专属档案，并标注为对应失败的修复方案，后续任务将直接复用。\n"
                    + "Software usage memory: this successful command has been recorded in the archive for "
                    + ", ".join(resolved)
                    + " and marked as the fix for the corresponding failure; later tasks will reuse it directly."
                )
            return ""
        except Exception:
            return ""  # 记忆系统绝不能影响正常执行

    @staticmethod
    def _execution_command_blocker(
        code: str,
        confirmed_plan: str,
        phase: str = "pilot",
        runtime_approved: frozenset[str] = frozenset(),
        registry=None,
    ) -> str | None:
        """Reject unplanned downloads, persistent activation, and unplanned env creation."""
        lowered = code.lower()
        compact = re.sub(r"\s+", "", lowered)
        approved = ResourceSkillRegistry.planned_database_acquisitions(confirmed_plan)
        approved_ids = {resource_id.partition(":")[0] for resource_id in approved}
        sra_transfer = bool(
            "download_sra_runs(" in compact
            or re.search(r"\bprefetch\b", lowered)
            or re.search(r"\bfasterq-dump\b", lowered)
        )
        if sra_transfer:
            return (
                "SRA 输入数据只能由已确认方案的分阶段数据运行器执行；分析模型不得直接运行 "
                "prefetch、fasterq-dump 或 download_sra_runs，以免越过 accession 和 pilot/full 授权边界。\n"
                "SRA input data may only be handled by the phased data runner of the confirmed plan; the analysis model must not "
                "run prefetch, fasterq-dump, or download_sra_runs directly, to avoid crossing the accession and pilot/full authorization boundary."
            )

        def references_approved_database() -> bool:
            if "reference-genomes" in approved_ids and "download_reference_genome(" in compact:
                return True
            if "reference-sequences" in approved_ids and "download_reference_sequences(" in compact:
                return True
            if "virus-genomes" in approved_ids and (
                "download_virus_genomes(" in compact
                or re.search(r"\bgget\s+virus\b", lowered)
                or re.search(r"\bdatasets\s+download\s+virus\b", lowered)
            ):
                return True
            return any(
                re.search(rf"(?<![a-z0-9]){re.escape(skill_id)}(?![a-z0-9])", lowered)
                or f"database/{skill_id}" in lowered
                for skill_id in approved_ids
            )

        database_acquisition = (
            "download_database(" in compact
            or ("ensure_database(" in compact and "auto_download=false" not in compact)
            or "download_reference_genome(" in compact
            or "download_reference_sequences(" in compact
            or "download_virus_genomes(" in compact
            or bool(re.search(r"\bdownload_database\b", lowered))
            or ("microbiome.resource_skills.acquisition" in lowered and bool(re.search(r"\bdownload\b", lowered)))
            or bool(re.search(r"\bgget\s+ref\b[^\n]*(?:\s-d\b|--download\b)", lowered))
            or bool(re.search(r"\bgget\s+virus\b", lowered))
            or bool(re.search(r"\bdatasets\s+download\b", lowered))
        )
        if database_acquisition and phase == "full":
            return "全量阶段不得新增或更新数据库；数据库获取和本地化必须已在小数据试跑前完成并验证。\nThe full stage must not add or update databases; database acquisition and localization must have been completed and validated before the pilot."
        if database_acquisition:
            # A plan may still carry an acquisition marker for a database that has
            # since become READY (or was READY all along). Never re-download it:
            # reuse the validated local path instead.
            if registry is not None:
                for skill_id in sorted(approved_ids):
                    try:
                        status = registry.database_status(skill_id)
                    except Exception:
                        continue
                    if status.status == "ready":
                        return (
                            f"数据库 {skill_id} 已经是 READY（{status.path}），无需下载。"
                            "直接使用该 READY 路径继续分析，禁止再次运行下载命令。\n"
                            f"Database {skill_id} is already READY ({status.path}); no download needed. "
                            "Continue the analysis directly with that READY path; do not run download commands again."
                        )
        if database_acquisition and not references_approved_database():
            if not downloads_runtime_approved(code, runtime_approved):
                return _UNAUTHORIZED_DOWNLOAD_MSG

        database_terms = (
            "database/",
            "gtdb",
            "swissprot",
            "checkv",
            "genomad",
            "checkm",
            "kraken",
            "card",
            "uniprot_sprot",
        )
        network_download = re.search(r"\b(?:wget|curl|aria2c)\b[^\n]*https?://", lowered) or "requests.get(" in compact
        if network_download and any(term in lowered for term in database_terms) and not references_approved_database():
            if not downloads_runtime_approved(code, runtime_approved):
                return _UNPLANNED_NETWORK_DOWNLOAD_MSG

        generic_transfer = bool(re.search(r"\b(?:wget|curl|aria2c)\b[^\n]*https?://", lowered)) or bool(
            re.search(r"\bdownload_file\s*\(", lowered)
        )
        if generic_transfer and not any(term in lowered for term in database_terms):
            if phase == "full":
                return "全量阶段不得临时新增输入数据下载；输入必须已在试跑阶段下载并验证。\nThe full stage must not add ad-hoc input-data downloads; inputs must have been downloaded and validated during the pilot."
            if not downloads_runtime_approved(code, runtime_approved):
                return _UNPLANNED_DATA_DOWNLOAD_MSG
            download_root = os.path.abspath(
                os.environ.get("MICROBIOME_DOWNLOAD_DIR") or os.environ.get("MICROBIOME_DATA_ROOT") or "./data"
            )
            destination_markers = (
                download_root.lower(),
                "microbiome_download_dir",
                "microbiome_data_root",
            )
            if not any(marker in lowered for marker in destination_markers):
                return (
                    "输入数据下载必须明确写入指定下载目录 "
                    f"{download_root}（或通过 MICROBIOME_DOWNLOAD_DIR/MICROBIOME_DATA_ROOT 获取该目录），"
                    "不得保存到当前工作目录。\n"
                    f"Input-data downloads must be written explicitly to the designated download directory {download_root} "
                    "(or obtained from MICROBIOME_DOWNLOAD_DIR/MICROBIOME_DATA_ROOT); do not save them to the current working directory."
                )

        if re.search(r"\b(?:conda|mamba|micromamba)\s+(?:de)?activate\b", lowered):
            return "禁止持久 activate/deactivate 环境。按软件 skill 使用独立的 conda run -n/-p 命令。\nPersistent activate/deactivate of environments is forbidden; use dedicated conda run -n/-p commands per software skill."

        if phase == "full" and (
            re.search(r"\b(?:conda|mamba|micromamba)\s+(?:install|create|update|remove)\b", lowered)
            or re.search(r"\bpip\s+install\b", lowered)
        ):
            return (
                "全量生产阶段禁止创建、安装、修复或更新环境/软件；检测到漂移后必须停止，"
                "返回 repair-validation 并冻结新的 pipeline 版本。\n"
                "The full production stage forbids creating, installing, repairing, or updating environments/software; "
                "on detected drift you must stop, return to repair-validation, and freeze a new pipeline version."
            )

        # 执行阶段允许自主安装软件、创建/修复独立环境来解决报错（执行期自愈），
        # 只禁止污染 base/当前环境；数据库下载授权和 SRA 边界规则保持不变。
        install_match = re.search(r"\b(?:conda|mamba|micromamba)\s+install\b([^\n]*)", lowered)
        if install_match:
            target_match = re.search(r"(?:-n|--name|-p|--prefix)\s+([^\s]+)", install_match.group(1))
            if not target_match:
                return "软件安装必须用 -n/--name 或 -p/--prefix 明确指定其 skill 环境，禁止安装到当前环境。\nSoftware installation must explicitly target its skill environment via -n/--name or -p/--prefix; installing into the current environment is forbidden."
            target = target_match.group(1).strip("'\"").lower()
            if target in ("base", "root"):
                return "禁止向 base/root 环境安装软件；为该工具创建或复用其 skill 独立环境。\nInstalling software into base/root environments is forbidden; create or reuse the tool's dedicated skill environment."

        if re.search(r"\bpip\s+install\b", lowered) and not re.search(
            r"\b(?:conda|mamba|micromamba)\s+run\b[^\n]*\bpip\s+install\b", lowered
        ):
            return "pip 安装必须通过软件 skill 指定环境的 conda run 执行，禁止修改当前 Python 环境。\npip installs must run through the conda run of the environment specified by the software skill; modifying the current Python environment is forbidden."

        create_match = re.search(
            r"\b(?:conda|mamba|micromamba)\s+(?:env\s+)?create\b[^\n]*(?:-n|--name)\s+([a-z0-9_.-]+)",
            lowered,
        )
        if create_match and create_match.group(1) in ("base", "root"):
            return "禁止重建 base/root 环境；为软件创建独立命名环境。\nRebuilding base/root environments is forbidden; create a dedicated named environment for the software."

        # Software analog of the READY-database re-download guard: never re-create or
        # re-install an environment the registry already has fully ready.
        if registry is not None:
            install_targets = []
            for match in (install_match, create_match):
                if not match:
                    continue
                name_match = re.search(r"(?:-n|--name)\s+['\"]?([a-z0-9_.-]+)", match.group(0))
                prefix_match = re.search(r"(?:-p|--prefix)\s+['\"]?(\S+?)['\"]?(?:\s|$)", match.group(0))
                if name_match:
                    install_targets.append(name_match.group(1).lower())
                elif prefix_match:
                    install_targets.append(Path(prefix_match.group(1).rstrip("/\\")).name.lower())
            for target in install_targets:
                for skill in registry.list_skills("software"):
                    env = str(skill.metadata.get("environment") or "").lower()
                    if env != target:
                        continue
                    try:
                        status = registry.software_status(skill.skill_id)
                    except Exception:
                        continue
                    if status.status == "ready":
                        return (
                            f"软件环境 {target} 已经 READY（{status.path}），无需重新创建或安装。"
                            "直接使用该环境（conda run -p 绝对前缀）继续分析。\n"
                            f"Software environment {target} is already READY ({status.path}); no need to recreate or install it. "
                            "Continue the analysis directly with that environment (conda run -p absolute prefix)."
                        )
        return None

    @classmethod
    def _execution_solution_blocker(
        cls,
        messages: list[BaseMessage],
        solution: str,
        phase: str = "full",
    ) -> str | None:
        """Explain why execution cannot finish yet, or return None when verified."""
        observations = cls._observation_texts(messages)
        if any(cls.RESOURCE_BLOCKED_MARKER in observation for observation in observations):
            return None
        preflight_indexes = [
            index for index, observation in enumerate(observations) if cls.PREFLIGHT_MARKER in observation
        ]
        if not preflight_indexes:
            return (
                "依赖预检尚未完成。先检查本任务需要的软件、命令、输入文件和数据库；"
                f"安装或下载所有缺失项并验证可用后，在真实命令输出中打印 {cls.PREFLIGHT_MARKER}。\n"
                "Dependency preflight is not complete. First check the software, commands, input files, and databases needed "
                f"for this task; after installing or downloading all missing items and verifying them, print {cls.PREFLIGHT_MARKER} in the real command output."
            )

        reconfirmation_phrases = (
            "请确认",
            "再次确认",
            "确认后",
            "是否执行",
            "confirm again",
            "please confirm",
            "awaiting confirmation",
        )
        if any(phrase in solution.lower() for phrase in reconfirmation_phrases):
            return "用户已经确认执行，不得再次要求确认；立即继续运行已确认方案中的命令。\nThe user has already confirmed execution; do not ask for confirmation again. Continue running the commands of the confirmed plan immediately."

        if observations and cls._observation_failed(observations[-1]):
            return (
                "最近一次执行观察包含报错。分析 stderr/退出码，说明根因，修改参数、路径或命令后重试；"
                "不得把失败包装成最终答案。\n"
                "The most recent execution observation contains errors. Analyze the stderr/exit code, explain the root cause, "
                "fix parameters, paths, or commands, then retry; do not wrap a failure into a final answer."
            )

        verification_marker = cls.PILOT_VERIFIED_MARKER if phase == "pilot" else cls.RESULT_VERIFIED_MARKER
        verification_indexes = [
            index for index, observation in enumerate(observations) if verification_marker in observation
        ]
        if not verification_indexes:
            target = "小数据端到端试跑" if phase == "pilot" else "全量结果"
            return (
                f"{target}尚未验收。运行检查输出文件存在性、非空性和关键统计的具体命令；"
                f"确认目标真实达成后，在该命令输出中打印 {verification_marker}。\n"
                f"{'The end-to-end pilot' if phase == 'pilot' else 'The full results'} have not been accepted yet. Run concrete commands that check the existence, non-emptiness, and key statistics of the output files; "
                f"once the target is truly achieved, print {verification_marker} in that command's output."
            )
        if verification_indexes[-1] <= preflight_indexes[-1] + 1:
            return "预检后尚无独立的分析执行观察。先运行已确认方案的核心分析命令，再单独执行结果验收。\nThere is no independent analysis-execution observation after preflight. Run the core analysis commands of the confirmed plan first, then perform the result acceptance separately."
        return None

    @classmethod
    def _execution_mode_prompt(cls, phase: str = "full") -> str:
        scope = (
            f"Run only an end-to-end pilot on a tiny representative subset. Never process the complete input. "
            f"After validating every selected workflow component and output, print {cls.PILOT_VERIFIED_MARKER}."
            if phase == "pilot"
            else f"The pilot was already verified. Run the complete confirmed dataset and print {cls.RESULT_VERIFIED_MARKER} only after final validation."
        )
        acquisition_policy = (
            f"prefer READY local database formats. Download/localize a missing database only when the confirmed plan contains its exact [MICROBIOME_DB_ACQUISITION:<database-id>] marker; staged SRA input transfer is handled outside this graph by [MICROBIOME_DATA_ACQUISITION:sra-runs]; any other missing database must print {cls.RESOURCE_BLOCKED_MARKER}"
            if phase == "pilot"
            else f"do not download or update any database during the full run; every selected database must still be READY from the pilot, otherwise print {cls.RESOURCE_BLOCKED_MARKER}"
        )
        resource_directive = ""
        try:
            from microbiome.resource_config import get_config as _get_resource_config

            resource_directive = _get_resource_config().utilization_directive()
        except Exception:
            pass
        resource_section = f"\n{resource_directive}\n" if resource_directive else ""
        preflight_policy = (
            "- check each software inside the exact conda environment declared by its software skill, using a separate conda run -n/-p command;\n"
            "- resolve every execution-phase deficiency yourself instead of stopping: install missing software with conda/mamba install -n <env> (never into base/current env), create or repair a named conda/mamba environment whenever a required tool is missing or its environment is broken, fix paths and parameters, then re-run to verify"
            if phase == "pilot"
            else "- environments and databases were already installed and verified during the pilot and inputs were already staged by the framework: keep preflight read-only (input paths, sizes, formats). Never re-create or re-install conda/mamba environments, never re-download or re-stage inputs, and never replay data-preparation steps from the confirmed plan; repair one specific item only when a command truly reports that environment/software missing or broken, then re-run the original analysis command"
        )
        preflight_done = (
            f"- verify each installed dependency. Only then print {cls.PREFLIGHT_MARKER} in the command output."
            if phase == "pilot"
            else f"- once the read-only checks pass, print {cls.PREFLIGHT_MARKER} in the command output and proceed directly to the pilot-proven commands."
        )
        return f"""

EXECUTION MODE IS ACTIVE AND THE USER HAS ALREADY CONFIRMED.
Do not plan again and never ask the user to confirm again. Continue autonomously until the confirmed goal is achieved and verified.

Your first action must be an <execute> command that performs only task-specific preflight checks. Do not run the primary analysis in the preflight command:
- verify every input path and determine the exact executables and databases required by the confirmed plan;
- inspect validated local resources with list_resource_skills() and prefer the READY skills selected by the confirmed plan;
- never use conda activate/deactivate and never reuse one software's environment for another software unless both skills explicitly declare the same environment;
{preflight_policy};
- {acquisition_policy};
{preflight_done}

{scope}
{resource_section}
After preflight, show concrete commands. After every observation, inspect the real exit status and output. If a command fails, diagnose the specific cause, change the command, parameters, path, environment, software installation, or database configuration, and retry. Never repeat an unchanged failing command and never stop merely because an error occurred.
Do not label execution messages or code comments as Step N, numbered steps, or 第几步. Describe only the current action.
Before every <execute>, state four concise user-visible fields: `当前步骤：...`, `目的：...`, `原因：...`, and `目标目录：...`. The reason must explain why the command is necessary now; the target must be the actual environment name, download directory, or results directory. Do not reveal private chain-of-thought.

Before a final <solution>, run an <execute> command that verifies expected output files are present and non-empty and checks task-relevant summary statistics. A final answer is forbidden until {cls.PREFLIGHT_MARKER} and the phase-specific verification marker have appeared in actual <observation> messages. Do not ask the user for the next confirmation inside this graph; the outer conversation gate handles it.
"""

    _INPUT_AUDIT_EXTENSIONS = (
        ".fastq",
        ".fq",
        ".fasta",
        ".fa",
        ".fna",
        ".faa",
        ".bam",
        ".sam",
        ".cram",
        ".vcf",
        ".bcf",
        ".gff",
        ".gff3",
        ".gtf",
        ".bed",
    )
    _INPUT_AUDIT_SKIP_PARTS = ("/envs/", "/site-packages/", "/.cache/", "/database/")
    _INPUT_AUDIT_SKIP_PREFIXES = ("/usr", "/bin", "/sbin", "/etc", "/proc", "/sys", "/dev", "/lib", "/var/lib")
    _INPUT_AUDIT_ARTIFACT_TOKENS = ("subsample", "pilot", "subset", "_tiny", "_mini", "_test")
    _INPUT_AUDIT_DIR_TOKENS = ("data", "fastq", "read", "seq", "input", "target", "raw", "sample")

    @classmethod
    def _plan_input_file_report(cls, task: str, plan: str, phase: str = "pilot") -> str:
        """Audit plan-referenced local input files so pilot and full share one ground truth."""
        text = f"{task or ''}\n{plan or ''}"
        if not text.strip():
            return ""
        trailing = ".,;:!?()[]{}\"'`，。；：、（）【】「」<>"
        candidates: list[str] = []
        for match in re.finditer(r"(?<![\w./:+-])/(?:[\w.@%=+~-]+/)*[\w.@%=+~-]+", text):
            token = match.group(0).rstrip(trailing)
            if len(token) < 4 or token in candidates:
                continue
            lowered = token.lower()
            if any(part in lowered for part in cls._INPUT_AUDIT_SKIP_PARTS):
                continue
            if lowered.startswith(cls._INPUT_AUDIT_SKIP_PREFIXES):
                continue
            candidates.append(token)
        if not candidates:
            return ""

        def is_input_name(name: str) -> bool:
            lowered = name.lower()
            if lowered.endswith(".gz"):
                lowered = lowered[:-3]
            return lowered.endswith(cls._INPUT_AUDIT_EXTENSIONS)

        def fmt_size(size: int) -> str:
            value = float(size)
            for unit in ("B", "KB", "MB", "GB", "TB"):
                if value < 1024 or unit == "TB":
                    return f"{int(value)} B" if unit == "B" else f"{value:.1f} {unit}"
                value /= 1024
            return f"{size} B"

        def file_size(path: Path) -> int:
            try:
                return path.stat().st_size
            except OSError:
                return 0

        def file_line(token: str, size: int) -> str:
            nonlocal problem
            name = Path(token).name.lower()
            is_artifact = any(marker in name for marker in cls._INPUT_AUDIT_ARTIFACT_TOKENS)
            if is_artifact:
                if size == 0:
                    return f"- 空文件 {token}（0 B，疑似试跑残留，禁止作为本阶段输入） / Empty file {token} (0 B, likely pilot residue; forbidden as input for this stage)"
                if phase == "full":
                    return f"- 试跑产物 {token}（{fmt_size(size)}，试跑专用，禁止作为全量输入） / Pilot artifact {token} ({fmt_size(size)}, pilot-only; forbidden as full input)"
                return f"- OK {token}（{fmt_size(size)}，试跑子集，仅限试跑阶段使用） / OK {token} ({fmt_size(size)}, pilot subset; for pilot stage only)"
            if size > 0:
                return f"- OK {token}（{fmt_size(size)}） / OK {token} ({fmt_size(size)})"
            problem = True
            return f"- ⚠️ 空文件 {token}（0 B） / Empty file {token} (0 B)"

        problem = False
        lines: list[str] = []
        reported: set[str] = set()
        for token in candidates:
            if len(lines) >= 14:
                break
            path = Path(token)
            if path.is_file():
                if is_input_name(path.name) and token not in reported:
                    reported.add(token)
                    lines.append(file_line(token, file_size(path)))
            elif path.is_dir():
                try:
                    entries = sorted(
                        (
                            entry
                            for entry in [*path.glob("*"), *path.glob("*/*")]
                            if entry.is_file() and is_input_name(entry.name)
                        ),
                        key=lambda entry: entry.name,
                    )
                except OSError:
                    continue
                if not entries:
                    if any(marker in path.name.lower() for marker in cls._INPUT_AUDIT_DIR_TOKENS):
                        problem = True
                        lines.append(f"- ⚠️ 目录 {token}（未发现测序数据文件） / Directory {token} (no sequencing data files found)")
                    continue
                for entry in entries[:6]:
                    key = str(entry)
                    if key in reported:
                        continue
                    reported.add(key)
                    lines.append(file_line(key, file_size(entry)))
                if len(entries) > 6:
                    lines.append(f"- … {token} 内另有 {len(entries) - 6} 个数据文件 / ... {len(entries) - 6} more data files inside {token}")
            elif is_input_name(token):
                problem = True
                lines.append(f"- ⚠️ 缺失 {token} / Missing {token}")
        if not lines:
            return ""
        if phase == "full":
            rule = (
                "全量阶段必须严格沿用以上 OK 的原始输入文件（与试跑阶段完全一致），不得改用其它路径；"
                "试跑生成的子集/中间文件严禁作为全量输入；若以上没有可用的完整原始输入（只有试跑产物），"
                "或必需输入缺失/为空，停止并打印 "
                f"{A1.RESOURCE_BLOCKED_MARKER}，严禁用试跑子集冒充全量数据，严禁在全量阶段下载替代数据。\n"
                "The full stage must strictly reuse the OK raw input files above (exactly as in the pilot); do not switch to other paths. "
                "Subsets/intermediate files generated by the pilot are forbidden as full inputs; if no complete raw input is available above "
                "(only pilot artifacts), or a required input is missing/empty, stop and print "
                f"{A1.RESOURCE_BLOCKED_MARKER}; never pass pilot subsets off as full data and never download replacement data during the full stage."
            )
        else:
            rule = (
                "试跑必须从以上 OK 的原始文件抽取子集，子集写入独立试跑目录，严禁覆盖或混用原始输入；"
                "生成子集后必须立即验证其非空且记录数符合预期。\n"
                "The pilot must sample subsets from the OK raw files above, writing them into a dedicated pilot directory; "
                "never overwrite or mix the original inputs, and immediately verify each subset is non-empty with the expected record count."
            )
        header = "输入文件自检（框架在本阶段启动前实测，是本阶段输入路径的唯一事实来源）：\nInput-file self-check (measured by the framework before this stage starts; the single source of truth for this stage's input paths):"
        body = [header, *lines]
        if problem:
            body.append("⚠️ 以上标记为缺失/空文件/无数据的条目若是方案必需的原始输入，必须先解决再继续。\nIf the items marked above as missing/empty/without data are required raw inputs for the plan, resolve them before continuing.")
        body.append(rule)
        return "\n".join(body)

    @staticmethod
    def _build_execution_prompt(
        task: str,
        plan: str,
        resource_guidance: str = "",
        phase: str = "pilot",
        pilot_summary: str = "",
        pilot_playbook: str = "",
        subset_context: str = "",
    ) -> str:
        """Build a pilot or full-run prompt after the corresponding confirmation."""
        guidance_section = f"\n\n已选资源的详细 skill 指南：\n{resource_guidance}\n" if resource_guidance else ""
        memory_section = ""
        try:
            from microbiome import software_memory as _software_memory

            if _software_memory.enabled():
                _memory_brief = _software_memory.memory_for_text(f"{task}\n{plan}")
                if _memory_brief:
                    memory_section = (
                        "\n\n软件历史使用记忆（来自过往失败的自动学习档案，必须遵守：优先复用已验证命令，"
                        "禁止原样重复已记录的失败命令；遇到新失败时按其要求联网检索正确用法并更新档案）：\n"
                        + _memory_brief
                        + "\n"
                    )
        except Exception:
            pass
        resource_directive = ""
        try:
            from microbiome.resource_config import get_config as _get_resource_config

            resource_directive = _get_resource_config().utilization_directive()
        except Exception:
            pass
        resource_section = f"\n{resource_directive}\n" if resource_directive else ""
        if phase == "pilot":
            scope = f"""
- 当前只运行端到端小数据试跑，严禁处理完整输入。框架会按 MICROBIOME_PILOT_MAX_RECORDS（默认 1000）和 10% 比例确定性生成子集并直接注入上下文；必须原样使用这些子集路径，严禁自行截取原始数据。只有当框架无法安全截取时才使用软件自带测试数据或最小合成数据，并记录与真实输入的差异。
- 子集必须写入独立试跑目录，严禁覆盖、截断或替换原始输入文件；生成子集后立即用 `ls -l` 和记录数抽查验证其非空且符合预期，子集为空或生成失败属于试跑失败，必须修正命令重试，严禁据此打印 {A1.PILOT_VERIFIED_MARKER}。
- 小数据必须依次通过已确认方案中的全部软件、格式转换和数据库接口，不得只测试第一条命令。
- 试跑输出验收成功后，让命令打印 {A1.PILOT_VERIFIED_MARKER}，然后仅总结试跑、修正过的命令和全量运行资源估计；不要自行启动全量数据，也不要在执行图内询问用户。
"""
            completion_marker = A1.PILOT_VERIFIED_MARKER
            database_policy = (
                "只有已确认方案中带 `[MICROBIOME_DB_ACQUISITION:<database-id>]` 标记的缺失数据库，"
                f"才允许按方案中的来源和命令下载到其独立 `Database/<database-id>/` 并本地化；任何计划外下载都必须停止并打印 {A1.RESOURCE_BLOCKED_MARKER}。"
            )
            preflight_intro = "首先只运行预检命令检查输入以及方案中选定的软件/数据库 skill，不要提前运行核心分析。优先使用本地 READY skill。"
            remediation_policy = (
                "执行阶段必须自主解决所有报错与不足，不得直接退出或只显示错误：软件缺失时用 `conda/mamba install -n <env>` 安装，"
                "或用 `conda create -n <env>` 创建独立环境；环境损坏时重建修复；pip 包经 `conda run -n <env> pip install` 安装。"
                "禁止装入 base/当前环境，也禁止把所有软件混装进同一环境。修复后必须立即重试并验证。"
            )
            preflight_done = f"所有输入、软件环境和本地数据库均验证可用后，让预检命令打印 {A1.PREFLIGHT_MARKER}。"
        else:
            scope = f"""
- 小数据端到端试跑已经通过。使用试跑中最终验证成功的命令、环境、数据库路径和参数处理完整输入，不得回退到试跑前的失败命令。
- 试跑摘要：{pilot_summary or "已由上一阶段验证；从已确认方案和资源绑定恢复命令。"}
- 试跑生成的子集/中间文件（subsampled_*、pilot_* 等）仅供试跑使用，严禁作为全量输入；全量输入必须是已确认方案中的原始完整文件，与下方输入文件自检保持严格一致，不得自行扫描目录重新推断输入。严禁把 pilot_run/ 等试跑目录中的子集当作完整数据处理；完整输入不可用时停止并打印 {A1.RESOURCE_BLOCKED_MARKER}。
- 环境与数据库已安装验证完毕、输入数据已备好（SRA 全量续传由框架数据运行器完成，不属于你的职责）：不得重跑方案中的数据下载、子集生成或环境安装步骤，直接用试跑验证过的环境与命令处理完整输入。
- 全量输出验收成功后让命令打印 {A1.RESULT_VERIFIED_MARKER}。
"""
            completion_marker = A1.RESULT_VERIFIED_MARKER
            database_policy = f"全量阶段不得新增或更新任何数据库；所有数据库必须沿用试跑验证过的 READY 路径，否则停止并打印 {A1.RESOURCE_BLOCKED_MARKER}。"
            preflight_intro = (
                "首先只运行只读预检核对输入（路径/大小/格式），不要提前运行核心分析；"
                "环境与数据库在试跑前已安装并验证，严禁重装环境、严禁重下数据、严禁重复方案中的数据准备步骤。"
            )
            remediation_policy = (
                "环境与数据库已就绪：严禁重新创建/安装环境、严禁重新下载输入数据；"
                "仅当某命令真实报告特定环境/软件缺失或损坏时，才按执行自愈修复该单项，修复后立即重跑原分析命令。"
            )
            preflight_done = f"输入只读核对通过后让预检命令打印 {A1.PREFLIGHT_MARKER}，随后直接使用试跑验证过的环境与命令处理完整输入。"
        input_audit = A1._plan_input_file_report(f"{task}\n{resource_guidance}", plan, phase=phase)
        input_audit_section = f"\n{input_audit}\n" if input_audit else ""
        subset_section = f"\n{subset_context}\n" if subset_context else ""
        playbook_section = ""
        if phase == "full" and pilot_playbook:
            playbook_section = (
                "\n试跑成功剧本（框架从试跑真实执行记录自动提取：最终成功的命令、环境、软件参数、"
                "数据下载落盘路径与数据库路径。本阶段必须直接复用：仅把输入路径替换为输入自检中 OK 的完整数据路径、"
                "输出目录换新；标注“试跑专用”的步骤直接跳过；严禁重新下载数据、严禁重装环境、严禁重新试错）：\n"
                + pilot_playbook
                + "\n"
            )
        return f"""[MICROBIOME_PLAN_CONFIRMED]
用户已经明确确认以下方案。现在执行，不要重新规划，也不要再次请求确认。

执行范围：{phase}

原始任务：
{task}

已确认方案：
{plan}
{guidance_section}{memory_section}{playbook_section}
{resource_section}
执行要求：
- {preflight_intro}
- {database_policy}
- 每个软件必须使用已就绪绑定的**绝对前缀** `conda run -p <absolute-prefix> --no-capture-output <tool> ...` 调用（前缀来自上方 `invoke=`/skill 指南里已改写的绝对路径）；`conda run -n <env>` 只能在没有已知前缀时使用，因为多 conda 安装的机器上按名解析可能命中错误的 root 并报 EnvironmentLocationNotFound。禁止 `conda activate/deactivate`，前一个命令退出后再运行下一个环境的命令。
- {remediation_policy}
- 每条 `<execute>` 前必须用四行明确说明 `当前步骤：`、`目的：`、`原因：`、`目标目录：`；只解释用户需要知道的操作依据，不输出私有思维过程。环境安装写真实环境名，数据下载写绝对下载目录，分析任务写实际结果目录。
- 所有非数据库输入数据必须下载到环境变量 `MICROBIOME_DOWNLOAD_DIR` 指定的目录；数据库必须写入 `MICROBIOME_DB_ROOT`，分析输出必须写入 `MICROBIOME_RESULTS_DIR`。写入前自动创建目标目录，并在完成后验证文件存在、非空及适用的校验信息。
- 如果执行时发现未列入下载标记的必需数据库缺失，让检查命令打印 {A1.RESOURCE_BLOCKED_MARKER}，随后说明官方来源、`Database/<database-id>/` 放置目录以及对应软件 skill 的本地化命令。
- {preflight_done}
- 如果命令报错，立即分析错误输出，修正命令、参数、路径、环境或依赖后重试；不要原样重复失败命令，也不要因一次报错停止。
- 组装类工具（megahit/metaSPAdes/SPAdes/RNAspades）**绝不覆盖已有输出目录**。每次运行前 `-o` 必须是全新且不存在的目录：用运行时动态唯一名（如 `ASM_OUT=".../megahit_$(date +%s%N)"` 或 `mktemp -d`，严禁硬编码固定名），运行前先 `test ! -e "$ASM_OUT"`，已存在就先 `rm -rf "$ASM_OUT"` 或换新名。若仍报 "Output directory ... already exists"，说明复用了旧目录，必须删除或换新名后重试，严禁原样重复。
- 完成当前范围后必须运行验收命令，检查预期文件存在且非空，并检查关键统计。验收成功后让命令打印 {completion_marker}。
{scope}
{subset_section}{input_audit_section}
- 严格基于真实工具输出工作，不要声称尚未完成的结果。
- 不要使用“第几步”、Step N、编号检查表或逐轮计数来汇报执行过程。
- 只报告有信息量的动作、观察、错误和最终结果。
- 确认后的第一条响应必须是包含预检命令的 <execute>，不能是 <solution>。只有预检和当前范围的验收标记都出现在真实观察中后才能输出 <solution>。
"""

    @staticmethod
    def _message_text(message: BaseMessage) -> str:
        """Normalize provider-specific message content into visible answer text."""
        content = getattr(message, "content", "")
        if isinstance(content, str):
            return content.strip()
        if not isinstance(content, list):
            return "" if content is None else str(content).strip()

        parts = []
        for block in content:
            if isinstance(block, str):
                parts.append(block)
                continue
            if isinstance(block, dict):
                if block.get("type") in ("text", "output_text", "redacted_text"):
                    value = block.get("text") or block.get("content") or ""
                    if isinstance(value, str):
                        parts.append(value)
                continue
            value = getattr(block, "text", None)
            if isinstance(value, str):
                parts.append(value)
        return "".join(parts).strip()

    def _planning_system_prompt(self, query: str = "") -> str:
        if getattr(self, "harness_planning", False):
            from microbiome.harness.planning import compact_planning_prompt

            return compact_planning_prompt(self) + (
                "\nRead supplied full workflow references before planning; explain applicability, adaptations and "
                "mapped stages. Use read_workflow_reference/search_workflow_references for other methods. "
                "Reference membership never means installed software or permission to install.\n"
            )
        tool_groups = []
        for module, tools in sorted(getattr(self, "module2api", {}).items()):
            names = sorted(tool.get("name", "") for tool in tools if isinstance(tool, dict) and tool.get("name"))
            if names:
                tool_groups.append(f"- {module}: {', '.join(names)}")
        software = ", ".join(sorted(getattr(self, "library_content_dict", {}).keys()))
        databases = ", ".join(sorted(getattr(self, "data_lake_dict", {}).keys()))
        resource_context = "(resource skill registry unavailable)"
        registry = getattr(self, "resource_skill_registry", None)
        if registry is not None:
            try:
                registry.reload()
                try:
                    resource_context = registry.planning_context(query=query)
                except TypeError:
                    resource_context = registry.planning_context()
            except Exception as error:
                resource_context = f"(resource skill inventory failed: {error})"
        read_only_lines = []
        try:
            for tool_name, tool_fn in sorted(self._planning_read_only_tools().items()):
                try:
                    raw_signature = inspect.signature(tool_fn)
                    # 受保护/自动注入的参数不展示，避免模型尝试显式传参触发校验错误
                    visible_params = [
                        parameter
                        for parameter in raw_signature.parameters.values()
                        if parameter.name not in {"registry", "db_root", "data_root", "skill_root", "project_root", "timeout_seconds"}
                    ]
                    signature = str(raw_signature.replace(parameters=visible_params))
                except (TypeError, ValueError):
                    signature = "(...)"
                doc = ""
                try:
                    doc_lines = (inspect.getdoc(tool_fn) or "").strip().splitlines()
                    doc = doc_lines[0] if doc_lines else ""
                except Exception:
                    doc = ""
                read_only_lines.append(f"- {tool_name}{signature}" + (f" — {doc}" if doc else ""))
        except Exception:
            read_only_lines = []
        read_only_catalog = "\n".join(read_only_lines) or "(read-only planning tool catalog unavailable)"
        experience_context = "(none)"
        try:
            from microbiome.analysis_experience import relevant_experience

            experience_query = query or getattr(self, "_pending_task", "") or ""
            experience_context = relevant_experience(experience_query) or "(none)"
        except Exception:
            experience_context = "(unavailable)"
        from microbiome.workflows import WorkflowCatalog

        capability_context = WorkflowCatalog().catalog_summary()
        return f"""You are Microbiome's microbial-bioinformatics planning assistant.
Discuss and revise an executable analysis plan with the user. Planning mode cannot run code, install software, download data or databases, modify files, or claim analysis results. It may call only the read-only metadata tools listed below. Always provide a useful plan for executable tasks; do not refuse merely because execution happens only after confirmation.
Bilingual output (中英双语输出)：每一份方案、解释、提问和回答都必须同时包含中文和英文（先中文后英文）。Every plan, explanation, question, and answer you produce must be bilingual — Chinese first, then English.
任务分流：先判断用户意图。若用户只是在询问信息而不需要真正运行软件、下载数据或产出文件——例如查询某个 accession 的 layout/大小/平台、某个物种的 TaxID、本地已有哪些数据或数据库、解释概念、比较方案优劣——必须先调用只读工具核实事实（禁止凭记忆编造 accession 属性、体量、版本号等），再把最终答案完整包裹在 <direct_answer>...</direct_answer> 中返回；此时不要输出执行方案、不要要求用户“确认执行”。只有需要实际执行分析或下载的请求才返回执行方案。方案讨论过程中的顺带提问也用同样方式直接回答。<direct_answer> 中只允许放事实性答复：绝不包含执行方案、命令、代码块、步骤列表、资源准备或“确认执行”请求；凡是包含这些内容的回复一律不加任何 XML 标签，直接作为方案文本返回。
When a species name, project identifier, accession, local-resource status, or source choice is uncertain, request exactly one read-only tool by returning only:
<read_only_tool>{{"name":"tool_name","arguments":{{"argument":"value"}}}}</read_only_tool>
Do not wrap that request in Markdown and do not add prose. After receiving <read_only_tool_result>, either request another allowed lookup or return the visible plan. Never request a download_*, install, shell, Python, R, write, delete, or execution tool in planning mode. The application validates a strict allowlist, so inventing a tool cannot work. At most {self.MAX_PLANNING_READ_ONLY_CALLS} metadata calls are available per planning response.
Use the exact parameter names from this read-only tool catalog — do not guess signatures:
{read_only_catalog}
Describe required inputs, task-specific software and databases, dependency checks, analysis commands at a conceptual level, expected outputs, error recovery, and final validation. A numbered plan is allowed in planning mode.

Use this supported workflow catalog to avoid omitting essential analysis branches, but never interpret catalog membership as proof that a tool or database is installed:
{capability_context}
Read the full selected workflow documents supplied with the current input manifest and resource evidence.
Explain which references apply, which stages you adapt and why; do not copy a recipe without checking its
input assumptions, study design, taxonomic scope and output validation. Read additional workflows with
read_workflow_reference/search_workflow_references before relying on their details.

关键澄清优先（执行类任务）：若用户要执行分析，但关键信息缺失会实质改变方案设计，**第一轮必须先逐条提问**，等用户回答后再输出完整编号方案；严禁在信息不足时凭猜测直接生成完整方案。按影响从高到低，一次只问 1~3 个最关键的问题：
1. 测序类型/平台：双端还是单端？Illumina / Nanopore / PacBio？读长大概多少？
2. 目标物种/病原体：是否有针对性物种（如登革热病毒）？还是无偏宏基因组/宏病毒组？
3. 样本信息：样本数量、样本类型（临床/环境/培养）、是否需要先去除宿主背景？
4. 分析目标：组装、注释、分型、完整性检查，还是其它？
先只问问题、不输出完整方案；用户回答后，再输出完整编号方案并在末尾请用户“确认执行”。只有纯信息查询才用 <direct_answer> 直接回答。
资源选择必须遵循以下优先级：优先使用本地 READY 且已有 skill 的数据库和软件；其次考虑已有 skill 但需要准备的资源；最后才考虑没有 skill 或外部检索的新资源。
功能重叠时优先采用 `selection_tier=default` 的成熟主路径；`selection_tier=conditional` 只有在其 skill 声明的数据类型、研究目的或交叉验证条件确实满足时才加入，不得为了展示工具而堆叠重复软件。
只列出与当前任务相关且真正选入方案的资源；不要因为某个资源是 READY 就介绍它。备选软件不要混入可执行主方案，尤其不要让未选备选项的数据库格式阻塞主路径。
注册表的 READY 状态已经由本机文件和格式标记验证。不得再次要求用户确认 READY 文件是否存在，也不要为 READY 数据库安排下载、重建或替代路径。
规划阶段不得实际下载数据库。对每个可用数据库方案说明本地 READY 状态、科学覆盖范围、优势、局限、版本兼容、预计下载/本地化体量和所需软件格式；有合适的本地 READY 格式时默认采用它，但可因明确的科学理由提出替代方案。注册表的 MISSING/NEEDS_LOCALIZATION 也是本机扫描事实，不要反过来询问用户文件是否其实存在。
若缺少必需数据库，必须给出官方来源、`Database/<database-id>/` 独立目录、获取命令、格式检查与本地化命令。仅对 Skill 声明可自动或有条件自动获取的数据库加入 `[MICROBIOME_DB_ACQUISITION:<database-id>]` 提案；用户回复“确认执行”后才授权执行该标记对应的下载。未标记、需登录、许可受限或参数未确定的资源仍然阻塞执行。
SRA/SRR/ERR/DRR 是项目输入数据而不是数据库，且必须严格匹配 accession 规则（SRR/ERR/DRR+数字）才可能成为远程候选。输入来源必须先本地后远程：用户明确给出的本地文件、本地目录或本地 sample manifest（sample_list.txt / samples.tsv / samples.csv / manifest.txt）是原始数据来源，不是 SRA 下载请求。若系统已给出【输入数据识别结果】并确认本地 FASTQ 可用，直接基于这些本地文件设计流程，禁止再询问 SRA/accession、禁止输出 SRA 下载计划。本地 manifest 中的样本必须逐样本分类：本地 FASTQ 样本保持本地，只对真正的远程 accession 记录单独询问是否下载，不要把整个任务拖进 SRA 模式。本地 FASTQ 文件缺失属于本地输入错误，不是使用 SRA 的理由。只有某个样本值严格匹配 accession 且本地确实没有对应 FASTQ/FASTA 时，才先用只读 resolve_sra_accessions 核对 run、layout 和体量，再调用 plan_sra_download 生成精确调用。只有该工具生成的 [MICROBIOME_DATA_ACQUISITION:sra-runs] 才能授权：第一次确认只下载代表性 pilot run，第二次“确认全量执行”才续传剩余已审核 runs 到 Data/sra/。
用户只提供物种俗名、缩写或可能有拼写偏差的名称时，先调用 `resolve_fuzzy_species_name`。只有置信度和候选间距通过门控后，才可调用 `plan_species_reference_download`：完整参考基因组先固定 assembly accession；基因、位点或蛋白序列必须再提供目标查询并由 TaxID 约束，禁止仅凭物种名下载该物种全部 Entrez 记录。
每个软件必须写明其 skill 声明的 conda 环境和 `conda run` 调用方式。若环境不存在，必须在方案中提前声明要创建的环境名、渠道和软件包；执行阶段不得临时发明新环境。
计划还必须定义一个覆盖全部已选软件和格式接口的小数据端到端试跑范围，以及全量数据的资源估计和验收指标。`create_sequence_pilot_dataset` 只能从用户已有 FASTA/FASTQ 截取完整记录并校验配对，不能模拟 reads；需要合成数据时必须选择已声明环境中的成熟模拟器或软件官方测试数据。第一次“确认执行”只会完成资源准备和小数据试跑；试跑验证通过后，系统会再次询问是否运行全量数据。
When all missing databases are either READY or represented by an executable MICROBIOME_DB_ACQUISITION proposal, invite changes and tell the user to reply exactly “确认执行”. When a required database is manual/license-gated or lacks a complete acquisition proposal, do not invite execution; give exact preparation instructions. Return plain visible text without XML tags.

Validated local resource skills and live readiness:
{resource_context}

Prior analysis experience (prefer proven workflows, avoid repeating failed ones):
{experience_context}

Available Microbiome tools:
{chr(10).join(tool_groups) if tool_groups else "- Tool registry unavailable; plan from the stated task."}

Available software catalog:
{software or "(not loaded)"}

Known data resources:
{databases or "(not loaded)"}
"""

    def _planning_read_only_tools(self) -> dict[str, Any]:
        """Return the hardcoded planning allowlist without exposing execution tools."""
        from microbiome.analysis_experience import query_analysis_experience
        from microbiome.research import search_research
        from microbiome.resource_skills.resolver import inspect_software_request
        from microbiome.tool.workflow_catalog import (
            list_workflow_references, read_workflow_reference, search_workflow_references,
        )
        from microbiome.tool.genome_retrieval import (
            inspect_local_reference_genomes,
            inspect_local_virus_genomes,
            plan_reference_genome_download,
            plan_virus_genome_download,
            resolve_reference_genome_accessions,
        )

        tools: dict[str, Any] = {
            "search_research": search_research,
            "inspect_local_reference_genomes": inspect_local_reference_genomes,
            "resolve_reference_genome_accessions": resolve_reference_genome_accessions,
            "plan_reference_genome_download": plan_reference_genome_download,
            "inspect_local_virus_genomes": inspect_local_virus_genomes,
            "plan_virus_genome_download": plan_virus_genome_download,
            "inspect_local_input_sources": inspect_local_input_sources,
            "query_analysis_experience": query_analysis_experience,
            "inspect_software_request": inspect_software_request,
            "list_workflow_references": list_workflow_references,
            "read_workflow_reference": read_workflow_reference,
            "search_workflow_references": search_workflow_references,
        }
        optional_modules = (
            (
                "microbiome.tool.sequence_retrieval",
                (
                    "inspect_local_reference_sequences",
                    "resolve_fuzzy_species_name",
                    "plan_species_reference_download",
                    "resolve_reference_sequence_accessions",
                    "plan_reference_sequence_download",
                ),
            ),
            (
                "microbiome.tool.sra_retrieval",
                ("inspect_local_sra_runs", "resolve_sra_accessions", "plan_sra_download"),
            ),
            (
                "microbiome.resource_skills",
                ("render_environment_create_command", "render_software_command"),
            ),
        )
        for module_name, names in optional_modules:
            try:
                module = __import__(module_name, fromlist=list(names))
            except ImportError:
                continue
            for name in names:
                function = getattr(module, name, None)
                if callable(function):
                    tools[name] = function
        return tools

    @staticmethod
    def _parse_planning_read_only_request(text: str) -> tuple[str, dict[str, Any]] | None:
        match = re.fullmatch(
            r"\s*<read_only_tool>\s*(\{.*\})\s*</read_only_tool>\s*",
            text,
            flags=re.DOTALL | re.IGNORECASE,
        )
        if match is None and "<read_only_tool" in text.lower():
            # 本地小模型常在标签前后夹带解释文字；宽松提取标签内的完整 JSON 请求
            match = re.search(
                r"<read_only_tool>\s*(\{.*\})\s*</read_only_tool>",
                text,
                flags=re.DOTALL | re.IGNORECASE,
            )
        if not match:
            return None
        if len(match.group(1)) > 8000:
            raise ValueError("read-only tool request exceeds 8000 characters")
        payload = json.loads(match.group(1))
        if not isinstance(payload, dict) or set(payload) != {"name", "arguments"}:
            raise ValueError("request must contain exactly 'name' and 'arguments'")
        name = payload["name"]
        arguments = payload["arguments"]
        if not isinstance(name, str) or not name:
            raise ValueError("tool name must be a non-empty string")
        if not isinstance(arguments, dict):
            raise ValueError("tool arguments must be a JSON object")
        forbidden = {"approved", "db_root", "data_root", "project_root", "timeout_seconds"}.intersection(arguments)
        if forbidden:
            raise ValueError(f"planning tool cannot set protected arguments: {', '.join(sorted(forbidden))}")
        return name, arguments

    def _run_planning_read_only_request(self, name: str, arguments: dict[str, Any]) -> str:
        tools = self._planning_read_only_tools()
        function = tools.get(name)
        if function is None:
            raise ValueError(f"{name!r} is not an allowed planning read-only tool")
        signature = inspect.signature(function)
        call_arguments = dict(arguments)
        registry = getattr(self, "resource_skill_registry", None)
        if "db_root" in signature.parameters and registry is not None and hasattr(registry, "db_root"):
            call_arguments["db_root"] = str(registry.db_root)
        if "registry" in signature.parameters and registry is not None:
            call_arguments["registry"] = registry
        if name == "inspect_software_request":
            if "project_root" in call_arguments:
                raise ValueError("planning tools cannot override the project root")
            project = self._find_pipeline_project()
            if project is not None:
                call_arguments["project_root"] = str(project.root)
        signature.bind(**call_arguments)
        result = function(**call_arguments)
        if name == "inspect_software_request":
            return json.dumps(result, ensure_ascii=False)
        if name in {"list_workflow_references", "read_workflow_reference", "search_workflow_references"}:
            if len(result.encode("utf-8")) > 128 * 1024:
                raise ValueError("Workflow references exceed the planning budget; select fewer exact workflow IDs.")
            return result
        if name == "search_research":
            from microbiome.pipeline.research_context import record_research_context

            evidence = json.loads(result)
            self._research_result = evidence
            project = self._find_pipeline_project()
            if project is None:
                raise ValueError("Research evidence requires an initialized project so complete sources can be persisted.")
            # Preserve full evidence before creating a UTF-8 byte-bounded model
            # view. Return here: the generic character slice below would cut
            # research JSON mid-record and can exceed the model's byte budget.
            return json.dumps(record_research_context(project, evidence), ensure_ascii=False)
        visible = str(result)
        if len(visible) > 24000:
            visible = f"{visible[:24000]}\n[read-only result truncated]"
        return visible

    def _invoke_planning_model(self, history: list[BaseMessage]) -> str:
        query = "\n".join(self._message_text(message) for message in history if isinstance(message, HumanMessage))[
            -12000:
        ]
        messages = [SystemMessage(content=self._planning_system_prompt(query=query)), *history]
        correction = HumanMessage(
            content=(
                "Your previous planning response was empty or tried to execute. "
                "Return a visible plan only, without XML execution tags. A read-only lookup must use "
                "the exact <read_only_tool> JSON protocol from the system prompt."
            )
        )
        conversation = list(messages)
        corrected = False
        query_nudged = False
        read_only_calls = 0
        for _attempt in range(self.MAX_PLANNING_READ_ONLY_CALLS + 5):
            response = self.llm.invoke(conversation)
            text = self._message_text(response)
            text = re.sub(r"^\s*<solution>\s*", "", text, flags=re.IGNORECASE)
            text = re.sub(r"\s*</solution>\s*$", "", text, flags=re.IGNORECASE)
            try:
                request = self._parse_planning_read_only_request(text)
            except (ValueError, json.JSONDecodeError) as error:
                request = None
                if "<read_only_tool" in text.lower():
                    conversation.extend(
                        [
                            AIMessage(content=text),
                            HumanMessage(content=f"<read_only_tool_result>ERROR: {error}</read_only_tool_result>"),
                        ]
                    )
                    continue
            if request is not None:
                name, arguments = request
                read_only_calls += 1
                if read_only_calls > self.MAX_PLANNING_READ_ONLY_CALLS:
                    observation = "ERROR: read-only planning call limit reached; return the best visible plan now"
                else:
                    try:
                        result = self._run_planning_read_only_request(name, arguments)
                        # Keep bounded research as structured data rather than
                        # double-escaping a JSON string inside another JSON blob.
                        content = json.loads(result) if name == "search_research" else result
                        observation = json.dumps({"name": name, "ok": True, "content": content}, ensure_ascii=False)
                    except Exception as error:
                        observation = json.dumps({"name": name, "ok": False, "error": str(error)}, ensure_ascii=False)
                conversation.extend(
                    [
                        AIMessage(content=text),
                        HumanMessage(content=f"<read_only_tool_result>{observation}</read_only_tool_result>"),
                    ]
                )
                continue
            if text and "<execute>" not in text.lower() and "<observe>" not in text.lower():
                direct = self._extract_direct_answer(text)
                if direct is not None:
                    if self._looks_like_pure_query(query) or not self._PLAN_SHAPED_RE.search(direct):
                        # 纯查询直接回答：跳过方案精修、资源绑定与下载提案注入
                        return text.strip()
                    # 模型把执行方案误包进 <direct_answer>（本地小模型常见）：剥掉标签，
                    # 按普通方案继续走资源绑定与获取提案注入，保证确认门不丢
                    text = direct
                if not query_nudged and self._looks_like_pure_query(query):
                    # 本地小模型常把纯查询过度展开成完整分析方案；提示一次后仍接受模型判断
                    conversation.extend(
                        [
                            AIMessage(content=text),
                            HumanMessage(
                                content=(
                                    "用户只是在询问信息，不需要执行方案。请直接回答问题（涉及 accession、"
                                    "物种、本地资源等事实先调用 <read_only_tool> 核实），把最终答案包裹在 "
                                    "<direct_answer>...</direct_answer> 中返回；不要输出执行方案，也不要要求确认执行。"
                                )
                            ),
                        ]
                    )
                    query_nudged = True
                    continue
                registry = getattr(self, "resource_skill_registry", None)
                if registry is not None and hasattr(registry, "detailed_context"):
                    try:
                        details = registry.detailed_context(text, max_skills=10, max_chars=32000)
                    except Exception:
                        details = ""
                    if details:
                        refinement = HumanMessage(
                            content=(
                                "Refine the draft plan using the task-relevant resource skills below. "
                                "Expand feasible analyses rather than assuming an omitted capability is impossible. "
                                "For each selected tool, make its accepted input format, upstream producer, key "
                                "parameter decisions, output format, downstream consumer, validation, and recovery "
                                "conditions explicit. Keep planning mode and do not execute.\n\n"
                                f"{details}"
                            )
                        )
                        try:
                            refined_response = self.llm.invoke([*conversation, AIMessage(content=text), refinement])
                            refined = self._message_text(refined_response)
                            refined = re.sub(r"^\s*<solution>\s*", "", refined, flags=re.IGNORECASE)
                            refined = re.sub(r"\s*</solution>\s*$", "", refined, flags=re.IGNORECASE)
                            if (
                                refined
                                and "<execute>" not in refined.lower()
                                and "<observe>" not in refined.lower()
                                and "<read_only_tool" not in refined.lower()
                            ):
                                text = refined
                        except Exception:
                            pass
                if getattr(self, "_structured_plan_bindings", False):
                    # The native workflow compiles and checks an explicit plan
                    # before presenting its dependency preview. A prose mention
                    # (including a rejected alternative) is not a resource use.
                    return re.sub(
                        r"\[MICROBIOME_DB_ACQUISITION:[a-z0-9-]+(?::[a-z0-9-]+)?\]",
                        "", text, flags=re.IGNORECASE).strip()
                if registry is not None and hasattr(registry, "plan_bindings"):
                    # Acquisition markers are a deterministic registry authorization surface,
                    # not free-form tokens the model may grant to itself.
                    text = re.sub(
                        r"\[MICROBIOME_DB_ACQUISITION:[a-z0-9-]+(?::[a-z0-9-]+)?\]",
                        "",
                        text,
                        flags=re.IGNORECASE,
                    ).strip()
                    try:
                        try:
                            bindings = registry.plan_bindings(text, query=query)
                        except TypeError:
                            bindings = registry.plan_bindings(text)
                    except Exception:
                        bindings = ""
                    if bindings:
                        text = f"{text.strip()}\n\n{bindings}"
                if self._sra_acquisition_allowed():
                    text = bind_sra_data_acquisition(text)
                else:
                    text = strip_sra_acquisition(text)
                if registry is not None and hasattr(registry, "database_acquisition_guidance"):
                    try:
                        candidates = registry.database_acquisition_candidates(text)
                        try:
                            acquisition = registry.database_acquisition_guidance(candidates, plan_text=text)
                        except TypeError:
                            acquisition = registry.database_acquisition_guidance(candidates)
                    except Exception:
                        acquisition = ""
                    if acquisition:
                        text = f"{text.strip()}\n\n{acquisition}"
                if registry is not None and hasattr(registry, "strip_ready_database_acquisitions"):
                    # Final deterministic cleanup: drop any download marker / download
                    # line for databases the registry already has READY, so the plan
                    # never even suggests re-downloading an existing resource.
                    try:
                        text = registry.strip_ready_database_acquisitions(text)
                    except Exception:
                        pass
                if registry is not None and hasattr(registry, "strip_ready_software_installs"):
                    # Same guard for software: drop create/install environment lines
                    # for environments the registry already has fully ready.
                    try:
                        text = registry.strip_ready_software_installs(text)
                    except Exception:
                        pass
                return text.strip()
            if not corrected:
                conversation.append(correction)
                corrected = True
        # The planning model repeatedly returned empty content or execution directives.
        # Degrade to a deterministic template instead of crashing, so the user can still
        # reach and edit the experimental design rather than being blocked entirely.
        return self._planning_fallback(query)

    def _planning_fallback(self, query: str) -> str:
        """Return a deterministic plan template when the planning model fails.

        This never invents tool/database facts: it surfaces the already-resolved input
        summary (if any) and asks the user to fill in the software, databases,
        parameters, and acceptance criteria that only they (or a working planner) can
        supply.
        """
        lines = [
            "# 分析方案（自动生成的基础模板，请审阅并补充后确认） / Analysis Plan (auto-generated basic template; please review, supplement, and confirm)",
            "",
            "> 规划模型本次未返回可用文本，系统已退回到基础模板，避免中断实验设计。\n> The planning model returned no usable text this time; the system fell back to the basic template to avoid interrupting the experimental design.",
            "",
            "## 任务 / Task",
            (query or "(未记录 / not recorded)").strip(),
            "",
        ]
        summary = getattr(self, "_input_summary", "") or ""
        if summary:
            lines.extend(["## 输入数据 / Input Data", summary, ""])
        lines.extend(
            [
                "## 建议步骤 / Suggested Steps",
                "1. 输入质控与格式检查（如 fastp） / Input QC and format check (e.g., fastp)",
                "2. 按任务目标执行核心分析（组装 / 基因预测 / 注释 / 分箱 / 定量 / 分类等） / Run the core analysis per the task goal (assembly / gene prediction / annotation / binning / quantification / classification, etc.)",
                "3. 输出结果验收与汇总 / Validate and summarize the output results",
                "",
                "## 待补充 / To Be Completed",
                "- 每步选用的软件、conda 环境与 `conda run` 调用方式 / Software, conda environment, and `conda run` invocation per step",
                "- 每步所需数据库及其 READY 状态 / Databases required per step and their READY status",
                "- 关键参数、输入输出路径与验收标准 / Key parameters, input/output paths, and acceptance criteria",
                "",
                "请补充以上内容后回复“确认执行”。\nPlease supplement the above items and reply “确认执行” to confirm execution.",
            ]
        )
        return "\n".join(lines)

    _QUERY_HINT_RE = re.compile(
        r"查询|查一下|查看|询问|是什么|哪些|多大|多少|有没有|是不是|介绍|解释|区别|"
        r"look\s?up|what\s+is|which|how\s+(?:many|much|big|large)|list|show|tell\s+me|explain",
        re.IGNORECASE,
    )
    _NEGATED_EXEC_RE = re.compile(
        r"(?:不要|不用|无需|先不|先别|不需要|no\s+need\s+to|don'?t|do\s+not|without)\s*"
        r"(?:下载|执行|运行|跑|分析|处理|download\w*|execut\w*|analy\w*|process\w*)",
        re.IGNORECASE,
    )
    # <direct_answer> 误用护栏：内容若呈现方案结构（代码块、步骤编号、确认执行请求、
    # 环境创建命令），即使包了标签也应按方案处理。纯查询答复常含执行类词汇
    # （“未下载”“不需要运行”），不能仅凭词汇判断，要看结构特征。
    _PLAN_SHAPED_RE = re.compile(
        r"```|确认执行|确认全量执行|(?:^|\n)\s*(?:#{1,4}\s*\d|步骤\s*\d|step\s*\d)|"
        r"conda\s+run|mamba\s+(?:create|install)",
        re.IGNORECASE,
    )
    # 注意：不要把 "run" 当作执行动词——"SRA run SRR..." 里的 run 是测序名词
    _EXEC_HINT_RE = re.compile(
        r"下载|分析|执行|运行|跑一下|处理|比对|组装|注释|质控|拼接|分箱|定量|"
        r"download\w*|analy\w*|execut\w*|process\w*|assembl\w*|align\w*|annotat\w*|\bqc\b",
        re.IGNORECASE,
    )

    @classmethod
    def _looks_like_pure_query(cls, query: str) -> bool:
        """Heuristic: the user asks for information, not execution (used only to nudge the planner)."""
        if not query:
            return False
        # CLI 首轮注入的路径/资源前缀含“下载”等词，只取真实任务文本判断意图
        if "用户任务：" in query:
            query = query.rsplit("用户任务：", 1)[-1]
        if not cls._QUERY_HINT_RE.search(query):
            return False
        scrubbed = cls._NEGATED_EXEC_RE.sub(" ", query)
        return not cls._EXEC_HINT_RE.search(scrubbed)

    @staticmethod
    def _extract_direct_answer(text: str) -> str | None:
        """Return the answer body when the planner directly answered a pure query."""
        if not isinstance(text, str):
            return None
        match = re.search(r"<direct_answer>\s*(.*?)\s*</direct_answer>", text, re.DOTALL | re.IGNORECASE)
        if not match:
            # Tolerate an unclosed tag (e.g. generation stopped early).
            match = re.search(r"<direct_answer>\s*(.+)$", text, re.DOTALL | re.IGNORECASE)
        if not match:
            return None
        return match.group(1).strip() or None

    def _inject_input_resolution_into_planning(self) -> None:
        """Append confirmed input context to the planner history (idempotent).

        The local-input summary is injected once and the SRA-decline note is
        injected once. Both are deterministic bridges between the resolver and
        the planning model so it cannot re-infer the source or re-ask for SRA.
        """
        if not getattr(self, "_input_summary_injected", False):
            summary = getattr(self, "_input_summary", "") or ""
            if summary:
                note = (
                    summary + "\n\n请基于以上已确认的输入来源设计分析方案。不要重新猜测原始数据来源，"
                    "不要把本地样本当作 SRA/accession；混合清单仅允许对已解析的远程记录提出下载。"
                )
                self._planning_history.append(HumanMessage(content=note))
            self._input_summary_injected = True
        if (
            getattr(self, "_sra_user_confirmed", False)
            and not getattr(self, "_allow_sra_download", True)
            and not getattr(self, "_sra_decline_injected", False)
        ):
            self._planning_history.append(
                HumanMessage(
                    content=(
                        "用户已明确表示不需要 SRA 原始测序数据。禁止再次询问或提议 "
                        "SRR/ERR/DRR/BioProject 下载；改用本地已有数据设计流程。"
                    )
                )
            )
            self._sra_decline_injected = True

    def _create_plan(self, prompt: str) -> str:
        self._pending_task = prompt
        self._direct_answer = None
        self._planning_history = [HumanMessage(content=prompt)]
        self._inject_input_resolution_into_planning()
        plan = self._invoke_planning_model(self._planning_history)
        answer = self._extract_direct_answer(plan)
        if answer is not None:
            # 纯信息查询：直接回答，不生成方案、不进入确认门
            self._direct_answer = answer
            return answer
        self._pending_plan = plan
        self._update_plan_resource_blockers(plan)
        self._planning_history.append(AIMessage(content=plan))
        self._set_plan_gate_from_resources()
        self._persist_plan_artifact(plan)
        return plan

    def _revise_plan(self, prompt: str) -> str:
        self._planning_history.append(HumanMessage(content=prompt))
        self._inject_input_resolution_into_planning()
        plan = self._invoke_planning_model(self._planning_history)
        answer = self._extract_direct_answer(plan)
        if answer is not None:
            # 方案讨论中的顺带提问：直接回答，保留当前方案与确认门状态
            self._planning_history.append(AIMessage(content=plan))
            self._direct_answer = answer
            return answer
        self._direct_answer = None
        self._pending_plan = plan
        self._update_plan_resource_blockers(plan)
        self._planning_history.append(AIMessage(content=plan))
        self._set_plan_gate_from_resources()
        self._persist_plan_artifact(plan)
        return plan

    def _persist_plan_artifact(self, plan: str) -> None:
        """Best-effort: write the current plan as an editable Markdown + YAML draft.

        Persistence is advisory — a write error must never break the conversation.
        """
        try:
            from microbiome.agent.plan_persistence import persist_plan_draft

            root = os.environ.get("MICROBIOME_RESULTS_DIR") or getattr(self, "path", None)
            if not root:
                return
            task = getattr(self, "_pending_task", "") or ""
            persist_plan_draft(root, task, plan)
        except Exception:
            pass

    def _set_plan_gate_from_resources(self) -> None:
        """Expose exactly one next-turn gate for the current draft plan."""
        blocked = bool(getattr(self, "_pending_missing_databases", []))
        self.awaiting_resource_preparation = blocked
        self.awaiting_plan_confirmation = not blocked

    def _missing_database_event(self) -> dict:
        """Build the deterministic event shown while manual resources are absent."""
        registry = getattr(self, "resource_skill_registry", None)
        missing = list(getattr(self, "_pending_missing_databases", []))
        if registry is not None and hasattr(registry, "missing_database_guidance"):
            guidance = registry.missing_database_guidance(missing)
        else:
            guidance = "资源准备尚未完成，当前不会进入分析执行。\nResource preparation is not complete, so analysis execution will not start yet."
        self.log = [guidance]
        return {"type": "resource_blocked", "content": guidance}

    def _sra_acquisition_allowed(self) -> bool:
        """SRA input transfer is only possible when it was not declined and no
        confirmed local raw input already exists."""
        resolution = getattr(self, "_input_resolution", None)
        if resolution is not None:
            return bool(getattr(self, "_allow_sra_download", True)) and resolution.has_remote_sra
        return bool(getattr(self, "_allow_sra_download", True)) and not bool(getattr(self, "_local_input_confirmed", False))

    @staticmethod
    def _detect_sra_decline(prompt: str) -> bool:
        """Return True when the user explicitly declines SRA / remote accession."""
        if not isinstance(prompt, str):
            return False
        compact = re.sub(r"\s+", "", prompt).lower()
        return bool(
            "不需要sra" in compact
            or "不用sra" in compact
            or "无需sra" in compact
            or "不要sra" in compact
            or "别用sra" in compact
            or "拒绝sra" in compact
            or "跳过sra" in compact
            or "不下载sra" in compact
            or "不需要下载sra" in compact
            or "不需要sra数据" in compact
            or "不需要sra原始数据" in compact
            or "noneedforsra" in compact
            or "nosra" in compact
        )

    def _run_input_resolution(self, prompt: str) -> str:
        """Deterministically resolve raw input sources before the LLM plans.

        When usable local data is found, persist input_manifest.yaml, mark the
        local input as confirmed, and return a summary for the planner. SRA is
        only ever proposed for strictly matched remote accessions with no local
        files, and only when the user has not declined SRA.
        """
        try:
            from microbiome.path_config import get_path_config
        except Exception as error:
            raise ValueError(f"input path configuration could not be loaded: {error}") from error
        try:
            cfg = get_path_config()
            raw_root = getattr(cfg, "raw_data_dir", None) or os.environ.get("MICROBIOME_DATA_DIR") or "."
            results_root = getattr(cfg, "results_dir", None) or os.environ.get("MICROBIOME_RESULTS_DIR") or raw_root
        except Exception:
            raw_root = os.environ.get("MICROBIOME_DATA_DIR") or "."
            results_root = os.environ.get("MICROBIOME_RESULTS_DIR") or raw_root
        try:
            resolver = InputSourceResolver(raw_root, output_root=results_root)
            result = resolver.resolve(prompt, allow_sra_download=self._allow_sra_download)
        except Exception as error:
            raise ValueError(f"input resolution failed: {error}") from error
        self._input_resolution = result
        if result.errors:
            raise ValueError("; ".join(result.errors))
        if result.samples:
            self._input_manifest_path = resolver.write_input_manifest(result)
            if not self._input_manifest_path:
                raise ValueError("input manifest could not be persisted")
        if result.has_usable_local_data:
            # Local raw inputs are confirmed: persist the manifest and forbid
            # the planner from re-inferring the source or proposing SRA.
            self._local_input_confirmed = True
            self._input_summary = summarize_resolution(result)
            return self._input_summary
        # Remote-only / ambiguous / unknown cases keep the existing planner path
        # (resolve_sra_accessions -> plan_sra_download) and need no local
        # summary injection.
        self._input_summary = summarize_resolution(result)
        return self._input_summary

    def _prepare_deterministic_subset(self) -> str:
        """Deterministically sample a pilot subset from resolved local inputs.

        Reuses the strict pipeline's format-aware sampler so the conversational
        pilot shares the same deterministic 10% logical-record subset contract and
        always records subset -> full-source lineage. Returns a context block for
        the execution prompt, or "" when sampling is skipped/unavailable (the
        existing LLM-driven subset path then remains the fallback).
        """
        resolution = getattr(self, "_input_resolution", None)
        if resolution is None:
            return ""
        try:
            from microbiome.input_resolution import LOCAL_SOURCE_TYPES
        except Exception:
            return ""
        samples = [
            sample
            for sample in getattr(resolution, "samples", []) or []
            if getattr(sample, "source_type", None) in LOCAL_SOURCE_TYPES
        ]
        paths: list[str] = []
        for sample in samples[:2]:
            for attr in ("r1", "r2"):
                value = getattr(sample, attr, None)
                if value and Path(value).is_file() and value not in paths:
                    paths.append(value)
            fasta = getattr(sample, "fasta", None)
            if fasta and Path(fasta).is_file() and fasta not in paths:
                paths.append(fasta)
        if not paths:
            return ""
        results_root = Path(os.environ.get("MICROBIOME_RESULTS_DIR") or getattr(self, "path", None) or ".")
        subset_dir = results_root / "pre_test_run" / "input_subset"
        try:
            from microbiome.tool.workflow_validation import create_sequence_pilot_dataset

            # A de novo metagenome pilot needs enough reads to actually assemble
            # contigs; a 1000-record subset yields 0 contigs and forces downstream
            # steps onto synthetic/empty data. Let operators raise the cap via
            # MICROBIOME_PILOT_MAX_RECORDS (default stays small for simple analyses).
            max_records = int(os.environ.get("MICROBIOME_PILOT_MAX_RECORDS", "1000"))
            payload = json.loads(
                create_sequence_pilot_dataset(
                    paths,
                    str(subset_dir),
                    max_records=max_records,
                    fraction=0.10,
                    seed=1729,
                )
            )
        except Exception:
            return ""
        outputs = payload.get("outputs", []) or []
        if not outputs:
            return ""
        try:
            mapping_path = self._write_subset_source_mapping(subset_dir.parent, outputs)
        except Exception:
            mapping_path = ""
        lines = [
            "【确定性试跑子集（已由框架生成；直接使用这些子集路径，严禁自行截取原始数据、"
            "严禁把这些子集当作全量输入）】\n"
            "[Deterministic pilot subsets (already generated by the framework; use these subset paths directly, never "
            "subsample raw data yourself, and never treat these subsets as full inputs)]",
        ]
        for entry in outputs:
            lines.append(
                f"- 原始：{entry.get('source')} → 子集：{entry.get('pilot')}（{entry.get('records')} 条记录） / Source: {entry.get('source')} → subset: {entry.get('pilot')} ({entry.get('records')} records)"
            )
        if mapping_path:
            lines.append(f"子集血缘映射已保存：{mapping_path} / Subset lineage mapping saved: {mapping_path}")
        return "\n".join(lines)

    def _write_subset_source_mapping(self, pretest_dir: Path, outputs: list[dict]) -> str:
        """Persist subset -> full-source lineage as source_mapping.yaml."""
        import yaml

        source: dict[str, str] = {}
        subset: dict[str, str] = {}
        for index, entry in enumerate(outputs, start=1):
            source[f"r{index}"] = str(entry.get("source"))
            subset[f"r{index}"] = str(entry.get("pilot"))
        payload = {
            "schema_version": 1,
            "purpose": "subset -> full-source lineage for production input binding",
            "sample_id": "pilot",
            "fraction": 0.10,
            "samples": [
                {
                    "sample_id": "pilot",
                    "source": source,
                    "subset": subset,
                    "fraction": 0.10,
                    "paired_sampling": len(outputs) == 2,
                }
            ],
        }
        path = pretest_dir / "source_mapping.yaml"
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(".yaml.part")
        temporary.write_text(yaml.safe_dump(payload, allow_unicode=True, sort_keys=False), encoding="utf-8")
        os.replace(temporary, path)
        return str(path)

    def _write_effective_resources(self, registry) -> None:
        """Persist the effective registry bindings to diagnostics/effective_resources.yaml.

        Best-effort: a write failure must never break the run. The snapshot makes a
        registry-vs-skill mismatch visible (conda run -n vs -p, or a CWD-relative
        Database/ path) before execution, which is the root cause of the genomad /
        CheckV repair loop.
        """
        if registry is None or not hasattr(registry, "effective_resources"):
            return
        root_value = os.environ.get("MICROBIOME_RESULTS_DIR") or getattr(self, "path", None)
        if not root_value:
            return
        try:
            import yaml

            payload = registry.effective_resources()
            path = Path(root_value) / "diagnostics" / "effective_resources.yaml"
            path.parent.mkdir(parents=True, exist_ok=True)
            temporary = path.with_suffix(".yaml.part")
            temporary.write_text(yaml.safe_dump(payload, allow_unicode=True, sort_keys=False), encoding="utf-8")
            os.replace(temporary, path)
        except Exception:
            pass

    def _update_plan_resource_blockers(self, plan: str) -> None:
        """Refresh deterministic missing-database blockers for the current plan."""
        if self._sra_acquisition_allowed():
            self._pending_data_acquisitions = ["sra-runs"] if planned_sra_data_acquisition(plan) else []
        else:
            self._pending_data_acquisitions = []
        registry = getattr(self, "resource_skill_registry", None)
        if registry is None:
            self._pending_missing_databases = []
            self._pending_database_acquisitions = []
            return
        try:
            registry.reload()
            missing = registry.referenced_missing_databases(plan)
            proposed = (
                registry.planned_database_acquisitions(plan)
                if hasattr(registry, "planned_database_acquisitions")
                else ResourceSkillRegistry.planned_database_acquisitions(plan)
            )
            itemized = {
                resource_id
                for resource_id in proposed
                if registry.get_skill("database", resource_id.partition(":")[0]).metadata.get("itemized")
            }
            self._pending_database_acquisitions = [
                resource_id for resource_id in dict.fromkeys([*missing, *sorted(itemized)]) if resource_id in proposed
            ]
            self._pending_missing_databases = [resource_id for resource_id in missing if resource_id not in proposed]
        except Exception:
            self._pending_missing_databases = []
            self._pending_database_acquisitions = []

    @staticmethod
    def _execution_event(message: BaseMessage) -> dict | None:
        content = A1._message_text(message)
        if not content or content.lower() in ("none", "null", "undefined"):
            return None

        solution = re.search(r"<solution>(.*?)</solution>", content, re.DOTALL | re.IGNORECASE)
        if solution:
            result = solution.group(1).strip()
            return {"type": "result", "content": result} if result else None

        observation = re.search(r"<observation>(.*?)</observation>", content, re.DOTALL | re.IGNORECASE)
        if observation:
            result = observation.group(1).strip()
            return {"type": "observation", "content": result} if result else None

        if isinstance(message, HumanMessage):
            return None

        execute = re.search(r"<execute>(.*?)</execute>", content, re.DOTALL | re.IGNORECASE)
        if execute:
            rationale = content[: execute.start()].strip()
            code = A1._sanitize_execute_code(execute.group(1))
            language = "python"
            display_code = code
            if code.startswith("#!BASH") or code.startswith("#!CLI"):
                language = "bash"
                display_code = re.sub(r"^#!(?:BASH|CLI)\s*", "", code, count=1).strip()
            elif code.startswith("#!R"):
                language = "r"
                display_code = re.sub(r"^#!R\s*", "", code, count=1).strip()
            rationale = re.sub(
                r"(?im)^(\s*)(?:step\s*\d+|步骤\s*\d+|第\s*[一二三四五六七八九十百0-9]+\s*步)\s*[:：.)-]*\s*",
                r"\1",
                rationale,
            )
            display_code = re.sub(
                r"(?im)^(\s*#\s*)(?:step\s*\d+|步骤\s*\d+|第\s*[一二三四五六七八九十百0-9]+\s*步)\s*[:：.)-]*\s*",
                r"\1",
                display_code,
            )
            operation = infer_operation(code, rationale)
            visible_progress = progress_event(0, operation)
            details = f"具体执行命令 / Specific commands:\n```{language}\n{display_code}\n```"
            explanation = visible_progress["content"]
            supplemental = re.sub(
                r"(?im)^\s*(?:【?(?:当前步骤|操作|任务|目的|目标|原因|依据|目标目录|输出目录|保存位置)】?)"
                r"\s*[:：].*$",
                "",
                rationale,
            ).strip()
            if supplemental:
                explanation = f"{explanation}\n补充说明：{supplemental} / Supplementary note: {supplemental}"
            return {
                "type": "action",
                "content": f"{explanation}\n\n{details}",
                "progress": visible_progress["progress"],
                "details": details,
            }

        return {"type": "status", "content": content}

    def _stream_execution(self, phase: str) -> Generator[dict, None, None]:
        """Run one confirmed phase and retain whether its real marker was observed."""
        task = self._pending_task or ""
        plan = self._pending_plan or ""
        self.critic_count = 0
        self.user_task = task
        self._execution_phase = phase
        self._acquisition_only_completed = False
        # 记录本阶段开始前的执行历史长度，供试跑剧本只收录本阶段命令
        exec_start = len(getattr(self, "_execution_results", []) or [])

        task_operation = OperationInfo(
            "task",
            f"执行{'小数据试跑' if phase == 'pilot' else '全量分析'} / Running {'pilot (small-data end-to-end)' if phase == 'pilot' else 'full analysis'}",
            "按用户确认的方案完成数据准备、分析和结果验收 / Complete data preparation, analysis, and result acceptance per the user-confirmed plan",
            "统一显示进度可以让环境安装、数据下载和长时间分析过程可追踪 / Unified progress display makes environment installation, data downloads, and long analyses trackable",
            os.environ.get("MICROBIOME_RESULTS_DIR", ""),
        )
        task_percent = 0

        if self.use_tool_retriever:
            selected_resources_names = self._prepare_resources_for_retrieval(task)
            self.update_system_prompt_with_selected_resources(selected_resources_names)

        self.log = []
        yield {
            "type": "status",
            "content": (
                "方案已确认。正在按 resource skill 检查输入、独立软件环境和本地数据库。 / Plan confirmed. Checking inputs, isolated software environments and local databases via resource skills."
                + (
                    "\n只获取方案中明确标记的缺失数据库，并仅获取已授权的代表性 SRA pilot run，完成验证后再运行端到端小数据试跑。 / Only fetch marked missing databases and the authorized representative SRA pilot run, then run the end-to-end pilot."
                    if phase == "pilot"
                    else "\n小数据验证已通过；正在续传已审核的剩余 SRA runs，并使用验证后的命令处理全量数据。 / Pilot passed; resuming the reviewed remaining SRA runs and processing the full data with validated commands."
                )
            ),
        }
        yield progress_event(task_percent, task_operation, detail="开始解析已确认方案和本地资源状态 / Starting to parse the confirmed plan and local resource status")

        resource_guidance = ""
        preparation_context = []
        registry = getattr(self, "resource_skill_registry", None)
        pending_data = list(getattr(self, "_pending_data_acquisitions", []))
        if phase == "pilot" and registry is not None and getattr(self, "auto_install", True):
            software_ids = SoftwareEnvironmentRunner.planned_software_ids(plan)
            extra_ids = SoftwareEnvironmentRunner.plan_environment_software_ids(registry, plan)
            software_ids = list(dict.fromkeys([*software_ids, *extra_ids]))
            if software_ids:
                project_root = Path(__file__).resolve().parents[2]
                custom_roots = [
                    root
                    for root in getattr(registry, "skill_roots", [])
                    if root != Path(__file__).resolve().parents[1] / "resource_skills"
                ]
                tool_resolver = ToolResolver(
                    project_root,
                    phase="BOOTSTRAP",
                    approved_tools=set(software_ids),
                    skill_registry=registry,
                    skill_root=custom_roots[-1] if custom_roots else None,
                )
                for index, software_id in enumerate(software_ids, start=1):
                    task_percent = max(task_percent, round(5 + 15 * (index - 1) / len(software_ids)))
                    skill = registry.find_skill("software", software_id)
                    environment = str(skill.metadata.get("environment") or "(自动解析 / auto-resolved)") if skill else "(自动解析 / auto-resolved)"
                    operation = OperationInfo(
                        "environment",
                        f"检查并准备软件环境 {environment}（{software_id}） / Checking and preparing software environment {environment} ({software_id})",
                        f"保证后续分析能够调用 {software_id} / Ensure later analysis can invoke {software_id}",
                        "该软件已被写入确认方案；缺失时自动创建独立环境，存在但不完整时自动修复\nThis software is in the confirmed plan; a dedicated environment is auto-created when missing and auto-repaired when incomplete",
                        str(environment),
                    )
                    yield progress_event(task_percent, operation, detail="正在检查环境和可执行文件 / Checking the environment and executable")
                    try:
                        binding = tool_resolver.resolve(software_id)
                        resolution_error = ""
                    except Exception as error:
                        binding = None
                        resolution_error = f"{type(error).__name__}: {error}"
                    completed_percent = round(5 + 15 * index / len(software_ids))
                    yield progress_event(
                        completed_percent,
                        operation,
                        status="completed" if binding is not None else "failed",
                        detail=(
                            f"已解析并验证：{binding.executable} / Resolved and verified: {binding.executable}"
                            if binding is not None
                            else f"资源解析失败：{resolution_error} / Resource resolution failed: {resolution_error}"
                        ),
                    )
                    task_percent = completed_percent
                    if binding is None:
                        blocked = (
                            f"{self.RESOURCE_BLOCKED_MARKER}\nsoftware: {software_id}\n"
                            f"environment: {environment}\nstatus: unresolved\nerror: {resolution_error}"
                        )
                        self._pilot_summary = blocked[-8000:]
                        self._last_execution_verified = False
                        yield {"type": "observation", "content": blocked}
                        return
                    invoke = (
                        f"conda run -p {binding.environment_prefix} --no-capture-output"
                        if binding.environment_prefix
                        else binding.executable
                    )
                    preparation_context.append(
                        f"- software {software_id}: family={binding.software_family}; status=READY; "
                        f"executable={binding.executable}; invoke={invoke}; skill={binding.skill_path}; "
                        f"source={binding.source}; installed={binding.installed}"
                    )
        if "sra-runs" in pending_data:
            data_runner = SRADataAcquisitionRunner(
                registry,
                data_root=DEFAULT_DATA_ROOT,
                timeout_seconds=max(int(getattr(self, "timeout_seconds", 3600)), 604_800),
            )
            preview = data_runner.preview(plan, phase)
            if preview.commands:
                task_percent = max(task_percent, 20)
                sra_operation = OperationInfo(
                    "download",
                    f"下载 {phase} 范围内的 SRA 输入数据 / Downloading SRA input data for the {phase} stage",
                    "准备已审核的测序 reads 供后续质控和分析 / Prepare the reviewed sequencing reads for downstream QC and analysis",
                    "确认方案包含 SRA 数据获取授权，且本地目标尚未完整就绪 / The confirmed plan authorizes SRA data acquisition and the local target is not yet fully ready",
                    str(data_runner.data_root / "sra"),
                )
                yield progress_event(task_percent, sra_operation, detail="将使用断点续传并校验下载结果 / Will use resumable download and validate the results")
                yield {
                    "type": "action",
                    "content": (
                        f"正在准备 {phase} 范围内获准的 SRA 输入数据。\n"
                        f"Preparing the authorized SRA input data for the {phase} stage.\n\n"
                        "具体执行命令 / Specific commands:\n```python\n" + "\n".join(preview.commands) + "\n```"
                    ),
                }
            result = data_runner.prepare(plan, phase)
            observation = "\n".join(
                [
                    "data acquisition: sra-runs",
                    f"stage: {phase}",
                    f"status: {result.status}",
                    f"path: {result.path or '(not created)'}",
                    f"message: {result.message}",
                    f"manifest: {result.manifest or '(not written)'}",
                    *(f"command: {command}" for command in result.commands),
                    result.output[-6000:] if result.output else "",
                ]
            ).strip()
            if result.success:
                task_percent = max(task_percent, 30)
                yield progress_event(
                    task_percent,
                    sra_operation,
                    status="completed",
                    detail=f"SRA 数据已写入并验证：{result.path} / SRA data written and validated: {result.path}",
                )
                preparation_context.append(
                    f"- SRA stage={phase}: status={result.status}; path={result.path}; "
                    f"manifest={result.manifest or '(not written)'}"
                    + (f"; commands: {' && '.join(result.commands[:3])[:400]}" if result.commands else "")
                )
                yield {"type": "observation", "content": observation}
            else:
                blocked = f"{self.RESOURCE_BLOCKED_MARKER}\n{observation}"
                self._pilot_summary = blocked[-8000:]
                self._last_execution_verified = False
                yield {"type": "observation", "content": blocked}
                return
        pending_acquisitions = []
        if phase == "pilot" and registry is not None:
            pending_acquisitions = list(getattr(self, "_pending_database_acquisitions", []))
            if pending_acquisitions:
                runner = DatabaseAcquisitionRunner(
                    registry,
                    project_root=Path(__file__).resolve().parents[2],
                    timeout_seconds=max(int(getattr(self, "timeout_seconds", 3600)), 604_800),
                )
                for resource_id in pending_acquisitions:
                    resource_index = pending_acquisitions.index(resource_id) + 1
                    database_percent = round(20 + 10 * (resource_index - 1) / len(pending_acquisitions))
                    database_skill = registry.get_skill("database", resource_id.partition(":")[0])
                    db_operation = OperationInfo(
                        "download",
                        f"获取并本地化数据库 {resource_id} / Acquiring and localizing database {resource_id}",
                        "准备分析软件要求的本地数据库格式 / Prepare the local database format required by the analysis software",
                        "确认方案已授权该数据库，但其 READY 标记尚未满足 / The confirmed plan authorizes this database, but its READY marker is not yet satisfied",
                        str(registry.db_root / str(database_skill.metadata["folder"])),
                    )
                    preview = runner.preview(resource_id, plan)
                    if preview.commands:
                        commands = "\n".join(preview.commands)
                        yield progress_event(
                            max(task_percent, database_percent),
                            db_operation,
                            detail="如下载环境缺失，将先自动创建对应独立环境 / If the download environment is missing, a dedicated environment will be auto-created first",
                        )
                        yield {
                            "type": "action",
                            "content": (
                                f"正在准备数据库 {resource_id}。本地化命令仅在下载后仍未满足就绪标记时执行。\n"
                                f"Preparing database {resource_id}. Localization commands run only when the ready marker is still unsatisfied after download.\n\n"
                                f"具体执行命令 / Specific commands:\n```bash\n{commands}\n```"
                            ),
                        }
                    result = runner.prepare(resource_id, plan)
                    command_details = []
                    for command in result.commands:
                        detail = f"$ {command.command}\nexit code: {command.returncode}"
                        output = "\n".join(part for part in (command.stdout.strip(), command.stderr.strip()) if part)
                        if output:
                            detail += f"\n{output[-4000:]}"
                        command_details.append(detail)
                    observation = "\n\n".join(
                        [
                            f"database: {resource_id}",
                            f"status: {result.status}",
                            f"path: {result.path}",
                            f"message: {result.message}",
                            f"missing markers: {', '.join(result.missing) if result.missing else '(none)'}",
                            f"acquisition manifest: {result.manifest or '(not written)'}",
                            *command_details,
                        ]
                    )
                    if result.success:
                        task_percent = max(task_percent, round(20 + 10 * resource_index / len(pending_acquisitions)))
                        yield progress_event(
                            task_percent,
                            db_operation,
                            status="completed",
                            detail=f"数据库已通过就绪性检查：{result.path} / Database passed the readiness check: {result.path}",
                        )
                        preparation_context.append(
                            f"- database {resource_id}: status={result.status}; path={result.path}; "
                            f"manifest={result.manifest or '(not written)'}; missing markers="
                            f"{', '.join(result.missing) if result.missing else '(none)'}"
                        )
                        yield {"type": "observation", "content": observation}
                    else:
                        blocked = f"{self.RESOURCE_BLOCKED_MARKER}\n{observation}"
                        self._pilot_summary = blocked[-8000:]
                        self._last_execution_verified = False
                        yield {"type": "observation", "content": blocked}
                        return

        acquisition_only = self._is_resource_acquisition_only_task(task, [*pending_data, *pending_acquisitions])
        if acquisition_only and preparation_context:
            marker = self.PILOT_VERIFIED_MARKER if phase == "pilot" else self.RESULT_VERIFIED_MARKER
            verified = "\n".join(
                [
                    "acquisition-only validation: complete",
                    *preparation_context,
                    "validation basis: every confirmed acquisition returned success and passed its manifest, "
                    "expected-record, non-empty-file, checksum, and resource readiness checks applicable to "
                    "that downloader.",
                    self.PREFLIGHT_MARKER,
                    marker,
                ]
            )
            self._pilot_summary = verified[-8000:]
            self._last_execution_verified = True
            # SRA remains intentionally staged: pilot success authorizes asking for
            # full transfer, while database/reference acquisition is complete now.
            self._acquisition_only_completed = phase == "full" or not pending_data
            yield progress_event(100, task_operation, status="completed", detail="数据获取和就绪性验证全部完成 / Data acquisition and readiness validation all complete")
            yield {"type": "observation", "content": verified}
            return

        if registry is not None and hasattr(registry, "detailed_context"):
            try:
                registry.reload()
                resource_guidance = registry.detailed_context(f"{task}\n{plan}", max_skills=12, max_chars=42000)
            except Exception:
                resource_guidance = ""
        if preparation_context:
            resource_guidance = "\n".join(
                [
                    "已由确定性运行器完成并验证的资源准备（不要重复下载；直接使用这些路径）：",
                    *preparation_context,
                    "",
                    resource_guidance,
                ]
            ).strip()
        # Persist the effective registry bindings so a registry-vs-skill mismatch
        # (e.g. conda run -n vs -p, or a CWD-relative Database/ path) is visible
        # before the model runs, instead of surfacing only as a repair loop.
        self._write_effective_resources(registry)
        subset_context = ""
        if phase == "pilot":
            # Deterministic 10% subset + lineage, created by the framework rather
            # than guessed by the model. The LLM then processes the subset paths
            # verbatim, so the freeze step can bind full data from source_mapping.
            subset_context = self._prepare_deterministic_subset()
        execution_prompt = self._build_execution_prompt(
            task,
            plan,
            resource_guidance,
            phase=phase,
            pilot_summary=self._pilot_summary,
            pilot_playbook=self._pilot_playbook if phase == "full" else "",
            subset_context=subset_context,
        )
        inputs = {"messages": [HumanMessage(content=execution_prompt)], "next_step": None}
        config = {
            "recursion_limit": 10000,
            "configurable": {"thread_id": f"{id(self)}-{phase}-{datetime.now().timestamp()}"},
        }
        final_state = None
        last_visible = None
        phase_summary = ""
        active_operation: OperationInfo | None = None
        active_percent = max(task_percent, 30)
        completion_progress_emitted = False

        yield progress_event(active_percent, task_operation, detail="资源准备完成，开始执行分析与验收命令 / Resource preparation complete; starting analysis and acceptance commands")

        for state in self.app.stream(inputs, stream_mode="values", config=config):
            final_state = state
            message = state["messages"][-1]
            self.log.append(pretty_print(message, printout=False))
            event = self._execution_event(message)
            if event and event["content"] != last_visible:
                if event["type"] == "action" and event.get("progress"):
                    metadata = event["progress"]
                    active_operation = OperationInfo(
                        metadata["kind"],
                        metadata["title"],
                        metadata["purpose"],
                        metadata["reason"],
                        metadata.get("target", ""),
                    )
                    if active_operation.kind == "verification":
                        active_percent = max(active_percent, 90)
                    elif active_operation.kind in {"environment", "software", "download"}:
                        active_percent = max(active_percent, 35)
                    else:
                        active_percent = min(85, max(40, active_percent + 10))
                    event["content"] = (
                        progress_event(active_percent, active_operation)["content"] + "\n\n" + event.get("details", "")
                    )
                elif event["type"] == "observation" and active_operation is not None:
                    if (
                        self.PILOT_VERIFIED_MARKER in event["content"]
                        or self.RESULT_VERIFIED_MARKER in event["content"]
                    ):
                        active_percent = 100
                    elif self.PREFLIGHT_MARKER in event["content"]:
                        active_percent = max(active_percent, 30)
                    else:
                        active_percent = min(95, active_percent + 5)
                    yield progress_event(
                        active_percent,
                        active_operation,
                        status="failed" if self._observation_failed(event["content"]) else "completed",
                        detail="已收到真实命令输出，正在检查退出状态和结果 / Real command output received; checking exit status and results",
                    )
                last_visible = event["content"]
                if phase == "full" and event["type"] == "result" and active_percent == 100:
                    yield progress_event(
                        100,
                        task_operation,
                        status="completed",
                        detail="当前阶段的输出和关键统计已经验收 / The current stage's outputs and key statistics have been accepted",
                    )
                    completion_progress_emitted = True
                if phase == "pilot" and event["type"] == "result":
                    phase_summary = event["content"]
                    yield {"type": "status", "content": event["content"]}
                else:
                    yield event

        if getattr(self, "awaiting_download_confirmation", False):
            # 下载确认门已触发：本次执行被暂停，等待用户确认后重新进入；
            # 不做试跑成败判定，避免污染 _pilot_summary。
            return

        self._conversation_state = final_state
        messages = final_state.get("messages", []) if final_state else []
        observations = self._observation_texts(messages)
        phase_results = list(getattr(self, "_execution_results", []) or [])[exec_start:]
        self._last_execution_verified, verification_note = self._phase_verification(
            messages, observations, phase, phase_results
        )
        if self._last_execution_verified and verification_note:
            yield {"type": "status", "content": f"验收说明：{verification_note} / Acceptance note: {verification_note}"}
        if self._last_execution_verified and not completion_progress_emitted:
            yield progress_event(100, task_operation, status="completed", detail="当前阶段的输出和关键统计已经验收 / The current stage's outputs and key statistics have been accepted")
        if phase == "pilot" and phase_summary:
            self._pilot_summary = phase_summary
        elif phase == "pilot" and observations:
            self._pilot_summary = observations[-1][-4000:]

        if phase == "pilot" and self._last_execution_verified:
            # 试跑成功：从真实执行记录生成"试跑成功剧本"，供全量阶段直接复用
            self._pilot_playbook = self._build_pilot_playbook(preparation_context, exec_start)
            if self._pilot_playbook:
                try:
                    playbook_path = Path(os.environ.get("MICROBIOME_RESULTS_DIR", "") or ".") / "pilot_playbook.md"
                    playbook_path.parent.mkdir(parents=True, exist_ok=True)
                    playbook_path.write_text(self._pilot_playbook, encoding="utf-8")
                    yield {
                        "type": "status",
                        "content": (
                            f"试跑成功剧本已生成并保存：{playbook_path}。"
                            "全量执行将直接复用其中的成功命令、数据下载路径、数据库路径和软件参数，不再重新试错。\n"
                            f"The successful-pilot playbook has been generated and saved: {playbook_path}. The full run will reuse "
                            "its successful commands, data download paths, database paths, and software parameters directly, without re-trying."
                        ),
                    }
                except Exception:
                    pass  # 剧本落盘失败不影响主流程

    def _build_pilot_playbook(self, preparation_lines: list | None = None, exec_start: int = 0) -> str:
        """Compile the pilot's verified commands and resolved resource paths into a reusable playbook.

        Built once the pilot prints PILOT_VERIFIED: keeps only commands whose real observation
        did not fail (retry-corrected versions therefore win), labels pilot-only preparation
        steps so the full run skips them, marks subset-based commands for input-path
        substitution, and records the deterministic runner paths (data download locations /
        database paths) for direct reuse.
        """
        entries = getattr(self, "_execution_results", []) or []
        commands: list[str] = []
        labels: list[str] = []
        seen: set[str] = set()
        prep_tokens = ("seqtk sample", "subsample", "subset", "采样", "抽取子集")
        artifact_tokens = (*A1._INPUT_AUDIT_ARTIFACT_TOKENS, "pilot_run", "pilot_")
        for entry in entries[exec_start:]:
            if not isinstance(entry, dict) or entry.get("failed") is not False:
                continue
            code = (entry.get("code") or "").strip()
            if not code:
                triggering = entry.get("triggering_message", "") or ""
                match = re.search(r"<execute>(.*?)</execute>", triggering, re.DOTALL | re.IGNORECASE)
                if not match:
                    continue
                code = A1._sanitize_execute_code(match.group(1)).strip()
            if not code or code in seen:
                continue
            seen.add(code)
            lowered = code.lower()
            if any(token in lowered for token in prep_tokens):
                labels.append("（试跑专用准备步骤：全量阶段直接跳过） / (Pilot-only preparation step: skip it directly in the full stage)")
            elif any(token in lowered for token in artifact_tokens):
                labels.append(
                    "（试跑输入为子集：全量阶段把子集路径替换为输入自检中 OK 的完整数据路径、输出目录换新后原样复用）\n"
                    "(The pilot input was a subset: in the full stage, replace the subset paths with the OK complete-data paths "
                    "from the input self-check, use new output directories, and reuse the commands as-is)"
                )
            else:
                labels.append("")
            commands.append(code[:2000])
        if not commands and not preparation_lines:
            return ""
        parts = ["# 试跑成功剧本（框架从试跑真实执行记录自动提取，供全量阶段直接复用） / Successful-Pilot Playbook (automatically extracted from the pilot's real execution records for direct reuse in the full stage)"]
        if preparation_lines:
            parts.append("## 已就绪资源（数据下载落盘路径 / 数据库路径，全量阶段直接沿用，禁止重新下载）\n## Ready Resources (data download paths / database paths; reuse directly in the full stage, no re-download)")
            parts.extend(preparation_lines)
        if commands:
            parts.append("## 试跑最终验证成功的命令（按执行顺序；曾重试的步骤以最后成功版本为准）\n## Commands Finally Verified in the Pilot (in execution order; retried steps use the last successful version)")
            for index, code in enumerate(commands[:40], start=1):
                label = f" {labels[index - 1]}" if labels[index - 1] else ""
                parts.append(f"{index}.{label}\n```\n{code}\n```")
        parts.append(
            "## 全量复用要求：仅将输入路径替换为输入自检中 OK 的完整数据路径、输出目录换新；"
            "环境名、软件参数、数据库路径原样复用；标注“试跑专用”的步骤直接跳过；"
            "严禁重新下载数据、严禁重装环境、严禁重新试错。\n"
            "## Full-Run Reuse Requirements: only replace the input paths with the OK complete-data paths from the input "
            "self-check and use new output directories; reuse environment names, software parameters, and database paths "
            "verbatim; skip steps labeled “pilot-only”; never re-download data, reinstall environments, or re-try from scratch."
        )
        return "\n\n".join(parts)[:12000]

    def _stream_confirmed_execution(self) -> Generator[dict, None, None]:
        """Backward-compatible entry for the first confirmed, pilot-only execution."""
        yield from self._stream_execution("pilot")

    def _pilot_failure_message(self) -> str:
        """Build a detailed pilot-failure report: exactly where it failed and how to fix it."""
        summary = (getattr(self, "_pilot_summary", "") or "").strip()
        self._record_analysis_experience(
            "failed", "小试未通过；见错误点与修正建议，避免在同类任务中重复该失败路径"
        )

        # The last executed command approximates the failing one.
        failing_command = ""
        for entry in reversed(getattr(self, "_execution_results", []) or []):
            triggering = entry.get("triggering_message", "") if isinstance(entry, dict) else ""
            match = re.search(r"<execute>(.*?)</execute>", triggering, re.DOTALL | re.IGNORECASE)
            if match:
                failing_command = A1._sanitize_execute_code(match.group(1))[-800:]
                break

        parts = ["小数据试跑未获得真实验收标记，当前不会进入全量执行。\nThe pilot did not produce a real acceptance marker, so the full run will not start."]
        if self.RESOURCE_BLOCKED_MARKER in summary:
            detail = summary.split(self.RESOURCE_BLOCKED_MARKER, 1)[1].strip()
            parts.append(f"【错误点：资源阻塞】\n{detail[-1500:]}\n[Error point: resource blocked]")
            if failing_command:
                parts.append(f"【最后执行的命令】\n{failing_command}\n[Last executed command]")
            lowered_detail = detail.lower()
            if "software:" in lowered_detail:
                parts.append(
                    "【修正建议】这是软件环境解析失败（不是数据库缺失）。按上面的 error 定位并修复："
                    "确认该软件的 SKILL 声明的 conda 环境名/前缀与实际安装一致；若可执行文件存在但"
                    "version 自检失败，检查该软件是否有 `--version`（部分工具如 bwa 需要裸执行才输出版本，"
                    "框架已支持这种探测）。修复环境或 SKILL 后重新“确认执行”，框架会复用已装好的环境，不会重复安装。\n"
                    "[Fix suggestion] This is a software-environment resolution failure (not a missing database). Diagnose and fix "
                    "it from the error above: confirm the conda environment name/prefix declared by the software's SKILL matches the "
                    "actual installation; if the executable exists but the version self-check fails, check whether the tool supports "
                    "`--version` (some tools such as bwa only print the version when run bare; the framework supports this probing). "
                    "After fixing the environment or SKILL, reply “确认执行” again; the framework reuses installed environments and will not reinstall."
                )
            elif "database:" in lowered_detail:
                parts.append(
                    "【修正建议】在方案中为缺失的数据库/资源补上 `[MICROBIOME_DB_ACQUISITION:<database-id>]` 下载标记"
                    "（或改用已 READY 的本地数据库、修正数据库目录路径），说明修改点后重新确认执行。\n"
                    "[Fix suggestion] Add the `[MICROBIOME_DB_ACQUISITION:<database-id>]` download marker to the plan for the missing "
                    "database/resource (or switch to a READY local database and fix the database directory path), state the changes, and confirm execution again."
                )
            else:
                parts.append(
                    "【修正建议】这是输入/数据获取失败。核对上面 error 中的来源、目标目录与命令，"
                    "修正后重新确认执行。\n"
                    "[Fix suggestion] This is an input/data-acquisition failure. Check the source, target directory, and command "
                    "in the error above, fix them, and confirm execution again."
                )
        elif summary:
            parts.append(f"【错误点】\n{summary[-1500:]}\n[Error point]")
            if failing_command:
                parts.append(f"【最后执行的命令】\n{failing_command}\n[Last executed command]")
            parts.append(f"【修正建议】\n{self._pilot_fix_suggestions(summary)}")
        else:
            parts.append("【错误点】执行代理没有打印验收标记，也未捕获到具体错误输出。\n[Error point] The execution agent did not print the acceptance marker, and no specific error output was captured.")
            if failing_command:
                parts.append(f"【最后执行的命令】\n{failing_command}\n[Last executed command]")
            parts.append("【修正建议】查看上面最后一条命令的真实输出定位问题，在方案中写明修改点后重新确认。\n[Fix suggestion] Inspect the real output of the last command above to locate the problem, write the changes in the plan, and confirm again.")
        parts.append("请根据以上信息修改方案，然后重新确认。\nPlease revise the plan according to the information above, then confirm again.")
        return "\n\n".join(parts)

    @staticmethod
    def _pilot_fix_suggestions(summary: str) -> str:
        """Map the pilot's last error output to concrete fix directions."""
        lowered = summary.lower()
        suggestions = []
        if "invalid syntax" in lowered or "syntaxerror" in lowered:
            suggestions.append(
                "代码格式错误：bash 命令必须以 #!BASH 开头、R 脚本以 #!R 开头；"
                "不要在 <execute> 内使用 ``` 代码围栏或 python/bash 语言标记，修正命令格式后重试。\n"
                "Code-format error: bash commands must start with #!BASH and R scripts with #!R; do not use ``` code fences or "
                "python/bash language markers inside <execute>. Fix the command format and retry."
            )
        if "command not found" in lowered or "not recognized" in lowered:
            suggestions.append(
                "命令不存在：用 `conda run -n <env> <tool> --help` 核对软件是否安装在对应环境；"
                "若未安装，在方案中写明环境名与安装包后重新确认。\n"
                "Command not found: verify the software is installed in the corresponding environment with "
                "`conda run -n <env> <tool> --help`; if it is not installed, state the environment name and packages in the plan and confirm again."
            )
        if re.search(r"output directory .*already exists", lowered) or (
            "already exists" in lowered and re.search(r"(?:^|\s)-o\s|\b--out", lowered)
        ):
            suggestions.append(
                "输出目录已存在：这是上一次（失败）运行的残留，megahit/SPAdes 等工具不会覆盖已有输出目录。"
                "输出目录名必须每次都用运行时动态生成（`ASM_OUT=\".../megahit_$(date +%s%N)\"` 或 `mktemp -d`），"
                "严禁把固定的旧目录名硬编码进脚本；先 `rm -rf <旧输出目录>`（或换全新名）再重试，"
                "严禁原样重复同一条命令。\n"
                "Output directory already exists: this is residue from the previous (failed) run; tools like megahit/SPAdes do not "
                "overwrite existing output directories. Generate a fresh output-directory name at runtime each time "
                "(`ASM_OUT=\".../megahit_$(date +%s%N)\"` or `mktemp -d`); never hardcode a fixed old directory name in the script; "
                "run `rm -rf <old-output-dir>` first (or use a brand-new name) and retry; never repeat the same command verbatim."
            )
        if (
            "not a conda environment" in lowered
            or "environmentlocationnotfound" in lowered
            or "could not find conda environment" in lowered
        ):
            suggestions.append(
                "conda 环境不存在或已损坏：用 `mamba create -y -n <env> -c conda-forge -c bioconda <包>` 重建；"
                "若目录已存在但损坏（无 conda-meta），先删除该 envs 下的残留目录再重建；"
                "调取时用绝对前缀 `conda run -p <.../envs/<env>> --no-capture-output <tool> ...`，"
                "避免按名 -n 在不同 conda 根之间解析失败。\n"
                "The conda environment is missing or broken: rebuild it with "
                "`mamba create -y -n <env> -c conda-forge -c bioconda <包>`; if the directory exists but is broken (no conda-meta), "
                "remove the stale directory under envs first and rebuild; invoke it with the absolute prefix "
                "`conda run -p <.../envs/<env>> --no-capture-output <tool> ...` to avoid -n name resolution failing across different conda roots."
            )
        if "no such file or directory" in lowered:
            suggestions.append(
                "文件/目录不存在：先用 ls 核对输入文件的真实位置（原始数据目录见【路径设置】），修正路径后重试。\n"
                "File/directory does not exist: first check the real location of the input files with ls (raw data directory is in "
                "[Path Settings]), fix the path, and retry."
            )
        if "permission denied" in lowered:
            suggestions.append("权限不足：更换到有写权限的目录（结果应写入【路径设置】的结果目录）或修正文件权限。\nPermission denied: switch to a writable directory (results should go to the results directory in [Path Settings]) or fix file permissions.")
        if "timed out" in lowered or "timeout" in lowered:
            suggestions.append("命令超时：进一步缩小试跑子集，或换用更高效的参数/工具后重试。\nCommand timed out: shrink the pilot subset further, or retry with more efficient parameters/tools.")
        if "out of memory" in lowered or "oom" in lowered or re.search(r"\bkilled\b", lowered):
            suggestions.append("疑似内存不足被杀掉：减小试跑数据量，或为该软件显式设置内存参数。\nLikely killed by insufficient memory: reduce the pilot data volume, or explicitly set memory parameters for the software.")
        if "database" in lowered and ("missing" in lowered or "not found" in lowered):
            suggestions.append("数据库缺失或路径不对：核对数据库目录（见【路径设置】）或在方案中补充下载标记。\nDatabase missing or wrong path: check the database directory (see [Path Settings]) or add the download marker to the plan.")
        if not suggestions:
            suggestions.append("根据上面的真实错误输出修正命令、参数、路径或软件环境，然后重试验证。\nFix the command, parameters, path, or software environment based on the real error output above, then retry and verify.")
        return "\n".join(f"- {item}" for item in suggestions)

    def _post_pilot_events(self) -> Generator[dict, None, None]:
        """Emit the standard events that follow a completed pilot execution stream."""
        if self._acquisition_only_completed:
            message = (
                "数据获取、本地化和就绪性验证已经完成。该确认任务仅要求准备数据，不存在需要再次确认的全量分析阶段。\n"
                "Data acquisition, localization, and readiness validation are complete. This confirmed task only requires preparing "
                "data; there is no full-analysis stage that needs further confirmation."
            )
            self.log.append(message)
            yield {"type": "result", "content": message}
            self._reset_planning_session()
            return
        if self._last_execution_verified:
            self.production_state = "PRETEST_PASSED"
            if getattr(self, "require_frozen_production", False):
                # 小试通过不等于可以请求全量确认：先立即冻结生产清单并通过就绪检查，
                # 只有 PRODUCTION_READY 之后才会向用户展示“是否开始全量执行”。
                yield from self._finalize_pretest_production()
            else:
                # 显式关闭 frozen production 的传统会话回放模式：保留原有确认门。
                self.awaiting_full_confirmation = True
                message = self._production_validation_summary()
                self.production_state = "AWAITING_PRODUCTION_APPROVAL"
                self.log.append(message)
                yield {"type": "plan", "content": message}
        else:
            self.awaiting_plan_confirmation = True
            if self._pilot_summary:
                self._planning_history.append(AIMessage(content=f"小数据试跑未通过，最后诊断：\n{self._pilot_summary}"))
            message = self._pilot_failure_message()
            self.log.append(message)
            yield {"type": "plan", "content": message}

    def _finalize_pretest_production(self) -> Generator[dict, None, None]:
        """Finalize verified pilot facts using the strict pipeline services.

        Previously approved management artifacts may be recovered. Legacy logs
        without a reviewed recovery proposal cannot create user authorization.
        """
        self.production_state = "PRETEST_FINALIZING"
        yield {
            "type": "status",
            "content": (
                "小数据试跑已通过。正在根据本次实际成功运行记录自动整理全量执行流程"
                "（不重新安装软件、不重新下载数据库、不重新规划）..."
                "\nThe pilot passed. Auto-finalizing the full-run workflow from the recorded successful execution (no software reinstall, no database re-download, no re-planning)..."
            ),
        }
        project = self._find_pipeline_project()
        readiness = None
        failure: Exception | None = None
        try:
            if project is not None and project.plan_path.is_file():
                from microbiome.pipeline.finalizer import ValidationFinalizer

                readiness = ValidationFinalizer(project).finalize_pretest()
            else:
                from microbiome.pipeline.synthesize import finalize_successful_pretest

                readiness = finalize_successful_pretest(
                    Path(os.environ.get("MICROBIOME_RESULTS_DIR") or getattr(self, "path", None) or "."),
                    raw_root=os.environ.get("MICROBIOME_DATA_DIR"),
                    db_root=os.environ.get("MICROBIOME_DB_ROOT"),
                )
        except Exception as exc:  # ExecutionFactMissingError / infrastructure
            failure = exc

        if readiness is not None and readiness.get("ready"):
            self._production_controller = None  # reload against the fresh lock
            self._record_analysis_experience(
                "success", "小试通过并完成生产冻结，本次工作流可直接复用于同类任务"
            )
            self.awaiting_full_confirmation = True
            self.production_state = "AWAITING_PRODUCTION_APPROVAL"
            message = self._production_validation_summary()
            self.log.append(message)
            yield {"type": "plan", "content": message}
            return

        self.awaiting_full_confirmation = False
        from microbiome.pipeline.errors import classify_finalization_failure

        category = classify_finalization_failure(failure or RuntimeError("unknown finalization failure"))
        self._last_finalization_failure_category = category.value
        if category.requires_pretest:
            self.production_state = "REVALIDATION_REQUIRED"
            message = self._execution_fact_failure_message(failure)
        else:
            self.production_state = "PRETEST_FINALIZATION_FAILED"
            message = self._management_finalization_failure_message(failure, category.value)
        self.log.append(message)
        yield {"type": "plan", "content": message}

    @staticmethod
    def _management_finalization_failure_message(failure: Exception | None, category: str) -> str:
        detail = str(failure) if failure is not None else "未记录到具体异常 / No specific exception recorded"
        return (
            "小数据生信流程已经验证通过；当前失败发生在管理层，不会重新运行小试分析。\n\n"
            "The pilot bioinformatics workflow was validated; the current failure is at the management layer, so the pilot will not be re-run.\n\n"
            f"【失败类别】{category} / [Failure category] {category}\n"
            f"【失败详情】{detail} / [Failure detail] {detail}\n\n"
            "系统将保留成功命令、软件环境、数据库、科学参数和全部小试产物。"
            "修复路径/清单/元数据/状态/输入绑定后，只重新执行 Finalize。可回复“重试冻结”继续。\n"
            "The system keeps the successful commands, software environments, databases, scientific parameters, and all pilot artifacts. "
            "After fixing paths/manifests/metadata/status/input bindings, only Finalize is re-run. Reply “重试冻结” to continue."
        )

    @staticmethod
    def _execution_fact_failure_message(failure: Exception | None) -> str:
        """Explain — by execution fact, never by YAML filename — why we cannot proceed."""
        from microbiome.pipeline.errors import ExecutionFactMissingError

        if isinstance(failure, ExecutionFactMissingError) and failure.fact == "false_pretest":
            # A claimed pre-test pass was not backed by real execution evidence.
            return (
                "[microbiome-run] 小数据验证状态修正 / Pilot validation status correction\n\n"
                "检查发现此前记录的“小试通过”缺少真实运行证据。\n"
                "The check found that the previously recorded “pilot passed” lacks real execution evidence.\n\n"
                f"【详情】{failure} / [Detail] {failure}\n\n"
                "已有软件、Conda 环境、数据库和下载资源全部保留并继续复用；\n"
                "系统将重新执行真正的 10% 数据验证（不会重新安装正常软件、不会重新下载 READY 数据库）。\n"
                "All existing software, Conda environments, databases, and downloaded resources are retained and reused; "
                "the system will re-run the real 10% data validation (without reinstalling working software or re-downloading READY databases)."
            )

        parts = ["小数据执行成功，但暂时无法整理出完整的全量执行流程。\nThe pilot executed successfully, but a complete full-run workflow cannot be assembled yet."]
        if isinstance(failure, ExecutionFactMissingError):
            parts.append(f"【无法确定的执行事实】{failure} / [Undeterminable execution fact] {failure}")
            if failure.requires_pretest:
                parts.append(
                    "该事实属于软件/数据库/科学参数或 Pipeline 的实际验证证据；只需针对该步骤重新做一次小数据验证"
                    "（复用现有资源，不需要重装或重新下载），成功后系统会自动完成整理。\n"
                    "This fact is actual validation evidence for software/database/scientific parameters or the Pipeline; only re-run "
                    "a small-data validation for that step (reusing existing resources, no reinstall or re-download). Once it succeeds, "
                    "the system automatically completes the finalization."
                )
        elif failure is not None:
            parts.append(f"【失败详情】{failure} / [Failure detail] {failure}")
        parts.append(
            "小试结果与结构化执行账本（pre_test_run/pipeline/execution_ledger.jsonl）均已保留。"
            "请说明如何修正相关步骤，或直接重新试跑。\n"
            "The pilot results and the structured execution ledger (pre_test_run/pipeline/execution_ledger.jsonl) are preserved. "
            "Please explain how to fix the relevant steps, or simply re-run the pilot."
        )
        return "\n\n".join(parts)

    def _handle_download_reply(self, prompt) -> Generator[dict, None, None]:
        """下载确认门开启时处理用户回复：全部/部分下载、跳过或重问。\n        Handle the user's reply while the download confirmation gate is open: approve all/part, skip, or re-ask."""
        items = list(getattr(self, "_pending_download_items", []) or [])
        status, approved = parse_download_reply(prompt, items)
        if status == "unclear" or (status == "approved" and not approved):
            notice = getattr(self, "_pending_download_notice", "") or format_download_inquiry(
                items, "", getattr(self, "_execution_phase", "pilot") or "pilot"
            )
            yield {"type": "plan", "content": notice + "\n\n（未能理解您的回复，请按以上格式明确回复。）\n(We could not understand your reply; please reply explicitly in the format above.)"}
            return

        self.awaiting_download_confirmation = False
        self._pending_download_items = []

        if status == "declined":
            self.awaiting_plan_confirmation = True
            message = (
                "已跳过本次下载请求，未获取任何网络数据（整体计划快照见上方保存路径）。"
                "您可以修改方案改用本地已 READY 的资源，或调整分析步骤后重新“确认执行”。\n"
                "This download request was skipped and no network data was fetched (the overall plan snapshot is at the saved path above). "
                "You can modify the plan to use local READY resources, or adjust the analysis steps and reply “确认执行” again."
            )
            self.log.append(message)
            yield {"type": "plan", "content": message}
            return

        approved_tokens = set(getattr(self, "_runtime_approved_downloads", set()) or set())
        approved_tokens.update(token for item in approved for token in item.tokens)
        self._runtime_approved_downloads = approved_tokens
        labels = "；".join(item.label for item in approved)
        yield {
            "type": "status",
            "content": (
                f"已确认下载 {len(approved)} 项：{labels}\n"
                f"Confirmed downloading {len(approved)} item(s): {labels}\n"
                "现在开始下载（实时显示进度与网速，停滞自动重试、断点续传），完成后自动继续执行原计划。\n"
                "Downloading now (progress and speed shown live; stalled transfers auto-retry with resumable download); "
                "the original plan resumes automatically when finished."
            ),
        }
        yield from self._stream_execution("pilot")
        if getattr(self, "awaiting_download_confirmation", False):
            # 执行中又出现新的未确认下载项：再次展示清单并暂停
            yield {"type": "plan", "content": self._pending_download_notice}
            return
        yield from self._post_pilot_events()

    def _save_plan_snapshot(self) -> str:
        """下载确认前自动保存整体计划快照，返回文件路径。\n        Automatically save an overall plan snapshot before download confirmation and return the file path."""
        plans_dir = os.path.join(getattr(self, "path", ".") or ".", "plans")
        os.makedirs(plans_dir, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(plans_dir, f"plan_{stamp}.md")
        items = getattr(self, "_pending_download_items", []) or []
        lines = [
            "# Microbiome 整体计划快照（下载确认前自动保存） / Microbiome Overall Plan Snapshot (auto-saved before download confirmation)",
            "",
            f"- 保存时间：{datetime.now().isoformat(timespec='seconds')} / Saved at: {datetime.now().isoformat(timespec='seconds')}",
            f"- 当前阶段：{getattr(self, '_execution_phase', None) or 'pilot'} / Current stage: {getattr(self, '_execution_phase', None) or 'pilot'}",
            "",
            "## 任务 / Task",
            getattr(self, "_pending_task", "") or "(未记录 / not recorded)",
            "",
            "## 计划 / Plan",
            getattr(self, "_pending_plan", "") or "(未记录 / not recorded)",
            "",
            "## 待确认下载 / Downloads Awaiting Confirmation",
            *(f"- {item.label}" for item in items),
            "",
        ]
        try:
            with open(path, "w", encoding="utf-8") as handle:
                handle.write("\n".join(lines))
        except OSError:
            return ""
        return path

    def go(self, prompt):
        """Advance one turn of the plan-discuss-confirm-execute conversation."""
        events = list(self.go_stream(prompt))
        self.log = [event["content"] for event in events if event.get("content")]
        for event in events:
            content = event.get("content")
            if isinstance(content, str) and content.strip():
                self._record_conversation_turn("assistant", content)
        final_content = self.log[-1] if self.log else ""
        return self.log, final_content

    def go_stream(self, prompt) -> Generator[dict, None, None]:
        """Advance the conversation and yield non-empty semantic events."""
        self._ensure_planning_session()
        # Start a fresh transcript only after a previous task cycle completed.
        if getattr(self, "_task_cycle_complete", False):
            self._conversation_turns = []
            self._task_cycle_complete = False
        self._record_conversation_turn("user", prompt)

        if getattr(self, "_use_persistent_workflow", False):
            from microbiome.agent.workflow import ConversationWorkflow
            from microbiome.pipeline.errors import PipelineError
            try:
                workflow = ConversationWorkflow.for_agent(self)
                yield from workflow.handle(self, prompt)
            except (PipelineError, ValueError, OSError) as error:
                yield {"type": "workflow_blocked", "content": f"项目路径或持久状态无法读取：{error}"}
            return

        if self._detect_sra_decline(prompt):
            # 用户明确表示不需要 SRA：本次任务内立即持久禁用远程原始数据获取，
            # 后续 planner 不得再次主动要求 SRR/ERR/DRR/BioProject。
            self._allow_sra_download = False
            self._sra_user_confirmed = True

        if getattr(self, "awaiting_download_confirmation", False):
            # 下载确认门开启中：本轮输入视为对下载清单的回复
            yield from self._handle_download_reply(prompt)
            return

        if self.production_state == "PAUSED":
            from microbiome.pipeline.approval import ProductionApprovalManager, ProductionIntent

            paused_intent = ProductionApprovalManager.classify_intent(prompt)
            if paused_intent in {ProductionIntent.APPROVE_PRODUCTION, ProductionIntent.MODIFY_PLAN}:
                self.awaiting_full_confirmation = True
            else:
                yield {
                    "type": "result",
                    "content": (
                        "全量分析仍处于暂停状态，已验证流程和资源均已保留。"
                        "如需恢复，可明确回复“确认全量执行”；如需调整，请说明修改内容。\n"
                        "The full analysis is still paused; the validated workflow and resources are preserved. To resume, reply "
                        "explicitly “确认全量执行”; to adjust, please describe the changes."
                    ),
                }
                return

        if self.production_state in {"REVALIDATION_REQUIRED", "PRETEST_FINALIZATION_FAILED"}:
            from microbiome.pipeline.approval import ProductionApprovalManager, ProductionIntent

            retry_markers = {"重试冻结", "重新整理", "重试", "重新冻结", "retry"}
            compact = re.sub(r"[\s，。！？、；：,.!?;:'\"`()]+", "", (prompt or "").strip().casefold())
            intent = ProductionApprovalManager.classify_intent(prompt)
            if compact in retry_markers or intent is ProductionIntent.APPROVE_PRODUCTION:
                # 按真实执行记录自动重新整理（管理工件始终自动回填，无需用户处理）
                yield from self._finalize_pretest_production()
                return
            if intent is ProductionIntent.MODIFY_PLAN:
                self.awaiting_full_confirmation = False
                self.awaiting_plan_confirmation = True
                self.production_state = "PLAN_MODIFICATION"
                if self._pilot_summary:
                    self._planning_history.append(AIMessage(content=f"已完成的小数据试跑摘要：\n{self._pilot_summary}"))
                plan = self._revise_plan(prompt)
                self.log = [plan]
                yield {"type": "plan", "content": plan}
                return
            if self.production_state == "PRETEST_FINALIZATION_FAILED":
                category = getattr(self, "_last_finalization_failure_category", "METADATA_ERROR")
                message = (
                    f"小试已经通过；当前为 {category} 管理层失败，禁止自动重跑生信分析。"
                    "可回复“重试冻结”在保留既有软件、数据库、参数和成功记录的前提下重新 Finalize。\n"
                    f"The pilot passed; the current failure is a {category} management-layer failure, so the bioinformatics analysis "
                    "must not be re-run automatically. Reply “重试冻结” to re-run Finalize while keeping the existing software, databases, "
                    "parameters, and success records."
                )
            else:
                message = (
                    "全量执行流程尚未整理完成（缺少软件/数据库/参数或 Pipeline 的实际验证事实）。"
                    "可回复“重试”重新自动整理，或说明需要修改的步骤。\n"
                    "The full-run workflow is not fully assembled yet (missing actual validation facts for software/databases/parameters "
                    "or the Pipeline). Reply “重试” to re-assemble automatically, or describe the steps you need changed."
                )
            self.log = [message]
            yield {"type": "plan", "content": message}
            return

        if self.awaiting_full_confirmation:
            from microbiome.pipeline.approval import ProductionApprovalManager, ProductionIntent

            intent = ProductionApprovalManager.classify_intent(prompt)
            controller = self._get_production_controller()
            if intent is ProductionIntent.QUESTION:
                pending_task = self._pending_task
                pending_plan = self._pending_plan
                answer = self._revise_plan(prompt)
                self._pending_task = pending_task
                self._pending_plan = pending_plan
                self.awaiting_full_confirmation = True
                self.awaiting_plan_confirmation = False
                self.production_state = "AWAITING_PRODUCTION_APPROVAL"
                self._direct_answer = None
                self.log = [answer]
                yield {"type": "result", "content": answer}
                return
            if intent is ProductionIntent.AMBIGUOUS:
                message = (
                    "当前仍在等待是否启动全量分析的明确决定。若要开始，请回复“确认全量执行”或"
                    "“开始跑全部数据”；若暂不运行或需要修改，也请直接说明。\n"
                    "We are still waiting for an explicit decision on whether to start the full analysis. To begin, reply "
                    "“确认全量执行” or “开始跑全部数据”; if you prefer not to run now or need changes, please say so directly."
                )
                self.log = [message]
                yield {"type": "plan", "content": message}
                return
            if intent is ProductionIntent.REJECT_PRODUCTION:
                if controller is not None:
                    controller.approvals.handle(prompt)
                self.awaiting_full_confirmation = False
                self.production_state = "PAUSED"
                message = "已暂停全量分析。小试结果、冻结流程、软件和数据库均已保留，未启动生产运行。\nFull analysis paused. The pilot results, frozen workflow, software, and databases are all preserved; no production run was started."
                self.log = [message]
                yield {"type": "result", "content": message}
                return
            if intent is ProductionIntent.MODIFY_PLAN:
                if controller is not None:
                    controller.approvals.handle(prompt)
                self.awaiting_full_confirmation = False
                self.awaiting_plan_confirmation = True
                self.production_state = "PLAN_MODIFICATION"
                if self._pilot_summary:
                    self._planning_history.append(AIMessage(content=f"已完成的小数据试跑摘要：\n{self._pilot_summary}"))
                plan = self._revise_plan(prompt)
                self.log = [plan]
                if getattr(self, "_direct_answer", None):
                    # 试跑后的顺带提问：直接回答，方案与确认门保持
                    self._direct_answer = None
                    yield {"type": "result", "content": plan}
                    return
                yield {"type": "plan", "content": plan}
                if self.awaiting_resource_preparation:
                    yield self._missing_database_event()
                return

            self.production_state = "PRODUCTION_APPROVED"
            if controller is not None:
                self.awaiting_full_confirmation = False
                yield {
                    "type": "status",
                    "content": (
                        "[microbiome-run] 已确认开始全量执行 / Full execution confirmed to start\n\n"
                        "正在自动进行生产前检查；通过后将直接使用 RAW_DATA_PATH 下的完整原始数据运行。\n"
                        "Running automatic pre-production checks; once passed, the complete raw data under RAW_DATA_PATH will be used.\n"
                        "软件、环境、数据库、参数、命令模板和流程顺序继续使用小试冻结内容。\n"
                        "Software, environments, databases, parameters, command templates, and workflow order continue to use the pilot-frozen content."
                    ),
                }
                try:
                    result = controller.handle_user_message(prompt)
                except Exception as exc:
                    from microbiome.pipeline.errors import classify_finalization_failure
                    from microbiome.pipeline.state import LifecycleState, ProjectStateMachine

                    category = classify_finalization_failure(exc)
                    self._last_finalization_failure_category = category.value
                    target = (
                        LifecycleState.REVALIDATION_REQUIRED
                        if category.requires_pretest
                        else LifecycleState.PRETEST_FINALIZATION_FAILED
                    )
                    try:
                        machine = ProjectStateMachine(controller.project)
                        machine.record_finalization_failure(category, detail=str(exc))
                        machine.transition(target, reason=f"production preflight failed: {exc}"[:400])
                    except Exception:
                        pass
                    if category.requires_pretest:
                        self.production_state = "REVALIDATION_REQUIRED"
                        message = (
                            f"生产前检查发现 {category.value}，已停止且没有修改冻结流程：{exc}。"
                            "该软件/数据库/参数/Pipeline 事实需要重新做针对性小试验证。\n"
                            f"The pre-production check found {category.value}; stopped without modifying the frozen workflow: {exc}. "
                            "This software/database/parameter/Pipeline fact requires a targeted pilot re-validation."
                        )
                    else:
                        self.production_state = "PRETEST_FINALIZATION_FAILED"
                        message = self._management_finalization_failure_message(exc, category.value)
                    self.log = [message]
                    yield {"type": "result", "content": message}
                    return
                manifest = result.get("manifest", {})
                self.production_state = "COMPLETED" if result.get("status") == "COMPLETED" else "PRODUCTION_FAILED"
                message = (
                    f"全量分析状态：{result.get('status')} / Full analysis status: {result.get('status')}\n"
                    f"原始数据根目录：/ Raw data root directory: "
                    f"{manifest.get('preflight', {}).get('input_rebinding', {}).get('raw_data_root')}\n"
                    f"结果目录：{manifest.get('outputs_path')} / Results directory: {manifest.get('outputs_path')}\n"
                    f"运行记录：/ Run record: "
                    f"{manifest.get('batch_manifest_path') or manifest.get('final_report', {}).get('markdown')}"
                )
                self.log = [message]
                yield {"type": "result", "content": message}
                self._reset_planning_session()
                return

            if getattr(self, "require_frozen_production", False):
                # 确认时只允许加载已冻结并就绪的记录；控制器缺失说明冻结/就绪
                # 尚未完成，回到 finalization 依据真实执行记录重建，绝不猜测。
                yield from self._finalize_pretest_production()
                return

            self.awaiting_full_confirmation = False
            try:
                yield from self._stream_execution("full")
                if self._acquisition_only_completed:
                    yield {
                        "type": "result",
                        "content": ("全部已审核数据已完成下载、本地化和完整性验证。该任务没有后续分析阶段。\nAll reviewed data have been downloaded, localized, and validated for integrity. This task has no subsequent analysis stage."),
                    }
            finally:
                self._reset_planning_session()
            return

        if self.awaiting_resource_preparation:
            self._update_plan_resource_blockers(self._pending_plan or "")
            self._set_plan_gate_from_resources()
            if self.awaiting_resource_preparation:
                if self.is_execution_confirmation(prompt):
                    yield self._missing_database_event()
                    return
                plan = self._revise_plan(prompt)
                self.log = [plan]
                if getattr(self, "_direct_answer", None):
                    # 资源阻塞时的顺带提问：直接回答，阻塞状态保持
                    self._direct_answer = None
                    yield {"type": "result", "content": plan}
                    return
                yield {"type": "plan", "content": plan}
                if self.awaiting_resource_preparation:
                    yield self._missing_database_event()
                return

        if not self.awaiting_plan_confirmation:
            if not self._looks_like_pure_query(prompt):
                try:
                    self._run_input_resolution(prompt)
                except (ValueError, OSError) as error:
                    yield {"type": "input_blocked", "content": f"输入确认未完成，尚未开始规划：{error}"}
                    return
            plan = self._create_plan(prompt)
            self.log = [plan]
            if getattr(self, "_direct_answer", None):
                # 纯查询任务：直接回答，不进入方案确认门；下一轮开启全新任务
                self._direct_answer = None
                yield {"type": "result", "content": plan}
                self._reset_planning_session()
                return
            yield {"type": "plan", "content": plan}
            if self.awaiting_resource_preparation:
                yield self._missing_database_event()
            return

        if not self.is_execution_confirmation(prompt):
            plan = self._revise_plan(prompt)
            self.log = [plan]
            if getattr(self, "_direct_answer", None):
                # 方案讨论中的顺带提问：直接回答，方案与确认门保持
                self._direct_answer = None
                yield {"type": "result", "content": plan}
                return
            yield {"type": "plan", "content": plan}
            if self.awaiting_resource_preparation:
                yield self._missing_database_event()
            return

        self._update_plan_resource_blockers(self._pending_plan or "")
        self._set_plan_gate_from_resources()
        if self.awaiting_resource_preparation:
            yield self._missing_database_event()
            return

        self.awaiting_plan_confirmation = False
        self._last_execution_verified = False
        yield from self._stream_confirmed_execution()
        if getattr(self, "awaiting_download_confirmation", False):
            # 下载确认门触发：计划快照已保存，展示待下载清单并暂停
            yield {"type": "plan", "content": self._pending_download_notice}
            return
        yield from self._post_pilot_events()

    def update_system_prompt_with_selected_resources(self, selected_resources):
        """Update the system prompt with the selected resources."""
        # Extract tool descriptions for the selected tools
        tool_desc = {}
        for tool in selected_resources["tools"]:
            # Get the module name from the tool
            if isinstance(tool, dict):
                module_name = tool.get("module", None)

                # If module is not specified, try to find it in the module2api
                if not module_name and hasattr(self, "module2api"):
                    for mod, apis in self.module2api.items():
                        for api in apis:
                            if api.get("name") == tool.get("name"):
                                module_name = mod
                                # Update the tool with the module information
                                tool["module"] = module_name
                                break
                        if module_name:
                            break

                # If still not found, use a default
                if not module_name:
                    module_name = "microbiome.tool.scRNA_tools"  # Default to scRNA_tools as a fallback
                    tool["module"] = module_name
            else:
                module_name = getattr(tool, "module_name", None)

                # If module is not specified, try to find it in the module2api
                if not module_name and hasattr(self, "module2api"):
                    tool_name = getattr(tool, "name", str(tool))
                    for mod, apis in self.module2api.items():
                        for api in apis:
                            if api.get("name") == tool_name:
                                module_name = mod
                                # Set the module_name attribute
                                tool.module_name = module_name
                                break
                        if module_name:
                            break

                # If still not found, use a default
                if not module_name:
                    module_name = "microbiome.tool.scRNA_tools"  # Default to scRNA_tools as a fallback
                    tool.module_name = module_name

            if module_name not in tool_desc:
                tool_desc[module_name] = []

            # Add the tool to the appropriate module
            if isinstance(tool, dict):
                # Ensure the module is included in the tool description
                if "module" not in tool:
                    tool["module"] = module_name
                tool_desc[module_name].append(tool)
            else:
                # Convert tool object to dictionary
                tool_dict = {
                    "name": getattr(tool, "name", str(tool)),
                    "description": getattr(tool, "description", ""),
                    "parameters": getattr(tool, "parameters", {}),
                    "module": module_name,  # Explicitly include the module
                }
                tool_desc[module_name].append(tool_dict)

        # Prepare data lake items with descriptions
        data_lake_with_desc = []
        for item in selected_resources["data_lake"]:
            description = self.data_lake_dict.get(item, f"Data lake item: {item}")
            data_lake_with_desc.append({"name": item, "description": description})

        # Prepare custom resources for highlighting
        custom_tools = []
        if hasattr(self, "_custom_tools") and self._custom_tools:
            for name, info in self._custom_tools.items():
                custom_tools.append(
                    {
                        "name": name,
                        "description": info["description"],
                        "module": info["module"],
                    }
                )

        custom_data = []
        if hasattr(self, "_custom_data") and self._custom_data:
            for name, info in self._custom_data.items():
                custom_data.append({"name": name, "description": info["description"]})

        custom_software = []
        if hasattr(self, "_custom_software") and self._custom_software:
            for name, info in self._custom_software.items():
                custom_software.append({"name": name, "description": info["description"]})

        # Extract know-how documents if present
        know_how_docs = selected_resources.get("know_how", [])

        self.system_prompt = self._generate_system_prompt(
            tool_desc=tool_desc,
            data_lake_content=data_lake_with_desc,
            library_content_list=selected_resources["libraries"],
            self_critic=getattr(self, "self_critic", False),
            is_retrieval=True,
            custom_tools=custom_tools if custom_tools else None,
            custom_data=custom_data if custom_data else None,
            custom_software=custom_software if custom_software else None,
            know_how_docs=know_how_docs if know_how_docs else None,
        )

        # Print the raw system prompt for debugging
        # print("\n" + "="*20 + " RAW SYSTEM PROMPT FROM AGENT " + "="*20)
        # print(self.system_prompt)
        # print("="*70 + "\n")

    def result_formatting(self, output_class, task_intention):
        self.format_check_prompt = ChatPromptTemplate.from_messages(
            [
                (
                    "system",
                    (
                        "You are evaluateGPT, tasked with extract and parse the task output based on the history of an agent. "
                        "Review the entire history of messages provided. "
                        "Here is the task output requirement: \n"
                        f"'{task_intention.replace('{', '{{').replace('}', '}}')}'.\n"
                    ),
                ),
                ("placeholder", "{messages}"),
            ]
        )

        checker_llm = self.format_check_prompt | self.llm.with_structured_output(output_class)
        result = checker_llm.invoke({"messages": [("user", str(self.log))]}).dict()
        return result

    def _parse_tool_calls_from_code(self, code: str) -> list[str]:
        """Parse code to detect imported tools by looking for import statements.

        Args:
            code: The Python code to parse

        Returns:
            List of detected tool names
        """
        module2api = getattr(self, "module2api", {})
        custom_functions = getattr(self, "_custom_functions", {})
        return parse_tool_calls_from_code(code, module2api, custom_functions)

    def _parse_tool_calls_with_modules(self, code: str) -> list[tuple[str, str]]:
        """Parse code to detect imported tools and their modules.

        Args:
            code: The Python code to parse

        Returns:
            List of tuples (tool_name, module_name)
        """
        module2api = getattr(self, "module2api", {})
        custom_functions = getattr(self, "_custom_functions", {})
        return parse_tool_calls_with_modules(code, module2api, custom_functions)

    def _inject_custom_functions_to_repl(self):
        """Inject custom functions into the Python REPL execution environment.
        This makes custom tools available during code execution.
        """
        custom_functions = getattr(self, "_custom_functions", {})
        inject_custom_functions_to_repl(custom_functions)

    def create_mcp_server(self, tool_modules=None):
        """
        Create an MCP server object that exposes internal Microbiome tools.
        This gives you control over when and how to run the server.

        Args:
            tool_modules: List of module names to expose (default: all in self.module2api)

        Returns:
            FastMCP server object that you can run manually
        """
        import importlib

        from mcp.server.fastmcp import FastMCP

        mcp = FastMCP("MicrobiomeTools")
        modules = tool_modules or list(self.module2api.keys())

        registered_tools = 0

        for module_name in modules:
            try:
                # Import the actual module
                module = importlib.import_module(module_name)
                # Get tools for this module
                module_tools = self.module2api.get(module_name, [])

                for tool_schema in module_tools:
                    tool_name = tool_schema.get("name")
                    if not tool_name:
                        continue

                    try:
                        # Get the actual function
                        fn = getattr(module, tool_name, None)
                        if fn is None:
                            fn = getattr(self, "_custom_functions", {}).get(tool_name)

                        if fn is None:
                            print(f"Warning: Could not find function '{tool_name}' in module '{module_name}'")
                            continue

                        # Extract parameters from your specific schema format
                        required_params = tool_schema.get("required_parameters", [])
                        optional_params = tool_schema.get("optional_parameters", [])

                        # Generate the wrapper function
                        wrapper_func = self._generate_mcp_wrapper_from_microbiome_schema(
                            fn, tool_name, required_params, optional_params
                        )

                        # Register with MCP
                        mcp.tool()(wrapper_func)
                        registered_tools += 1

                    except Exception as e:
                        print(f"Warning: Failed to register tool '{tool_name}': {e}")
                        continue

            except ImportError as e:
                print(f"Warning: Could not import module '{module_name}': {e}")
                continue

        print(f"Created MCP server with {registered_tools} tools")
        return mcp

    def save_conversation_history(self, filepath: str, include_images: bool = True, save_pdf: bool = True) -> None:
        """Save the complete conversation history as Markdown and, optionally, PDF.

        The Markdown file is always written so callers can inspect, diff, or post-process
        the full transcript; it is no longer deleted after PDF conversion. PDF generation is
        a best-effort extra and never blocks the Markdown artifact.

        Args:
            filepath: Target path. An explicit .md or .pdf extension is honoured; any other
                    extension is treated as a base name and both .md and .pdf are appended.
            include_images: Whether to embed captured plots and images. Defaults to True.
            save_pdf: Whether to also convert the Markdown to PDF. Defaults to True.
        """
        import os

        if not isinstance(filepath, str) or not filepath.strip():
            raise ValueError("filepath must be a non-empty string")

        directory = os.path.dirname(filepath)
        if directory:
            os.makedirs(directory, exist_ok=True)

        if filepath.endswith(".md"):
            md_path = filepath
            pdf_path = filepath[:-3] + ".pdf"
        elif filepath.endswith(".pdf"):
            pdf_path = filepath
            md_path = filepath[:-4] + ".md"
        else:
            md_path = f"{filepath}.md"
            pdf_path = f"{filepath}.pdf"

        markdown_content = self._generate_markdown_content(include_images)
        with open(md_path, "w", encoding="utf-8") as handle:
            handle.write(markdown_content)
        print(f"Conversation history saved as Markdown: {md_path}")
        print(f"Total steps recorded: {len(self.log)}")

        if not save_pdf:
            print("PDF conversion disabled; Markdown file only.")
            return

        try:
            self._convert_markdown_to_pdf_with_timeout(md_path, pdf_path)
            print(f"Conversation history saved as PDF: {pdf_path}")
        except Exception as exc:
            print(f"Warning: Could not convert to PDF (Markdown still saved at {md_path}): {exc}")

    def _convert_markdown_to_pdf_with_timeout(self, markdown_path: str, pdf_path: str, timeout: int = 120) -> None:
        """Convert Markdown to PDF with a portable, best-effort timeout.

        Unlike the previous `signal.alarm` approach, this uses a worker thread and therefore
        works on Windows as well as POSIX platforms. On timeout the worker thread is left to
        finish in the background (threads cannot be forcibly killed); the call itself returns
        with an error so the caller is not left hanging.
        """
        import concurrent.futures

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(self._convert_markdown_to_pdf, markdown_path, pdf_path)
            try:
                future.result(timeout=timeout)
            except concurrent.futures.TimeoutError as exc:
                raise TimeoutError(f"PDF conversion timed out after {timeout} seconds") from exc

    def _generate_markdown_content(self, include_images: bool = True) -> str:
        """Generate markdown content from conversation history using both log and conversation state.

        This function processes the agent's conversation history from either the conversation
        state (if available) or the internal log to create a formatted markdown document.
        It handles step numbering, message processing, and content formatting.

        Args:
            include_images: Whether to include captured plots and images in the output.
                          Defaults to True.

        Returns:
            Formatted markdown string containing the complete conversation history
            with proper step numbering and content structure.
        """

        # Initialize content and tracking variables
        content = """# Microbiome Agent Conversation History

"""
        added_plots = set()
        step_number = 0
        first_human_shown = False

        # Get data source (conversation state or log)
        messages = self._get_messages_for_processing()

        # Process all messages using unified logic
        for message_data in messages:
            content, step_number, first_human_shown = self._process_message(
                message_data, content, step_number, first_human_shown, added_plots, include_images
            )

        return content

    def _get_messages_for_processing(self):
        """Get messages from the durable turn transcript, then legacy sources.

        The turn transcript (populated by `go_stream`/`go`) is the authoritative source:
        it preserves every user turn and agent reply with explicit roles. Legacy sources —
        `_conversation_state` (LangChain messages) and the flat `self.log` — remain as
        fallbacks for deserialized or older agent instances.
        """
        turns = getattr(self, "_conversation_turns", None)
        if turns:
            return [
                {"content": turn["content"], "type": "human" if turn["role"] == "user" else "ai", "original": turn}
                for turn in turns
            ]

        conversation_state = getattr(self, "_conversation_state", None)
        if conversation_state and hasattr(conversation_state, "get") and "messages" in conversation_state:
            return self._normalize_conversation_state_messages(conversation_state["messages"])

        return self._normalize_log_messages(self.log)

    def _normalize_conversation_state_messages(self, messages):
        """Convert conversation state messages to unified format.

        This function takes LangChain message objects from the conversation state and
        converts them into a standardized dictionary format that the markdown generation
        system can work with. It extracts content and determines message types.

        Args:
            messages: List of LangChain message objects (HumanMessage, AIMessage, etc.)

        Returns:
            List of normalized message dictionaries with 'content', 'type', and 'original' keys
        """
        normalized = []
        for message in messages:
            if hasattr(message, "content"):
                content = str(message.content)
            else:
                content = str(message)

            # Determine message type
            if isinstance(message, HumanMessage):
                msg_type = "human"
            elif isinstance(message, AIMessage):
                msg_type = "ai"
            else:
                msg_type = "other"

            normalized.append({"content": content, "type": msg_type, "original": message})

        return normalized

    def _normalize_log_messages(self, log_entries):
        """Convert log entries to unified format.

        This function takes internal log entries and converts them into the same
        standardized format as conversation state messages. It parses the log format
        to determine message types and extract content.

        Args:
            log_entries: List of log entry strings from the agent's internal log

        Returns:
            List of normalized message dictionaries with 'content', 'type', and 'original' keys
        """
        normalized = []
        for log_entry in log_entries:
            content = str(log_entry)

            # Determine message type from log format
            if "Human Message" in content:
                msg_type = "human"
            elif "Ai Message" in content:
                msg_type = "ai"
            else:
                msg_type = "other"

            normalized.append({"content": content, "type": msg_type, "original": log_entry})

        return normalized

    def _process_message(self, message_data, content, step_number, first_human_shown, added_plots, include_images):
        """Process a single message and return updated state.

        This function is the main dispatcher for processing individual messages in the
        conversation history. It determines the message type and delegates to the
        appropriate processing function.

        Args:
            message_data: Dictionary containing 'content', 'type', and 'original' keys
            content: Current markdown content string
            step_number: Current step number counter
            first_human_shown: Boolean flag indicating if first human message was shown
            added_plots: Set of already added plot data to avoid duplicates
            include_images: Whether to include images in the output

        Returns:
            Tuple of (updated_content, updated_step_number, updated_first_human_shown)
        """
        clean_output = clean_message_content(message_data["content"])
        msg_type = message_data["type"]

        if msg_type == "human":
            return self._process_human_message(clean_output, content, step_number, first_human_shown)
        elif msg_type == "ai":
            return self._process_ai_message(clean_output, content, step_number, added_plots, include_images)
        else:
            return self._process_other_message(
                clean_output, content, step_number, first_human_shown, added_plots, include_images
            )

    def _process_human_message(self, clean_output, content, step_number, first_human_shown):
        """Process human messages.

        This function handles human messages in the conversation history. It identifies
        parsing error messages and displays them appropriately, or formats the first
        human prompt as a special section.

        Args:
            clean_output: Cleaned message content with ANSI codes removed
            content: Current markdown content string
            step_number: Current step number counter (unchanged for human messages)
            first_human_shown: Boolean flag indicating if first human message was shown

        Returns:
            Tuple of (updated_content, step_number, updated_first_human_shown)

        Note:
            Human messages don't increment the step counter as they are not considered
            steps in the agent's process.
        """
        if "each response must include thinking process" in clean_output.lower():
            parsing_error_content = create_parsing_error_html()
            content += f"{parsing_error_content}\n\n"
        elif clean_output.strip():
            # Every user message is part of the transcript. The previous
            # `first_human_shown` guard silently dropped all turns after the first
            # one, producing an incomplete conversation history.
            content += "#### Human Prompt\n\n"
            content += f"{clean_output}\n\n"
            first_human_shown = True

        return content, step_number, first_human_shown  # step_number unchanged

    def _process_ai_message(self, clean_output, content, step_number, added_plots, include_images):
        """Process AI messages.

        This function handles AI messages in the conversation history. It can process
        both regular AI responses and messages containing observation tags. It handles
        step numbering, execution results, and content formatting.

        Args:
            clean_output: Cleaned message content with ANSI codes removed
            content: Current markdown content string
            step_number: Current step number counter
            added_plots: Set of already added plot data to avoid duplicates
            include_images: Whether to include images in the output

        Returns:
            Tuple of (updated_content, updated_step_number, True)

        Note:
            This function can split messages containing observation tags and process
            each part separately, with observations formatted as terminal blocks.
        """
        # Check if this message contains observation tags and process accordingly
        import re

        observation_pattern = r"<observation>(.*?)</observation>"
        observation_matches = re.findall(observation_pattern, clean_output, re.DOTALL | re.IGNORECASE)

        if observation_matches:
            # Extract content before, between, and after observation tags
            parts = re.split(observation_pattern, clean_output, flags=re.DOTALL | re.IGNORECASE)

            # Process each part
            for i, part in enumerate(parts):
                if i % 2 == 0:  # Even indices are non-observation content
                    if part.strip():
                        # This is regular content - process it normally
                        if not should_skip_message(part):
                            if part.strip():
                                step_number += 1
                                content += f"#### Step {step_number}\n\n"

                                # Handle execution results if present
                                execution_results = getattr(self, "_execution_results", None)
                                if has_execution_results(part, execution_results):
                                    content, added_plots = self._process_execution_with_results(
                                        part, content, added_plots, include_images, execution_results
                                    )
                                else:
                                    content = self._process_regular_ai_message(part, content)
                else:  # Odd indices are observation content
                    if part.strip():
                        # This is observation content - format as terminal
                        formatted_observation = format_observation_as_terminal(f"<observation>{part}</observation>")
                        if formatted_observation is not None:
                            content += f"{formatted_observation}\n\n"

            return content, step_number, True

        # Skip empty or error messages
        if should_skip_message(clean_output):
            return content, step_number, True

        if clean_output.strip():
            step_number += 1
            content += f"#### Step {step_number}\n\n"

            # Handle execution results if present
            execution_results = getattr(self, "_execution_results", None)
            if has_execution_results(clean_output, execution_results):
                content, added_plots = self._process_execution_with_results(
                    clean_output, content, added_plots, include_images, execution_results
                )
            else:
                content = self._process_regular_ai_message(clean_output, content)

        return content, step_number, True

    def _process_other_message(
        self, clean_output, content, step_number, first_human_shown, added_plots, include_images
    ):
        """Process other message types.

        This function handles message types that are neither human nor AI messages.
        It checks for observation tags and processes them accordingly, or adds the
        content as regular text.

        Args:
            clean_output: Cleaned message content with ANSI codes removed
            content: Current markdown content string
            step_number: Current step number counter
            first_human_shown: Boolean flag indicating if first human message was shown
            added_plots: Set of already added plot data to avoid duplicates
            include_images: Whether to include images in the output

        Returns:
            Tuple of (updated_content, step_number, first_human_shown)
        """
        # Check if this is actually an observation (has <observation> tags)
        import re

        if not re.search(r"<observation>", clean_output, re.IGNORECASE):
            content += f"{clean_output}\n\n"
        return content, step_number, first_human_shown

    def _process_execution_with_results(self, clean_output, content, added_plots, include_images, execution_results):
        """Process AI message with execution results.

        This function handles AI messages that have associated execution results.
        It finds the matching execution result and adds any captured plots or images
        to the content.

        Args:
            clean_output: Cleaned message content with ANSI codes removed
            content: Current markdown content string
            added_plots: Set of already added plot data to avoid duplicates
            include_images: Whether to include images in the output
            execution_results: List of execution result dictionaries

        Returns:
            Tuple of (updated_content, updated_added_plots)
        """
        matching_execution = find_matching_execution(clean_output, execution_results)

        if matching_execution:
            content = self._format_and_add_content(clean_output, content)
            content, added_plots = self._add_execution_plots(matching_execution, content, added_plots, include_images)
        else:
            content = self._format_and_add_content(clean_output, content)

        return content, added_plots

    def _format_and_add_content(self, clean_output, content):
        """Format and add content to markdown.

        This function applies formatting to AI message content before adding it to the
        markdown. It processes lists, execute tags, and tool calls to create properly
        formatted markdown content.

        Args:
            clean_output: Cleaned message content with ANSI codes removed
            content: Current markdown content string

        Returns:
            Updated markdown content string with formatted content added
        """
        # Process lists first, then execute tags
        formatted_content = format_lists_in_text(clean_output)

        # Create a wrapper function for the tool parsing
        def parse_tool_calls_wrapper(code):
            return self._parse_tool_calls_with_modules(code)

        formatted_content = format_execute_tags_in_content(formatted_content, parse_tool_calls_wrapper)
        return content + f"{formatted_content}\n\n"

    def _add_execution_plots(self, matching_execution, content, added_plots, include_images):
        """Add plots from execution results.

        This function adds captured plots and images from execution results to the
        markdown content. It prevents duplicate plots from being added multiple times.

        Args:
            matching_execution: Execution result dictionary containing image data
            content: Current markdown content string
            added_plots: Set of already added plot data to avoid duplicates
            include_images: Whether to include images in the output

        Returns:
            Tuple of (updated_content, updated_added_plots)
        """
        if include_images and matching_execution.get("images"):
            for plot_data in matching_execution["images"]:
                if plot_data not in added_plots:
                    content += f"![Plot]({plot_data})\n\n"
                    added_plots.add(plot_data)
        return content, added_plots

    def _process_regular_ai_message(self, clean_output, content):
        """Process regular AI message without execution results.

        This function handles AI messages that don't have associated execution results.
        It applies standard formatting and adds the content to the markdown.

        Args:
            clean_output: Cleaned message content with ANSI codes removed
            content: Current markdown content string

        Returns:
            Updated markdown content string with formatted content added
        """
        return self._format_and_add_content(clean_output, content)

    def _convert_markdown_to_pdf(self, markdown_path: str, pdf_path: str) -> None:
        """Convert markdown file to PDF using weasyprint or markdown2pdf.

        This function is a wrapper around the utility function for converting markdown
        to PDF. It provides a clean interface for the agent to convert conversation
        history to PDF format.

        Args:
            markdown_path: Path to the input markdown file
            pdf_path: Path where the output PDF file should be saved

        Note:
            This function delegates to the convert_markdown_to_pdf utility function
            which handles multiple PDF conversion libraries and fallbacks.
        """
        convert_markdown_to_pdf(markdown_path, pdf_path)

    def _clear_execution_plots(self):
        """Clear execution plots before new execution.

        This function clears any previously captured plots from the execution environment
        before starting a new execution. This prevents old plots from appearing in
        new execution results.

        Note:
            This function calls the clear_captured_plots utility function and handles
            any exceptions gracefully to prevent execution failures.
        """
        try:
            from microbiome.tool.support_tools import clear_captured_plots

            clear_captured_plots()
        except Exception as e:
            print(f"Warning: Could not clear execution plots: {e}")

    def _generate_mcp_wrapper_from_microbiome_schema(self, original_func, func_name, required_params, optional_params):
        """Generate wrapper function based on Microbiome schema format."""
        import inspect

        # Combine all parameters
        all_params = required_params + optional_params

        if not all_params:
            # No parameters
            def wrapper() -> dict:
                try:
                    result = original_func()
                    if isinstance(result, dict):
                        return result
                    return {"result": result}
                except Exception as e:
                    return {"error": str(e)}

            wrapper.__name__ = func_name
            wrapper.__doc__ = original_func.__doc__
            return wrapper

        else:
            # Has parameters
            def wrapper(**kwargs) -> dict:
                try:
                    # Build arguments dict
                    filtered_kwargs = {}

                    # Add required parameters
                    for param_info in required_params:
                        param_name = param_info["name"]
                        if param_name in kwargs and kwargs[param_name] is not None:
                            filtered_kwargs[param_name] = kwargs[param_name]

                    # Add optional parameters only if provided and not None
                    for param_info in optional_params:
                        param_name = param_info["name"]
                        if param_name in kwargs and kwargs[param_name] is not None:
                            filtered_kwargs[param_name] = kwargs[param_name]

                    result = original_func(**filtered_kwargs)
                    if isinstance(result, dict):
                        return result
                    return {"result": result}
                except Exception as e:
                    return {"error": str(e)}

            # Set function metadata
            wrapper.__name__ = func_name
            wrapper.__doc__ = original_func.__doc__

            # Create proper signature
            new_params = []

            # Map your types to Python types
            type_map = {"str": str, "int": int, "float": float, "bool": bool, "List[str]": list[str], "dict": dict}

            # Add required parameters
            for param_info in required_params:
                param_name = param_info["name"]
                param_type_str = param_info["type"]
                param_type = type_map.get(param_type_str, str)

                new_params.append(inspect.Parameter(param_name, inspect.Parameter.KEYWORD_ONLY, annotation=param_type))

            # Add optional parameters
            for param_info in optional_params:
                param_name = param_info["name"]
                param_type_str = param_info["type"]
                param_type = type_map.get(param_type_str, str)

                # Make it optional
                optional_type = param_type | None

                new_params.append(
                    inspect.Parameter(
                        param_name, inspect.Parameter.KEYWORD_ONLY, default=None, annotation=optional_type
                    )
                )

            # Set the signature
            wrapper.__signature__ = inspect.Signature(new_params, return_annotation=dict)

            return wrapper

    def launch_gradio_demo(self, thread_id=42, share=False, server_name="0.0.0.0", require_verification=False):
        """Launch a full-featured Gradio UI for the A1 agent (adapted from codeact_copilot).

        Args:
            thread_id: Thread ID for the conversation
            share: Whether to create a public shareable link
            server_name: Server name/IP to bind to (default: "0.0.0.0")
            require_verification: If True, requires access code verification

        Example:
            >>> agent = A1()
            >>> agent.launch_gradio_demo()
        """
        try:
            import gradio as gr
            from gradio import ChatMessage
        except ImportError:
            raise ImportError("Gradio is not installed. Please install it with: pip install gradio") from None

        import os
        from time import time

        # Define supported file extensions
        SUPPORTED_EXTENSIONS = (".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".pdf")

        self.main_history_copy = []

        # Available access codes (if verification is required)
        available_access_codes = ["Microbiome2025"]

        # Function for verification page
        def verify_access_code(code):
            if code in available_access_codes:
                return gr.update(visible=False), gr.update(visible=True), gr.update(visible=False)
            else:
                return (
                    gr.update(visible=True),
                    gr.update(visible=False),
                    gr.update(value="Incorrect access code. Please check your access code.", visible=True),
                )

        def generate_response(prompt_input, inner_history=None, main_history=None):
            if main_history is None:
                main_history = []
            if inner_history is None:
                inner_history = []
            text_input = prompt_input.get("text", "")
            files = prompt_input.get("files", [])

            self.main_history_copy += [{"role": "user", "content": text_input}]
            main_history.append(ChatMessage(role="user", content=text_input if text_input else "[Uploaded file]"))

            # Add "Executor is working on it" message
            main_history.append(ChatMessage(role="assistant", content="Executor is working on it 👉"))
            yield inner_history, main_history

            # Process uploaded files if any
            for file_info in files:
                file_path = file_info
                text_input += f"\n\n User uploaded this file: {file_path}\n Please use it if needed."

            agent_messages = []
            for msg in self.main_history_copy:
                if msg["role"] == "user":
                    agent_messages.append(HumanMessage(content=msg["content"]))
                elif msg["role"] == "assistant":
                    if msg["content"] not in ["Executor is working on it 👉"]:
                        agent_messages.append(AIMessage(content=msg["content"]))

            agent_messages.append(HumanMessage(content=text_input))

            # Prepare inputs for the agent
            inputs = {"messages": agent_messages, "next_step": None}
            config = {"recursion_limit": 10000, "configurable": {"thread_id": thread_id}}

            # Stream the agent's responses
            t = time()
            solution_found = False

            # Configure the agent with tool retrieval if needed
            if self.use_tool_retriever:
                print("Using tool retriever...")
                inner_history.append(
                    ChatMessage(
                        role="assistant",
                        content="Retrieving relevant tools, data lake items, and libraries...",
                    )
                )
                yield inner_history, main_history

                try:
                    selected_resources_names = self._prepare_resources_for_retrieval(text_input)
                    if selected_resources_names:
                        self.update_system_prompt_with_selected_resources(selected_resources_names)
                except Exception as e:
                    print(f"Warning: Tool retrieval failed: {e}")
                    print("Continuing without tool retrieval...")
                    inner_history.append(
                        ChatMessage(
                            role="assistant",
                            content="Tool retrieval unavailable, proceeding with all tools...",
                        )
                    )
                    yield inner_history, main_history

            # Keep track of code execution messages
            code_execution_messages = []
            code_execution_operations = []

            # Stream the agent's responses
            for s in self.app.stream(inputs, stream_mode="values", config=config):
                t_step = time() - t
                message = s["messages"][-1]

                # Skip the first message which is the input task
                if message.content == text_input:
                    t = time()
                    continue

                # Process the message
                if isinstance(message.content, str):
                    # Extract thinking/reasoning part (text before any tags)
                    tag_positions = []
                    for tag in ["<execute>", "<solution>", "<observation>"]:
                        pos = message.content.find(tag)
                        if pos != -1:
                            tag_positions.append(pos)

                    # If there are tags, extract the text before the first tag
                    if tag_positions:
                        first_tag_pos = min(tag_positions)
                        thinking = message.content[:first_tag_pos].strip()
                        if thinking:
                            inner_history.append(
                                ChatMessage(
                                    role="assistant",
                                    content=f"{thinking}",
                                    metadata={"title": "🤔 Reasoning", "log": "Agent's thinking process"},
                                )
                            )
                            yield inner_history, main_history

                    # Check for solution tag
                    solution_match = re.search(r"<solution>(.*?)</solution>", message.content, re.DOTALL)
                    if solution_match and not solution_found:
                        solution = solution_match.group(1).strip()
                        main_history.append(
                            ChatMessage(
                                role="assistant",
                                content=solution,
                                metadata={"title": "✅ Answer", "log": "Final answer provided by the agent"},
                            )
                        )
                        self.main_history_copy += [{"role": "assistant", "content": solution}]
                        solution_found = True
                        yield inner_history, main_history

                    # Check for execute tag
                    execute_match = re.search(r"<execute>(.*?)</execute>", message.content, re.DOTALL)
                    if execute_match:
                        code = A1._sanitize_execute_code(execute_match.group(1))
                        rationale = message.content[: execute_match.start()].strip()
                        operation = infer_operation(code, rationale)
                        progress = progress_event(0, operation, detail="命令已提交，正在等待真实执行结果 / Command submitted; waiting for the real execution result")
                        language = "python"
                        if code.strip().startswith("#!R"):
                            language = "r"
                            code = re.sub(r"^#!R", "", code, count=1).strip()
                        elif code.strip().startswith("#!BASH") or code.strip().startswith("#!CLI"):
                            language = "bash"
                            code = re.sub(r"^#!BASH|^#!CLI", "", code, count=1).strip()

                        code_msg = ChatMessage(
                            role="assistant",
                            content=f"{progress['content']}\n\n##### Code: \n```{language}\n{code}\n```",
                            metadata={
                                "title": "⏳ 进度 0% / Progress 0%",
                                "log": f"Executing {language.capitalize()} code block...",
                                "status": "pending",
                                "start_time": t,
                            },
                        )
                        inner_history.append(code_msg)
                        code_execution_messages.append(code_msg)
                        code_execution_operations.append(operation)
                        yield inner_history, main_history

                    # Check for observation
                    observation_match = re.search(r"<observation>(.*?)</observation>", message.content, re.DOTALL)
                    if observation_match:
                        observation = observation_match.group(1).strip()

                        # Update the status of the most recent code execution message
                        if code_execution_messages:
                            code_msg = code_execution_messages[-1]
                            operation = code_execution_operations[-1]
                            failed = self._observation_failed(observation)
                            completed = progress_event(
                                100,
                                operation,
                                status="failed" if failed else "completed",
                                detail="已收到并记录真实命令输出 / Real command output received and recorded",
                            )
                            code_msg.content = completed["content"] + "\n\n" + code_msg.content.split("\n\n", 1)[-1]
                            code_msg.metadata.update(
                                {
                                    "status": "done",
                                    "title": "❌ 进度 100%（失败） / Failed at 100%" if failed else "✅ 进度 100% / 100% Complete",
                                    "duration": t_step,
                                    "log": f"Code execution completed in {t_step:.2f}s",
                                }
                            )

                        # Create a new message for the observation
                        inner_history.append(
                            ChatMessage(
                                role="assistant",
                                content=f"##### Observation: \n```\n{observation}\n```",
                                metadata={
                                    "status": "done",
                                    "duration": t_step,
                                    "log": "Observation from code execution",
                                    "collapsed": True,
                                    "collapsible": True,
                                },
                            )
                        )
                        yield inner_history, main_history

                        # Check for file paths in the observation
                        if isinstance(observation, str) and any(ext in observation for ext in SUPPORTED_EXTENSIONS):
                            matches = re.findall(r"(\S+?(?:\.png|\.jpg|\.jpeg|\.gif|\.bmp|\.webp|\.pdf))", observation)

                            valid_matches = []
                            for match in matches:
                                if not (
                                    match.startswith("Warning:") or match.startswith("Error:") or match.startswith("'")
                                ):
                                    if not match.startswith("."):
                                        valid_matches.append(match)

                            if valid_matches:
                                inner_history.append(
                                    ChatMessage(
                                        role="assistant",
                                        content="",
                                        metadata={"title": "📁 Files", "log": "Files generated by the agent"},
                                    )
                                )

                                for file_path in valid_matches:
                                    file_path = file_path.strip("\"'").strip()

                                    abs_path = None
                                    if os.path.isabs(file_path) and os.path.exists(file_path):
                                        abs_path = file_path
                                    elif os.path.exists(os.path.join(os.getcwd(), file_path)):
                                        abs_path = os.path.join(os.getcwd(), file_path)
                                    elif (
                                        hasattr(self, "path")
                                        and self.path
                                        and os.path.exists(os.path.join(self.path, file_path))
                                    ):
                                        abs_path = os.path.join(self.path, file_path)

                                    if abs_path:
                                        if file_path.lower().endswith(".pdf"):
                                            inner_history.append(
                                                ChatMessage(
                                                    role="assistant",
                                                    content=f"Found PDF at: {abs_path}",
                                                    metadata={"title": "📄 PDF File"},
                                                )
                                            )
                                        else:
                                            inner_history.append(
                                                ChatMessage(
                                                    role="assistant",
                                                    content=gr.Image(abs_path),
                                                    metadata={"title": "🖼️ Image Preview"},
                                                )
                                            )

                                yield inner_history, main_history

                t = time()

            # If no solution was found, add the final message
            if not solution_found:
                final_message = s["messages"][-1].content if s["messages"] else ""
                solution_match = re.search(r"<solution>(.*?)</solution>", final_message, re.DOTALL)
                if solution_match:
                    solution = solution_match.group(1).strip()
                    main_history.append(
                        ChatMessage(role="assistant", content=solution, metadata={"title": "✅ Solution"})
                    )
                    self.main_history_copy += [{"role": "assistant", "content": solution}]
                else:
                    cleaned_content = re.sub(r"<execute>.*?</execute>", "", final_message, flags=re.DOTALL)
                    cleaned_content = re.sub(r"<observation>.*?</observation>", "", cleaned_content, flags=re.DOTALL)
                    cleaned_content = re.sub(r"\n\s*\n", "\n\n", cleaned_content)

                    if cleaned_content.strip():
                        main_history.append(
                            ChatMessage(
                                role="assistant", content=cleaned_content.strip(), metadata={"title": "📝 Summary"}
                            )
                        )
                        self.main_history_copy += [{"role": "assistant", "content": cleaned_content.strip()}]
                    else:
                        main_history.append(
                            ChatMessage(
                                role="assistant",
                                content="Task completed. Please check the execution log for details.",
                                metadata={"title": "📝 Summary"},
                            )
                        )
                        self.main_history_copy += [{"role": "assistant", "content": "Task completed."}]

            # Add completion message
            inner_history.append(
                ChatMessage(
                    role="assistant",
                    content="👈 Returning the result to the main interface...",
                    metadata={"title": "🔄 Complete"},
                )
            )
            yield inner_history, main_history

        def like(data: gr.LikeData):
            print("User liked the response")
            print(f"Index: {data.index}, Liked: {data.liked}")

        # Create the Gradio interface
        with gr.Blocks() as demo:
            # Verification page (if enabled)
            verification_container = gr.Group(visible=require_verification)
            main_interface_container = gr.Group(visible=not require_verification)

            with verification_container:
                gr.Markdown("# Microbiome A1 Agent - Access Verification")
                gr.Markdown("Please enter your access code to continue.")
                access_code_input = gr.Textbox(label="Access Code", type="password")
                access_error_msg = gr.Markdown(visible=False)
                verify_btn = gr.Button("Verify Access")
                verify_btn.click(
                    fn=verify_access_code,
                    inputs=[access_code_input],
                    outputs=[verification_container, main_interface_container, access_error_msg],
                )

            # Main interface
            with main_interface_container:
                with gr.Row():
                    with gr.Column(scale=1):
                        main_chatbot = gr.Chatbot(
                            label="Microbiome A1 Agent",
                            type="messages",
                            height=800,
                            show_copy_button=True,
                            show_share_button=True,
                        )
                    with gr.Column(scale=1):
                        innerloop_chatbot = gr.Chatbot(
                            label="Microbiome Executor",
                            type="messages",
                            height=800,
                            show_copy_button=True,
                            show_share_button=True,
                        )

                with gr.Row():
                    prompt_input = gr.MultimodalTextbox(
                        interactive=True,
                        file_count="multiple",
                        placeholder="Ask something or upload a file...",
                        show_label=False,
                    )

                # Bind submission
                prompt_input.submit(
                    generate_response,
                    [prompt_input, innerloop_chatbot, main_chatbot],
                    [innerloop_chatbot, main_chatbot],
                ).then(lambda: gr.MultimodalTextbox(value=None), None, [prompt_input])
                main_chatbot.like(like)

        # Launch
        print(f"Launching Gradio demo on {server_name}:7860")
        demo.launch(share=share, server_name=server_name)
