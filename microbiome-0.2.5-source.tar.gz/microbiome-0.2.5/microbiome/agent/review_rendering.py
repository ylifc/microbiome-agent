"""Deterministic native review of an already validated study; never a planner."""
from __future__ import annotations

import json


RENDERER_VERSION = "structured_native_review_v1"


def render_native_review(*, study, goal_contract, manifest, paths, dependencies,
                         pretest, validation_policy, audit_source):
    """Present all current contracts without adopting model narrative as facts.

    This function only serializes supplied, validated facts. It does not infer
    capabilities from tool names or prose, add assertions, resolve placeholders,
    change parameters, or grant approval.
    """
    rows = ["# 当前方案审阅（待确认）",
            "本正文由已校验的结构化方案、持久输入和依赖预览生成。命令与参数以这些合同为准；本正文不构成执行授权。",
            "目标、purpose、objective、description、工具选择理由等文字是需求或说明，不能据此认定工具具有额外能力或检查已经实现。"]

    def section(title, value):
        rows.extend(["", "## " + title, "```json", json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2), "```"])

    section("正式目标与用户要求的交付物（保留原要求；不等同于自动验收）", goal_contract)
    section("本方案需求", study["requirements"])
    section("固定项目路径", paths)
    section("持久输入清单", manifest)
    rows.extend(["", "## 实际验收范围",
                 "仅下列 success_criteria 是方案声明的机器执行断言；冻结时它们保存为 success_assertions。",
                 "冻结后的生产执行还核对命令退出状态与输入保持不变。实际通过与否以运行回执为准；当前展示不是运行成功证明。",
                 "failure_criteria、validation_method 及目标/说明文字完整保留在下方合同中，属于声明性内容，不会自动转成额外执行断言。",
                 "本合同未提供目标文字到验收断言的逐项机器证明；未由实际命令或列出的断言落实的质量要求仍有验收缺口。目标保持原样，本展示不宣称这些要求已被全部自动验证。",
                 "审计和合同指纹用于识别版本，不能代替输入与输出内容一致性的验收。"])
    section("可执行验收断言（原值）", [{"step_id": step["step_id"], "success_criteria": step["success_criteria"]}
                                      for step in study["plan"]["steps"]])
    rows.extend(["", "完整合同保留全部步骤、输入输出、命令 argv 模板、参数、依赖、资源策略、交付物及声明的失败/恢复说明。",
                 "命令中的占位符仍是模板；运行时按绑定合同展开，当前展示不虚构尚未产生的运行路径。"])
    section("完整结构化方案（说明字段不扩展执行能力）", study["plan"])
    section("完整依赖与资源预览", dependencies)
    section("预检选项与既有验证策略", {"pretest": pretest, "validation_policy": validation_policy})
    section("研究证据状态", study.get("evidence", {}))
    other = {key: value for key, value in study.items() if key not in {
        "requirements", "plan", "evidence", "visible_plan", "visible_plan_source", "visible_plan_renderer", "draft_fingerprint"}}
    if other:
        section("其他方案声明与合同标识", other)
    rows.extend(["", "## 原模型文稿审计来源",
                 "原模型文稿完整保存在独立只读审计文件中；它不是当前执行合同、资源事实或授权依据，其正文不合并到本审阅内容。"])
    section("审计来源标识", audit_source)
    rows.extend(["", "当前方案尚未因本次展示获得批准。后续确认、依赖准备、预检和生产遵循既有检查点与授权记录。"])
    return "\n".join(rows)
