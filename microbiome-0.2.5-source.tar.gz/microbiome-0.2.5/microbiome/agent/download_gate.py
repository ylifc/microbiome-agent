"""交互式下载确认门（interactive download gate）。

执行阶段遇到计划外网络下载时，不再一律拒绝，而是：
1. 保存整体计划快照（由 A1 负责写盘）；
2. 用本模块从被拦截的命令中抽取待下载清单——名称、归属物种或 SRA 号；
3. 生成询问文案展示给用户并暂停执行；
4. 解析用户回复（全部下载 / 选择编号 / 跳过），确认的资源以 token 集合
   记录在 ``A1._runtime_approved_downloads``，执行守卫据此放行等价命令，
   下载完成后继续执行原计划。

Interactive download confirmation gate. When the execution phase encounters
an unplanned network download it no longer rejects outright; instead it:
1. saves the overall plan snapshot (written by A1);
2. extracts the pending download list from the intercepted command with this
   module — names, host species, or SRA accessions;
3. generates inquiry text shown to the user and pauses execution;
4. parses the user's reply (download all / pick numbers / skip); the approved
   resources are recorded as a token set in ``A1._runtime_approved_downloads``
   and the execution guard lets equivalent commands through; once the
   downloads finish, the original plan resumes.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field


@dataclass
class DownloadItem:
    """一个待确认的网络下载项。tokens 用于执行守卫的等价匹配（任一命中即放行）。

    A pending network download item awaiting confirmation. Its tokens are used
    for equivalence matching by the execution guard (a match on any token lets
    the command through).
    """

    kind: str  # reference | virus | database | sra | file
    label: str  # 展示内容：名称 + 归属物种或 SRA 号
    tokens: frozenset[str] = field(default_factory=frozenset)


def _norm(value: str) -> str:
    """归一化标识符，便于跨命令形式（工具函数/命令行/URL）匹配同一资源。"""
    return re.sub(r"[^a-z0-9]+", "", str(value).lower())


# 常见参考基因组 -> 归属物种（展示用）；键为归一化名称。
_REFERENCE_SPECIES = {
    "grch38": "人 (Homo sapiens)",
    "hg38": "人 (Homo sapiens)",
    "grch37": "人 (Homo sapiens)",
    "hg19": "人 (Homo sapiens)",
    "chm13": "人 (Homo sapiens)",
    "t2tchm13": "人 (Homo sapiens)",
    "hs1": "人 (Homo sapiens)",
    "grcm39": "小鼠 (Mus musculus)",
    "mm39": "小鼠 (Mus musculus)",
    "grcm38": "小鼠 (Mus musculus)",
    "mm10": "小鼠 (Mus musculus)",
    "rn7": "大鼠 (Rattus norvegicus)",
    "rn6": "大鼠 (Rattus norvegicus)",
    "grcz11": "斑马鱼 (Danio rerio)",
    "danrer11": "斑马鱼 (Danio rerio)",
    "bdgp6": "果蝇 (Drosophila melanogaster)",
    "dm6": "果蝇 (Drosophila melanogaster)",
    "wbcel235": "秀丽隐杆线虫 (C. elegans)",
    "saccer3": "酿酒酵母 (S. cerevisiae)",
    "galgal6": "鸡 (Gallus gallus)",
    "canfam6": "犬 (Canis familiaris)",
    "susscr11": "猪 (Sus scrofa)",
    "bostau9": "牛 (Bos taurus)",
    "tair10": "拟南芥 (A. thaliana)",
}

# 同一组装的不同别名（用户确认其中一个，等价名称一并放行）。
_REFERENCE_ALIAS_GROUPS = [
    {"grch38", "hg38"},
    {"grch37", "hg19"},
    {"chm13", "t2tchm13", "hs1"},
    {"grcm39", "mm39"},
    {"grcm38", "mm10"},
    {"grcz11", "danrer11"},
    {"bdgp6", "dm6"},
]


def _reference_tokens(name: str) -> frozenset[str]:
    key = _norm(name)
    tokens = {key}
    for group in _REFERENCE_ALIAS_GROUPS:
        if key in group:
            tokens.update(group)
    return frozenset(token for token in tokens if token)


_SRA_RE = re.compile(r"\b([SED]RR\d+)\b", re.IGNORECASE)
_REF_CALL_RE = re.compile(r"download_reference_(?:genome|sequences)\(\s*[\"']([^\"']+)[\"']", re.IGNORECASE)
_VIRUS_CALL_RE = re.compile(r"download_virus_genomes\(([^)]*)\)", re.IGNORECASE | re.DOTALL)
_GGET_REF_RE = re.compile(r"\bgget\s+ref\s+([^\s;&|)]+)", re.IGNORECASE)
_GGET_VIRUS_RE = re.compile(r"\bgget\s+virus\s+([^\s;&|)]+)", re.IGNORECASE)
_DATASETS_VIRUS_RE = re.compile(r"\bdatasets\s+download\s+virus\s+(?:taxon\s+)?([^\s;&|)]+)", re.IGNORECASE)
_DB_CALL_RE = re.compile(r"(?:download_database|ensure_database)\(\s*[\"']([^\"']+)[\"']", re.IGNORECASE)
_DB_PATH_RE = re.compile(r"[Dd]atabase/([A-Za-z0-9_.-]+)")
_URL_RE = re.compile(r"https?://[^\s\"'<>);]+")
_QUOTED_RE = re.compile(r"[\"']([^\"']+)[\"']")


def _url_stem(url: str) -> str:
    """从 URL 提取归一化的文件主名（去掉压缩/格式扩展名），用作等价 token。"""
    basename = url.rstrip("/").rsplit("/", 1)[-1]
    stem = re.sub(
        r"(\.(fa|fasta|fna|fastq|fq|gz|zip|tar|tgz|bz2|xz|gff\d?|gtf|bed|txt|json|tsv|csv|hmm|dmnd))+$",
        "",
        basename.lower(),
    )
    return _norm(stem or basename)


def extract_download_items(code: str) -> list[DownloadItem]:
    """从被拦截的命令中抽取待下载清单（名称 + 归属物种 / SRA 号 / 数据库 id）。

    Extract the pending download list from an intercepted command (names +
    host species / SRA accessions / database ids).
    """
    items: list[DownloadItem] = []
    seen: set[str] = set()
    covered: set[str] = set()

    def _add(kind: str, label: str, tokens) -> None:
        tokens = frozenset(t for t in tokens if t)
        if not tokens or label in seen:
            return
        seen.add(label)
        covered.update(tokens)
        items.append(DownloadItem(kind=kind, label=label, tokens=tokens))

    for name in _REF_CALL_RE.findall(code or ""):
        species = _REFERENCE_SPECIES.get(_norm(name), "物种未在命令中注明 / species not specified in the command")
        _add("reference", f"参考基因组 {name}（{species}）", _reference_tokens(name))

    for blob in _VIRUS_CALL_RE.findall(code or ""):
        names = [n for n in _QUOTED_RE.findall(blob) if n.strip()]
        if names:
            label = "、".join(names)
            _add("virus", f"病毒基因组 {label} / Virus genomes {label}", {_norm(n) for n in names})

    for arg in _GGET_REF_RE.findall(code or ""):
        arg = arg.strip("'\"")
        species = _REFERENCE_SPECIES.get(_norm(arg), f"物种：{arg} / Species: {arg}")
        _add("reference", f"gget ref 参考序列（{species}）/ gget ref reference sequences ({species})", _reference_tokens(arg))

    for arg in list(_GGET_VIRUS_RE.findall(code or "")) + list(_DATASETS_VIRUS_RE.findall(code or "")):
        arg = arg.strip("'\"")
        _add("virus", f"病毒基因组（{arg}）/ Virus genomes ({arg})", {_norm(arg)})

    for db_id in _DB_CALL_RE.findall(code or ""):
        key = _norm(db_id)
        _add("database", f"数据库 {db_id}（Database/{db_id}/）/ Database {db_id} (Database/{db_id}/)", {key, f"database/{db_id.lower()}"})

    # Database/ 路径只认已知数据库目录名，避免把 output_dir="Database/reference-genomes/"
    # 这类普通输出目录误报为数据库下载项。
    _known_db_terms = ("gtdb", "swissprot", "checkv", "genomad", "checkm", "kraken", "card", "uniprot", "uniref", "pfam", "rfam", "bakta", "dbcan")
    for db_id in _DB_PATH_RE.findall(code or ""):
        key = _norm(db_id)
        if key and key not in covered and any(term in db_id.lower() for term in _known_db_terms):
            _add("database", f"数据库 {db_id}（Database/{db_id}/）/ Database {db_id} (Database/{db_id}/)", {key, f"database/{db_id.lower()}"})

    for acc in dict.fromkeys(a.upper() for a in _SRA_RE.findall(code or "")):
        _add("sra", f"SRA 序列 {acc}（归属物种见 NCBI 元数据）/ SRA sequence {acc} (host species per NCBI metadata)", {_norm(acc)})

    for url in _URL_RE.findall(code or ""):
        stem = _url_stem(url)
        if stem and stem in covered:
            continue  # 与上面已识别的资源是同一文件（如先列参考基因组再出现其 URL）
        basename = url.rstrip("/").rsplit("/", 1)[-1] or url
        host = re.sub(r"^https?://", "", url).split("/", 1)[0]
        _add("file", f"文件 {basename}（来自 {host}）/ File {basename} (from {host})", {url.lower(), stem})

    return items


def downloads_runtime_approved(code: str, runtime_approved) -> bool:
    """被拦截代码中的全部下载项都已被用户运行时确认时返回 True。

    无法识别出任何下载项时不放行（保持原有的拒绝行为，由用户改写命令）。

    Return True when every download item in the intercepted code has already
    been confirmed by the user at runtime. When no download item can be
    recognized the command is not allowed through (the original rejection
    behavior is kept; the user rewrites the command).
    """
    approved = {_norm(t) if not t.startswith("http") else t.lower() for t in (runtime_approved or set())}
    approved |= set(runtime_approved or set())
    items = extract_download_items(code)
    if not items:
        return False
    return all(item.tokens & approved for item in items)



def format_download_inquiry(items: list[DownloadItem], plan_path: str, phase: str = "pilot") -> str:
    """生成展示给用户的下载确认清单（编号、名称、归属物种或 SRA 号）。

    Generate the download confirmation list shown to the user (numbers, names,
    host species, or SRA accessions).
    """
    phase_label = "小数据试跑（验证）/ pilot run (validation)" if phase == "pilot" else "全量数据 / full data"
    lines = [
        "📥 下载确认请求 —— 执行已暂停，等待您确认 / 📥 Download confirmation request — execution paused, awaiting your confirmation",
        "",
        f"整体计划已保存：{plan_path or '(快照写入失败，计划见上方对话)'} / Overall plan saved: {plan_path or '(snapshot write failed; see the plan in the conversation above)'}",
        f"当前阶段：{phase_label}。继续执行需要下载以下 {len(items)} 项网络数据：/ Current phase: {phase_label}. Continuing requires downloading the following {len(items)} network data items:",
        "",
    ]
    for index, item in enumerate(items, start=1):
        lines.append(f"  {index}. {item.label}")
    lines += [
        "",
        "回复方式：/ How to reply:",
        "  • “确认下载” —— 下载以上全部 / • “Confirm download” — download all of the above",
        "  • “下载 1,3” —— 只下载指定编号 / • “Download 1,3” — download only the selected numbers",
        "  • “跳过下载” —— 不下载，返回方案讨论（可改用本地已就绪资源） / • “Skip download” — do not download and return to plan discussion (local ready resources may be used instead)",
        "",
        "确认后立即开始下载（实时显示进度与网速，停滞自动重试、断点续传），完成后继续执行原计划。 / Downloads start immediately after confirmation (live progress and speed, automatic retry on stall, resumable transfer); the original plan resumes afterwards.",
    ]
    return "\n".join(lines)


_DECLINE_MARKERS = (
    "不下载", "跳过下载", "跳过", "取消下载", "取消", "拒绝", "别下", "先不下",
    "不用下载", "都不要", "暂不", "no download", "skip", "cancel",
)
_APPROVE_ALL = {
    "确认下载", "全部下载", "下载全部", "同意下载", "都下载", "全部下",
    "确认全部下载", "可以下载", "开始下载", "都下", "全下", "全都要",
}
_APPROVE_ALL_EN = {
    "download all", "confirm download", "confirm downloads", "approve download",
    "approve downloads", "yes download", "download them", "download everything",
}


def parse_download_reply(text: str, items: list[DownloadItem]) -> tuple[str, list[DownloadItem]]:
    """解析用户对下载清单的回复。

    返回 (status, approved_items)：status ∈ {"approved", "declined", "unclear"}。
    注意“确认执行”“确认全量执行”等不含“下载”的确认一律视为 unclear，
    避免把方案确认误当成下载授权。

    Parse the user's reply to the download list. Returns
    (status, approved_items) with status ∈ {"approved", "declined", "unclear"}.
    Confirmations that do not mention “下载” (download), such as “确认执行”
    (confirm execution) or “确认全量执行” (confirm full execution), are always
    treated as unclear so a plan confirmation is never mistaken for a download
    authorization.
    """
    if not isinstance(text, str) or not text.strip() or not items:
        return ("unclear", [])
    lowered = text.strip().lower()

    if any(marker in lowered for marker in _DECLINE_MARKERS):
        return ("declined", [])

    compact = re.sub(r"[\s，。！？、；：,.!?;:'\"`]+", "", lowered)
    if compact in _APPROVE_ALL:
        return ("approved", list(items))
    english = re.sub(r"[^a-z]+", " ", lowered).strip()
    if english in _APPROVE_ALL_EN:
        return ("approved", list(items))
    if "下载" in compact and not re.search(r"\d", compact) and ("全部" in compact or "都" in compact):
        return ("approved", list(items))

    # 编号子集：“下载 1,3”“只下载1”“1和3”“1,3”
    if "下载" in lowered or "download" in lowered or re.fullmatch(r"[\d\s,，、和]+", lowered.replace("and", "，")):
        numbers = [int(n) for n in re.findall(r"\d+", lowered)]
        if numbers and all(1 <= n <= len(items) for n in numbers):
            picked: list[DownloadItem] = []
            for n in dict.fromkeys(numbers):
                picked.append(items[n - 1])
            return ("approved", picked)
    return ("unclear", [])

