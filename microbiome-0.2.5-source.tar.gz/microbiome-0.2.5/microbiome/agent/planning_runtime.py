"""Durable, bounded planning calls; this module grants no execution authority."""
from __future__ import annotations

from copy import deepcopy
import hashlib
from pathlib import Path
import re

from microbiome.pipeline.errors import ConfigurationError
from microbiome.pipeline.io import object_fingerprint, read_json, write_json


# Only installed compiler/input-contract code can establish a new repair round.
# Model messages, policy overrides, host profiles and recovery tokens are absent.
_COMPILER_CONTRACT_FILES = (
    "pipeline/study.py", "pipeline/models.py", "pipeline/planning_inputs.py",
    "pipeline/external_cohort.py", "pipeline/derived.py", "pipeline/planning_context.py",
    "pipeline/commands.py",
)


def compiler_contract():
    root = Path(__file__).resolve().parents[1]
    files = {name: hashlib.sha256((root / name).read_bytes()).hexdigest()
             for name in _COMPILER_CONTRACT_FILES}
    return {"schema_version": 1, "files": files, "fingerprint": object_fingerprint(files)}


def _bind_format_round(ledger, contract):
    """Upgrade once, retaining every cumulative counter and old call receipt."""
    if "format_repair_rounds" not in ledger:
        ledger["format_repair_rounds"] = {"legacy_unversioned": {
            "contract_fingerprint": "legacy_unversioned", "reason": "LEGACY_UNVERSIONED_MIGRATION",
            "previous_schema_version": ledger.get("schema_version", 1),
            "format_repairs": ledger.get("format_repairs", 0),
            "model_calls_at_migration": ledger.get("model_calls", 0),
            "call_receipts_at_migration": len(ledger.get("calls", [])),
        }}
        ledger.setdefault("format_round_events", []).append({
            "reason": "LEGACY_UNVERSIONED_MIGRATION", "previous_contract": "legacy_unversioned",
            "next_contract": contract["fingerprint"], "model_calls": ledger.get("model_calls", 0),
            "format_repairs": ledger.get("format_repairs", 0)})
    ledger["schema_version"] = 2
    rounds = ledger["format_repair_rounds"]
    identity = contract["fingerprint"]
    previous = ledger.get("active_format_contract")
    if identity not in rounds:
        rounds[identity] = {"contract_fingerprint": identity, "contract_files": deepcopy(contract["files"]),
                            "format_repairs": 0, "started_at_model_calls": ledger.get("model_calls", 0),
                            "started_at_call_sequence": len(ledger.get("calls", []))}
    if previous and previous != identity:
        ledger.setdefault("format_round_events", []).append({
            "reason": "LOCAL_COMPILER_CONTRACT_CHANGED", "previous_contract": previous,
            "next_contract": identity, "model_calls": ledger.get("model_calls", 0),
            "format_repairs": ledger.get("format_repairs", 0)})
    ledger["active_format_contract"] = identity
    return rounds[identity]


def _bind_convergence_round(ledger, contract, *, saved=None):
    """Account for convergence independently of the resumable checkpoint cursor."""
    identity = contract["fingerprint"]
    if "convergence_contract_rounds" not in ledger:
        saved = saved or {}
        count = saved.get("round", 0)
        count = count if type(count) is int and count >= 0 else 0
        previous = saved.get("compiler_contract_fingerprint") or ledger.get("active_format_contract")
        previous = previous or "legacy_unversioned"
        ledger["convergence_contract_rounds"] = {}
        if count:
            ledger["convergence_contract_rounds"][previous] = {
                "contract_fingerprint": previous, "rounds_started": count,
                "rounds_completed": count, "attempts": [], "migrated_checkpoint_round": count}
        ledger["convergence_rounds_total"] = count
        ledger["convergence_round_events"] = [{
            "reason": "LEGACY_UNVERSIONED_MIGRATION", "checkpoint_round": count,
            "attributed_contract": previous, "next_contract": identity,
            "checkpoint_fingerprint": saved.get("fingerprint"),
            "model_calls": ledger.get("model_calls", 0)}]
    rounds = ledger["convergence_contract_rounds"]
    previous = ledger.get("active_convergence_contract")
    if identity not in rounds:
        rounds[identity] = {"contract_fingerprint": identity, "contract_files": deepcopy(contract["files"]),
                            "rounds_started": 0, "rounds_completed": 0, "attempts": []}
    if previous and previous != identity:
        ledger.setdefault("convergence_round_events", []).append({
            "reason": "LOCAL_COMPILER_CONTRACT_CHANGED", "previous_contract": previous,
            "next_contract": identity, "model_calls": ledger.get("model_calls", 0),
            "convergence_rounds_total": ledger.get("convergence_rounds_total", 0)})
    ledger["active_convergence_contract"] = identity
    return rounds[identity]


def planning_ledger_view(ledger, *, contract=None):
    """Read-only projection includes a prospective new round after code upgrade."""
    if not ledger:
        return None
    projected = deepcopy(ledger)
    convergence = _bind_convergence_round(projected, contract or compiler_contract())
    current = _bind_format_round(projected, contract or compiler_contract())
    return {**{key: projected.get(key, 0) for key in (
                "task_fingerprint", "model_calls", "format_repairs", "technical_adjustments")},
            "active_format_contract": projected["active_format_contract"],
            "model_call_limit": projected.get("model_call_limit", 24),
            "format_repairs_total": projected.get("format_repairs", 0),
            "format_repair_round": {**deepcopy(current), "limit": projected.get("format_repair_limit", 3)},
            "format_repair_rounds": deepcopy(projected["format_repair_rounds"]),
            "convergence_rounds_total": projected.get("convergence_rounds_total", 0),
            "convergence_round": {**deepcopy(convergence), "limit": 3},
            "convergence_contract_rounds": deepcopy(projected["convergence_contract_rounds"]),
            "round_persistence": "recorded" if projected["active_format_contract"] == ledger.get("active_format_contract")
                                 else "pending_local_contract_transition"}


def saved_planning_ledger_view(project, state):
    summary = state.get("planning_ledger")
    if not summary:
        return None
    identity = summary.get("task_fingerprint", "")
    if isinstance(identity, str) and re.fullmatch(r"[a-f0-9]{64}", identity):
        path = project.state_dir / "planning_runs" / (identity + ".json")
        if path.is_file():
            return planning_ledger_view(read_json(path))
    return planning_ledger_view(summary)


def task_fingerprint(state, manifest=None, *, requirements=None):
    from microbiome.agent.input_state import derive_goal_contract
    goal = derive_goal_contract(state, requirements or {})["fingerprint"]
    return object_fingerprint({"goal": goal, "input": manifest})


class PlanningLimitError(ConfigurationError):
    def __init__(self, code, *, measured, limit, policy_fingerprint, ledger=None):
        self.details = {"code": code, "category": "PLANNING_POLICY", "recoverable": True,
                        "consumes_recovery_attempt": False, "requires_user_information": False,
                        "measured": measured, "limit": limit, "policy_fingerprint": policy_fingerprint,
                        "next_action": "inspect_planning_policy_and_checkpoint"}
        if ledger is not None:
            active = ledger.get("active_format_contract")
            current = ledger.get("format_repair_rounds", {}).get(active, {})
            contract = {"fingerprint": active, "files": current.get("contract_files", {})} if active else None
            self.details["planning_ledger"] = planning_ledger_view(ledger, contract=contract)
        if code in {"PLANNING_FORMAT_REPAIR_LIMIT", "PLANNING_CONVERGENCE_LIMIT"}:
            self.details["next_action"] = "inspect_compiler_contract_and_retained_candidate"
            self.details["retry_when"] = "A verified local compiler contract changes; policy/profile changes do not replenish repair or convergence rounds"
        label = ("current compiler-contract repair round" if code == "PLANNING_FORMAT_REPAIR_LIMIT"
                 else "current compiler-contract convergence rounds" if code == "PLANNING_CONVERGENCE_LIMIT"
                 else "planning limit")
        total = f"; cumulative format repairs {ledger['format_repairs']}" if ledger is not None else ""
        super().__init__(f"{code}: {label} {measured}/{limit}{total}; candidate and checkpoint retained.")


class PlanningRuntime:
    """One ledger per substantive task, unchanged by retries or policy revisions.

    The caller holds the project lock. Persist calls before dispatch so a crash
    or an uncertain transport response cannot grant an extra model invocation.
    """
    def __init__(self, workflow, manifest=None):
        self.workflow = workflow
        self.project = workflow.project
        from microbiome.agent.input_state import derive_goal_contract
        from microbiome.pipeline.requirements import RequirementManager
        requirements = RequirementManager(self.project).load()
        self.goal_fingerprint = derive_goal_contract(workflow.state, requirements)["fingerprint"]
        self.input_fingerprint = object_fingerprint(manifest) if manifest is not None else None
        self.task = task_fingerprint(workflow.state, manifest, requirements=requirements)
        self.path = self.project.state_dir / "planning_runs" / f"{self.task}.json"
        existing_ledger = self.path.is_file()
        self.ledger = read_json(self.path) if existing_ledger else {
            "schema_version": 2, "task_fingerprint": self.task,
            "model_calls": 0, "format_repairs": 0, "technical_adjustments": 0, "calls": [],
            "format_repair_rounds": {}, "format_round_events": [],
            "convergence_contract_rounds": {}, "convergence_round_events": [], "convergence_rounds_total": 0}
        self.contract = compiler_contract()
        saved = workflow.state.get("planning_checkpoint") or {}
        if (saved.get("task_fingerprint") != self.task or saved.get("fingerprint") != object_fingerprint(
                {key: value for key, value in saved.items() if key != "fingerprint"})):
            saved = {}
        if saved and not existing_ledger:
            # A legacy checkpoint can predate durable model ledgers. Its cursor
            # is still consumed evidence, not a reason to grant a fresh round.
            self.ledger.pop("convergence_contract_rounds")
        self.previous_compiler_contract = saved.get("compiler_contract_fingerprint") or self.ledger.get("active_format_contract")
        self.convergence_round = _bind_convergence_round(self.ledger, self.contract, saved=saved)
        self.format_round = _bind_format_round(self.ledger, self.contract)

    def _save(self):
        write_json(self.path, self.ledger)
        self.workflow.state["planning_ledger"] = planning_ledger_view(self.ledger, contract=self.contract)
        self.workflow.save()

    def begin_convergence(self, *, resume_attempt=None):
        """Reserve once before compilation; an interrupted attempt remains charged."""
        current = self.workflow.state.get("planning_checkpoint") or {}
        attempts = self.convergence_round["attempts"]
        active = attempts[-1] if attempts else None
        if active and active["status"] == "IN_PROGRESS":
            expected = {"contract_fingerprint": self.contract["fingerprint"], "number": active["number"]}
            if current.get("convergence_attempt") == expected and resume_attempt == expected:
                return expected
            active["status"] = "INTERRUPTED"
        count = self.convergence_round["rounds_started"]
        if count >= 3:
            self._save()
            raise PlanningLimitError("PLANNING_CONVERGENCE_LIMIT", measured=count, limit=3,
                                     policy_fingerprint=self.ledger.get("policy_fingerprint"), ledger=self.ledger)
        self.convergence_round["rounds_started"] += 1
        self.ledger["convergence_rounds_total"] += 1
        attempt = {"number": count + 1, "status": "IN_PROGRESS",
                   "candidate_fingerprint": current.get("candidate_fingerprint"),
                   "started_at_model_calls": self.ledger["model_calls"]}
        attempts.append(attempt)
        self._save()
        return {"contract_fingerprint": self.contract["fingerprint"], "number": attempt["number"]}

    def finish_convergence(self):
        active = self.convergence_round["attempts"][-1]
        if active["status"] == "IN_PROGRESS":
            active["status"] = "COMPLETED"
            active["finished_at_model_calls"] = self.ledger["model_calls"]
            self.convergence_round["rounds_completed"] += 1
            self._save()
        return active["number"]

    def invoke(self, invoke, messages, *, purpose="planning", **kwargs):
        from microbiome.pipeline.planning_policy import get_effective_policy, preflight_model_messages

        policy = get_effective_policy(self.project)
        fingerprint = policy["policy_fingerprint"]
        limits = policy["limits"]
        self.ledger["format_repair_limit"] = limits["max_format_repairs"]
        self.ledger["model_call_limit"] = limits["max_model_calls"]
        previous_settings = self.ledger.get("policy_settings")
        if previous_settings is not None and previous_settings != policy["settings"]:
            count = self.ledger["technical_adjustments"] + 1
            if count > limits["max_technical_adjustments"]:
                raise PlanningLimitError("PLANNING_TECHNICAL_ADJUSTMENT_LIMIT", measured=count,
                                         limit=limits["max_technical_adjustments"], policy_fingerprint=fingerprint,
                                         ledger=self.ledger)
            self.ledger["technical_adjustments"] = count
        self.ledger["policy_fingerprint"] = fingerprint
        self.ledger["policy_settings"] = deepcopy(policy["settings"])
        self._save()
        # Rejected preflight is not a model call or a format repair.
        preflight_model_messages(self.project, messages, purpose=purpose, tools=kwargs.get("tools"))
        counters = [(self.ledger["model_calls"], "max_model_calls", "PLANNING_MODEL_CALL_LIMIT")]
        if purpose == "format_repair":
            counters.append((self.format_round["format_repairs"], "max_format_repairs", "PLANNING_FORMAT_REPAIR_LIMIT"))
        for measured, limit_name, code in counters:
            if measured >= limits[limit_name]:
                raise PlanningLimitError(code, measured=measured, limit=limits[limit_name],
                                         policy_fingerprint=fingerprint, ledger=self.ledger)
        self.ledger["model_calls"] += 1
        if purpose == "format_repair":
            self.ledger["format_repairs"] += 1
            self.format_round["format_repairs"] += 1
        call = {"number": self.ledger["model_calls"], "sequence": len(self.ledger["calls"]) + 1,
                "purpose": purpose, "status": "DISPATCHED",
                "policy_fingerprint": fingerprint, "compiler_contract_fingerprint": self.contract["fingerprint"]}
        self.ledger["calls"].append(call)
        self._save()
        try:
            result = invoke(messages, **kwargs)
        except BaseException as error:
            call.update(status="FAILED", error_type=type(error).__name__)
            details = getattr(error, "details", {})
            if isinstance(details, dict) and (details.get("model_request_dispatched") is False
                    or details.get("transport_attempts") == 0):
                # Only an explicit transport-boundary receipt can prove that
                # the persisted reservation did not become a real API call.
                self.ledger["model_calls"] -= 1
                if purpose == "format_repair":
                    self.ledger["format_repairs"] -= 1
                    self.format_round["format_repairs"] -= 1
                call["status"] = "REJECTED_BEFORE_DISPATCH"
            self._save()
            raise
        call["status"] = "RETURNED"
        usage = getattr(result, "usage_metadata", None)
        if isinstance(usage, dict):
            call["usage"] = {k: v for k, v in usage.items() if isinstance(v, (int, float))}
        self._save()
        return result

    def visible(self, agent, messages):
        # Native review receives resource facts from the structured dependency
        # preview. Free text may mention rejected alternatives; those mentions
        # must never select bindings or acquisition proposals for this draft.
        absent = object()
        previous = getattr(agent, "_structured_plan_bindings", absent)
        agent._structured_plan_bindings = True
        try:
            return self._visible(agent, messages)
        finally:
            if previous is absent:
                del agent._structured_plan_bindings
            else:
                agent._structured_plan_bindings = previous

    def _visible(self, agent, messages):
        # A1 adds a system prompt and may invoke several times for read-only
        # discovery/refinement. Guard each final message list, not just history.
        original = getattr(agent, "llm", None)
        if original is None:  # Adapters that provide their own single-call planner.
            return self.invoke(agent._invoke_planning_model, messages, purpose="visible_plan")
        runtime = self
        blocked = []

        class GuardedModel:
            def __getattr__(self, name):
                return getattr(original, name)

            def invoke(self, messages, **kwargs):
                try:
                    return runtime.invoke(original.invoke, messages, purpose="visible_plan", **kwargs)
                except ConfigurationError as error:
                    if getattr(error, "details", {}).get("category") == "PLANNING_POLICY":
                        blocked.append(error)
                    raise

        agent.llm = GuardedModel()
        try:
            result = agent._invoke_planning_model(messages)
            if blocked:  # Optional refinement must not swallow a budget stop.
                raise blocked[0]
            return result
        finally:
            agent.llm = original

    def compiler(self, agent):
        return lambda messages, *, purpose="compile": self.invoke(agent.llm.invoke, messages, purpose=purpose)


def _resource_contracts(project):
    """Hash semantic registry contracts without reading resource/sample files."""
    from microbiome.agent.recovery import _registry_contract

    registries = {path.name: object_fingerprint(_registry_contract(path)) for path in (
        project.tool_registry_path, project.database_registry_path, project.tool_alias_registry_path)}
    return {"registries": registries, "fingerprint": object_fingerprint(registries)}


def _policy_snapshot(project):
    from microbiome.pipeline.planning_policy import get_effective_policy

    policy = get_effective_policy(project)
    return {**{key: deepcopy(policy.get(key)) for key in (
        "schema_version", "message_builder_version", "revision", "policy_fingerprint", "settings", "limits")},
        "host_capacity": {"source": policy.get("capacity_source"),
            "profile_fingerprint": policy.get("host_profile_fingerprint"),
            **{key: policy["limits"][key] for key in (
                "context_window_tokens", "output_reserve_tokens", "protocol_margin_tokens")}}}


def checkpoint(workflow, runtime, *, stage, candidate=None, validated=None, **fields):
    """Save a candidate before the next context build; never mark it approved."""
    current = workflow.state.get("planning_checkpoint") or {}
    if current.get("task_fingerprint") != runtime.task:
        current = {"schema_version": 1, "task_fingerprint": runtime.task, "round": 0}
    current = deepcopy(current)
    current.update(stage=stage, **fields)
    current["compiler_contract_fingerprint"] = runtime.contract["fingerprint"]
    # Keep old explicit cursors auditable without ever replenishing the ledger.
    observed_round = current.get("round", 0)
    if type(observed_round) is int and observed_round > runtime.convergence_round["rounds_started"]:
        difference = observed_round - runtime.convergence_round["rounds_started"]
        runtime.convergence_round["rounds_started"] = observed_round
        runtime.convergence_round["rounds_completed"] = max(
            observed_round, runtime.convergence_round["rounds_completed"])
        runtime.ledger["convergence_rounds_total"] += difference
    runtime._save()
    current["policy_snapshot"] = _policy_snapshot(workflow.project)
    current["contract_links"] = {"task_fingerprint": runtime.task,
                                 "input_manifest_fingerprint": runtime.input_fingerprint,
                                 "goal_fingerprint": runtime.goal_fingerprint}
    current["resource_contracts"] = _resource_contracts(workflow.project)
    if candidate is not None:
        current["candidate"] = deepcopy(candidate)
        current["candidate_fingerprint"] = object_fingerprint(candidate)
    if validated is not None:
        current["validated"] = validated
    current["fingerprint"] = object_fingerprint({k: v for k, v in current.items() if k != "fingerprint"})
    workflow.state["planning_checkpoint"] = current
    workflow.save()
    return current


def restore_checkpoint(workflow, runtime):
    current = workflow.state.get("planning_checkpoint") or {}
    if (current.get("task_fingerprint") != runtime.task or current.get("stage") == "COMPLETE"
            or current.get("fingerprint") != object_fingerprint({k: v for k, v in current.items()
                                                                 if k != "fingerprint"})):
        return None
    previous_compiler = current.get("compiler_contract_fingerprint") or runtime.previous_compiler_contract
    if previous_compiler != runtime.contract["fingerprint"]:
        return checkpoint(workflow, runtime, stage="BUILD_RESOURCE_CONTEXT",
            round=runtime.convergence_round["rounds_completed"], convergence_attempt=None,
            previous_resource_receipt=current.get("resource_receipt"), resource_receipt=None,
            compiler_revalidation={"required": True,
                "reason": "LOCAL_COMPILER_CONTRACT_CHANGED" if previous_compiler else "LEGACY_UNVERSIONED_MIGRATION",
                "previous_contract": previous_compiler or "legacy_unversioned",
                "current_contract": runtime.contract["fingerprint"],
                "previous_round": current.get("round", 0),
                "retained_candidate_fingerprint": object_fingerprint(
                    current.get("pending_candidate") or current.get("candidate"))})
    observed = _resource_contracts(workflow.project)
    previous = current.get("resource_contracts") or {}
    if previous.get("fingerprint") != observed["fingerprint"]:
        # An accepted candidate remains useful evidence, but a completed resource
        # scope cannot survive registry drift. Preserve the total model ledger;
        # the checkpoint cursor restarts, but the compiler-contract allowance
        # remains charged in the separate durable convergence ledger.
        return checkpoint(workflow, runtime, stage="BUILD_RESOURCE_CONTEXT", round=0,
            previous_resource_receipt=current.get("resource_receipt"), resource_receipt=None,
            resource_revalidation={"reason": "RESOURCE_CONTRACT_CHANGED" if previous else "RESOURCE_PROVENANCE_MISSING",
                "previous_fingerprint": previous.get("fingerprint"), "current_fingerprint": observed["fingerprint"],
                "previous_round": current.get("round", 0)})
    return deepcopy(current)
