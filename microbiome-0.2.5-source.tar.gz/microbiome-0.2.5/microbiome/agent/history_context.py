"""Lossless history projections governed by the project's planning policy."""

from microbiome.conversation_memory import (
    ConversationMemoryOverflow,
    build_conversation_memory,
    user_context,
)
from microbiome.pipeline.planning_policy import PlanningPolicyError, get_effective_policy


def _project_history_view(project, history, builder):
    policy = get_effective_policy(project)
    limit = policy["settings"]["history_bytes"]
    try:
        return builder(history, max_user_bytes=limit)
    except ConversationMemoryOverflow as error:
        raise PlanningPolicyError(
            "PLANNING_HISTORY_LIMIT",
            "完整用户历史超过当前规划历史预算；原始事件和目标保持不变，未发送模型请求。",
            field="history_bytes", measured=error.measured, limit=limit,
            maximum=policy["limits"]["max_history_bytes"],
            policy_fingerprint=policy["policy_fingerprint"], policy_revision=policy["revision"],
            model_request_dispatched=False, transport_attempts=0,
            requires_user_information=False,
            preserved=["conversation_history", "goal_contract", "requirements_draft", "input_manifest"],
            next_action={"tool": "microbiome_maintenance", "operation": "planning_policy",
                         "arguments": {"action": "inspect"}, "owner": "controller",
                         "reason": "Inspect and adjust history_bytes within the project ceiling; preserve all user facts"},
        ) from error


def project_conversation_memory(project, history):
    return _project_history_view(project, history, build_conversation_memory)


def project_user_context(project, history):
    return _project_history_view(project, history, user_context)
