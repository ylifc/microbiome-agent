"""Persist conversational analysis plans as editable, durable design artifacts.

The conversational :class:`~microbiome.agent.a1.A1` agent produces a natural-language
Markdown plan. These helpers write that plan — plus a light structured outline — into
the results tree so the user always has an editable experimental-design document,
independent of the strict frozen pipeline's ``experiment_plan.yaml`` (which is
auto-backfilled from verified execution facts by ``microbiome.pipeline.synthesize``).

The draft outline here is deliberately relaxed: it is a human-editable design
artifact, not the production-validated schema in ``microbiome.pipeline.models``.
"""

from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path
from typing import Any


def _utcnow() -> str:
    return datetime.now().isoformat(timespec="seconds")


_STEP_ITEM_RE = re.compile(r"^(?:[-*+]|\d{1,2}[.)、])\s+(.+)$")
_HEADING_RE = re.compile(r"^#{1,3}\s+(.+)$")
_SKIP_HEADINGS = ("分析方案", "任务", "目标", "输入", "plan", "task", "objective", "input")


def extract_plan_outline(task: str, markdown_plan: str) -> dict[str, Any]:
    """Extract a best-effort, deterministic outline from a Markdown plan.

    Steps come from numbered/bulleted list items first, then fall back to Markdown
    headings. The result is an editable design draft, never a validated production
    plan.
    """
    steps: list[str] = []
    for line in (markdown_plan or "").splitlines():
        match = _STEP_ITEM_RE.match(line.strip())
        if match and len(match.group(1)) > 2:
            steps.append(match.group(1).strip())

    if not steps:
        for line in (markdown_plan or "").splitlines():
            match = _HEADING_RE.match(line.strip())
            if match:
                heading = match.group(1).strip()
                if heading.lower().startswith(_SKIP_HEADINGS):
                    continue
                steps.append(heading)

    if not steps:
        steps = ["待补充：请在此填写分析步骤 / To be filled in: please add the analysis steps here"]

    seen: set[str] = set()
    unique_steps: list[str] = []
    for step in steps:
        if step not in seen:
            seen.add(step)
            unique_steps.append(step)

    return {
        "plan_source": "conversational_draft",
        "generated_at": _utcnow(),
        "task": (task or "").strip(),
        "objective": (task or "").strip(),
        "steps": unique_steps,
        "note": (
            "This is a human-editable design draft derived from the conversational plan. "
            "The authoritative production plan is auto-generated from verified pre-test "
            "execution facts (see microbiome.pipeline.synthesize)."
        ),
    }


def persist_plan_draft(results_root: str | Path, task: str, markdown_plan: str) -> dict[str, str]:
    """Write the Markdown plan and a light YAML outline under ``<root>/plans/``.

    Returns a dict of written paths keyed by ``markdown``, ``markdown_history``,
    ``yaml``, and ``yaml_history``. The stable ``analysis_plan_latest.*`` files are
    overwritten so the latest design is easy to find; a timestamped copy preserves
    history.
    """
    import yaml

    root = Path(results_root)
    plans_dir = root / "plans"
    plans_dir.mkdir(parents=True, exist_ok=True)

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    outline = extract_plan_outline(task, markdown_plan)

    md_latest = plans_dir / "analysis_plan_latest.md"
    md_stamped = plans_dir / f"analysis_plan_{stamp}.md"
    yaml_latest = plans_dir / "analysis_plan_latest.yaml"
    yaml_stamped = plans_dir / f"analysis_plan_{stamp}.yaml"

    header = (
        "# 实验设计方案（对话生成，可编辑）\n"
        "# Experimental Design Plan (conversation-generated, editable)\n\n"
        f"- 生成时间：{outline['generated_at']}\n"
        f"- Generated at: {outline['generated_at']}\n"
        f"- 任务：{outline['task'] or '(未记录)'}\n"
        f"- Task: {outline['task'] or '(not recorded)'}\n\n"
    )
    body = header + (markdown_plan or "").strip() + "\n"
    md_latest.write_text(body, encoding="utf-8")
    md_stamped.write_text(body, encoding="utf-8")

    yaml_text = yaml.safe_dump(outline, allow_unicode=True, sort_keys=False)
    yaml_latest.write_text(yaml_text, encoding="utf-8")
    yaml_stamped.write_text(yaml_text, encoding="utf-8")

    return {
        "markdown": str(md_latest),
        "markdown_history": str(md_stamped),
        "yaml": str(yaml_latest),
        "yaml_history": str(yaml_stamped),
    }
