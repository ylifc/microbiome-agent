"""Read-only evidence keys for bounded planning recovery, never execution consent."""
from __future__ import annotations

import os
import hashlib
import re
from pathlib import Path

from microbiome.pipeline.io import manifest_fingerprint, object_fingerprint, read_json, read_yaml
from microbiome.pipeline.diagnostics import normalized_candidate


RECOVERY_EVIDENCE_VERSION = 3
_JOURNAL_FIELDS = {"updated_at", "created_at", "validated_at", "installed_at", "last_checked_at",
                   "last_successful_use", "timestamp", "checked_at", "created_by"}
def effective_goal_facts(state):
    """Compatibility view of the single authoritative user-fact projection."""
    from microbiome.agent.input_state import derive_goal_contract

    return derive_goal_contract(state, {})["user_facts"]


def _registry_contract(path):
    """Parse semantic contracts: comments and maintenance timestamps are not facts."""
    if not path.is_file():
        return None
    try:
        value = read_yaml(path)
    except Exception as error:
        # Invalid bytes remain evidence, but are never mistaken for a READY registry.
        return {"invalid": type(error).__name__, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
    if not isinstance(value, dict):
        return {"invalid": "not_mapping", "value": value}
    result = {key: item for key, item in value.items()
              if key not in _JOURNAL_FIELDS and key != "manifest_fingerprint"}
    # A corrupt seal is materially different from a valid contract. A proper
    # timestamp-only reseal, however, must not create a new recovery attempt.
    if "manifest_fingerprint" in value:
        result["integrity_valid"] = value["manifest_fingerprint"] == manifest_fingerprint(value)
    for collection in ("tools", "resources", "aliases"):
        if isinstance(result.get(collection), dict):
            result[collection] = {name: ({key: item for key, item in entry.items()
                                         if key not in _JOURNAL_FIELDS} if isinstance(entry, dict) else entry)
                                  for name, entry in result[collection].items()}
    return result


def _observations(root, excluded=(), maximum=4096):
    """Bounded file metadata only; do not follow symlinks or read sample data."""
    result = []
    root = Path(root)
    if not root.is_dir():
        return {"exists": root.exists(), "entries": []}
    for directory_count, (directory, dirs, files) in enumerate(os.walk(root, followlinks=False)):
        if directory_count >= 512:
            return {"exists": True, "entries": result, "truncated": True}
        dirs[:] = sorted(d for d in dirs if not d.startswith('.') and not (Path(directory) / d).is_symlink()
                         and (Path(directory) / d).resolve() not in excluded)
        for name in sorted(files):
            if not (name.lower().endswith(('.fastq', '.fq', '.fasta', '.fa', '.fna', '.fastq.gz', '.fq.gz',
                                           '.fasta.gz', '.fa.gz')) or re.fullmatch(
                    r'(?:sample[_-]?(?:list|manifest|sheet)|samples|manifest)\.(?:csv|tsv|txt|json|yaml)',
                    name, re.IGNORECASE)):
                continue
            path = Path(directory) / name
            try:
                stat = path.lstat()
                result.append([str(path.relative_to(root)), stat.st_size, stat.st_mtime_ns, stat.st_mode])
            except OSError:
                continue
            if len(result) >= maximum:
                return {"exists": True, "entries": result, "truncated": True}
    return {"exists": True, "entries": result, "truncated": False}


def planning_recovery_snapshot(project):
    from microbiome.agent.input_state import derive_goal_contract, input_is_protected
    from microbiome.conversation_memory import pending_design_questions
    from microbiome.pipeline.state import ProjectStateMachine
    from microbiome.pipeline.requirements import RequirementManager

    path = project.state_dir / 'conversation.json'
    state = read_json(path) if path.is_file() else {}
    available = True
    reason = 'PLANNING_RECOVERY_AVAILABLE'
    if input_is_protected(project):
        available, reason = False, 'PROTECTED_PHASE'
    elif not any(row.get('role') == 'user' for row in state.get('history', [])):
        available, reason = False, 'NO_USER_TASK'
    elif pending_design_questions(state):
        available, reason = False, 'NEEDS_USER_ANSWER'
    elif state.get('draft') and not state.get('input_error') and not state.get('compiler_repair'):
        available, reason = False, 'PLAN_ALREADY_READY'
    config = project.load_config()
    manifest_path = project.requirements_dir / 'input_manifest.yaml'
    manifest = read_yaml(manifest_path) if manifest_path.is_file() else None
    stored_selection = state.get('input_selection') or {}
    selection = {key: stored_selection.get(key) for key in
        ('mode', 'paths', 'resources', 'ambiguous_paths', 'layout', 'remote_ids', 'search_roots')
        if key in stored_selection}
    checkpoint = state.get('planning_checkpoint') or {}
    candidate = normalized_candidate((state.get('compiler_repair') or {}).get('candidate')
                                     or checkpoint.get('pending_candidate') or checkpoint.get('candidate'))
    from microbiome.version import __version__
    registries = {path.name: _registry_contract(path)
                  for path in (project.tool_registry_path, project.database_registry_path,
                               project.tool_alias_registry_path)}
    raw_root = Path(config['paths']['raw_data']).resolve()
    excluded = {Path(value).resolve() for key, value in config['paths'].items()
                if key != 'raw_data' and isinstance(value, str) and Path(value).resolve() != raw_root}
    if project.root.resolve() != raw_root:
        excluded.add(project.root.resolve())
    else:
        excluded.update(project.root / name for name in ('state', 'requirements', 'plans', 'pipeline',
                                                         'reports', 'runs', 'logs', 'config'))
    selected_files = []
    for value in selection.get('paths', [])[:4096]:
        path = Path(value).expanduser()
        path = path if path.is_absolute() else raw_root / path
        try:
            stat = path.lstat()
            selected_files.append([str(path), 'directory' if path.is_dir() else [stat.st_size, stat.st_mtime_ns, stat.st_mode]])
        except OSError:
            selected_files.append([str(path), 'missing'])
    source = Path(__file__).resolve().parents[1]
    contracts = {name: hashlib.sha256((source / name).read_bytes()).hexdigest()
                 for name in ('agent/recovery.py', 'agent/workflow.py', 'agent/review_rendering.py', 'input_resolution.py',
                              'pipeline/study.py', 'pipeline/models.py', 'pipeline/diagnostics.py',
                              'pipeline/database_service.py', 'pipeline/planning_policy.py',
                              'pipeline/planning_context.py', 'pipeline/planning_inputs.py',
                              'pipeline/external_cohort.py', 'pipeline/derived.py', 'pipeline/input_commit.py',
                              'agent/planning_runtime.py',
                              'conversation_memory.py', 'agent/input_state.py', 'agent/history_context.py')}
    # Once an explicit selection is verified, unrelated files elsewhere under
    # raw_data are not new planning evidence. Directory discovery still observes
    # newly appearing input candidates without reading sequence contents.
    discover = not manifest or bool(state.get('input_error')) or selection.get('mode') == 'directory'
    inventory = _observations(raw_root, excluded) if discover else None
    from microbiome.pipeline.planning_policy import policy_fingerprint
    from microbiome.agent.planning_runtime import compiler_contract
    material = {'evidence_version': RECOVERY_EVIDENCE_VERSION,
                'compiler_contract_fingerprint': compiler_contract()['fingerprint'],
                'project': str(project.root), 'paths': config['paths'], 'engine_version': __version__,
                'engine_contracts': contracts, 'selected_files': selected_files,
                'resource_registries': registries,
                'selection': selection, 'manifest': manifest,
                'compiler_candidate': candidate,
                # Planning provenance is never a new production prerequisite.
                'planning_policy': None if reason == 'PROTECTED_PHASE' else policy_fingerprint(project),
                'planning_checkpoint': {key: checkpoint.get(key) for key in
                                        ('task_fingerprint', 'stage', 'round', 'candidate_fingerprint')},
                'raw_inventory': inventory,
                'task': derive_goal_contract(state, RequirementManager(project).load())['fingerprint']}
    token = object_fingerprint(material)
    attempted = project.state_dir / 'harness' / f'recovery-{token}.json'
    attempt = read_json(attempted) if attempted.is_file() else {}
    busy_attempt = (attempt.get('error', {}).get('code') == 'PROJECT_BUSY'
                    if isinstance(attempt.get('error'), dict) else 'PROJECT_BUSY' in str(attempt.get('error', '')))
    if available and attempted.is_file() and not busy_attempt:
        available, reason = False, 'UNCHANGED_ATTEMPT_RECORDED'
    from microbiome.agent.planning_runtime import saved_planning_ledger_view
    return {'available': available, 'reason': reason, 'recovery_token': token,
            'checkpoint': 'INPUT_RESOLUTION' if state.get('input_error') else checkpoint.get('stage', 'PLAN_COMPILATION'),
            'candidate_available': bool(candidate),
            'planning_policy_fingerprint': material['planning_policy'],
            'planning_ledger': saved_planning_ledger_view(project, state),
            'state': ProjectStateMachine(project).current.value,
            'evidence_version': RECOVERY_EVIDENCE_VERSION,
            'input_revision': (state.get('input_declarations') or {}).get('revision', 0),
            'tool': 'microbiome_resume_planning',
            'scope': 'Resolve persisted inputs and compile a reviewable plan; no approval or execution.'}
