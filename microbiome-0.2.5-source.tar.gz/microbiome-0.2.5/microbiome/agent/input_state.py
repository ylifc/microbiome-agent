"""Auditable input declarations and unconfirmed conversation requirements.

This is control-plane persistence only: no downloads, analysis, resource edits,
or approval creation. Callers serialize modifications under the project lock.
"""

from __future__ import annotations

import re
import unicodedata
from copy import deepcopy
from datetime import UTC, datetime
from pathlib import Path

from microbiome.pipeline.errors import ConfigurationError
from microbiome.pipeline.io import object_fingerprint, read_json, read_yaml, write_json
from microbiome.pipeline.requirements import ConfirmationAction, RequirementManager
from microbiome.pipeline.state import LifecycleState, ProjectStateMachine


_EDITABLE = {
    LifecycleState.NEW, LifecycleState.PATH_CONFIRMATION, LifecycleState.DATA_DISCOVERY,
    LifecycleState.DATA_CHARACTERIZATION, LifecycleState.GOAL_DEFINITION,
    LifecycleState.REQUIREMENTS_CONFIRMED, LifecycleState.RESOURCE_DISCOVERY,
    LifecycleState.EVIDENCE_REVIEW, LifecycleState.PLAN_DRAFTING,
    LifecycleState.PLAN_CONFIRMATION, LifecycleState.DEPENDENCY_REVIEW,
    LifecycleState.INSTALL_APPROVAL, LifecycleState.PLAN_MODIFICATION,
}


def input_is_protected(project):
    return (project.pipeline_lock_path.is_file()
            or ProjectStateMachine(project).current not in _EDITABLE)


def input_resolver(workflow):
    from microbiome.input_resolution import InputSourceResolver

    config = workflow.project.load_config()
    cfg = config["paths"]
    return InputSourceResolver(cfg["raw_data"], output_root=workflow.project.output_root,
        database_root=cfg.get("database"), download_root=cfg.get("download"),
        knowledge_root=cfg.get("knowledge"), project_root=workflow.project.root,
        workspace_root=config.get("host_workspace"))


def _selection_facts(selection):
    return {key: selection.get(key) for key in (
        "mode", "paths", "resources", "ambiguous_paths", "layout", "remote_ids", "search_roots",
        "sample_records", "structured_source")}


def _new_selection(workflow):
    raw = workflow.project.load_config()["paths"]["raw_data"]
    return {"schema_version": 1, "mode": "directory", "paths": [raw],
            "resources": [], "ambiguous_paths": [], "layout": None, "remote_ids": [],
            "search_roots": [raw], "revision": 0, "processed_history_count": 0,
            "source_message_ids": [], "updates": []}


def _merge_selection(selection, patch, *, replace=False):
    """Apply one message's field facts; never reparse concatenated history."""
    paths = patch.get("paths", [])
    ambiguous = patch.get("ambiguous_paths", [])
    if paths or ambiguous or patch.get("remote_ids"):
        mode = patch["mode"]
        if (not replace and mode == selection.get("mode") == "explicit_files"
                and not ambiguous):
            selection["paths"] = list(dict.fromkeys([*selection["paths"], *paths]))
        else:
            selection["paths"] = list(paths)
        selection["mode"] = mode
        selection["ambiguous_paths"] = list(ambiguous)
        selection["remote_ids"] = list(patch.get("remote_ids", []))
        for key in ("sample_records", "structured_source"):
            if key in patch:
                selection[key] = deepcopy(patch[key])
            else:
                selection.pop(key, None)
        directories = [value for value in paths if Path(value).expanduser().is_dir()]
        if directories:
            selection["search_roots"] = directories
    resources = list(patch.get("resources", []))
    selection["resources"] = list(dict.fromkeys(
        [value for value in selection.get("resources", []) if value not in paths] + resources))
    # A role correction also removes its stale raw candidate.
    selection["paths"] = [value for value in selection["paths"] if value not in resources]
    if patch.get("layout"):
        selection["layout"] = patch["layout"]
    return selection


def update_input_selection(workflow, resolver, *, prompt=""):
    """Consume new user messages individually and persist auditable file facts.

    No model call, approval, download, or source-history mutation is involved.
    Empty resume prompts reuse the already selected input.
    """
    history = workflow.state["history"]
    selection = deepcopy(workflow.state.get("input_selection") or _new_selection(workflow))
    effective = (workflow.state.get("input_declarations") or {}).get("effective")
    if not workflow.state.get("input_selection") and effective:
        selection = deepcopy(effective.get("selection") or _merge_selection(
            selection, resolver.selection_from_message(effective.get("declaration") or ""), replace=True))
        selection["processed_history_count"] = effective["history_boundary"]
    start = min(selection.get("processed_history_count", 0), len(history))
    messages = [(index, item) for index, item in enumerate(history[start:], start)
                if item.get("role") == "user"]
    last = next((item for item in reversed(history) if item.get("role") == "user"), {})
    if prompt and last.get("content") != prompt:
        messages.append((None, {"content": prompt, "message_id": "prompt:" + object_fingerprint(prompt)}))
    for index, item in messages:
        text = item["content"]
        source_id = item.get("message_id") or item.get("turn_id") or f"history:{index}"
        patch = resolver.selection_from_message(text, preserve_binding=True)
        if patch.get("ignored_candidates"):
            observations = workflow.state.setdefault("path_observations", [])
            observations.append({"source_message_id": source_id, "candidates": patch["ignored_candidates"]})
            workflow.state["path_observations"] = observations[-100:]
        before = _selection_facts(selection)
        replace = bool(re.search(r"(?:修改|更正|纠正|替换)(?:原始)?(?:输入|数据路径)|(?:改为|替换为)", text))
        _merge_selection(selection, patch, replace=replace)
        if _selection_facts(selection) != before:
            selection["revision"] = selection.get("revision", 0) + 1
            selection.setdefault("updates", []).append({"revision": selection["revision"],
                "source_message_id": source_id, "history_index": index,
                "facts": _selection_facts(selection)})
            selection["source_message_ids"] = list(dict.fromkeys(
                [*selection.get("source_message_ids", []), source_id]))
            selection["validation_status"] = "UNVALIDATED"
            selection.pop("sample_count", None)
            selection.pop("resolved_samples", None)
    selection["processed_history_count"] = len(history)
    selection["selection_fingerprint"] = object_fingerprint(_selection_facts(selection))
    workflow.state["input_selection"] = selection
    workflow.save()
    return selection


def _manifest_facts(manifest):
    """Compare resolved identities/bindings, independent of declaration prose."""
    rows = []
    for sample in manifest.get("samples", []):
        row = {key: sample.get(key) for key in ("sample_id", "source_type", "layout", "accession")}
        if row["layout"] is None:
            row["layout"] = {"LOCAL_SINGLE_FASTQ": "single_end", "LOCAL_PAIRED_FASTQ": "paired_end"}.get(row["source_type"])
        for role in ("r1", "r2", "fasta"):
            value = sample.get(role)
            path = value.get("path") if isinstance(value, dict) else value
            row[role] = str(Path(path).resolve()) if path else None
        rows.append(row)
    return sorted(rows, key=lambda row: row.get("sample_id") or "")


def record_selection_validation(selection, resolver, result):
    errors = result.errors or ([] if result.samples else ["请提供原始文件、目录或样本清单。"])
    selection["validation_status"] = "UNRESOLVED" if errors else "VALID"
    selection["validation_errors"] = errors
    selection["sample_count"] = None if errors else len(result.samples)
    selection["resolved_samples"] = [] if errors else _manifest_facts(resolver.to_input_manifest(result))


def import_host_history(workflow, records, *, source):
    """Merge host-attributed events once; historical approvals are never executed.

    Event ids are scoped by the original host session, and reused ids must keep
    exactly the same role and content. The host supplies these records directly,
    not via model-controlled tool arguments.
    """
    from microbiome.conversation_memory import validate_conversation_history

    if not isinstance(source, str) or not source or len(source) > 256:
        raise ConfigurationError("INVALID_HISTORY_SOURCE")
    if not isinstance(records, list):
        raise ConfigurationError("INVALID_HOST_HISTORY")
    known = {}
    for item in workflow.state["history"]:
        event_id = item.get("host_event_id")
        event_source = item.get("host_source") or item.get("source")
        if event_id and event_source == source:
            known[str(event_id)] = (item.get("role"), item.get("content"))
        elif (item.get("role") == "user" and item.get("turn_id")
              and workflow.state.get("host_session_id") == source and not item.get("historical")):
            # Compatibility for earlier worker turns carrying the actual id as
            # turn_id before explicit host_source fields were introduced.
            known[str(item["turn_id"])] = (item.get("role"), item.get("content"))
    additions = []
    for item in records:
        if (not isinstance(item, dict) or set(item) - {"role", "content", "host_event_id"}
                or item.get("role") not in {"user", "assistant"}
                or not isinstance(item.get("content"), str)
                or not isinstance(item.get("host_event_id"), str)
                or not item["host_event_id"] or len(item["host_event_id"]) > 256):
            raise ConfigurationError("INVALID_HOST_HISTORY_EVENT")
        identity = item["host_event_id"]
        fact = (item["role"], item["content"])
        if identity in known:
            if known[identity] != fact:
                raise ConfigurationError("HOST_HISTORY_EVENT_CONFLICT: an existing event id changed content")
            continue
        known[identity] = fact
        additions.append({**item, "host_source": source, "source": source,
                          "historical": True, "turn_id": identity, "message_id": identity, "stage": 1})
    proposed = [*workflow.state["history"], *additions]
    validate_conversation_history(proposed)
    workflow.state["history"] = proposed
    workflow.state["host_session_id"] = source
    workflow.save()
    persist_requirement_draft(workflow)
    persist_goal_contract(workflow)
    return {"imported": len(additions), "reused": len(records) - len(additions)}


_PROCEDURAL_MESSAGE = re.compile(
    r"(?:请|麻烦)?\s*(?:谢谢(?:你)?|感谢(?:你)?|辛苦了|好的?|好|可以|行|没问题|收到|知道了|你好|在吗|"
    r"继续(?:修复方案|规划|修复|执行|处理|完善方案)?|修复方案|重试(?:规划|方案|编译)?|恢复规划|开始|"
    r"确认(?:执行|全量执行|方案|计划|预检|安装|下载)?|同意|批准|取消|停止|暂停|恢复|"
    r"(?:当前|现在)?(?:进度|状态)(?:如何|怎样|怎么样|是什么)?|现在到哪(?:一步)?了?|"
    r"进展(?:如何|怎么样)?|现在(?:怎么样|进度如何)|(?:查看|查询)(?:进度|状态)|"
    r"thanks?(?: you)?|thank you|ok(?:ay)?|continue|retry|proceed|approve|cancel|stop|pause|resume(?: planning)?|"
    r"confirm(?: execution| plan)?|yes|hello|hi|status|progress(?: update)?|how(?: is it going| are you))", re.I)


def derive_goal_contract(state, requirements, *, answering_pending=False):
    """Keep original goal facts separately from conversational control turns.

    Structured scope/outputs become accepted facts only through the existing
    requirements confirmation service. Text is retained as a user statement;
    no model extraction or implicit approval is performed here.
    """
    previous = state.get("goal_contract") or {}
    retained_answers = set(previous.get("clarification_source_ids", []))
    users = [(index, item) for index, item in enumerate(state.get("history", [])) if item.get("role") == "user"]
    selection = state.get("input_selection") or {}
    known_paths = {str(value) for key in ("paths", "resources", "search_roots") for value in selection.get(key, [])}
    if answering_pending and users:
        index, item = users[-1]
        retained_answers.add(str(item.get("host_event_id") or item.get("message_id") or item.get("turn_id") or f"history:{index}"))
    statements, unique_facts = [], []
    for index, item in users:
        identity = str(item.get("host_event_id") or item.get("message_id") or item.get("turn_id") or f"history:{index}")
        content = item["content"]
        normalized = unicodedata.normalize("NFC", content).strip().rstrip("。！？!?，,. ")
        if not normalized or (_PROCEDURAL_MESSAGE.fullmatch(normalized) and identity not in retained_answers):
            continue
        lines = [line.strip() for line in normalized.splitlines() if line.strip()]
        if (identity not in retained_answers and lines and known_paths and all(re.sub(
                r"^(?:(?:修改|更正|纠正|替换)?(?:原始数据|原始输入|输入|数据路径|raw_data|input)\s*[:：]?\s*)",
                "", line, flags=re.IGNORECASE).strip("`\"'") in known_paths for line in lines)):
            continue
        normalized = re.sub(r"\s+", " ", normalized)
        statements.append({"source_message_id": identity, "content": content,
                           "host_source": item.get("host_source") or item.get("source")})
        if normalized not in unique_facts:
            unique_facts.append(normalized)
    confirmed = requirements.get("confirmed_fields", {})
    target = requirements.get("target", {}) if confirmed.get("target") else {}
    goal = requirements.get("analysis_goal", {}) if confirmed.get("analysis_goal") else {}
    accepted_scope = target.get("accepted_scope", target.get("scope")) if isinstance(target, dict) else None
    required_outputs = (goal.get("required_outputs", goal.get("deliverables", goal.get("outputs", [])))
                        if isinstance(goal, dict) else [])
    value = {"schema_version": 1, "authority": "Original user statements plus explicitly confirmed requirement fields; never execution approval",
             "statements": statements, "user_facts": unique_facts, "source_message_ids": [row["source_message_id"] for row in statements],
             "clarification_source_ids": sorted(retained_answers), "accepted_scope": accepted_scope,
             "required_outputs": required_outputs, "confirmed_target": target, "confirmed_analysis_goal": goal}
    value["fingerprint"] = object_fingerprint({"user_facts": unique_facts, "target": target, "analysis_goal": goal})
    return value


def persist_goal_contract(workflow, *, answering_pending=False):
    value = derive_goal_contract(workflow.state, RequirementManager(workflow.project).load(),
                                 answering_pending=answering_pending)
    workflow.state["goal_contract"] = value
    write_json(workflow.project.requirements_dir / "goal_contract.json", value)
    workflow.save()
    return value


def goal_contract_context(workflow):
    """Compact goal identity; original statements already occur in model memory."""
    value = persist_goal_contract(workflow)
    return {key: value[key] for key in ("authority", "fingerprint", "accepted_scope", "required_outputs", "source_message_ids")}


def validate_confirmed_goal_contract(workflow, payload):
    """Protect explicitly structured confirmed fields without interpreting prose.

    RequirementManager.MODIFY clears the topic's confirmation through the
    existing versioned flow; an unconfirmed topic may then be redesigned.
    """
    current = RequirementManager(workflow.project).load()
    proposed = payload.get("requirements", {}) if isinstance(payload, dict) else {}
    differences = []
    for topic, key in (("target", "accepted_scope"), ("analysis_goal", "required_outputs")):
        before_topic = current.get(topic, {})
        if not current["confirmed_fields"].get(topic) or key not in before_topic:
            continue
        after_topic = proposed.get(topic, {}) if isinstance(proposed, dict) else {}
        present = isinstance(after_topic, dict) and key in after_topic
        before = before_topic[key]
        after = after_topic.get(key) if isinstance(after_topic, dict) else None
        missing = None
        if key == "required_outputs" and isinstance(before, list) and isinstance(after, list):
            identities = {object_fingerprint(item) for item in after}
            missing = [item for item in before if object_fingerprint(item) not in identities]
            changed = bool(missing)
        else:
            changed = not present or object_fingerprint(before) != object_fingerprint(after)
        if changed:
            differences.append({"field": f"requirements.{topic}.{key}",
                "code": "CONFIRMED_FIELD_CHANGED" if present else "CONFIRMED_FIELD_MISSING",
                "before": before, "after": after, "after_present": present,
                **({"missing": missing} if missing is not None else {})})
    if differences:
        error = ConfigurationError("CONFIRMED_GOAL_DRIFT: candidate changed explicitly confirmed goal fields")
        error.details = {"code": "CONFIRMED_GOAL_DRIFT", "category": "INTERNAL_PLAN_COMPILATION",
            "recoverable": True, "diff": differences, "violations": differences,
            "next_action": "Restore the confirmed fields; a user-requested revision uses RequirementManager.MODIFY before redesign"}
        raise error
    return payload


def persist_requirement_draft(workflow):
    """Preserve exact user statements with topic hints, without claiming parsing.

    These statements are deliberately not merged into confirmed requirements.
    Topic hints help resume clarification but are not executable parameter facts.
    """
    rows = []
    topics = {
        "input": r"原始|输入|样本清单|FASTQ|FASTA|raw|input|manifest",
        "dataset": r"样本|单端|双端|分组|sample|single.end|paired.end",
        "target": r"对象|目标|target|scope",
        "analysis_goal": r"分析|统计|结果|报告|目标|需求|希望|analysis|report|goal|objective",
    }
    for index, item in enumerate(workflow.state["history"]):
        if item.get("role") != "user":
            continue
        source_id = item.get("message_id") or item.get("turn_id") or f"history:{index}"
        text = item["content"]
        rows.append({"source_message_id": source_id, "history_index": index,
                     "content": text, "timestamp": item.get("timestamp"),
                     "validation_status": "UNVALIDATED", "confirmed_by_user": False,
                     "topic_hints": [key for key, pattern in topics.items() if re.search(pattern, text, re.I)]})
    value = {"schema_version": 1, "status": "UNCONFIRMED",
             "authority": "User statements only; no execution or resource approval.",
             "statements": rows, "input_declaration_revision":
                 workflow.state.get("input_declarations", {}).get("revision", 0)}
    value["draft_fingerprint"] = object_fingerprint(value)
    write_json(workflow.project.requirements_dir / "requirements_draft.json", value)
    return value


def repair_declaration(workflow, declaration=None, *, selection=None, source_message_id, expected_revision=None):
    from microbiome.pipeline.maintenance_contract import validate_maintenance_request

    request = {key: value for key, value in {"declaration": declaration, "selection": selection}.items() if value is not None}
    validate_maintenance_request("repair_input", request)
    if declaration is not None and (not declaration.strip() or len(declaration.encode("utf-8")) > 65536):
        raise ConfigurationError("输入更正必须包含非空声明，且不得超过 64 KiB。")
    declaration = declaration.strip() if declaration is not None else None
    structured_input = deepcopy(selection)
    if not isinstance(source_message_id, str) or not source_message_id.strip() or len(source_message_id) > 256:
        raise ConfigurationError("输入更正需要明确的来源消息标识。")
    ledger = workflow.state.get("input_declarations") or {"revision": 0, "records": [], "effective": None}
    revision = ledger["revision"]
    # Retried management requests are idempotent, including pending changes.
    for old in ledger["records"]:
        if old["source_message_id"] == source_message_id:
            if old.get("declaration") != declaration or old.get("structured_input") != structured_input:
                raise ConfigurationError("同一来源消息不能提交不同的输入更正。")
            persist_requirement_draft(workflow)
            return old
    if expected_revision is not None and (type(expected_revision) is not int or expected_revision != revision):
        raise ConfigurationError(f"输入声明版本已改变：当前为 {revision}，请重新读取后更正。")
    protected = input_is_protected(workflow.project)
    resolver = input_resolver(workflow)
    selection = deepcopy(workflow.state.get("input_selection") or _new_selection(workflow))
    patch = resolver.selection_from_structure(structured_input) if structured_input is not None else resolver.selection_from_message(declaration)
    _merge_selection(selection, patch, replace=True)
    if structured_input is not None:
        selection["layout"] = patch["layout"]
        selection["resources"] = []
        # Typed relative paths always refer to the persisted raw-data binding.
        # A previous natural-language directory selection is not an alias.
        selection["search_roots"] = [str(resolver.raw_data_root)]
    selection["processed_history_count"] = len(workflow.state["history"])
    selection["source_message_ids"] = list(dict.fromkeys([*selection.get("source_message_ids", []), source_message_id]))
    selection["selection_fingerprint"] = object_fingerprint(_selection_facts(selection))
    selection["revision"] = selection.get("revision", 0) + int(
        selection["selection_fingerprint"] != (workflow.state.get("input_selection") or {}).get("selection_fingerprint"))
    validation_errors, resolved = [], None
    if not protected:
        resolved = resolver.resolve_selection(selection, allow_sra_download=workflow.state.get("allow_sra", True))
        validation_errors = resolved.errors or ([] if resolved.samples else ["请提供原始文件、目录或样本清单。"])
        record_selection_validation(selection, resolver, resolved)
    else:
        selection["validation_status"] = "PENDING"
        selection.pop("sample_count", None)
        selection.pop("resolved_samples", None)
    old_manifest_path = workflow.project.requirements_dir / "input_manifest.yaml"
    old_manifest = read_yaml(old_manifest_path) if old_manifest_path.is_file() else None
    equivalent = (not protected and not validation_errors and isinstance(old_manifest, dict)
                  and _manifest_facts(old_manifest) == _manifest_facts(resolver.to_input_manifest(resolved)))
    validation_status = "PENDING" if protected else ("UNRESOLVED" if validation_errors else "VALID")
    before = _manifest_facts(old_manifest) if isinstance(old_manifest, dict) else []
    after = _manifest_facts(resolver.to_input_manifest(resolved)) if resolved is not None else []
    before_by_id, after_by_id = ({row["sample_id"]: row for row in rows} for rows in (before, after))
    sample_change = {"before": before, "after": after,
        "comparison_status": "PENDING" if protected else "INCOMPLETE" if validation_errors else "COMPLETE",
        "added": sorted(set(after_by_id) - set(before_by_id)),
        "removed": sorted(set(before_by_id) - set(after_by_id)) if not protected and not validation_errors else [],
        "changed": sorted(key for key in set(before_by_id) & set(after_by_id) if before_by_id[key] != after_by_id[key])}
    record = {"revision": revision + 1, "status": "PENDING_CHANGE" if protected else "APPLIED",
              "declaration": declaration, "structured_input": structured_input, "source_message_id": source_message_id,
              "validation_status": validation_status, "validation_errors": validation_errors,
              "resume_ready": not protected and not validation_errors,
              "semantic_changed": not equivalent, "input_revision": selection["revision"],
              "selection": selection,
              "sample_change": sample_change,
              "timestamp": datetime.now(UTC).isoformat(),
              "supersedes": (ledger.get("effective") or {}).get("revision"),
              "history_boundary": len(workflow.state["history"]),
              "bound_paths_fingerprint": object_fingerprint(workflow.project.load_config()["paths"])}
    if equivalent:
        record["status"] = "UNCHANGED"
        # Existing authoritative approvals remain untouched. A blocked older
        # declaration is still invalidated; resolution below must finish its
        # current contract rather than silently resurrecting approvals.
        requirements = RequirementManager(workflow.project).load()
        if requirements.get("input", {}).get("validation_status") == "UNVALIDATED":
            record["status"] = "APPLIED"
            equivalent = False
        else:
            workflow.state["input_selection"] = selection
            workflow.state["input_error"] = False
            workflow.state.pop("input_blocker", None)
    if not protected and not equivalent:
        # Copy control-plane facts into an immutable revision receipt before
        # invalidating anything. Original history/files remain at their paths.
        archived = {"record": record, "previous_declaration": ledger.get("effective"),
                    "previous_state": {key: workflow.state[key] for key in (
                        "draft", "input_summary", "input_error", "input_blocker", "approved_draft",
                        "approved_pretest", "compiler_repair", "input_selection") if key in workflow.state}}
        for name in ("input_manifest.yaml", "input_resolution_errors.json"):
            path = workflow.project.requirements_dir / name
            if path.is_file():
                archived[name] = read_yaml(path) if name.endswith(".yaml") else read_json(path)
        manager = RequirementManager(workflow.project)
        archived["requirements"] = manager.load()
        archived["lifecycle"] = ProjectStateMachine(workflow.project).load()
        archive_path = workflow.project.requirements_dir / "input_revisions" / f"{record['revision']:06d}.json"
        # An interrupted write may leave a receipt without the state update.
        # Never replace a conflicting receipt under the same revision.
        if archive_path.is_file():
            existing = read_json(archive_path)
            old = existing.get("record", {})
            stable = ("revision", "status", "declaration", "structured_input", "source_message_id", "supersedes", "bound_paths_fingerprint")
            if any(old.get(key) != record.get(key) for key in stable):
                raise ConfigurationError("发现未完成的输入修复回执，请先检查并恢复该事务。")
            record = dict(old)
            selection = deepcopy(record.get("selection", selection))
        else:
            write_json(archive_path, archived)
        record["previous_facts_path"] = str(archive_path)
        # Invalidate the authoritative requirements, not only the chat draft.
        # Every API entry point checks these confirmations; retaining an old
        # manifest file must never preserve approval to execute that input.
        requirements = manager.decide("input", {
            "declaration": record["declaration"], "declaration_revision": record["revision"],
            "selection": structured_input,
            "validation_status": "UNVALIDATED",
        }, action=ConfirmationAction.MODIFY, decision_source={
            "source_message_id": source_message_id, "operation": "input_declaration_repair"})
        if requirements["confirmed_fields"].get("dataset"):
            requirements = manager.decide("dataset", requirements["dataset"],
                action=ConfirmationAction.MODIFY, decision_source={
                    "source_message_id": source_message_id, "operation": "input_declaration_repair"})
        machine = ProjectStateMachine(workflow.project)
        # Recover a crash between the requirements write and its state update.
        if machine.load().get("requirements_version") != requirements["requirements_version"]:
            machine.invalidate_for_requirements(requirements["requirements_version"],
                                                reason="input declaration repair resumed")
        ledger["effective"] = dict(record)
        workflow.state["input_selection"] = selection
        workflow.state["input_error"] = True
        workflow.state["draft"] = None
        for key in ("input_summary", "input_blocker", "approved_draft", "approved_pretest", "compiler_repair"):
            workflow.state.pop(key, None)
    # Recovered archive records may contain an earlier copy of the selection.
    if not protected:
        ledger["effective"] = dict(record)
    ledger["revision"] = record["revision"]
    ledger["records"].append(record)
    workflow.state["input_declarations"] = ledger
    workflow.save()
    persist_requirement_draft(workflow)
    return record
