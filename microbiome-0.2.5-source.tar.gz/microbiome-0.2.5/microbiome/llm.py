import os
from typing import TYPE_CHECKING, Literal, Optional
from urllib.parse import urlparse

from langchain_core.language_models.chat_models import BaseChatModel

if TYPE_CHECKING:
    from microbiome.config import MicrobiomeConfig

SourceType = Literal["OpenAI", "AzureOpenAI", "Anthropic", "Ollama", "Gemini", "Bedrock", "Groq", "Custom", "DeepSeek"]
ALLOWED_SOURCES: set[str] = set(SourceType.__args__)


def _local_openai_transport(base_url):
    if base_url and urlparse(base_url).hostname in {"localhost", "127.0.0.1", "::1"}:
        import httpx
        return {"http_client": httpx.Client(trust_env=False, timeout=60),
                "http_async_client": httpx.AsyncClient(trust_env=False, timeout=60)}
    return {}


def _local_anthropic_client(asynchronous=False):
    import importlib
    import anthropic
    factory = anthropic.DefaultAsyncHttpxClient if asynchronous else anthropic.DefaultHttpxClient
    # Use the SDK's actual HTTP implementation (httpx or httpx2). Some SDK
    # versions create proxy mounts even with trust_env=False unless a transport
    # is supplied explicitly.
    module_name = next(cls.__module__.split(".")[0] for cls in factory.__mro__
                       if cls.__module__.split(".")[0] in {"httpx", "httpx2"})
    http = importlib.import_module(module_name)
    transport = http.AsyncHTTPTransport if asynchronous else http.HTTPTransport
    return factory(trust_env=False, transport=transport(trust_env=False), timeout=60)


def get_llm(
    model: str | None = None,
    temperature: float | None = None,
    stop_sequences: list[str] | None = None,
    source: SourceType | None = None,
    base_url: str | None = None,
    api_key: str | None = None,
    config: Optional["MicrobiomeConfig"] = None,
    max_tokens: int | None = None,
    context_length: int | None = None,
    prefer_host: bool = True,
) -> BaseChatModel:
    """
    Get a language model instance based on the specified model name and source.
    This function supports models from OpenAI, Azure OpenAI, Anthropic, Ollama, Gemini, Bedrock, and custom model serving.
    Args:
        model (str): The model name to use
        temperature (float): Temperature setting for generation
        stop_sequences (list): Sequences that will stop generation
        source (str): Source provider: "OpenAI", "AzureOpenAI", "Anthropic", "Ollama", "Gemini", "Bedrock", or "Custom"
                      If None, will attempt to auto-detect from model name
        base_url (str): The base URL for custom model serving (e.g., "http://localhost:8000/v1"), default is None
        api_key (str): The API key for the custom llm
        config (MicrobiomeConfig): Optional configuration object. If provided, unspecified parameters will use config values
    """
    from microbiome.harness.model import host_model
    injected = host_model() if prefer_host else None
    if injected is not None:
        return injected
    # Use config values for any unspecified parameters
    if config is not None:
        if model is None:
            model = config.llm
        if temperature is None:
            temperature = config.temperature
        if source is None:
            source = config.source
        if base_url is None:
            base_url = config.base_url
        if api_key is None:
            api_key = config.api_key

    if config is not None:
        max_tokens = max_tokens if max_tokens is not None else config.max_tokens
        context_length = context_length if context_length is not None else config.context_length

    # Never choose a provider or read its credentials for the default host path.
    if model in {None, "current-host-model", "current-harness-model"} or source == "harness":
        raise RuntimeError(
            "HOST_MODEL_NOT_ATTACHED: Use microbiome mcp from your current host, "
            "or microbiome endpoint --endpoint URL --project PROJECT for an existing "
            "model service. Python integrations may attach a model_client or use_host_model()."
        )
    if temperature is None:
        temperature = 0.7
    # Auto-detect source from model name if not specified
    if source is None:
        env_source = os.getenv("LLM_SOURCE")
        if env_source in ALLOWED_SOURCES:
            source = env_source
        else:
            if model[:7] == "claude-":
                source = "Anthropic"
            elif model[:7] == "gpt-oss":
                source = "Ollama"
            elif model[:4] == "gpt-":
                source = "OpenAI"
            elif model.startswith("azure-"):
                source = "AzureOpenAI"
            elif model[:7] == "gemini-":
                source = "Gemini"
            elif "groq" in model.lower():
                source = "Groq"
            elif model.startswith("deepseek-") or "deepseek" in model.lower():
                source = "DeepSeek"
            elif base_url is not None:
                source = "Custom"
            elif "/" in model or any(
                name in model.lower()
                for name in [
                    "llama",
                    "mistral",
                    "qwen",
                    "gemma",
                    "phi",
                    "dolphin",
                    "orca",
                    "vicuna",
                ]
            ):
                source = "Ollama"
            elif model.startswith(
                ("anthropic.claude-", "amazon.titan-", "meta.llama-", "mistral.", "cohere.", "ai21.", "us.")
            ):
                source = "Bedrock"
            else:
                raise ValueError("Unable to determine model source. Please specify 'source' parameter.")

    # Create appropriate model based on source
    if source == "OpenAI":
        try:
            from langchain_openai import ChatOpenAI
        except ImportError:
            raise ImportError(  # noqa: B904
                "langchain-openai package is required for OpenAI models. Install with: pip install langchain-openai"
            )
        # Newer OpenAI models (e.g., gpt-5-*) require the Responses API and may reject
        # legacy Chat Completions parameters like `stop`. Force Responses API when
        # using gpt-5 models to avoid 400 errors such as: "Unsupported parameter: 'stop'".
        use_responses = model.startswith("gpt-5")

        if use_responses:
            # Define a minimal subclass that drops the `stop` field when using the
            # Responses API, since certain models (gpt-5-*) reject it entirely.
            class _ChatOpenAIResponsesNoStop(ChatOpenAI):
                def _get_request_payload(self, input_, *, stop=None, **kwargs):  # type: ignore[override]
                    payload = super()._get_request_payload(input_, stop=stop, **kwargs)
                    try:
                        # If this call will use the Responses API, drop `stop` to avoid 400s.
                        if hasattr(self, "_use_responses_api") and self._use_responses_api(payload):  # type: ignore[attr-defined]
                            payload.pop("stop", None)
                            # Also drop temperature for gpt-5 models as they only support default value
                            payload.pop("temperature", None)
                    except Exception:
                        # Be conservative: if anything goes wrong, still remove `stop` and `temperature`.
                        payload.pop("stop", None)
                        payload.pop("temperature", None)
                    return payload

            return _ChatOpenAIResponsesNoStop(
                model=model,
                temperature=1,  # Set to default value for gpt-5, will be removed in payload
                stop_sequences=stop_sequences,
                use_responses_api=True,
                output_version="v0",
                api_key=api_key,
                base_url=base_url,
                max_tokens=max_tokens,
                **_local_openai_transport(base_url),
            )
        else:
            return ChatOpenAI(
                model=model,
                temperature=temperature,
                stop_sequences=stop_sequences,
                api_key=api_key,
                base_url=base_url,
                max_tokens=max_tokens,
                **_local_openai_transport(base_url),
            )

    elif source == "AzureOpenAI":
        try:
            from langchain_openai import AzureChatOpenAI
        except ImportError:
            raise ImportError(  # noqa: B904
                "langchain-openai package is required for Azure OpenAI models. Install with: pip install langchain-openai"
            )
        API_VERSION = "2024-12-01-preview"
        model = model.replace("azure-", "")
        return AzureChatOpenAI(
            openai_api_key=os.getenv("OPENAI_API_KEY"),
            azure_endpoint=os.getenv("OPENAI_ENDPOINT"),
            azure_deployment=model,
            openai_api_version=API_VERSION,
            temperature=temperature,
        )

    elif source == "Anthropic":
        try:
            from langchain_anthropic import ChatAnthropic
        except ImportError:
            raise ImportError(  # noqa: B904
                "langchain-anthropic package is required for Anthropic models. Install with: pip install langchain-anthropic"
            )

        anthropic_class = ChatAnthropic
        if base_url and urlparse(base_url).hostname in {"localhost", "127.0.0.1", "::1"}:
            from functools import cached_property
            import anthropic

            class LocalChatAnthropic(ChatAnthropic):
                @cached_property
                def _client(self):
                    return anthropic.Anthropic(**self._client_params, http_client=_local_anthropic_client())

                @cached_property
                def _async_client(self):
                    return anthropic.AsyncAnthropic(**self._client_params, http_client=_local_anthropic_client(asynchronous=True))

            anthropic_class = LocalChatAnthropic

        return anthropic_class(
            model=model,
            temperature=temperature,
            max_tokens=max_tokens or 8192,
            stop_sequences=stop_sequences,
            api_key=api_key or os.getenv("ANTHROPIC_API_KEY"),
            base_url=base_url,
        )

    elif source == "Gemini":
        # If you want to use ChatGoogleGenerativeAI, you need to pass the stop sequences upon invoking the model.
        # return ChatGoogleGenerativeAI(
        #     model=model,
        #     temperature=temperature,
        #     google_api_key=api_key,
        # )
        try:
            from langchain_openai import ChatOpenAI
        except ImportError:
            raise ImportError(  # noqa: B904
                "langchain-openai package is required for Gemini models. Install with: pip install langchain-openai"
            )
        return ChatOpenAI(
            model=model,
            temperature=temperature,
            api_key=os.getenv("GEMINI_API_KEY"),
            base_url="https://generativelanguage.googleapis.com/v1beta/openai/",
            stop_sequences=stop_sequences,
        )

    elif source == "Groq":
        try:
            from langchain_openai import ChatOpenAI
        except ImportError:
            raise ImportError(  # noqa: B904
                "langchain-openai package is required for Groq models. Install with: pip install langchain-openai"
            )
        return ChatOpenAI(
            model=model,
            temperature=temperature,
            api_key=os.getenv("GROQ_API_KEY"),
            base_url="https://api.groq.com/openai/v1",
            stop_sequences=stop_sequences,
        )

    elif source == "Ollama":
        try:
            from langchain_ollama import ChatOllama
        except ImportError:
            raise ImportError(  # noqa: B904
                "langchain-ollama package is required for Ollama models. Install with: pip install langchain-ollama"
            )
        # Qwen-family thinking models can spend the whole generation budget in
        # Ollama's separate ``thinking`` field and leave ``message.content`` empty.
        # Microbiome's execution protocol parses message.content, so keep reasoning in
        # the normal answer channel. Users can still ask the model for a concise
        # rationale in the prompt without exposing a hidden reasoning stream.
        ollama_base_url = base_url or os.getenv("OLLAMA_BASE_URL") or "http://127.0.0.1:11434"
        ollama_base_url = ollama_base_url.rstrip("/")
        if ollama_base_url.endswith("/v1"):
            ollama_base_url = ollama_base_url[: -len("/v1")]

        # httpx honors ALL_PROXY by default. Local Ollama traffic must stay on
        # the loopback interface even when the shell has a global proxy.
        ollama_host = urlparse(ollama_base_url).hostname
        client_kwargs = {"timeout": 120.0}
        if ollama_host in {"localhost", "127.0.0.1", "::1"}:
            client_kwargs["trust_env"] = False

        return ChatOllama(
            model=model,
            temperature=temperature,
            reasoning=False,
            base_url=ollama_base_url,
            client_kwargs=client_kwargs,
            stop=stop_sequences,
            **({"num_ctx": context_length} if context_length else {}),
            **({"num_predict": max_tokens} if max_tokens else {}),
        )

    elif source == "Bedrock":
        try:
            from langchain_aws import ChatBedrock
        except ImportError:
            raise ImportError(  # noqa: B904
                "langchain-aws package is required for Bedrock models. Install with: pip install langchain-aws"
            )
        return ChatBedrock(
            model=model,
            temperature=temperature,
            stop_sequences=stop_sequences,
            region_name=os.getenv("AWS_REGION", "us-east-1"),
        )

    elif source == "Custom":
        try:
            from langchain_openai import ChatOpenAI
        except ImportError:
            raise ImportError(  # noqa: B904
                "langchain-openai package is required for custom models. Install with: pip install langchain-openai"
            )
        # Custom LLM serving such as SGLang. Must expose an openai compatible API.
        assert base_url is not None, "base_url must be provided for customly served LLMs"
        llm = ChatOpenAI(
            model=model,
            temperature=temperature,
            max_tokens=max_tokens or 8192,
            stop_sequences=stop_sequences,
            base_url=base_url,
            api_key=api_key or os.getenv("OPENAI_API_KEY") or "EMPTY",
            **_local_openai_transport(base_url),
        )
        return llm

    elif source == "DeepSeek":
        # DeepSeek exposes an OpenAI-compatible API. deepseek-chat (V3) is the
        # recommended model for Microbiome's agentic planning/execution loop (it supports
        # plain-text tool use well); deepseek-reasoner (R1) is also compatible but
        # rejects `temperature`/`stop`, so it is not used here.
        try:
            from langchain_openai import ChatOpenAI
        except ImportError:
            raise ImportError(  # noqa: B904
                "langchain-openai package is required for DeepSeek models. Install with: pip install langchain-openai"
            )
        deepseek_base_url = base_url or os.getenv("DEEPSEEK_BASE_URL") or "https://api.deepseek.com/v1"
        deepseek_api_key = (
            api_key
            or os.getenv("DEEPSEEK_API_KEY")
            or os.getenv("OPENAI_API_KEY")
            or "EMPTY"
        )
        return ChatOpenAI(
            model=model,
            temperature=temperature,
            max_tokens=max_tokens or 8192,
            stop_sequences=stop_sequences,
            base_url=deepseek_base_url,
            api_key=deepseek_api_key,
            **_local_openai_transport(deepseek_base_url),
        )

    else:
        raise ValueError(
            f"Invalid source: {source}. Valid options are 'OpenAI', 'AzureOpenAI', 'Anthropic', 'Gemini', 'Groq', 'Bedrock', 'DeepSeek', 'Ollama', or 'Custom'"
        )
