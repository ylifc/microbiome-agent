"""Download helpers: live speed/progress display, stall detection, resumable retries.

下载增强工具，满足：下载基因组/数据库/数据时必须显示网速与下载进度；
一旦"没有网速"（停滞超时无任何字节到达）自动多次重试，并支持断点续传。

Two entry points:

- ``download_file(url, dest, ...)``
    Direct HTTP(S) download with a tqdm progress bar (percentage + live speed +
    ETA), stall detection via socket read timeout, and resume support: partial
    bytes are kept in ``dest + ".part"`` and the next attempt sends an HTTP
    ``Range: bytes=<have>-`` header to continue exactly where it stopped
    (falls back to a fresh download when the server ignores Range).

- ``run_download_command(command, watch_paths=..., ...)``
    Wrapper for external download commands (``gget ref``/``gget virus``,
    NCBI ``datasets``, ``prefetch``, ``genomad download-database`` ...).
    The command's own output (including its progress) is streamed live, while a
    watchdog polls the byte size of ``watch_paths``: if neither command output
    nor file growth happens for ``stall_timeout`` seconds, the process is
    killed and the command retried (tools like prefetch resume natively;
    others restart that attempt). Non-zero exits are retried only when the
    output looks like a transient upstream error (503/timeout/reset ...).

Tunables (env vars, overridable per call):
    MICROBIOME_DL_STALL_TIMEOUT  – seconds without bytes/progress before an attempt
                               is declared stalled (default 60 for download_file,
                               180 for run_download_command)
    MICROBIOME_DL_MAX_RETRIES    – max attempts (default 5 / 3 respectively)
"""

from __future__ import annotations

import os
import subprocess
import threading
import time
from pathlib import Path

import requests
from tqdm import tqdm

from microbiome import proxy_config
from microbiome.progress import OperationInfo, emit_progress, parse_reported_percent, progress_event

_CONNECT_TIMEOUT = 30
_TRANSIENT_PATTERNS = (
    "503",
    "502",
    "500",
    "429",
    "temporarily",
    "timed out",
    "timeout",
    "connection reset",
    "connection refused",
    "network is unreachable",
    "temporary failure",
)


def _env_float(name, default):
    try:
        return float(os.environ.get(name, "") or default)
    except ValueError:
        return default


def _env_int(name, default):
    try:
        return int(os.environ.get(name, "") or default)
    except ValueError:
        return default


def _head_size(url, session=None):
    """Best-effort remote size via HEAD (0 when unknown/unreachable)."""
    try:
        http = session or proxy_config.session_for(url)
        r = http.head(url, allow_redirects=True, timeout=_CONNECT_TIMEOUT)
        return int(r.headers.get("content-length", 0) or 0)
    except Exception:
        return 0



def download_file(
    url,
    dest,
    *,
    desc=None,
    stall_timeout=None,
    max_retries=None,
    chunk_size=1 << 20,
    min_bytes=1,
    expected_size=None,
    log=print,
    progress_callback=None,
    purpose="把任务所需数据可靠地保存到本地",
    reason="本地目标文件缺失或尚未完整下载",
):
    """Download ``url`` to ``dest`` with progress bar, stall-retry and resume.

    显示实时网速与进度（tqdm：百分比 + MB/s + ETA）；停滞（stall_timeout 秒内
    无任何字节到达）或连接中断时自动重试最多 max_retries 次；已通过 HTTP Range
    头从 ``dest.part`` 的断点处继续下载，不重复消耗流量。

    Returns the destination path on success; raises RuntimeError after all
    retries are exhausted.
    """
    stall_timeout = _env_float("MICROBIOME_DL_STALL_TIMEOUT", 60.0) if stall_timeout is None else float(stall_timeout)
    max_retries = _env_int("MICROBIOME_DL_MAX_RETRIES", 5) if max_retries is None else int(max_retries)
    dest = os.fspath(dest)
    parent = os.path.dirname(os.path.abspath(dest))
    os.makedirs(parent, exist_ok=True)
    partial = dest + ".part"
    # 有代理/无代理都能下：重试时在探测到的首选通道与备选通道（直连↔代理）间轮换。
    plans = proxy_config.transport_plans(url)
    total = int(expected_size or 0) or _head_size(url, proxy_config.session_for(url, transport=plans[0]))
    operation = OperationInfo("download", desc or f"下载 {os.path.basename(dest)}", purpose, reason, os.path.abspath(dest))

    def report(percent, *, status="running", detail=""):
        event = progress_event(percent, operation, status=status, detail=detail)
        if progress_callback is not None:
            emit_progress(progress_callback, event)
        else:
            log(event["content"])

    if os.path.exists(dest):
        have_done = os.path.getsize(dest)
        if (total > 0 and have_done == total) or (total == 0 and have_done >= min_bytes):
            report(100, status="skipped", detail="目标文件已存在且通过大小检查")
            log(f"✅ 已存在且大小匹配，跳过下载: {dest}（{have_done} 字节）")
            return dest

    label = desc or os.path.basename(dest) or url
    last_err = None
    last_structured_percent = -1
    report(0, detail=f"来源：{url}")
    for attempt in range(1, max_retries + 1):
        transport = plans[(attempt - 1) % len(plans)]
        channel = f"代理 {transport[1]['https']}" if transport[0] == "proxy" and transport[1] else "直连"
        have = os.path.getsize(partial) if os.path.exists(partial) else 0
        if total and have >= total:
            break  # previous attempt fetched all bytes but not the rename
        headers = {"Range": f"bytes={have}-"} if have else {}
        mode = "ab" if have else "wb"
        if have:
            log(f"🔁 第 {attempt}/{max_retries} 次尝试：从断点 {have} 字节处续传 {label}（{channel}）")
        elif attempt > 1:
            log(f"🔁 第 {attempt}/{max_retries} 次尝试：重新下载 {label}（{channel}）")
        else:
            log(f"⏬ 下载 {label}（{channel}）\n   {url}")
        try:
            with proxy_config.session_for(url, transport=transport).get(
                url, stream=True, headers=headers, timeout=(_CONNECT_TIMEOUT, stall_timeout)
            ) as r:
                if have and r.status_code == 200:
                    log("   ⚠️ 服务器不支持断点续传（未返回 206），从头重新下载。")
                    have, mode = 0, "wb"
                elif r.status_code not in (200, 206):
                    raise RuntimeError(f"HTTP {r.status_code} {r.reason}")
                content_len = int(r.headers.get("content-length", 0) or 0)
                bar_total = have + content_len if content_len else (total or None)
                with (
                    open(partial, mode) as fh,
                    tqdm(
                        total=bar_total,
                        initial=have,
                        unit="B",
                        unit_scale=True,
                        unit_divisor=1024,
                        desc=f"⏬ {label}"[:60],
                        dynamic_ncols=True,
                        mininterval=0.5,
                    ) as bar,
                ):
                    for chunk in r.iter_content(chunk_size=chunk_size):
                        if chunk:
                            fh.write(chunk)
                            bar.update(len(chunk))
                            if progress_callback is not None and bar_total:
                                percent = int(bar.n * 100 / bar_total)
                                if (percent == 100 or percent % 5 == 0) and percent != last_structured_percent:
                                    report(percent, detail=f"已接收 {bar.n}/{bar_total} 字节")
                                    last_structured_percent = percent
        except (requests.exceptions.RequestException, OSError) as e:
            last_err = e
            kept = os.path.getsize(partial) if os.path.exists(partial) else 0
            log(
                f"   ⚠️ 第 {attempt}/{max_retries} 次下载中断（{type(e).__name__}: {e}）；"
                f"已保留 {kept} 字节，稍后从断点继续。"
            )
            if attempt < max_retries:
                time.sleep(min(2**attempt, 30))
            continue
        got = os.path.getsize(partial)
        if total and got < total:
            last_err = RuntimeError(f"连接提前关闭（{got}/{total} 字节）")
            log(f"   ⚠️ 第 {attempt}/{max_retries} 次下载不完整（{got}/{total} 字节），将断点续传重试。")
            if attempt < max_retries:
                time.sleep(min(2**attempt, 30))
            continue
        if got < min_bytes:
            last_err = RuntimeError(f"下载内容过小（{got} 字节）")
            if attempt < max_retries:
                time.sleep(min(2**attempt, 30))
            continue
        os.replace(partial, dest)
        proxy_config.remember_transport(url, transport)
        report(100, status="completed", detail=f"下载完成并原子写入 {dest}")
        log(f"✅ 下载完成: {dest}（{got} 字节）")
        return dest

    if os.path.exists(partial) and total and os.path.getsize(partial) >= total:
        os.replace(partial, dest)
        report(100, status="completed", detail=f"断点文件已完成并写入 {dest}")
        log(f"✅ 下载完成: {dest}（{os.path.getsize(dest)} 字节）")
        return dest
    raise RuntimeError(
        f"下载失败：重试 {max_retries} 次后仍未完成 {url}\n"
        f"最后错误: {last_err}\n"
        f"提示：已下载部分保留在 {partial}，再次调用会自动从断点续传；"
        f"也可用环境变量 MICROBIOME_DL_MAX_RETRIES / MICROBIOME_DL_STALL_TIMEOUT 调整重试策略。"
    )


def _watched_bytes(watch_paths):
    """Total size in bytes of all files under the given files/dirs (0 if none)."""
    total = 0
    for p in watch_paths:
        try:
            path = Path(p)
            if path.is_file():
                total += path.stat().st_size
            elif path.is_dir():
                for f in path.rglob("*"):
                    if f.is_file():
                        try:
                            total += f.stat().st_size
                        except OSError:
                            pass
        except OSError:
            pass
    return total


def run_download_command(
    command,
    *,
    watch_paths=None,
    stall_timeout=None,
    max_retries=None,
    timeout_seconds=None,
    env=None,
    desc=None,
    stream=True,
    log=print,
    transient_patterns=_TRANSIENT_PATTERNS,
    expected_size=None,
    progress_callback=None,
    purpose="获取任务所需的外部数据资源",
    reason="本地数据尚未满足已确认任务的输入要求",
):
    """Run an external download command with live output, stall watchdog, retries.

    实时转发命令自身输出（含其进度）；看门狗监视 watch_paths 的字节增长与
    命令输出活动，stall_timeout 秒均无进展（没有网速）则终止本次尝试并重试，
    最多 max_retries 次。支持断点续传的工具（如 prefetch）会自动续传。

    Returns a subprocess.CompletedProcess with the combined output in .stdout.
    """
    stall_timeout = _env_float("MICROBIOME_DL_STALL_TIMEOUT", 180.0) if stall_timeout is None else float(stall_timeout)
    max_retries = _env_int("MICROBIOME_DL_MAX_RETRIES", 3) if max_retries is None else int(max_retries)
    # 有代理/无代理都能下：未显式传 env 时按通道探测结果生成 env，重试时轮换。
    envs = [env] if env is not None else proxy_config.download_env_plans()
    watch = list(watch_paths or [])
    cmd_str = command if isinstance(command, str) else " ".join(str(c) for c in command)
    label = desc or cmd_str
    last = None
    target = ", ".join(str(Path(path).expanduser().resolve()) for path in watch) if watch else ""
    operation = OperationInfo("download", label, purpose, reason, target)

    def report(percent, *, status="running", detail=""):
        event = progress_event(percent, operation, status=status, detail=detail)
        if progress_callback is not None:
            emit_progress(progress_callback, event)
        else:
            log(event["content"])

    report(0, detail=f"命令：{cmd_str}")

    for attempt in range(1, max_retries + 1):
        attempt_env = envs[(attempt - 1) % len(envs)]
        if len(envs) > 1:
            channel = "直连" if attempt_env.get("no_proxy") == "*" else f"代理 {attempt_env.get('https_proxy')}"
            log(f"⏬ {label}（第 {attempt}/{max_retries} 次尝试，{channel}）")
        else:
            log(f"⏬ {label}（第 {attempt}/{max_retries} 次尝试）")
        proc = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            errors="replace",
            bufsize=1,
            env=attempt_env,
            shell=isinstance(command, str),
        )
        lines = []
        state = {"activity": time.monotonic()}
        state["percent"] = 0

        def _reader(proc=proc, lines=lines, state=state):
            try:
                for line in proc.stdout:
                    lines.append(line)
                    state["activity"] = time.monotonic()
                    reported = parse_reported_percent(line)
                    if reported is not None and reported > state["percent"]:
                        state["percent"] = reported
                        report(reported, detail=line.strip()[-300:])
                    if stream:
                        print(f"   | {line}", end="")
            except (OSError, ValueError):
                pass

        reader = threading.Thread(target=_reader, daemon=True)
        reader.start()
        started = time.monotonic()
        last_bytes = _watched_bytes(watch)
        killed_stall = False
        killed_timeout = False
        while proc.poll() is None:
            time.sleep(1)
            now = time.monotonic()
            current = _watched_bytes(watch)
            if current > last_bytes:
                last_bytes = current
                state["activity"] = now
                if expected_size:
                    percent = min(99, int(current * 100 / int(expected_size)))
                    if percent > state["percent"]:
                        state["percent"] = percent
                        report(percent, detail=f"目标目录已写入 {current}/{expected_size} 字节")
            if timeout_seconds and now - started > timeout_seconds:
                killed_timeout = True
                proc.kill()
                break
            if now - state["activity"] > stall_timeout:
                killed_stall = True
                proc.kill()
                break
        proc.wait()
        reader.join(timeout=5)
        output = "".join(lines)
        last = subprocess.CompletedProcess(command, proc.returncode, output, "")

        if proc.returncode == 0 and not killed_stall and not killed_timeout:
            report(100, status="completed", detail="下载命令成功退出")
            log(f"✅ 下载命令完成（第 {attempt} 次尝试）: {label}")
            return last
        if killed_timeout:
            report(state["percent"], status="failed", detail=f"超过总时限 {timeout_seconds}s")
            log(f"⏱️ 超过总时限 {timeout_seconds}s，终止下载命令: {label}")
            break
        if killed_stall:
            report(state["percent"], status="retrying", detail=f"{stall_timeout:.0f}s 无输出或文件增长")
            log(
                f"⚠️ {stall_timeout:.0f}s 无网速/无进展，判定下载停滞；"
                f"终止第 {attempt} 次尝试并断点重试（工具支持续传时自动继续）。"
            )
        else:
            lowered = output.lower()
            transient = any(p in lowered for p in transient_patterns)
            log(
                f"⚠️ 下载命令退出码 {proc.returncode}"
                f"{'（瞬态上游错误，将重试）' if transient else '（非瞬态错误，不再重试）'}"
            )
            if not transient:
                break
        if attempt < max_retries:
            time.sleep(min(2**attempt, 20))
    return last
