"""Automatic, isolated software-environment provisioning for confirmed plans."""

from __future__ import annotations

import os
import queue
import re
import shlex
import shutil
import subprocess
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path

from microbiome.conda_discovery import find_conda_manager
from microbiome.progress import (
    OperationInfo,
    ProgressCallback,
    emit_progress,
    parse_reported_percent,
    print_progress,
    progress_event,
)


@dataclass
class EnvironmentProvisionResult:
    """Result of creating or repairing one registered software environment."""

    software_id: str
    environment: str
    success: bool
    status: str
    commands: list[str] = field(default_factory=list)
    output: str = ""
    error: str = ""


class SoftwareEnvironmentRunner:
    """Install missing registered software into its declared Conda environment."""

    _BINDING_RE = re.compile(r"(?im)^\s*-\s*software\s+([a-z0-9][a-z0-9_.-]*):")

    def __init__(
        self,
        registry,
        *,
        project_root: str | Path,
        timeout_seconds: int = 7200,
        progress_callback: ProgressCallback | None = print_progress,
    ):
        self.registry = registry
        self.project_root = Path(project_root).expanduser().resolve()
        self.timeout_seconds = max(1, int(timeout_seconds))
        self.progress_callback = progress_callback

    @classmethod
    def planned_software_ids(cls, confirmed_plan: str) -> list[str]:
        """Return exact software IDs from registry-verified plan bindings."""

        return list(dict.fromkeys(match.lower() for match in cls._BINDING_RE.findall(confirmed_plan or "")))

    _PLAN_ENV_NAME_RE = re.compile(r"(?:-n|--name)\s+['\"]?([a-zA-Z0-9_.-]+)")
    _PLAN_ENV_PATH_RE = re.compile(r"/envs/([a-zA-Z0-9_.-]+)")
    _PLAN_ENV_KWARG_RE = re.compile(r"\benv\s*=\s*['\"]([a-zA-Z0-9_.-]+)['\"]")
    _PREFIX_EXISTS_RE = re.compile(r"already exists|prefix already|CondaValueError", re.IGNORECASE)

    @classmethod
    def plan_environment_software_ids(cls, registry, plan: str) -> list[str]:
        """Software IDs whose declared conda env is referenced by plan commands.

        补充绑定行的盲区：方案正文里直接写出的 `conda run -n <env>`、
        `conda run -p .../envs/<env>` 或 `env='<env>'` 引用也必须在预检时
        确保环境存在，否则执行阶段就会撞上 EnvironmentLocationNotFound。
        """

        if registry is None or not plan:
            return []
        names: list[str] = []
        for line in str(plan).splitlines():
            if re.search(r"\b(?:conda|mamba|micromamba)\s+run\b", line):
                names.extend(cls._PLAN_ENV_NAME_RE.findall(line))
            names.extend(cls._PLAN_ENV_PATH_RE.findall(line))
            names.extend(cls._PLAN_ENV_KWARG_RE.findall(line))
        if not names:
            return []
        by_environment: dict[str, list[str]] = {}
        for skill in registry.list_skills("software"):
            environment = str(skill.metadata.get("environment") or "")
            if environment:
                by_environment.setdefault(environment, []).append(skill.skill_id)
        ordered: list[str] = []
        for name in names:
            for skill_id in by_environment.get(name, []):
                if skill_id not in ordered:
                    ordered.append(skill_id)
        return ordered

    def _candidate_env_dirs(self) -> list[Path]:
        """Roots under which a broken prefix for a named environment may linger."""

        roots: list[Path] = []
        manager = find_conda_manager()
        if manager:
            roots.append(Path(manager).resolve().parent.parent / "envs")
        conda_prefix = os.environ.get("CONDA_PREFIX")
        if conda_prefix:
            roots.append(Path(conda_prefix) / "envs")
        roots.append(Path.home() / ".conda" / "envs")
        unique: list[Path] = []
        for root in roots:
            if root not in unique:
                unique.append(root)
        return unique

    def _broken_prefix(self, environment: str) -> Path | None:
        """Return an on-disk directory claiming this env name without valid conda metadata.

        创建过程被中断（网络失败、超时、手动终止）会留下没有 conda-meta/history 的
        半截目录：conda 既不认为它是环境（EnvironmentLocationNotFound），mamba create
        又会因 "already exists" 拒绝重建。必须先识别并清理。
        """

        if not environment or environment.lower() in {"base", "root"}:
            return None
        catalog = getattr(self.registry, "environment_catalog", None) or {}
        if environment in catalog:
            prefix = Path(catalog[environment])
            return None if (prefix / "conda-meta" / "history").is_file() else prefix
        for root in self._candidate_env_dirs():
            candidate = root / environment
            if candidate.is_symlink():
                continue
            if candidate.is_dir() and not (candidate / "conda-meta" / "history").is_file():
                return candidate
        return None

    @staticmethod
    def _prefix_from_exists_error(output: str, environment: str) -> Path | None:
        """Extract the conflicting prefix from an 'already exists' create error.

        兜底解析：当残留目录不在候选 envs 根（如 .condarc 自定义 envs_dirs）时，
        预清理发现不了它，但 mamba/conda 的报错文本里带有绝对路径，可直接利用。
        仍要求无有效 conda-meta，避免误删健康环境。
        """

        for token in re.findall(r"(/\S+)", output or ""):
            candidate = Path(token.rstrip("'\""))
            if candidate.name != environment or candidate.parent.name != "envs":
                continue
            if candidate.is_dir() and not (candidate / "conda-meta" / "history").is_file():
                return candidate
        return None

    @staticmethod
    def _remove_broken_prefix(prefix: Path, environment: str) -> bool:
        """Remove a confirmed-broken prefix with strict path safety checks."""

        try:
            resolved = prefix.resolve()
        except OSError:
            return False
        if resolved.name != environment or resolved.parent.name != "envs":
            return False
        if prefix.is_symlink() or not resolved.is_dir():
            return False
        shutil.rmtree(resolved, ignore_errors=True)
        return not resolved.exists()

    def _emit(self, event: dict) -> None:
        emit_progress(self.progress_callback, event)

    def _operation(self, software_id: str, environment: str, status: str) -> OperationInfo:
        action = "创建" if status == "missing_environment" else "修复"
        return OperationInfo(
            "environment" if status == "missing_environment" else "software",
            f"{action}软件环境 {environment}（{software_id}）",
            f"确保分析软件 {software_id} 可以在独立环境中执行",
            "预检发现该环境不存在或必需可执行文件缺失；自动修复后会再次验证",
            environment,
        )

    def _repair_commands(self, software_id: str, environment: str) -> list[str]:
        skill = self.registry.get_skill("software", software_id)
        metadata = skill.metadata
        manager = find_conda_manager()
        if not manager:
            raise FileNotFoundError("未找到 conda/mamba/micromamba，无法创建隔离软件环境")
        packages = [str(value) for value in metadata.get("packages") or []]
        channels = [str(value) for value in metadata.get("channels") or ["conda-forge", "bioconda"]]
        command = [manager, "install", "-y", "-n", environment]
        for channel in channels:
            command.extend(["-c", channel])
        command.extend(packages)
        commands = [shlex.join(command)] if packages else []
        pip_packages = [str(value) for value in metadata.get("pip_packages") or []]
        if pip_packages:
            commands.append(
                shlex.join(
                    [
                        manager,
                        "run",
                        "-n",
                        environment,
                        "--no-capture-output",
                        "python",
                        "-m",
                        "pip",
                        "install",
                        *pip_packages,
                    ]
                )
            )
        return commands

    @staticmethod
    def _conda_stage_percent(line: str) -> int | None:
        lowered = line.lower()
        stages = (
            ("collecting package metadata", 15),
            ("solving environment", 30),
            ("package plan", 45),
            ("downloading and extracting", 55),
            ("preparing transaction", 75),
            ("verifying transaction", 85),
            ("executing transaction", 92),
        )
        for marker, percent in stages:
            if marker in lowered:
                return percent
        return parse_reported_percent(line)

    @staticmethod
    def _looks_network_failure(output: str) -> bool:
        """Whether a conda/mamba/pip failure looks transport-related (retry on the other channel)."""
        lowered = (output or "").lower()
        markers = (
            "ssl",
            "tls",
            "timed out",
            "timeout",
            "connection refused",
            "connection reset",
            "connection error",
            "connecterror",
            "name or service not known",
            "temporary failure in name resolution",
            "network is unreachable",
            "proxyerror",
            "proxy error",
            "download error",
            "httperror",
            "http error",
            "repodata",
            "unexpected eof",
            "503",
            "502",
            "429",
        )
        return any(marker in lowered for marker in markers)

    def _subprocess_envs(self, argv: list[str]) -> list[dict]:
        """Ordered subprocess envs for conda/mamba/pip commands (preferred transport first).

        环境创建/修复与数据下载共用同一套直连↔代理自动选择（microbiome.proxy_config）：
        首选通道的 env 在前，备选通道在后，网络类失败时自动切换重试。
        非 conda 系命令返回单个继承环境（维持原行为）。
        """
        base = os.environ.copy()
        try:
            from microbiome.proxy_config import download_env_plans

            name = os.path.basename(str(argv[0])).lower() if argv else ""
            if name in {"conda", "mamba", "micromamba"}:
                url = (
                    "https://pypi.org"
                    if "pip" in {str(part).lower() for part in argv}
                    else "https://conda.anaconda.org"
                )
                plans = download_env_plans(url, base_env=base)
                return plans or [base]
        except Exception:
            pass
        return [base]

    def _run_command(self, command: str, operation: OperationInfo) -> tuple[int, str]:
        argv = shlex.split(command)
        if argv and argv[0] in {"conda", "mamba", "micromamba"}:
            argv[0] = find_conda_manager() or argv[0]
        envs = self._subprocess_envs(argv)
        outputs: list[str] = []
        for index, env in enumerate(envs):
            if index:
                self._emit(
                    progress_event(
                        5,
                        operation,
                        status="retrying",
                        detail="网络通道失败，自动切换直连/代理后重试",
                    )
                )
            returncode, output = self._run_once(argv, env, operation)
            outputs.append(output)
            if returncode == 0 or index + 1 >= len(envs) or not self._looks_network_failure(output):
                return returncode, "".join(outputs)[-20_000:]
        return returncode, "".join(outputs)[-20_000:]

    def _run_once(self, argv: list[str], env: dict, operation: OperationInfo) -> tuple[int, str]:
        process = subprocess.Popen(
            argv,
            cwd=self.project_root,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            errors="replace",
            bufsize=1,
        )
        output: list[str] = []
        messages: queue.Queue[str | None] = queue.Queue()

        def read_output() -> None:
            assert process.stdout is not None
            for line in process.stdout:
                messages.put(line)
            messages.put(None)

        reader = threading.Thread(target=read_output, daemon=True)
        reader.start()
        started = time.monotonic()
        last_percent = 0
        reader_done = False
        while process.poll() is None or not reader_done:
            if time.monotonic() - started > self.timeout_seconds:
                process.kill()
                output.append(f"command timed out after {self.timeout_seconds} seconds\n")
                break
            try:
                line = messages.get(timeout=0.5)
            except queue.Empty:
                continue
            if line is None:
                reader_done = True
                continue
            output.append(line)
            percent = self._conda_stage_percent(line)
            if percent is not None and percent > last_percent:
                last_percent = min(percent, 99)
                self._emit(progress_event(last_percent, operation, detail=line.strip()[-300:]))
        process.wait()
        reader.join(timeout=2)
        while not messages.empty():
            line = messages.get_nowait()
            if line:
                output.append(line)
        return process.returncode, "".join(output)[-20_000:]

    def ensure(self, software_id: str) -> EnvironmentProvisionResult:
        """Create/repair one environment and verify all declared executables."""

        status = self.registry.software_status(software_id)
        environment = str(status.environment or "")
        if environment.lower() in {"base", "root", ""}:
            return EnvironmentProvisionResult(
                software_id,
                environment,
                False,
                "blocked",
                error="软件 skill 必须声明非 base/root 的独立环境",
            )
        if status.status == "ready":
            operation = self._operation(software_id, environment, status.status)
            self._emit(progress_event(100, operation, status="skipped", detail="环境已经 READY，无需重复安装"))
            return EnvironmentProvisionResult(software_id, environment, True, "ready")

        operation = self._operation(software_id, environment, status.status)
        self._emit(progress_event(0, operation, detail="开始解析并安装已确认的软件依赖"))
        try:
            if status.status == "missing_environment":
                broken = self._broken_prefix(environment)
                if broken is not None:
                    self._emit(
                        progress_event(
                            5,
                            operation,
                            status="repairing",
                            detail=f"检测到上次安装中断留下的无效环境目录，自动清理后重建：{broken}",
                        )
                    )
                    self._remove_broken_prefix(broken, environment)
                commands = self.registry.environment_create_command(software_id).split(" && ")
            else:
                commands = self._repair_commands(software_id, environment)
        except Exception as error:
            self._emit(progress_event(0, operation, status="failed", detail=str(error)))
            return EnvironmentProvisionResult(
                software_id,
                environment,
                False,
                "failed",
                error=f"{type(error).__name__}: {error}",
            )

        outputs = []
        for command in commands:
            returncode, output = self._run_command(command, operation)
            outputs.append(output)
            if returncode != 0 and self._PREFIX_EXISTS_RE.search(output):
                broken = self._broken_prefix(environment) or self._prefix_from_exists_error(output, environment)
                if broken is not None and self._remove_broken_prefix(broken, environment):
                    self._emit(
                        progress_event(
                            10,
                            operation,
                            status="retrying",
                            detail=f"残留目录 {broken} 导致创建被拒绝，已清理并自动重建一次",
                        )
                    )
                    returncode, output = self._run_command(command, operation)
                    outputs.append(output)
            if returncode != 0:
                detail = f"命令退出码 {returncode}: {output[-1000:]}"
                self._emit(progress_event(100, operation, status="failed", detail=detail))
                return EnvironmentProvisionResult(
                    software_id,
                    environment,
                    False,
                    "failed",
                    commands,
                    "\n".join(outputs),
                    detail,
                )

        self.registry.reload()
        verified = self.registry.software_status(software_id)
        success = verified.status == "ready"
        detail = (
            "环境和全部声明的可执行文件已验证可用"
            if success
            else f"安装完成但仍缺少：{', '.join(verified.missing) or verified.status}"
        )
        self._emit(progress_event(100, operation, status="completed" if success else "failed", detail=detail))
        return EnvironmentProvisionResult(
            software_id,
            environment,
            success,
            verified.status,
            commands,
            "\n".join(outputs),
            "" if success else detail,
        )
