"""Durable single-machine jobs independent of the MCP/chat process.

This is not a remote scheduler. A host change reconnects to the same project
on the same Linux machine. Crashes are reported, never automatically replayed.
"""
from __future__ import annotations

import hashlib
import os
import re
import signal
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path

from microbiome.pipeline.errors import ConfigurationError
from microbiome.pipeline.io import object_fingerprint, read_json, write_json

_CHILDREN: dict[str, subprocess.Popen] = {}
TERMINAL = {"completed", "failed", "cancelled", "interrupted"}


class JobCancelled(BaseException):
    """Cancellation must cross scientific code's OSError/Exception handlers."""


PARAMETERS = {
    "bootstrap": set(), "resolve_databases": set(),
    "pretest": {"fraction", "resume_validation_id", "repair_validation_id"},
    "finalize": {"new_version"},
    "production": {"run_id", "threads", "memory_gb", "gpus", "resume"},
}


def _now():
    return datetime.now(UTC).isoformat()


def _process(pid: int) -> str | None:
    """Linux PID start time prevents signalling a recycled PID."""
    try:
        parts = Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()
        return None if parts[0] == "Z" else parts[19]
    except (FileNotFoundError, ProcessLookupError, IndexError):
        return None


def _directory(project, job_id):
    if not re.fullmatch(r"[a-f0-9]{32}", job_id):
        raise ConfigurationError("Invalid job_id")
    return project.state_dir / "portable" / "jobs" / job_id


def _request(operation: str, parameters: dict) -> None:
    if operation not in PARAMETERS or not isinstance(parameters, dict) or parameters.keys() - PARAMETERS[operation]:
        raise ConfigurationError("Unsupported job operation or parameters")
    if operation == "pretest" and "fraction" in parameters:
        from microbiome.pipeline.cases import validate_pretest_fraction
        validate_pretest_fraction(parameters["fraction"])
    reuse_keys = {"resume_validation_id", "repair_validation_id"} & parameters.keys()
    if reuse_keys:
        from microbiome.pipeline.continuation import validate_validation_id
        if len(reuse_keys) != 1 or "fraction" in parameters:
            raise ConfigurationError("choose exactly one derived continuation/repair mode and omit fraction")
        validate_validation_id(parameters[next(iter(reuse_keys))])
    for name in ("new_version", "resume"):
        if name in parameters and type(parameters[name]) is not bool:
            raise ConfigurationError(f"{name} must be a boolean")


def _gate(project, operation):
    from microbiome.integrations.service import confirmed_manifest
    from microbiome.pipeline.state import LifecycleState, ProjectStateMachine
    from microbiome.pipeline.dependencies import require_bootstrap_approval
    from microbiome.pipeline.lifecycle import load_plan
    confirmed_manifest(project)
    if operation in {"bootstrap", "resolve_databases", "pretest"}:
        allowed = {"bootstrap": (LifecycleState.BOOTSTRAP,),
                   "resolve_databases": (LifecycleState.BOOTSTRAP, LifecycleState.PRETEST_PREPARATION),
                   "pretest": (LifecycleState.PRETEST_PREPARATION, LifecycleState.PRETEST_REPAIR)}[operation]
        require_bootstrap_approval(project, load_plan(project), allowed_states=allowed)
    elif operation == "production":
        from microbiome.pipeline.approval import ProductionApprovalManager
        ProductionApprovalManager(project).require_valid_approval()
    else:
        ProjectStateMachine(project).require(LifecycleState.PRETEST_PASSED, LifecycleState.VALIDATED,
                                             LifecycleState.PRETEST_FINALIZATION_FAILED)


def start_job(project: str, operation: str, request_id: str, parameters: dict | None = None) -> dict:
    from microbiome.integrations.service import execution_binding, project_at, project_lock
    if not sys.platform.startswith("linux"):
        raise ConfigurationError("Portable job execution currently requires Linux or WSL2")
    if not isinstance(request_id, str) or not 1 <= len(request_id) <= 200:
        raise ConfigurationError("A stable request_id of 1–200 characters is required")
    parameters = {} if parameters is None else parameters
    _request(operation, parameters)
    instance = project_at(project)
    request = {"project": str(instance.root), "operation": operation, "parameters": parameters, "request_id": request_id}
    job_id = hashlib.sha256((str(instance.root) + "\0" + request_id).encode()).hexdigest()[:32]
    directory = _directory(instance, job_id)
    request_hash = object_fingerprint(request)
    if (directory / "request.json").is_file():
        if read_json(directory / "request.json")["request_fingerprint"] != request_hash:
            raise ConfigurationError("request_id already identifies a different operation")
        return {**job_status(project, job_id), "reused": True}
    with project_lock(instance):
        # Submission and the worker share the existing project operation lock.
        # This closes the gap between process creation and worker lock acquisition.
        for path in (instance.state_dir / "portable" / "jobs").glob("*/status.json"):
            if job_status(project, path.parent.name)["status"] not in TERMINAL:
                raise ConfigurationError("PROJECT_BUSY: another portable job is queued/running")
        _gate(instance, operation)
        if operation == "pretest":
            from microbiome.integrations.service import confirmed_manifest
            kind = confirmed_manifest(instance).get("input_kind")
            if kind == "completed_run_artifacts" and "fraction" in parameters:
                raise ConfigurationError("complete_derived_samples rejects fraction")
            if kind == "external_cohort_tables" and any(key in parameters for key in (
                    "fraction", "resume_validation_id", "repair_validation_id")):
                raise ConfigurationError("complete_external_cohort rejects fraction and validation reuse")
        request.update(request_fingerprint=request_hash, binding=execution_binding(instance), job_id=job_id)
        directory.mkdir(parents=True, exist_ok=False)
        write_json(directory / "request.json", request)
        write_json(directory / "status.json", {"job_id": job_id, "operation": operation, "status": "queued", "created_at": _now()})
        try:
            # A detached local worker survives MCP shutdown. No model credentials are required.
            with (directory / "worker.log").open("ab") as output:
                child = subprocess.Popen([sys.executable, "-m", "microbiome.integrations.jobs", str(directory / "request.json")],
                                         cwd=Path(__file__).resolve().parents[2], stdin=subprocess.DEVNULL,
                                         stdout=output, stderr=output, start_new_session=True)
            _CHILDREN[job_id] = child
            write_json(directory / "process.json", {"pid": child.pid, "start_time": _process(child.pid)})
        except Exception as error:
            write_json(directory / "status.json", {"job_id": job_id, "operation": operation, "status": "failed", "error": str(error)})
            raise
    return {"job_id": job_id, "status": "queued", "project": str(instance.root), "reused": False}


def job_status(project: str, job_id: str) -> dict:
    from microbiome.integrations.service import project_at
    directory = _directory(project_at(project), job_id)
    state = read_json(directory / "status.json")
    if job_id in _CHILDREN and _CHILDREN[job_id].poll() is not None:
        _CHILDREN.pop(job_id)
    if state["status"] not in TERMINAL and (directory / "process.json").is_file():
        process = read_json(directory / "process.json")
        if not process["start_time"] or _process(process["pid"]) != process["start_time"]:
            # Re-read to avoid overwriting a terminal result published just before exit.
            state = read_json(directory / "status.json")
            if state["status"] not in TERMINAL:
                state.update(status="interrupted", error="Worker exited; inspect state before an explicit retry", finished_at=_now())
                write_json(directory / "status.json", state)
    return {**state, "result_path": str(directory / "result.json"), "log_path": str(directory / "worker.log")}


def cancel_job(project: str, job_id: str) -> dict:
    from microbiome.integrations.service import project_at
    directory = _directory(project_at(project), job_id)
    state = job_status(project, job_id)
    if state["status"] in TERMINAL:
        return state
    process = read_json(directory / "process.json")
    if not process["start_time"] or _process(process["pid"]) != process["start_time"]:
        raise ConfigurationError("Worker identity changed; refusing to signal another process")
    write_json(directory / "cancel.json", {"requested_at": _now()})
    os.killpg(process["pid"], signal.SIGTERM)
    return {"job_id": job_id, "status": "cancelling", "note": "Query job.status for the durable terminal outcome"}


def _dead_worker_evidence(process: dict) -> dict:
    """Fail closed if a detached worker or any child in its session still runs.

    Workers are created with start_new_session=True. Checking the session as
    well as the process group catches children that create another group; a
    zombie cannot write outputs and is treated as dead. Never signal anything.
    """
    pid, started = process.get("pid"), process.get("start_time")
    if type(pid) is not int or pid <= 1 or not isinstance(started, str) or not started.isdigit():
        raise ConfigurationError("Recovery requires a valid recorded worker identity")
    if _process(pid) is not None:
        raise ConfigurationError("PROJECT_BUSY: recorded worker PID is still alive or has been recycled")
    for stat in Path("/proc").glob("[0-9]*/stat"):
        try:
            fields = stat.read_text().rsplit(")", 1)[1].split()
            alive = fields[0] not in {"Z", "X"}
            owned = int(fields[2]) == pid or int(fields[3]) == pid
        except (FileNotFoundError, ProcessLookupError):
            continue
        except (OSError, IndexError, ValueError) as error:
            raise ConfigurationError(f"Cannot verify worker session is dead: {stat}") from error
        if alive and owned:
            raise ConfigurationError("PROJECT_BUSY: a child in the recorded worker group/session is still alive")
    return {"pid": pid, "start_time": started, "worker_alive": False,
            "live_group_or_session_members": [], "checked_at": _now()}


def recover_job(project: str, job_id: str) -> dict:
    """Recover only the lifecycle of an abandoned complete-derived pretest.

    This neither launches work nor validates/reuses any scientific checkpoint.
    The subsequent explicit resume still runs its normal continuation audit.
    """
    from microbiome.integrations.service import confirmed_manifest, execution_binding, project_at, project_lock
    from microbiome.pipeline.dependencies import require_bootstrap_approval
    from microbiome.pipeline.derived import KIND, MODE, validate_derived_plan
    from microbiome.pipeline.lifecycle import load_plan
    from microbiome.pipeline.state import LifecycleState, ProjectStateMachine

    if not sys.platform.startswith("linux"):
        raise ConfigurationError("Portable job recovery currently requires Linux or WSL2")
    instance = project_at(project)
    directory = _directory(instance, job_id)
    with project_lock(instance):
        request = read_json(directory / "request.json")
        state = read_json(directory / "status.json")
        if (request.get("project") != str(instance.root) or request.get("job_id") != job_id
                or request.get("operation") != "pretest" or state.get("operation") != "pretest"
                or state.get("job_id") != job_id):
            raise ConfigurationError("Recovery requires the original matching pretest job")
        if state.get("status") not in {"failed", "cancelled", "interrupted"}:
            raise ConfigurationError("Recovery requires a terminal failed/cancelled/interrupted job")
        material = {key: request[key] for key in ("project", "operation", "parameters", "request_id")}
        if request.get("request_fingerprint") != object_fingerprint(material):
            raise ConfigurationError("Recovery request fingerprint is invalid")
        expected_id = hashlib.sha256((str(instance.root) + "\0" + request["request_id"]).encode()).hexdigest()[:32]
        if expected_id != job_id:
            raise ConfigurationError("Recovery job ID differs from the original request")
        _request("pretest", request["parameters"])
        if execution_binding(instance) != request.get("binding"):
            raise ConfigurationError("STALE_JOB: project contracts changed after submission")
        evidence = _dead_worker_evidence(read_json(directory / "process.json"))
        # A terminal label alone does not prove all scientific children exited.
        for other in (instance.state_dir / "portable" / "jobs").glob("*/status.json"):
            if other.parent == directory:
                continue
            status = read_json(other)
            if status.get("status") not in TERMINAL:
                raise ConfigurationError("PROJECT_BUSY: another portable job is queued/running")
            if (other.parent / "process.json").is_file():
                _dead_worker_evidence(read_json(other.parent / "process.json"))
        machine = ProjectStateMachine(instance)
        before = machine.load()
        receipt_path = directory / "recovery.json"
        reason = f"Public job.recover: terminal pretest {job_id}; explicit checkpoint-audited resume required"
        receipt = read_json(receipt_path) if receipt_path.is_file() else None
        if receipt is None:
            machine.require(LifecycleState.PRETEST_RUNNING)
        else:
            if (receipt.get("schema_version") != 1 or receipt.get("status") not in {"PREPARED", "RECOVERED"}
                    or receipt.get("source_status") != state["status"]
                    or receipt.get("receipt_fingerprint") != object_fingerprint(
                    {k: v for k, v in receipt.items() if k != "receipt_fingerprint"})
                    or receipt.get("source_request_fingerprint") != request["request_fingerprint"]
                    or receipt.get("execution_binding") != request["binding"]
                    or receipt.get("job_id") != job_id or receipt.get("project") != str(instance.root)):
                raise ConfigurationError("Recovery receipt is invalid or belongs to changed contracts")
            machine.require(LifecycleState.PRETEST_RUNNING, LifecycleState.PRETEST_REPAIR)
            if machine.current == LifecycleState.PRETEST_REPAIR:
                last = before["history"][-1]
                if (last.get("from") != LifecycleState.PRETEST_RUNNING.value
                        or last.get("to") != LifecycleState.PRETEST_REPAIR.value or last.get("reason") != reason):
                    raise ConfigurationError("Current repair state is not attributable to this recovery")
                if receipt["status"] == "RECOVERED" and receipt.get("state_after") != before["state_fingerprint"]:
                    raise ConfigurationError("Lifecycle changed after the recorded recovery")
            elif receipt.get("status") != "PREPARED" or receipt.get("state_before") != before["state_fingerprint"]:
                raise ConfigurationError("Recovery receipt cannot recover a later lifecycle episode")
        manifest = confirmed_manifest(instance)
        if manifest.get("input_kind") != KIND or manifest.get("pilot_mode") != MODE or "fraction" in request["parameters"]:
            raise ConfigurationError("job.recover currently requires a complete-derived pretest without fraction")
        plan = load_plan(instance)
        validate_derived_plan(plan, manifest)
        require_bootstrap_approval(instance, plan, allowed_states=(machine.current,))
        if receipt is None:
            receipt = {"schema_version": 1, "status": "PREPARED", "project": str(instance.root),
                       "job_id": job_id, "source_status": state["status"],
                       "source_request_fingerprint": request["request_fingerprint"],
                       "execution_binding": request["binding"], "process_evidence": evidence,
                       "manifest_fingerprint": manifest["manifest_fingerprint"],
                       "plan_fingerprint": plan["plan_fingerprint"], "state_before": before["state_fingerprint"],
                       "created_at": _now(), "scientific_completion_asserted": False,
                       "checkpoint_reuse_authorized": False, "worker_started": False}
            receipt["receipt_fingerprint"] = object_fingerprint(receipt)
            write_json(receipt_path, receipt)
        after = machine.transition(LifecycleState.PRETEST_REPAIR, reason=reason)
        reused = receipt["status"] == "RECOVERED"
        if not reused:
            receipt.update(status="RECOVERED", state_after=after["state_fingerprint"], recovered_at=_now())
            receipt["receipt_fingerprint"] = object_fingerprint(
                {k: v for k, v in receipt.items() if k != "receipt_fingerprint"})
            write_json(receipt_path, receipt)
        return {"job_id": job_id, "status": "RECOVERED", "lifecycle": after["current_state"],
                "receipt_path": str(receipt_path), "receipt_fingerprint": receipt["receipt_fingerprint"],
                "reused": reused, "worker_started": False, "checkpoint_reuse_authorized": False}


def _execute(project, operation, parameters):
    if operation == "bootstrap":
        from microbiome.pipeline.lifecycle import bootstrap_toolchain
        return bootstrap_toolchain(project)
    if operation == "resolve_databases":
        from microbiome.pipeline.lifecycle import resolve_databases
        return resolve_databases(project)
    if operation == "pretest":
        from microbiome.pipeline.cases import validate_manifest_cases
        from microbiome.integrations.service import confirmed_manifest
        return validate_manifest_cases(project, confirmed_manifest(project), all_samples=True, **parameters)
    if operation == "finalize":
        from microbiome.pipeline.finalizer import ValidationFinalizer
        return ValidationFinalizer(project).finalize_pretest(**parameters)
    from microbiome.pipeline.execution import FrozenPipelineExecutor
    from microbiome.pipeline.inputs import ProductionInputResolver
    from microbiome.pipeline.batch import execute_batch
    from microbiome.pipeline.io import read_yaml
    pipeline = read_yaml(project.pipeline_lock_path)
    return execute_batch(project, FrozenPipelineExecutor(project), pipeline,
                         ProductionInputResolver(project, pipeline), **parameters)


def main(argv=None):
    import time
    from microbiome.integrations.service import execution_binding, project_at, project_lock
    request_path = Path((argv or sys.argv[1:])[0]).resolve()
    request = read_json(request_path)
    instance = project_at(request["project"])
    directory = _directory(instance, request["job_id"])
    if request_path != directory / "request.json":
        raise ConfigurationError("Job request is outside its managed directory")
    state = read_json(directory / "status.json")

    def cancelled(*_):
        raise JobCancelled("Cancellation requested")

    signal.signal(signal.SIGTERM, cancelled)
    try:
        # Parent publishes the PID identity before releasing the project lock.
        for _ in range(100):
            if (directory / "process.json").is_file():
                break
            time.sleep(0.01)
        with project_lock(instance, blocking=True):
            if (directory / "cancel.json").is_file():
                raise JobCancelled("Cancellation requested")
            if execution_binding(instance) != request["binding"]:
                raise ConfigurationError("STALE_JOB: project contracts changed after submission")
            _request(request["operation"], request["parameters"])
            _gate(instance, request["operation"])
            instance.export_paths()
            state.update(status="running", started_at=_now())
            write_json(directory / "status.json", state)
            result = _execute(instance, request["operation"], request["parameters"])
            write_json(directory / "result.json", result)
            failed = isinstance(result, dict) and (result.get("status") in {"FAILED", "ERROR", "BLOCKED"} or result.get("ready") is False)
            state.update(status="failed" if failed else "completed", finished_at=_now())
    except JobCancelled as error:
        state.update(status="cancelled", error=str(error), finished_at=_now())
    except Exception as error:
        state.update(status="failed", error=str(error), error_code=type(error).__name__, finished_at=_now())
    write_json(directory / "status.json", state)
    return 0 if state["status"] == "completed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
