"""The canonical host Skill assets; no model, installer or scientific imports."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil


SKILL_ROOT = Path(__file__).parent / "templates" / "skills"


def skill_files(root: Path | None = None) -> dict[str, Path]:
    """List complete installable Skills, excluding interpreter caches only."""
    root = SKILL_ROOT if root is None else Path(root)
    files = {}
    for skill in sorted(root.iterdir()):
        if skill.is_symlink():
            raise ValueError(f"Host Skill symlinks are not exportable: {skill.name}")
        if not skill.is_dir() or not (skill / "SKILL.md").is_file():
            continue
        for path in sorted(skill.rglob("*")):
            relative = path.relative_to(root)
            if "__pycache__" in relative.parts or path.suffix in {".pyc", ".pyo"}:
                continue
            if path.is_symlink():
                raise ValueError(f"Host Skill symlinks are not exportable: {relative}")
            if path.is_file():
                files[relative.as_posix()] = path
    if not files:
        raise ValueError("No bundled host Skills were found")
    return files


def export_skills(output: Path) -> dict:
    """Copy every formal Skill and verify its exported bytes."""
    inventory = {}
    for name, source in skill_files().items():
        before = hashlib.sha256(source.read_bytes()).hexdigest()
        target = output / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        if hashlib.sha256(target.read_bytes()).hexdigest() != before:
            raise ValueError(f"Host Skill changed during export: {name}")
        inventory[name] = before
    return {
        "skills": sorted({name.split("/", 1)[0] for name in inventory}),
        "skill_files": inventory,
        "skill_fingerprint": hashlib.sha256(json.dumps(inventory, sort_keys=True, separators=(",", ":")).encode()).hexdigest(),
    }
