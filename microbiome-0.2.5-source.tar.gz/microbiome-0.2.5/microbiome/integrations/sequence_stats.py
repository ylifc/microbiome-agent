"""Bounded, standard-library-only local nucleotide file inspection.

This utility neither creates pipeline state nor grants scientific execution approval.
"""
from __future__ import annotations

from collections import Counter
from contextlib import ExitStack
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import platform
import stat
import sys
import uuid


MAX_DECOMPRESSED_BYTES = 256 * 1024 * 1024
MAX_RECORDS = 2_000_000
ALPHABET = frozenset("ACGTURYSWKMBDHVN")


class SequenceStatsError(ValueError):
    """Invalid local input, output conflict, or utility limit; never a passed check."""


def _now():
    return datetime.now(timezone.utc).isoformat()


def _write_json(path, value):
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, indent=2, ensure_ascii=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())


def _identity(info):
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


class _HashReader(io.RawIOBase):
    def __init__(self, handle):
        super().__init__()
        self.handle = handle
        self.digest = hashlib.sha256()

    def readable(self):
        return True

    def readinto(self, buffer):
        size = self.handle.readinto(buffer)
        if size:
            self.digest.update(memoryview(buffer)[:size])
        return size


class _Input:
    def __init__(self, path, stack, budget):
        self.path = path
        self.raw = stack.enter_context(path.open("rb"))
        self.before = os.fstat(self.raw.fileno())
        if not stat.S_ISREG(self.before.st_mode):
            raise SequenceStatsError(f"Input must be a regular local file: {path}")
        self.hashed = _HashReader(self.raw)
        buffered = stack.enter_context(io.BufferedReader(self.hashed))
        self.compression = "gzip" if buffered.peek(2)[:2] == b"\x1f\x8b" else "none"
        if path.name.lower().endswith(".gz") and self.compression != "gzip":
            raise SequenceStatsError(f"Invalid gzip header: {path}")
        binary = stack.enter_context(gzip.GzipFile(fileobj=buffered)) if self.compression == "gzip" else buffered
        self.text = stack.enter_context(io.TextIOWrapper(binary, encoding="ascii", errors="strict", newline=""))
        self.budget = budget
        self.line = 0
        self.format = None
        self.counts = Counter()
        self.records = self.bases = 0
        self.minimum = self.maximum = None
        self.quality_min = self.quality_max = None

    def readline(self):
        remaining = MAX_DECOMPRESSED_BYTES - self.budget["bytes"]
        value = self.text.readline(remaining + 1)
        self.budget["bytes"] += len(value)
        if self.budget["bytes"] > MAX_DECOMPRESSED_BYTES:
            raise SequenceStatsError("Quick statistics limit exceeded: 256 MiB of decompressed input. "
                                     "Use a separately reviewed larger-file workflow; no successful statistics were produced")
        self.line += bool(value)
        return value

    def fail(self, message):
        raise SequenceStatsError(f"{self.path.name}, line {self.line}: {message}")

    def sequence(self, value, counts):
        value = value.rstrip("\r\n").upper()
        if not value or any(letter not in ALPHABET for letter in value):
            self.fail("Expected nonempty ungapped IUPAC nucleotide sequence (ACGTU and ambiguity codes)")
        counts.update(value)
        return len(value)

    def record(self, header, length, counts):
        if not header.strip() or length == 0:
            self.fail("Empty sequence identifier or sequence")
        self.budget["records"] += 1
        if self.budget["records"] > MAX_RECORDS:
            self.fail("Quick statistics limit exceeded: 2,000,000 total records; use a larger-file workflow")
        self.records += 1
        self.bases += length
        self.minimum = length if self.minimum is None else min(self.minimum, length)
        self.maximum = length if self.maximum is None else max(self.maximum, length)
        self.counts.update(counts)
        return header

    def iterate(self):
        value = self.readline()
        if not value:
            self.fail("Empty input file")
        if value.startswith(">"):
            self.format = "fasta"
            header, length, counts = value[1:].rstrip("\r\n"), 0, Counter()
            while True:
                value = self.readline()
                if not value or value.startswith(">"):
                    yield self.record(header, length, counts)
                    if not value:
                        return
                    header, length, counts = value[1:].rstrip("\r\n"), 0, Counter()
                elif value.strip():
                    length += self.sequence(value, counts)
        elif value.startswith("@"):
            self.format = "fastq"
            while value:
                if not value.startswith("@"):
                    self.fail("FASTQ record must begin with @")
                header, length, counts = value[1:].rstrip("\r\n"), 0, Counter()
                if not header.strip():
                    self.fail("Empty FASTQ identifier")
                value = self.readline()
                while value and not value.startswith("+"):
                    length += self.sequence(value, counts)
                    value = self.readline()
                if not value or not length:
                    self.fail("FASTQ sequence or + separator is missing")
                repeated = value[1:].strip()
                if repeated and repeated.split()[0] != header.split()[0]:
                    self.fail("FASTQ + separator identifier differs from its @ identifier")
                quality_length = 0
                while quality_length < length:
                    value = self.readline()
                    quality = value.rstrip("\r\n")
                    if not quality:
                        self.fail("FASTQ quality is truncated or empty")
                    low, high = ord(min(quality)), ord(max(quality))
                    if low < 33 or high > 126:
                        self.fail("FASTQ quality characters must be ASCII 33 through 126")
                    quality_length += len(quality)
                    self.quality_min = low if self.quality_min is None else min(self.quality_min, low)
                    self.quality_max = high if self.quality_max is None else max(self.quality_max, high)
                if quality_length != length:
                    self.fail("FASTQ sequence and quality lengths differ")
                yield self.record(header, length, counts)
                value = self.readline()
        else:
            self.fail("Expected FASTA > or FASTQ @ as the first character")

    def snapshot(self):
        if _identity(os.fstat(self.raw.fileno())) != _identity(self.before) or _identity(self.path.stat()) != _identity(self.before):
            raise SequenceStatsError(f"Input changed during inspection: {self.path}")
        canonical = sum(self.counts[base] for base in "ACGTU")
        gc = self.counts["G"] + self.counts["C"]
        return {"path": str(self.path), "bytes": self.before.st_size, "mtime_ns": self.before.st_mtime_ns,
                "sha256": self.hashed.digest.hexdigest(), "format": self.format, "compression": self.compression,
                "records": self.records, "total_bases": self.bases, "min_length": self.minimum,
                "max_length": self.maximum, "mean_length": self.bases / self.records,
                "base_counts": dict(sorted(self.counts.items())), "canonical_bases": canonical,
                "ambiguous_bases": self.bases - canonical, "gc_bases": gc,
                "gc_percent": (100 * gc / canonical) if canonical else None,
                "quality_ascii_min": self.quality_min, "quality_ascii_max": self.quality_max}


def _mate(header, expected):
    fields = header.split()
    name = fields[0]
    mate = None
    if name.endswith(("/1", "/2")):
        name, mate = name[:-2], int(name[-1])
    if not name:
        raise SequenceStatsError("Empty paired read identifier")
    if len(fields) > 1 and fields[1].startswith(("1:", "2:")):
        casava = int(fields[1][0])
        if mate is not None and mate != casava:
            raise SequenceStatsError("Conflicting /1 or /2 and CASAVA mate labels")
        mate = casava
    if mate is not None and mate != expected:
        raise SequenceStatsError(f"Mate label indicates read {mate}, expected read {expected}")
    return name


def sequence_stats(inputs: list[str], output: str, paired: bool = False) -> dict:
    """Inspect explicit small local files and create a fresh result directory."""
    if not isinstance(inputs, list) or not 1 <= len(inputs) <= 2 or any(not isinstance(value, str) for value in inputs):
        raise SequenceStatsError("inputs must contain one or two explicit absolute local file paths")
    if not isinstance(paired, bool) or (paired and len(inputs) != 2):
        raise SequenceStatsError("paired must be boolean; paired=true requires exactly two FASTQ files in R1,R2 order")
    paths = []
    for value in inputs:
        path = Path(value).expanduser()
        if not path.is_absolute():
            raise SequenceStatsError("Input paths must be absolute local paths; remote identifiers are unsupported")
        path = path.resolve(strict=True)
        if not path.is_file():
            raise SequenceStatsError(f"Input must be a regular local file: {path}")
        paths.append(path)
    if len(paths) == 2 and os.path.samefile(*paths):
        raise SequenceStatsError("The same file cannot be supplied twice, including symlinks or hard links")
    if not isinstance(output, str) or not Path(output).expanduser().is_absolute():
        raise SequenceStatsError("output must be an absolute path to a new, separate directory")
    target = Path(output).expanduser()
    if any(part.is_symlink() for part in (target, *target.parents)):
        raise SequenceStatsError("Output directory and its parents must not be symlinks")
    target = target.resolve()
    if any(target == path.parent or target.is_relative_to(path.parent) for path in paths):
        raise SequenceStatsError("Output must be outside each input file's directory to avoid mixing results with raw inputs")
    # No recursive parent creation or overwrite: the user chooses an existing results parent.
    target.mkdir(mode=0o700, exist_ok=False)
    execution = {"schema_version": 1, "operation": "sequence.stats", "run_id": uuid.uuid4().hex,
                 "status": "RUNNING", "started_at": _now(), "inputs": [str(path) for path in paths],
                 "output_directory": str(target), "paired": paired,
                 "implementation": {"module": "microbiome.integrations.sequence_stats", "source_path": str(Path(__file__).resolve()),
                                    "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                                    "python_executable": sys.executable, "python_version": platform.python_version(),
                                    "algorithm_version": 1, "dependencies": "Python standard library"},
                 "limits": {"decompressed_bytes": MAX_DECOMPRESSED_BYTES, "total_records": MAX_RECORDS}}
    log_path = target / "execution.log.jsonl"
    with log_path.open("x", encoding="utf-8") as log:
        def event(kind, **details):
            log.write(json.dumps({"timestamp": _now(), "event": kind, **details}, ensure_ascii=False) + "\n")
            log.flush()
        event("started", operation="sequence.stats", run_id=execution["run_id"])
        try:
            budget = {"bytes": 0, "records": 0}
            with ExitStack() as stack:
                readers = [_Input(path, stack, budget) for path in paths]
                if paired:
                    from itertools import zip_longest
                    pairs = 0
                    for left, right in zip_longest(readers[0].iterate(), readers[1].iterate()):
                        if left is None or right is None:
                            raise SequenceStatsError("Paired FASTQ files have different record counts")
                        if any(reader.format != "fastq" for reader in readers):
                            raise SequenceStatsError("Paired inspection requires two FASTQ files")
                        if _mate(left, 1) != _mate(right, 2):
                            raise SequenceStatsError(f"Paired read identifiers differ at record {pairs + 1}")
                        pairs += 1
                else:
                    for reader in readers:
                        for _ in reader.iterate():
                            pass
                snapshots = [reader.snapshot() for reader in readers]
            result = {"schema_version": 1, "operation": "sequence.stats", "status": "COMPLETED",
                      "inputs": snapshots, "pairing": {"matched_pairs": pairs, "order_verified": True} if paired else None,
                      "gc_denominator": "A+C+G+T+U; IUPAC ambiguity codes excluded; null when denominator is zero",
                      "quality_policy": "ASCII 33..126 and sequence/quality length verified; Phred offset is not inferred",
                      "decompressed_bytes_read": budget["bytes"], "total_records": budget["records"]}
            result_path = target / "stats.json"
            _write_json(result_path, result)
            execution.update(status="COMPLETED", finished_at=_now(), input_fingerprints=[
                {key: entry[key] for key in ("path", "bytes", "mtime_ns", "sha256")} for entry in snapshots],
                result={"path": str(result_path), "sha256": hashlib.sha256(result_path.read_bytes()).hexdigest()})
            event("completed", total_records=budget["records"], result_sha256=execution["result"]["sha256"])
            execution["log"] = {"path": str(log_path), "sha256": hashlib.sha256(log_path.read_bytes()).hexdigest()}
            _write_json(target / "execution.json", execution)
            return {"statistics": result, "execution": str(target / "execution.json"), "log": str(log_path),
                    "result": str(result_path), "run_id": execution["run_id"]}
        except Exception as error:
            execution.update(status="FAILED", finished_at=_now(), error={"type": type(error).__name__, "message": str(error)})
            event("failed", error=execution["error"])
            execution["log"] = {"path": str(log_path), "sha256": hashlib.sha256(log_path.read_bytes()).hexdigest()}
            _write_json(target / "execution.json", execution)
            raise SequenceStatsError(f"{error}. Failed execution record: {target / 'execution.json'}") from error


def main(argv=None):
    """Direct stdlib-only module entry, also useful before optional host dependencies."""
    import argparse
    parser = argparse.ArgumentParser(prog="microbiome stats", description=__doc__,
        epilog="Limits: 256 MiB total decompressed data and 2,000,000 total records, including both mates.")
    parser.add_argument("inputs", nargs="+", help="One or two absolute local nucleotide FASTA/FASTQ paths; gzip is supported")
    parser.add_argument("--output", required=True, help="New directory outside raw input directories; parent must exist")
    parser.add_argument("--paired", action="store_true", help="Verify paired FASTQ identifiers in R1,R2 order")
    args = parser.parse_args(argv)
    try:
        response = {"schema_version": 1, "ok": True, "result": sequence_stats(args.inputs, args.output, args.paired)}
    except Exception as error:
        response = {"schema_version": 1, "ok": False, "error": {"code": type(error).__name__, "message": str(error)}}
    print(json.dumps(response, ensure_ascii=False, indent=2))
    return 0 if response["ok"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
