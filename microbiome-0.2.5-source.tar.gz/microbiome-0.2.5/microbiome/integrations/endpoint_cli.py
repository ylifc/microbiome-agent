"""Explicitly reuse an existing OpenAI-compatible service; never discover credentials."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from microbiome.integrations.endpoint import EndpointError, discover_endpoint, make_chat_model


def _project(path: str | None):
    from microbiome.pipeline.project import PipelineProject

    if path:
        project = PipelineProject(Path(path).expanduser().resolve())
        project.load_config()
    else:
        if not sys.stdin.isatty():
            raise EndpointError("PROJECT_REQUIRED", "Supply --project for noninteractive use. Initialize paths with "
                                "microbiome-service init --project ... --raw-data ... --database ... --output ...")
        from microbiome.path_config import prompt_paths
        paths = prompt_paths()
        destination = Path(paths.results_dir)
        if (destination / "project_config.yaml").is_file():
            project = PipelineProject(destination)
        else:
            project = PipelineProject.initialize(destination, raw_data_path=paths.raw_data_dir,
                database_path=paths.db_root, output_path=paths.results_dir,
                download_path=paths.download_dir, knowledge_path=paths.software_memory_dir)
    project.export_paths()
    return project


def _conversation(route, project, prompt):
    # Only the explicit endpoint branch loads the existing conversation implementation.
    from microbiome.harness.model import use_host_model

    model = make_chat_model(route)
    with use_host_model(model):
        from microbiome.agent.a1 import A1
        from microbiome.agent.workflow import ConversationWorkflow

        agent = A1(path=str(project.state_dir / "endpoint_agent"), llm=route.model, source="Custom",
                   base_url=route.endpoint, model_client=model, use_tool_retriever=False,
                   enable_datalake_download=False, auto_install=True, require_frozen_production=True)
        # Bind the requested project explicitly, including when results live elsewhere.
        workflow = ConversationWorkflow(project)
        workflow.registry = agent.resource_skill_registry
        workflow.auto_install = True

        def run(text):
            for event in workflow.handle(agent, text):
                content = event.get("content") or event.get("output")
                if content:
                    print(f"\n[{event.get('type', 'message')}]\n{content}", flush=True)

        if prompt:
            run(prompt)
        if not sys.stdin.isatty():
            if not prompt:
                raise EndpointError("PROMPT_REQUIRED", "Supply --prompt for noninteractive use")
            return
        print("Connected. Discuss the plan first; existing explicit confirmation and frozen-production gates apply. "
              "Type exit or Ctrl-D to close this conversation.", flush=True)
        while True:
            try:
                value = input("microbiome> ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if value.lower() in {"exit", "quit"}:
                break
            if value:
                run(value)


def main(argv=None):
    parser = argparse.ArgumentParser(prog="microbiome endpoint", description=__doc__)
    parser.add_argument("--endpoint", required=True, help="Explicit API base URL, e.g. http://127.0.0.1:8000[/v1]")
    parser.add_argument("--check", action="store_true", help="Only discover and verify a chat model; no agent or project initialization")
    parser.add_argument("--project", help="Existing project; otherwise interactive path setup")
    parser.add_argument("--prompt", help="One conversation turn; interactive terminals stay open afterwards")
    args = parser.parse_args(argv)
    try:
        route = discover_endpoint(args.endpoint)
        print(json.dumps({"ok": True, "route": route.as_dict()}, ensure_ascii=False), flush=True)
        if args.check:
            return 0
        project = _project(args.project)
        _conversation(route, project, args.prompt)
    except EndpointError as error:
        print(json.dumps({"ok": False, "error": {"code": error.code, "message": str(error)}}, ensure_ascii=False), file=sys.stderr)
        return 2
    except Exception as error:
        print(json.dumps({"ok": False, "error": {"code": type(error).__name__, "message": str(error)}}, ensure_ascii=False), file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
