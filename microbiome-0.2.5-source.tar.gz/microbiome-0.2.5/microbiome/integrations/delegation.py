"""Explicit, project-scoped host delegation; no simulated terminal approvals.

The conversation host reports the user's request. This is auditable provenance,
not independent authentication of that user. Scientific gates remain unchanged.
"""
from __future__ import annotations

from datetime import UTC, datetime
import uuid

from microbiome.pipeline.errors import ConfigurationError
from microbiome.pipeline.io import object_fingerprint, read_json, write_json


def _now():
    return datetime.now(UTC).isoformat()


def _directory(project):
    return project.state_dir / "portable" / "delegation"


def _text(value, field):
    if not isinstance(value, str) or not value.strip():
        raise ConfigurationError(f"{field} must be a nonempty string")
    return value.strip()


def load_authorization(project):
    path = _directory(project) / "mode.json"
    if not path.exists():
        return {"schema_version": 1, "mode": "interactive", "project": str(project.root),
                "topics": [], "authorization_fingerprint": None}
    value = read_json(path)
    fingerprint = object_fingerprint({k: v for k, v in value.items() if k != "authorization_fingerprint"})
    if value.get("authorization_fingerprint") != fingerprint:
        raise ConfigurationError("Delegation authorization fingerprint is invalid")
    if value.get("project") != str(project.root):
        raise ConfigurationError("Delegation authorization belongs to another project")
    if (value.get("mode") == "host_delegated"
            and value.get("paths_fingerprint") != object_fingerprint(project.load_config()["paths"])):
        raise ConfigurationError("Project paths changed; configure delegation again for the current paths")
    if value.get("mode") not in {"interactive", "host_delegated"}:
        raise ConfigurationError("Invalid approval mode")
    return value


def inspect_authorization(project: str):
    from microbiome.integrations.service import project_at
    return load_authorization(project_at(project))


def configure_authorization(project: str, mode: str, user_request: str, source: str,
                            scope: str, topics: list[str]):
    from microbiome.integrations.service import TOPICS, project_at, project_lock
    if mode not in {"interactive", "host_delegated"}:
        raise ConfigurationError("mode must be interactive or host_delegated")
    user_request = _text(user_request, "user_request")
    source = _text(source, "source")
    scope = _text(scope, "scope")
    if (not isinstance(topics, list) or any(not isinstance(topic, str) for topic in topics)
            or len(set(topics)) != len(topics) or set(topics) - set(TOPICS)):
        raise ConfigurationError("topics must be a unique list of supported decision topics")
    if mode == "host_delegated" and not topics:
        raise ConfigurationError("host_delegated requires explicit topic scope")
    if mode == "interactive" and topics:
        raise ConfigurationError("interactive mode must use an empty topic list")
    instance = project_at(project)
    with project_lock(instance):
        value = {"schema_version": 1, "mode": mode, "project": str(instance.root),
                 "authorization_id": uuid.uuid4().hex, "created_at": _now(),
                 "paths_fingerprint": object_fingerprint(instance.load_config()["paths"]),
                 "user_request": user_request, "source": source, "scope": scope, "topics": topics,
                 "attestation": "host-reported user request; not an independent human-authentication proof"}
        value["authorization_fingerprint"] = object_fingerprint(value)
        directory = _directory(instance)
        # Preserve every grant/revocation as well as the current mode.
        write_json(directory / "authorizations" / f"{value['authorization_id']}.json", value)
        write_json(directory / "mode.json", value)
        return value


def record_decision(project: str, topic: str, action: str, expected: str,
                    authorization_fingerprint: str, reason: str):
    from microbiome.integrations.service import (
        _apply_reviewed_decision, decision_snapshot, project_at, project_lock,
    )
    from microbiome.pipeline.requirements import ConfirmationAction
    reason = _text(reason, "reason")
    decision = ConfirmationAction(action)
    instance = project_at(project)
    with project_lock(instance):
        authorization = load_authorization(instance)
        if authorization["mode"] != "host_delegated":
            raise ConfigurationError("Host delegation is not enabled for this project; use the operator terminal")
        if authorization["authorization_fingerprint"] != authorization_fingerprint:
            raise ConfigurationError("Stale or mismatched delegation authorization")
        if topic not in authorization["topics"]:
            raise ConfigurationError("Decision topic is outside the delegated scope")
        snapshot = decision_snapshot(project, topic)
        if snapshot["decision_fingerprint"] != expected:
            raise ConfigurationError("STALE_DECISION: review the changed artifact before deciding")
        record_id = uuid.uuid4().hex
        source = {
            "type": "host_delegation", "actor": "host_agent", "record_id": record_id,
            "authorization_fingerprint": authorization_fingerprint,
            "authorization_id": authorization["authorization_id"],
            "user_request": authorization["user_request"], "host_source": authorization["source"],
            "scope": authorization["scope"], "decision_fingerprint": expected, "reason": reason,
        }
        receipt = {"schema_version": 1, "record_id": record_id, "project": str(instance.root),
                   "topic": topic, "action": action, "created_at": _now(), "source": source,
                   "reviewed_material": snapshot, "status": "attempted"}
        path = _directory(instance) / "decisions" / f"{record_id}.json"
        write_json(path, receipt)
        try:
            result = _apply_reviewed_decision(instance, snapshot, decision, decision_source=source)
        except Exception as error:
            receipt.update(status="failed", finished_at=_now(), error=str(error))
            write_json(path, receipt)
            raise
        receipt.update(status="applied", finished_at=_now(), result_fingerprint=object_fingerprint(result))
        write_json(path, receipt)
        return {"decision": result, "source": source, "receipt_path": str(path)}
