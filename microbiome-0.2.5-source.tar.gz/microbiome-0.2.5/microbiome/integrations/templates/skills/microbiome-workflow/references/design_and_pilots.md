# Analysis design and proportionate pilots

Use this guidance when designing a substantial analysis, not for a simple file statistic, an already agreed routine rerun, or a minor cosmetic edit.

## Design brief to discuss

Write the brief in the user's language. Connect each method to the scientific question it answers. A useful compact table has: question; input and independent biological unit; selected method and alternative; key assumptions/exclusions; output figure/table; cost basis; acceptance criterion. Explain consequential choices such as low-coverage inclusion, compositional analysis, multiple testing, confounding, biological replication, phylogenetic rooting, support measures and missing-data sensitivity when relevant. Do not introduce analyses just to populate a template.

Keep three categories separate: supplied facts; choices already agreed; unresolved choices requiring discussion. A user's approval to improve workflow software is not retrospective approval of new sample exclusions, statistical methods or tree parameters. Reuse existing valid authorization for execution details. Record a truthful source for decisions, without inventing user confirmation. The brief supplements rather than replaces the engine's full decision review and fingerprints.

Give the user a concrete design to assess, including a small figure mockup if presentation is consequential. A mockup with invented data must visibly say synthetic. A real-data preview must state its run and validation status. After an agreed design's representative pilot, summarize what worked, what failed, measured cost and any changes needing discussion; do not ask again about unchanged choices.

## Four different kinds of execution

| Kind | Purpose | Data and interpretation | Evidence |
| --- | --- | --- | --- |
| Native behavior probe | Prove a fragile command does what the plan says | Tiny synthetic input can exercise duplicate identities, missing sites, fixed topology and label semantics; no biological conclusion | Actual executable/version, argv, seed, hashes, logs, expected invariant and measured result |
| Representative diagnostic pilot | Estimate feasibility, tune resources and preview layout | Explicitly selected real inputs with their own manifest; retain relevant sample groups and hard cases; no substitution into an existing validation | Selection rationale, source IDs/hashes, limits, outputs, performance and visual checks |
| Engine scientific pretest | Meet the installed engine's scientific validation contract | Use the confirmed manifest and supported input-specific mode, including complete-derived data when required | Public job result, logs, identity/count/quality checks, actual native outputs and image acceptance |
| Frozen production | Produce formal results under the validated contract | Replay the approved immutable plan; any reuse/promotion must be explicitly supported and fingerprint-verified | Formal run and independent final result/figure audit |

Diagnostic success cannot mark an engine pretest passed. Do not lower bootstrap/support settings and call the diagnostic tree a final tree. FASTQ subsampling, taxon selection and alignment-column selection change different things; name the operation and its limitations. A small input's optimal thread count need not be optimal on the full input. Use a bounded workload of relevant size or the native tool's documented autotuning when appropriate, within the approved resource scope.

## Resource evidence

Inventory physical cores, logical threads, accessible affinity/cgroup quota, RAM and relevant storage. Compare only equivalent workloads: same input contents, software/model/scientific options, database and seed policy, with isolated outputs. Distinguish single-task latency from multi-task throughput. Record repeats and uncertainty rather than declaring an optimum from one noisy run. Measure enough to identify CPU, memory, disk or sequential bottlenecks; further monitoring should answer a concrete question.

Choose parallel independent work according to DAG dependencies, tool scaling and memory/I/O pressure. Do not split a coupled inference into arbitrary jobs or force GPU use merely because hardware exists. Prepare benchmarks during planning/repair; do not install, tune or mutate a running frozen task.

## Acceptance and repair

Define output-level invariants before expensive steps: exact sample/leaf IDs; meaningful output counts; topology identity where required; support names/order and branch mapping; missing/no-information values; plot data mapping and readable output. Exit zero, help text, synthetic tests and large check counts are insufficient on their own.

On failure, retain evidence and inspect actual logs, job/process status and checkpoints. Reuse only success whose inputs, command semantics, tools/databases, outputs and dependency closure remain valid. If the public API lacks safe scoped reuse, report that limitation and improve/test the engine separately; never edit locks, checkpoints or state to bypass the gate. Do not describe a proposed artifact-promotion feature as available until implemented, tested and activated.
