#!/usr/bin/env python3
"""Isolated behavioral checks. Set MICROBIOME_RSCRIPT and WGCNA_TEST_OUTPUT.
No WGCNA installation; real powers/fit tests are explicitly out of scope when absent.
"""
import csv
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

SCRIPT = Path(__file__).with_name('wgcna_analysis.R')
R = os.environ.get('MICROBIOME_RSCRIPT') or shutil.which('Rscript')
OUTPUT = Path(os.environ.get('WGCNA_TEST_OUTPUT', tempfile.mkdtemp(prefix='wgcna_checks_')))
OUTPUT.mkdir(parents=True, exist_ok=True)

@unittest.skipUnless(R, 'Rscript absent; set MICROBIOME_RSCRIPT')
class PreflightTests(unittest.TestCase):
    def setUp(self):
        self.root = OUTPUT / self._testMethodName
        self.root.mkdir(exist_ok=True)
        self.matrix = self.root / 'matrix.tsv'
        self.meta = self.root / 'metadata.tsv'
        self.rows = [['sample_id'] + [f'gene_{j:03}' for j in range(1, 41)] + ['constant','missing','sparse']]
        for i in range(12):
            self.rows.append([f'S{i+1:02}'] + [round(10+2*math.sin(i+j*.31)+.1*i*j,5) for j in range(40)] + [0, 'NA' if i==0 else i+1, 1 if i==0 else 0])
        self.meta_rows = [['sample_id','cage_id','group','weight']] + [[f'S{i+1:02}',f'CAGE_{i+1:02}', 'CLMH'[i//3],20+i*.5] for i in reversed(range(12))]
        self.save()
    def save(self):
        for p,rows in [(self.matrix,self.rows),(self.meta,self.meta_rows)]:
            with p.open('w',newline='') as f: csv.writer(f,delimiter='\t').writerows(rows)
    def run_cli(self, extra=(), mode='preflight', name='out'):
        cmd=[R,'--vanilla',str(SCRIPT),'--mode',mode,'--matrix',str(self.matrix),'--metadata',str(self.meta),'--out',str(self.root/name),'--assay','dna','--unit','TPM','--transform','log2p1','--preprocessing-note','SYNTHETIC fixture: gene-blind filter and explicit TPM unit','--independent-unit','cage_id','--dataset-kind','synthetic',*extra]
        p=subprocess.run(cmd,text=True,capture_output=True)
        (self.root/f'{name}_run.json').write_text(json.dumps({'argv':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr},indent=2))
        return p
    def fail_has(self, text, extra=(),mode='preflight'):
        p=self.run_cli(extra,mode); self.assertNotEqual(p.returncode,0,p.stdout); self.assertIn(text,p.stderr)
    def test_descriptive_12_samples(self):
        p=self.run_cli(); self.assertEqual(p.returncode,0,p.stderr)
        out=self.root/'out'
        info=(out/'preflight.tsv').read_text()
        self.assertIn('DESCRIPTIVE_ONLY_LOW_N',info); self.assertIn('independent_samples\t12',info)
        self.assertIn('genes_retained\t40',info); self.assertIn('DNA_gene_coabundance_not_expression',info)
        self.assertIn('retained_full_single_dense_GiB',info); self.assertIn('block_single_dense_GiB',info)
        self.assertFalse((out/'network.rds').exists())
        for ext in ('pdf','svg','png'): self.assertGreater((out/f'sample_qc.{ext}').stat().st_size,100)
        with (out/'metadata_joined.tsv').open() as f: joined=list(csv.DictReader(f,delimiter='\t'))
        self.assertEqual([r['sample_id'] for r in joined],[r[0] for r in self.rows[1:]])
        with (out/'traits.tsv').open() as f: traits=list(csv.DictReader(f,delimiter='\t'))
        self.assertEqual({k for k in traits[0] if k!='sample_id'}, {'group=C','group=L','group=M','group=H'})
        self.assertEqual(sum(float(traits[0][k]) for k in traits[0] if k!='sample_id'),1)
        with (out/'feature_filter.tsv').open() as f: filt={r['gene_id']:r for r in csv.DictReader(f,delimiter='\t')}
        for g in ('constant','missing','sparse'): self.assertEqual(filt[g]['retained'],'FALSE')
    def test_numeric_style_ids_preserved(self):
        for i,r in enumerate(self.rows[1:]): r[0]=f"{i+1:03}"
        for r in self.meta_rows[1:]:
            r[0]=f"{int(r[0][1:]):03}"; r[1]=f"{int(r[1].split('_')[1]):04}"
        self.save(); p=self.run_cli(); self.assertEqual(p.returncode,0,p.stderr)
        with (self.root/'out'/'metadata_joined.tsv').open() as f: joined=list(csv.DictReader(f,delimiter="\t"))
        self.assertEqual(joined[0]["sample_id"],"001"); self.assertEqual(joined[0]["cage_id"],"0001")
    def test_whitespace_ids_rejected(self):
        self.rows[1][0]=" S01"; self.save(); self.fail_has("Matrix sample_id")
    def test_no_duplicate_samples(self):
        self.rows[2][0]=self.rows[1][0]; self.save(); self.fail_has('Matrix sample_id')
    def test_no_duplicate_gene_ids(self):
        self.rows[0][2]=self.rows[0][1]; self.save(); self.fail_has('Matrix column IDs')
    def test_no_pseudoreplication(self):
        self.meta_rows[2][1]=self.meta_rows[1][1]; self.save(); self.fail_has('Independent units')
    def test_exact_identity_join(self):
        self.meta_rows[1][0]='WRONG'; self.save(); self.fail_has('Exact sample identity join failed')
    def test_no_negative_abundance(self):
        self.rows[1][1]=-1; self.save(); self.fail_has('Abundances cannot be negative')
    def test_no_text_coercion(self):
        self.rows[1][1]='oops'; self.save(); self.fail_has('must be numeric')
    def test_no_infinity(self):
        self.rows[1][1]='Inf'; self.save(); self.fail_has('Infinite matrix value')
    def test_no_empty_group(self):
        self.meta_rows[1][2]=''; self.save(); self.fail_has('Group values must be present')
    def test_no_unknown_option(self): self.fail_has('Unknown options', ['--differential-filter','true'])
    def test_no_repeated_option(self): self.fail_has('Duplicate option', ['--mode','fit'])
    def test_low_n_powers_blocked(self):
        self.fail_has('n<15: powers/fit blocked',mode='powers')
        self.assertIn('BLOCKED_LOW_SAMPLE_SIZE',(self.root/'out'/'completion.tsv').read_text())
    def test_override_requires_rationale(self): self.fail_has('requires --exploratory-reason',['--exploratory-low-n','true'])
    def test_override_remains_exploratory(self):
        p=self.run_cli(['--exploratory-low-n','true','--exploratory-reason','Technical sensitivity only; n=12 not reliable.']); self.assertEqual(p.returncode,0,p.stderr)
        self.assertIn('EXPLORATORY_LOW_N_UNVALIDATED',(self.root/'out'/'preflight.tsv').read_text())
    def test_missing_wgcna_reported_honestly(self):
        probe=subprocess.run([R,'--vanilla','-e','cat(requireNamespace("WGCNA",quietly=TRUE))'],capture_output=True,text=True)
        if probe.stdout.strip()=='TRUE': self.skipTest('WGCNA present: missing-dependency branch not applicable')
        self.fail_has('WGCNA is not installed',['--exploratory-low-n','true','--exploratory-reason','Technical sensitivity only.'],mode='powers')
        self.assertIn('BLOCKED_MISSING_WGCNA',(self.root/'out'/'completion.tsv').read_text())
        self.assertFalse((self.root/'out'/'power_diagnostics.rds').exists())
    def test_no_overwrite(self):
        (self.root/'out').mkdir(exist_ok=True); self.fail_has('no overwrite')
    def test_trait_category_not_continuous(self): self.fail_has('categorical group cannot be encoded',['--continuous-traits','group'])
    def test_continuous_trait_exact_join(self):
        p=self.run_cli(['--continuous-traits','weight']); self.assertEqual(p.returncode,0,p.stderr)
        with (self.root/'out'/'traits.tsv').open() as f: t=list(csv.DictReader(f,delimiter='\t'))
        self.assertEqual(float(t[0]['weight']),20)
    def test_raw_counts_rejected(self):
        cmd=[R,'--vanilla',str(SCRIPT),'--mode','preflight','--assay','dna','--unit','counts']
        p=subprocess.run(cmd,capture_output=True,text=True); self.assertNotEqual(p.returncode,0); self.assertIn('unit must be',p.stderr)
    def test_parse(self):
        p=subprocess.run([R,'--vanilla','-e',f'invisible(parse({json.dumps(str(SCRIPT))})); cat("PARSE_OK")'],capture_output=True,text=True)
        self.assertEqual(p.returncode,0,p.stderr); self.assertIn('PARSE_OK',p.stdout)

if __name__=='__main__': unittest.main(verbosity=2)
