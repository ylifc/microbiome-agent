#!/usr/bin/env python3
"""Audit-preserving gene quantity aggregation; stdlib only, no annotation inference."""
import argparse
import collections
import csv
import hashlib
import json
import math
import pathlib
import platform
import sys
from datetime import datetime, timezone

VERSION = "1.0.0"
UNANNOTATED = "__UNANNOTATED__"
MISSING = {"", "NA"}
UNITS = ("DNA_TPM", "RNA_TPM", "read_count", "estimated_count", "coverage")


def read_table(path, required):
    with open(path, newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh, delimiter="\t")
        if not reader.fieldnames or len(set(reader.fieldnames)) != len(reader.fieldnames):
            raise ValueError(f"{path}: absent/duplicate column headers")
        if not set(required).issubset(reader.fieldnames):
            raise ValueError(f"{path}: required columns {required}")
        rows = list(reader)
    for number, row in enumerate(rows, 2):
        if None in row or any(v is None for v in row.values()):
            raise ValueError(f"{path}:{number}: ragged TSV row")
        if any(row[k] == "" or row[k] != row[k].strip() for k in required if k != "value"):
            raise ValueError(f"{path}:{number}: empty/padded identifier")
    return rows


def unique_ids(rows, key, label):
    ids = [r[key] for r in rows]
    if not ids or len(ids) != len(set(ids)):
        raise ValueError(f"{label}: empty or duplicate {key}")
    return ids


def numeric(raw, unit):
    if raw in MISSING:
        return None
    value = float(raw)
    if not math.isfinite(value) or value < 0:
        raise ValueError(f"quantity must be finite/nonnegative: {raw!r}")
    if unit == "read_count" and not value.is_integer():
        raise ValueError("read_count requires integers; use estimated_count for fractional estimates")
    return value


def sha(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def write_tsv(path, headers, rows):
    with open(path, "w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, headers, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        for row in rows:
            writer.writerow({k: "NA" if row.get(k) is None else row[k] for k in headers})


def aggregate(args):
    output = pathlib.Path(args.out)
    if output.exists() and any(output.iterdir()):
        raise ValueError("output directory must be new or empty")
    genes = unique_ids(read_table(args.genes, ["gene_id"]), "gene_id", "gene catalog")
    samples = unique_ids(read_table(args.samples, ["sample_id"]), "sample_id", "samples")
    gene_set, sample_set = set(genes), set(samples)
    quant = {}
    explicit_na = 0
    for r in read_table(args.quant, ["gene_id", "sample_id", "value"]):
        key = r["gene_id"], r["sample_id"]
        if key[0] not in gene_set or key[1] not in sample_set:
            raise ValueError(f"quantity identifier absent from catalog/sample table: {key}")
        if key in quant:
            raise ValueError(f"duplicate gene/sample quantity: {key}")
        quant[key] = numeric(r["value"], args.unit)
        explicit_na += quant[key] is None
    ann = collections.defaultdict(lambda: collections.defaultdict(set))
    ann_rows = read_table(args.annotations, ["gene_id", "database", "feature_id"])
    duplicates = 0
    for r in ann_rows:
        if r["gene_id"] not in gene_set:
            raise ValueError(f"annotation gene not in catalog: {r['gene_id']}")
        if r["feature_id"] == UNANNOTATED:
            raise ValueError(f"reserved feature ID {UNANNOTATED}")
        bucket = ann[r["database"]][r["gene_id"]]
        duplicates += r["feature_id"] in bucket
        bucket.add(r["feature_id"])
    if not ann:
        raise ValueError("annotation table has no database/feature records")
    # Different annotation databases are independent views; never pool their totals.
    layers = {( "direct", db): gene_features for db, gene_features in ann.items()}
    universes = {key: set().union(*mapping.values()) for key, mapping in layers.items()}
    map_duplicates, unused_map_sources = 0, set()
    if args.members:
        member_rows = read_table(args.members, ["database", "feature_id", "target_database", "target_id", "target_kind"])
        seen = set()
        source_genes = collections.defaultdict(set)
        for db, mapping in ann.items():
            for gene, fs in mapping.items():
                for feature in fs:
                    source_genes[(db, feature)].add(gene)
        known_sources = set(source_genes)
        for r in member_rows:
            if r["target_kind"] not in {"module", "pathway", "member_group"}:
                raise ValueError("target_kind must be module, pathway, or member_group")
            if r["target_id"] == UNANNOTATED:
                raise ValueError(f"reserved target ID {UNANNOTATED}")
            identity = tuple(r[k] for k in ["database", "feature_id", "target_database", "target_id", "target_kind"])
            if identity in seen:
                map_duplicates += 1
                continue
            seen.add(identity)
            key = ("member_" + r["target_kind"], r["target_database"])
            layers.setdefault(key, collections.defaultdict(set))
            universes.setdefault(key, set()).add(r["target_id"])
            source = r["database"], r["feature_id"]
            if source not in known_sources:
                unused_map_sources.add(source)
            for gene in source_genes.get(source, set()):
                layers[key][gene].add(r["target_id"])
    projected_rows = sum((len(fs) + 1) * len(samples) for fs in universes.values())
    projected_contributions = sum(sum(max(1, len(mapping.get(g, []))) for g in genes) * len(samples) for mapping in layers.values())
    if projected_rows > args.max_output_rows:
        raise ValueError(f"{projected_rows} abundance rows exceed --max-output-rows; review memory/disk or explicitly narrow annotation feature views while retaining the full gene/sample catalog")
    if projected_contributions // len(samples) > args.max_output_rows:
        raise ValueError("gene assignment table exceeds --max-output-rows; review resource capacity")
    if args.write_contributions and projected_contributions > args.max_output_rows:
        raise ValueError(f"{projected_contributions} contribution rows exceed --max-output-rows; omit --write-contributions or review resource limits")
    assignments, values, summaries, contributions = [], [], [], []
    multimapped = []
    for (layer, db), mapping in sorted(layers.items()):
        inverse = collections.defaultdict(dict)
        for gene in genes:
            targets = mapping.get(gene, set()) or {UNANNOTATED}
            weight = 1.0 / len(targets) if args.multimap == "fractional" else 1.0
            if len(targets) > 1:
                multimapped.append({"layer": layer, "database": db, "gene_id": gene, "n_targets": len(targets)})
            for target in sorted(targets):
                inverse[target][gene] = weight
                assignments.append(dict(layer=layer, database=db, gene_id=gene, feature_id=target, weight=weight))
        for target in sorted(universes[(layer, db)] | {UNANNOTATED}):
            members = inverse[target]
            for sample in samples:
                observed = [(g, w, quant.get((g, sample))) for g, w in members.items() if quant.get((g, sample)) is not None]
                total = math.fsum(w * q for _, w, q in observed)
                n_missing = len(members) - len(observed)
                status = "no_catalog_members" if not members else "incomplete" if n_missing else "complete"
                values.append(dict(layer=layer, database=db, feature_id=target, sample_id=sample,
                                   value=total if status == "complete" else None, observed_sum=total,
                                   n_catalog_genes=len(members), n_observed_genes=len(observed), n_missing_genes=n_missing,
                                   status=status, unit=args.unit))
                for gene, weight in (members.items() if args.write_contributions else []):
                    q = quant.get((gene, sample))
                    contributions.append(dict(layer=layer, database=db, feature_id=target, gene_id=gene, sample_id=sample,
                                              weight=weight, gene_value=q, contribution=None if q is None else weight * q,
                                              quantity_status="missing" if q is None else "observed", unit=args.unit))
        for sample in samples:
            observed_all = [quant[(g, sample)] for g in genes if quant.get((g, sample)) is not None]
            unannotated = [g for g in genes if not mapping.get(g)]
            annotated = [g for g in genes if mapping.get(g)]
            def observed_sum(group):
                return math.fsum(quant[(g, sample)] for g in group if quant.get((g, sample)) is not None)
            sample_values = [v for v in values if v["layer"] == layer and v["database"] == db and v["sample_id"] == sample]
            summaries.append(dict(layer=layer, database=db, sample_id=sample, unit=args.unit,
                                  total_catalog_genes=len(genes), observed_genes=len(observed_all),
                                  missing_genes=len(genes)-len(observed_all), observed_catalog_total=math.fsum(observed_all),
                                  catalog_total=math.fsum(observed_all) if len(observed_all) == len(genes) else None,
                                  annotated_observed_total=observed_sum(annotated), unannotated_observed_total=observed_sum(unannotated),
                                  weighted_membership_observed_total=math.fsum(v["observed_sum"] for v in sample_values)))
    output.mkdir(parents=True, exist_ok=True)
    tables = [
        ("functional_abundance.tsv", values, ["layer", "database", "feature_id", "sample_id", "value", "observed_sum", "n_catalog_genes", "n_observed_genes", "n_missing_genes", "status", "unit"]),
        ("gene_assignments.tsv", assignments, ["layer", "database", "gene_id", "feature_id", "weight"]),
        ("sample_denominators.tsv", summaries, ["layer", "database", "sample_id", "unit", "total_catalog_genes", "observed_genes", "missing_genes", "observed_catalog_total", "catalog_total", "annotated_observed_total", "unannotated_observed_total", "weighted_membership_observed_total"]),
        ("multimapped_genes.tsv", multimapped, ["layer", "database", "gene_id", "n_targets"]),
    ]
    if args.write_contributions:
        tables.append(("gene_contributions.tsv", contributions, ["layer", "database", "feature_id", "gene_id", "sample_id", "weight", "gene_value", "contribution", "quantity_status", "unit"]))
    for name, rows, headers in tables:
        for row in rows:
            row["gene_scope"] = args.gene_scope
        write_tsv(output / name, headers + ["gene_scope"], rows)
    sources = [args.quant, args.genes, args.samples, args.annotations, args.source_evidence, __file__] + ([args.members] if args.members else [])
    manifest = dict(tool="aggregate_gene_functions", version=VERSION, created_utc=datetime.now(timezone.utc).isoformat(),
                    dataset_kind=args.dataset_kind, unit=args.unit, gene_scope=args.gene_scope, multimap_policy=args.multimap, source_note=args.source_note,
                    python=platform.python_version(), argv=sys.argv,
                    source_files=[{"path": str(pathlib.Path(p).resolve()), "sha256": sha(p)} for p in sources],
                    output_files=[{"path": p.name, "sha256": sha(p)} for p in sorted(output.iterdir())],
                    diagnostics=dict(genes=len(genes), samples=len(samples), explicit_missing_rows=explicit_na,
                                     absent_quantity_cells=len(genes)*len(samples)-len(quant),
                                     duplicate_annotation_rows_collapsed=duplicates, duplicate_member_rows_collapsed=map_duplicates,
                                     unused_member_sources=[list(x) for x in sorted(unused_map_sources)]),
                    semantics={"zero": "explicit measured zero; never filled for absent quant cells", "missing": "blank/NA or absent row; feature value is NA if any assigned gene missing",
                               "member_abundance": "unique gene membership union per target, not KO-row sum, activity, flux, or module completeness",
                               "fractional": "equal allocation across each gene's unique targets within each layer/database, recalculated for target membership",
                               "full_membership": "full gene quantity in each target; sums may exceed catalog total",
                               "unannotated": "retained independently within each namespace; denominator includes all catalog genes",
                               "normalization": "none; no annotated-only renormalization or TPM calculation; databases are separate views"})
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False)+"\n", encoding="utf-8")
    print(json.dumps({"out": str(output.resolve()), "genes": len(genes), "samples": len(samples), "abundance_rows": len(values)}))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--quant", required=True)
    p.add_argument("--genes", required=True, help="complete catalog TSV with gene_id")
    p.add_argument("--samples", required=True, help="complete sample manifest TSV with sample_id")
    p.add_argument("--annotations", required=True)
    p.add_argument("--members", help="explicit supplied feature-to-module/pathway/group mapping TSV")
    p.add_argument("--unit", required=True, choices=UNITS)
    p.add_argument("--gene-scope", required=True, choices=["locus", "representative_family"], help="declared quantification identity; no family-to-locus allocation is inferred")
    p.add_argument("--multimap", required=True, choices=["full_membership", "fractional"])
    p.add_argument("--source-evidence", required=True, help="existing provenance record; recorded/hash only, not independently certified")
    p.add_argument("--source-note", required=True)
    p.add_argument("--dataset-kind", required=True, choices=["synthetic", "real"])
    p.add_argument("--out", required=True)
    p.add_argument("--write-contributions", action="store_true", help="optional large gene×sample×membership detail; assignments are always retained")
    p.add_argument("--max-output-rows", type=int, default=2000000, help="resource guard; review capacity before increasing")
    args = p.parse_args()
    if not pathlib.Path(args.source_evidence).is_file():
        p.error("source evidence file does not exist")
    try:
        aggregate(args)
    except (ValueError, OSError, OverflowError) as exc:
        p.exit(2, f"ERROR: {exc}\n")


if __name__ == "__main__":
    main()
