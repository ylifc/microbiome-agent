#!/usr/bin/env python3
"""Traceable file-only scientific visualization; never runs phylogenetic inference."""
from __future__ import annotations
import argparse
from collections import Counter
import csv
import hashlib
import html
import io
import json
import math
from pathlib import Path
import shutil
import sys
import textwrap
from datetime import datetime, timezone

import Bio
from Bio.Phylo import NewickIO
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.patches import Patch

ORDERS = ('SH-aLRT/UFBoot', 'SH-aLRT', 'UFBoot')
UNKNOWN = 'Unknown'
GROUP_COLORS = {'C': '#009E73', 'L': '#56B4E9', 'M': '#E69F00', 'H': '#CC79A7', UNKNOWN: '#B6B6B6'}
REQUIRED = ('genome_id', 'sample_id', 'group', 'phylum', 'species')
QA_CHECKS = ('labels_readable', 'support_mapping_clear', 'no_clipping', 'colors_consistent', 'identity_coverage')


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def write_json(path, data):
    with Path(path).open('x', encoding='utf-8') as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write('\n')


def number(value, maximum, field):
    if value in ('', None, 'NA'):
        return None
    try:
        result = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f'Invalid {field}: {value!r}') from exc
    require(math.isfinite(result) and 0 <= result <= maximum, f'Out-of-range {field}: {value!r}')
    return result


def identity(value):
    require(isinstance(value, str) and value and not any(c.isspace() for c in value), 'Genome/sample IDs must be exact non-whitespace strings')
    return value


class RawParser(NewickIO.Parser):
    def process_clade(self, clade):
        clade.raw_support = clade.name if clade.clades else None
        return super().process_clade(clade)


def nodes_of(tree):
    ordered = []
    stack = [(tree.root, None, 0.)]
    while stack:
        node, parent, x = stack.pop()
        node._parent, node._x = parent, x
        ordered.append(node)
        for child in reversed(node.clades):
            stack.append((child, node, x + (child.branch_length or 0.)))
    return ordered


def validate_identical_groups(metadata):
    """Validate declarations only; no alignment comparison or duplicate inference."""
    groups = {}
    for gid, row in metadata.items():
        group = row['identical_msa_group']
        raw_count = row.get('identical_msa_count', '')
        raw_members = row.get('identical_msa_members', '')
        row['_identical_count'] = None
        row['_identical_members'] = None
        row['_identical_status'] = 'none'
        if raw_count or raw_members:
            require(group and raw_count and raw_members, 'Identical-MSA count and members must both be supplied with a group: ' + gid)
            require(raw_count.isascii() and raw_count.isdigit() and int(raw_count) >= 1,
                    'Identical-MSA count must be an integer >= 1: ' + gid)
            members = [identity(member) for member in raw_members.split(';')]
            require(len(members) == len(set(members)) and gid in members,
                    'Identical-MSA members must be unique and include this genome: ' + gid)
            require(len(members) == int(raw_count), 'Identical-MSA count/member mismatch: ' + gid)
            require(set(members) <= set(metadata), 'Identical-MSA members absent from figure metadata: ' + gid)
            row['_identical_count'] = int(raw_count)
            row['_identical_members'] = frozenset(members)
            row['_identical_status'] = 'multimember' if int(raw_count) > 1 else 'singleton'
        elif group:
            row['_identical_status'] = 'unknown_size'
        if group:
            identity(group)
            groups.setdefault(group, []).append(gid)
    for group, gids in groups.items():
        signatures = {(metadata[gid]['_identical_count'], metadata[gid]['_identical_members']) for gid in gids}
        require(len(signatures) == 1, 'Inconsistent identical-MSA declarations within group: ' + group)
        count, members = next(iter(signatures))
        if count is not None:
            require(set(gids) == members, 'Identical-MSA group/member identity mismatch: ' + group)


def identical_summary(metadata):
    def group_count(status):
        return len({r['identical_msa_group'] for r in metadata.values() if r['_identical_status'] == status})
    return {'declared_multimember_identical_group_count': group_count('multimember'),
            'declared_multimember_identical_genome_count': sum(r['_identical_status'] == 'multimember' for r in metadata.values()),
            'declared_singleton_identical_group_count': group_count('singleton'),
            'declared_unknown_size_identical_group_count': group_count('unknown_size')}


def load_inputs(tree_path, metadata_path, order):
    require(order in ORDERS, 'Unsupported support order: sCF is not bootstrap; use a separately audited sCF table')
    raw = Path(tree_path).read_text(encoding='utf-8')
    require(raw.strip().endswith(';'), 'Newick must terminate with a semicolon')
    trees = list(RawParser(io.StringIO(raw)).parse(rooted=False))
    require(len(trees) == 1, 'Exactly one native tree required')
    tree = trees[0]
    nodes = nodes_of(tree)
    leaves = [n for n in nodes if not n.clades]
    ids = [identity(n.name) for n in leaves]
    require(len(ids) >= 2 and len(ids) == len(set(ids)), 'Duplicate or insufficient tree leaf identities')
    for n in nodes:
        require(n.branch_length is None and n is tree.root or n.branch_length is not None and math.isfinite(n.branch_length) and n.branch_length >= 0, 'Missing/nonfinite/negative native branch length')
        n._support = {}
        if n.clades and n.raw_support not in (None, ''):
            pieces = n.raw_support.split('/')
            require(len(pieces) == len(order.split('/')), 'Support fields do not match declared order; sCF must not be merged into bootstrap')
            for key, value in zip(order.split('/'), pieces):
                n._support[key] = number(value, 100, key)
                require(n._support[key] is not None, 'Missing value inside numeric support label')
    with Path(metadata_path).open(encoding='utf-8-sig', newline='') as handle:
        reader = csv.DictReader(handle, delimiter='\t')
        fields = reader.fieldnames or []
        require(len(fields) == len(set(fields)) and set(REQUIRED) <= set(fields), 'Missing or duplicate metadata columns')
        original = {}
        metadata = {}
        for row in reader:
            require(None not in row and all(v is not None for v in row.values()), 'Malformed TSV row')
            require(not any(any(ch in v for ch in '\r\n\t') for v in row.values()), 'Embedded TSV control characters')
            gid = identity(row['genome_id'])
            identity(row['sample_id'])
            require(gid not in original, 'Duplicate metadata identity: ' + gid)
            original[gid] = dict(row)
            parsed = dict(row)
            for key in ('group', 'phylum', 'species'):
                parsed[key] = parsed[key] if parsed[key].strip() else UNKNOWN
            for key, maximum in (('completeness', 100), ('contamination', 100), ('msa_aa_fraction', 1)):
                parsed[key] = number(row.get(key), maximum, key)
            parsed['identical_msa_group'] = row.get('identical_msa_group', '')
            metadata[gid] = parsed
    require(set(original) == set(ids), 'Exact tree/metadata leaf join failed: missing or extra IDs')
    validate_identical_groups(metadata)
    sample_groups = {}
    for row in metadata.values():
        sample_groups.setdefault(row['sample_id'], set()).add(row['group'])
    require(all(len(v) == 1 for v in sample_groups.values()), 'One sample maps to multiple groups')
    for i, n in enumerate(leaves):
        n._y = float(i)
        n._desc = [n.name]
    for n in reversed(nodes):
        if n.clades:
            n._y = sum(c._y for c in n.clades) / len(n.clades)
            n._desc = [gid for c in n.clades for gid in c._desc]
    supported = sorted([n for n in nodes if n.clades and n._support], key=lambda n: n._y)
    previous = -.45
    for n in supported:
        n._label_y = max(n._y, previous + .48)
        previous = n._label_y
    following = len(leaves) - .08
    for n in reversed(supported):
        n._label_y = min(n._label_y, following - .48)
        following = n._label_y
    require(not supported or supported[0]._label_y >= -.49, 'Too many supported nodes for readable rows')
    return tree, nodes, leaves, metadata, original, fields


def source_contract(path, tree, metadata, order):
    contract = json.loads(Path(path).read_text())
    require(contract.get('dataset_kind') in ('synthetic', 'biological'), 'Explicit dataset kind required')
    require(isinstance(contract.get('description'), str) and contract['description'].strip(), 'Source description required')
    require(contract.get('support_order') == order, 'Source support statistic/order mismatch')
    require(contract.get('inputs') == {'tree': sha(tree), 'metadata': sha(metadata)}, 'Source hash mismatch')
    status = contract.get('source_scientific_status')
    require(status in ('synthetic_fixture', 'unverified', 'validated'), 'Explicit source scientific status required')
    require((contract['dataset_kind'] == 'synthetic') == (status == 'synthetic_fixture'), 'Synthetic/source status inconsistent')
    evidence = contract.get('source_evidence', [])
    if contract['dataset_kind'] == 'biological':
        require(evidence, 'Biological data require traceable source evidence')
    for item in evidence:
        require(sha(item['path']) == item['sha256'], 'Source evidence changed')
    return contract


def palette(values, key):
    values = sorted(set(values))
    if key == 'group':
        values = [v for v in ('C', 'L', 'M', 'H') if v in values] + [v for v in values if v not in ('C', 'L', 'M', 'H')]
    cmap = plt.get_cmap('tab20')
    return {v: (GROUP_COLORS.get(v, matplotlib.colors.to_hex(cmap(i % 20))) if key == 'group'
                else '#B6B6B6' if v == UNKNOWN else matplotlib.colors.to_hex(cmap(i % 20))) for i, v in enumerate(values)}


def segments(nodes):
    result = []
    for n in nodes:
        if n._parent is not None:
            result.append([(n._parent._x, n._y), (n._x, n._y)])
        if n.clades:
            result.append([(n._x, min(c._y for c in n.clades)), (n._x, max(c._y for c in n.clades))])
    return result


def wrapped_label(row):
    lines = []
    for text in [f"{row['genome_id']} | sample {row['sample_id']} | group {row['group']}",
                 f"Species: {row['species']}", f"Phylum: {row['phylum']}"]:
        lines.extend(textwrap.wrap(text, width=83, break_long_words=True, break_on_hyphens=False) or [''])
    if row.get('_identical_status') == 'multimember':
        text = f"Declared identical MSA: {row['identical_msa_group']} ({row['_identical_count']} members; unresolved)"
        lines.extend(textwrap.wrap(text, 83))
    elif row.get('_identical_status') == 'unknown_size':
        lines.extend(textwrap.wrap('MSA group declaration: ' + row['identical_msa_group'] + ' (size unknown; duplicates not established)', 83))
    return lines


def title_label(contract, title):
    return ('SYNTHETIC ENGINEERING FIXTURE — NOT BIOLOGICAL RESULTS\n' if contract['dataset_kind'] == 'synthetic'
            else 'VISUALIZATION PREVIEW — source status: ' + contract['source_scientific_status'] + '\n') + title


def tree_figure(nodes, leaves, metadata, colors, title, order, start=0, stop=None, overview=False):
    stop = len(leaves) if stop is None else stop
    row_lines = max(len(wrapped_label(metadata[n.name])) for n in leaves[start:stop])
    row_height = max(.44, .135 * row_lines)
    height = 11.7 if overview else max(6, (stop - start) * row_height + 2.0)
    require(height <= 40, 'Full labels require excessively tall detail page; lower --rows-per-page')
    width = 16.5 if overview else 23
    fig = plt.figure(figsize=(width, height), facecolor='white')
    left, right = (.055, .77) if overview else (.035, .405)
    bottom, top = .9 / height, 1 - 1.25 / height
    tax = fig.add_axes([left, bottom, right - left, top - bottom])
    tax.add_collection(LineCollection(segments(nodes), colors='#44525A', linewidths=.35 if overview else .6))
    maxx = max(n._x for n in nodes) or 1.
    tax.set_xlim(-maxx*.005, maxx*1.065)
    tax.set_ylim(stop - .5, start - .5)
    tax.set_yticks([])
    tax.set_xlabel('Substitutions / site — native lengths; drawing root has no ancestral meaning', fontsize=8)
    tax.tick_params(axis='x', labelsize=8)
    tax.spines[['top', 'right', 'left']].set_visible(False)
    if not overview:
        for n in nodes:
            if n.clades and n._support and start-.5 <= n._label_y < stop-.5:
                tax.annotate(n.raw_support, (n._x, n._y), (n._x + maxx*.01, n._label_y),
                    fontsize=6.5, ha='left', va='center', annotation_clip=False,
                    bbox={'facecolor': 'white', 'edgecolor': 'none', 'pad': .45, 'alpha': .94},
                    arrowprops={'arrowstyle': '-', 'lw': .3, 'color': '#647580'})
        lax = fig.add_axes([.435, bottom, .395, top-bottom]); lax.set_ylim(stop-.5, start-.5);lax.set_xlim(0,1);lax.axis('off')
        qax = fig.add_axes([.918, bottom, .077, top-bottom]);qax.set_ylim(stop-.5,start-.5);qax.set_xlim(-.5,2.5);qax.set_yticks([])
        qax.xaxis.tick_top();qax.set_xticks([0,1,2],['Comp.%','Cont.%','AA%'],fontsize=7)
        for spine in qax.spines.values():spine.set_visible(False)
        for i in range(start,stop):
            row=metadata[leaves[i].name]
            lax.text(0,i,'\n'.join(wrapped_label(row)),fontsize=7.2,va='center',linespacing=1.13)
            for j,(key,scale) in enumerate((('completeness',1),('contamination',1),('msa_aa_fraction',100))):
                v=row[key];qax.text(j,i,'NA' if v is None else f'{v*scale:.1f}',fontsize=7,ha='center',va='center')
            if i % 2 == 0:
                lax.axhspan(i-.48,i+.48,color='#F0F4F6',zorder=-1)
                qax.axhspan(i-.48,i+.48,color='#F0F4F6',zorder=-1)
    sx, sw = (.80,.16) if overview else (.845,.06)
    sax=fig.add_axes([sx,bottom,sw,top-bottom]);sax.set_ylim(stop-.5,start-.5);sax.set_xlim(-.5,2.5);sax.set_yticks([])
    sax.xaxis.tick_top();sax.set_xticks([0,1,2],['Group','Sample','Phylum'],fontsize=8 if overview else 7)
    for spine in sax.spines.values():spine.set_visible(False)
    from matplotlib.colors import to_rgba
    strips=[[to_rgba(colors[key][metadata[n.name][key]]) for key in ('group','sample_id','phylum')] for n in leaves[start:stop]]
    sax.imshow(strips,extent=(-.5,2.5,stop-.5,start-.5),aspect='auto',interpolation='nearest')
    fig.text(.035,1-.18/height,title,fontsize=12,weight='bold',va='top')
    caption=(f'Overview: all {len(leaves):,} leaves; exact IDs and every supplied support value are in detail pages/index.' if overview
             else f'Rows {start+1}–{stop} / {len(leaves)} | support order {order}; zero is measured, missing is unavailable.')
    fig.text(.035,1-.78/height,caption,fontsize=9,va='top')
    fig.text(.035,.23/height,'Native topology and leaf order retained. Colors annotate genomes; counts do not represent independent animals. Legend is separate.',fontsize=8)
    return fig


def save_formats(fig, base, pdf=True):
    for ext in ('svg','pdf','png') if pdf else ('svg','png'):
        fig.savefig(str(base)+'.'+ext,dpi=120,facecolor='white')


def write_tsv(path, rows, fields):
    with Path(path).open('x',encoding='utf-8',newline='') as handle:
        writer=csv.DictWriter(handle,fieldnames=fields,delimiter='\t',extrasaction='raise')
        writer.writeheader();writer.writerows(rows)


def render(args):
    require(4 <= args.rows_per_page <= 64,'rows-per-page must be 4–64')
    sources={key:Path(getattr(args,key)).resolve(strict=True) for key in ('tree','metadata','source_manifest')}
    hashes={key:sha(path) for key,path in sources.items()}
    contract=source_contract(args.source_manifest,args.tree,args.metadata,args.support_order)
    tree,nodes,leaves,metadata,original,fields=load_inputs(args.tree,args.metadata,args.support_order)
    require(not args.out_dir.is_symlink(),'Redirected output directory forbidden')
    out=args.out_dir.resolve()
    require(not out.exists() or out.is_dir() and not any(out.iterdir()),'Use a fresh or empty output directory')
    require(not any(p==out or out in p.parents for p in sources.values()),'Input files must be outside output directory')
    require(not out.is_symlink(),'Redirected output directory forbidden')
    reserved={'figure_page','row_in_figure','display_missing_fields'}
    require(not reserved & set(fields),'Reserved output columns present in metadata')
    for i in range(0,len(leaves),args.rows_per_page):
        height=(min(args.rows_per_page,len(leaves)-i)*max(.44,.135*max(len(wrapped_label(metadata[n.name])) for n in leaves[i:i+args.rows_per_page]))+2)
        require(height<=40,'Full labels require shorter pages; lower --rows-per-page')
    out.mkdir(parents=True,exist_ok=True);(out/'pages').mkdir()
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'pdf.fonttype':42,'svg.fonttype':'none','axes.unicode_minus':False})
    colors={key:palette([r[key] for r in metadata.values()],key) for key in ('group','sample_id','phylum')}
    title=title_label(contract,args.title)
    overview=tree_figure(nodes,leaves,metadata,colors,title,args.support_order,overview=True)
    save_formats(overview,out/'overview');plt.close(overview)
    page_count=math.ceil(len(leaves)/args.rows_per_page);page_support_counts=[]
    with PdfPages(out/'details.pdf') as pdf:
        for page,start in enumerate(range(0,len(leaves),args.rows_per_page),1):
            stop=min(start+args.rows_per_page,len(leaves))
            fig=tree_figure(nodes,leaves,metadata,colors,title+f' — page {page}/{page_count}',args.support_order,start,stop)
            pdf.savefig(fig);save_formats(fig,out/'pages'/f'page_{page:03d}',pdf=False);plt.close(fig)
            page_support_counts.append(sum(bool(n.clades) and bool(n._support) and start-.5<=n._label_y<stop-.5 for n in nodes))
    counts=Counter(r['group'] for r in metadata.values())
    fig,axes=plt.subplots(1,2,figsize=(15,6));fig.subplots_adjust(top=.72,bottom=.16,wspace=.3);fig.suptitle(title,fontsize=12,weight='bold')
    n_quality=0
    groups=list(colors['group'])
    for group in groups:
        subset=[r for r in metadata.values() if r['group']==group and r['completeness'] is not None and r['contamination'] is not None]
        n_quality+=len(subset)
        axes[0].scatter([r['completeness'] for r in subset],[r['contamination'] for r in subset],s=12,alpha=.55,c=colors['group'][group],label=group)
    max_cont=max((r['contamination'] for r in metadata.values() if r['contamination'] is not None and r['completeness'] is not None),default=0.)
    upper=max(5.,min(101.,max_cont*1.08+0.5))
    axes[0].set(xlabel='Completeness (%)',ylabel='Contamination (%)',xlim=(-1,101),ylim=(-upper*.015,upper),title=f'Quality: {n_quality}/{len(leaves)} genomes with both values')
    axes[0].legend(frameon=False)
    axes[1].bar(groups,[counts[k] for k in groups],color=[colors['group'][k] for k in groups])
    axes[1].set(ylabel='Genome count (not biological replicates)',title='All supplied genomes per group')
    fig.text(.07,.05,'Descriptive visualization only; no significance or treatment-effect inference. Missing quality pairs are omitted from scatter, not from counts.',fontsize=8)
    save_formats(fig,out/'quality_counts');plt.close(fig)
    fig,axes=plt.subplots(1,3,figsize=(16,max(5,max(len(v) for v in colors.values())*.28+2)))
    fig.suptitle(title+' — color key',fontsize=12,weight='bold');fig.subplots_adjust(top=.77)
    for ax,key in zip(axes,colors):
        ax.axis('off');ax.legend(handles=[Patch(facecolor=c,label=textwrap.fill(v,32)) for v,c in colors[key].items()],title=key,loc='upper left',frameon=False,fontsize=9)
    save_formats(fig,out/'legend');plt.close(fig)
    rows=[]
    for i,n in enumerate(leaves):
        row=dict(original[n.name]);row.update(figure_page=i//args.rows_per_page+1,row_in_figure=i%args.rows_per_page+1,
            display_missing_fields=','.join(k for k in ('group','phylum','species','completeness','contamination','msa_aa_fraction') if metadata[n.name][k] in (None,UNKNOWN)))
        rows.append(row)
    write_tsv(out/'genome_index.tsv',rows,fields+['figure_page','row_in_figure','display_missing_fields'])
    branch_rows=[]
    for i,n in enumerate(n for n in nodes if n.clades):
        branch_rows.append({'node_id':f'N{i+1:05d}','is_display_root':n is tree.root,'raw_support':n.raw_support or '',
            'support_order':args.support_order,'SH-aLRT':n._support.get('SH-aLRT',''),'UFBoot':n._support.get('UFBoot',''),
            'detail_page':math.floor((n._label_y+.5)/args.rows_per_page)+1 if n._support else '',
            'descendant_ids':json.dumps(n._desc,ensure_ascii=False)})
    write_tsv(out/'branch_support.tsv',branch_rows,list(branch_rows[0]))
    shutil.copy2(args.tree,out/'source_tree.nwk');shutil.copy2(args.metadata,out/'source_metadata.tsv');shutil.copy2(args.source_manifest,out/'source_manifest.json')
    links=''.join(f'<li><a href="pages/page_{i:03d}.png">Page {i} PNG</a> · <a href="pages/page_{i:03d}.svg">SVG</a></li>' for i in range(1,page_count+1))
    html_body=f'''<!doctype html><meta charset="utf-8"><title>{html.escape(args.title)}</title><style>body{{max-width:1200px;margin:2em auto;font:16px system-ui;line-height:1.5}}img{{max-width:100%}}li{{margin:.3em}}.banner{{padding:1em;background:#fff1cf}}</style><h1>{html.escape(title).replace(chr(10),'<br>')}</h1><p class="banner">PREVIEW. Visualization QA is separate from scientific validation. Synthetic data remain synthetic.</p><p>All {len(leaves)} identities are preserved. The overview omits text deliberately; use detail pages for native support labels.</p><a href="overview.svg"><img src="overview.png" alt="Native tree overview and annotation strips"></a><p><a href="details.pdf">All detail pages PDF</a> · <a href="genome_index.tsv">Complete genome index</a> · <a href="branch_support.tsv">Branch support table</a> · <a href="render_manifest.json">Source and output hashes</a></p><h2>Quality and counts</h2><img src="quality_counts.png"><h2>Color key</h2><img src="legend.png"><h2>Readable detail pages</h2><ul>{links}</ul>'''
    (out/'index.html').write_text(html_body,encoding='utf-8')
    require(hashes=={key:sha(path) for key,path in sources.items()},'Source modified during rendering')
    dense=page_support_counts.index(max(page_support_counts))+1
    qa_images=['overview.png','legend.png','quality_counts.png']+[f'pages/page_{p:03d}.png' for p in sorted({1,(page_count+1)//2,page_count,dense})]
    limits=['Overview intentionally omits leaf/support text; every supplied value remains in detail pages and tables.',
            'Newick root is display-only. Rendering does not verify source biological conclusions or compute supports.',
            'sCF is not included; provide a separately audited branch table/view if requested.',
            'Identical-MSA groups are supplied declarations; only validated multi-member declarations are labeled unresolved. Unknown-size groups do not establish duplicates; no alignments are read or compared.',
            'Color palettes repeat after 20 nonstandard categories; inspect the legend and exact metadata when categories exceed 20.']
    manifest={'schema_version':1,'status':'preview','scope':'visualization_only','dataset_kind':contract['dataset_kind'],
        'source_scientific_status':contract['source_scientific_status'],'title':args.title,'created_at':datetime.now(timezone.utc).isoformat(),
        'sources':{key:{'path':str(path),'sha256':hashes[key]} for key,path in sources.items()},
        'script':{'path':str(Path(__file__).resolve()),'sha256':sha(__file__)},'versions':{'python':sys.version.split()[0],'Bio':Bio.__version__,'matplotlib':matplotlib.__version__},
        'leaf_count':len(leaves),'internal_node_count':len(branch_rows),'numeric_support_count':sum(bool(n._support) for n in nodes),
        'support_order':args.support_order,'topology_changed':False,'rows_per_page':args.rows_per_page,'page_count':page_count,
        'page_support_label_counts':page_support_counts,'quality_pairs_plotted':n_quality,'group_genome_counts':dict(counts),'palettes':colors,
        **identical_summary(metadata),
        'qa_required_images':qa_images,'limitations':limits,
        'outputs_sha256':{str(f.relative_to(out)):sha(f) for f in sorted(out.rglob('*')) if f.is_file()}}
    write_json(out/'render_manifest.json',manifest)
    return {'status':'preview','leaf_count':len(leaves),'page_count':page_count,'manifest':str(out/'render_manifest.json'),'qa_required_images':qa_images}


def accept_qa(args):
    out=args.out_dir.resolve(strict=True);mp=out/'render_manifest.json'
    manifest=json.loads(mp.read_text());review=json.loads(args.review_file.read_text())
    require(manifest.get('status')=='preview','Expected completed preview manifest')
    require(review.get('render_manifest_sha256')==sha(mp),'Visual review bound to a different manifest')
    require(review.get('verdict')=='pass' and isinstance(review.get('reviewer'),str) and review['reviewer'].strip(),'Explicit reviewer and pass verdict required')
    require(all(review.get('checks',{}).get(k) is True for k in QA_CHECKS),'Visual QA checks incomplete')
    require(set(manifest['qa_required_images'])<=set(review.get('inspected_images',[])),'Required overview/detail images not all inspected')
    require(isinstance(review.get('limitations'),list) and all(isinstance(x,str) for x in review['limitations']),'Explicit limitations list required')
    for relative,expected in manifest['outputs_sha256'].items():
        path=(out/relative).resolve(strict=True)
        require(path.is_relative_to(out) and sha(path)==expected,'Rendered output changed after review: '+relative)
    for item in manifest['sources'].values():
        require(sha(item['path'])==item['sha256'],'Source changed since render')
    write_json(out/'visual_validation.json',{'status':'validated','scope':'visualization_only','dataset_kind':manifest['dataset_kind'],
        'source_scientific_status':manifest['source_scientific_status'],'render_manifest_sha256':sha(mp),
        'review_file':str(args.review_file.resolve()),'review_sha256':sha(args.review_file),'review':review,
        'note':'Human/agent visual declaration plus deterministic integrity checks; no biological inference or pipeline approval.',
        'validated_at':datetime.now(timezone.utc).isoformat()})
    return {'status':'validated','scope':'visualization_only','dataset_kind':manifest['dataset_kind']}


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__);subs=parser.add_subparsers(dest='command',required=True)
    m=subs.add_parser('manifest');r=subs.add_parser('render');q=subs.add_parser('accept-qa')
    for p in (m,r):
        p.add_argument('--tree',type=Path,required=True);p.add_argument('--metadata',type=Path,required=True);p.add_argument('--support-order',choices=ORDERS,required=True)
    m.add_argument('--out',type=Path,required=True);m.add_argument('--dataset-kind',choices=['synthetic','biological'],required=True)
    m.add_argument('--description',required=True);m.add_argument('--source-scientific-status',choices=['synthetic_fixture','unverified','validated'],required=True)
    m.add_argument('--source-evidence',type=Path,action='append',default=[])
    r.add_argument('--source-manifest',type=Path,required=True);r.add_argument('--out-dir',type=Path,required=True)
    r.add_argument('--title',required=True);r.add_argument('--rows-per-page',type=int,default=32)
    q.add_argument('--out-dir',type=Path,required=True);q.add_argument('--review-file',type=Path,required=True)
    args=parser.parse_args(argv)
    try:
        if args.command=='manifest':
            load_inputs(args.tree,args.metadata,args.support_order)
            require((args.dataset_kind=='synthetic')==(args.source_scientific_status=='synthetic_fixture'),'Dataset kind/status mismatch')
            require(args.dataset_kind=='synthetic' or args.source_evidence,'Biological source evidence required')
            require(args.description.strip(),'Description required')
            data={'dataset_kind':args.dataset_kind,'description':args.description,'support_order':args.support_order,
                'source_scientific_status':args.source_scientific_status,'inputs':{'tree':sha(args.tree),'metadata':sha(args.metadata)},
                'source_evidence':[{'path':str(f.resolve(strict=True)),'sha256':sha(f)} for f in args.source_evidence]}
            write_json(args.out,data);result={'manifest':str(args.out),'status':'source_recorded'}
        elif args.command=='render':result=render(args)
        else:result=accept_qa(args)
        print(json.dumps(result,ensure_ascii=False));return 0
    except (ValueError, OSError, KeyError, TypeError) as exc:
        print(json.dumps({'status':'FAILED','error':str(exc)},ensure_ascii=False),file=sys.stderr);return 2


if __name__=='__main__':
    raise SystemExit(main())
