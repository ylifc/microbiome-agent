"""Input-integrity and visual-QA gate tests; all fixtures are synthetic."""
import contextlib
import copy
import csv
import importlib.util
import io
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest

MODULE=Path(__file__).with_name('visualize_microbiome.py')
spec=importlib.util.spec_from_file_location('viz',MODULE);viz=importlib.util.module_from_spec(spec);spec.loader.exec_module(viz)

class FigureContractTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='synthetic_test_',dir=Path(__file__).parent);self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name)
        self.tree=self.root/'synthetic.nwk';self.meta=self.root/'synthetic.tsv'
        self.tree.write_text('((SYN_A:0.1,SYN_B:0.2)0/95:0.1,SYN_C:0.1,SYN_D:0.2);\n')
        self.meta.write_text('genome_id\tsample_id\tgroup\tphylum\tspecies\tcompleteness\tcontamination\tmsa_aa_fraction\n'+''.join(f'SYN_{x}\tSAMPLE_{x}\tC\tp__Synthetic\tSynthetic species {x}\t80\t0\t0.7\n' for x in 'ABCD'))
    def load(self):return viz.load_inputs(self.tree,self.meta,'SH-aLRT/UFBoot')
    def test_zero_support_not_missing(self):
        _,nodes,leaves,*_=self.load();self.assertEqual(len(leaves),4)
        self.assertEqual([n._support['SH-aLRT'] for n in nodes if n._support],[0])
        self.assertFalse(nodes[0]._support)
    def test_duplicate_leaf_rejected(self):
        self.tree.write_text(self.tree.read_text().replace('SYN_D','SYN_C'))
        with self.assertRaises(ValueError):self.load()
    def test_duplicate_metadata_rejected(self):
        with self.meta.open('a') as f:f.write(self.meta.read_text().splitlines()[1]+'\n')
        with self.assertRaises(ValueError):self.load()
    def test_extra_metadata_identity_rejected(self):
        with self.meta.open('a') as f:f.write('SYN_E\tSAMPLE_E\tC\tp__Synthetic\tSynthetic\t1\t1\t1\n')
        with self.assertRaises(ValueError):self.load()
    def test_missing_identity_rejected(self):
        self.meta.write_text('\n'.join(self.meta.read_text().splitlines()[:-1])+'\n')
        with self.assertRaises(ValueError):self.load()
    def test_missing_annotations_remain_explicit(self):
        self.meta.write_text(self.meta.read_text().replace('p__Synthetic\tSynthetic species A\t80\t0\t0.7','\t\t\t0\t'))
        *_,metadata,original,fields=self.load();self.assertIsNone(metadata['SYN_A']['completeness'])
        self.assertEqual(metadata['SYN_A']['contamination'],0);self.assertEqual(original['SYN_A']['phylum'],'')
    def test_nonfinite_and_out_of_range_quality_rejected(self):
        text=self.meta.read_text()
        for invalid in ['NaN','inf','-1','101']:
            self.meta.write_text(text.replace('\t80\t','\t'+invalid+'\t'))
            with self.subTest(invalid=invalid),self.assertRaises(ValueError):self.load()
    def test_support_order_cannot_hide_scf(self):
        with self.assertRaises(ValueError):viz.load_inputs(self.tree,self.meta,'sCF')
        self.tree.write_text(self.tree.read_text().replace('0/95','0/95/33.3'))
        with self.assertRaises(ValueError):self.load()
    def test_nonfinite_support_rejected(self):
        self.tree.write_text(self.tree.read_text().replace('0/95','NaN/95'))
        with self.assertRaises(ValueError):self.load()
    def test_missing_branch_length_rejected(self):
        self.tree.write_text(self.tree.read_text().replace('SYN_A:0.1','SYN_A'))
        with self.assertRaises(ValueError):self.load()
    def test_multiple_trees_rejected(self):
        self.tree.write_text(self.tree.read_text()*2)
        with self.assertRaises(ValueError):self.load()
    def test_full_labels_wrap_without_truncation(self):
        _,_,_,meta,*_=self.load();row=meta['SYN_A'];row['species']='Synthetic_LONG_'+'x'*250
        self.assertIn(row['species'],''.join(viz.wrapped_label(row)).replace(' ',''))
    def test_sample_group_contradiction_rejected(self):
        self.meta.write_text(self.meta.read_text().replace('SAMPLE_B\tC','SAMPLE_A\tL'))
        with self.assertRaises(ValueError):self.load()
    def declarations(self, values):
        with self.meta.open() as f:
            reader = csv.DictReader(f, delimiter='\t'); fields = reader.fieldnames; rows = list(reader)
        extra = ['identical_msa_group', 'identical_msa_count', 'identical_msa_members']
        with self.meta.open('w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fields+extra, delimiter='\t'); writer.writeheader()
            for row in rows:
                row.update(dict(zip(extra, values.get(row['genome_id'], ('', '', '')))))
                writer.writerow(row)
    def test_declared_singleton_not_unresolved(self):
        self.declarations({'SYN_A': ('HASH_A', '1', 'SYN_A')})
        _,_,_,meta,original,_ = self.load()
        self.assertEqual(meta['SYN_A']['_identical_status'], 'singleton')
        self.assertNotIn('unresolved', ' '.join(viz.wrapped_label(meta['SYN_A'])))
        self.assertEqual(original['SYN_A']['identical_msa_count'], '1')
        self.assertEqual(viz.identical_summary(meta)['declared_multimember_identical_group_count'], 0)
    def test_declared_pair_count_and_identity(self):
        self.declarations({'SYN_A': ('HASH_AB', '2', 'SYN_A;SYN_B'), 'SYN_B': ('HASH_AB', '2', 'SYN_B;SYN_A')})
        _,_,_,meta,*_ = self.load()
        self.assertIn('(2 members; unresolved)', ' '.join(viz.wrapped_label(meta['SYN_A'])))
        summary = viz.identical_summary(meta)
        self.assertEqual(summary['declared_multimember_identical_group_count'], 1)
        self.assertEqual(summary['declared_multimember_identical_genome_count'], 2)
    def test_group_only_is_unknown_size_not_duplicate(self):
        self.declarations({'SYN_A': ('HASH_AB', '', ''), 'SYN_B': ('HASH_AB', '', '')})
        _,_,_,meta,*_ = self.load(); label = ' '.join(viz.wrapped_label(meta['SYN_A']))
        self.assertIn('size unknown', label); self.assertIn('duplicates not established', label)
        self.assertNotIn('unresolved', label)
        self.assertEqual(viz.identical_summary(meta)['declared_unknown_size_identical_group_count'], 1)
    def test_identical_count_must_be_positive_integer(self):
        source = self.meta.read_text()
        for value in ('0', '-1', '2.0', 'nan', 'inf', ' 2', '２'):
            self.meta.write_text(source); self.declarations({'SYN_A': ('H', value, 'SYN_A')})
            with self.subTest(value=value), self.assertRaises(ValueError): self.load()
    def test_identical_members_require_unique_self_and_count(self):
        source = self.meta.read_text()
        for count,members in [('2','SYN_A;SYN_A'),('1','SYN_B'),('3','SYN_A;SYN_B'),('2','SYN_A;SYN_E'),('2','SYN_A; SYN_B')]:
            self.meta.write_text(source); self.declarations({'SYN_A': ('H',count,members)})
            with self.subTest(members=members,count=count), self.assertRaises(ValueError): self.load()
    def test_identical_incomplete_declaration_rejected(self):
        source = self.meta.read_text()
        for group,count,members in [('H','2',''),('H','','SYN_A;SYN_B'),('','1','SYN_A')]:
            self.meta.write_text(source); self.declarations({'SYN_A':(group,count,members)})
            with self.subTest(group=group,count=count,members=members), self.assertRaises(ValueError): self.load()
    def test_identical_same_group_conflicting_members_rejected(self):
        self.declarations({'SYN_A': ('H','2','SYN_A;SYN_B'), 'SYN_B': ('H','2','SYN_B;SYN_C')})
        with self.assertRaises(ValueError): self.load()
    def test_identical_mixed_known_unknown_same_group_rejected(self):
        self.declarations({'SYN_A': ('H','2','SYN_A;SYN_B'), 'SYN_B': ('H','','')})
        with self.assertRaises(ValueError): self.load()
    def test_identical_group_member_not_declared_rejected(self):
        self.declarations({'SYN_A': ('H','2','SYN_A;SYN_B')})
        with self.assertRaises(ValueError): self.load()
    def test_identical_two_groups_cannot_claim_same_members(self):
        self.declarations({'SYN_A': ('H1','2','SYN_A;SYN_B'), 'SYN_B': ('H2','2','SYN_A;SYN_B')})
        with self.assertRaises(ValueError): self.load()
    def contract(self):
        path=self.root/'source.json'
        data={'dataset_kind':'synthetic','description':'Synthetic test only','support_order':'SH-aLRT/UFBoot','source_scientific_status':'synthetic_fixture','inputs':{'tree':viz.sha(self.tree),'metadata':viz.sha(self.meta)},'source_evidence':[]}
        path.write_text(json.dumps(data));return path
    def test_source_drift_rejected(self):
        p=self.contract();self.tree.write_text(self.tree.read_text().replace('0/95','1/95'))
        with self.assertRaises(ValueError):viz.source_contract(p,self.tree,self.meta,'SH-aLRT/UFBoot')
    def test_false_biological_source_without_evidence_rejected(self):
        p=self.contract();d=json.loads(p.read_text());d.update(dataset_kind='biological',source_scientific_status='validated');p.write_text(json.dumps(d))
        with self.assertRaises(ValueError):viz.source_contract(p,self.tree,self.meta,'SH-aLRT/UFBoot')
    def qa_fixture(self):
        out=self.root/'render';out.mkdir();img=out/'SYNTHETIC.txt';img.write_text('SYNTHETIC QA contract only, not a rendered image')
        m={'status':'preview','dataset_kind':'synthetic','source_scientific_status':'synthetic_fixture','qa_required_images':['SYNTHETIC.txt'],'outputs_sha256':{'SYNTHETIC.txt':viz.sha(img)},'sources':{'tree':{'path':str(self.tree),'sha256':viz.sha(self.tree)}}}
        mp=out/'render_manifest.json';mp.write_text(json.dumps(m))
        q=self.root/'review.json';review={'verdict':'pass','reviewer':'SYNTHETIC TEST','render_manifest_sha256':viz.sha(mp),'inspected_images':['SYNTHETIC.txt'],'checks':{k:True for k in viz.QA_CHECKS},'limitations':['Synthetic unit fixture; no real image inspection implied']}
        q.write_text(json.dumps(review));return out,q,review
    def test_qa_requires_all_checks_and_required_images(self):
        out,q,d=self.qa_fixture();d['inspected_images']=[];q.write_text(json.dumps(d))
        with self.assertRaises(ValueError):viz.accept_qa(SimpleNamespace(out_dir=out,review_file=q))
        self.assertFalse((out/'visual_validation.json').exists())
    def test_qa_refuses_changed_output(self):
        out,q,d=self.qa_fixture();(out/'SYNTHETIC.txt').write_text('changed')
        with self.assertRaises(ValueError):viz.accept_qa(SimpleNamespace(out_dir=out,review_file=q))
        self.assertFalse((out/'visual_validation.json').exists())
    def test_qa_scope_never_becomes_biological(self):
        out,q,d=self.qa_fixture();r=viz.accept_qa(SimpleNamespace(out_dir=out,review_file=q))
        self.assertEqual(r,{'status':'validated','scope':'visualization_only','dataset_kind':'synthetic'})
        self.assertEqual(json.loads((out/'render_manifest.json').read_text())['status'],'preview')

if __name__=='__main__':unittest.main(verbosity=2)
