#!/usr/bin/env python3
"""Behavior checks for the base-R CLI; all data are synthetic and temporary.

Set MICROBIOME_RSCRIPT to an existing Rscript when it is not on PATH.
No package installation or project data access occurs.
"""
import csv
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

SCRIPT = Path(__file__).with_name('plot_table_base.R')
RSCRIPT = os.environ.get('MICROBIOME_RSCRIPT') or shutil.which('Rscript')


@unittest.skipUnless(RSCRIPT, 'Rscript unavailable: set MICROBIOME_RSCRIPT')
class TablePlots(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='microbiome-plot-test-')
        self.root = Path(self.temp.name)
        (self.root / 'inputs').mkdir()
        (self.root / 'outputs').mkdir()
        self.output = self.root / 'outputs' / 'plot'

    def tearDown(self):
        self.temp.cleanup()

    def run_plot(self, kind, table, extra=(), dataset='synthetic'):
        source = self.root / 'inputs' / 'values.tsv'
        source.write_text(table, encoding='utf-8')
        cmd = [RSCRIPT, '--vanilla', str(SCRIPT), '--kind', kind,
               '--input', str(source), '--output', str(self.output),
               '--title', 'Synthetic contract test', '--dataset-kind', dataset,
               '--source-note', 'Synthetic fixture; no biological inference',
               '--x-label', 'Supplied x', '--y-label', '-log10(adjusted q-value)', *extra]
        result = subprocess.run(cmd, text=True, capture_output=True, timeout=30)
        return result, source

    def reject(self, kind, table, reason, extra=(), dataset='synthetic'):
        result, _ = self.run_plot(kind, table, extra, dataset)
        self.assertEqual(result.returncode, 2, result.stderr)
        self.assertIn(reason, result.stderr)
        self.assertFalse(self.output.exists(), 'Invalid input created output')

    def test_duplicate_identity(self):
        self.reject('alpha', 'sample_id\tgroup\tmetric\tvalue\nA\tC\tShannon\t1\nA\tC\tShannon\t2\n', 'Duplicate observational key')

    def test_sample_group_conflict(self):
        self.reject('growth', 'sample_id\tgroup\ttime\tvalue\nA\tC\t0\t1\nA\tL\t1\t2\n', 'multiple groups')

    def test_composition_not_renormalized(self):
        self.reject('composition', 'sample_id\tgroup\tfeature\tvalue\nA\tC\tf1\t0.4\nA\tC\tf2\t0.4\n', 'sum to 1')

    def test_missing_composition_not_zero(self):
        self.reject('composition', 'sample_id\tgroup\tfeature\tvalue\nA\tC\tf1\t1\nB\tC\tf2\t1\n', 'explicit zero rows')

    def test_zero_qvalue_not_fabricated(self):
        self.reject('volcano', 'feature\teffect\tqvalue\nf1\t1\t0\n', 'qvalue must', ['--q-threshold', '.05'])

    def test_interval_must_contain_effect(self):
        self.reject('forest', 'feature\teffect\tlower\tupper\nf1\t2\t0\t1\n', 'within supplied interval', ['--reference', '0'])

    def test_read_depth_bounds(self):
        self.reject('rarefaction', 'sample_id\tgroup\tdepth\trichness\nA\tC\t1\t2\n', 'richness <= depth')

    def test_biological_requires_source(self):
        self.reject('alpha', 'sample_id\tgroup\tmetric\tvalue\nA\tC\tShannon\t1\n', 'source-evidence', dataset='biological')

    def test_malformed_row(self):
        self.reject('alpha', 'sample_id\tgroup\tmetric\tvalue\nA\tC\tShannon\n', 'Malformed')

    def test_nonfinite_value(self):
        self.reject('heatmap', 'sample_id\tfeature\tvalue\nA\tf1\tInf\n', 'Nonfinite')

    def test_overwrite_rejected(self):
        self.output.mkdir()
        sentinel = self.output / 'figure.pdf'
        sentinel.write_bytes(b'keep-existing')
        result, _ = self.run_plot('alpha', 'sample_id\tgroup\tmetric\tvalue\nA\tC\tShannon\t1\n')
        self.assertEqual(result.returncode, 2)
        self.assertEqual(sentinel.read_bytes(), b'keep-existing')

    def test_dangling_symlink_rejected(self):
        self.output.symlink_to(self.root / 'absent', target_is_directory=True)
        result, _ = self.run_plot('alpha', 'sample_id\tgroup\tmetric\tvalue\nA\tC\tShannon\t1\n')
        self.assertEqual(result.returncode, 2)
        self.assertTrue(self.output.is_symlink())
        self.assertFalse((self.root / 'absent').exists())

    def test_heatmap_zero_missing_distinct_and_hashed(self):
        result, source = self.run_plot('heatmap', 'sample_id\tfeature\tvalue\nA\tf1\t0\nB\tf1\tNA\nA\tf2\t2\nB\tf2\t3\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        with (self.output / 'plotted_values.tsv').open() as f:
            rows = list(csv.DictReader(f, delimiter='\t'))
        self.assertEqual([r['value'] for r in rows], ['0', 'NA', '2', '3'])
        with (self.output / 'manifest.tsv').open() as f:
            manifest = {r['key']: r['value'] for r in csv.DictReader(f, delimiter='\t')}
        self.assertEqual(manifest['status'], 'preview')
        self.assertEqual(manifest['source_sha256'], hashlib.sha256(source.read_bytes()).hexdigest())
        for ext, signature in [('pdf', b'%PDF'), ('png', b'\x89PNG')]:
            data = (self.output / ('figure.' + ext)).read_bytes()
            self.assertTrue(data.startswith(signature))
            self.assertEqual(manifest['output_sha256.figure.' + ext], hashlib.sha256(data).hexdigest())
        self.assertIn('<svg', (self.output / 'figure.svg').read_text())

    def test_single_constant_heatmap(self):
        result, _ = self.run_plot('heatmap', 'sample_id\tfeature\tvalue\nA\tf1\t0\n')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertTrue((self.output / 'figure.pdf').exists())


if __name__ == '__main__':
    unittest.main(verbosity=2)
