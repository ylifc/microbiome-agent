#!/usr/bin/env Rscript
# WGCNA helper: preflight is base R only; powers/fit require an existing WGCNA.
# Never installs packages. Every network is exploratory pending independent validation.
options(stringsAsFactors = FALSE, warn = 1)
fail <- function(x) stop(x, call. = FALSE)
args <- commandArgs(trailingOnly = TRUE)
if (!length(args) || "--help" %in% args) {
  cat(paste(
    "Usage: Rscript wgcna_analysis.R --mode preflight|powers|fit",
    " --matrix samples_x_genes.tsv --metadata metadata.tsv --out NEW_DIR",
    " --assay dna|rna --unit TPM|normalized_counts|VST|log_abundance|CLR",
    " --transform log2p1|none --preprocessing-note TEXT --independent-unit cage_id",
    " --dataset-kind biological|synthetic [--group group] [--continuous-traits age,weight]",
    " [--min-abundance 0] [--min-prevalence 0.2] [--min-variance 0]",
    " [--threads 1] [--memory-gb 4] [--max-block-size 2000]",
    " [--min-module-size 30] [--merge-cut-height 0.25] [--seed 20261014]",
    " [--powers 1,2,3,4,5,6,8,10,12,16,20,24,28]",
    " [--exploratory-low-n true --exploratory-reason TEXT]",
    "fit additionally: --power NUMBER --powers-run POWERS_DIR --power-review FILE",
    " [--stability none|loo]  # loo explicitly refits n networks; potentially expensive",
    "Matrix first column must be sample_id; remaining columns are unique gene IDs.",
    "Metadata requires sample_id, the independent-unit column, and group (categorical).",
    "TPM/normalized_counts require log2p1; VST/log_abundance/CLR require none.",
    "Preflight does not infer a network; n<15 blocks powers/fit unless explicitly exploratory.",
    "Raw counts are not accepted; prepare normalized data with recorded provenance first.",
    sep = "\n"), "\n")
  quit(status = 0)
}
if (length(args) %% 2 || any(!grepl("^--", args[seq(1, length(args), 2)]))) fail("Use --key VALUE pairs.")
keys <- sub("^--", "", args[seq(1, length(args), 2)])
if (anyDuplicated(keys)) fail("Duplicate option.")
a <- as.list(args[seq(2, length(args), 2)]); names(a) <- keys
allowed <- c("mode", "matrix", "metadata", "out", "assay", "unit", "transform", "preprocessing-note", "independent-unit", "dataset-kind", "group", "continuous-traits", "min-abundance", "min-prevalence", "min-variance", "threads", "memory-gb", "max-block-size", "min-module-size", "merge-cut-height", "seed", "powers", "exploratory-low-n", "exploratory-reason", "power", "powers-run", "power-review", "stability")
if (length(setdiff(keys, allowed))) fail(paste("Unknown options:", paste(setdiff(keys, allowed), collapse=", ")))
get <- function(k, default = NULL) { x <- a[[k]]; if (is.null(x)) default else x }
req <- function(k) { x <- get(k); if (is.null(x) || !nzchar(x)) fail(paste("Missing --", k, sep="")); x }
choice <- function(k, vals, default=NULL) { x <- get(k, default); if (is.null(x) || !(x %in% vals)) fail(paste(k, "must be", paste(vals, collapse="|"))); x }
num <- function(k, default, lo=-Inf, hi=Inf, integer=FALSE) { v <- suppressWarnings(as.numeric(get(k, default))); if (length(v)!=1 || !is.finite(v) || v<lo || v>hi || (integer && v!=round(v))) fail(paste("Invalid", k)); v }
mode <- choice("mode", c("preflight","powers","fit"))
assay <- choice("assay", c("dna","rna")); unit <- choice("unit", c("TPM","normalized_counts","VST","log_abundance","CLR"))
transform <- choice("transform", c("log2p1","none")); kind <- choice("dataset-kind", c("biological","synthetic"))
if ((unit %in% c("TPM","normalized_counts")) != (transform == "log2p1")) fail("TPM/normalized_counts require log2p1; already transformed units require none.")
note <- req("preprocessing-note"); independent <- req("independent-unit"); group <- get("group","group")
low_n <- choice("exploratory-low-n", c("true","false"), "false") == "true"
if (low_n && !nzchar(get("exploratory-reason",""))) fail("Exploratory override requires --exploratory-reason.")
stability <- choice("stability", c("none","loo"), "none")
threads <- num("threads",1,1,integer=TRUE); memory <- num("memory-gb",4,0.1)
maxblock <- num("max-block-size",2000,50,integer=TRUE); minmodule <- num("min-module-size",30,5,integer=TRUE)
merge <- num("merge-cut-height",0.25,0,1); seed <- num("seed",20261014,0,.Machine$integer.max,TRUE)
minab <- num("min-abundance",0,0); prev <- num("min-prevalence",0.2,0,1); minvar <- num("min-variance",0,0)
if (transform == "none" && ("min-abundance" %in% keys || "min-prevalence" %in% keys)) fail("Apply abundance/prevalence filters before VST/log/CLR and record them in preprocessing-note; transformed values cannot be treated as abundances.")
powers <- suppressWarnings(as.numeric(strsplit(get("powers","1,2,3,4,5,6,8,10,12,16,20,24,28"),",",fixed=TRUE)[[1]]))
if (!length(powers) || any(!is.finite(powers) | powers <= 0) || anyDuplicated(powers)) fail("Invalid powers.")
mp <- normalizePath(req("matrix"), mustWork=TRUE); mt <- normalizePath(req("metadata"), mustWork=TRUE)
out <- req("out"); if (file.exists(out)) fail("Output must be a new directory; no overwrite.")
read_tsv <- function(p) read.delim(p, check.names=FALSE, colClasses="character", na.strings=c("NA",""), quote="", comment.char="")
x <- read_tsv(mp); meta <- read_tsv(mt)
check_ids <- function(v, label) { if (anyNA(v) || any(!nzchar(as.character(v))) || any(trimws(as.character(v)) != as.character(v)) || anyDuplicated(v)) fail(paste(label,"must be unique and nonempty.")) }
if (names(x)[1] != "sample_id" || ncol(x)<3) fail("Matrix requires sample_id followed by at least two genes.")
check_ids(names(x),"Matrix column IDs"); check_ids(x$sample_id,"Matrix sample_id")
if (!all(c("sample_id",independent,group) %in% names(meta))) fail("Metadata missing sample_id/independent-unit/group.")
check_ids(names(meta),"Metadata columns"); check_ids(meta$sample_id,"Metadata sample_id"); check_ids(meta[[independent]],"Independent units")
if (!setequal(x$sample_id,meta$sample_id)) fail("Exact sample identity join failed; no intersection or silent sample removal is allowed.")
meta <- meta[match(x$sample_id,meta$sample_id),,drop=FALSE]
if (anyNA(meta[[group]]) || any(!nzchar(as.character(meta[[group]]))) || any(trimws(meta[[group]]) != meta[[group]])) fail("Group values must be present.")
if (length(unique(meta[[group]]))<2) fail("At least two categorical groups required.")
numeric_column <- function(v, label) {
  z <- suppressWarnings(as.numeric(v))
  if(any(!is.na(v) & is.na(z))) fail(paste(label,"must be numeric; malformed text is not missing abundance."))
  z
}
raw <- vapply(names(x)[-1],function(g) numeric_column(x[[g]],paste("Gene",g)),numeric(nrow(x)))
rownames(raw) <- x$sample_id
if (any(is.infinite(raw))) fail("Infinite matrix value.")
if (transform=="log2p1" && any(raw<0,na.rm=TRUE)) fail("Abundances cannot be negative.")
if (nrow(raw)<4) fail("Fewer than four independent samples cannot support this helper.")
missing <- colSums(is.na(raw)); prevalence <- if(transform=="log2p1") colMeans(raw>minab,na.rm=TRUE) else rep(NA_real_,ncol(raw))
y <- if(transform=="log2p1") log2(raw+1) else raw
variance <- apply(y,2,var,na.rm=TRUE); mads <- apply(y,2,mad,na.rm=TRUE)
keep <- missing==0 & is.finite(variance) & variance>minvar & is.finite(mads) & mads>0
if(transform=="log2p1") keep <- keep & is.finite(prevalence) & prevalence>=prev
filter <- data.frame(gene_id=colnames(raw),missing_n=missing,prevalence=prevalence,transformed_variance=variance,transformed_MAD=mads,retained=keep)
dat <- as.data.frame(y[,keep,drop=FALSE],check.names=FALSE)
if (ncol(dat)<2) fail("Fewer than two genes remain after group-blind abundance/variance/MAD/complete-case filtering.")
traits <- model.matrix(~factor(meta[[group]])-1)
colnames(traits) <- paste0(group,"=",levels(factor(meta[[group]]))); rownames(traits) <- rownames(dat)
continuous <- get("continuous-traits","")
if (nzchar(continuous)) {
  continuous <- strsplit(continuous,",",fixed=TRUE)[[1]]
  if (anyDuplicated(continuous) || any(!continuous %in% names(meta)) || group %in% continuous) fail("Invalid continuous traits; categorical group cannot be encoded as continuous.")
  for (cn in continuous) {
    v <- numeric_column(meta[[cn]],paste("Continuous trait",cn))
    if (!is.numeric(v) || any(!is.finite(v)) || sd(v)==0) fail(paste("Continuous trait must be finite, numeric and variable:",cn))
    traits <- cbind(traits,v); colnames(traits)[ncol(traits)] <- cn
  }
}
if (anyDuplicated(colnames(traits))) fail("Trait names collide.")
n <- nrow(dat); b <- min(ncol(dat),maxblock)
input_full_dense_gib <- 8*ncol(raw)^2/1024^3
full_dense_gib <- 8*ncol(dat)^2/1024^3
single_dense_gib <- 8*b*b/1024^3
# Screening allowance, not an observed peak-memory guarantee.
working_gib <- 6*single_dense_gib + 3*8*n*ncol(dat)/1024^3
status <- if(n<15 && !low_n) "DESCRIPTIVE_ONLY_LOW_N" else if(n<15) "EXPLORATORY_LOW_N_UNVALIDATED" else "EXPLORATORY_UNVALIDATED"
dependency <- requireNamespace("WGCNA",quietly=TRUE)
params <- list(assay=assay,unit=unit,transform=transform,preprocessing_note=note,independent_unit=independent,group=group,continuous_traits=continuous,min_abundance=minab,min_prevalence=prev,min_variance=minvar,complete_case_genes=TRUE,MAD_positive=TRUE,network_type="signed",TOM_type="signed",correlation="bicor",maxPOutliers=0.05,pearsonFallback="individual",threads=threads,memory_gb=memory,max_block_size=maxblock,min_module_size=minmodule,merge_cut_height=merge,seed=seed,powers=powers,low_n_override=low_n,low_n_reason=get("exploratory-reason",""),dataset_kind=kind)
script_arg <- grep("^--file=",commandArgs(FALSE),value=TRUE)
script_path <- if(length(script_arg)) normalizePath(sub("^--file=","",script_arg[1]),mustWork=TRUE) else NA_character_
contract <- list(inputs_md5=tools::md5sum(c(mp,mt)),script_md5=if(!is.na(script_path)) tools::md5sum(script_path) else NA,params=params,samples=rownames(dat),genes=colnames(dat))
dir.create(out,recursive=TRUE); out <- normalizePath(out,mustWork=TRUE)
write_tsv <- function(z,f) write.table(z,file.path(out,f),sep="\t",quote=FALSE,row.names=FALSE,na="NA")
write_tsv(filter,"feature_filter.tsv"); write_tsv(meta,"metadata_joined.tsv")
write_tsv(data.frame(sample_id=rownames(traits),traits,check.names=FALSE),"traits.tsv")
write_tsv(data.frame(sample_id=rownames(dat),dat,check.names=FALSE),"matrix_used.tsv")
writeLines(c(paste("status",status,sep="\t"),paste("mode",mode,sep="\t"),paste("independent_samples",n,sep="\t"),paste("genes_input",ncol(raw),sep="\t"),paste("genes_retained",ncol(dat),sep="\t"),paste("WGCNA_installed",dependency,sep="\t"),paste("input_full_single_dense_GiB",input_full_dense_gib,sep="\t"),paste("retained_full_single_dense_GiB",full_dense_gib,sep="\t"),paste("block_single_dense_GiB",single_dense_gib,sep="\t"),paste("screening_working_GiB_not_peak_guarantee",working_gib,sep="\t"),paste("network_label",if(assay=="dna") "DNA_gene_coabundance_not_expression" else "RNA_gene_coexpression",sep="\t"),"fdr_family\tall_non_grey_modules_x_all_declared_traits", "acceptance\tNOT_SCIENTIFICALLY_OR_VISUALLY_ACCEPTED"),file.path(out,"preflight.tsv"))
saveRDS(contract,file.path(out,"contract.rds")); dput(params,file=file.path(out,"parameters.R"))
capture.output(sessionInfo(),file=file.path(out,"sessionInfo.txt"))
writeLines(c("Each row is one independent sampling unit; gene/contig/MAG rows are not sample replicates.","DNA networks describe abundance covariation, not coexpression, interaction, regulation or causal hubs.","WGCNA statistical modules are not KEGG biochemical MODULEs; link them by separately tested enrichment.","Gene filtering is group-blind; omitted genes and complete-case policy are recorded in feature_filter.tsv.","Same-contig/copy/taxonomic abundance and compositional closure can drive edges.","Power choice, module stability and independent-cohort validation remain separate evidence.",if(n<15) "Fewer than 15 independent samples: descriptive default; explicit override never makes a reliable network." else if(n<20) "15-19 independent samples: limited stability; independent validation needed." else "Sample count alone does not certify network validity.",if(kind=="synthetic") "SYNTHETIC TEST DATA: not a biological result." else "Biological data remain unvalidated."),file.path(out,"limitations.txt"))
stamp <- if(kind=="synthetic") "SYNTHETIC | PREVIEW" else "PREVIEW"
plots <- function(name,fun,w=11,h=7) {
  for (ext in c("pdf","svg","png")) {
    p <- file.path(out,paste0(name,".",ext))
    if(ext=="pdf") pdf(p,width=w,height=h) else if(ext=="svg") svg(p,width=w,height=h) else png(p,width=w,height=h,units="in",res=140)
    set.seed(seed)
    par(oma=c(0,0,4,0))
    tryCatch({
      fun()
      mtext(stamp,side=3,outer=TRUE,line=2.1,cex=0.9,font=2)
      mtext(status,side=3,outer=TRUE,line=0.8,cex=0.85)
    },finally=dev.off())
  }
}
plots("sample_qc",function(){ par(mfrow=c(1,2),mar=c(5,4,4,1)); plot(hclust(dist(dat)),main="Sample clustering",xlab="Independent sample IDs",sub="Euclidean distance on recorded transformed matrix",cex=0.65); hist(log10(variance[is.finite(variance)&variance>0]),main="Gene variance before filtering",xlab="log10(transformed variance)") })
finalize <- function(completion) {
  writeLines(c(paste("stage",completion,sep="\t"),paste("status",status,sep="\t"),"visual_QA\tPENDING_ACTUAL_INSPECTION", "independent_validation\tNOT_PERFORMED"),file.path(out,"completion.tsv"))
  fs <- list.files(out,full.names=TRUE,recursive=TRUE); fs <- fs[!dir.exists(fs)]
  write_tsv(data.frame(path=substring(fs,nchar(out)+2),md5=unname(tools::md5sum(fs))),"file_manifest_md5.tsv")
}
if (mode=="preflight") { finalize("PREFLIGHT_ONLY_NO_NETWORK"); cat("Preflight written:",out,"\n",status,"\n"); quit(status=0) }
if(n<15 && !low_n) { finalize("BLOCKED_LOW_SAMPLE_SIZE"); fail("n<15: powers/fit blocked. Prefer descriptive figures. Explicit exploratory override with rationale required.") }
if(!dependency) { finalize("BLOCKED_MISSING_WGCNA"); fail("WGCNA is not installed in this R runtime. No installation attempted; powers/fit have not run.") }
if (working_gib>memory) { finalize("BLOCKED_MEMORY_SCREEN"); fail("Estimated working matrices exceed memory budget. Reduce max-block-size after documenting the tradeoff.") }
if (ncol(dat)<minmodule) { finalize("BLOCKED_TOO_FEW_GENES"); fail("Retained genes fewer than min-module-size.") }
# Also constrain BLAS in the launching shell; changing these after R startup may not reconfigure loaded BLAS.
Sys.setenv(OMP_NUM_THREADS=as.character(threads),OPENBLAS_NUM_THREADS="1",MKL_NUM_THREADS="1")
if(threads==1) WGCNA::disableWGCNAThreads() else WGCNA::enableWGCNAThreads(nThreads=threads)
gsg <- WGCNA::goodSamplesGenes(dat,verbose=0)
if(!gsg$allOK) { finalize("BLOCKED_WGCNA_QC"); fail("WGCNA goodSamplesGenes failed; inspect rather than silently dropping samples/genes.") }
if (mode=="powers") {
  pst <- WGCNA::pickSoftThreshold(dat,powerVector=powers,networkType="signed",corFnc=WGCNA::bicor,corOptions=list(use="pairwise.complete.obs",maxPOutliers=0.05,pearsonFallback="individual"),blockSize=min(maxblock,ncol(dat)),moreNetworkConcepts=TRUE,verbose=2)
  write_tsv(pst$fitIndices,"power_diagnostics.tsv"); saveRDS(list(contract=contract,diagnostics=pst),file.path(out,"power_diagnostics.rds"))
  plots("power_diagnostics",function(){ par(mfrow=c(1,3),mar=c(4,4,4,1)); z <- pst$fitIndices; plot(z$Power,-sign(z$slope)*z$SFT.R.sq,type="b",xlab="Power",ylab="Signed scale-free fit",main="Inspect fit and slope"); plot(z$Power,z$mean.k.,type="b",xlab="Power",ylab="Mean connectivity",main="Retained connectivity"); plot(z$Power,z$slope,type="b",xlab="Power",ylab="Slope",main="Degree fit slope") },w=16,h=5)
  finalize("POWERS_ONLY_REVIEW_REQUIRED_NO_NETWORK_FIT"); quit(status=0)
}
power <- num("power",NA,0.1); powers_run <- normalizePath(req("powers-run"),mustWork=TRUE); review <- normalizePath(req("power-review"),mustWork=TRUE)
pr <- readRDS(file.path(powers_run,"power_diagnostics.rds"))
if (!identical(pr$contract,contract)) fail("Power diagnostics input/script/parameter contract differs; regenerate diagnostics for this exact design.")
if (!(power %in% pr$diagnostics$fitIndices$Power)) fail("Chosen power absent from reviewed diagnostics.")
if (file.info(review)$size<20) fail("Power review must record the fit/connectivity tradeoff and selection rationale.")
file.copy(review,file.path(out,"power_selection_review.txt"),overwrite=FALSE)
write_tsv(data.frame(selected_power=power,review_path=review,review_md5=unname(tools::md5sum(review))),"power_selection.tsv")
fit <- function(z) WGCNA::blockwiseModules(z,power=power,maxBlockSize=maxblock,networkType="signed",TOMType="signed",corType="bicor",maxPOutliers=0.05,pearsonFallback="individual",minModuleSize=minmodule,mergeCutHeight=merge,numericLabels=TRUE,randomSeed=seed,nThreads=threads,saveTOMs=FALSE,loadTOM=FALSE,verbose=2)
net <- fit(dat); saveRDS(net,file.path(out,"network.rds"))
colors <- WGCNA::labels2colors(net$colors); names(colors) <- colnames(dat)
mes <- WGCNA::orderMEs(net$MEs); rownames(mes) <- rownames(dat)
write_tsv(data.frame(sample_id=rownames(mes),mes,check.names=FALSE),"module_eigengenes.tsv")
write_tsv(data.frame(gene_id=colnames(dat),wgcna_module=net$colors,module_color=colors),"gene_modules.tsv")
# Eigengene orientation is arbitrary; kME is signed membership, not a causal score.
kme <- WGCNA::bicor(as.matrix(dat),as.matrix(mes),maxPOutliers=0.05,pearsonFallback="individual",use="all.obs")
write_tsv(data.frame(gene_id=colnames(dat),kme,check.names=FALSE),"gene_kME_all_modules.tsv")
for(i in seq_along(net$dendrograms)) local({ j<-i; plots(paste0("module_dendrogram_block_",j),function(){ WGCNA::plotDendroAndColors(net$dendrograms[[j]],colors[net$blockGenes[[j]]],"WGCNA module",dendroLabels=FALSE,hang=0.03,addGuide=TRUE,guideHang=0.05,main=paste("Gene clustering; block",j)) }) })
valid <- setdiff(colnames(mes),"ME0")
if(length(valid)) {
  mtcor <- WGCNA::bicorAndPvalue(as.matrix(mes[,valid,drop=FALSE]),traits,robustY=FALSE,maxPOutliers=0.05,pearsonFallback="individual",use="all.obs")
  mtlong <- expand.grid(module=valid,trait=colnames(traits),stringsAsFactors=FALSE)
  mtlong$r <- as.vector(mtcor$bicor); mtlong$n <- as.vector(mtcor$nObs)
  mtlong$p_approx <- if(n<15) NA_real_ else as.vector(mtcor$p)
  # Fixed family: all non-grey module x all declared trait tests, no pre-selection.
  mtlong$q_BH <- if(n<15) NA_real_ else p.adjust(mtlong$p_approx,method="BH")
  mtlong$family <- "all_non_grey_modules_x_all_declared_traits"
  write_tsv(mtlong,"module_trait_associations.tsv")
  plots("module_trait_heatmap",function(){ WGCNA::labeledHeatmap(Matrix=mtcor$bicor,xLabels=colnames(traits),yLabels=valid,ySymbols=valid,colorLabels=FALSE,colors=WGCNA::blueWhiteRed(50),textMatrix=matrix(sprintf("%.2f",mtcor$bicor),nrow=length(valid)),setStdMargins=FALSE,cex.text=0.65,zlim=c(-1,1),main="Module-trait correlations; BH results in TSV"); },w=max(10,ncol(traits)*1.3),h=max(6,length(valid)*.35))
  for (m in valid) local({ mm <- m; plots(paste0("eigengene_",mm),function(){ boxplot(mes[[mm]]~factor(meta[[group]]),outline=FALSE,xlab=paste(group,"(categorical)"),ylab=paste(mm,"arbitrary sign"),main="Independent sample eigengenes"); stripchart(mes[[mm]]~factor(meta[[group]]),vertical=TRUE,method="jitter",add=TRUE,pch=19,col="navy") }) })
}
if(stability=="loo") {
  # Compare by shared-gene Jaccard rather than colour names, which can permute.
  rows <- list(); k<-0
  for(i in seq_len(n)) {
    reduced <- dat[-i,,drop=FALSE]
    # Avoid an unexplained algorithmic failure after omission; report unavailable sensitivity.
    g <- WGCNA::goodSamplesGenes(reduced,verbose=0)
    if(!g$allOK) { k<-k+1; rows[[k]]<-data.frame(omitted_sample=rownames(dat)[i],module=NA,best_matching_loo_module=NA,jaccard=NA,status="QC_FAILED_NO_SILENT_FILTER"); next }
    nf <- tryCatch(fit(reduced),error=function(e)e)
    if(inherits(nf,"error")) { k<-k+1; rows[[k]]<-data.frame(omitted_sample=rownames(dat)[i],module=NA,best_matching_loo_module=NA,jaccard=NA,status=paste("FIT_FAILED",conditionMessage(nf))); next }
    for(m in setdiff(unique(net$colors),0)) {
      aa <- which(net$colors==m); candidates <- setdiff(unique(nf$colors),0)
      js <- vapply(candidates,function(c){bb<-which(nf$colors==c); length(intersect(aa,bb))/length(union(aa,bb))},numeric(1))
      k<-k+1; rows[[k]] <- data.frame(omitted_sample=rownames(dat)[i],module=m,best_matching_loo_module=if(length(js)) candidates[which.max(js)] else NA,jaccard=if(length(js)) max(js) else 0,status="SENSITIVITY_NOT_INDEPENDENT_VALIDATION")
    }
  }
  if(length(rows)) write_tsv(do.call(rbind,rows),"loo_module_best_jaccard.tsv")
  writeLines("LOO refits use the same input gene set, chosen power and parameters. Best-match Jaccard is descriptive and asymmetric; splits/merges can occur. LOO reuses the discovery cohort and is NOT independent validation.",file.path(out,"loo_limitations.txt"))
} else writeLines("Not run. Plan independent-unit resampling/module preservation and an external cohort before biological module or hub claims.",file.path(out,"stability_pending.txt"))
capture.output(sessionInfo(),file=file.path(out,"sessionInfo.txt"))
finalize("NETWORK_FIT_EXPLORATORY_VALIDATION_PENDING")
cat("Exploratory outputs:",out,"\n")
