#!/usr/bin/env python3
"""Focused functional invariants using synthetic data; never project analysis."""
import argparse
import csv
import json
import pathlib
import subprocess
import sys
import tempfile

HERE = pathlib.Path(__file__).resolve().parent


def table(path, columns, rows):
    with path.open("w", newline="") as f:
        writer = csv.writer(f, delimiter="\t", lineterminator="\n")
        writer.writerow(columns)
        writer.writerows(rows)


def read(path):
    with path.open() as f:
        return list(csv.DictReader(f, delimiter="\t"))


def run(out, rscript):
    out.mkdir(parents=True, exist_ok=False)
    fixture = out / "synthetic_inputs"
    fixture.mkdir()
    paths = {key: fixture / (key + ".tsv") for key in ["genes", "samples", "quant", "annotations", "members", "coordinates", "contigs", "family_quant"]}
    table(paths["genes"], ["gene_id"], [["g1"], ["g2"], ["g3"], ["g4"]])
    table(paths["samples"], ["sample_id"], [["S1"], ["S2"], ["S3"]])
    qrows = [["g1","S1",10],["g1","S2",0],["g2","S1",20],["g2","S2","NA"],["g3","S1",0],["g3","S2",30],["g4","S1",5],["g4","S2",5]]
    table(paths["quant"], ["gene_id","sample_id","value"], qrows)
    table(paths["annotations"], ["gene_id","database","feature_id"], [["g1","KEGG_KO","K00001"],["g1","KEGG_KO","K00002"],["g1","KEGG_KO","K00001"],["g2","KEGG_KO","K00002"],["g3","COG","COG0001"]])
    table(paths["members"], ["database","feature_id","target_database","target_id","target_kind"], [["KEGG_KO","K00001","KEGG_MODULE","M00001","module"],["KEGG_KO","K00002","KEGG_MODULE","M00001","module"],["KEGG_KO","K00002","KEGG_MODULE","M00002","module"],["KEGG_KO","K99999","KEGG_MODULE","M99999","module"]])
    table(paths["coordinates"], ["gene_id","contig_id","start","end","strand","feature_id","representative_gene_id"], [["g1","ctg1",100,500,"+","K00001","g1"],["g2","ctg1",350,850,"-","K00002","g1"],["g3","ctg1",1200,1600,".","COG0001","g3"],["g4","ctg1",2000,2800,"+","Unannotated","g4"]])
    table(paths["contigs"], ["contig_id","length"], [["ctg1",3000]])
    table(paths["family_quant"], ["gene_id","sample_id","value"], [r for r in qrows if r[0] != "g2"])
    evidence = fixture / "provenance.json"
    evidence.write_text(json.dumps({"dataset_kind":"synthetic", "note":"Synthetic tool validation; invented features/values, not biological evidence."}))
    checks = []
    def check(name, condition):
        checks.append({"name":name,"passed":bool(condition)})
        if not condition:
            raise AssertionError(name)
    base = [sys.executable, str(HERE / "aggregate_gene_functions.py")]
    for key in ["genes","samples","quant","annotations","members"]:
        base += ["--"+key, str(paths[key])]
    base += ["--unit","DNA_TPM","--gene-scope","locus","--source-evidence",str(evidence),"--source-note","Synthetic validation only","--dataset-kind","synthetic","--write-contributions"]
    for policy in ["full_membership","fractional"]:
        target = out / policy
        completed = subprocess.run(base + ["--multimap",policy,"--out",str(target)], text=True,capture_output=True)
        check(policy+" exits successfully", completed.returncode == 0)
        rows = read(target / "functional_abundance.tsv")
        def get(db, feature, sample):
            return next(r for r in rows if (r["database"],r["feature_id"],r["sample_id"]) == (db,feature,sample))
        check(policy+" shared KO-to-module routes count unique gene once", float(get("KEGG_MODULE","M00001","S1")["value"]) == (30 if policy == "full_membership" else 15))
        check(policy+" preserves unannotated denominator", float(get("KEGG_KO","__UNANNOTATED__","S1")["value"]) == 5)
        check(policy+" measured zero remains zero", get("KEGG_KO","K00001","S2")["value"] == "0.0")
        check(policy+" explicit missing propagates", get("KEGG_KO","K00002","S2")["value"] == "NA")
        check(policy+" absent sample retained as missing", get("KEGG_KO","K00001","S3")["status"] == "incomplete")
        check(policy+" unmatched catalog target is not biological zero", get("KEGG_MODULE","M99999","S1")["status"] == "no_catalog_members")
        den = next(r for r in read(target / "sample_denominators.tsv") if r["database"] == "KEGG_KO" and r["sample_id"] == "S1")
        check(policy+" total remains full catalog", float(den["catalog_total"]) == 35)
        check(policy+" membership conservation/duplication explicit", float(den["weighted_membership_observed_total"]) == (45 if policy == "full_membership" else 35))
        manifest = json.loads((target/"manifest.json").read_text())
        check(policy+" duplicate evidence collapsed with diagnostic", manifest["diagnostics"]["duplicate_annotation_rows_collapsed"] == 1)
    negative = [("duplicate", qrows + [["g1","S1",10]]), ("negative", [["g1","S1",-1]]), ("infinity", [["g1","S1","Inf"]]), ("unknown_gene", [["unknown","S1",1]]), ("unknown_sample", [["g1","missing",1]])]
    for name, rows in negative:
        path = fixture / (name+".tsv"); table(path,["gene_id","sample_id","value"],rows)
        argv = base.copy(); argv[argv.index("--quant")+1] = str(path)
        result = subprocess.run(argv+["--multimap","fractional","--out",str(out/("rejected_"+name))],capture_output=True,text=True)
        check("reject "+name, result.returncode != 0)
        (out/(name+"_stderr.txt")).write_text(result.stderr)
    result = subprocess.run(base+["--multimap","fractional","--out",str(out/"rejected_limit"),"--max-output-rows","1"],capture_output=True,text=True)
    check("reject excessive projected output before writing",result.returncode!=0 and not (out/"rejected_limit").exists())
    if rscript:
        rbase=[rscript,str(HERE/"plot_contig_functions.R"),"--genes",str(paths["coordinates"]),"--contigs",str(paths["contigs"]),"--samples",str(paths["samples"]),"--contig","ctg1","--unit","DNA_TPM","--dataset-kind","synthetic","--source-evidence",str(evidence),"--source-note","Synthetic positions and quantities; no biological interpretation"]
        for scope,qpath in [("locus",paths["quant"]),("family_profile",paths["family_quant"])]:
            target=out/("contig_"+scope)
            result=subprocess.run(rbase+["--quant",str(qpath),"--quantity-scope",scope,"--out",str(target)],capture_output=True,text=True)
            (out/("R_"+scope+"_stdout.txt")).write_text(result.stdout)
            (out/("R_"+scope+"_stderr.txt")).write_text(result.stderr)
            check("R "+scope+" executes",result.returncode==0)
            for ext in ["svg","pdf","png"]:
                check("R "+scope+" creates "+ext,(target/("contig_functions."+ext)).stat().st_size>1000)
            values=read(target/"plotted_quantities.tsv")
            check("R "+scope+" keeps all 12 cells",len(values)==12)
            check("R "+scope+" retains missing sample",all(r["value"]=="NA" for r in values if r["sample_id"]=="S3"))
            if scope=="family_profile":
                check("R family repetition labelled and sourced",next(r for r in values if r["gene_id"]=="g2" and r["sample_id"]=="S1")["quantity_gene_id"]=="g1")
            else:
                check("R genomic overlap occupies separate lanes",len(set(r["lane"] for r in read(target/"plotted_genes.tsv")[:2]))==2)
        badcoords=fixture/"bad_coordinates.tsv"
        rows=read(paths["coordinates"]); rows[0]["start"]="0"
        table(badcoords,list(rows[0]),[list(r.values()) for r in rows])
        bad=rbase.copy();bad[bad.index("--genes")+1]=str(badcoords)
        result=subprocess.run(bad+["--quant",str(paths["quant"]),"--quantity-scope","locus","--out",str(out/"rejected_R_coords")],capture_output=True,text=True)
        check("R rejects zero-based/invalid coordinates",result.returncode!=0)
        longcoords=fixture/"long_coordinates.tsv"; longquant=fixture/"long_quant.tsv"
        rows=read(paths["coordinates"])
        long_gene="gene_"+"long_identity_"*12
        long_feature="KEGG_description_"+"long_function_"*10
        rows[0]["gene_id"]=long_gene;rows[0]["feature_id"]=long_feature
        table(longcoords,list(rows[0]),[list(r.values()) for r in rows])
        table(longquant,["gene_id","sample_id","value"],[[long_gene if r[0]=="g1" else r[0],r[1],r[2]] for r in qrows])
        longargs=rbase.copy();longargs[longargs.index("--genes")+1]=str(longcoords)
        result=subprocess.run(longargs+["--quant",str(longquant),"--quantity-scope","locus","--out",str(out/"contig_long_identity")],capture_output=True,text=True)
        check("R long identities render with index and full data",result.returncode==0)
        longrows=read(out/"contig_long_identity"/"plotted_genes.tsv")
        check("R long gene identity preserved without truncation",longrows[0]["gene_id"]==long_gene and "full ID" in longrows[0]["display_label"])
        longcolors=read(out/"contig_long_identity"/"feature_colors.tsv")
        check("R long feature identity preserved without truncation",any(r["feature_id"]==long_feature and "full ID" in r["display_label"] for r in longcolors))
    result={"dataset_kind":"synthetic","checks":checks,"passed":len(checks),"failed":0,"rscript":rscript,"visual_qa":"Requires actual image inspection; tests do not claim visual acceptance"}
    (out/"test_results.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result))


if __name__=="__main__":
    parser=argparse.ArgumentParser();parser.add_argument("--out",type=pathlib.Path,required=True);parser.add_argument("--rscript")
    a=parser.parse_args();run(a.out,a.rscript)
