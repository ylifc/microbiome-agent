#!/usr/bin/env Rscript
# File-only tree preview. No dependency installation, inference, rooting or pruning.
fail <- function(x) stop(x, call. = FALSE)
need <- function(x, message) if (!isTRUE(x)) fail(message)
usage <- function() cat(paste(
  "Usage: Rscript plot_phylogeny.R --tree TREE.nwk --metadata genomes.tsv --out NEW_DIR",
  "  --dataset-kind synthetic|biological --source-status synthetic_fixture|unverified|validated",
  "  --description TEXT --support-order SH-aLRT/UFBoot|SH-aLRT|UFBoot|bootstrap|none",
  "  [--evidence FILE] [--backend ape|ggtree]",
  "  [--layout rectangular|cladogram|fan|unrooted|circular]",
  "  [--labels ids|none] [--supports all|table] [--title TEXT]",
  "  [--width 16] [--height 10]",
  "R packages must already be installed. ape is required; ggtree also needs ggplot2.",
  "circular is ggtree-only. Large/long-label trees require explicit overview mode",
  "(--labels none --supports table), with complete indexes; use the Python renderer",
  "for 1000+ tip detail pages. Every output remains PREVIEW pending actual image QA.",
  "--check-runtime checks dependencies only. --help requires no extra R packages.", sep = "\n"), "\n")
parse_cli <- function(args) {
  if (identical(args, "--help") || !length(args)) { usage(); return(NULL) }
  if (identical(args, "--check-runtime")) return(list(check_runtime = TRUE))
  allowed <- c("tree", "metadata", "out", "dataset-kind", "source-status", "description",
               "support-order", "evidence", "backend", "layout", "labels", "supports", "title", "width", "height")
  need(length(args) %% 2L == 0L, "Options require separate --name value pairs")
  opt <- list(backend = "ape", layout = "rectangular", labels = "ids", supports = "all",
              title = "Phylogenetic tree", width = "16", height = "10")
  seen <- character()
  for (i in seq.int(1L, length(args), 2L)) {
    need(startsWith(args[i], "--"), "Expected --option")
    key <- substring(args[i], 3L)
    need(key %in% allowed && !(key %in% seen), paste("Unknown or duplicate option:", key))
    seen <- c(seen, key); opt[[key]] <- args[i + 1L]
  }
  required <- c("tree", "metadata", "out", "dataset-kind", "source-status", "description", "support-order")
  need(all(required %in% names(opt)), paste("Required:", paste(required, collapse = ", ")))
  need(opt$backend %in% c("ape", "ggtree"), "backend must be ape or ggtree")
  need(opt$layout %in% c("rectangular", "cladogram", "fan", "unrooted", "circular"), "Unsupported layout")
  need(opt$layout != "circular" || opt$backend == "ggtree", "circular requires backend ggtree; ape fan is a different layout")
  need(opt$labels %in% c("ids", "none") && opt$supports %in% c("all", "table"), "Invalid labels/supports option")
  need(opt[["support-order"]] %in% c("SH-aLRT/UFBoot", "SH-aLRT", "UFBoot", "bootstrap", "none"), "sCF/gCF are not bootstrap and require a separate split-audited view")
  need(opt[["dataset-kind"]] %in% c("synthetic", "biological"), "Explicit dataset kind required")
  need(opt[["source-status"]] %in% c("synthetic_fixture", "unverified", "validated"), "Invalid source status")
  need((opt[["dataset-kind"]] == "synthetic") == (opt[["source-status"]] == "synthetic_fixture"), "Dataset kind/status mismatch")
  need(nzchar(trimws(opt$description)), "Source description cannot be blank")
  if (opt[["dataset-kind"]] == "biological") need(!is.null(opt$evidence) && file.exists(opt$evidence), "Biological preview requires an existing evidence file; this does not certify that evidence")
  for (key in c("width", "height")) {
    v <- suppressWarnings(as.numeric(opt[[key]])); need(is.finite(v) && v >= 5 && v <= 30, "Device dimensions must be 5-30 inches")
    opt[[key]] <- v
  }
  opt
}
runtime <- function() {
  packages <- c("ape", "ggtree", "ggplot2", "treeio", "phytools", "ggtreeExtra")
  data.frame(package = packages, available = vapply(packages, requireNamespace, logical(1), quietly = TRUE),
    version = vapply(packages, function(p) if (requireNamespace(p, quietly = TRUE)) as.character(utils::packageVersion(p)) else "", character(1)), stringsAsFactors = FALSE)
}
sha256 <- function(path) {
  tool <- Sys.which("sha256sum"); need(nzchar(tool), "sha256sum is required for source provenance")
  answer <- system2(tool, shQuote(normalizePath(path, mustWork = TRUE)), stdout = TRUE, stderr = TRUE)
  need(is.null(attr(answer, "status")) && length(answer) == 1L && grepl("^[0-9a-f]{64} ", answer), "Unable to hash input")
  substring(answer, 1L, 64L)
}
exact_ids <- function(x) all(!is.na(x) & nzchar(x) & !grepl("[[:space:]]", x)) && !anyDuplicated(x)
write_tsv <- function(x, path) utils::write.table(x, path, sep = "\t", row.names = FALSE, quote = TRUE, na = "NA", fileEncoding = "UTF-8")
read_inputs <- function(opt) {
  need(file.exists(opt$tree) && file.exists(opt$metadata), "Tree and metadata must exist")
  tr <- ape::read.tree(opt$tree)
  need(inherits(tr, "phylo") && !inherits(tr, "multiPhylo"), "Exactly one tree required")
  need(length(tr$tip.label) >= 2 && exact_ids(tr$tip.label), "Unique exact non-whitespace tip IDs required")
  need(!is.null(tr$edge.length) && length(tr$edge.length) == nrow(tr$edge) && all(is.finite(tr$edge.length) & tr$edge.length >= 0), "Finite nonnegative native edge lengths required, even for cladogram view")
  meta <- utils::read.delim(opt$metadata, check.names = FALSE, colClasses = "character", na.strings = character(), quote = "", comment.char = "", strip.white = FALSE)
  need(!anyDuplicated(names(meta)) && all(c("genome_id", "sample_id", "group", "phylum", "species") %in% names(meta)), "Metadata columns required: genome_id sample_id group phylum species")
  need(exact_ids(meta$genome_id) && all(!is.na(meta$sample_id) & nzchar(meta$sample_id) & !grepl("[[:space:]]", meta$sample_id)), "Metadata identity is blank, duplicated or whitespace-containing")
  need(setequal(tr$tip.label, meta$genome_id) && nrow(meta) == length(tr$tip.label), "Exact tree/metadata leaf join failed")
  meta <- meta[match(tr$tip.label, meta$genome_id), , drop = FALSE]
  groups <- ifelse(nzchar(trimws(meta$group)), meta$group, "Unknown")
  need(all(vapply(split(groups, meta$sample_id), function(x) length(unique(x)) == 1L, logical(1))), "Sample assigned to inconsistent groups")
  raw <- if (is.null(tr$node.label)) rep("", tr$Nnode) else tr$node.label
  need(length(raw) == tr$Nnode && !anyNA(raw), "Malformed node labels")
  order <- opt[["support-order"]]; fields <- if (order == "none") character() else strsplit(order, "/", fixed = TRUE)[[1L]]
  if (order == "none") need(all(!nzchar(raw)), "Existing node labels require an explicit support-order; refusing silent loss")
  for (label in raw[nzchar(raw)]) {
    values <- strsplit(label, "/", fixed = TRUE)[[1L]]
    numeric <- suppressWarnings(as.numeric(values))
    need(length(values) == length(fields) && all(nzchar(values)) && all(is.finite(numeric) & numeric >= 0 & numeric <= 100), "Node label conflicts with declared support order/range; no sCF mixing")
  }
  need(opt$labels == "none" || (length(tr$tip.label) <= 80L && max(nchar(tr$tip.label)) <= 120L), "Use explicit --labels none for large/long-label overview; complete identities remain in index and Python detail renderer")
  need(opt$supports == "table" || length(tr$tip.label) <= 80L, "Use --supports table for large overview; no support text is silently suppressed")
  list(tree = tr, metadata = meta, groups = groups, raw = raw)
}
plot_ape <- function(data, opt, colors) {
  type <- switch(opt$layout, rectangular = "phylogram", cladogram = "phylogram", fan = "fan", unrooted = "unrooted")
  graphics::par(mar = c(4, 1, 5, 1))
  ape::plot.phylo(data$tree, type = type, use.edge.length = opt$layout != "cladogram",
    show.tip.label = opt$labels == "ids", show.node.label = FALSE,
    tip.color = unname(colors[data$groups]), font = 1, cex = 0.65, underscore = TRUE,
    open.angle = if (opt$layout == "fan") 60 else 0)
  if (opt$supports == "all" && any(nzchar(data$raw))) {
    take <- which(nzchar(data$raw))
    ape::nodelabels(text = data$raw[take], node = length(data$tree$tip.label) + take,
                   frame = "none", cex = 0.55, adj = c(1, -0.3))
  }
  graphics::title(main = opt$title, cex.main = 0.8)
  graphics::mtext(paste("PREVIEW |", opt[["dataset-kind"]], "|", opt[["source-status"]]), side = 3, line = 2.5, cex = 0.8)
  graphics::mtext(if (opt$layout == "cladogram") "Topology only: displayed lengths are not substitutions or time" else "Native branch lengths; source root is a drawing origin, not an inferred ancestor", side = 1, line = 2.4, cex = 0.7)
  graphics::mtext(paste("Support:", opt[["support-order"]], "| full identities and node values: TSV indexes"), side = 1, line = 3.2, cex = 0.65)
}
plot_ggtree <- function(data, opt, colors) {
  lay <- switch(opt$layout, cladogram = "rectangular", unrooted = "equal_angle", opt$layout)
  p <- ggtree::ggtree(data$tree, layout = lay, ladderize = FALSE,
    branch.length = if (opt$layout == "cladogram") "none" else "branch.length")
  if (opt$labels == "ids") p <- p + ggtree::geom_tiplab(size = 2.5)
  if (opt$supports == "all" && any(nzchar(data$raw))) {
    p$data$source_support <- data$raw[match(p$data$node, length(data$tree$tip.label) + seq_along(data$raw))]
    p <- p + ggtree::geom_text2(ggplot2::aes(subset = !isTip & !is.na(source_support) & nzchar(source_support), label = source_support), size = 2.1, hjust = -0.15)
  }
  p <- p + ggplot2::labs(title = opt$title, subtitle = paste("PREVIEW |", opt[["dataset-kind"]], "|", opt[["source-status"]]),
    caption = paste("Support order:", opt[["support-order"]], "; no rooting/inference. Full identity/support TSV indexes. ggtree backend uses plain tip labels."))
  print(p)
}
main <- function() {
  opt <- parse_cli(commandArgs(trailingOnly = TRUE)); if (is.null(opt)) return(invisible(0L))
  if (isTRUE(opt$check_runtime)) { cat(R.version.string, "\n"); print(runtime(), row.names = FALSE); return(invisible(0L)) }
  required <- if (opt$backend == "ape") "ape" else c("ape", "ggtree", "ggplot2")
  missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
  need(!length(missing), paste("RUNTIME_NOT_VALIDATED: missing installed packages:", paste(missing, collapse = ", "), "- no auto-install performed"))
  data <- read_inputs(opt)
  link <- Sys.readlink(opt$out)
  need(!dir.exists(opt$out) && !file.exists(opt$out) && (is.na(link) || !nzchar(link)), "Use a new output directory; refusing overwrite")
  need(isTRUE(capabilities("cairo")) && isTRUE(capabilities("png")), "PNG/SVG devices require Cairo support")
  script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
  need(length(script_arg) == 1L, "Run using Rscript so script provenance can be recorded")
  inputs <- c(tree = opt$tree, metadata = opt$metadata, renderer_script = substring(script_arg, 8L))
  if (!is.null(opt$evidence)) inputs <- c(inputs, evidence = opt$evidence)
  hashes <- vapply(inputs, sha256, character(1))
  groups <- unique(c(intersect(c("C", "L", "M", "H"), unique(data$groups)), sort(setdiff(unique(data$groups), c("C", "L", "M", "H")))))
  colors <- setNames(grDevices::hcl.colors(length(groups), "Dark 3"), groups)
  fixed <- c(C = "#009E73", L = "#56B4E9", M = "#E69F00", H = "#CC79A7", Unknown = "#B6B6B6")
  colors[intersect(names(colors), names(fixed))] <- fixed[intersect(names(colors), names(fixed))]
  created <- dir.create(opt$out, recursive = TRUE)
  need(isTRUE(created) && dir.exists(opt$out), "Cannot exclusively create output directory; refusing concurrent/existing directory")
  warnings <- character()
  for (ext in c("pdf", "svg", "png")) {
    file <- file.path(opt$out, paste0("tree.", ext))
    if (ext == "pdf") grDevices::pdf(file, width = opt$width, height = opt$height, useDingbats = FALSE)
    if (ext == "svg") grDevices::svg(file, width = opt$width, height = opt$height)
    if (ext == "png") grDevices::png(file, width = opt$width, height = opt$height, units = "in", res = 160, type = "cairo")
    tryCatch(withCallingHandlers({
      if (opt$backend == "ape") plot_ape(data, opt, colors) else plot_ggtree(data, opt, colors)
    }, warning = function(w) { warnings <<- c(warnings, conditionMessage(w)); invokeRestart("muffleWarning") }), finally = grDevices::dev.off())
  }
  write_tsv(data$metadata, file.path(opt$out, "genome_index.tsv"))
  write_tsv(data.frame(group = names(colors), color = unname(colors)), file.path(opt$out, "group_colors.tsv"))
  write_tsv(data.frame(source_node = length(data$tree$tip.label) + seq_along(data$raw), raw_support = data$raw,
    support_order = opt[["support-order"]], meaning = ifelse(nzchar(data$raw), "supplied_numeric", "missing")), file.path(opt$out, "node_support.tsv"))
  need(all(vapply(inputs, sha256, character(1)) == hashes), "Source changed during render; no success manifest written")
  need(file.copy(opt$tree, file.path(opt$out, "source_tree.nwk"), overwrite = FALSE), "Tree copy failed")
  need(file.copy(opt$metadata, file.path(opt$out, "source_metadata.tsv"), overwrite = FALSE), "Metadata copy failed")
  need(sha256(file.path(opt$out, "source_tree.nwk")) == hashes[["tree"]] && sha256(file.path(opt$out, "source_metadata.tsv")) == hashes[["metadata"]], "Source copy checksum mismatch")
  writeLines(capture.output(sessionInfo()), file.path(opt$out, "sessionInfo.txt"))
  writeLines(unique(warnings), file.path(opt$out, "warnings.txt"))
  write_tsv(data.frame(role = names(inputs), path = normalizePath(inputs), sha256 = hashes), file.path(opt$out, "source_hashes.tsv"))
  manifest <- data.frame(key = c("status", "scope", "dataset_kind", "source_status", "description", "backend", "layout", "tips", "labels", "supports", "support_order", "topology_transformation", "visual_qa"),
    value = c("preview", "visualization_only", opt[["dataset-kind"]], opt[["source-status"]], opt$description, opt$backend, opt$layout, length(data$tree$tip.label), opt$labels, opt$supports, opt[["support-order"]], "none; display layout only", "PENDING: open each actual image and check legibility/clipping; no automatic validated claim"))
  write_tsv(manifest, file.path(opt$out, "render_manifest.tsv"))
  files <- list.files(opt$out, full.names = TRUE)
  write_tsv(data.frame(file = basename(files), sha256 = vapply(files, sha256, character(1))), file.path(opt$out, "output_hashes.tsv"))
  cat("PREVIEW created:", normalizePath(opt$out), "\n")
  invisible(0L)
}
tryCatch(main(), error = function(e) { message(conditionMessage(e)); quit(status = 2L) })
