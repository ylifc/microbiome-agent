#!/usr/bin/env Rscript
# Plot already analysed tidy tables with base R only; no fitting or tests.
main <- function() {
  argv <- commandArgs(trailingOnly=TRUE)
  kinds <- c('composition','heatmap','alpha','ordination','volcano','forest','mag-quality','rarefaction','growth')
  if (length(argv)==0 || '--help' %in% argv) {
    cat('Rscript plot_table_base.R --kind KIND --input data.tsv --output NEW_DIR --title TEXT --dataset-kind synthetic|biological --source-note TEXT\n',
        'Biological: --source-evidence existing_file\n',
        'Engine-created empty directory only: --allow-empty-output true (default false)\n',
        'Labels: --x-label TEXT --y-label TEXT; forest: --reference NUMBER; volcano: --q-threshold NUMBER\n',
        'Kinds:',paste(kinds,collapse=', '),'\nSee references/table-cli.md for exact columns.\n')
    return(invisible(NULL))
  }
  need <- function(ok, msg) if (!isTRUE(ok)) stop(msg,call.=FALSE)
  need(length(argv)%%2==0,'Arguments must be --key value pairs')
  keys <- argv[seq(1,length(argv),2)]; vals <- argv[seq(2,length(argv),2)]
  allowed <- paste0('--',c('kind','input','output','title','dataset-kind','source-note','source-evidence','x-label','y-label','reference','q-threshold','allow-empty-output'))
  need(!anyDuplicated(keys) && all(keys %in% allowed),'Duplicate/unknown arguments')
  a <- as.list(vals); names(a) <- substring(keys,3)
  for (k in c('kind','input','output','title','dataset-kind','source-note')) need(!is.null(a[[k]]) && nzchar(trimws(a[[k]])),paste('Required:',k))
  need(a$kind %in% kinds,'Unknown kind')
  need(a[['dataset-kind']] %in% c('synthetic','biological'),'Explicit dataset kind required')
  need(!any(grepl('[\t\r\n]',unlist(a))),'Control separators in arguments')
  inp <- normalizePath(a$input,mustWork=TRUE)
  need(!dir.exists(inp),'Input must be a TSV file')
  need(file.info(inp)$size <= 64*1024^2,'Input exceeds 64 MiB table limit')
  if(a[['dataset-kind']]=='biological') need(!is.null(a[['source-evidence']]) && file.exists(a[['source-evidence']]) && !dir.exists(a[['source-evidence']]),'Biological input requires a source-evidence file')
  allow_empty <- a[['allow-empty-output']]
  if (is.null(allow_empty)) allow_empty <- 'false'
  need(allow_empty %in% c('true','false'),'allow-empty-output must be true or false')
  no_output_symlink <- function(path) {
    path <- path.expand(path)
    if (!startsWith(path,'/')) path <- file.path(getwd(),path)
    repeat {
      link <- Sys.readlink(path)
      need(is.na(link) || !nzchar(link),'Output path or ancestor must not be a symlink')
      parent <- dirname(path)
      if (identical(parent,path)) break
      path <- parent
    }
  }
  no_output_symlink(a$output)
  need(!basename(a$output) %in% c('','.','..'),'Output requires a named directory')
  out_parent <- normalizePath(dirname(a$output),mustWork=TRUE)
  out <- file.path(out_parent,basename(a$output))
  need(!identical(out_parent,dirname(inp)),'Keep new figures outside input directory')
  check_output <- function() {
    no_output_symlink(a$output)
    if (file.exists(out) || dir.exists(out)) {
      need(allow_empty == 'true','Output must not exist unless --allow-empty-output true')
      need(dir.exists(out) && file.access(out,4)==0 && length(list.files(out,all.files=TRUE,no..=TRUE))==0,
           'Existing output must be a readable, strictly empty directory')
    }
  }
  check_output()
  sha_tool <- Sys.which('sha256sum'); need(nzchar(sha_tool),'sha256sum required for provenance; no package installation attempted')
  hash <- function(p) {z<-system2(sha_tool,shQuote(p),stdout=TRUE,stderr=TRUE); need(is.null(attr(z,'status')),paste('Cannot hash',p));v<-strsplit(z[1],' ')[[1]][1];need(grepl('^[a-f0-9]{64}$',v),'Invalid SHA256 response');v}
  input_hash <- hash(inp)
  evidence <- if(is.null(a[['source-evidence']])) '' else normalizePath(a[['source-evidence']],mustWork=TRUE)
  evidence_hash <- if(nzchar(evidence)) hash(evidence) else ''
  fields <- count.fields(inp,sep='\t',quote='',comment.char='',blank.lines.skip=FALSE)
  need(length(fields)>1 && all(fields==fields[1]),'Malformed/blank TSV row')
  d <- read.delim(inp,sep='\t',quote='',comment.char='',check.names=FALSE,colClasses='character',na.strings=NULL,strip.white=FALSE)
  need(nrow(d)>0 && !anyDuplicated(names(d)) && all(nzchar(names(d))) && all(names(d)==trimws(names(d))),'Empty/duplicate/whitespace header or empty input')
  required <- switch(a$kind,composition=c('sample_id','group','feature','value'),heatmap=c('sample_id','feature','value'),alpha=c('sample_id','group','metric','value'),ordination=c('sample_id','group','axis1','axis2'),volcano=c('feature','effect','qvalue'),forest=c('feature','effect','lower','upper'),'mag-quality'=c('genome_id','group','completeness','contamination'),rarefaction=c('sample_id','group','depth','richness'),growth=c('sample_id','group','time','value'))
  need(all(required %in% names(d)),paste('Required columns:',paste(required,collapse=',')))
  idcols <- intersect(c('sample_id','genome_id','feature','group','metric'),required)
  for(k in idcols) need(all(nzchar(d[[k]])) && all(d[[k]]==trimws(d[[k]])),paste('Invalid exact identity/category:',k))
  numericcols <- setdiff(required,idcols)
  for(k in numericcols) {
    missing <- d[[k]] %in% c('','NA')
    n <- suppressWarnings(as.numeric(d[[k]]))
    need(all(is.finite(n) | (missing & a$kind=='heatmap')),paste('Nonfinite/invalid number:',k))
    d[[k]] <- n
  }
  if(all(c('sample_id','group') %in% names(d))) need(all(vapply(split(d$group,d$sample_id),function(x) length(unique(x))==1,logical(1))),'One sample maps to multiple groups')
  unique_key <- switch(a$kind,composition=c('sample_id','feature'),heatmap=c('sample_id','feature'),alpha='sample_id',ordination='sample_id',volcano='feature',forest='feature','mag-quality'='genome_id',rarefaction=c('sample_id','depth'),growth=c('sample_id','time'))
  need(!anyDuplicated(d[unique_key]),'Duplicate observational key; aggregate or resolve upstream explicitly')
  if(a$kind=='alpha') need(length(unique(d$metric))==1,'One metric per figure; split metrics upstream')
  if(a$kind %in% c('ordination','volcano','forest','heatmap','growth','rarefaction')) {
    for(k in c('x-label','y-label')) need(!is.null(a[[k]]) && nzchar(a[[k]]),paste('Declare axis meaning/units:',k))
  }
  if(a$kind=='composition') {
    need(all(d$value>=0 & d$value<=1),'Composition values must be fractions in [0,1]')
    need(all(abs(tapply(d$value,d$sample_id,sum)-1)<1e-6),'Each composition must sum to 1; no silent normalization')
    need(nrow(d)==length(unique(d$sample_id))*length(unique(d$feature)),'Composition requires explicit zero rows; missing is not automatically zero')
    need(length(unique(d$feature))<=25,'Too many features for stacked colors; review top-N/Other aggregation first')
  }
  if(a$kind=='mag-quality') need(all(d$completeness>=0 & d$completeness<=100 & d$contamination>=0),'Invalid quality percentages')
  if(a$kind=='rarefaction') {
    need(all(d$depth>=0 & d$richness>=0),'Negative rarefaction values')
    need(all(d$depth==floor(d$depth) & d$richness<=d$depth+1e-8),'Read-count rarefaction requires integer depth and richness <= depth')
    for(s in unique(d$sample_id)) {z<-d[d$sample_id==s,];z<-z[order(z$depth),];need(all(diff(z$richness)>=-1e-8),'Rarefaction richness must not decrease with depth')}
  }
  if(a$kind=='volcano') {
    need(a[['y-label']] %in% c('-log10 adjusted q','-log10(adjusted q)','-log10(adjusted q-value)'), 'Volcano y-label must explicitly identify -log10(adjusted q-value)')
    need(all(d$qvalue>0 & d$qvalue<=1),'qvalue must be (0,1]; handle underflow/zero upstream with an explicit documented bound')
    need(!is.null(a[['q-threshold']]),'Declare q-threshold')
    threshold <- suppressWarnings(as.numeric(a[['q-threshold']]))
    need(length(threshold)==1 && is.finite(threshold) && threshold>0 && threshold<1,'Invalid q-threshold')
  }
  if(a$kind=='forest') {
    need(all(d$lower<=d$effect & d$effect<=d$upper),'Effect must lie within supplied interval')
    need(nrow(d)<=60,'Forest plot too large; split reviewed feature sets first')
    reference <- suppressWarnings(as.numeric(a$reference));need(length(reference)==1 && is.finite(reference),'Declare forest reference: 0 for difference, 1 for ratio')
  }
  samples <- if('sample_id' %in% names(d)) unique(d$sample_id) else character()
  features <- if('feature' %in% names(d)) unique(d$feature) else character()
  if(a$kind=='heatmap') need(length(samples)<=80 && length(features)<=100 && any(is.finite(d$value)),'Heatmap needs finite values and <=80 samples / <=100 features; use tiled/ComplexHeatmap for larger data')
  groups <- if('group' %in% names(d)) unique(d$group) else character()
  cols <- if(length(groups)) setNames(grDevices::hcl.colors(length(groups),'Dark 3'),groups) else character()
  fixed <- c(C='#009E73',L='#56B4E9',M='#E69F00',H='#CC79A7')
  for(g in intersect(groups,names(fixed))) cols[g]<-fixed[g]
  width<-10;height<-7
  if(a$kind=='forest') height<-max(6,0.24*nrow(d)+2)
  if(a$kind=='heatmap') {width<-min(24,max(9,0.22*length(samples)+4));height<-min(26,max(7,0.20*length(features)+3))}
  title <- paste(if(a[['dataset-kind']]=='synthetic') 'SYNTHETIC |' else 'BIOLOGICAL PREVIEW |',a$title)
  draw <- function() {
    par(mar=c(6,6,4,2),xpd=FALSE)
    if(a$kind=='composition') {
      m<-matrix(0,length(features),length(samples),dimnames=list(features,samples));m[cbind(match(d$feature,features),match(d$sample_id,samples))]<-d$value
      par(mar=c(7,5,4,11));barplot(m,col=hcl.colors(length(features),'Spectral'),border=NA,las=2,ylim=c(0,1),ylab='Relative abundance (fraction)',main=title)
      u<-par('usr');legend(u[2]+diff(u[1:2])*.03,1,legend=features,fill=hcl.colors(length(features),'Spectral'),cex=.65,bty='n',xpd=NA,xjust=0,yjust=1)
    } else if(a$kind=='heatmap') {
      m<-matrix(NA_real_,length(features),length(samples));m[cbind(match(d$feature,features),match(d$sample_id,samples))]<-d$value
      pal<-hcl.colors(64,'Viridis'); zr<-range(m,na.rm=TRUE)
      if(diff(zr)==0) zr<-zr+c(-1,1)*max(1,abs(zr[1]))*.01
      par(mar=c(8,10,4,9)); image(seq_along(samples),seq_along(features),t(m[nrow(m):1,,drop=FALSE]),col=pal,zlim=zr,axes=FALSE,xlab=a[['x-label']],ylab='',main=title)
      axis(1,seq_along(samples),samples,las=2,cex.axis=.6);axis(2,seq_along(features),rev(features),las=2,cex.axis=.6);mtext(a[['y-label']],2,line=8)
      if(anyNA(m)) {ij<-which(is.na(m),arr.ind=TRUE);points(ij[,2],nrow(m)-ij[,1]+1,pch=4,col='grey40')}
      mtext(paste('As supplied; no scaling/clustering. Range:',paste(signif(range(m,na.rm=TRUE),4),collapse=' to '),'; x = missing'),1,line=6,cex=.65)
      u<-par('usr'); bx<-u[2]+diff(u[1:2])*.04; bw<-diff(u[1:2])*.04
      by<-seq(u[3],u[4],length.out=65)
      rect(bx,by[-65],bx+bw,by[-1],col=pal,border=NA,xpd=NA)
      ticks<-pretty(zr);ticks<-ticks[ticks>=zr[1] & ticks<=zr[2]]
      text(bx+bw*1.4,u[3]+(ticks-zr[1])/diff(zr)*diff(u[3:4]),format(ticks,trim=TRUE),adj=0,cex=.65,xpd=NA)
    } else if(a$kind=='alpha') {
      x<-match(d$group,groups);offset<-numeric(nrow(d))
      for(i in seq_along(groups)) {ix<-which(x==i);if(length(ix)>1) offset[ix]<-seq(-.12,.12,length.out=length(ix))}
      plot(x+offset,d$value,col=cols[d$group],pch=19,xaxt='n',xlim=c(.5,length(groups)+.5),xlab='',ylab=unique(d$metric),main=title)
      axis(1,seq_along(groups),paste0(groups,' (n=',table(factor(d$group,levels=groups)),')'))
      for(i in seq_along(groups)) segments(i-.18,median(d$value[x==i]),i+.18,median(d$value[x==i]),lwd=2)
      mtext('Raw sample values + median; no significance test',1,line=4,cex=.7)
    } else if(a$kind=='ordination') {
      plot(d$axis1,d$axis2,col=cols[d$group],pch=19,xlab=a[['x-label']],ylab=a[['y-label']],main=title,asp=1)
      text(d$axis1,d$axis2,labels=d$sample_id,pos=3,cex=.65);legend('topright',groups,col=cols,pch=19,bty='n',cex=.75)
    } else if(a$kind=='volcano') {
      plot(d$effect,-log10(d$qvalue),col=ifelse(d$qvalue<threshold,'#D55E00','grey50'),pch=19,xlab=a[['x-label']],ylab='-log10(adjusted q-value)',main=title)
      abline(h=-log10(threshold),lty=2);mtext(paste('Supplied adjusted q; threshold',threshold,'; no re-fitting or effect-size cutoff'),1,line=4,cex=.65)
    } else if(a$kind=='forest') {
      y<-rev(seq_len(nrow(d)));par(mar=c(6,12,4,2));plot(d$effect,y,xlim=range(c(d$lower,d$upper,reference)),ylim=c(.5,nrow(d)+.5),yaxt='n',xlab=a[['x-label']],ylab='',pch=19,main=title)
      segments(d$lower,y,d$upper,y);axis(2,y,d$feature,las=2,cex.axis=.7);abline(v=reference,lty=2);mtext(a[['y-label']],1,line=4,cex=.7)
    } else if(a$kind=='mag-quality') {
      plot(d$completeness,d$contamination,col=cols[d$group],pch=19,xlab='Completeness (%)',ylab='Contamination (%)',xlim=c(0,100),main=title)
      legend('topright',groups,col=cols,pch=19,bty='n',cex=.75);mtext('Descriptive quality estimates; not MIMAG certification or biological replicates',1,line=4,cex=.65)
    } else {
      xx<-if(a$kind=='growth') 'time' else 'depth'; yy<-if(a$kind=='growth') 'value' else 'richness'
      plot(d[[xx]],d[[yy]],type='n',xlab=a[['x-label']],ylab=a[['y-label']],main=title)
      for(s in samples) {z<-d[d$sample_id==s,];z<-z[order(z[[xx]]),];lines(z[[xx]],z[[yy]],col=cols[z$group[1]],type='b',pch=16,cex=.6)}
      legend('topleft',groups,col=cols,lty=1,bty='n',cex=.75);mtext('One line per sample; supplied values; no fitted model or extrapolation',1,line=4,cex=.65)
    }
  }
  need(capabilities('cairo'),'Cairo needed for headless PNG rendering')
  check_output()
  if (!dir.exists(out)) {
    created <- dir.create(out,recursive=FALSE)
    need(isTRUE(created) && dir.exists(out),'Cannot exclusively create output; refusing concurrent/existing directory')
  }
  for(fmt in c('pdf','svg','png')) {
    f<-file.path(out,paste0('figure.',fmt))
    if(fmt=='pdf') pdf(f,width=width,height=height,useDingbats=FALSE)
    if(fmt=='svg') svg(f,width=width,height=height)
    if(fmt=='png') png(f,width=width,height=height,units='in',res=160,type='cairo')
    tryCatch(draw(),finally=dev.off())
  }
  need(identical(hash(inp),input_hash),'Input changed during rendering')
  if(nzchar(evidence)) need(identical(hash(evidence),evidence_hash),'Source evidence changed')
  need(isTRUE(file.copy(inp,file.path(out,'source_table.tsv'),overwrite=FALSE)), 'Cannot preserve source table')
  need(identical(hash(file.path(out,'source_table.tsv')), input_hash), 'Source copy checksum mismatch')
  write.table(d,file.path(out,'plotted_values.tsv'),sep='\t',row.names=FALSE,quote=FALSE,na='NA')
  writeLines(capture.output(sessionInfo()),file.path(out,'sessionInfo.txt'))
  writeLines(c('Visual status: preview; not accepted automatically.','Inspect PNG and vector file at intended size. Check labels, ranges, legends, missing values, IDs and source statistic/units.','No inference, normalization, clustering, FDR correction, fitting, significance testing or production approval was performed.','Heatmap axes follow first appearance; missing cells are marked x. Ordination uses supplied coordinates.','Figures from synthetic data remain synthetic after inspection.'),file.path(out,'review_required.txt'))
  sf<-sub('^--file=','',grep('^--file=',commandArgs(),value=TRUE)[1])
  kv<-c(status='preview',scope='visualization_only',kind=a$kind,dataset_kind=a[['dataset-kind']],source_note=a[['source-note']],source_path=inp,source_sha256=input_hash,source_evidence=evidence,source_evidence_sha256=evidence_hash,script_sha256=hash(sf),rows=nrow(d),R_version=R.version.string,source_scientific_validation='not_asserted',created_at=format(Sys.time(),tz='UTC',usetz=TRUE))
  for(k in names(a)) kv[paste0('argument.',k)]<-a[[k]]
  for(f in list.files(out,full.names=TRUE)) kv[paste0('output_sha256.',basename(f))]<-hash(f)
  write.table(data.frame(key=names(kv),value=unname(kv)),file.path(out,'manifest.tsv'),sep='\t',quote=TRUE,row.names=FALSE)
  cat('PREVIEW created:',out,'\n')
}
tryCatch(main(),error=function(e) {cat('FAILED:',conditionMessage(e),'\n',file=stderr());quit(status=2)})
