# 微生物群落图谱：按问题选图

本页是 **36 类图形的选型与验收参考**，不是自动分析计划。已有结果优先重绘；重新计算距离、排序、差异模型、关联网络或置换检验属于分析，须处于已有授权范围并记录方法。配套代码见 [12 个 R 配方](r-community-recipes.md)。这里的 R、Python、GUI 名称是实现入口，**不代表已安装、已运行或已通过当前数据验收**。现有树 renderer 的输入合同不能直接套用到丰度表。

目录：共同合同 → 组成与层级（01–04）→ α 多样性与采样（05–09）→ β 多样性与排序（10–19）→ 差异与特征分布（20–28）→ 关联、时间与多组学（29–36）→ 官方来源。

## 共同数据与科学合同

| 输入简称 | 最低字段与含义 |
| --- | --- |
| `M` 样本表 | `sample_id, biological_unit_id, group, batch`；重复测量另有 `time, subject_id/pair_id`。sample ID 唯一，按 ID 显式对齐，不依赖行顺序；未测与测得零分开。 |
| `X` 群落矩阵 | 行为样本、列为唯一 `feature_id`，非负丰度；原始计数还要求整数。记录单位、测序/定量方法、完整特征集合、分母、过滤与零处理。全零样本须明确处理，不能无声删除。 |
| `T` 分类/功能映射 | `feature_id, taxonomy_id/path, rank, label, database_version`；功能另有 `function_id, namespace, annotation_method`。同名不同谱系不合并；多重注释的分配规则须明确。 |
| `D` 样本距离 | 对称、有限、非负、零对角的带双轴 sample ID 方阵；另存 `metric, transform, zero_policy, phylogeny_hash`（如适用）。不能把距离矩阵再次当丰度矩阵计算距离。 |
| `O` 排序结果 | `sample_id, axis1, axis2, method, metric, transform, run_id`，加原生 eigenvalues/stress/载荷、参数与随机种子；轴解释比例必须来自对应算法。 |
| `E` 模型结果 | `feature_id, contrast, method, estimate, effect_scale, null_effect, CI/SE, p, q, tested, n_units, model_formula, source_run`；保留失败、结构零与未检验状态。映射原生列时记录字典，不能猜测系数尺度。 |
| `G` 图/集合结果 | 节点表含所有节点（包括孤立点）；边表 `source,target,estimate,method,n_units,q/stability,source_run`。集合表必须带检测阈值、总体及“任一样本/全部样本/达到某比例”的定义。 |

- **组成性与零：** 相对丰度上升不等于绝对数量增加。不要对闭合组成直接做 Pearson 相关后称为生态互作。CLR 需要明确的正值/零替换方案；伪计数及 rCLR 的缺失重建也属于方法选择。Hellinger 是相对丰度开方，不是 CLR，也不是消除全部组成性问题的保证。未测、未分类、未检验和观测零各自保留。
- **实验单位：** 本 DBDPE 项目为 **12 个独立笼混样，C/L/M/H 各 3 笼，每笼 5 只鼠**。组间 n 是 3，不是 15；MAG/ASV/基因是特征，不是处理组重复。技术重复不能扩大 n。时间图只连接真实相同笼/受试者，不能给横断面样本创造配对。
- **小 n 与批次：** 每组 3 点优先原始点、具体效应和不确定性，不用平滑密度或置信椭圆营造精确分布。batch 用可见标记/分面检查；若处理组与 batch 完全混杂，不能靠换颜色或加协变量分离二者。高维模型、网络和监督多组学必须说明 n、自由度、调参、验证及稳定性局限。
- **统计边界：** 不因“美化”而新增过滤、稀释、检验、p 值或因果措辞。PERMANOVA 可能混合位置与离散度效应；结合 dispersion、设计与置换可交换性解释，`betadisper p>0.05` 不证明离散度完全相等。置换应反映随机化/区组/重复测量，不能机械地把每个唯一笼设为不可交换 block。[vegan adonis2](https://vegandevs.github.io/vegan/reference/adonis.html)
- **输出验收：** 每张图记录输入 SHA-256、源 run/科学状态、ID 映射、变换与筛选、代码/版本/种子、完整可下载数表。预览保留 `preview`；视觉 QA 只验证图形。核对所有点/样本/节点、分母、图例和缺失数量，再检查可读尺度、截断和颜色。任何展示子集都列出包含/排除 ID，不回写正式结果。

## 组成与层级

| 图种与问题 | 输入与变换 | R / Python 或 GUI 路径 | 前提与常见误读 | 验收重点 |
| --- | --- | --- | --- | --- |
| **01 Stacked abundance**：每个样本由哪些类群构成？ | `X+M+T`；同一分类层级，按声明分母算比例；显示 Top N 时其余汇入 Other，保留未分类。 | R `phyloseq::plot_bar` / `ggplot2::geom_col`，配方 R01；Python `Axes.bar(bottom=...)`。 | `plot_bar` 本身不归一化。每组混合 reads 后作一条柱会丢掉笼间变化；组均值必须先算每笼比例并说明权重。 | 每样本总和、Other+Unknown 守恒；分类级别一致；全部 12 个 sample ID 和颜色稳定。 |
| **02 Alluvial taxonomy**：已计量质量如何分布到分类层级？ | 每条唯一路径 `sample_id,path_id,kingdom,phylum,genus,weight`；权重只能在一套互斥路径上分配。 | R `ggalluvial::geom_alluvium, geom_stratum`，R03；Python `plotly.graph_objects.Sankey`。 | 连带表示分类归属，不表示微生物迁移或时间转化；各层混入父级总量和子级量会双计。 | 每轴总质量一致；同名属保留上级路径；缺失层级显式 Unclassified；宽度与表一致。 |
| **03 Sankey transfer**：来源到去向的真实分配/候选谱系关系？ | `source_id,target_id,weight,weight_unit,relation_type`；只有上游确证的映射才画边。 | R 先转 lodes 表再用 `ggalluvial::geom_flow`；Python `go.Sankey`。 | “原 bin→精修候选”可用已验证重叠 bp，但共享/多重归属需规则；不能从丰度相关臆造流向。 | 节点命名空间唯一、边无重复；非守恒系统明确新增/丢失/重叠，不硬凑平衡。 |
| **04 Krona / sunburst**：交互查看分类层级及占比？ | `weight,taxonomic_path` 或 `id,parent,value`；固定分母与层级。 | R `plotly::plot_ly(type='sunburst')`；Python `px.sunburst`；GUI/CLI KronaTools 导入显式谱系。 | Krona 是层级组成，不是推断系统树；Plotly `branchvalues='total'` 与 `'remainder'` 含义不同。 | 独立 ID 防止重名串枝；父子总量关系正确；导出 HTML 与完整数表，检查点击后的分母。 |

入口依据：[phyloseq bars](https://joey711.github.io/phyloseq/plot_bar-examples.html)、[ggalluvial](https://corybrunson.github.io/ggalluvial/articles/ggalluvial.html)、[KronaTools](https://github.com/marbl/Krona/wiki/KronaTools)、[Plotly Sankey](https://plotly.com/python/sankey-diagram/)、[Plotly sunburst](https://plotly.com/python/sunburst-charts/)。

## α 多样性与采样充分性

| 图种与问题 | 输入与变换 | R / Python 或 GUI 路径 | 前提与常见误读 | 验收重点 |
| --- | --- | --- | --- | --- |
| **05 α 原始点 + box/median**：笼间多样性分布如何？ | 已计算 `sample_id,metric,value` + M；注明 Shannon 的 log 底、Simpson 的具体定义及过滤/稀释。 | R `geom_point+geom_boxplot`，R02；Python `Axes.scatter, boxplot`。 | 每点一个生物单位；箱线须、SE、CI 不互换。丰富度估计依赖稀有计数，不能先删单例再称原始丰富度。 | 原始点全显、每组 n 和缺失数；指标单位、零值与相同值可识别；不凭箱体添加显著性。 |
| **06 α violin / raincloud**：足量样本的分布形状？ | 与 05 同；只对已有指标做核密度和点/摘要展示。 | R `geom_violin` 或 `ggdist::stat_halfeye` + raw points；Python `Axes.violinplot+scatter`。 | 核密度带宽影响形状；零界附近可能越界。**当前 n=3/组默认改用 05**；半眼区间也不是自动的组效应 CI。 | 带宽、边界、密度缩放及 n 可追溯；不隐藏离群原始点，不把平滑轮廓当样本量。 |
| **07 Rarefaction curve**：随测序采样量增加能观察多少特征？ | 未稀有过滤的整数计数，或上游 `sample_id,depth,richness,method`；清楚是 reads、个体还是采样单位。 | R 计算 `vegan::rarecurve/rarefy`，已有曲线 R04；Python只绘上游曲线 `Axes.plot`。 | 画稀释曲线不等于批准把所有下游数据稀释到固定深度；平坦不证明无未检出类群。MAG 数不能替代测序计数。 | 深度不超过真实 library（外推另标）；坐标单位、原始深度、插值/外推、低深度样本保留。 |
| **08 Coverage / Hill diversity**：在相似覆盖度下比较哪些多样性阶数？ | abundance 或 incidence 明确类型；上游 `coverage,estimate,CI,order_q,method`。 | R `iNEXT::iNEXT` 计算、`ggiNEXT(type=2/3)` 绘图；R04/Python `fill_between+plot` 可重绘导出表。 | sample coverage 不是组装完整度或基因组 coverage；q=1 是 exp(Shannon)，不是 Shannon 本身。不能任意合并独立笼以制造精确组曲线。 | q、数据类型、外推上限、CI 方法与稀有事件保留；样本身份和插值/外推线型清楚。 |
| **09 Rank abundance**：优势度与长尾形状？ | 每样本 `feature_id,abundance`；在样本内按正丰度降序排序，保留 rank↔ID 表。 | R `geom_line`；Python `Axes.plot`；描述计算 `sort`/`rank`。 | 不同样本第 10 名不是同一物种；log y 不能绘零，不用随意伪计数伪装未检出尾部。 | 并列规则、正值数、零/未测数量与尾部裁剪范围；说明相对或绝对单位。 |

入口依据：[phyloseq α](https://joey711.github.io/phyloseq/plot_richness-examples)、[ggplot box](https://ggplot2.tidyverse.org/reference/geom_boxplot.html)、[violin](https://ggplot2.tidyverse.org/reference/geom_violin.html)、[ggdist half-eye](https://mjskay.github.io/ggdist/reference/stat_halfeye.html)、[vegan rarefy](https://vegandevs.github.io/vegan/reference/rarefy.html)、[iNEXT 作者文档](https://github.com/AnneChao/iNEXT)。

## β 多样性、排序与约束模型

**不要互换这些方法的轴解释。** PCoA 输入距离；PCA 对特征矩阵的线性方差排序；NMDS 拟合距离的次序并报告 stress；t-SNE/UMAP 是非线性邻域嵌入，轴没有解释方差百分比。最后两者不能通过视觉“分群更清楚”替代原分析，当前 12 笼不宜用它们作为处理效应的主要证据。[scikit-bio PCoA](https://scikit.bio/docs/latest/generated/skbio.stats.ordination.pcoa.html)、[PCA](https://scikit-learn.org/stable/modules/generated/sklearn.decomposition.PCA.html)、[manifold](https://scikit-learn.org/stable/modules/manifold.html)、[UMAP parameters](https://umap-learn.readthedocs.io/en/latest/parameters.html)

| 图种与问题 | 输入与变换 | R / Python 或 GUI 路径 | 前提与常见误读 | 验收重点 |
| --- | --- | --- | --- | --- |
| **10 PCoA**：指定生态距离的主要样本差异？ | `D+M`；Bray、Jaccard、Aitchison、UniFrac 均须明确生成方法。 | R `vegan::wcmdscale` / `phyloseq::ordinate(method='PCoA')` 计算；R05 或 Python `skbio.stats.ordination.pcoa` 后绘图。 | 非欧氏距离可能有负特征值；Lingoes/Cailliez 修正属于分析选择。UniFrac 需要匹配、有意义枝长的特征树。 | 全部样本、距离及树哈希、特征值/负惯量、修正和坐标比例；不可随意标“解释总方差”。 |
| **11 PCA**：声明特征尺度下的线性变化？ | X 经约定变换；例如 Hellinger，或明确零处理后的 CLR；记录 center/scale。 | R `stats::prcomp`，R06；Python `sklearn.decomposition.PCA`。 | 原始 reads PCA 常受 library size 支配；CLR-PCA 和 Hellinger-PCA 回答不同几何问题；列 z-score 会改变稀有特征权重。 | 每轴百分比、载荷 ID、变换与零策略；符号翻转无科学差异，样本不能重排错配。 |
| **12 NMDS**：样本距离的相对次序？ | D 或 X+声明距离；保存 k、seed、starts 与收敛记录。 | R `vegan::metaMDS(...,autotransform=FALSE)`；Python `sklearn.manifold.MDS(metric=False)`，非完全等价实现。 | 默认自动变换可能另改数据；低 stress 在极少点时也可能无解释力；坐标不是百分比方差。 | stress/收敛、多起点与 Shepard 诊断；明确 Python 零距离/收敛语义，不假定与 vegan 一致。 |
| **13 t-SNE**：局部邻域探索？ | 已约定变换的 X 或受支持的预计算距离；参数包括 perplexity、metric、seed、初始化。 | R `Rtsne::Rtsne`；Python `sklearn.manifold.TSNE`；R05重绘坐标。 | 大尺度团间距离、岛面积和方向不宜当生物效应；perplexity 必须适合 n；不能用调参挑出期待分离。 | 原样本 ID、参数敏感性/重复种子、邻域保持；轴无方差%、无自动簇显著性。 |
| **14 UMAP**：局部结构在低维的探索表示？ | X/距离，记录 n_neighbors、min_dist、metric、seed 与预处理。 | R `uwot::umap`；Python `umap.UMAP`；R05重绘。 | 同时改变邻居数与 min_dist 会改变图形；群间距离/密度不是统一定量标尺，嵌入不等于聚类检验。 | 保存拟合模型/坐标与 seed；核对样本覆盖和参数稳健性，不报告不存在的轴解释方差。 |
| **15 Ordination biplot**：样本位置与哪些载荷/梯度对应？ | O + 同一模型的 feature scores/loadings 或另存的拟合环境向量。 | R `vegan::scores`, `plot.cca` / `phyloseq::plot_ordination(type='biplot')`；Python `Axes.scatter+arrow` 只绘导出坐标。 | PCA/RDA species scores、后验 envfit 向量和 PCoA 的样本坐标不是同一对象；不能凭相关把箭头冒充原生载荷。 | scoring scaling、箭头倍率、筛选规则及来源；原点/比例保留；未画箭头仍在表中。 |
| **16 dbRDA / CAP**：已指定环境/处理如何约束距离结构？ | D 或 X；M 中解释变量/协变量、公式和 Condition 项。 | R `vegan::dbrda` / `capscale` 计算与 `scores`；Python只绘导出 scores。 | 约束空间分离是模型构造结果，不是独立验证；说明 CAP 具体实现（这里指 vegan capscale），不是泛指分类准确率。 | 总/约束惯量分母、负特征值、模型秩/残差自由度、共线性；任何置换结果保存设计。 |
| **17 RDA**：变换后群落矩阵的线性解释结构？ | Hellinger 等 X + M；声明 predictors、Condition、缩放。 | R `vegan::rda`，`scores`/`plot`；Python Matplotlib 重绘导出样本与载荷。 | RDA 与 dbRDA 不等同；n=12 时大量协变量可耗尽自由度。组与 batch 混杂不能靠 partial RDA解决。 | 模型矩阵秩、adjusted R²/残差及两种轴解释比例清楚；输入与 scores 一一对应。 |
| **18 Beta dispersion**：组内离散程度是否不同？ | D + 分组；上游 `sample_id,distance_to_center,center_method`。 | R `vegan::betadisper(type='median')` 计算，R12重绘；Python画同一导出表，勿假定 PERMDISP实现完全一致。 | 中心类型和 small-sample bias correction 要记录；置换检验是单独分析。小 n 无显著差异不等于同方差。 | 全样本距离、负特征值/修正警告、n 与中心定义；与 PERMANOVA用同一距离与纳入集。 |
| **19 Distance heatmap**：哪些样本两两接近及有无批次结构？ | D + M；不再行 z-score，也不将 D 再做 Bray。 | R `ComplexHeatmap::Heatmap` / `geom_tile`，R12；Python `Axes.imshow`。 | 聚类枝只是由指定 linkage 得到的聚类，不是系统发育或独立显著性。 | 对称性、零对角、双轴同序、单一距离色标；batch/组注释与矩阵同 ID 对齐。 |

方法入口：[vegan vegdist](https://vegandevs.github.io/vegan/reference/vegdist.html)、[decostand](https://vegandevs.github.io/vegan/reference/decostand.html)、[metaMDS](https://vegandevs.github.io/vegan/reference/metaMDS.html)、[dbRDA/capscale](https://vegandevs.github.io/vegan/reference/dbrda.html)、[betadisper](https://vegandevs.github.io/vegan/reference/betadisper.html)、[phyloseq ordination](https://joey711.github.io/phyloseq/plot_ordination-examples.html)。

## 差异证据、特征分布与集合

| 图种与问题 | 输入与变换 | R / Python 或 GUI 路径 | 前提与常见误读 | 验收重点 |
| --- | --- | --- | --- | --- |
| **20 Effect forest**：哪些效应有多大、不确定性多宽？ | E 的 estimate、真实 CI、contrast、尺度和 null；只重绘已有模型。 | R `geom_pointrange/geom_segment`，R08；Python `Axes.errorbar`。 | ANCOM-BC2 的 lfc 可为自然对数；MaAsLin 系数依模型/变换而定；LDA 分数不是 fold change。CI不能凭 SE 随手改称95%。 | 对比方向、参考组、尺度与零/一无效线；保留不显著/失败数；区间与点来自同一模型。 |
| **21 Volcano**：效应与校正证据如何同时分布？ | E；x 为明确尺度的效应，y 为 -log10(q) 或 p，必须注明。 | R `geom_point`，R08；Python `Axes.scatter`。 | q 与原始 p 不混；q=0 是数值下溢/舍入状态，不是“绝对显著”；筛后再做 FDR 会改变问题。 | 统计总体、检测失败数、数值下限及截断箭头；阈值来源固定，不按漂亮程度调阈值。 |
| **22 MA**：效应是否依赖平均丰度？ | 同一比较的 mean abundance 与 effect；注明均值在哪个归一化尺度上计算。 | R `geom_point`，R08；Python `Axes.scatter`。 | A轴不能混合 raw counts 与 proportions；零均值不应无声加1；并非每个差异工具都有可比的 A。 | 原生效应方向与平均丰度匹配；零值方案、低丰度区和未检验特征清楚。 |
| **23 LEfSe cladogram / LDA bar**：已运行 LEfSe 报告了哪些判别类群？ | 原生 LEfSe 结果、完整分类路径、class/subclass/subject设置、阈值与版本。 | R 仅用 `ggplot` 重绘导出的 LDA分数/层级节点；GUI bioBakery Galaxy LEfSe visualization 或原工具绘图入口，先核实本地版本帮助。 | 分类 cladogram 不是序列推断树；LDA score 不是因果效应，也不是 ANCOM/回归的 logFC；不能把别的 p/q填成LEfSe结果。 | 节点谱系、类群方向、原生分数和入选规则对应；披露小 n、批次及未控制混杂。 |
| **24 Taxa heatmap**：样本间哪些类群丰度模式不同？ | X+M+T；显示相对丰度/log值/CLR/行z须预先声明。 | R `ComplexHeatmap::Heatmap`，R07；Python `Axes.imshow/pcolormesh`。 | 行z显示特征内相对高低，不能比较不同特征的绝对量；高变异/TopN 是展示选择，不等于差异显著。 | 零与 NA 分色、色标单位、所有列 ID、行筛选表；聚类距离/linkage单列记录。 |
| **25 Function/pathway heatmap**：功能组成或活性在哪些样本不同？ | `sample_id,function_id,value,unit,namespace,DBversion`；层级与长度/拷贝数/分层贡献规则。 | R R07；Python `Axes.imshow`；在已有注释结果上绘制。 | DNA功能潜能不等于表达或通路通量；多重命中不能不加说明重复求和；基因数、CPM、覆盖和相对丰度不互换。 | 数据库版本、功能层级、unknown/unmapped比例、stratified与unstratified守恒及量纲。 |
| **26 Prevalence / occupancy**：检测到某特征的生物单位比例？ | `feature_id,n_detected,n_measured,threshold,group`；或从明确完整 X 和阈值描述计算。 | R `geom_point/geom_tile`；Python `Axes.scatter/imshow`。 | 0/3与3/3精度有限；技术缺失不能进未检出分母。占据模型若校正检测概率是另一个统计模型。 | 分子≤分母、每组 n、阈值单位、检测与真实缺失区别；若CI存在核对其方法。 |
| **27 Venn**：少数集合共享/独有多少特征？ | G 的明确二元集合与 universe；通常2–3集合易读。 | R `VennDiagram::venn.diagram`；Python `matplotlib_venn.venn2/venn3`；也可转28。 | 面积未必精确比例；“组内任一笼检出”与“全部笼检出”不同，测序深度也影响交集。 | 与精确成员清单和集合大小对账；交集不是共享功能/迁移证据；显示universe和阈值。 |
| **28 UpSet**：多集合的精确交集规模？ | 同27，完整 `feature_id,set_A,set_B,...` 的0/1表。 | R `ComplexUpset::upset`，R09；Python `upsetplot.UpSet`。 | distinct/exclusive 与 inclusive交集不同；不要只保留最大交集而不报告被省略成员。 | 交集mode、空集/全FALSE、总成员与集合大小核对；保留完整membership.tsv。 |

结果来源核验：[ANCOM-BC2 原生输出](https://www.bioconductor.org/packages/release/bioc/vignettes/ANCOMBC/inst/doc/ANCOMBC2.html)、[MaAsLin2 输出与变换](https://github.com/biobakery/Maaslin2)、[MaAsLin3 丰度/检出模型](https://github.com/biobakery/Maaslin3)、[LEfSe 官方教程](https://github.com/biobakery/biobakery/wiki/lefse)。MaAsLin2 与3、丰度与检出子模型不能仅凭同名 coef 合并。图形入口：[ComplexHeatmap](https://jokergoo.github.io/ComplexHeatmap-reference/book/a-single-heatmap.html)、[ComplexUpset](https://krassowski.github.io/complex-upset/articles/Examples_R.html)、[VennDiagram 手册](https://cran.r-project.org/web/packages/VennDiagram/VennDiagram.pdf)、[matplotlib-venn](https://github.com/konstantint/matplotlib-venn)、[UpSetPlot](https://upsetplot.readthedocs.io/en/stable/)。

## 关联、重复测量与多组学

| 图种与问题 | 输入与变换 | R / Python 或 GUI 路径 | 前提与常见误读 | 验收重点 |
| --- | --- | --- | --- | --- |
| **29 Correlation/association heatmap**：已估计关联的方向与强度？ | 导出 `feature_a,feature_b,estimate,method,q,n_units`，或模型系数矩阵；方法决定是否对称。 | R `geom_tile/ComplexHeatmap`；Python `Axes.imshow`；不得在重绘时自动 `cor(X)`。 | Pearson/Spearman闭合组成相关、CLR相关、偏相关不是同一量；共享批次可制造关联；缺失的边不是0。 | 方法/调整项、完整检验总体、FDR或稳定性含义、NA颜色、上下三角含义一致。 |
| **30 Co-occurrence network**：已有模型支持哪些条件关联？ | G，包含所有节点、带方法的边和稳定性/证据；推断应有过滤、组合方法、调参与重采样记录。 | R `SpiecEasi::spiec.easi` 是推断；`igraph::graph_from_data_frame` / R11只绘图。Python `networkx.draw_networkx` 或 Cytoscape导入边表。 | 边不证明共生/竞争/因果；正负偏关联也非直接互作。n=12、数千特征不足以靠复杂网络外观建立可信机制。 | 节点/边计数、孤立点、符号/权重/阈值、稳定性及布局种子；布局距离没有生物学量纲。 |
| **31 Longitudinal / spaghetti**：同一生物单位随时间如何变化？ | `biological_unit_id,sample_id,time,feature/metric,value,group`；计划访视和缺测状态。 | R `geom_line(aes(group=biological_unit_id))+geom_point`，R10；Python `Axes.plot`按单位循环。 | 线属于单位不是组；不连接不同动物/笼；时间间隔按真实数值；平滑或混合模型属于新增分析。 | 配对ID、缺测断点、time顺序、各时点在险/实测n；group mean不能遮掉单体轨迹。 |
| **32 Paired slope / change**：真实配对前后变化如何？ | `pair_id/biological_unit_id,time,value`，每对每条件一次，明确两时点。 | R R10 paired模式；Python `Axes.plot`两点线。 | 横断面C与H不能按行号配对；完整对分析改变纳入集，需清单；多个MAG不是同一笼的独立配对。 | 每条线恰一真实对、缺失对数量、单位和变化方向；检验结果仅引用原已批准模型。 |
| **33 Environment association**：环境梯度与组成/特征的关系？ | 现有 envfit向量，或 E 的环境系数；需单位、调整项、n和变换。 | R `vegan::envfit` 为拟合/可能置换；绘图用 `plot.envfit`或R08；Python绘导出箭头/forest。 | 箭头不是因果方向；`envfit` 默认可做置换，纯展示用已有fit，不能悄悄重拟合。梯度与batch共线仍无法识别。 | scaling、箭头倍率、环境单位、模型/检验来源、被筛选变量和多重检验集合。 |
| **34 Variance partition**：不同解释变量组贡献哪些变异部分？ | X/D 与2–4个已定义解释矩阵，公式、变换和调整R²结果。 | R `vegan::varpart`, `plot.varpart`；Python根据已导出分量绘固定diagram/条形。 | 相交解释部分不是各因素的因果贡献；调整R²可能负，不应改为正或静默截0；非所有分量可直接检验。 | 分量代数关系、adjusted/unadjusted区分、残差与负值原表、可检验状态和模型自由度。 |
| **35 Procrustes / PROTEST**：两个已匹配样本的排序配置一致吗？ | 两个O，共同sample ID、相同维数、选择/缩放规则；保存旋转与残差。 | R `vegan::procrustes` 计算/`plot`；`protest`另外做置换；Python `scipy.spatial.procrustes` + Matplotlib（尺度语义需对齐）。 | 箭头短表示拟合后配置接近，不证明组学因果或原距离完全相同；共用输入会产生非独立的一致性。 | 交集/遗漏ID清单、固定参考配置、维数、残差、旋转缩放；置换需符合生物设计。 |
| **36 Multiomics circos / association**：不同组学哪些预先估计关系值得查看？ | 已配对生物单位的多组学矩阵；绘图用 G/E 或已验证多块模型，ID带组学前缀。 | R `circlize::chordDiagram`绘已给边；mixOmics既有模型的 `circosPlot/network`；Python用NetworkX二部图或Plotly Sankey替代布局。 | circos不是统计方法；相关/PLS载荷/预测贡献不可混；监督模型有泄漏风险，特征选择和调参应在正确验证层内，n=12尤其受限。 | 配对覆盖、各组学单位/批次、来源方法、方向与证据，显示阈值和全部边表；不把带宽画成物质流量。 |

入口依据：[SPIEC-EASI](https://github.com/zdk123/SpiecEasi)、[igraph数据框建图](https://r.igraph.org/reference/graph_from_data_frame.html)、[NetworkX绘图与导出](https://networkx.org/documentation/stable/reference/drawing.html)、[envfit](https://vegandevs.github.io/vegan/reference/envfit.html)、[varpart](https://vegandevs.github.io/vegan/reference/varpart.html)、[Procrustes](https://vegandevs.github.io/vegan/reference/procrustes.html)、[circlize chordDiagram](https://jokergoo.github.io/circlize_book/book/the-chorddiagram-function.html)。

## 官方来源与版本使用说明

以上在线文档的访问核验日期为 **2026-10-14**；链接来自作者、项目组织或 Bioconductor 官方站。它们证明接口/语义的文档出处，不能证明本机版本或配方已运行。phyloseq部分教程较旧，使用本地实际帮助核对函数，避免复制其已弃用别名或示例中的样本合并/过滤选择。通用 Python 图元见 [Matplotlib plot types](https://matplotlib.org/stable/plot_types/index.html)。

非线性嵌入接口与参数另见 [Rtsne 手册](https://cran.r-project.org/web/packages/Rtsne/Rtsne.pdf)、[uwot UMAP](https://jlmelville.github.io/uwot/reference/umap.html)、[scikit-learn manifold](https://scikit-learn.org/stable/modules/manifold.html)、[UMAP 参数](https://umap-learn.readthedocs.io/en/latest/parameters.html)；线性/距离排序对照见 [scikit-learn PCA](https://scikit-learn.org/stable/modules/generated/sklearn.decomposition.PCA.html)、[scikit-bio PCoA](https://scikit.bio/docs/latest/generated/skbio.stats.ordination.pcoa.html)。

执行时记录 `sessionInfo()`、实际包版本和函数参数；固定已有科学方法，缺包时报告并按依赖范围处理，不在正式运行里临时安装。R/Python实现即使同名也可能有默认参数差异。图表选择应由科学问题决定，不把这36项变成必须全部执行的清单。
