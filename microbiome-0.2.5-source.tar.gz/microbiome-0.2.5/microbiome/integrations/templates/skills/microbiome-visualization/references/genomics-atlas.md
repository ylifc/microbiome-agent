# 微生物基因组与实验图谱：34 类用途、输入和验收

按当前科学问题选择条目，不必生成全部图。软件操作与官方资料见 [software-recipes.md](software-recipes.md)；已有树、MAG 质量与分组计数的本地 renderer 合约见 [figure-contract.md](figure-contract.md)。本页是扩展设计指南，不表示这些分析或软件已在当前环境执行。

## 使用边界

- 图只消费真实、可定位的表、序列、图像或统计结果；缺少计数、背景集合、模型结果或独立重复时，先给描述性图，不能补造 P 值、置信区间、剂量或生物学结论。
- DBDPE 项目中一份测序样本是同笼 5 只小鼠的混样，C/L/M/H 各 3 个独立笼混样。组间推断单位是笼混样；bin、基因、contig、reads 和池内小鼠都不能自动当独立重复。没有具体剂量数值/单位时只用剂量类别轴。
- 每种图同时保存实际使用的数据子集 TSV/CSV、原始 ID 对照、过滤及变换记录、脚本/软件版本、输入/输出哈希、editable 工程或脚本和 SVG/PDF。图像/密集栅格可嵌入矢量图，但应明确哪些层为栅格，另存原始分辨率数据。
- 下文“R；其他”是候选绘图路线；须以运行前环境核验为准。程序缺失不等于授权安装，浏览文档不等于本机实测。云服务上传数据、树、注释或图片须已有明确外传授权；否则生成本地导入包。

## 测序与组装

### G01 Reads QC / MultiQC 总览

**用途**：定位样本的碱基质量、接头、长度、GC 或过滤损失异常。**输入**：同一阶段的 FastQC/fastp 等真实报告，sample ID、R1/R2、raw/clean 阶段和 reads/pairs 单位。**R；其他**：ggplot2 分面质量曲线；MultiQC 本地 HTML 与解析表。**误读**：MultiQC 汇总已有结果，不重新做 QC；红灯不是自动剔除理由，宏基因组组成可能影响 GC。**验收**：样本数与 manifest 相符；双端和阶段不重名覆盖；过滤前后分母可核对。[FastQC](https://www.bioinformatics.babraham.ac.uk/projects/fastqc/)、[MultiQC](https://docs.seqera.io/multiqc)（访问 2026-10-14）。

### G02 Contig 长度分布

**用途**：观察碎片化与短 contig 负担。**输入**：每条 contig 的 ID、长度、所属样本及最短保留长度。**R；其他**：ggplot2 histogram/ECDF；Matplotlib。**误读**：按 contig 数量的直方图与按总 bp 加权不是同一分布；log 轴不能隐去零/缺失。**验收**：bin 边界、截断阈值和计数单位可见；长度之和、contig 总数与输入一致。

### G03 Nx / N50 / L50

**用途**：比较组装连续性。**输入**：相同过滤规则下的完整长度列表或 QUAST 指标。**R；其他**：ggplot2 阶梯 Nx 曲线；QUAST 报告。**误读**：N50 是按累积 bp 到 50% 时对应的长度，不是长度中位数；L50 是达到该比例的 contig 数；NG50 使用已知目标基因组长度，不能与 N50 混写。**验收**：降序累积独立重算 N50/L50；坐标单位、总长分母与最短 contig 阈值注明。[QUAST](https://quast.sourceforge.net/docs/manual.html)（访问 2026-10-14）。

### G04 累积组装长度曲线

**用途**：同时展示 contig 数与所覆盖的组装总量。**输入**：降序长度列表，样本、组装流程版本。**R；其他**：ggplot2 累积折线；QUAST、Matplotlib。**误读**：曲线高可能是更大群落、重复或污染，不能直接解释为更好组装。**验收**：末端累积长度等于本次纳入长度之和；排名轴是否截断、曲线比较是否相同输入范围写清。

### G05 GC–coverage / Blob 图

**用途**：发现组成、丰度或分类异常的 contig 簇。**输入**：contig ID、GC、长度、同一 reads 集的覆盖统计、分类及证据来源。**R；其他**：ggplot2 气泡；BlobToolKit。**误读**：GC 或 coverage 离群不能单独判污染；点大小按面积还是半径、coverage 是均值还是中位数必须明确；未分类不等于外源。**验收**：GC 范围、coverage 单位、面积映射、分类库版本和所有未分类点均可追溯。[BlobTools2](https://blobtoolkit.genomehubs.org/blobtools2/)（访问 2026-10-14）。

## MAG 与分箱证据

### G06 完整度–污染度散点

**用途**：对比原始/精修 bins 的质量分布和改进。**输入**：bin ID、阶段、CheckM/CheckM2 实际指标、样本和原始→新 bin 映射。**R；其他**：ggplot2；本地 MAG renderer、Matplotlib。**误读**：估计完整度不等于真实回收比例；两个指标不足以自动授予完整高质量 MAG 标签；拆分/合并不能强配成一对一箭头。**验收**：版本/模型一致性、坐标百分比、阈值用途和未配对 bins 显示清楚。[CheckM2](https://github.com/chklovski/CheckM2)（访问 2026-10-14）。

### G07 Marker occupancy / 重复标记热图

**用途**：审查系统发育输入信息量及重复标记。**输入**：genome×marker 的缺失/单拷贝/多拷贝状态，标准 AA 覆盖率及实际 marker 集。**R；其他**：ComplexHeatmap；seaborn/Matplotlib。**误读**：marker 存在比例、MSA 非 gap 比例和完整度是三个指标；多拷贝不一定等于污染。**验收**：bac120/ar53 分域；缺失、重复和未评估使用不同状态；分母与准入规则可重算。[GTDB-Tk marker summary](https://ecogenomics.github.io/GTDBTk/files/markers_summary.tsv.html)（访问 2026-10-14）。

### G08 Bin 去向 Sankey / alluvial

**用途**：展示原始候选、精修、吸收/拆分、保留与未入树的去向。**输入**：contig 级源→目标对应与 bp；另有 bin 级状态表。**R；其他**：ggplot2 搭配经核验的 alluvial 扩展；Plotly Sankey。**误读**：拆分/合并时 bin 个数不守恒；不能把源 bin 数作为流量后强行让各节点守恒。**验收**：使用不重叠 contig-bp 流量或明确可重复归属口径；所有未分配/移除边可查，原303 bins的归档与去向逐一对账。

### G09 Bin 内污染诊断面板

**用途**：为人工复核定位可疑 contig，辅助精修。**输入**：bin-contig 成员表、GC/coverage、分类一致性、标记位置/拷贝、序列长度。**R；其他**：ggplot2 多面板、ComplexHeatmap；BlobToolKit、IGV。**误读**：离群点只能提供候选证据，不能通过绘图静默删除 contig；嵌合、水平转移与真实稀有片段可能相似。**验收**：每个标记点可定位 contig 与证据；展示前后成员集合不被修改；建议删除与已执行删除分开记录。

## 基因组比较

### G10 ANI 比较矩阵

**用途**：显示核苷酸层面的基因组相似性。**输入**：成对 ANI、比较方向、比对/片段覆盖、算法/参数及 genome ID。**R；其他**：ComplexHeatmap；seaborn、FastANI 输出适配。**误读**：无足够比对不是 ANI=0；方向性输出不能未经定义就平均成对称值；热图聚类不等于系统发育。**验收**：ANI 与覆盖分开编码，低覆盖/缺测标 NA，百分数刻度和对称化策略明示。[FastANI](https://github.com/ParBLiSS/FastANI)（访问 2026-10-14）。

### G11 AAI 比较矩阵

**用途**：比较实际匹配蛋白集合的氨基酸相似性。**输入**：成对 AAI、匹配蛋白数、覆盖/同源规则、蛋白预测及算法版本。**R；其他**：ComplexHeatmap；Matplotlib，已有 CompareM 或其他经核验的 AAI 输出。**误读**：AAI 与 ANI 的序列层级、匹配集合和覆盖不同；不能共用阈值解释或拿 AAI 填补缺失 ANI。**验收**：独立面板/图例，低覆盖隐藏规则可追溯，输入蛋白与基因组 ID 一一对应。[CompareM 官方仓库](https://github.com/dparks1134/CompareM)（访问 2026-10-14；具体当前 CLI 须本机核验）。

### G12 dDDH 矩阵及区间

**用途**：呈现已计算的数字 DNA–DNA 杂交估计。**输入**：实际 dDDH 输出、使用公式、点估计/区间、比较基因组。**R；其他**：ggplot2 区间图或 ComplexHeatmap；GGDC 输出适配。**误读**：dDDH 不是 ANI，也不是湿实验 DDH；不同公式/质量条件不能混成同一矩阵，无区间结果时不补造区间。**验收**：公式、单位、区间类型与来源逐项记录；在线计算涉及序列外传时先核对授权。[DSMZ GGDC FAQ](https://ggdc.dsmz.de/faq.php)（访问 2026-10-14）。

### G13 泛基因组存在/缺失矩阵

**用途**：显示同一比较范围内基因簇分布。**输入**：gene-cluster×genome 矩阵、簇定义、拷贝数/二元规则、基因组质量与树。**R；其他**：ComplexHeatmap；panX、seaborn。**误读**：MAG 未检出可能是缺组装，不等于真实缺失；跨极远类群不能直接套用单物种泛基因组流程。**验收**：0/1/未评估分开，拷贝数不偷换 presence，簇/样本顺序及纳入范围锁定。[panX](https://pangenome.org/)、[Roary 范围限制](https://sanger-pathogens.github.io/Roary/)（访问 2026-10-14）。

### G14 泛基因组积累 / 开放性

**用途**：考察增加基因组后基因簇与核心集合的变化。**输入**：固定簇矩阵、抽样顺序/置换种子、每轮 n、原始曲线及拟合结果。**R；其他**：ggplot2 线带；Python 数值计算后 Matplotlib。**误读**：拟合“开放”依赖抽样与模型，不是菌种固有定论；不完整 MAG 会制造缺失与伪新增。**验收**：区间明确是置换分布还是模型不确定度，核心规则、重复株处理、拟合区间与外推范围注明；不凭曲线外形宣布显著性。

### G15 全基因组共线性

**用途**：比较保守块、方向与重排候选。**输入**：FASTA/GenBank、序列长度、已计算的对齐块和 identity、方向。**R；其他**：gggenomes；pyGenomeViz。**误读**：未连线可能是阈值过滤而非不存在；任意 contig 排序可能制造重排；连接色不能混用 identity 与类别。**验收**：坐标/方向/反转规则、过滤阈值、是否比例缩放、所有拼接间隙可见，未比对区域保留。

### G16 基因邻域 / operon 候选

**用途**：检查功能基因周边和保守排列。**输入**：GFF3/GenBank、contig ID、start/end/strand、稳定基因 ID、同源组。**R；其他**：gggenes；pyGenomeViz。**误读**：相邻不证明共转录；反向链不是“负长度”；不同邻域独立缩放会夸大相似性。**验收**：坐标基制转换明确；箭头方向、邻域窗口、跨 contig 边界及标签映射正确。

### G17 环形基因组 / 轨道图

**用途**：整合 CDS、GC/GC-skew、coverage 和比较区段。**输入**：每条 replicon 的长度/拓扑证据、注释与有窗口定义的数值轨道。**R；其他**：circlize；经核验的专用圈图程序。**误读**：环形布局不证明闭环组装；不能把不同 MAG contigs 静默接成闭合染色体；GC-skew 不直接证明复制起点。**验收**：contig 分隔、未闭环声明、轨道单位/窗口/方向/尺度明确；输出坐标映射与 SVG/PDF。

## 功能与移动元件

基因级 TPM、多库注释、KEGG module/pathway 逐层追溯与 contig 功能关联，使用扩展的[功能图谱](functional-atlas.md)和[数据契约](functional-data-contract.md)；统计共丰度模块另见[WGCNA](wgcna.md)。下面保留通用图种入口。

### G18 通路富集气泡图

**用途**：总结真实富集检验的效应与不确定性。**输入**：通路 ID、命中/背景计数、gene ratio 定义、检验、原始 P 和校正 P、比较方向。**R；其他**：ggplot2；Matplotlib/Plotly。**误读**：通路丰度高不等于富集；只拿显著基因构造背景会偏倚；一个基因可命中多通路。**验收**：背景集合可重建，气泡面积含义明确，颜色注明 FDR/效应方向；q=0 的显示截断不更改原值。

### G19 功能/通路丰度热图

**用途**：呈现功能谱与样本间模式。**输入**：功能×样本丰度，单位/归一化/分层规则、注释与库版本。**R；其他**：ComplexHeatmap；seaborn，HUMAnN 表适配。**误读**：行 z-score 只表示同功能相对变化，不能比较功能绝对大小；stratified 与 unstratified 行相加会重复计数；基因潜力不是代谢通量。**验收**：转化前数据另存；未检出/NA/结构性不适用分开；矩阵顺序与样本元数据一致。[HUMAnN](https://huttenhower.sph.harvard.edu/humann/)（访问 2026-10-14）。

### G20 KEGG 通路映射图

**用途**：将已审核的 KO/基因层数值放到实际通路节点。**输入**：KO 或物种基因 ID、明确数值、通路 ID、映射版本。**R；其他**：pathview；KEGG Mapper。**误读**：节点着色不证明完整通路/活性，节点可对应多个基因；自动合并多值会改变解释。**验收**：未映射 ID 比例、节点聚合方法与色标记录；保留原 ID→节点表、图源和许可说明；没有外传授权只制作本地待导入数据。[KEGG Mapper](https://www.kegg.jp/kegg/mapper/)、[pathview](https://bioconductor.org/packages/release/bioc/html/pathview.html)（访问 2026-10-14）。

### G21 CAZy / CAZyme 谱

**用途**：比較碳水化合物相关酶家族与候选基因簇。**输入**：gene/domain→family 注释、命中方法/阈值、样本量化、数据库版本。**R；其他**：ggplot2 分组图或 ComplexHeatmap；dbCAN 输出适配。**误读**：family 不必唯一决定底物；一蛋白多 domain 不能当多个独立基因；拷贝数不等于酶活性。**验收**：按 gene/domain/family 的计数规则明确，重复命中处理一致，样本分母与单位可查。[dbCAN](https://run-dbcan.readthedocs.io/en/latest/)（访问 2026-10-14）。

### G22 AMR 基因/突变谱

**用途**：展示基因、突变与药物类别注释。**输入**：实际命中表、覆盖/identity、调用类别、物种上下文、AMR 库版本及定量单位。**R；其他**：ComplexHeatmap；NCBI AMRFinderPlus 输出适配。**误读**：序列命中不能等同耐药表型或临床 MIC；负结果取决检测限和覆盖，药物类别多映射会重复计数。**验收**：保留不确定命中、区分基因与点突变，数据库与阈值写入图注。[AMRFinderPlus](https://github.com/ncbi/amr)（访问 2026-10-14）。

### G23 毒力相关基因谱

**用途**：审查已注释的毒力相关特征分布。**输入**：gene、功能类别、参考命中、覆盖、库版本及样本/基因组。**R；其他**：ggplot2/ComplexHeatmap；已验证注释结果适配。**误读**：同源片段不证明完整毒力系统或致病性；多类注释不宜求和当唯一基因数。**验收**：标签写“毒力相关注释/候选”，保留 identity/coverage 和存在证据；不生成未经实验支持的风险评级。

### G24 移动元件–质粒–病毒–宿主网络

**用途**：整合候选连接与证据类型，挑选待验证关系。**输入**：nodes(ID/type/sample)、edges(source/target/evidence/score/direction)、预测阈值。**R；其他**：经核验的 igraph/ggraph；Cytoscape、Gephi。**误读**：共现不等于感染/转移；不同算法分数不能混成统一置信度；布局距离不等于生物距离。**验收**：宿主预测与实验证据分层，孤立节点保留；边数去重、阈值、布局种子/坐标和证据表随图交付。

## 变异、实验与其他组学

### G25 SNV / 等位基因频率图

**用途**：展示可信位点的频率变化或群体异质性。**输入**：VCF/BCF 或审核表，REF/ALT、AD/DP、过滤、样本与统一参考版本。**R；其他**：ggplot2；bcftools 导出后 Matplotlib、IGV。**误读**：低覆盖的未调用不是频率0；混菌株频率不能直接当二倍体基因型；多等位位点不能随意合并。**验收**：频率分母与过滤后计数一致，深度/链偏好/比对质量规则可追溯，NA可见。[bcftools](https://samtools.github.io/bcftools/bcftools.html)（访问 2026-10-14）。

### G26 基因组深度轨道

**用途**：检查覆盖缺口、异常深度及候选结构事件。**输入**：同参考的 BAM/CRAM+索引、FASTA/索引、bedGraph/bigWig 或逐位深度、MAPQ/重复/配对计数策略。**R；其他**：ggplot2 轨道；IGV。**误读**：局部高深度也可能是多重比对；自动 y 轴会夸大不同样本差异；下采样显示不是全 reads 证据。**验收**：reference hash、坐标约定、窗口聚合、0 深度区间与统一/独立尺度显式记录；截图附区间与 session。[IGV Desktop](https://igv.org/doc/desktop/)（访问 2026-10-14）。

### G27 生长曲线（OD）

**用途**：显示生长动力学与实际拟合区间。**输入**：time、OD 波长、空白、稀释/光程、培养条件和生物/技术重复 ID。**R；其他**：ggplot2；Matplotlib，已核验的模型输出。**误读**：OD 不等于活菌数；饱和区或未经空白校正曲线不适合盲拟增长率。**验收**：原曲线与处理曲线可追溯；重复层级、误差条含义、时间单位与增长率拟合范围明确。

### G28 log CFU / 存活曲线

**用途**：比较培养可检出的活菌负荷变化。**输入**：实际菌落数、稀释倍数、接种体积、样本质量/体积、检出限及重复。**R；其他**：ggplot2；Matplotlib。**误读**：0 菌落是低于检测限，不能直接取 log10(0) 或假装无菌；技术平板不当独立动物。**验收**：单位 CFU/mL 或 CFU/g 与换算一致；删失点、LOD、计数范围和汇总层级画清。

### G29 抑制 / 剂量反应

**用途**：展示浓度与实际测得生长/活性抑制关系。**输入**：数值剂量/单位、溶剂和零剂量对照、响应定义、重复及已拟合参数/区间。**R；其他**：ggplot2+drc；已审核模型后 Python 绘图。**误读**：抑菌圈直径不能直接当 MIC/IC50；剂量未跨越半效应就不能强称测得 IC50；C/L/M/H 不能编成等间距数值。**验收**：响应方向、上下限、对照归一化、模型/区间方法、外推和删失明确。[drc 手册](https://cran.r-universe.dev/drc/doc/manual.html)（访问 2026-10-14）。

### G30 空间分布 / FISH 图像

**用途**：显示真实空间定位与经验证分割对象。**输入**：原始图像、像素尺度、通道/曝光、z 切片或投影方式、ROI 和对照。**R；其他**：ggplot2 展示已验证对象表；Fiji/ImageJ 原图与 overlay。**误读**：视野不是独立生物重复；阈值与串色会影响共定位；不能用示意图替代实验照片。**验收**：比例尺来自 calibration，亮度处理跨组一致且记录，原图/ROI/分割保留，代表视野选择有依据。[ImageJ spatial calibration](https://imagej.net/imaging/spatial-calibration)（访问 2026-10-14）。

### G31 纵向/重复测量时间序列

**用途**：观察同一实验单位随时间的变化。**输入**：sample、subject/cage、真实采样时间、处理及已定义单位的特征值。**R；其他**：ggplot2 个体轨迹/汇总；Plotly。**误读**：横断面不同动物不能画作同一主体连线；每个时间点不是额外独立重复，平滑线不是拟合因果。**验收**：subject/cage 连线正确，缺测间隔与不规则时间可见；重复测量统计只引用实际模型结果。

### G32 宏转录组功能响应

**用途**：展示转录本/功能表达和已估计差异。**输入**：计数、library/批次/配对信息、注释与模型结果；若 RNA/DNA 联合，须有对应 DNA 定量。**R；其他**：ggplot2、ComplexHeatmap；HUMAnN 输出/Python。**误读**：RNA丰度混合了菌量与单位菌表达；TPM不可冒充原始计数送入要求 counts 的模型；宏基因组不能替代转录组。**验收**：原始量与展示变换分开，设计矩阵/分母/配对正确，未测 RNA 不画“表达”。[HUMAnN](https://huttenhower.sph.harvard.edu/humann/)、[DESeq2](https://bioconductor.org/packages/release/bioc/html/DESeq2.html)（访问 2026-10-14）。

### G33 SIP 密度分布 / 同位素富集

**用途**：显示真实标记样品的密度位移或已计算同位素富集。**输入**：标记/未标记对照、梯度分馏密度、DNA量/定量计数、fraction×taxon 表及 qSIP 等计算结果。**R；其他**：HTSSIP 输出+ggplot2；Matplotlib。**误读**：高 GC 本身影响密度；只见重馏分 reads 不等于定量同位素掺入；普通宏基因组不能推算 atom%。**验收**：密度标定、回收/归一化、对照、重复与区间来源明确；没有同位素实验就不生成此图。[HTSSIP](https://github.com/nick-youngblut/HTSSIP)（访问 2026-10-14）。

### G34 宏蛋白组通路/蛋白组图

**用途**：总结实际鉴定和定量蛋白的功能模式。**输入**：经 FDR 控制的 peptide/protein-group 表、共享肽处理、强度/谱计数、样本与功能映射。**R；其他**：ComplexHeatmap、ggplot2，适用时处理 MSstats 结果；Python。**误读**：一个共享肽不能唯一分配多个物种；基因存在不能冒充蛋白检测；缺失强度不自动等于零。**验收**：鉴定/定量 FDR 与层级明确，protein-group→通路聚合避免重复，缺失/插补方法可追溯。[MSstats](https://bioconductor.org/packages/release/bioc/html/MSstats.html)（访问 2026-10-14）。

## 交付时的逐图验收

选取至少一个原始样本/基因组逐值回查，确认主图、图例和下载表一致。数值图检查单位、分母、NA、对数轴、误差/支持度类型；坐标图检查参考与方向；网络检查边证据；图像检查标尺与原图。大图提供概览与可读细节，不用无限增大画布掩盖标签不可读。SVG/PDF 的文字、图例和密集区域须实际打开检查，保存实际视觉验收记录；文件存在不等于图已通过验收。
