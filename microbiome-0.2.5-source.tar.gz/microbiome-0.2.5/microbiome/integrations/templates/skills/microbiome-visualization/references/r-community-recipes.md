# 群落图形的 12 个 R 配方

这是可适配的源码参考。R 代码块可单独做语法检查，公共纯 base R 辅助函数可隔离验证；**完整绘图与高级分析配方仍未运行验收，不能把语法检查当成出图成功**。使用前核对实际 R/包版本；不自动安装。先运行公共块，再选择一个配方，按下面的精确 schema 准备数据并替换文件名。预期科学图、纳入集、分母、模型及变换沿用已有约定；不要为得到漂亮分组改参数。

2026-10-14 本机有限验证：R 4.4.1 `--vanilla` 对全部14个R代码块 `parse()` 通过；隔离执行22项纯base/数值边界检查通过，覆盖新文件/已有文件/悬空链接、ID、数值、唯一键、单行矩阵及火山图数值0与极小正q；`grDevices::svg` 基础设备实写通过（出现 Fontconfig 初始化警告）。这些检查未加载/运行完整 ggplot2 或高级包配方，也未完成视觉或科学验收。

| 配方 | 处理性质 | 最低包（除 base R） |
| --- | --- | --- |
| R01 组成堆积柱 | 绘图 + 已归一化比例的展示分组 | ggplot2, digest |
| R02 α 原始点与箱线 | 已有指标重绘；箱线为描述摘要，无检验 | ggplot2, digest |
| R03 分类 alluvial | 已有路径权重重绘 | ggplot2, digest, ggalluvial |
| R04 稀释/覆盖度曲线 | 已有估计及CI重绘，不重新稀释/外推 | ggplot2, digest |
| R05 排序散点 | 已有坐标重绘，不重新计算距离/排序 | ggplot2, digest |
| R06 Hellinger-PCA | **计算变换及排序**，无组间检验；须已批准该分析 | ggplot2, digest, vegan |
| R07 分类/功能热图 | 已有显示尺度矩阵重绘，不重新标准化/聚类 | ggplot2, digest, ComplexHeatmap, circlize |
| R08 forest/volcano/MA | 已有模型估计重绘，不拟合模型/生成CI/FDR | ggplot2, digest |
| R09 UpSet | 已定义二元集合的描述计数与绘图 | ggplot2, digest, ComplexUpset |
| R10 时间轨迹/配对线 | 已有测量重绘，无平滑/混合模型/配对检验 | ggplot2, digest |
| R11 关联网络 | 已有边的布局与绘图，不估计相关/网络 | ggplot2, digest, igraph |
| R12 距离热图/dispersion点图 | 已有距离及到中心距离重绘，无PERMANOVA/PERMDISP | ggplot2, digest |

本项目独立单位为12个笼混样、每组3笼。`biological_unit_id` 必须是笼，不是MAG；不能把每笼5只小鼠拆成并不存在的个体测量。重复测量的多个样本仍属于同一单位。更多图型/科学边界见 [community-atlas.md](community-atlas.md)。

## 公共块：身份、数值与独立输出

`metadata.tsv` 每行一个实际测量样本，必需 `sample_id,biological_unit_id,group,batch`。ID与group非空无首尾空格，sample_id唯一；这组简单配方假定一个单位对应固定group，交叉设计需另行适配。batch缺失写 `Unknown`，不能伪造批次。矩阵/图数据出现不同样本集合时默认停止；经批准的子集应提供其对应的元数据和排除清单。

另需单行 `figure_context.tsv`：`dataset_kind,source_run,source_scientific_status,description`。dataset_kind为biological或synthetic；source_scientific_status为unverified、validated或synthetic_fixture，合成数据必须使用后者。填写实际源run；未知来源须显式记录unverified，不能冒称validated。

该块只检查输入并建立新目录；图形一直标为 PREVIEW，合成数据始终另标SYNTHETIC。保存 input hash 和实际 `sessionInfo`，不生成“科学已验收”声明。现有来源 run、筛选、转换和科学状态仍需随交付清单保存；以下轻量文件并不替代完整 figure contract。

```r
need <- function(pkg) {
  if (!requireNamespace(pkg, quietly = TRUE))
    stop("Missing package; no installation attempted: ", pkg)
}
need("ggplot2"); need("digest")
library(ggplot2)
out_dir <- "community_preview_new"  # 改为新的隔离目录；不覆盖已有目录
stopifnot(!file.exists(out_dir), !dir.exists(out_dir))
stopifnot(dir.create(out_dir, recursive = FALSE))
fresh <- function(name) {
  p <- file.path(out_dir, name)
  link <- Sys.readlink(p)
  if (file.exists(p) || (!is.na(link) && nzchar(link))) stop("Output exists: ", p)
  p
}
check_id <- function(x) {
  stopifnot(!anyNA(x), all(nzchar(x)), all(x == trimws(x)),
            !any(grepl("[\t\r\n]", x)))
  invisible(x)
}
unique_key <- function(d, cols) {
  for (k in cols) check_id(d[[k]])
  stopifnot(!anyDuplicated(d[cols]))
}
number <- function(x, nonnegative = FALSE, allow_na = FALSE) {
  y <- suppressWarnings(as.numeric(x))
  allowed_missing <- is.na(x) | x == ""
  stopifnot(all(is.finite(y) | (allow_na & allowed_missing)))
  if (nonnegative) stopifnot(all(y[!is.na(y)] >= 0))
  y
}
read_tsv <- function(path, required) {
  d <- read.delim(path, colClasses = "character", check.names = FALSE,
                  quote = "", comment.char = "", fill = FALSE,
                  na.strings = "NA", stringsAsFactors = FALSE)
  check_id(names(d)); stopifnot(!anyDuplicated(names(d)), nrow(d) > 0,
                              all(required %in% names(d)))
  receipt <- data.frame(path = normalizePath(path, mustWork = TRUE),
                        sha256 = digest::digest(file = path, algo = "sha256"))
  f <- file.path(out_dir, "input_hashes.tsv")
  write.table(receipt, f, sep = "\t", row.names = FALSE, quote = FALSE,
              col.names = !file.exists(f), append = file.exists(f))
  d
}
one <- function(x) {
  check_id(x); stopifnot(length(unique(x)) == 1L); unique(x)[1]
}
context <- read_tsv("figure_context.tsv", c("dataset_kind", "source_run", "source_scientific_status", "description"))
stopifnot(nrow(context) == 1)
kind <- one(context$dataset_kind); scientific_status <- one(context$source_scientific_status)
stopifnot(kind %in% c("biological", "synthetic"),
          scientific_status %in% c("unverified", "validated", "synthetic_fixture"),
          (kind == "synthetic") == (scientific_status == "synthetic_fixture"))
preview_banner <- paste("PREVIEW", toupper(kind), one(context$source_run), scientific_status, sep = " | ")
meta <- read_tsv("metadata.tsv", c("sample_id", "biological_unit_id", "group", "batch"))
unique_key(meta, "sample_id")
check_id(meta$biological_unit_id); check_id(meta$group)
stopifnot(all(vapply(split(meta$group, meta$biological_unit_id),
                    function(z) length(unique(z)) == 1L, logical(1))))
group_levels <- unique(c(intersect(c("C", "L", "M", "H"), meta$group),
                         sort(setdiff(meta$group, c("C", "L", "M", "H")))))
group_colours <- c(C = "#009E73", L = "#56B4E9", M = "#E69F00", H = "#CC79A7")
extra <- setdiff(group_levels, names(group_colours))
if (length(extra)) group_colours <- c(group_colours,
    setNames(grDevices::hcl.colors(length(extra), "Dark 3"), extra))
add_meta <- function(d, full = TRUE) {
  check_id(d$sample_id)
  ix <- match(d$sample_id, meta$sample_id); stopifnot(!anyNA(ix))
  if (full) stopifnot(setequal(d$sample_id, meta$sample_id))
  if ("group" %in% names(d)) stopifnot(identical(d$group, meta$group[ix]))
  d$group <- factor(meta$group[ix], levels = group_levels)
  d$biological_unit_id <- meta$biological_unit_id[ix]
  d
}
colour_groups <- function() scale_colour_manual(values = group_colours,
                                                  limits = group_levels, drop = FALSE)
save_plot <- function(p, name, width = 9, height = 6) {
  p <- p + labs(subtitle = preview_banner)
  ggsave(fresh(paste0(name, ".pdf")), p, width = width, height = height)
  ggsave(fresh(paste0(name, ".png")), p, width = width, height = height, dpi = 180)
  ggsave(fresh(paste0(name, ".svg")), p, width = width, height = height, device = grDevices::svg)
  print(p)
}
save_table <- function(d, name) write.table(d, fresh(name), sep = "\t",
                                            quote = FALSE, row.names = FALSE, na = "NA")
```

输入路径与输出目录应分离。代码不做缺失值插补；`NA`必须保留含义，不能为了通过验证改写为0。共享 sample/cage 信息来自元数据，不能由文件名猜测。

## R01 — 每样本组成堆积柱

输入 `relative_abundance.tsv`：`sample_id,taxon_id,abundance`，同一分类层级；唯一 sample×taxon，完整笛卡尔表（含观测0），比例[0,1]且每样本和为1。未分类需有显式taxon ID；相对某一子集的分母必须在标题声明。只将已有比例的全样本平均最高10类保留独立颜色，余项汇总；不按处理组挑选Top taxa。

```r
d <- read_tsv("relative_abundance.tsv", c("sample_id", "taxon_id", "abundance"))
unique_key(d, c("sample_id", "taxon_id")); d <- add_meta(d)
d$abundance <- number(d$abundance, nonnegative = TRUE)
stopifnot(all(d$abundance <= 1),
          nrow(d) == length(unique(d$sample_id)) * length(unique(d$taxon_id)),
          all(abs(tapply(d$abundance, d$sample_id, sum) - 1) < 1e-6),
          !"__OTHER_DISPLAY__" %in% d$taxon_id)
mean_ab <- tapply(d$abundance, d$taxon_id, mean)
top <- names(mean_ab)[order(-mean_ab, names(mean_ab))][seq_len(min(10, length(mean_ab)))]
d$display_taxon <- ifelse(d$taxon_id %in% top, d$taxon_id, "__OTHER_DISPLAY__")
save_table(unique(d[c("taxon_id", "display_taxon")]), "R01_taxon_display_mapping.tsv")
b <- aggregate(abundance ~ sample_id + display_taxon, d, sum)
b <- add_meta(b); b$sample_id <- factor(b$sample_id, levels = meta$sample_id)
p <- ggplot(b, aes(sample_id, abundance, fill = display_taxon)) +
  geom_col(width = .85) + facet_grid(~group, scales = "free_x", space = "free_x") +
  scale_y_continuous(labels = function(x) paste0(round(100 * x), "%")) +
  labs(x = "Biological sample", y = "Fraction of the declared feature universe", fill = "Taxon") +
  theme_bw() + theme(axis.text.x = element_text(angle = 60, hjust = 1))
save_table(b, "R01_plot_data.tsv"); save_plot(p, "R01_composition")
```

验收：每柱总和、全部sample ID、Top与Other映射及未分类份额；柱高不能解释为绝对菌量。[phyloseq bar语义](https://joey711.github.io/phyloseq/plot_bar-examples.html)

## R02 — α 指标原始点与描述箱线

输入 `alpha.tsv`：`sample_id,metric,value`；每sample×metric唯一，所有元数据样本均有行，未成功估计用NA而非删行。指标已由有记录的方法计算。当前12笼的每指标每笼只允许一次观测；纵向设计用R10。

```r
d <- read_tsv("alpha.tsv", c("sample_id", "metric", "value"))
unique_key(d, c("sample_id", "metric")); d <- add_meta(d)
for (metric in unique(d$metric)) {
  z <- d[d$metric == metric, ]
  stopifnot(setequal(z$sample_id, meta$sample_id), !anyDuplicated(z$biological_unit_id))
}
d$value <- number(d$value, allow_na = TRUE)
save_table(d[is.na(d$value), ], "R02_missing_values.tsv")
visible <- d[!is.na(d$value), ]; stopifnot(nrow(visible) > 0)
p <- ggplot(visible, aes(group, value, colour = group)) +
  geom_boxplot(width = .38, outlier.shape = NA, notch = FALSE) +
  geom_point(position = position_jitter(width = .09, height = 0, seed = 20261014), size = 2.8) +
  facet_wrap(~metric, scales = "free_y") + colour_groups() + theme_bw() +
  labs(x = "Treatment", y = "Recorded alpha metric", caption =
       paste("Raw biological units; missing estimates:", sum(is.na(d$value)), "; no hypothesis test"))
save_table(d, "R02_plot_data.tsv"); save_plot(p, "R02_alpha")
```

验收时逐facet核对实际n。箱线只是描述，当前n=3/组不增加violin/half-eye来推断分布形状；全体原始点保持可见。[ggplot2箱线](https://ggplot2.tidyverse.org/reference/geom_boxplot.html)

## R03 — 单一样本分类 alluvial

输入 `taxonomy_flows.tsv`：`sample_id,path_id,kingdom,phylum,genus,weight`；本配方一次只绘一个样本，每条path_id唯一，weight为非负已有权重；所有路径互斥，不能同时把父级总量当另一条路径。缺分类层级可空，显示为谱系内Unclassified。

```r
need("ggalluvial")
d <- read_tsv("taxonomy_flows.tsv", c("sample_id", "path_id", "kingdom", "phylum", "genus", "weight"))
unique_key(d, "path_id"); sample <- one(d$sample_id)
stopifnot(sample %in% meta$sample_id)
d$weight <- number(d$weight, nonnegative = TRUE); stopifnot(sum(d$weight) > 0)
for (v in c("kingdom", "phylum", "genus"))
  d[[v]][is.na(d[[v]]) | !nzchar(d[[v]])] <- "Unclassified"
stopifnot(!any(grepl("\\|", unlist(d[c("kingdom", "phylum", "genus")]))))
d$phylum_path <- paste(d$kingdom, d$phylum, sep = "|")
d$genus_path <- paste(d$phylum_path, d$genus, sep = "|")
p <- ggplot(d, aes(axis1 = kingdom, axis2 = phylum_path, axis3 = genus_path, y = weight)) +
  ggalluvial::geom_alluvium(aes(fill = phylum_path), width = 1/10, alpha = .75) +
  ggalluvial::geom_stratum(width = 1/10, colour = "grey40") +
  geom_text(stat = "stratum", aes(label = after_stat(stratum)), size = 2.5) +
  scale_x_discrete(limits = c("Kingdom", "Phylum path", "Genus path"), expand = c(.08, .08)) +
  labs(title = sample, y = "Recorded weight (declare unit in figure manifest)", x = NULL) + theme_minimal()
save_table(d, "R03_plot_data.tsv"); save_plot(p, "R03_alluvial", width = 13)
```

核对各轴权重和、重复属名的父谱系、宽度与标签；密集时使用已记录的分类层级聚合或分页，不能偷删小流。[ggalluvial官方数据形式](https://corybrunson.github.io/ggalluvial/articles/ggalluvial.html)

## R04 — 已有 rarefaction / coverage 曲线

输入 `sampling_curves.tsv`：`curve_id,sample_id,metric,x_unit,x,estimate,lower,upper,method`。x_unit一次只能是 `reads` 或 `coverage`；method为 `interpolated,observed,extrapolated`；每curve×method×x唯一。lower/upper是来源方法的同一水平CI，可二者一起NA；不能用组间SD冒充。保存生成曲线的上游参数，绘图不会调用 `rarefy` 或 `iNEXT`。

```r
d <- read_tsv("sampling_curves.tsv", c("curve_id", "sample_id", "metric", "x_unit", "x", "estimate", "lower", "upper", "method"))
unique_key(d, c("curve_id", "method", "x")); d <- add_meta(d)
metric <- one(d$metric); unit <- one(d$x_unit)
stopifnot(unit %in% c("reads", "coverage"), all(d$method %in% c("interpolated", "observed", "extrapolated")))
for (v in c("x", "estimate")) d[[v]] <- number(d[[v]], nonnegative = TRUE)
stopifnot(!anyDuplicated(d[c("curve_id", "method", "x")]),
          all(vapply(split(d$sample_id, d$curve_id), function(z) length(unique(z)) == 1L, logical(1))))
for (v in c("lower", "upper")) d[[v]] <- number(d[[v]], allow_na = TRUE)
stopifnot(all(is.na(d$lower) == is.na(d$upper)))
if (unit == "coverage") stopifnot(all(d$x <= 1))
ci <- d[!is.na(d$lower), ]; stopifnot(all(ci$lower <= ci$estimate), all(ci$estimate <= ci$upper))
p <- ggplot(d, aes(x, estimate, group = interaction(curve_id, method), colour = group)) +
  geom_ribbon(data = ci, aes(ymin = lower, ymax = upper, fill = group), alpha = .12, colour = NA) +
  geom_line(data = d[d$method != "observed", ], aes(linetype = method)) +
  geom_point(data = d[d$method == "observed", ], size = 2) +
  facet_wrap(~sample_id) + colour_groups() +
  scale_fill_manual(values = group_colours, limits = group_levels, drop = FALSE) +
  scale_linetype_manual(values = c(interpolated = "solid", extrapolated = "dashed")) +
  labs(x = unit, y = metric, caption = "Intervals and extrapolation are imported from the recorded upstream method") + theme_bw()
save_table(d, "R04_plot_data.tsv"); save_plot(p, "R04_sampling", width = 11, height = 8)
```

如果已有 iNEXT 对象，可改用 `ggiNEXT(object,type=1/2/3)`；先运行 `iNEXT()` 是计算估计，不属于此重绘配方。[iNEXT作者说明](https://github.com/AnneChao/iNEXT)

## R05 — 已有 PCoA/PCA/NMDS/t-SNE/UMAP 坐标

输入 `ordination_scores.tsv`：`sample_id,axis1,axis2,method,metric,transform,run_id,axis1_label,axis2_label`，每样本唯一、完整匹配meta，每个说明字段整表唯一。PCA/PCoA标签百分比必须源于同一原生结果且注明分母；NMDS/t-SNE/UMAP不填方差百分比。NMDS的stress另随源结果保存。

```r
d <- read_tsv("ordination_scores.tsv", c("sample_id", "axis1", "axis2", "method", "metric", "transform", "run_id", "axis1_label", "axis2_label"))
unique_key(d, "sample_id"); d <- add_meta(d)
for (v in c("axis1", "axis2")) d[[v]] <- number(d[[v]])
for (v in c("method", "metric", "transform", "run_id", "axis1_label", "axis2_label")) one(d[[v]])
p <- ggplot(d, aes(axis1, axis2, colour = group)) + geom_point(size = 3) +
  geom_text(aes(label = sample_id), vjust = -0.7, size = 2.7, show.legend = FALSE) +
  coord_equal() + colour_groups() + theme_bw() +
  labs(x = one(d$axis1_label), y = one(d$axis2_label),
       title = paste(one(d$method), one(d$metric), one(d$run_id)),
       caption = paste("Transform:", one(d$transform), "; no ellipse or group significance inferred"))
save_table(d, "R05_plot_data.tsv"); save_plot(p, "R05_ordination")
```

用batch形状/分面检查混杂须保留同一坐标；别因分离不好重做算法或删除样本。[phyloseq排序展示与方法区别](https://joey711.github.io/phyloseq/plot_ordination-examples.html)

## R06 — 显式计算 Hellinger-PCA（不是纯绘图）

仅当 **Hellinger变换后PCA已处于当前批准的分析范围** 时执行本段；否则使用R05导入已有结果。输入 `counts.tsv` 第一列 `feature_id`，其余列名恰好是meta中的sample_id，元素为完整非负整数计数，不能有NA或全零样本。这不是PCoA，不计算Bray/UniFrac，也不做PERMANOVA。方法固定为样本内相对丰度开方、列中心化、不按列方差再缩放。

```r
need("vegan")
d <- read_tsv("counts.tsv", "feature_id"); unique_key(d, "feature_id")
stopifnot(setequal(setdiff(names(d), "feature_id"), meta$sample_id))
count_mat <- do.call(cbind, lapply(d[meta$sample_id], function(x) number(x, nonnegative = TRUE)))
rownames(count_mat) <- d$feature_id
stopifnot(all(count_mat == round(count_mat)))
X <- t(count_mat); stopifnot(all(rowSums(X) > 0), nrow(X) >= 3, ncol(X) >= 2)
H <- vegan::decostand(X, method = "hellinger", MARGIN = 1)
fit <- stats::prcomp(H, center = TRUE, scale. = FALSE)
stopifnot(ncol(fit$x) >= 2, sum(fit$sdev^2) > 0)
fraction <- fit$sdev^2 / sum(fit$sdev^2)
scores <- add_meta(data.frame(sample_id = rownames(fit$x), axis1 = fit$x[, 1], axis2 = fit$x[, 2]))
saveRDS(list(fit = fit, transformed_matrix = H, method = "Hellinger PCA",
             center = TRUE, scale = FALSE), fresh("R06_analysis_object.rds"))
save_table(data.frame(axis = seq_along(fraction), variance_fraction = fraction), "R06_axis_variance.tsv")
save_table(scores, "R06_scores.tsv")
save_table(data.frame(feature_id = rownames(fit$rotation), fit$rotation, check.names = FALSE), "R06_loadings.tsv")
p <- ggplot(scores, aes(axis1, axis2, colour = group)) + geom_point(size = 3) +
  coord_equal() + colour_groups() + theme_bw() +
  labs(x = sprintf("PC1 (%.1f%% transformed variance)", 100 * fraction[1]),
       y = sprintf("PC2 (%.1f%% transformed variance)", 100 * fraction[2]),
       title = "Hellinger-PCA", caption = "New ordination computation; no inferential group test")
save_plot(p, "R06_hellinger_pca")
```

验收变换矩阵、样本顺序、每轴分母及载荷；Hellinger的零仍是零，没有加入伪计数。若需CLR-PCA、Bray-PCoA或NMDS，回到方法设计再指定零策略/距离/修正/stress，不在此代码里替换一个标签了事。[vegan decostand](https://vegandevs.github.io/vegan/reference/decostand.html)

## R07 — 已有显示尺度的 taxa/function heatmap

输入 `heatmap_values.tsv` 第一列 `feature_id`，其余列与meta样本集相同，有限数值或NA；矩阵**已经**处于约定的比例、log、CLR或行z尺度。另有单行 `heatmap_scale.tsv`：`value_scale,zero_policy,break_low,break_mid,break_high`；三break严格递增且覆盖所有有限值。本配方不选择TopN、不加伪计数、不做z-score、不重新聚类。

```r
need("ComplexHeatmap"); need("circlize")
d <- read_tsv("heatmap_values.tsv", "feature_id"); unique_key(d, "feature_id")
stopifnot(setequal(setdiff(names(d), "feature_id"), meta$sample_id))
mat <- do.call(cbind, lapply(d[meta$sample_id], function(x) number(x, allow_na = TRUE)))
rownames(mat) <- d$feature_id
s <- read_tsv("heatmap_scale.tsv", c("value_scale", "zero_policy", "break_low", "break_mid", "break_high"))
stopifnot(nrow(s) == 1, any(is.finite(mat)))
br <- number(unlist(s[c("break_low", "break_mid", "break_high")]))
stopifnot(all(diff(br) > 0), min(mat, na.rm = TRUE) >= br[1], max(mat, na.rm = TRUE) <= br[3])
ha <- ComplexHeatmap::HeatmapAnnotation(group = factor(meta$group, levels = group_levels),
                                       col = list(group = group_colours))
ht <- ComplexHeatmap::Heatmap(mat, name = one(s$value_scale),
       col = circlize::colorRamp2(br, c("#2166AC", "white", "#B2182B")), na_col = "grey70",
       cluster_rows = FALSE, cluster_columns = FALSE, top_annotation = ha,
       column_title = preview_banner,
       row_names_gp = grid::gpar(fontsize = 8), column_names_gp = grid::gpar(fontsize = 8))
grDevices::pdf(fresh("R07_heatmap.pdf"), width = 10, height = max(6, .15 * nrow(mat) + 2))
ComplexHeatmap::draw(ht); grDevices::dev.off()
save_table(data.frame(feature_id = rownames(mat), mat, check.names = FALSE), "R07_plot_data.tsv")
```

大量行时先设计完整分页/索引，不能把超长PDF缩成一页后宣称可读。灰色仅表示NA，白色是声明的break_mid，未必是0。功能热图同时保存数据库与单位，DNA功能丰度不等于表达。[ComplexHeatmap官方参考](https://jokergoo.github.io/ComplexHeatmap-reference/book/a-single-heatmap.html)

## R08 — 已有结果的 forest / volcano / MA

输入 `effects.tsv` 必需 `feature_id,contrast,method,effect_scale,null_effect,estimate,lower,upper,qvalue,tested,mean_abundance`。每feature一行，本段一次一对比/方法/尺度；tested为 `TRUE/FALSE`。lower/upper只能是已计算、已记录水平的CI（如95%），不能把SE直接改名；如无CI用NA并选volcano/MA。未检验/失败保留NA及tested=FALSE。附源模型formula、reference、n和过滤/FDR总体；MaAsLin还保存模型子类型。此schema是重绘适配层，不是任何软件的原生列名。

```r
d <- read_tsv("effects.tsv", c("feature_id", "contrast", "method", "effect_scale", "null_effect", "estimate", "lower", "upper", "qvalue", "tested", "mean_abundance"))
unique_key(d, "feature_id")
for (v in c("contrast", "method", "effect_scale", "null_effect")) one(d[[v]])
stopifnot(all(d$tested %in% c("TRUE", "FALSE")))
for (v in c("estimate", "lower", "upper", "qvalue", "mean_abundance"))
  d[[v]] <- number(d[[v]], allow_na = TRUE)
stopifnot(all(is.na(d$qvalue) | (d$qvalue >= 0 & d$qvalue <= 1)))
ref <- number(one(d$null_effect)); tested <- d[d$tested == "TRUE", ]
stopifnot(nrow(tested) > 0, all(is.finite(tested$estimate)))
mode <- "forest"  # 按已定图形改为 "volcano" 或 "MA"；不改变模型或显著性阈值
if (mode == "forest") {
  stopifnot(all(is.finite(tested$lower)), all(is.finite(tested$upper)),
            all(tested$lower <= tested$estimate), all(tested$estimate <= tested$upper))
  tested$feature_id <- factor(tested$feature_id, levels = tested$feature_id[order(tested$estimate)])
  p <- ggplot(tested, aes(estimate, feature_id)) +
    geom_vline(xintercept = ref, colour = "grey65") +
    geom_segment(aes(x = lower, xend = upper, yend = feature_id)) + geom_point(size = 2) +
    labs(x = one(d$effect_scale), y = NULL)
} else if (mode == "volcano") {
  stopifnot(all(is.finite(tested$qvalue)))
  tested$neglog10q <- -log10(tested$qvalue)
  tested$neglog10q[tested$qvalue == 0] <- 300  # 只为数值0设展示占位；正q不截断
  p <- ggplot(tested, aes(estimate, neglog10q)) + geom_point(aes(shape = qvalue == 0)) +
    labs(x = one(d$effect_scale), y = "-log10(q); q=0 placeholder=300 (not a bound)", shape = "q=0")
} else if (mode == "MA") {
  stopifnot(all(is.finite(tested$mean_abundance)), all(tested$mean_abundance > 0))
  p <- ggplot(tested, aes(log10(mean_abundance), estimate)) + geom_point() +
    geom_hline(yintercept = ref, colour = "grey65") +
    labs(x = "log10(mean abundance on the recorded upstream scale)", y = one(d$effect_scale))
} else stop("Unknown plot mode")
p <- p + theme_bw() + labs(title = paste(one(d$method), one(d$contrast)),
         caption = paste("Not tested:", sum(d$tested == "FALSE"), "; estimates are associations, not causal effects"))
save_table(d, "R08_all_input_results.tsv"); save_plot(p, paste0("R08_", mode))
```

q=0必须回查原生数值精度，不在报告中写p=0。图中300仅是数值0的显式展示占位，不代表真实-log10(q)下限；正q保留真实变换值，可超过300，原始q留在输入结果表。ANCOM-BC2的ln fold change不要直接标log2FC；MaAsLin系数须保留归一化/变换及模型字段；LEfSe LDA score不能塞进此图冒充fold change。[ANCOM-BC2](https://www.bioconductor.org/packages/release/bioc/vignettes/ANCOMBC/inst/doc/ANCOMBC2.html)、[MaAsLin2](https://github.com/biobakery/Maaslin2)、[MaAsLin3](https://github.com/biobakery/Maaslin3)

## R09 — 精确集合交集 UpSet

输入 `membership.tsv`：第一列feature_id，其余列为集合ID，值严格 `0/1`，行唯一；另有 `set_definitions.tsv`：`set_id,presence_rule,universe,n_independent_units`。例如每组“至少一笼检出”与“3/3笼均检出”必须写成不同规则。全集中不属于任何集合的特征也保留，单独报告。

```r
need("ComplexUpset")
d <- read_tsv("membership.tsv", "feature_id"); unique_key(d, "feature_id")
s <- read_tsv("set_definitions.tsv", c("set_id", "presence_rule", "universe", "n_independent_units"))
unique_key(s, "set_id"); one(s$universe); check_id(s$presence_rule)
sets <- s$set_id; stopifnot(setequal(sets, setdiff(names(d), "feature_id")), length(sets) >= 2)
n_units <- number(s$n_independent_units, nonnegative = TRUE)
stopifnot(all(n_units > 0), all(n_units == round(n_units)))
for (v in sets) { stopifnot(all(d[[v]] %in% c("0", "1"))); d[[v]] <- d[[v]] == "1" }
outside <- rowSums(as.matrix(d[sets])) == 0
save_table(d[outside, ], "R09_outside_all_sets.tsv")
p <- ComplexUpset::upset(d, sets, mode = "distinct", keep_empty_groups = TRUE,
                         min_size = 0, n_intersections = Inf, name = "Features") +
  labs(caption = paste("Distinct/exclusive intersections; outside all sets:", sum(outside)))
save_table(d, "R09_complete_membership.tsv"); save_plot(p, "R09_upset", width = 11)
```

空集合显示与全FALSE区域的具体呈现需对实际版本做视觉检查；用保存表逐一核对交集而非只看柱高。图不检验集合富集或组差异。[ComplexUpset modes](https://krassowski.github.io/complex-upset/articles/Examples_R.html)

## R10 — 真实重复测量 spaghetti / paired slope

输入 `trajectories.tsv`：`biological_unit_id,time,metric,value,group`，每unit×time×metric唯一；一次一个metric，time为真实数值时间。所有计划访视都要有行，未测value为NA；不能只删除缺测行后把长缺口画成连续变化。此表的单位必须存在于meta。配对模式需要全体单位的两个真实共同时间点与完整值，不自动删除不完整对。

```r
d <- read_tsv("trajectories.tsv", c("biological_unit_id", "time", "metric", "value", "group"))
unique_key(d, c("biological_unit_id", "time", "metric")); metric <- one(d$metric)
stopifnot(all(d$biological_unit_id %in% meta$biological_unit_id))
stopifnot(setequal(d$biological_unit_id, meta$biological_unit_id))
unit_group <- unique(meta[c("biological_unit_id", "group")])
stopifnot(identical(d$group, unit_group$group[match(d$biological_unit_id, unit_group$biological_unit_id)]))
d$time <- number(d$time); d$value <- number(d$value, allow_na = TRUE)
stopifnot(!anyDuplicated(d[c("biological_unit_id", "time")]))
d <- d[order(d$biological_unit_id, d$time), ]
d$group <- factor(d$group, levels = group_levels)
mode <- "longitudinal"  # 已有真实两时点配对时可选 "paired"
if (mode == "paired") {
  stopifnot(length(unique(d$time)) == 2, all(table(d$biological_unit_id) == 2), !anyNA(d$value))
} else stopifnot(mode == "longitudinal")
# 显式NA把每单位曲线切段；保留计划时间，不跨越已记录的缺访行。
d$segment <- ave(is.na(d$value), d$biological_unit_id, FUN = cumsum)
visible <- d[!is.na(d$value), ]; stopifnot(nrow(visible) > 0)
p <- ggplot(visible, aes(time, value, colour = group,
                        group = interaction(biological_unit_id, segment))) +
  geom_line(alpha = .55) + geom_point(size = 2.2) + colour_groups() + theme_bw() +
  labs(x = "Recorded time (declare unit)", y = metric,
       caption = paste("Biological units:", length(unique(d$biological_unit_id)),
                       "; scheduled missing values:", sum(is.na(d$value))))
save_table(d, "R10_complete_visits.tsv"); save_plot(p, paste0("R10_", mode))
```

本DBDPE数据若仅有一次横断面测量，R10不适用。不能把C/L/M/H按剂量序号连成同一个体的时间轨迹。

## R11 — 已有边表的无向关联网络

输入 `nodes.tsv`：`feature_id,label,feature_type`，包含孤立点；`edges.tsv`：`source,target,estimate,method,source_run,n_units`，可附q或stability原始列，但不得互换。每无序节点对仅一条边、无自环、端点均在nodes。边已经由记录的方法/阈值选定，此配方不估计任何网络、不再筛边。方向未知，所以画无向图。

```r
need("igraph")
v <- read_tsv("nodes.tsv", c("feature_id", "label", "feature_type")); unique_key(v, "feature_id")
e <- read_tsv("edges.tsv", c("source", "target", "estimate", "method", "source_run", "n_units"))
check_id(e$source); check_id(e$target); one(e$method); one(e$source_run)
stopifnot(all(e$source %in% v$feature_id), all(e$target %in% v$feature_id), all(e$source != e$target))
pair <- data.frame(a = pmin(e$source, e$target), b = pmax(e$source, e$target))
stopifnot(!anyDuplicated(pair))
e$estimate <- number(e$estimate); e$n_units <- number(e$n_units, nonnegative = TRUE)
stopifnot(all(e$n_units > 0), all(e$n_units == round(e$n_units)))
g <- igraph::graph_from_data_frame(e, directed = FALSE, vertices = v)
edge_col <- ifelse(e$estimate > 0, "#B2182B", ifelse(e$estimate < 0, "#2166AC", "grey65"))
# 固定圆形布局只处理展示；不用边权调用额外优化或推断中心性。
layout <- igraph::layout_in_circle(g, order = order(igraph::V(g)$name))
grDevices::pdf(fresh("R11_network.pdf"), width = 10, height = 10)
plot(g, layout = layout, vertex.label = igraph::V(g)$label, vertex.size = 6,
     vertex.color = "grey85", vertex.label.cex = .65,
     edge.color = edge_col, edge.width = 1.2, main = preview_banner,
     sub = "Recorded associations; not ecological interactions")
legend("topleft", c("Positive", "Negative", "Zero"), col = c("#B2182B", "#2166AC", "grey65"), lty = 1, bty = "n")
grDevices::dev.off()
stopifnot(igraph::vcount(g) == nrow(v), igraph::ecount(g) == nrow(e))
save_table(data.frame(feature_id = igraph::V(g)$name, x = layout[, 1], y = layout[, 2]), "R11_node_coordinates.tsv")
save_table(v, "R11_all_nodes.tsv"); save_table(e, "R11_all_edges.tsv")
```

若上游没有边，交付“未推断/无入选边”的节点表和说明，不人为补边。n=12的高维网络需特别说明稳定性，布局团块不能充当新的生态结论。[igraph接口与孤立节点](https://r.igraph.org/reference/graph_from_data_frame.html)、[SPIEC-EASI推断与绘图区别](https://github.com/zdk123/SpiecEasi)

## R12 — 已有距离矩阵和 beta dispersion

输入 `distance.tsv` 第一列sample_id，余列是同一全体sample ID，有限非负、对称、零对角。另有 `distance_contract.tsv` 单行 `metric,transform,run_id`。可选 `dispersion.tsv`：`sample_id,distance_to_center,center_method,metric,transform`，来源于同一D与纳入集，center_method须明确median或centroid。下面只有绘图，不调用 `vegdist/betadisper/adonis2/permutest`。

```r
d <- read_tsv("distance.tsv", "sample_id"); unique_key(d, "sample_id")
stopifnot(setequal(d$sample_id, meta$sample_id), setequal(setdiff(names(d), "sample_id"), meta$sample_id))
d <- d[match(meta$sample_id, d$sample_id), ]
D <- do.call(cbind, lapply(d[meta$sample_id], function(x) number(x, nonnegative = TRUE)))
rownames(D) <- d$sample_id
stopifnot(max(abs(D - t(D))) < 1e-8, all(abs(diag(D)) < 1e-8))
contract <- read_tsv("distance_contract.tsv", c("metric", "transform", "run_id")); stopifnot(nrow(contract) == 1)
z <- expand.grid(sample_i = meta$sample_id, sample_j = meta$sample_id, stringsAsFactors = FALSE)
z$distance <- as.vector(D)
z$sample_i <- factor(z$sample_i, levels = meta$sample_id)
z$sample_j <- factor(z$sample_j, levels = rev(meta$sample_id))
p <- ggplot(z, aes(sample_i, sample_j, fill = distance)) + geom_tile() + coord_equal() +
  scale_fill_viridis_c() + theme_bw() + theme(axis.text.x = element_text(angle = 60, hjust = 1)) +
  labs(x = NULL, y = NULL, title = paste(one(contract$metric), one(contract$transform), one(contract$run_id)))
save_table(z, "R12_distance_plot_data.tsv"); save_plot(p, "R12_distance")

if (file.exists("dispersion.tsv")) {  # 只在已有结果文件存在时重绘
  b <- read_tsv("dispersion.tsv", c("sample_id", "distance_to_center", "center_method", "metric", "transform"))
  unique_key(b, "sample_id"); b <- add_meta(b)
  stopifnot(one(b$center_method) %in% c("median", "centroid"),
            one(b$metric) == one(contract$metric), one(b$transform) == one(contract$transform))
  b$distance_to_center <- number(b$distance_to_center, nonnegative = TRUE)
  p <- ggplot(b, aes(group, distance_to_center, colour = group)) +
    geom_point(position = position_jitter(width = .08, height = 0, seed = 20261014), size = 3) +
    colour_groups() + theme_bw() + labs(x = "Treatment", y = paste("Distance to", one(b$center_method)),
      caption = "Imported dispersion distances; no dispersion or PERMANOVA test run")
  save_table(b, "R12_dispersion_plot_data.tsv"); save_plot(p, "R12_dispersion")
}
```

PERMANOVA如已运行，结果与原模型/置换方案一起呈现；dispersion小样本不显著不能证明组差异完全来自中心位置。[vegan adonis2](https://vegandevs.github.io/vegan/reference/adonis.html)、[betadisper](https://vegandevs.github.io/vegan/reference/betadisper.html)

## 执行后交付与验证

```r
# 在选定配方运行完成后记录实际会话；本句本身不表示视觉或科学验收。
writeLines(capture.output(sessionInfo()), fresh("R_sessionInfo.txt"))
writeLines(c(preview_banner, "Visual QA pending; scientific pipeline status unchanged."), fresh("STATUS.txt"))
```

验收图中的实际样本数/独立单位数、ID对应、分母和单位、NA与零、原生效应尺度、面板间配色、完整数据表及所读输入hash；按最终使用尺寸打开PDF/PNG，检查标签、图例、分页和颜色。代码通过、文件存在或有图片都不等于正式科学结果。若生成了计算产物（R06），单独记录其分析状态和授权来源，不将它登记成现有引擎已通过的pretest。

本页官方文档访问核验日期：**2026-10-14**。ggplot/phyloseq/vegan等文档接口与本机版本可能不同，修改参数前查本地帮助。这里没有安装步骤、自动检验、批次校正、差异分析拟合、网络推断或生产晋级操作。
