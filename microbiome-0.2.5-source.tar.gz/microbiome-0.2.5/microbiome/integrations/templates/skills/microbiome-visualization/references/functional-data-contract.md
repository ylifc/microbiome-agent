# 功能注释、定量与基因位置的数据契约

用于 gene → KO/COG/arCOG → module/pathway 的追溯，以及 contig/MAG 上的功能分布。先确定分析对象是**基因位点、去冗余基因家族、功能集合还是基因组**。它们不可因共享名称而互换。图种见 [functional-atlas.md](functional-atlas.md)，执行工具见 [functional-cli.md](functional-cli.md)，网络见 [wgcna.md](wgcna.md)。

## 1. 先交付可讨论的设计

用一页说明：问题与预期比较、DNA/RNA 数据类型、独立生物学单位、现有注释和缺口、共享定量参考、主要/敏感性映射政策、拟画图样、统计和资源成本、小试范围。解释哪些选择会改变结论，再执行已经确定的方案。增加 skill 不等于同意在活动生产任务中增加新的注释/网络步骤。

推荐分层导航：注释质量总览 → 样本功能概览 → 候选 pathway → module 的逐步证据 → 具体 gene → contig 区段和 MAG → 关联网络。每个节点保留可点击 ID、来源和导出的底表。整库概览控制密度，细节分页或按查询展开，不在一张弦图中塞入几十万个基因。

## 2. 数据库是互补证据，不是拼接计数

| 来源 | 主键/证据 | 可以展示 | 不能直接声称 |
| --- | --- | --- | --- |
| KEGG KO | `Kxxxxx`，分配方法、阈值、数据库版本 | KO、反应和其集合成员关系 | 仅相似命中就证明酶活；KO 与任一 pathway 一一对应 |
| KEGG MODULE / PATHWAY | `Mxxxxx`、`map/ko/organism+number`，版本化映射/定义 | 模块逻辑、通路上下文 | 同一基因必须沿一条唯一层级路径；通路和 module 等价 |
| NCBI NR | accession **含版本**、同源比对证据和蛋白描述 | 同源证据、候选描述、分类来源 | NR 本身提供完整 KO/pathway；描述关键词等于可信功能 ID |
| COG | COG ID、分类字母及版本 | 直系同源组/宽功能类别 | 类别字母是一条具体代谢通路 |
| arCOG | arCOG ID、古菌直系同源组及版本 | 古菌功能分布、跨域比较 | 与 COG/KO 编号或描述完全等价；无入树古菌就无需古菌注释 |
| 可选扩展 | eggNOG、Pfam/InterPro、EC、GO、CAZy/dbCAN、AMR/VF、BGC 等 | 研究问题对应的补充功能/结构域证据 | 数据库更多就自动提高每个基因的置信度 |

保留长表式原始证据；另建解析后的接受映射表。记录查询覆盖、命中覆盖、identity、E-value、bitscore/HMM 分数、命中排名、接受规则及冲突状态；不同程序/数据库的分数不能直接排序投票。保留未注释、描述性注释、歧义和冲突，禁止以多数票掩盖不一致。跨库转换只能用有版本来源的 crosswalk，不能从蛋白名称猜 KO。

[KEGG 注释说明](https://www.genome.jp/kegg/annotation/)、[NCBI COG/arCOG 入口](https://www.ncbi.nlm.nih.gov/research/cog-project/)、[NCBI NR 说明](https://www.nlm.nih.gov/ncbi/workshops/2023-08_BLAST_evol/databases.html)用于确认各库语义；实际执行固定本地版本和哈希。缺库作为缺口记录，不自动下载数据库或上传未公开序列。

## 3. 规范化关系表

以下是语义规范；轻量 CLI 的最小列名以 [functional-cli.md](functional-cli.md)为准。建立适配时写出字段映射，不靠字符串位置猜样本或截断下划线猜 contig。

| 表 | 关键字段 | 主键与验证 |
| --- | --- | --- |
| samples | `sample_id, unit_id, group, assay, batch`，必要时配对/时间 | sample 唯一；重复测量共享 unit，不能当独立样本 |
| genes | `gene_id, catalog_id, locus_id, assembly_id, sample_of_origin, contig_id, start, end, strand, nt_length, partial` | 位点 ID 在 assembly 命名空间唯一；坐标系统明示，长度/边界/链方向检查 |
| gene_family_members | `catalog_id, representative_gene_id, member_gene_id, identity, coverage` | 每成员的归属政策明确；坐标是成员属性，不是代表属性 |
| quantification | `feature_id, sample_id, raw_or_estimated_count, length_used, abundance, unit, measurement_status` | feature×sample 唯一；参考目录/读段分配政策固定；NA 与 0 分开 |
| annotation_evidence | `gene_id, database, db_release, target_id, evidence_id, method, score, accepted, conflict` | 一条命中证据一行；多重证据不多次加丰度 |
| accepted_assignments | `gene_id, database, feature_id, allocation_weight, policy` | gene×db×feature 去重；权重来自明示政策 |
| memberships | `source_namespace, source_id, target_namespace, target_id, release, relation_type` | KO→module 与 KO→pathway 是不同多对多关系，不强行串联 |
| module_definitions | `module_id, definition, db_release, evaluator_version` | 保留原逻辑表达式和可解析状态，不只存 KO 列表 |
| contig_MAG | `assembly_id, contig_id, mag_id, membership_status, evidence` | bin 重叠、拆分、未分箱单独表示；MAG不是实验重复 |
| network_edges | `source, target, edge_type, statistic, n_units, q, stability, evidence_id` | 邻接、注释共享、相关、TOM 各有独立 edge_type |

输出必须记录输入及脚本 SHA256、数据库 release/hash、软件版本、转换和筛选、未匹配 ID 清单、集合分母、样本顺序、图使用的精确数据，以及图像实际验收状态。

## 4. TPM、counts、覆盖度与分母

- DNA shotgun 的 TPM 型值是长度和样本内总量归一化后的**相对基因丰度/功能潜力**，不称转录表达。RNA TPM 才是转录本相对量，仍不等于蛋白活性、代谢通量或绝对细胞数量。
- 若从分配给基因的 reads/fragments 计算：`rate_g = count_g / length_used_g`，`TPM_g = 1e6 * rate_g / sum(rate)`。记录使用物理长度还是有效长度、读段还是片段、多重比对分配、宿主过滤、参考全集及未映射比例。现有量化器生成 TPM 时保留其定义，不能重复除长度。Salmon 的 effective length 和估计 counts 有特定含义，见[官方输出格式](https://salmon.readthedocs.io/en/latest/file_formats.html)。
- 样本必须映射到可比较的共同目录/特征空间；拼接每个样本自己组装出来的矩阵，会混入参考缺失与真正零丰度。未测/不可判定用 NA；检测后确认为零才用 0。不能为让热图更整齐而填零。
- 输入是已筛选的 TPM 子集时，其总和通常不是一百万；保留原单位与原参考分母，不擅自重新归一化。记录保留比例。只在明示“选中集合内组成”时重新计算百分比。
- counts、TPM、CPM、RPKM、平均覆盖、拷贝数和相对百分比不能混在同一连续色标。差异分析使用对应模型所需的原始/估计 counts 或专门的组成分析设计，不能把 TPM 作为整数原始 counts。行 Z-score 只能比较该行的样本模式，不能比较不同基因的绝对高低。
- 零/缺失、伪计数、log 转换都写入图例和底表；定量技术不确定性不能靠增加显示小数位消除。

## 5. 去重、多重归属与守恒

建议同时提供两个回答不同问题的视图，不能混名：

1. **成员丰度视图**：功能集合 (F) 中每个基因只出现一次，`A_Fs = sum_g w_gF * abundance_gs`。full-membership 的基因可进入多个集合，所以跨集合的和可能超过输入总丰度；不能画成各部分互斥的100%饼图。
2. **分摊组成视图**：同一层级/命名空间内给多归属设置归一权重，保留“未分配”桶，使 assigned + unassigned 与输入相符。这是可视化/统计分配政策，不是证明真实功能各占一半。

基因多条 NR 命中不应成为多份基因。COG 多类别字母也需展开和权重声明。KO→module/pathway 的 join 先按最终 `gene_id × target_id` 合并所有到达路径，再落实归属政策；同一个 KO 经多个中间路径到同一目标不能重复加。不同数据库产生的是平行证据面板，不把 KEGG+COG+NR 丰度相加。

示例：g1=10、g2=20、g3=30；g1/g2 均属于集合A，g1也属于B，g3未注释。full-membership得到A=30、B=10、未注释=30，总和70（非互斥）；对g1等分得到A=25、B=5、未注释=30，总和60。这两个结果回答的问题不同。不能隐藏政策，只选择更好看的图。

**特别处理代表基因的空间归属**：代表家族 TPM 若对应多个基因位点，不可原样复制到每个 contig 后汇总。可显示“该位点所属家族的跨样本丰度”，但明确不是位点特异量。要做 contig/MAG 定量贡献分解，必须有位点可区分的读段、经审核的概率分配或明示分摊敏感性分析；没有则贡献归属为不确定。

## 6. KEGG module 与 pathway 的细化

至少保留三张互相联动但不同单位的表：

- 基因/KO 成员的丰度与分配政策；
- module 定义中的逐块证据（命中、缺失、不可判定、替代支路、复合物子单元）；
- pathway 的成员分布与反应上下文。

KEGG MODULE 完整性须按版本化表达式中的必需项、替代项、可选项和顶层块评价，不能用“命中KO数/所有KO数”替代逻辑。[KEGG 官方定义](https://www.genome.jp/kegg/module.html)。无法解析的定义应标记 unsupported，不返回一个看似精确的完整度。成员 TPM 求和也不是完整性分数。

每个 MAG/基因组分别判断能力；社区中跨多个物种拼齐一个 module 仅表示社区层面的基因集合。短 contig 上缺一个酶、低完整度 MAG 缺一个块，可能是组装/恢复不足；保留“未观测”，不能直接宣称生物学缺失。

没有通用的“module TPM”。可报告明示定义的成员和、步骤平均/瓶颈代理等研究性指标，但应展示步骤覆盖和算法假设并做敏感性比较，不称通量。KEGG module 和 WGCNA 统计模块用 `KEGG:Mxxxxx` 与 `WGCNA:module_id` 两个命名空间。

## 7. contig 功能分布与关联

按 bp 的箭头轨道展示坐标/链/注释，按样本的热图展示丰度模式，按基因窗口或 bp 窗口展示局部功能密度，跨 contig 的共线性展示保守邻域。窗口密度明确分母是bp、完整ORF数或覆盖基因数；不同组装质量的总数不能直接比较。

关系边分层：同一 contig 邻近（坐标证据）、同一功能集合（注释证据）、跨样本共丰度（统计证据）、共线性/同源（序列证据）、预测相互作用（独立算法证据）。邻近不证明操纵子，相关不证明相互作用或因果，同一 MAG 共丰度可能只是宿主基因组的丰度变化。避免把这些边合成一种“关联强度”。

使用共享的gene/contig/MAG索引联动网络、热图、坐标和通路图；小样本优先画观测值/散点和已有生物学集合，而不是制造稳定网络的外观。未知功能基因作为可检索的一类保留，优先展示其邻域和测量质量，不能自动赋予邻居的功能。

## 8. 分层验收与资源

先检验 ID/坐标/样本/单位/映射守恒，再以少量有多重注释、NA、重复位点、跨页长标签的固定示例验证图。用于算法验证的合成图明确标记。真实数据图须重新核对；合成测试不能替代真实科学结论。

聚合可流式/稀疏完成；整库热图先按问题挑选特征，导出完整底表。WGCNA 的稠密邻接/TOM 有二次内存成本，用分块预算和受控线程；不要为占满CPU而同时争抢内存。性能探针和正式科学试跑分开，沿用原工作流的指纹、审批和冻结约束。
