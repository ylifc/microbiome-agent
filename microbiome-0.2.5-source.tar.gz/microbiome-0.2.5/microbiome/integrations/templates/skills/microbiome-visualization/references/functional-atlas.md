# 基因—功能—通路—contig/MAG 图谱：28 个可审计图种

本扩展用于已经取得的 KEGG、NR、COG、arCOG 等注释和基因定量数据。它把群落功能概览向具体基因、基因组位置和证据追踪细化；不替代注释、比对、差异模型或网络推断。正式输入核验见 [functional-data-contract.md](functional-data-contract.md)，入口配方见 [functional-r-recipes.md](functional-r-recipes.md)，共丰度模块分析另见 [wgcna.md](wgcna.md)。以下是设计与实现指南，不表示当前项目已经有这些注释、网络或图像。当前项目已观察到代表基因 TPM、COG/Swiss-Prot 注释；不能由本skill支持某库就声称KO/NR/arCOG注释已完成，须逐库读取真实产物。

## 先交付一页设计，再扩成图册

先明确问题：是比较各笼的功能潜力、追溯某条通路由哪些基因/MAG贡献，还是检查基因邻域与功能关联？展示拟用数据、方法/备选、统计单位、聚合规则、缺失处理、样图布局和预计成本，讨论有科学意义的选择。已确定的样本与参数不重复审批。先用一个真实候选通路、一个 contig 邻域、少量审核后的功能行做只读预览；诊断子集不代替全样本科学验证。

DBDPE 有 12 个独立笼混样，C/L/M/H 各 3 笼，每份含 5 只小鼠。统计单位是笼；gene、contig、MAG 和池内小鼠不能扩充 n。C/L/M/H 按类别，不编造等间距剂量。当前已审核运行中的 Stage B 系统发育流程不因新增 skill 而改变；新功能分析属于另行明确范围的设计。

推荐组织成六个相互链接的层级：①注释/量化质量；②gene/KO/COG/arCOG 定量；③KEGG module 步骤及 pathway；④贡献来源 MAG/分类；⑤contig 坐标与邻域；⑥有证据类型的关联网络。每层保留完整 ID 和下载表，不用一张密集圆图承载全部信息。

## 数据契约：关系图，不是单一分类树

所有 ID 带命名空间，库版本和引用记录入 manifest。原注释保留，规范表是衍生文件；不能用一列“综合功能”覆盖多个证据。建议以下长表，每个键的唯一性与 join 基数必须检查：

| 表 | 最低列与键 | 约束 |
| --- | --- | --- |
| `samples.tsv` | `sample_id,cage_id,group,assay,batch`；键 sample_id | assay 为 DNA/RNA；批次未知应声明，不能造值；独立单位另行核验 |
| `genes.tsv` | `gene_id,contig_id,mag_id,start,end,strand,nt_length,protein_id,gene_catalog_id`；键 gene_id | 此处坐标统一 1-based closed，`1<=start<=end<=contig_length`；strand 为 +/−；未分箱用显式状态；原始GFF转换只做一次 |
| `quant.tsv` | `sample_id,gene_id,tpm,assigned_fragments,effective_length,quant_status,denominator_id`；键 sample+gene | 检测到/测量零/未量化/低可信分别记录；TPM 可 NA，不能把缺项补0；分数分配的 fragments 不强制取整 |
| `annotation_evidence.tsv` | `evidence_id,gene_id,database,db_release,target_id,method,identity,qcov,scov,evalue,bitscore,call_status`；键 evidence_id | profile/HMM 分数与比对 identity 不混用，无法提供的字段 NA；记录命中阈值、域及多结构域证据 |
| `function_membership.tsv` | `gene_id,function_ns,function_id,evidence_id,assignment_status,allocation_weight,allocation_policy` | 基因×功能×证据可多行；聚合前先消除同一功能的重复证据，不能将同一命中报告两次算两基因 |
| `function_relations.tsv` | `source_ns,source_id,target_ns,target_id,relation,db_release` | KO→module、KO→pathway、module→pathway、COG→category 是独立关系表；不假设每个节点只有一个父节点 |
| `module_definition.tsv` | `module_id,definition,definition_release,definition_sha256`；键 module+release | 保存合法来源定义；使用能处理完整语法和嵌套的审核解析器；不在绘图中用正则拆 K 号代替逻辑 |
| `module_blocks.tsv` | `scope_type,scope_id,module_id,block_id,block_order,logic_expression,required,status,supporting_gene_ids,missing_ko_ids` | scope 为 sample/community、MAG 或 contig；状态 present/not_detected/unknown，支持集合可追溯 |
| `feature_values.tsv` | `sample_id,feature_ns,feature_id,value,unit,aggregation_policy,quant_status`；键 sample+ns+id+policy | counts/TPM/weighted_TPM/gene_set_sum 不混写；一个图只用明确单一口径 |
| `contigs.tsv` | `contig_id,length,mag_id,assembly_id,topology_status`；键 contig_id | contig 名跨组装可能重复，须带 assembly 命名空间；环形布局不证明闭环 |
| `edges.tsv` | `edge_id,source_id,target_id,edge_type,score,score_type,sign,n_units,qvalue,evidence_id`；键 edge_id | 邻接、共丰度、同源、同通路、WGCNA TOM 和预测反应分别编码；有向/无向另记录；缺失 q 不伪造 |

### 注释合并的五条边界

1. KEGG KO 是功能正交组标识，KEGG MODULE 的 `Mxxxxx` 是基因集合逻辑定义，PATHWAY 是更大范围的图；它们可多对多。NR 提供序列相似性证据和数据库记录，不是现成的通路层级。不能从 NR 描述关键词“猜” KO，也不能把最高 bit score 当成跨库统一置信度。[KEGG 条目结构](https://www.kegg.jp/kegg/docs/dbentry.html)、[NCBI BLAST FAQ](https://blast.ncbi.nlm.nih.gov/Blast.cgi?+CMD=Web&DOC_TYPE=FAQ&PAGE_TYPE=BlastDocs)。
2. COG 与 arCOG 的簇边界、覆盖范围及版本不同，跨库对应不默认一一等价；同一 COG 可涉及多功能类别。保留各自 ID、原始命中及映射证据，分类归属的相似不是独立实验验证。arCOG 缺命中不说明无古菌。[COG 2024 原始数据库论文](https://pmc.ncbi.nlm.nih.gov/articles/PMC11701660/)、[arCOG 原始更新论文](https://pmc.ncbi.nlm.nih.gov/articles/PMC4390880/)。
3. 模糊命中、仅家族级证据、多个真实功能、冲突证据和未注释是不同状态；先输出冲突清单和可解释的决策规则，不以“多数数据库同意”替代独立证据评估。
4. 同一跨样本 gene catalog 的成员映射、代表序列及量化目标必须冻结。若分别组装，各样本同名 gene 不可直接合并；聚为 gene family/KO 后的结果不能假装仍是同一具体基因。**代表基因/family可对应多个contig位点；其TPM不可复制到每个member后再相加。** 未取得可辨识的位点量化或审核后的分摊权重时，邻域里只能标“共享family profile，非位点特异”，不计算位点或MAG贡献总和。共享/多重比对 reads 要保存分配算法、可辨识度与覆盖证据。
5. 本 skill 不打包或批量下载 KEGG 全库、KGML 或图像。已有合法本地数据库只读使用并记录 release/哈希/使用条件；不要把“支持 pathview”理解为获准上传项目基因和数值。[KEGG 官方使用说明](https://www.kegg.jp/kegg/legal.html)。

### 量化、分配与守恒

若已有经过审核的基因 TPM，优先保留其量化程序定义。若明确决定从已分配的片段量重算，常用形式是 `R_gs=C_gs/L_gs`、`TPM_gs=10^6 R_gs/sum_h R_hs`，其中有效长度、片段/reads 单位及分母集合必须固定并记录。已有长度校正量不能再次除长度。一个样本只有在同一完整量化分母集合、零分母已处理的条件下才应总和约百万；展示子集不要求百万，不能因筛选后总和较小就偷偷再归一化。

DNA shotgun TPM 在本 skill 中标“基因相对丰度/功能潜力”，不标表达、酶活性或通量。RNA TPM 也受菌量、RNA组成和技术因素影响；DNA/RNA比必须有配对、零值政策及明确模型。TPM不能当要求原始counts的差异模型输入。

对于一基因多功能，选定并并列说明以下口径：

- **唯一可信归属**：只将已确认唯一功能的值归入，剩余质量归未分配/歧义项。
- **带权分配**：同一 namespace、同一聚合目的下的权重非负且每基因和≤1；余量留残差。它是约定的分配量，不是实验测得的基因各功能用量。权重来源必须可审计。
- **多标签成员展示**：每个命中集合独立显示；允许同一基因出现在多个 pathway，但明确标“非守恒 gene-set sum”，不能把这些通路列相加当全群落TPM。

不能跨 KEGG/NR/COG/arCOG 相加总TPM；那是对同一批基因重复注释。基因集合内去重不解决集合之间重叠。未量化成员若导致特征汇总不完整，该值标 partial/NA，不能把 `sum(...,na.rm=TRUE)` 当完整总量。按 MAG/分类分层的贡献和只在基因归属和分配口径一致时能对上非分层总量。

### KEGG module 的覆盖和丰度必须分开

官方 MODULE 逻辑中，空格和 `+` 表示 AND，逗号表示 OR，`-` 引导复合体可选项；顶层空格分隔的 block 要先正确分组。某些定义可引用其他 M 号，遇到解析器不支持的表达式应标 unsupported，不返回0%。保存原定义、解析树及版本，分别给每个必需 block 的证据和未满足项。[KEGG MODULE 官方定义](https://www.kegg.jp/kegg/module.html)。

- 描述性完整度可定义为“已满足必需顶层block / 全部必需顶层block”，还要另列 unknown blocks；不把全部K号命中比例当逻辑完整度。可选项不算必需缺口。
- 可展示 KO 丰度、各必需步骤的丰度向量或已预注册的模块丰度估计。AND取最小、OR求和/取最大等是不同估计模型，不能把随意选择的聚合当KEGG官方通量。默认展示步骤丰度而不是虚构唯一“module TPM”。
- 在 community 中汇总不同菌的 KOs 可形成群落集合覆盖，不能证明某个 MAG 含完整通路，也不能证明跨菌互补代谢已发生；MAG 缺失可能由不完整组装造成。
- `KEGG:Mxxxxx`、`WGCNA:module_id` 必须分开命名。前者是数据库定义，后者是本数据推断的共变集合；做富集可联系二者，不能视为同一种 module。

## 28 个图种：按问题选择，不机械全画

每项均须附数据快照、ID字典、变换/过滤、分母、软件/脚本版本、输入输出SHA256和实际开图QA。R代码配方索引为本页后链FR；已有通用工具不重复复制。

### F01 注释覆盖漏斗与数据库交集
**问题**：哪些基因获得哪类证据，覆盖损失发生在哪里？**输入**：`gene_id,database,call_status`及完整genes集合；若加丰度权重需`sample_id,tpm,quant_status`。**实现**：R ggplot2分面条+ComplexUpset交集；Python upsetplot。**编码/解读**：分别显示独立基因数和每样本丰度份额，不把各库覆盖柱叠成100%。**陷阱/验收**：NR注释不是KO命中；被过滤、无命中、未运行分别计数；交集用去重gene ID，全集分母包含无命中。

### F02 多库证据一致性与冲突矩阵
**问题**：具体基因的功能推断在哪些层级一致或不确定？**输入**：`gene_id,database,target_id,evidence_id,call_status,comparison_level,conflict_class`。**实现**：ComplexHeatmap分类矩阵+旁列原命中链接。**编码/解读**：一致/兼容多功能/冲突/不可比/未评估；色块不是跨库分数平均。**陷阱/验收**：有明确规则才能称冲突；检查COG/arCOG/KO层级不可比项，不能用未比对的库表示反对票。

### F03 注释可信度—量化可信度散点
**问题**：高丰度候选是否依赖弱注释或多重比对？**输入**：`sample_id,gene_id,tpm,qcov,identity,unique_mapping_fraction,annotation_method,quant_status`。**实现**：ggplot2散点/分面，R FR01可改；Plotly本地hover。**编码/解读**：同一方法面板内x=qcov，y=log1p(TPM)，颜色为mapping可信度，NA独立条带。**陷阱/验收**：HMM无identity不能填0；点透明不是删点；高TPM不提升注释确定性。

### F04 基因×样本 TPM 热图
**问题**：指定具体基因在所有独立笼中怎样变化？**输入**：`sample_id,gene_id,tpm,quant_status`、samples、gene→功能证据。**实现**：ComplexHeatmap FR02；ggplot2 tile。**编码/解读**：默认log2(TPM+1)，缺值灰；另需行z-score时独立版与原量并存。**陷阱/验收**：同源簇不假作同一基因；检查12样本全部列与真实0/NA；标签过多分页而非只给不可读全图。

### F05 KO×样本丰度与检出率 dot plot
**问题**：KO量化强度与检出范围是否一致？**输入**：`feature_ns=KO,feature_id,sample_id,value,unit,quant_status`；按组摘要需`n_detected,n_evaluated`。**实现**：ggplot2 FR01；Python scatter。**编码/解读**：颜色log abundance、面积明确为TPM或检出比例之一；优先每笼一点。**陷阱/验收**：组摘要旁示3笼原值；面积不能同时暗示丰度和显著性；未知量化不纳入已评估分母。

### F06 COG/arCOG 功能类别谱
**问题**：在各自数据库覆盖范围内，哪类功能得到较多量化支持？**输入**：`sample_id,database,category_id,value,unit,allocation_policy,unassigned_value`。**实现**：ggplot2堆积柱或点图，数据库分面；FR03。**编码/解读**：独立显示两个库，不强行归并同名字母；按约定分配的份额附残差。**陷阱/验收**：一COG多类别需权重或非守恒标注；全部样本共用色表与分母，未知类别不能消失。

### F07 KEGG pathway 丰度热图
**问题**：预选通路集合的成员基因丰度模式如何？**输入**：`pathway_id,sample_id,value,unit,aggregation_policy,n_genes,n_ko,n_missing`。**实现**：ComplexHeatmap FR02。**编码/解读**：颜色取已定义gene-set sum或审定算法输出；显示KO覆盖与重叠附轨。**陷阱/验收**：pathway大者天然含更多基因；不能把总和叫活性或将多路径和再当组成；样本内不同通路的面积比较需同口径。

### F08 KEGG module 必需 block 覆盖矩阵
**问题**：哪个必需步骤已支持，哪些缺口只是未测？**输入**：module_blocks全部列；`module_definition_sha256`、scope及完整block清单。**实现**：ggplot2离散tile FR04；ComplexHeatmap。**编码/解读**：present/not_detected/unknown分色，可选项标边框；每行旁标coverage分子/分母。**陷阱/验收**：按AND/OR逻辑审查；不能把缺少的行默认not_detected；community与MAG分别画，标题点明scope。

### F09 Module 每步丰度与瓶颈候选
**问题**：已覆盖的module中，哪个步骤量化支持较低？**输入**：`sample_id,module_id,block_id,ko_id,value,unit,block_logic,quant_status`。**实现**：ggplot2 dot/box、FR01分面。**编码/解读**：保留KO和替代路线，不强合一个值；低值只称候选限制步骤。**陷阱/验收**：DNA丰度不等于速率限制/代谢瓶颈；同一KO复用、缺失与0区分；若提供模块标量须明确算法与敏感性图。

### F10 本地 KEGG 通路节点着色
**问题**：具体KO量化或已有比较效应落在哪些反应区域？**输入**：`ko_id,value,unit,contrast`、真实pathway ID、本地匹配KGML与PNG及版本。**实现**：pathview FR07；审核的本地KGML网络renderer。**编码/解读**：丰度单向色标、效应发散色标分别出图；节点多KO聚合明确。**陷阱/验收**：先给未映射表；节点不是基因一一对应，不凭上色断言完整通路；本地缺资源停止，不自动上传或下载。

### F11 通路→module→KO→gene 可钻取局部图
**问题**：一个通路结论究竟由哪些基因和证据支撑？**输入**：function_relations、function_membership、`gene_id,sample_id,tpm`及局部选择清单。**实现**：igraph/ggraph或Cytoscape本地分层图，配HTML索引。**编码/解读**：节点形状区分层级，边型是membership/annotation而非因果；hover保留原ID。**陷阱/验收**：多父节点不克隆为独立基因；同一gene贡献不可沿多路径反复求和；保留无module的直接KO→pathway关系。

### F12 MAG/分类群对目标功能的贡献分解
**问题**：功能丰度变化来自哪些MAG或已确认分类来源？**输入**：`sample_id,feature_id,mag_id,contribution,unit,assignment_policy`和功能总量。**实现**：ggplot2堆积柱+原笼点，FR03；分面heatmap。**编码/解读**：给每笼绝对分配量，再给功能内部百分比的独立版；Unbinned/Unclassified保留。**陷阱/验收**：分层和严格对账总量；分类不确定不强配species；贡献变化不等于单菌表达调控。

### F13 有权重的来源—功能 alluvial
**问题**：某样本/对比中量化质量怎样在MAG、功能与通路间分配？**输入**：`flow_id,gene_id,mag_id,function_id,pathway_id,weight,unit,allocation_policy`，明确无注释残差。**实现**：ggalluvial FR06或Plotly Sankey。**编码/解读**：宽度为非负守恒分配量；节点ID带namespace。**陷阱/验收**：多标签每路径重复用完整TPM会假增宽；若非守恒则不能绘成守恒流；每轴权重对账输入且不跨样本相加冒充重复。

### F14 Contig 基因箭头图
**问题**：指定功能基因位于哪里、方向如何、相邻基因是什么？**输入**：`contig_id,gene_id,start,end,strand,function_label,annotation_status`和contig长度。**实现**：gggenes FR05；pyGenomeViz。**编码/解读**：真实bp长度、方向箭头，颜色为功能，未知灰；短标签附字典。**陷阱/验收**：邻接不是operon；审查正负链及边界，坐标不得越界，缺口不隐藏，gene与绘制箭头数一致。

### F15 Contig 多轨：位置—功能—覆盖—TPM
**问题**：基因功能区域与真实覆盖/量化是否一致？**输入**：F14；`sample_id,contig_id,start,end,depth,coverage_status`及gene TPM、可选GC窗口。**实现**：ggplot2+patchwork共享x；Gviz/IGV本地会话。**编码/解读**：独立y轴和单位，gene箭头+depth轨+gene色块；同样本或固定小倍图。**陷阱/验收**：TPM不是每bp深度，不能画作连续覆盖；轴范围统一策略明确，抽查原BAM/bedGraph区段。

### F16 Contig 滑窗功能密度/丰度
**问题**：哪些区段富集某类功能或未知基因？**输入**：`contig_id,window_start,window_end,function_id,overlap_bp,gene_equivalent,assigned_value,evaluable_bp`及窗口/分配规则。**实现**：ggplot2线/heatmap；circlize窗口轨。**编码/解读**：genes/kb、功能CDS覆盖比例和TPM分配轨分开。**陷阱/验收**：跨窗口基因整值重复会增量；固定窗口或重叠窗口清楚标记，末窗用实际可评估bp，CDS重叠的union bp与sum bp不同。

### F17 多 contig/MAG 功能景观
**问题**：目标功能在碎片化基因组中集中还是分散？**输入**：contigs；`contig_id,start,end,function_id,mag_id`；明确排列/筛选清单。**实现**：circlize分sector或ggplot2线性小倍图。**编码/解读**：contig间可见缝隙、长度比例与unknown轨，优先线性分页。**陷阱/验收**：圈图不是闭环证据；各MAG独立总长不强接染色体；每个contig可追溯且未画小contig列清单。

### F18 锚基因邻域比较与同源共线性
**问题**：同源功能周边排列在不同MAG中是否保守？**输入**：F14、`anchor_gene_id,homolog_group,alignment_id,source_start,source_end,target_start,target_end,identity,strand`。**实现**：gggenes锚对齐；gggenomes/pyGenomeViz画真实同源link。**编码/解读**：平移/反转仅显示变换，link颜色为已计算identity。**陷阱/验收**：同名注释不能代替比对；跨contig末端不能称基因缺失，等比例和反向坐标回读需核验。

### F19 基因物理邻接网络
**问题**：哪些功能在同一contig局部成邻接候选？**输入**：`source_gene,target_gene,contig_id,gap_bp,same_strand,neighborhood_rule,evidence_id`及节点功能。**实现**：igraph/ggraph；Cytoscape导入包。**编码/解读**：边表示距离阈值下邻接，宽度可映射已说明的距离变换；与coabundance分面。**陷阱/验收**：不跨contig连物理边；重叠gap允许负值但需说明；候选operon不写共转录已证明。

### F20 跨样本基因共丰度网络
**问题**：哪些基因在独立样本间共变？**输入**：审核后的edges，`edge_type=coabundance,score_type,sign,n_units,qvalue`、原矩阵及建模配置。**实现**：ggraph/igraph静态，Cytoscape本地；WGCNA路线见[wgcna.md](wgcna.md)。**编码/解读**：符号颜色、强度宽度、稳定性独立属性。**陷阱/验收**：不是互作/调控证明；12笼样本网络不稳，先落实适用性和稳定性；同一菌丰度、多重比对和组成效应可造共变。

### F21 多证据关联网络
**问题**：共丰度、物理邻接、同源和共同通路是否支持同一候选关系？**输入**：nodes加完整edges；每条边保留`edge_type,score_type,evidence_id`。**实现**：ggraph多层分面/Cytoscape多重边。**编码/解读**：边型区分证据，不能将不同分数简单相加成“可信度”。**陷阱/验收**：共同注释是先验成员关系，不是独立统计证据；抽查边端点与来源，布局距离无科学单位，孤立节点保留。

### F22 MAG—功能二分 / MAG—gene—功能三分图
**问题**：功能在哪些MAG中共享，哪些基因连接这些证据？**输入**：`mag_id,gene_id,function_ns,function_id,abundance,presence_status,evidence_id`。**实现**：igraph/ggraph固定分层坐标；复杂集合改用ComplexHeatmap。**编码/解读**：不同层形状，边为归属，presence与丰度权重分版本。**陷阱/验收**：数据库多标签不增加独立MAG；低完整度的未检出不是缺失；报告过滤前后节点/边数，避免大毛线团。

### F23 未知功能负担与待研究候选排名
**问题**：高丰度或保守邻域中的未知基因值得优先检查哪些？**输入**：`gene_id,sample_id,tpm,annotation_status,domain_hit,conservation_evidence,contig_id`。**实现**：ggplot2排名点图+邻域链接；ComplexHeatmap。**编码/解读**：未注释、一般功能预测、未知具体功能分色；保留原库标签。**陷阱/验收**：高丰度不能称新功能已发现；排名记录规则/并列处理，未评估不归未知，gene ID可回溯。

### F24 缺失与检测能力矩阵
**问题**：看似缺功能是否由组装/覆盖/注释或量化能力造成？**输入**：`sample_id,gene_or_feature_id,annotation_status,quant_status,coverage_status,mag_completeness`。**实现**：ComplexHeatmap多状态矩阵；ggplot2tile。**编码/解读**：零、低检出、未运行、未组装可评估性不足分别编码。**陷阱/验收**：不能将所有NA改0；仅有TPM表不能辨真缺失，需要实际coverage证据；各状态定义写入图例。

### F25 功能差异效应与不确定性
**问题**：指定比较的基因/KO/pathway效应有多大、精度如何？**输入**：`feature_id,contrast,effect,effect_unit,lower,upper,interval_type,pvalue,qvalue,n_units,model_id`。**实现**：ggplot2forest FR08；volcano作辅助。**编码/解读**：点与CI、0或1参考线按效应单位；跨层级分面。**陷阱/验收**：绘图不从TPM造p值；多重检验family和实际模型记录；3笼/组原始点并列，不用星号代替效应。

### F26 已有富集结果与基因重叠网络
**问题**：差异候选涉及哪些功能集合，显著项是否由相同基因重复驱动？**输入**：`set_id,test_id,n_hit,n_background,background_id,ratio,qvalue`及`gene_id,set_id,in_test_universe`。**实现**：ggplot2气泡+UpSet/集合重叠网络，clusterProfiler只消费审核结果。**编码/解读**：大小实际命中数，颜色FDR，边为Jaccard等明确集合相似。**陷阱/验收**：背景是可检测/可检验集合，不自动用全库；ID映射损失和重叠可对账；富集不等于通路通量。

### F27 WGCNA 模块—功能注释—contig/MAG 关联面板
**问题**：数据驱动共变模块包含哪些数据库功能、是否受单一MAG/邻域主导？**输入**：`gene_id,wgcna_module,kME,module_assignment_status,contig_id,mag_id`，富集表与实际模块稳定性结果。**实现**：ComplexHeatmap模块×集合效应图、MAG贡献条+基因邻域图；分析/适用性见[wgcna.md](wgcna.md)。**编码/解读**：WGCNA模块名与KEGG M号独立列；hub候选保留kME与稳定性。**陷阱/验收**：模块富集不证明调控，单MAG大量基因可主导；未分配grey不自动解释为生物模块；当前12笼需按WGCNA适用性门控处理。

### F28 目标通路“证据卡”组合图
**问题**：读者能否从通路结论一路追查到基因与坐标？**输入**：F04/F08/F10/F12/F14/F25的同一目标ID、manifest与显式join表。**实现**：patchwork/cowplot布局或本地HTML导航。**编码/解读**：上层每笼定量，中层module缺口与来源，下层关键gene邻域；效应只来自已有模型。**陷阱/验收**：不同面板纳入范围/单位不可混淆；样本和功能ID一致、图例完整、附表可找全gene；一张漂亮图不能替代科学审核。

## 交付与实际验收

出图包至少含 `design.md`、输入清单及SHA256、完整样本/基因身份表、annotation与mapping审计、聚合规则、显示矩阵、每图实际数据、脚本/sessionInfo、SVG/PDF/PNG及本地索引。超密矩阵提供概览和细节页；交互图提供静态备份，不向公共服务上传数据。

抽查高/低/零/NA量化、模糊功能、一基因多KO/多pathway、unbinned、反链基因、末端截断、跨窗口基因以及最密页。沿“gene原值→分配→KO/模块步骤/路径显示→MAG贡献→图例”回算；守恒与非守恒图分别验证。记录实际打开的文件和发现的问题，不能仅凭脚本exit0认定验收。

本扩展官方资料检索日期：2026-10-14。具体版本以实际环境和库manifest为准；文档支持、已安装、已运行和已视觉验收是四种不同状态。
