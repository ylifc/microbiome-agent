# 基础 R 表格绘图入口

`scripts/plot_table_base.R` 使用基础R和系统`sha256sum`，不依赖ggplot2，不安装包。绘制已分析的TSV并输出PDF、SVG、PNG、`plotted_values.tsv`、原表副本、`sessionInfo.txt`和含SHA256的`manifest.tsv`。输入≤64MiB；默认输出必须是不存在的新目录，父目录已存在，且不能与输入位于同一目录。DAG 预建了文件父目录时，可显式传 `--allow-empty-output true`，仅接纳可读取、严格为空的普通目录；隐藏文件也算非空。目录自身或任意祖先是符号链接、非空目录、输入目录及文件覆盖仍拒绝。省略该参数或传 `false` 不允许已存在目录，其他值报错。

```bash
Rscript scripts/plot_table_base.R --kind mag-quality \
  --input /data/mag_quality.tsv --output /results/new_quality \
  --title 'MAG quality' --dataset-kind biological \
  --source-note 'CheckM2 results from recorded run; genomes are not replicates' \
  --source-evidence /results/source_run_receipt.json
```

合成数据用`--dataset-kind synthetic`，不能用它绕过真实数据的来源记录。`source-evidence`只建立来源路径和哈希，不独立认证其中的结论。`--source-note`解释源分析与单位。运行前发现并验证当前选定环境中的 Rscript 绝对路径、版本及图形设备能力；此文档不代表本机资源已就绪。

| `--kind` | 必需TSV列 | 行键、画法与边界 |
| --- | --- | --- |
| `composition` | sample_id, group, feature, value | sample×feature唯一；value是0–1比例，每样本总和1，所有零行显式存在；不补零、不闭合、不合并Other，≤25类；每样本一根堆叠柱 |
| `heatmap` | sample_id, feature, value | sample×feature唯一；value允许NA/空值，缺失位置标×并有连续色条；不聚类、不log、不行Z-score；输入首次出现顺序，≤80样本/100特征 |
| `alpha` | sample_id, group, metric, value | 每样本一行且一张图只含一个metric；显示原始点和中位数，标实际n；点仅按输入顺序横向散开避免完全重叠，纵值不变，无自动检验/密度估计 |
| `ordination` | sample_id, group, axis1, axis2 | 输入已计算坐标，每样本唯一；不计算距离/PCoA/NMDS；等轴比例，不自动椭圆或检验 |
| `volcano` | feature, effect, qvalue | 每特征唯一；effect方向/尺度由轴说明，q必须为(0,1]；纵轴固定为`-log10(adjusted q-value)`，`--y-label`须与此一致；需要`--q-threshold 0.05`等明确阈值，不重新FDR，不替q=0下溢制造数值 |
| `forest` | feature, effect, lower, upper | 特征唯一，区间须包含效应，≤60行；需要`--reference 0`（差值）或`1`（比值）；区间水平/模型来源由说明给出 |
| `mag-quality` | genome_id, group, completeness, contamination | MAG唯一，质量估计按百分数；完整度0–100，污染非负可超过100；不自动声称MIMAG认证 |
| `rarefaction` | sample_id, group, depth, richness | sample×depth唯一，depth是非负整数reads数，0≤richness≤depth且随depth不减少；读入预计算期望值并连线，不执行稀释/外推；不同sample独立线。覆盖率/样本数为横轴的曲线用专门配方 |
| `growth` | sample_id, group, time, value | sample×time唯一，按time排序连线；必须区分实验重复/技术重复，写OD/CFU等单位；不扣空白、不拟合生长模型、不把负背景校正值截为0 |

除composition/alpha/mag-quality外，必须传`--x-label`与`--y-label`，例如`--x-label 'PCoA 1 (27.1%; Bray-Curtis)' --y-label 'PCoA 2 (13.4%)'`。该百分比必须来自源排序结果，脚本不会推断；NMDS轴不能伪写解释方差。forest的y-label说明源区间，例如`95% CI; supplied model estimates`，特征名逐行显示。

TSV为无引号、无内嵌制表/换行的表。重复列名、错误行长、非有限数值、重复观测键、同一样本跨组等在写图前拒绝。多样本条件轨迹若真实同一受试者跨处理，应提供单独观测sample_id，受试者链接由专门配对图配方处理，不能硬塞此合同。

输入首次出现顺序保留；C/L/M/H配色固定，其他类别自动取色。更多面板、长类别名、更多特征、复杂分组/配对、多层注释、聚类树或期刊主题适用更完整的ggplot2/ComplexHeatmap配方，不能假定基础CLI自动解决。每张图仍需实际检查；目录出现`manifest.tsv`表示完成preview，不表示视觉验收。

程序仅生成描述图及声明明确的显示变换（例如火山图的`-log10(q)`）。R官方基础绘图接口可查`?plot`、`?barplot`、`?image`、`?segments`、`?pdf`、`?svg`、`?png`。高级R配方见 [r-community-recipes.md](r-community-recipes.md)，每个图种的科学解释见对应图谱。
