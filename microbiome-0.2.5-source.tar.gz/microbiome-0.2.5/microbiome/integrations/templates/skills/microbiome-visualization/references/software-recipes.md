# 科研图软件配方：从真实输入到可编辑交付

用途索引见 [genomics-atlas.md](genomics-atlas.md)。本页提供官方能力核验后的操作路线，**不是本机安装清单或成功运行记录**。官方来源统一访问于 **2026-10-14**；页面上最新版本不能当作本机版本。这里没有执行安装、分析、上传或重新生产的授权。

## 先选执行范围，再选软件

1. 读取项目当前产物和环境记录。已完成的分析结果优先直接绘制；作图不自动授权重新比对、计算 ANI、寻找宿主或做差异检验。运行中的科学流程与冻结脚本保持不变。
2. 为候选程序记录 `executable/interpreter` 路径和真实版本；R 用 `requireNamespace(..., quietly=TRUE)` 与 `packageVersion()`，Python 核对选定解释器的模块版本。缺少包就报告缺口或使用已验证替代方案，不临时在生产环境安装。
3. 把能力分为 `documented_only`（官方文档支持）、`environment_verified`（当前环境实际可用）、`rendered`（本次已输出）、`visually_checked`（实际开图检查）。环境通过不意味着科学模型已验证；合成图不能改名成真实结果。
4. 写入新的独立输出目录，先做一小页真实数据预览。明确顺序、单位、阈值、颜色、支持度/统计量；通过视觉检查后再批量出图。不要为测试绘图复制或重算整个科学流程。
5. 保存数据与脚本/工程文件。最小 provenance 包含来源文件路径与 SHA256、样本/基因组纳入清单、ID 映射、过滤/变换、单位/分母、软件和脚本版本、命令、随机种子/布局坐标、输出哈希、实际视觉检查文件及限制。R 另存 `sessionInfo()`；Python 记录实际解释器及相关包版本。

任何在线工具都先判断是否会传输树、基因组、样本标签、注释、图像或数值。未获明确外传授权时，完成本地文件和导入包即可；不要把“选择 iTOL/KEGG 软件”误读为可上传任意项目数据。

## R 路线

### R1 ggplot2：数值图、效应区间和分面

**输入格式**：长表 TSV，一行一个测量或已审核统计量；ID 列保留字符串，数值列带单位说明。时间序列包含实际 subject/cage ID；气泡图包含真实 ratio/count/q-value 来源。

**操作**：按 ID 显式 join 并检查一对多；锁定 C/L/M/H 因子顺序和具名颜色映射；用 `geom_point()`、`geom_line()`、`geom_col()`、`geom_errorbar()` 等映射真实列。需要原样显示已计算值时不让绘图层再次计算统计量。对数轴之前处理并说明零与删失；展示局部放大与删除数据是不同操作。

**交付/验收**：`ggsave()` 保存明确物理尺寸的 SVG/PDF 与预览 PNG；记录字体和实际设备，检查图例、轴和缺失点。另存绘图长表与 R 脚本，不能只留截图。DBDPE 每组只有三个笼混样，避免用平滑图形掩盖真实点数；没有实际模型结果不加星号。

来源：[ggplot2 reference](https://ggplot2.tidyverse.org/reference/index.html)。本配方尚未在指定项目 R 环境执行。

### R2 ComplexHeatmap：多注释矩阵

**输入格式**：数值或离散矩阵，唯一 row/column names；独立 annotation 表，键严格匹配。分类标签不能借由读取失败被转成 NA 或数值。

**操作**：先显式重排注释到矩阵顺序并断言 ID 集合一致；决定保留顺序或聚类，记录 distance/linkage 与过滤；用 `Heatmap()` 和 `HeatmapAnnotation()` 组织主矩阵和样本/质量轨道；使用固定色标，缺失指定专用颜色。presence/absence 与 copy number 分开；行 z-score 另存原值。

**交付/验收**：在 PDF/SVG 设备内调用 `draw()`；大矩阵可只栅格化 tile 层并注明。保存原矩阵、展示矩阵、最终顺序、聚类对象/设置及脚本。抽查原值→色块→legend，不能用热图聚类替代系统发育或统计显著性。

来源：[ComplexHeatmap complete reference](https://jokergoo.github.io/ComplexHeatmap-reference/book/)。

### R3 circlize：环形轨道与连接

**输入格式**：`sequence_id,length`，带坐标约定的 interval/value 表，以及起终点 ID/坐标明确的 link 表。先判断输入是否真闭环、线性 contig 或人为排列。

**操作**：用 `circos.initialize()` 指定 sector 和范围；按同一坐标绘制注释/数值轨道，固定间隔与值域；用 link 层表达已有对应关系；每幅图结束 `circos.clear()`，防止上图布局状态污染下一图。更换方向或起点时保留坐标变换表。

**交付/验收**：PDF/SVG、sector 顺序与原坐标表。检查跨原点区间、正负链、轨道尺度、标签是否裁切。碎片化 MAG 必须画出 contig 缝隙并标明环形布局不代表完整闭环。

来源：[circlize 作者手册](https://jokergoo.github.io/circlize_book/book/)。

### R4 gggenes：少量基因邻域

**输入格式**：`molecule,start,end,strand,gene_id,homology_group`；将 GFF3 的 1-based closed 或其他来源坐标明确转换为绘图约定。不得为“对齐漂亮”改动原始注释。

**操作**：`geom_gene_arrow()` 映射 `xmin/xmax/y`，方向用实际 strand 映射到 `forward`；`geom_gene_label()` 加短标签；围绕共同锚基因对齐时记录平移/反转。独立 facet 的 free scale 会改变视觉比较，图注必须说明是否同一比例尺。

**交付/验收**：SVG/PDF、完整基因表、短标签对照和坐标变换。抽查正反链各一基因与边界基因；区分同名注释和已证实同源。

来源：[gggenes 作者文档](https://wilkox.org/gggenes/)。

### R5 gggenomes：多序列共线性与注释轨道

**输入格式**：显式命名的 sequence、gene/feature 和 alignment/link 数据集，ID 对应同一 FASTA/GFF3 版本。保留 link 的起终点、方向和 identity，不把缺失连接补成相似块。

**操作**：通过当前版本支持的 readers 或已审核适配器建立轨道；`gggenomes()` 组装数据，再添加 sequence/gene/link 图层。先用两条序列检验坐标和反向连接，再扩展到实际集合。自动排布与翻转属于显示变换，记录最终顺序及对应关系。

**交付/验收**：脚本、标准化输入表和 SVG/PDF；核对 contig 边界、长度比例与阈值，避免布局翻转被当作实际生物重排。

来源：[gggenomes 官方入门](https://thackl.github.io/gggenomes/articles/gggenomes.html)。

## Python 路线

### P1 Matplotlib / seaborn：可审计静态图

**输入格式**：审核后的长表或矩阵；join 保留字符串 ID。热图不允许无说明地把 NA 填零。

**操作**：显式创建 Figure/Axes、物理尺寸、色标范围和 tick/legend；`seaborn.heatmap()` 用于固定顺序，`clustermap()` 仅在聚类有意义且满足缺失值处理要求时使用。若已有科学树顺序，不再隐式聚类打乱。对同一系列面板复用具名颜色映射。大数据层可栅格化，文字/图例保留矢量。

**交付/验收**：`savefig()` 分别输出 SVG/PDF/PNG；clustermap 使用其绘图对象的保存方法并检视是否裁切。保存实际变换矩阵、最终顺序和 Python 脚本。导出后实际打开，检查字体替换、颜色范围、位图嵌入与页边界。

来源：[Matplotlib savefig](https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.savefig.html)、[seaborn clustermap](https://seaborn.pydata.org/generated/seaborn.clustermap.html)。本 skill 已有本地 renderer 的实测范围仅以当次产物和验收记录为准，不能扩展为所有 Python 配方均通过。

### P2 Plotly：可筛选交互图与 Sankey

**输入格式**：稳定 ID 长表；Sankey 使用 nodes 和 `source,target,value`，节点索引必须来自固定映射。bin 拆分/吸收推荐按无重复 bp 流量，而非强制守恒的 bin 个数。

**操作**：hover 显示原始 ID、样本、单位和证据；独立保留缺失状态；保存 Figure JSON 和本地 HTML。敏感数据不发布到公共 chart 服务。需要离线查看时把必要 JS 放在本地包或嵌入 HTML，并核对是否仍引用远程资源。

**交付/验收**：交互 HTML 之外提供静态 SVG/PDF/PNG。静态导出依赖当前 Plotly/Kaleido 和浏览器条件，先核验，不因导出失败临时安装。WebGL 图层可能以栅格嵌入矢量文件，应标明。抽查 Sankey 各阶段流量和所有孤立/丢弃状态。

来源：[Plotly static export](https://plotly.com/python/static-image-export/)。

### P3 pyGenomeViz：基因组比较图

**输入格式**：已有 GenBank/FASTA、注释和对齐信息。若仅要求画图，使用已存在的 alignment；重新调用比对工具属于额外分析，需匹配已授权范围和当前流程门控。

**操作**：按官方 API 建立 GenomeViz、feature tracks/segments，添加基因与实际匹配 link；选定坐标/颜色/identity 阈值并记录。先检验两个方向不同的区段；native readers 的坐标转换与 GFF3/BED 约定不能重复应用。

**交付/验收**：脚本、原注释/对齐哈希、标准化 link 表；通过当前版本实际支持的接口保存静态图和需要时的 HTML。分别检查反向链接、边界、缺测与标签，不能将近邻关系自动说成共线保守机制。

来源：[pyGenomeViz 官方文档](https://moshi4.github.io/pyGenomeViz/)。

## 树图桌面/在线工具

### T1 iTOL：注释树与可移植导入包

**输入格式**：原始 Newick/Nexus/PhyloXML 等受支持树；唯一叶 ID 的 metadata；COLORSTRIP、HEATMAP、TEXT 等按当前官方模板生成的注释文件。先完成 tree tips↔metadata 的集合与唯一性检查。

**操作**：在本地生成树副本、样本/组/phylum/species 色条和图例；明确枝长、根的显示意义和支持字段。`SH-aLRT/UFBoot` 复合标签不能只凭斜杠自行解释顺序；sCF 仅通过已审核的分支对应加入。获得上传授权后才能在网页导入树和 datasets，调整环/矩形布局；导出设置和文件随包保存。

**交付/验收**：树原件、注释文本、ID 索引、可编辑设置记录、SVG/PDF 与 PNG；检查每个 tip 可查、缺值可见、数值支持正确。大树给概览和细节，不只一张字不可读的圆树。部分导出/自动接口受账户条件影响，以实际可用功能为准。

来源：[iTOL 官方帮助及模板](https://itol.embl.de/help.cgi)。无上传授权时交付本地导入包，不宣称已在 iTOL 完成渲染。

### T2 FigTree：本地树排版

**输入格式**：Newick/Nexus 树和可识别注释；原树只读保存。**操作**：打开副本，明确内部标签对应的支持统计量，配置 tip/node labels、枝长比例尺、颜色与显示根；需要改变根/旋转时保存为显示衍生文件并记录变换。不要把 support 文字当枝长，或误把概率与百分数共用刻度。

**交付/验收**：保存含设置的工作文件及当前版本实际支持的矢量导出；另存原始 Newick和 metadata。回读导出树，核对叶集合、未根化 split、枝长与支持；纯布局改变不应改科学关系。对大树的缩放/字体需实际检查，格式是否保留所有注释以回读为准。

来源：[FigTree 作者主页](https://tree.bio.ed.ac.uk/software/figtree/)。

### T3 Dendroscope：本地树/网络探索

**输入格式**：当前版本支持的树或系统发育网络格式；先用小的真实副本检查内部标签与网络节点解释。**操作**：导入后选择树/网络对应布局，核对叶 ID 和支持；保留原生工程与导出设置。不要把网络边当 ML 树分支，或把局部旋转/折叠误当改变拓扑的科学推断。

**交付/验收**：原件、显示衍生树/网络、当前版本支持的矢量图和操作记录。隐藏/折叠节点必须在图注明；保留展开版本及完整 ID 索引。某格式若丢失注释，不能用该导出覆盖输入。

来源：[Dendroscope 作者官方仓库](https://github.com/husonlab/dendroscope3)。主页入口抓取不稳定，此处仅核实作者仓库的工具定位；具体格式/导出选项必须查当前安装帮助，未在本机 GUI 实测。

## 网络、QC 和序列浏览

### N1 Cytoscape / Gephi：证据网络

**输入格式**：nodes 表唯一 `id,type,sample,group`，edges 表 `source,target,evidence,score,directed`；Cytoscape 可用表格导入，Gephi 可使用 CSV/GEXF/GraphML 等当前支持格式。保留未连接节点，先验证所有端点存在。

**操作**：分别导入边和节点属性，明确方向与多重边规则；节点色/形映射类型，边型映射证据，而不是把所有预测 score 当统一概率。运行选定布局，记录参数与固定坐标；只在正确图模型下解释 degree/centrality。布局靠近不证明相互作用。

**交付/验收**：Cytoscape `.cys` / Gephi `.gephi` 工程、原表、最终坐标及当前版本支持的 SVG/PDF等矢量导出。核查孤立节点、边数、方向箭头、并行边与图例；科学网络不允许为了美观静默删边。网络上传/共享需单独核对授权。

来源：[Cytoscape 创建/导入网络](https://manual.cytoscape.org/en/stable/Creating_Networks.html)、[Cytoscape 官方手册](https://manual.cytoscape.org/en/stable/)、[Gephi 导入手册](https://docs.gephi.org/desktop/User_Manual/Import/)。

### Q1 MultiQC：汇总现有分析报告

**输入格式**：已有 FastQC/fastp/比对等工具报告与配置，避免把未完成文件和多个历史版本混入同一路径。**操作**：核对报告所属 run 与样本；按当前 `multiqc --help` 指定输入和新的输出目录。典型模式是 `multiqc REPORT_DIR -o NEW_OUTPUT_DIR`；先验证 sample cleaning/重名规则，必要时使用明确配置，不能让同名文件静默覆盖样本。

**交付/验收**：HTML、`multiqc_data` 解析数据、配置和完整日志。核对每模块样本数/阶段、被忽略文件与统计单位。需要单张出版图时从解析表在 R/Python 重新绘制并保留数据来源，不把网页截图当唯一可编辑产物。MultiQC 仅汇总已经产生的统计，不执行 QC 或替代科学验收。

来源：[MultiQC overview](https://docs.seqera.io/multiqc)、[MultiQC 运行指南](https://docs.seqera.io/multiqc/getting_started/running_multiqc)。

### Q2 IGV：覆盖、变异和注释的局部核查

**输入格式**：完全一致的参考 FASTA/索引，排序并有索引的 BAM/CRAM，VCF/BCF 及所需索引，或 BED/bedGraph/bigWig/GFF3 等轨道。CRAM 解码依赖正确参考；染色体/contig 名不可盲目删除前缀。

**操作**：先加载本地参考，再加载 reads 与注释；定位实际坐标，记录覆盖尺度、MAPQ、重复、多重比对和下采样显示设置。比较不同样本时决定统一 y 轴；放大后核对碱基和成对证据。不要只凭 overview 柱形判断变异真实存在。

**交付/验收**：保存 session、确切 locus、参考/轨道哈希及截图；当前版本能否导出 SVG 等矢量须实际确认，不支持时保留原始分辨率截图并用外部矢量框架添加说明。打开 session 复核路径可用，截图图例与原数据一致。界面截图不是原始 alignment 的替代。

来源：[IGV Desktop 官方文档](https://igv.org/doc/desktop/)。本次未启动 IGV；不承诺未核验的导出选项。

### Q3 Krona：分类组成的交互探索

**输入格式**：计数/丰度与完整 taxonomy 路径的表，明确每级分类与分母。不同样本数据集需保留独立 sample ID。**操作**：使用当前安装版导入器支持的表结构，核对默认列含义后生成本地 HTML；不要把 relative abundance 再当 reads count 求和。保留 unclassified 与被过滤类群。

**交付/验收**：自包含性经检查的 HTML、输入表、分类库/层级/分母记录；导出稳定静态概览可用相同数据在 R/Python 重绘。Krona 用于层级探索，面积不提供差异显著性，也不替代每个样本的可比较统计图。

来源：[Krona 官方仓库](https://github.com/marbl/Krona)。

## 专门输入的最小操作路线

### S1 KEGG Mapper / pathview

把实际 KO/基因 ID 与数值按所选工具格式导出，先计算未映射列表；决定多基因节点聚合规则，选择真实 pathway ID。pathview 使用当前文档支持的本地 R 接口；KEGG Mapper 网页操作会传输提交的 ID/数值，未经明确授权不提交。保存原映射表、处理后节点值、图源版本及许可信息；原生通路图片可能为栅格，不能称为完全可编辑矢量图。具体 R 示例、KO 数值聚合和本地资源检查见[功能R配方](functional-r-recipes.md)；模块逻辑和多库追溯见[数据契约](functional-data-contract.md)。

来源：[KEGG Mapper](https://www.kegg.jp/kegg/mapper/)、[Bioconductor pathview](https://bioconductor.org/packages/release/bioc/html/pathview.html)。只有映射完成不等于富集检验或通路活性已证实。

### S2 Fiji / ImageJ：实验图像与比例尺

读入原图和元数据，核对像素尺寸、单位、通道及 z 信息；先保存无损原图副本，再应用可重复的显示范围、ROI、分割和 scale bar overlay。比例尺由真实 calibration 生成，不能由显示窗口宽度猜测。相同组间比较保持处理一致；保存原图、ROI/掩膜、参数/宏和高分辨率展示图。版面可用 SVG/PDF 包裹真实栅格图，但不声称实验图像变成矢量。

来源：[ImageJ spatial calibration](https://imagej.net/imaging/spatial-calibration)。图像采集与分割误差需在生物统计前处理，视野不自动成为独立重复。

## 适配新的分析工具时

先读取实际 TSV/CSV/JSON 或结构化报告与当前帮助，再写小型只读适配器；使用固定的非生产测试输入核对 ID、范围、分母、NA、坐标和双重计数。新格式转换失败时保留来源与失败证据，不用“默认0”填平问题。只把已运行、已审阅的科学统计放入图；本页软件列表不证明数据已经满足对应统计模型的条件。
