# 微生物基因丰度的 WGCNA：从适用性到模块、性状和功能解释

本指南用于**网络分析设计与绘图**，不是把 TPM 热图自动升级成网络证据。先说明网络拟回答的问题、独立样本数、DNA/RNA、基因目录及定量单位、过滤与变换、需要控制的混杂、资源成本、验证计划，再选择是否建网。文档和脚本的交付不等于本项目已经运行或验证 WGCNA。

导航：适用性与命名 → 输入与预处理 → 分阶段运行 → 图种 → 功能整合 → 稳定性 → 资源与验收。

## 1. 本项目的默认决策和通用适用性

DBDPE 的 12 个样本是 12 个独立笼混样，每笼 5 鼠不是 5 个可拆开的重复。C/L/M/H 各 3 笼，不能分别建立组内 WGCNA，不能把 contig、MAG、基因数量或软件重采样增加到样本数中。

官方 FAQ 不建议少于 15 个样本，能达到 20 个以上更好。因此本项目默认做基因/KO/KEGG module/pathway 的描述图和 WGCNA 适用性检查；**12 笼下不自动产出“可靠网络”“核心驱动基因”结论**。明确讨论后可用脚本的低样本探索开关考察可行性；图和表始终标注探索，默认不输出小样本关联 p/q 值。15 或 20 并非有效性的认证线。过滤应基于整体丰度、检出率和变异，不能先挑差异基因建网；优先考察 signed 网络和带限制的 bicor，二元性状关闭 Y 的稳健处理。[WGCNA 作者 FAQ](https://edo98811.github.io/WGCNA_official_documentation/faq.html)

这里有三个必须分开的概念：

| 名称 | 数据含义 | 能说明什么，不能说明什么 |
| --- | --- | --- |
| DNA 基因共丰度模块 | 宏基因组基因在样本间的丰度协变 | 可能反映菌群组成、基因拷贝、同一基因组/contig 或共同变化；不是共表达、直接相互作用或调控网络 |
| RNA 基因共表达模块 | 宏转录组定量，经记录的归一化/变换 | 与表达协变有关；仍受物种丰度和组成效应影响，最好联合匹配 DNA 分析，不自动等于调控 |
| KEGG MODULE / pathway | 数据库定义的反应/功能集合与逻辑 | 是外部功能知识；WGCNA 模块颜色/编号只是数据驱动聚类，两者不得混称 |

TPM 是相对量。共同的分母会引入组成相关；直接在 TPM 上建 Pearson/bicor 网络不会解除闭合约束。优先查看定量流程、零值和测序深度；可设计经理由支持的 log(TPM+1)、经归一化的计数/方差稳定化，或 CLR 等敏感性视图。CLR 的零替代及参考基因集合必须固定记录；不能在每个差异子集上重新 CLR 后宣称可直接比较。DNA/RNA 配对比例需要可比的基因目录和检测/零值策略，不能对两个独立 TPM 分母机械相除宣称“转录活性”。这些是本指南的微生物数据分析约束，不是 WGCNA 对所有微生物数据的官方认证。

## 2. 输入契约

`scripts/wgcna_analysis.R` 读取两个 UTF-8 TSV，样本为行、基因为列：

```text
# matrix.tsv（真实文件无此注释）
sample_id    gene_001    gene_002    gene_003
C1           2.5         0           19.7
C2           4.1         1.2         20.0
```

```text
# metadata.tsv
sample_id    cage_id    group    body_weight
C1           cage_C1    C        23.1
C2           cage_C2    C        24.5
```

- `sample_id`、gene ID、metadata 列名均唯一且非空；metadata 与矩阵样本集合完全一致，按明确 ID 重排。脚本拒绝取交集和静默删除样本。
- 独立单位列必须完整且唯一。重复测量/多个技术文库来自同一宿主或同一笼时，此工具直接拒绝；先设计聚合或重复测量模型，而不是换个 ID 骗过检查。唯一 ID 不能自行证明独立，仍需实验元数据证据。
- `--assay dna|rna` 与 `--unit TPM|normalized_counts|VST|log_abundance|CLR` 必填。原始 counts 不接受；归一化、比对多重分配、有效长度、批次处理与基因目录版本写入 `--preprocessing-note`，另保留其上游脚本/参数/指纹。
- TPM/normalized_counts 使用显式 `--transform log2p1`。VST/log_abundance/CLR 使用 `none`，不重复取 log；在上游做检出率过滤并记录。
- 工具对未变换丰度提供 `min-abundance`（严格大于此值视作检出）与 `min-prevalence`；所有数据都要求正方差、正 MAD，并删除有缺失的基因，保存完整过滤表。**未检出 0 不等于未定量 NA**，不把 NA 填 0。
- 正 MAD 是此保守工具的明确过滤策略，会排除多数样本值相同的稀疏基因；要换用别的策略必须修订设计和重做诊断，不可仅为得到目标模块调阈值。
- `group` 永远作为类别，C/L/M/H 不转成 1/2/3/4。可声明真实连续性状；脚本不自动批次校正、不拟合协变量或纵向模型。批次/宿主/测序深度与组完全混杂时，不存在可靠的自动“校正掉批次”。

## 3. 三阶段 R CLI

只使用已安装的 R/WGCNA；本工具不安装包、不下载数据库。以下为**待替换路径的命令示例**，不是当前项目运行收据。每次 `--out` 必须新建，不覆盖以前的结果。

```bash
Rscript --vanilla scripts/wgcna_analysis.R --mode preflight \
  --matrix samples_x_genes.tsv --metadata metadata.tsv --out out_preflight \
  --assay dna --unit TPM --transform log2p1 \
  --preprocessing-note 'gene catalog v1; paired-fragment quantification; mapped library TPM; no differential selection' \
  --independent-unit cage_id --dataset-kind biological --group group
```

预检不依赖 WGCNA 包：检查数据、样本单位、过滤、资源和包可用性，画样本聚类与变异分布，输出 `preflight.tsv`、样本与基因索引、变换后的实际矩阵。`DESCRIPTIVE_ONLY_LOW_N` 是科学适用性结论，不应被解释为程序故障。

`powers` 在同一输入/设计上显式扫描候选 power，输出 fit index、斜率、平均/中位/最大连接度，保存完整诊断表及 RDS。输入行列方向和这些诊断量与官方函数约定一致；它的 `powerEstimate` 只是阈值规则给出的候选，本工具不自动采用。[pickSoftThreshold 文档](https://search.r-project.org/CRAN/refmans/WGCNA/html/pickSoftThreshold.html)

```bash
# 在上面所有共同参数不变的基础上，改 --mode powers 和 --out out_powers。
# 12 笼如已讨论探索设计，另外显式写：
# --exploratory-low-n true --exploratory-reason '仅技术探索；不作可靠模块/因果结论'
```

打开软阈值图和样本 QC，检查强组间分离、异常样本、连接度塌陷、斜率、参数敏感性；不机械把 R² 达到 0.8/0.9 当作分析通过。写 power 选择说明文件，记录备选及取舍。`fit` 必须指向这次实际诊断目录和说明文件：

```bash
# 复制同一组共同参数，改为：
# --mode fit --out out_fit --power 12 \
# --powers-run out_powers --power-review power_selection.txt
# 12 是语法示例，不是给本项目选定的 power。
```

脚本比较输入文件、脚本、过滤/变换/资源/网络参数的实际合同，拒绝换数据后套旧 power 图。`blockwiseModules` 使用 signed adjacency/TOM、bicor、maxPOutliers=0.05、显式 power/线程/模块大小/合并阈值，保留随机种子和 sessionInfo。大网络分块可能改变候选聚类，应按资源与科学目标选定；模块编号不是跨运行稳定 ID。[blockwiseModules 文档](https://search.r-project.org/CRAN/refmans/WGCNA/html/blockwiseModules.html)

关联图使用模块 eigengene × 分类组 one-hot/声明连续性状；二元组变量 `robustY=FALSE`。组 one-hot 相关是“这一组与其余样本”的边际描述，**不是控制其他协变量的组间模型或全组 omnibus 检验**。需要协变量时另拟 `eigengene ~ factor(group) + covariates` 并预先确定对比及多重检验族。脚本的 BH 家族固定为全部非灰模块 × 全部声明性状，不先筛显著模块；Student 近似 p 值不适合被称为置换检验。低于 15 样本的探索输出 p/q=NA。[bicorAndPvalue 文档](https://search.r-project.org/CRAN/refmans/WGCNA/html/bicorAndPvalue.html)

## 4. 完整图组及具体解释

| 图种 | 目的和输入 | R/软件路线 | 验收及解读限制 |
| --- | --- | --- | --- |
| 样本聚类 + metadata 色带 | 看异常、批次、组与测序深度；矩阵和精确样本表 | helper 的 sample_qc；扩展用 WGCNA::plotDendroAndColors / ComplexHeatmap | 聚类不是 phylogeny；保留全部独立样本，不按喜欢的结果删离群点 |
| 软阈值诊断图 | 共同检查拟合、斜率与连接度 | helper 的 power_diagnostics PDF/SVG/PNG | 不只展示过阈值的一个点；本项目 power 尚未选择 |
| 基因聚类树 + 模块颜色 | 看数据驱动模块和分块边界 | helper 的 block dendrogram；WGCNA::plotDendroAndColors | 这是基因丰度相似性树，不是基因进化树；灰色未分配不是无功能 |
| 模块 eigengene 样本热图 | 看模块在 12 笼中的模式 | module_eigengenes.tsv → ComplexHeatmap/pheatmap，列顶标组与笼 | 特征向量符号任意；可比较模式，不把正负解释成激活/抑制机制 |
| 模块—性状热图 | 报告方向、效应及全族校正 | helper 的 heatmap + module_trait_associations.tsv；复杂协变量用独立模型后再画 | 显示 r、样本数、p/q 的具体定义；小样本不标显著星号 |
| Eigengene 组间点图/箱线图 | 让独立重复数量清楚 | helper 每模块 eigengene 图；ggplot2::geom_point/boxplot | n=3/组必须展示全部点；不以单一均值/SEM 掩盖分布 |
| kME 与性状关联散点 | 候选基因在模块中的代表性 | gene_kME_all_modules.tsv 加独立基因关联表 → ggplot2 | kME 是模块成员相关，不能称关键驱动；缺失、负号、多个检验均保留 |
| 模块内部网络/邻接热图 | 展示经声明的边阈值和核心子图 | 小模块 adjacency/TOM 子矩阵 → ComplexHeatmap；igraph/ggraph/Cytoscape | 区分 correlation、adjacency、TOM 三种边；完整边表及筛选阈值必须保存；不画百万节点毛线球 |
| 模块 × KEGG/COG/arCOG 富集点图 | 外部功能对网络模块的解释 | 模块 gene ID join 到完整注释长表 → hypergeometric/permutation 方案后 ggplot2 | 富集背景是此次可检测、通过同一过滤、具相应注释机会的基因；全模块×全部功能族 BH；不能只挑目标 pathway |
| 模块 → KO → KEGG MODULE/pathway alluvial | 连通统计聚类与数据库层次 | ggalluvial/igraph；加 contig/MAG 维度时分页 | 颜色/线宽含义必须明确是基因数还是丰度；一基因多注释不能重复扩增总量 |
| Contig 位置 + 模块颜色 + 功能基因箭头 | 同一模块是否聚集于同一基因组邻域 | gggenes/gggenomes；坐标、方向、gene ID、WGCNA模块和KO注释表 | 同一 contig 会天然共丰度；邻接≠操纵子≠互作，断裂/负链/未知功能不可隐藏 |
| 跨样本/重采样稳定性热图 | 检验一个样本是否驱动模块 | helper 可选 LOO best-Jaccard 表 → ggplot2；WGCNA::modulePreservation | 颜色号不等同跨次模块；用共享基因匹配并报告分裂合并；内部重采样非外部验证 |

当前 helper 已编码预检、power、分块聚类、模块—性状、eigengene 点图和数据导出；网络子图、功能富集、alluvial、基因位置整合属于上述扩展路线，不能宣称 helper 自动算完它们。运行实际图后按本 skill 图像规范检查：样本完整性、色标、模块/基因 ID、长标签、空模块、灰模块、极端值、分页、合成标记、图表数值一致。

## 5. 将网络模块连回基因、contig、KO 与功能

建立可追溯的 `gene_id → contig_id/start/end/strand → MAG/taxon`，另保留每种数据库的 `gene_id → annotation_id/version/evidence` 长表。网络模块只在 gene ID 处 join，绝不用注释描述字符串当唯一基因 ID。

建议一次回答三个层面的问题：

1. **协变是否主要来自宿主数量？** 对每个网络模块绘制基因所属 contig/MAG/taxon 比例，并比较 MAG/contig 丰度；跨 MAG 分布不自动证明生态互作。可设计在宿主丰度控制后的敏感性分析，但不能通过反复残差化寻找想要的模块。
2. **功能是否在同一基因组内形成路径？** 按每个 MAG/contig 的实际 KO 覆盖判断 KEGG module 的 AND/OR/复合体逻辑；群落拼起来的 KO 集不能证明单个微生物拥有完整通路。contig 缺基因还可能是装配截断。
3. **处理是否改变模块模式？** 使用 12 个笼级 eigengene/功能汇总原值，分类组比较；先呈现点图和效应范围。12 笼探索网络不把分组相关包装成确证结论。

功能富集及网络内部 hub 候选应再返回原始 reads 覆盖、比对特异性、基因长度/多重比对、序列完整性和注释置信度。网络边、邻域共定位、数据库关联是不同证据层，用不同颜色/线型/图例，不混进同一种“关联”。

## 6. 稳定性、资源与退出条件

`--stability loo` 明确加做 n 次留一独立样本重建，同一基因集合/power/参数；输出模块 best-match Jaccard，并记录失败和未分配。该分数是非对称描述指标，不是 p 值或独立验证。默认不运行，避免无意触发 n 倍计算。更大队列可设计独立单位 bootstrap、模块 preservation 或保留验证集；必须保留原始抽样单位和批次结构，不能重采样基因来伪增样本。官方 sampledBlockwiseModules 是可选的样本重采样实现。[样本重采样文档](https://search.r-project.org/CRAN/refmans/WGCNA/html/sampledBlockwiseModules.html)

资源先估算：单个 b×b double 矩阵约 8b² 字节，实际 adjacency/TOM/副本/聚类往往同时存在。helper 的 6 倍矩阵加数据副本仅为保守筛查启发，不是峰值保证，也不是硬内存配额；TSV 本身一次读入，占用需另测。默认 `max-block-size=2000`、`threads=1`、`memory-gb=4`；在独立预试中测 1/2/4/8 线程和不同 block-size 的 wall time、CPU、RSS，再定正式资源。不可用 CPU 占用当加速倍数。

WGCNA 的相关计算线程与 BLAS 线程是不同层；在启动 R 前设置 `OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 OMP_NUM_THREADS=<预算>` 并记录 R sessionInfo/BLAS 信息。脚本也设置这些值，但 R 启动后改变环境不保证已加载 BLAS 生效。遵守进程 CPU affinity/调度器资源预算；若 BLAS 使用线程，再相应减少外层并行，避免嵌套超卖。缺包时只报告能力缺口，不在已冻结生产环境里安装。

每轮输出保持 `PREVIEW` 和科学/视觉未验收状态。若样本、计量方式、功能映射、power稳定性或资源不支持问题，应收束为描述性结果或补样设计，而不是调参数直到出现理想图。DBDPE 当前 12 笼的默认停止点是描述性/预检；已有 MAG 系统发育任务不因此改变。
