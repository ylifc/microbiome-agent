"""Runtime identity and effective capabilities; no model, initialization or writes."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

from microbiome.protocol import PROTOCOL_VERSION
from microbiome.version import __version__


def runtime_capabilities(project=None):
    package = Path(__file__).resolve().parents[1]
    contracts = {}
    for name in ('maintenance', 'database'):
        path = package / 'pipeline' / f'{name}_contract.json'
        if path.is_file():
            raw = path.read_bytes()
            value = json.loads(raw)
            contracts[name] = {'schema_version': value['schema_version'],
                               'sha256': hashlib.sha256(raw).hexdigest(),
                               'operations': list(value['operations']),
                               'common_arguments': value.get('common_arguments', {}),
                               'operation_schemas': {op: spec['parameters'] for op, spec in value['operations'].items()}}
    value = {'schema_version': 1, 'engine_version': __version__,
             'protocol_version': PROTOCOL_VERSION,
             'plugin_sha256': hashlib.sha256((package / 'harness/plugin.mjs').read_bytes()).hexdigest(),
             'python_executable': sys.executable, 'runtime_root': sys.prefix,
             'package_root': str(package), 'contracts': contracts,
             'features': {'bound_file_reads': True, 'structured_input_repair': True,
                          'planning_policy': True, 'complete_request_budget': True,
                          'planning_recovery': True, 'database_service': 'database' in contracts,
                          'native_delegated_checkpoints': True, 'inline_read_operations': True,
                          'diagnostic_snapshot': True, 'conversation_export_integrity': True},
             'project': None, 'execution_started': False,
             'next_action': {'tool': 'microbiome_maintenance', 'operation': 'inspect'}}
    if project is not None:
        from microbiome.pipeline.project import PipelineProject
        from microbiome.pipeline.maintenance import permission_snapshot
        from microbiome.pipeline.maintenance_read import effective_paths
        from microbiome.pipeline.database_service import database_permissions
        instance = project if isinstance(project, PipelineProject) else PipelineProject(project)
        # require_layout() repairs directories/registries; a probe must only read.
        instance.load_config()
        value.update(project=str(instance.root), effective_paths=effective_paths(instance),
                     permissions=permission_snapshot(instance), database_permissions=database_permissions(instance))
        from microbiome.pipeline.planning_policy import inspect_policy
        from microbiome.pipeline.errors import ConfigurationError
        try:
            value['planning_policy'] = inspect_policy(instance)
        except ConfigurationError as error:
            # A planning setting must not become a new prerequisite for
            # replaying an already validated frozen execution contract.
            value['planning_policy'] = {'available': False, 'diagnostic': getattr(error, 'details', {'message': str(error)})}
    return value


def check_host_contract(expected, actual=None):
    """An old host may omit attestation; an attested mismatch must never run work."""
    from microbiome.pipeline.errors import ConfigurationError
    if expected is None:
        return
    if not isinstance(expected, dict) or set(expected) != {'engine_version', 'protocol_version', 'plugin_sha256', 'contracts'}:
        raise ConfigurationError('INVALID_CAPABILITY_ATTESTATION')
    actual = actual or runtime_capabilities()
    differences = []
    for key in ('engine_version', 'protocol_version', 'plugin_sha256'):
        if expected[key] != actual[key]:
            differences.append(key)
    if not isinstance(expected['contracts'], dict):
        differences.append('contracts')
    else:
        for name in ('maintenance', 'database'):
            if expected['contracts'].get(name) != actual['contracts'].get(name, {}).get('sha256'):
                differences.append('contracts.' + name)
    if differences:
        error = ConfigurationError('CAPABILITY_MISMATCH: reload a matching plugin and backend installation')
        error.details = {'code': 'CAPABILITY_MISMATCH', 'mismatched_fields': differences,
                         'actual': actual, 'next_action': {'operation': 'runtime.capabilities',
                         'reason': 'Compare installed plugin and backend; reload the corrected installation.'}}
        raise error
