"""Explicit OpenAI-compatible endpoint discovery, without credential lookup."""
from __future__ import annotations

from dataclasses import dataclass
from urllib.parse import urlsplit, urlunsplit


class EndpointError(RuntimeError):
    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(message)


def normalize_endpoint(value: str) -> str:
    value = value.strip()
    if "://" not in value:
        value = "http://" + value
    parsed = urlsplit(value)
    try:
        port = parsed.port
    except ValueError as error:
        raise EndpointError("ENDPOINT_URL", "Endpoint has an invalid port") from error
    if (parsed.scheme not in {"http", "https"} or not parsed.hostname
            or parsed.username or parsed.password or parsed.query or parsed.fragment
            or any(character.isspace() for character in value)):
        raise EndpointError("ENDPOINT_URL", "Use an explicit HTTP(S) endpoint without credentials, query or fragment")
    if port is not None and not 1 <= port <= 65535:
        raise EndpointError("ENDPOINT_URL", "Endpoint port must be between 1 and 65535")
    path = parsed.path.rstrip("/")
    for suffix in ("/chat/completions", "/models"):
        if path.endswith(suffix):
            path = path[:-len(suffix)]
            break
    if not path:
        path = "/v1"
    return urlunsplit((parsed.scheme, parsed.netloc, path, "", ""))


def _request(base: str, path: str, *, body: dict | None = None, timeout: float = 20) -> dict:
    import httpx

    url = base + path
    try:
        # Do not pick up proxy credentials, ambient Authorization or alternate cloud endpoints.
        with httpx.Client(trust_env=False, follow_redirects=False, timeout=timeout) as client:
            response = client.get(url) if body is None else client.post(url, json=body)
    except httpx.TimeoutException as error:
        raise EndpointError("ENDPOINT_TIMEOUT", f"Endpoint did not answer {path} within {timeout:g} seconds") from error
    except httpx.HTTPError as error:
        raise EndpointError("ENDPOINT_UNREACHABLE", f"Cannot connect to the explicitly supplied endpoint {base}") from error
    if response.status_code in {401, 403}:
        raise EndpointError("ENDPOINT_AUTH_REQUIRED", f"Endpoint returned HTTP {response.status_code} for {path}; "
                            "its local/gateway route is not accessible without authentication. "
                            "Microbiome does not read host credentials; expose an authorized local route or use the host MCP integration.")
    if 300 <= response.status_code < 400:
        raise EndpointError("ENDPOINT_REDIRECT", f"Endpoint redirected {path}; supply its intended final API URL explicitly")
    if response.status_code >= 400:
        raise EndpointError("ENDPOINT_HTTP", f"Endpoint returned HTTP {response.status_code} for {path}; "
                            "this route must support OpenAI-compatible /models and /chat/completions")
    try:
        payload = response.json()
    except ValueError as error:
        raise EndpointError("ENDPOINT_PROTOCOL", f"Endpoint returned non-JSON content for {path}") from error
    if not isinstance(payload, dict) or payload.get("error"):
        raise EndpointError("ENDPOINT_PROTOCOL", f"Endpoint returned an invalid or error response for {path}")
    return payload


def _message(payload: dict) -> dict:
    choices = payload.get("choices")
    if not isinstance(choices, list) or not choices or not isinstance(choices[0], dict):
        raise EndpointError("ENDPOINT_CHAT_PROTOCOL", "Chat response must include choices[0].message")
    message = choices[0].get("message")
    if not isinstance(message, dict) or message.get("role", "assistant") != "assistant":
        raise EndpointError("ENDPOINT_CHAT_PROTOCOL", "Chat response must contain an assistant message")
    content = message.get("content")
    calls = message.get("tool_calls")
    if not (isinstance(content, str) and content.strip()) and not (isinstance(calls, list) and calls):
        raise EndpointError("ENDPOINT_EMPTY_CHAT", "Chat response contains no assistant text or tool calls")
    return message


@dataclass(frozen=True)
class EndpointRoute:
    endpoint: str
    model: str
    advertised_models: tuple[str, ...]
    probed_models: tuple[str, ...]

    def as_dict(self) -> dict:
        return {"endpoint": self.endpoint, "model": self.model,
                "advertised_models": list(self.advertised_models), "probed_models": list(self.probed_models),
                "protocol": "openai-chat-completions", "credentials": "none", "chat_verified": True}


def discover_endpoint(endpoint: str, *, timeout: float = 20) -> EndpointRoute:
    base = normalize_endpoint(endpoint)
    payload = _request(base, "/models", timeout=timeout)
    entries = payload.get("data")
    if not isinstance(entries, list):
        raise EndpointError("ENDPOINT_MODELS_PROTOCOL", "GET /models must return an object with a data array")
    models = {row["id"]: row for row in entries if isinstance(row, dict)
              and isinstance(row.get("id"), str) and row["id"].strip()}
    if not models:
        raise EndpointError("ENDPOINT_NO_MODELS", "Endpoint advertises no model IDs; load a chat model in the existing service")
    preferred = payload.get("default_model")
    if not isinstance(preferred, str):
        preferred = None
    candidates = sorted(models, key=lambda name: (
        0 if name == preferred or models[name].get("default") is True or models[name].get("is_default") is True else 1,
        name,
    ))
    attempts, failures = [], []
    for name in candidates[:3]:
        attempts.append(name)
        try:
            result = _request(base, "/chat/completions", body={"model": name, "stream": False,
                "messages": [{"role": "user", "content": "Reply with READY only."}], "max_tokens": 16}, timeout=timeout)
            message = _message(result)
            if not isinstance(message.get("content"), str) or not message["content"].strip():
                raise EndpointError("ENDPOINT_EMPTY_CHAT", "Probe did not produce assistant text")
            return EndpointRoute(base, name, tuple(sorted(models)), tuple(attempts))
        except EndpointError as error:
            if error.code in {"ENDPOINT_AUTH_REQUIRED", "ENDPOINT_REDIRECT", "ENDPOINT_UNREACHABLE", "ENDPOINT_TIMEOUT"}:
                raise
            failures.append({"model": name, "code": error.code, "message": str(error)})
    import json
    raise EndpointError("ENDPOINT_NO_CHAT_ROUTE", "No usable chat route among the first three advertised candidates: "
                        + json.dumps(failures, ensure_ascii=False))


def make_chat_model(route: EndpointRoute):
    """Build a LangChain client lazily; no provider SDK or key configuration."""
    import json
    from langchain_core.language_models.chat_models import BaseChatModel
    from langchain_core.messages import AIMessage
    from langchain_core.outputs import ChatGeneration, ChatResult

    class EndpointChatModel(BaseChatModel):
        endpoint: str
        model_name: str

        @property
        def _llm_type(self):
            return "explicit-openai-compatible-endpoint"

        def _generate(self, messages, stop=None, run_manager=None, **kwargs):
            wire = []
            for message in messages:
                entry = {"role": {"human": "user", "ai": "assistant"}.get(message.type, message.type),
                         "content": message.content}
                if getattr(message, "tool_calls", None):
                    entry["tool_calls"] = [{"id": call["id"], "type": "function", "function": {
                        "name": call["name"], "arguments": json.dumps(call["args"])}} for call in message.tool_calls]
                if getattr(message, "tool_call_id", None):
                    entry["tool_call_id"] = message.tool_call_id
                wire.append(entry)
            body = {"model": self.model_name, "messages": wire, "stream": False}
            if stop:
                body["stop"] = stop
            if kwargs.get("tools"):
                body["tools"] = kwargs["tools"]
            result = _request(self.endpoint, "/chat/completions", body=body, timeout=120)
            response = _message(result)
            calls = []
            try:
                for call in response.get("tool_calls") or []:
                    calls.append({"id": call["id"], "name": call["function"]["name"],
                                  "args": json.loads(call["function"]["arguments"]), "type": "tool_call"})
            except (KeyError, TypeError, ValueError) as error:
                raise EndpointError("ENDPOINT_TOOL_PROTOCOL", "Chat endpoint returned invalid function-call arguments") from error
            message = AIMessage(content=response.get("content") or "", tool_calls=calls,
                                response_metadata={"model_name": self.model_name, "usage": result.get("usage", {})})
            return ChatResult(generations=[ChatGeneration(message=message)])

        def bind_tools(self, tools, *, tool_choice=None, **kwargs):
            from langchain_core.utils.function_calling import convert_to_openai_tool
            if tool_choice not in (None, "auto"):
                raise ValueError("Explicit endpoint client supports automatic tool choice only")
            return self.bind(tools=[convert_to_openai_tool(tool) for tool in tools], **kwargs)

        def with_structured_output(self, schema, *, include_raw=False, **kwargs):
            from langchain_core.messages import HumanMessage, SystemMessage
            from langchain_core.runnables import RunnableLambda
            spec = schema.model_json_schema() if hasattr(schema, "model_json_schema") else schema

            def generate(value):
                messages = value.to_messages() if hasattr(value, "to_messages") else value
                if isinstance(messages, str):
                    messages = [HumanMessage(content=messages)]
                raw = self.invoke([SystemMessage(content="Return only JSON matching this schema: " + json.dumps(spec)), *messages])
                try:
                    value = raw.content.strip()
                    if value.startswith("```"):
                        value = value.split("\n", 1)[1].rsplit("```", 1)[0]
                    parsed = json.loads(value)
                    if hasattr(schema, "model_validate"):
                        parsed = schema.model_validate(parsed)
                    elif isinstance(schema, dict):
                        import jsonschema
                        jsonschema.validate(parsed, schema)
                except Exception as error:
                    if include_raw:
                        return {"raw": raw, "parsed": None, "parsing_error": error}
                    raise
                return {"raw": raw, "parsed": parsed, "parsing_error": None} if include_raw else parsed
            return RunnableLambda(generate)

    return EndpointChatModel(endpoint=route.endpoint, model_name=route.model)
