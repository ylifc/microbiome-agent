"""Versioned workflow operations shared by the JSON CLI and MCP adapter.

No model, network listener, implicit approvals, or scientific installation runs
at import/startup. Authoritative decisions remain in the existing pipeline.
"""
from __future__ import annotations

import contextlib
import hashlib
import sys
import threading
from pathlib import Path

from microbiome.pipeline.errors import ConfigurationError
from microbiome.pipeline.io import object_fingerprint, read_json, read_yaml, write_json, write_yaml
from microbiome.pipeline.project import PipelineProject

SCHEMA_VERSION = 1
_OUTPUT_LOCK = threading.RLock()
TOPICS = ("input", "dataset", "target", "analysis_goal", "analysis_plan", "dependencies", "production")


def project_at(project: str, *, read_only: bool = False) -> PipelineProject:
    if not Path(project).expanduser().is_absolute():
        raise ConfigurationError("project must be an absolute path on the execution machine")
    instance = PipelineProject(project)
    if read_only:
        instance.load_config()
    else:
        instance.require_layout()
    return instance


@contextlib.contextmanager
def project_lock(project: PipelineProject, *, blocking: bool = False):
    """Use the same stable coordination lock for CLI, MCP, maintenance and workers."""
    from microbiome.pipeline.locking import project_operation_lock
    with project_operation_lock(project, blocking=blocking):
        yield


def maintain_project(project: str, operation: str, arguments: dict | None = None, *,
                     user_message: str, message_id: str, session_id: str = "portable-host",
                     host_events: list | None = None) -> dict:
    """Host-attested maintenance; no fabricated approvals or scientific dispatch.

    Portable hosts must forward the actual user request and stable identifiers.
    These fields are provenance, not independent authentication of a human.
    File ownership/phase/path rules are enforced regardless of host assertions.
    """
    from microbiome.pipeline.maintenance import execute_maintenance
    return execute_maintenance(project_at(project, read_only=True), operation, arguments or {},
        user_message=user_message, message_id=message_id, session_id=session_id, host_events=host_events)


def planning_recovery(project: str) -> dict:
    from microbiome.agent.recovery import planning_recovery_snapshot
    return planning_recovery_snapshot(project_at(project, read_only=True))


def runtime_capabilities(project: str | None = None) -> dict:
    from microbiome.integrations.capabilities import runtime_capabilities as inspect_runtime
    return inspect_runtime(project_at(project, read_only=True) if project is not None else None)


def database_service(project: str, operation: str, arguments: dict | None = None, *,
                     user_message: str, message_id: str, session_id: str = "portable-host") -> dict:
    from microbiome.pipeline.database_service import database_operation
    if not all(isinstance(value, str) and value.strip() for value in (user_message, message_id, session_id)):
        raise ConfigurationError("Actual user message and stable message/session identifiers are required")
    return database_operation(project_at(project, read_only=True), operation, arguments,
        user_message=user_message, message_id=message_id, session_id=session_id)


def _proposal_path(project: PipelineProject, topic: str) -> Path:
    if topic not in TOPICS[:4]:
        raise ConfigurationError("unsupported requirement topic")
    return project.state_dir / "portable" / "proposals" / f"{topic}.json"


def catalog_list() -> dict:
    from microbiome.workflows import WorkflowCatalog
    return {"authority": "CURATED_REFERENCE", "workflows": WorkflowCatalog().list()}


def catalog_show(workflow_id: str) -> dict:
    from microbiome.workflows import WorkflowCatalog
    return WorkflowCatalog().get(workflow_id)


def catalog_search(query: str, workflow_ids: list[str] | None = None, limit: int = 4) -> dict:
    from microbiome.workflows import WorkflowCatalog
    if type(limit) is not int or not 1 <= limit <= 20:
        raise ConfigurationError("limit must be an integer between 1 and 20")
    return WorkflowCatalog().selection_context(query, workflow_ids=workflow_ids, limit=limit)


def inspect_software(project: str, logical_tool: str, executable: str | None = None,
                     software_family: str | None = None, environment_name: str | None = None) -> dict:
    from microbiome.resource_skills.resolver import inspect_software_request
    instance = project_at(project, read_only=True)
    if not isinstance(logical_tool, str) or not logical_tool.strip():
        raise ConfigurationError("logical_tool must be a nonempty capability name")
    return inspect_software_request(logical_tool, executable=executable, software_family=software_family,
                                    environment_name=environment_name, project_root=instance.root)


def inspect_project(project: str) -> dict:
    from microbiome.integrations.delegation import load_authorization
    from microbiome.pipeline.requirements import RequirementManager
    from microbiome.pipeline.state import ProjectStateMachine
    instance = project_at(project, read_only=True)
    paths = {
        "input_manifest": instance.requirements_dir / "input_manifest.yaml",
        "plan": instance.plan_path,
        "dependency_report": instance.plans_dir / "dependency_gap_report.yaml",
        "validation": instance.validation_report_path,
        "pipeline_lock": instance.pipeline_lock_path,
        "toolchain_lock": instance.toolchain_lock_path,
        "database_lock": instance.database_lock_path,
        "production_approval": instance.pipeline_dir / "production_approval.yaml",
    }
    return {"project": str(instance.root), "paths": instance.load_config()["paths"],
            "capabilities": runtime_capabilities(project),
            "approval_mode": load_authorization(instance),
            "lifecycle": ProjectStateMachine(instance).load(),
            "requirements": RequirementManager(instance).load(),
            "artifacts": {name: {"path": str(path), "exists": path.is_file()} for name, path in paths.items()},
            "reports": [str(path) for path in sorted(instance.reports_dir.glob("*")) if path.is_file()]}


def confirmed_manifest(project: PipelineProject) -> dict:
    from microbiome.pipeline.requirements import RequirementManager
    requirements = RequirementManager(project).require_confirmed()
    manifest = read_yaml(project.requirements_dir / "input_manifest.yaml")
    fingerprint = object_fingerprint({k: v for k, v in manifest.items() if k != "manifest_fingerprint"})
    if manifest.get("manifest_fingerprint") != fingerprint or manifest.get("resolution_status") != "CONFIRMED":
        raise ConfigurationError("Input manifest is unconfirmed or changed; resolve and confirm inputs again")
    declared = requirements["input"].get("manifest_fingerprint")
    if declared and declared not in {fingerprint, object_fingerprint(manifest)}:
        raise ConfigurationError("Input manifest differs from confirmed requirements")
    if not manifest.get("samples"):
        raise ConfigurationError("Input manifest has no samples")
    from microbiome.pipeline.input_commit import verify_input_manifest
    commit_path = project.state_dir / "input_commit.json"
    commit = read_json(commit_path) if commit_path.is_file() else {}
    if commit and commit.get("status") != "COMMITTED":
        raise ConfigurationError("INPUT_COMMIT_INCOMPLETE: finish the reviewed input confirmation before planning or execution")
    if commit.get("manifest_fingerprint") == manifest.get("manifest_fingerprint"):
        verify_input_manifest(project, manifest, expected_files=commit["local_files"])
    if manifest.get("input_kind") == "completed_run_artifacts":
        from microbiome.pipeline.derived import verify_derived_manifest
        verify_derived_manifest(project, manifest)
    if manifest.get("input_kind") == "external_cohort_tables":
        from microbiome.pipeline.external_cohort import verify_external_manifest
        verify_external_manifest(project, manifest)
    return manifest


def resolve_input(project: str, declaration: str) -> dict:
    """Resolve once into a pending proposal; only operator confirmation persists it."""
    from microbiome.input_resolution import InputSourceResolver
    from microbiome.integrations.delegation import load_authorization
    instance = project_at(project)
    with project_lock(instance):
        load_authorization(instance)
        paths = instance.load_config()["paths"]
        resolver = InputSourceResolver(paths["raw_data"], instance.output_root,
            database_root=paths["database"], download_root=paths.get("download"),
            knowledge_root=paths.get("knowledge"), project_root=instance.root)
        result = resolver.resolve(declaration, allow_sra_download=False)
        if result.errors or not result.samples:
            raise ConfigurationError("; ".join(result.errors or ["No resolved input samples"]))
        manifest = resolver.to_input_manifest(result)
        if manifest.get("resolution_status") != "CONFIRMED":
            raise ConfigurationError("Input needs explicit remote acquisition or clarification; no download was started")
        manifest["manifest_fingerprint"] = object_fingerprint(manifest)
        value = {"source": manifest["overall_source"], "layout": manifest["layout"],
                 "manifest_fingerprint": manifest["manifest_fingerprint"], "sample_count": len(manifest["samples"])}
        from microbiome.pipeline.input_commit import input_file_snapshot
        write_json(_proposal_path(instance, "input"), {"value": value, "manifest": manifest,
                                                      "local_files": input_file_snapshot(manifest)})
        return decision_snapshot(project, "input")


def resolve_derived_input(project: str, parent_run_id: str, samples: list[dict],
                          cohort_artifacts: dict | None = None) -> dict:
    """Propose checkpoint-bound, complete biological sample inputs for review."""
    from microbiome.pipeline.derived import resolve_derived_manifest
    from microbiome.integrations.delegation import load_authorization
    instance = project_at(project)
    with project_lock(instance):
        load_authorization(instance)
        manifest = resolve_derived_manifest(instance, parent_run_id, samples, cohort_artifacts)
        value = {"source": manifest["overall_source"], "layout": manifest["layout"],
                 "manifest_fingerprint": manifest["manifest_fingerprint"],
                 "sample_count": len(manifest["samples"]), "pilot_mode": manifest["pilot_mode"],
                 "parent_run_id": parent_run_id}
        from microbiome.pipeline.input_commit import input_file_snapshot
        write_json(_proposal_path(instance, "input"), {"value": value, "manifest": manifest,
                                                      "local_files": input_file_snapshot(manifest)})
        return decision_snapshot(project, "input")


def resolve_external_cohort_input(project: str, local_roots: list[str], samples: list[dict],
                                  cohort_artifacts: dict, provenance: dict | None = None) -> dict:
    """Propose fingerprinted external cohort tables; no fake parent or approval."""
    from microbiome.pipeline.external_cohort import resolve_external_manifest
    from microbiome.integrations.delegation import load_authorization
    instance = project_at(project)
    with project_lock(instance):
        load_authorization(instance)
        manifest = resolve_external_manifest(instance, local_roots, samples, cohort_artifacts, provenance)
        value = {"source": manifest["overall_source"], "layout": manifest["layout"],
                 "manifest_fingerprint": manifest["manifest_fingerprint"],
                 "sample_count": len(manifest["samples"]), "pilot_mode": manifest["pilot_mode"]}
        from microbiome.pipeline.input_commit import input_file_snapshot
        write_json(_proposal_path(instance, "input"), {"value": value, "manifest": manifest,
                                                      "local_files": input_file_snapshot(manifest)})
        return decision_snapshot(project, "input")


def propose_requirement(project: str, topic: str, value: dict) -> dict:
    from microbiome.integrations.delegation import load_authorization
    if topic not in ("dataset", "target", "analysis_goal") or not isinstance(value, dict) or not value:
        raise ConfigurationError("Use a nonempty dataset/target/analysis_goal proposal; resolve input separately")
    instance = project_at(project)
    with project_lock(instance):
        load_authorization(instance)
        write_json(_proposal_path(instance, topic), {"value": value})
        return decision_snapshot(project, topic)


def validate_plan(plan: dict, project: str | None = None) -> dict:
    from microbiome.pipeline.models import validate_experiment_plan
    from microbiome.pipeline.workflow_references import bind_reference_decisions, workflow_ids
    from microbiome.workflows import WorkflowCatalog
    candidate = dict(plan)
    if project is not None:
        from microbiome.pipeline.database_service import expand_resource_references
        candidate = expand_resource_references(project_at(project, read_only=True), candidate)
    # A host-supplied path is not proof that the application persisted/read evidence.
    candidate.pop("workflow_reference_evidence", None)
    candidate.pop("planning_evidence", None)
    normalized = validate_experiment_plan(candidate)
    selection = WorkflowCatalog().selection_context(normalized["objective"], workflow_ids=workflow_ids(normalized))
    from microbiome.visualization.references import figure_references
    figures = figure_references(normalized["objective"], normalized)
    if figures:
        selection["visualization"] = figures
        selection["fingerprint"] = object_fingerprint({key: value for key, value in selection.items() if key != "fingerprint"})
    return validate_experiment_plan(bind_reference_decisions(normalized, selection, require_match=True))


def planning_context(project: str, query: str, workflow_ids: list[str] | None = None,
                     visualization_topics: list[str] | None = None) -> dict:
    from microbiome.pipeline.planning_context import PlanningContext
    instance = project_at(project)
    confirmed_manifest(instance)
    with project_lock(instance):
        context_service = PlanningContext(instance)
        requested = {}
        if workflow_ids is not None:
            requested["workflow_ids"] = workflow_ids
        if visualization_topics is not None:
            requested["visualization_topics"] = visualization_topics
        context = context_service.collect(plan=requested or None, query=query)
        receipt = context_service.persist(context)
        return {"context": context_service.workflow_for_model(context),
                "resource_context": context_service.for_model(context), "receipt": receipt}


def _verify_reference_delivery(instance: PipelineProject, original: dict, normalized: dict, manifest: dict):
    """Prove documents were supplied by planning.context; never claim to prove model thought."""
    from microbiome.pipeline.workflow_references import reference_summary
    references = normalized.get("workflow_references") or []
    if not references and not normalized.get("visualization_reference"):
        return
    receipt = original.get("workflow_reference_evidence")
    if not isinstance(receipt, dict) or not receipt.get("path") or not receipt.get("context_fingerprint"):
        raise ConfigurationError("Call planning.context before designing; include its receipt as workflow_reference_evidence")
    path = Path(receipt["path"]).expanduser().resolve()
    if not path.is_relative_to((instance.plans_dir / "planning_evidence").resolve()):
        raise ConfigurationError("Workflow evidence must be a planning.context receipt inside this project")
    context = read_json(path)
    fingerprint = object_fingerprint({k: v for k, v in context.items() if k != "context_fingerprint"})
    if context.get("context_fingerprint") != fingerprint or receipt["context_fingerprint"] != fingerprint:
        raise ConfigurationError("Workflow evidence changed; request planning.context again")
    delivered = reference_summary(context.get("workflow_references", {}))
    if sorted(delivered, key=lambda item: item["workflow_id"]) != sorted(references, key=lambda item: item["workflow_id"]):
        raise ConfigurationError("Selected references differ from the delivered documents; request planning.context again")
    from microbiome.visualization.references import reference_summary as figure_summary
    if figure_summary(context.get("workflow_references", {}).get("visualization")) != normalized.get("visualization_reference"):
        raise ConfigurationError("Figure references differ from delivered documents; request planning.context again")
    if (context.get("project_paths") != instance.load_config()["paths"] or
            context.get("input_contract", {}).get("manifest_fingerprint") != manifest["manifest_fingerprint"]):
        raise ConfigurationError("Workflow evidence refers to different project inputs; request planning.context again")


def save_plan(project: str, plan: dict) -> dict:
    from microbiome.pipeline.lifecycle import save_experiment_plan
    from microbiome.pipeline.planning_context import PlanningContext
    from microbiome.pipeline.workflow_references import bind_reference_decisions
    instance = project_at(project)
    with project_lock(instance):
        from microbiome.pipeline.requirements import RequirementManager
        requirements = RequirementManager(instance).require_confirmed()
        manifest = confirmed_manifest(instance)
        normalized = validate_plan(plan, project=project)
        _verify_reference_delivery(instance, plan, normalized, manifest)
        from microbiome.pipeline.study import validate_study
        from microbiome.pipeline.planning_inputs import validate_conversation_input_bindings
        from microbiome.pipeline.cohort import expand_cohort_plan
        comparative = requirements["dataset"].get("comparative_analysis", requirements["analysis_goal"].get("comparative_analysis", False))
        normalized = validate_study({"requirements": requirements, "plan": normalized,
                                     "comparative_analysis": comparative})["plan"]
        metadata = requirements["dataset"].get("sample_metadata", [])
        if metadata and (len(metadata) != len(manifest["samples"]) or
                         {row.get("sample_id") for row in metadata} != {row["sample_id"] for row in manifest["samples"]}):
            raise ConfigurationError("Sample metadata must match every confirmed manifest sample exactly once")
        from microbiome.pipeline.derived import validate_derived_plan
        validate_derived_plan(normalized, manifest)
        from microbiome.pipeline.external_cohort import validate_external_plan
        validate_external_plan(normalized, manifest)
        validate_conversation_input_bindings(normalized, manifest, instance)
        if normalized.get("cohort_members"):
            raise ConfigurationError("Submit an unexpanded cohort template; membership is derived from the confirmed manifest")
        normalized = expand_cohort_plan(normalized, manifest)
        context_service = PlanningContext(instance)
        context = context_service.collect(plan=normalized, query=normalized["objective"])
        receipt = context_service.persist(context)
        normalized = bind_reference_decisions(normalized, context["workflow_references"], receipt=receipt, require_match=True)
        normalized["planning_evidence"] = receipt
        return save_experiment_plan(instance, normalized)


def preview_dependencies(project: str, plan: dict | None = None) -> dict:
    from microbiome.pipeline.dependencies import DependencyResolver
    from microbiome.pipeline.lifecycle import load_plan
    instance = project_at(project)
    with project_lock(instance):
        candidate = validate_plan(plan, project=project) if plan is not None else load_plan(instance)
        return DependencyResolver(instance).review(preview_plan=candidate)


def review_dependencies(project: str) -> dict:
    from microbiome.pipeline.dependencies import DependencyResolver
    instance = project_at(project)
    with project_lock(instance):
        return DependencyResolver(instance).review()


def decision_snapshot(project: str, topic: str) -> dict:
    """Return exact review material; this operation cannot grant any approval."""
    from microbiome.pipeline.requirements import RequirementManager
    if topic not in TOPICS:
        raise ConfigurationError("Unknown decision topic")
    instance = project_at(project)
    requirements = RequirementManager(instance).load()
    if topic in TOPICS[:4]:
        artifact = read_json(_proposal_path(instance, topic))
    else:
        path = {"analysis_plan": instance.plan_path,
                "dependencies": instance.plans_dir / "dependency_gap_report.yaml",
                "production": instance.pipeline_lock_path}[topic]
        artifact = read_yaml(path)
    material = {"project": str(instance.root), "topic": topic,
                "requirements_fingerprint": requirements["requirements_fingerprint"], "artifact": artifact}
    if topic == "production":
        from microbiome.pipeline.approval import ProductionApprovalManager
        material["validation_summary"] = ProductionApprovalManager(instance).render_validation_summary()
    from microbiome.integrations.delegation import load_authorization
    authorization = load_authorization(instance)
    if authorization["mode"] == "host_delegated":
        material["authorization_fingerprint"] = authorization["authorization_fingerprint"]
    return {**material, "decision_fingerprint": object_fingerprint(material),
            "approval_channel": ("project-scoped host delegation or interactive local operator CLI"
                                 if authorization["mode"] == "host_delegated"
                                 else "interactive local operator CLI; host delegation is not enabled")}


def _apply_operator_decision(project: str, topic: str, action: str, expected: str) -> dict:
    """Internal CLI-only boundary. The caller must obtain an actual operator response."""
    from microbiome.pipeline.requirements import ConfirmationAction
    instance = project_at(project)
    with project_lock(instance):
        snapshot = decision_snapshot(project, topic)
        if snapshot["decision_fingerprint"] != expected:
            raise ConfigurationError("STALE_DECISION: review the changed artifact before deciding")
        return _apply_reviewed_decision(instance, snapshot, ConfirmationAction(action))


def _apply_reviewed_decision(instance: PipelineProject, snapshot: dict, decision,
                             *, decision_source: dict | None = None) -> dict:
    """Apply a reviewed snapshot while the caller holds the project lock."""
    from microbiome.pipeline.requirements import ConfirmationAction, RequirementManager
    from microbiome.pipeline.dependencies import confirm_plan, DependencyResolver
    topic = snapshot["topic"]
    if topic in TOPICS[:4]:
        proposal = snapshot["artifact"]
        if topic == "input" and decision is ConfirmationAction.CONFIRM:
            from microbiome.pipeline.input_commit import commit_input_manifest
            manifest = proposal["manifest"]
            return commit_input_manifest(instance, manifest, requirement_value=proposal["value"],
                decision_source=decision_source, expected_files=proposal.get("local_files"),
                revision_snapshot=manifest.get("input_kind") in {"completed_run_artifacts", "external_cohort_tables"})
        return RequirementManager(instance).decide(topic, proposal["value"], action=decision,
                                                   decision_source=decision_source)
    if topic == "analysis_plan":
        return confirm_plan(instance, decision, decision_source=decision_source)
    if topic == "dependencies":
        return DependencyResolver(instance).approve(decision, decision_source=decision_source)
    from microbiome.pipeline.approval import ProductionApprovalManager
    message = {"CONFIRM": "确认全量执行", "MODIFY": "修改方案", "CANCEL": "先等等"}[decision.value]
    return ProductionApprovalManager(instance).handle(message, decision_source=decision_source)


def execution_binding(project: PipelineProject) -> dict:
    """Fingerprint all execution contracts at submission and check them in the worker."""
    paths = [project.config_path, project.requirements_path, project.plan_path,
             project.requirements_dir / "input_manifest.yaml",
             project.plans_dir / "dependency_gap_report.yaml", project.pipeline_lock_path,
             project.toolchain_lock_path, project.database_lock_path,
             project.pipeline_dir / "production_approval.yaml"]
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None for path in paths}


def dispatch(operation: str, arguments: dict | None = None) -> dict:
    """Invoke only explicit public operations, with protocol-clean structured results."""
    from microbiome.integrations.jobs import cancel_job, start_job, job_status, recover_job
    from microbiome.integrations.sequence_stats import sequence_stats
    from microbiome.integrations.delegation import configure_authorization, inspect_authorization, record_decision
    from microbiome.visualization.service import reference, manifest, inspect, review
    operations = {
        "runtime.capabilities": runtime_capabilities, "database.operate": database_service,
        "visualization.reference": reference, "visualization.manifest": manifest,
        "visualization.inspect": inspect, "visualization.review": review,
        "catalog.list": catalog_list, "catalog.show": catalog_show, "catalog.search": catalog_search,
        "project.inspect": inspect_project, "software.inspect": inspect_software,
        "project.maintain": maintain_project, "project.recovery": planning_recovery,
        "input.resolve": resolve_input, "input.resolve_derived": resolve_derived_input,
        "input.resolve_external_cohort": resolve_external_cohort_input, "planning.context": planning_context,
        "requirements.propose": propose_requirement, "plan.validate": validate_plan, "plan.save": save_plan,
        "dependencies.preview": preview_dependencies, "dependencies.review": review_dependencies,
        "decision.inspect": decision_snapshot, "job.start": start_job, "job.status": job_status,
        "approval.configure": configure_authorization, "approval.inspect": inspect_authorization,
        "decision.record": record_decision,
        "job.cancel": cancel_job, "job.recover": recover_job,
        "sequence.stats": sequence_stats,
    }
    try:
        if operation not in operations or (arguments is not None and not isinstance(arguments, dict)):
            raise ConfigurationError("Unknown operation or invalid arguments")
        with _OUTPUT_LOCK, contextlib.redirect_stdout(sys.stderr):
            value = operations[operation](**(arguments or {}))
        return {"schema_version": SCHEMA_VERSION, "ok": True, "result": value}
    except Exception as error:
        from microbiome.pipeline.diagnostics import error_diagnostic
        return {"schema_version": SCHEMA_VERSION, "ok": False,
                "error": {"code": type(error).__name__, "message": str(error),
                          "diagnostic": error_diagnostic(error),
                          **({"details": error.details} if hasattr(error, "details") else {})}}
