# 用本地 Ollama（qwen3.6）自然语言驱动 Microbiome 微生物生信

> 已实测通过：Microbiome 的 `get_llm` 接入 Ollama 的 `qwen3.6:latest`，自然语言提问→模型回答正常。

## 前提（一次性）
```bash
# 1. Ollama 在跑（已确认 http://localhost:11434，模型 qwen3.6:latest）
ollama list

# 2. microbiome conda 环境里装好依赖（已装）
conda run -n microbiome pip install langchain-ollama "httpx[socks]"

# 3. 本机访问 localhost 不要走代理（重要，否则 SOCKS 报错）
export NO_PROXY=localhost,127.0.0.1
```

## 用法 A：直接拿 LLM 对话
```python
import os
os.environ["NO_PROXY"] = "localhost,127.0.0.1"
from microbiome.llm import get_llm

llm = get_llm(model="qwen3.6:latest", source="Ollama")
print(llm.invoke("用一句话回答：宏基因组拼接常用的一个软件是什么？").content)
# -> 宏基因组拼接常用的一个软件是MEGAHIT。
```
模型名含 "qwen" 时会自动识别为 Ollama，也可显式写 `source="Ollama"`。

## 用法 B：A1 agent 自主完成生信任务（自然语言 → 自动调用工具）
```python
import os
os.environ["NO_PROXY"] = "localhost,127.0.0.1"
from microbiome.agent import A1

agent = A1(path="./data", llm="qwen3.6:latest")   # 自动走 Ollama
agent.go("对 dna_R1.fq 和 dna_R2.fq 做宏基因组拼接、基因预测和分箱")
```
agent 会从已注册的工具表（含我们新增的 metagenomics/microbial_genomics/transcriptomics/virology/amplicon/phylogenetics/microbial_networks/microbial_databases）自动检索并调用工具。

## 用法 C：显式 OpenAI 兼容端点（等价替代）
```python
llm = get_llm(model="qwen3.6:latest", source="Custom",
              base_url="http://localhost:11434/v1", api_key="ollama")
```

## 用法 D（零代码，推荐非程序员）：microbiome-run 命令行
装好 microbiome（`pip install -e .`）后会有一个 `microbiome-run` 命令，不用写任何 Python：
```bash
# 一句话直接执行（自然语言 → 自动调用生信工具）
microbiome-run "对 dna_R1.fq 和 dna_R2.fq 做宏基因组拼接、基因预测和分箱"

# 不带参数 = 交互式对话循环，逐条输入任务，exit 退出
microbiome-run
```
可选参数：`-m 模型名`（默认 `MICROBIOME_OLLAMA_MODEL` 或 qwen3.6:latest）、`-d 数据目录`（默认 `MICROBIOME_DATA_DIR` 或 ./data）、`--base-url`（Ollama 地址）。等价地也可 `python -m microbiome.cli "任务"`。

## 常见问题
- **`SOCKS proxy ... socksio` 报错**：本机有代理环境变量。解决：`pip install "httpx[socks]"` 且 `export NO_PROXY=localhost,127.0.0.1`。
- **找不到 microbiome**：在项目根目录运行，或 `export PYTHONPATH=<项目路径>`。
- **模型慢**：qwen3.6 是 36B MoE，首次加载需预热；后续调用会快。