---
name: VADR viral genome annotation
short_description: End-to-end viral genome classification, validation and feature annotation with VADR, from assembled viral FASTA to an INSDC/NGDC-ready 5-column feature table.
license: Apache-2.0
commercial_use: true
---

# VADR Viral Genome Annotation

Microbiome 通过 `microbiome.tool.virology.annotate_virus_vadr` 暴露 VADR（Viral Annotation DefineR）
病毒基因组注释能力，并配套软件 Skill（`software/vadr`）。所有工具返回 markdown 研究日志并把
结果落盘。

## 环境

VADR 是**非 Conda 的源码安装**，位于用户指定的 `/home/ylifc/AI_models_works/qingliang`。
使用时通过 `vadr_env.sh` 激活（设置 `VADRINSTALLDIR`、`VADRMODELDIR`、`PERL5LIB` 等），
再调用 `perl v-annotate.pl`。无需 `conda run`。

```bash
source /home/ylifc/AI_models_works/qingliang/vadr_env.sh
perl /home/ylifc/AI_models_works/qingliang/vadr/v-annotate.pl -h   # 冒烟自检
```

依赖：Infernal 1.1.5（cmsearch/cmalign）、BLAST（blastn/makeblastdb，复用系统 2.12.0）、
FASTA、minimap2、Bio-Easel、本地 Perl 模块（Inline::C）。仅安装了 RSV 模型库，其他病毒家族
按需下载（见软件 Skill）。

## 流程

```
assembled viral genome FASTA（组装产物，来自 PVGA / SPAdes / 参考引导组装）
  └─ annotate_virus_vadr(sequence_fasta, model="rsv", out_dir, cpu=...)
       → 调用 v-annotate.pl（--mkey <model> --split --cpu <n> -r --xnocomp --nomisc）
       → out_dir/*.vadr.sqc   逐序列分类摘要（PASS/FAIL、最佳模型、分组、覆盖率）
       → out_dir/*.vadr.sqa   逐序列注释摘要（特征数、告警数）
       → out_dir/*.vadr.pass.tbl   5 列特征表（gene/CDS，可提交 INSDC/NGDC）
       → out_dir/*.vadr.alt.list   告警清单
  └─（提交前）convert_vadr_to_ngdc.py → NGDC_GenBase_submission/{fasta,tbl,gff3}
```

## 示例

```python
from microbiome.tool.virology import annotate_virus_vadr

log = annotate_virus_vadr(
    "RSV/BACDC_3_seq.fasta",
    model="rsv",
    out_dir="RSV/vadr_output",
    cpu=8,
)
print(log)
```

命令行等价：

```bash
source /home/ylifc/AI_models_works/qingliang/vadr_env.sh
perl /home/ylifc/AI_models_works/qingliang/vadr/v-annotate.pl \
  --mkey rsv --split --cpu 8 -r --xnocomp --nomisc \
  RSV/BACDC_3_seq.fasta RSV/vadr_output
```

## 备注

- `--mkey` 必须与 `$VADRMODELDIR` 中已安装的模型文件前缀一致（如 `rsv`）。
- RSV 注释建议 16GB 内存/核；`--split --cpu` 用于并行，`-r` 替换 N 区，`--xnocomp`/`--nomisc`
  为 rsv 模型默认推荐选项。
- 提交 NCBI/NGDC：病毒基因组走 NGDC 的 **GenBase**（非 GWH）；`.pass.tbl` 已是五列特征表，
  用 `convert_vadr_to_ngdc.py` 生成提交包。
- 分类结果受模型家族影响：样本与所选模型家族不符（如牛 RSV 用人类 RSV 模型）仍可能给出
  高置信度但错误的分类，需核对最佳模型与评分。
