---
name: Analysis experience and planning confirmation
short_description: How Microbiome records software errors/successes and task-level workflows, reuses them during planning, and gates execution behind plan display, confirmation, and a small-data pilot.
license: Apache-2.0
commercial_use: true
---

# 分析经验沉淀与规划确认（Analysis experience & planning confirmation）

Microbiome 把每次运行的经验沉淀到三层，并在后续规划时自动引用；执行前先展示分析路径、
经用户确认后只跑小数据试跑，通过后再全量。

## 三层经验沉淀

| 层 | 内容 | 位置 | 复用方式 |
| --- | --- | --- | --- |
| 软件级 | 每个软件的成功命令 / 失败命令与原因归类 / 网络检索结论 | `software_memory/<软件>.md` | 执行前注入 `memory_for_text` |
| 调用级 | 每次调用的命令、环境、数据库、exit_code、错误摘要 | `ResourceSkills/knowledge/tools/<软件>/`（invocations、known_errors） | `record_invocation` / `verified_fixes` |
| 任务级 | 整条分析路径（工作流）+ 嵌套子流程 + 成败小结 | `analysis_experience/experience.jsonl` + `index.md` | 规划时注入 `relevant_experience` / `query_analysis_experience` |

- 软件级由 `microbiome.software_memory` 维护（`record_failure` / `record_success` / `record_web_note`）。
- 调用级由 `microbiome.pipeline.knowledge.KnowledgeBase` 与 `ExecutionLedger` 维护。
- 任务级由 `microbiome.analysis_experience` 维护（`record_experience` / `relevant_experience`）。
- 开关：`MICROBIOME_SOFTWARE_MEMORY=0`、`MICROBIOME_ANALYSIS_EXPERIENCE=0`；目录可分别用
  `MICROBIOME_SOFTWARE_MEMORY_DIR`、`MICROBIOME_ANALYSIS_EXPERIENCE_DIR` 指定。

## 规划确认流

```
用户任务
  └─ 规划器（只读）：
       1. 先展示分析路径/流程（优先本地 READY 的软件与数据库）
       2. 注入相关历史经验（prior analysis experience）供参考
       3. 末尾请用户「确认执行」
  └─ 用户「确认执行」→ 资源准备 + 小数据试跑（环境/软件/数据库验证）
        ├─ 失败 → 记录失败经验 + 修正建议，用户改方案重试
        └─ 通过 → 冻结生产流程 + 记录成功经验 → 请用户「确认全量执行」
  └─ 用户「确认全量执行」→ 全量运行
```

关键约束（规划器系统提示词已强制）：本地 READY 优先；`selection_tier=default` 主路径优先；
只列与任务相关的资源；第一次确认只做资源准备和小试，第二次确认才全量。

## 显式查询接口

规划器在只读规划工具里可显式调用 `query_analysis_experience(task)` 查询历史经验：

```python
from microbiome.analysis_experience import query_analysis_experience

print(query_analysis_experience("对 RSV 样本做病毒注释"))
```

无匹配记录时返回 `"无相关的历史分析经验记录。"`，有记录时返回按相关度排序的中英双语摘要。
`relevant_experience(task)` 是同一能力的底层函数，供规划提示词自动注入使用。

## 验证

```bash
python -m microbiome.selfcheck   # 运行环境段会显示 conda/mamba 与 analysis experience 记录数
pytest -q tests/test_analysis_experience.py
```
