# Microbiome 微生物生信扩展 — 使用 / 数据库 / 打包迁移 指南

> 适用模块：metagenomics, microbial_genomics, transcriptomics, virology, amplicon, phylogenetics, microbial_networks, microbial_databases
> 统一 conda 环境名：`microbiome`（可用环境变量 `MICROBIOME_ENV` 改名）

---

## 一、两种使用方式

### 方式 A：Python 函数直接调用（最直接，推荐先用这个）
```python
from microbiome.tool.metagenomics import assemble_metagenome, predict_genes, bin_metagenome, assess_bins_quality
from microbiome.tool.microbial_genomics import assemble_isolate_genome, annotate_isolate_genome
from microbiome.tool.transcriptomics import assemble_transcriptome, transcript_abundance, annotate_transcriptome
from microbiome.tool.virology import assemble_virus_reference_guided, identify_viral_contigs, assess_virome_quality
from microbiome.tool.amplicon import amplicon_denoise_dada2, amplicon_taxonomy_blast, amplicon_diversity
from microbiome.tool.phylogenetics import align_sequences, build_phylogenetic_tree, molecular_clock_analysis
from microbiome.tool.microbial_networks import build_compound_metabolic_network, analyze_compound_network
from microbiome.tool.microbial_databases import download_database

# 例：宏基因组全流程
assemble_metagenome("dna_R1.fq", "dna_R2.fq", "asm")
predict_genes("asm/contigs.fasta", "genes")
bin_metagenome("asm/contigs.fasta", "dna_R1.fq", "dna_R2.fq", "bins", binner="metabat2")  # 或 maxbin2/concoct
assess_bins_quality("bins", "bins_quality")
```
每个函数返回 markdown 研究日志（含命令、结果、文件路径），并把结果文件写到你指定的目录。

### 方式 B：让 Microbiome agent 用自然语言驱动
```python
from microbiome.agent import A1
agent = A1(path="./data", llm="claude-sonnet-4-5")
agent.go("对 dna_R1.fq 和 dna_R2.fq 做宏基因组拼接、基因预测和分箱")
```
所有工具已注册进 agent 可检索的工具表（`read_module2api`），agent 会自动找到并调用。

---

## 二、如何下载数据库

### 用统一入口（推荐）
```python
from microbiome.tool.microbial_databases import download_database
download_database("swissprot", "db/")   # 直链下载（GTDB/CARD/dbCAN/eggNOG/Swiss-Prot）
download_database("genomad", "db/")     # 走 genomad download-database
download_database("checkv", "db/")      # 走 checkv download_database
download_database("kraken2", "db/")     # 给构建/预建索引提示
```

### 各数据库的手动命令（等价）
| 数据库 | 命令 |
|---|---|
| CheckM | `checkm data setRoot <dir>`（或设环境变量 `CHECKM_DATA_PATH`） |
| geNomad | `genomad download-database <dir>`，再 `export GENOMAD_DB=<dir>/genomad_db` |
| CheckV | `checkv download_database <dir>`，再 `export CHECKVDB=<dir>/checkv-db-v1.5` |
| Bakta | `bakta_db download --output <dir> --type light`，再 `export BAKTA_DB=<dir>/db-light` |
| Swiss-Prot (DIAMOND) | `diamond makedb --in uniprot_sprot.fasta.gz --db swissprot` |
| Kraken2 | `kraken2-build --standard --db <dir>`，或下预建索引 |
| GTDB | 下载 tarball 解压即可（下载器已内置 URL） |

下载是一次性的；下好后设对应环境变量，工具就能直接用。

---

## 三、能否打包到其他 workbuddy/机器安装？

**能，有两条路。**

### 路径 1：标准 conda 重建（目标机有 conda + 网络）
```bash
git clone <repo>                      # 或拷贝整个项目目录
cd Biomni_further_developed
bash microbiome_env/setup_microbiome.sh   # 自动 mamba/conda 建环境
```
最稳妥，跨机器最兼容。缺点：要联网下载包。

### 路径 2：conda-pack 便携包（目标机无网络/无 conda）
在本机打包，拷贝到目标机解压即用：
```bash
# 本机
bash microbiome_env/pack_microbiome.sh microbiome microbiome_portable
# 得到 microbiome_portable_env.tar.gz + unpack_and_run.sh

# 目标机（拷贝这两个文件过去后）
bash unpack_and_run.sh ./microbiome_env_unpacked
export PATH="$PWD/microbiome_env_unpacked/bin:$PATH"
export MICROBIOME_ENV=""     # 让工具直接用 PATH 上的可执行文件
```
然后把 Microbiome 项目源码也拷过去（git clone 或整体拷贝），用目标机的 Python（≥3.10，装好 microbiome 的 pip 依赖）`pip install -e .` 或把仓库加入 `PYTHONPATH` 即可。
注意：conda-pack 的 tarball 是**同平台同 libc** 的（都是 Linux x86_64 没问题）。

---

## 四、跨 workbuddy（多智能体）共享
工具都是**纯函数 + 落盘文件**，无全局状态，天然可被多个 workbuddy 并行调用：
- 每个 workbuddy 只要 `import microbiome.tool.<module>` 就能用；
- 共享同一个 `microbiome` conda 环境（或同一个 unpacked 目录）；
- 结果各自写到不同的 `out_dir`，互不干扰；
- agent 模式下，工具表对所有 workbuddy 可见（同一 `read_module2api`）。