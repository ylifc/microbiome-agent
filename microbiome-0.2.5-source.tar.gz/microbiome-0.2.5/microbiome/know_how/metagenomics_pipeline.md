---
name: Metagenomics analysis pipeline
short_description: End-to-end metagenome assembly, gene prediction, abundance (TPM/FPKM), binning and quality assessment using the microbiome metagenomics tools.
license: Apache-2.0
commercial_use: true
---

# Metagenomics Analysis Pipeline

> Legacy wrapper reference / 历史接口示例。本文描述早期 Python wrapper 的接口和默认环境，
> 不作为当前分析规划、安装或生产执行依据。新的方法说明见 `microbiome/workflows/assembly-mag/`
> 与 contig 分析参考目录；实际位置和版本以 Registry 为准，生产以冻结 lock 为准。
> 下文统一环境安装示例只能在明确批准的维护范围内评估，不能覆盖现有环境复用策略。

Microbiome 提供 `microbiome.tool.metagenomics` 模块，覆盖宏基因组核心流程。所有工具返回 markdown 研究日志并把关键结果落盘。

## 环境

首次使用先建统一环境（含 MEGAHIT/SPAdes/Prodigal/MetaBAT2/CheckM/Salmon/BWA 等）：

```bash
bash microbiome_env/setup_microbiome.sh        # 创建名为 microbiome 的 conda 环境
```

工具默认通过 `conda run -n microbiome` 调用 CLI；可用环境变量 `MICROBIOME_ENV` 改名，或在工具参数里传 `env=""` 强制使用 PATH 上已有的工具。CLI 缺失时工具会返回含安装命令的日志而不会报错。

## 流程与工具

```
reads(fastq)
  └─ assemble_metagenome(reads_1, reads_2, out_dir, assembler="megahit"|"metaspades")
       → contigs.fasta (含 N50)
  ├─ predict_genes(contigs, out_dir)
       → genes.fna / proteins.faa / genes.gff
  ├─ calculate_gene_abundance  (TPM/FPKM 纯函数 _tpm/_fpkm)
  ├─ bin_metagenome(contigs, reads_1, reads_2, out_dir, binner="metabat2")
       → bins/*.fa   (内部用 BWA+samtools+jgi_summarize 计算覆盖度)
  └─ assess_bins_quality(bins_dir, out_dir)
       → bins_quality.tsv  (CheckM lineage_wf；需 CHECKM_DATA_PATH 指向数据库)
```

## 示例

```python
from microbiome.tool.metagenomics import (
    assemble_metagenome, predict_genes, bin_metagenome, assess_bins_quality,
)

assemble_metagenome("sample_R1.fastq", "sample_R2.fastq", "asm", assembler="megahit")
predict_genes("asm/contigs.fasta", "genes")
bin_metagenome("asm/contigs.fasta", "sample_R1.fastq", "sample_R2.fastq", "bins")
assess_bins_quality("bins", "bins_quality")   # 需先 checkm data setRoot <db>
```

## 备注

- CheckM 需要单独下载标记基因数据库并 `checkm data setRoot <dir>`，或设置 `CHECKM_DATA_PATH`。
- 大型数据库（GTDB/Kraken2 等）的下载器在 `microbiome.tool.microbial_databases`（后续阶段）。
- 测试与最小示例见 `tests/test_metagenomics.py`、`tests/test_metagenomics_e2e.py`。
