---
name: Microbial workflow selection and minimum completeness
short_description: Decision matrix for selecting complete isolate, metagenome, amplicon, virome and microbial RNA workflows without overclaiming resource readiness.
license: Apache-2.0
commercial_use: true
---

# 微生物分析工作流选择与最低完整性

本文是规划检查表，不是软件已安装或数据库 READY 的证明。实际资源位置和版本来自 Registry/Skill，生产只使用冻结锁。

## 通用入口

所有流程先完成：逐样本输入解析 → FASTA/FASTQ 格式、配对、压缩完整性和重复样本检查 → 测序平台/文库/宿主背景/实验设计确认 → 只读资源盘点 → 小试与验收定义。不得因为本地文件缺失就推断 SRA；混合 manifest 只获取远程记录。

短读长默认用 fastp 产生过滤 reads 与 JSON/HTML；需要逐周期诊断时加 FastQC，多样本用 MultiQC 汇总。已知引物/接头序列且需要严格锚定去除时用 Cutadapt；需要 k-mer 宿主/污染去除、去重或 read 修复时用 BBMap/BBTools。长读长先用 NanoPlot，只有过滤规则有明确质量/长度依据时才用 Chopper。宿主去除必须记录参考版本、输入/保留/宿主 reads 数并保留未映射配对同步性。

## 单菌 WGS

- Illumina：fastp → SPAdes isolate → QUAST/read-back mapping → Bakta；按目标追加 MLST、AMRFinderPlus/RGI/ABRicate、MOB-suite、antiSMASH。需要物种界定/近缘关系时用 fastANI（或 Mash 先粗筛）计算 ANI；需要 16S/23S 时用 barrnap 提取。
- ONT/PacBio：NanoPlot → 可选 Chopper → Flye → minimap2 read-back → Racon；ONT 且 basecaller 模型明确时可选 Medaka → QUAST → Bakta。
- 同一样本的 Illumina + long reads：可选 Unicycler。不得把不同菌株或样本混合为“提高覆盖度”。
- 群体/暴发：一致参考下 Snippy/core SNP → Gubbins 去重组 → SNP-sites/SNP-dists → IQ-TREE；泛基因组用 Panaroo。参考适配、callable core、重组处理、样本元数据和树支持度是必须验收项。

## Shotgun 宏基因组

有两条互补但不应默认堆叠的路线：

1. Read-based：fastp/去宿主 → Kraken2 → Bracken（必须有匹配 read length 的分布文件）；需要 marker-based 方法时选 MetaPhlAn；需要 read-based 功能通路时选 HUMAnN；内存/体量受限且只需对已知参考集做基因组级相对丰度时选 Sylph。
2. Assembly/MAG：MEGAHIT（短读长）或 metaFlye（长读长）→ Prodigal → read-back coverage → MetaBAT2 默认分箱；只有有充分理由时增加 MaxBin2/CONCOCT/SemiBin2，并用 DAS Tool 精炼 → CheckM2 → GUNC → GTDB-Tk → dRep → Bakta/eggNOG-mapper。MAG/基因组覆盖度与相对丰度用 CoverM 精确计算（替代 jgi_summarize 的现代方案）。

必须报告未分类比例、宿主去除记账、组装统计、映射率、每个 MAG 的完整度/污染度/嵌合证据、分类和数据库版本。Kraken/Bracken/MetaPhlAn/HUMAnN 相对丰度不是绝对菌量。

## 功能注释

Bakta 提供结构与标准化细菌注释；eggNOG-mapper 提供广覆盖直系同源功能；DIAMOND+Swiss-Prot 提供较高可解释性的同源证据；HMMER+Pfam 提供结构域证据。大型基因目录去冗余/聚类用 MMseqs2（替代 CD-HIT）；从基因组/宏基因组提取 rRNA 用 barrnap 或 VSEARCH。按问题追加 AMR、毒力（VFDB）、整合子、质粒和 BGC 分支。保留 no-hit、比对覆盖度、身份度、数据库 release 和稳定 query ID，禁止把短片段同源直接写成确定功能。

## 质粒 / 移动遗传元件 / 水平基因转移

先明确问题层级：质粒鉴定（这是不是质粒）、质粒分型（什么复制子/Inc 型）、前噬菌体/基因组岛（染色体上被转移来的区域）、接合/分泌系统（HGT 机制）、同源重组（群体内 HGT 的量化）。

- 质粒鉴定：宏基因组/组装 contig 先用 geNomad（质粒/染色体/病毒三分类 + 移动基因），再用 PlasFlow / PlasClass 做无参考 ML 互证；短读长质粒组装可用 PlasmidSPAdes（spades 内的 `plasmidspades.py`）或 Recycler。
- 质粒分型：MOB-suite 给质粒簇与移动性（mobilizable/conjugative/non-mobilizable）；ABRicate + PlasmidFinder 数据库给复制子/Inc 型。
- 前噬菌体/基因组岛：PhiSpy / Phigaro（前噬菌体）、IslandPath-DIMOB（基因组岛，二核苷酸偏倚 + 移动基因）、VIBRANT（病毒/前噬菌体 + AMG 注释）。
- HGT 机制：MacSyFinder + CONJscan 模型检测接合/IV 型分泌系统；整合子用 IntegronFinder。
- 同源重组：群体内近缘基因组用 Gubbins 或 ClonalFrameML 估计重组事件与重组/突变比。
- 组合证据：`mobile_elements.detect_hgt` 用四核苷酸组成 z-score + geNomad 移动基因做组成学 HGT 初筛；多个独立方法一致才下结论，单一预测器的概率不等于已证实的转移事件。

## 扩增子

确认 16S/18S/ITS、引物、方向、平台和预期长度 → 引物去除（Cutadapt 锚定去除或 DADA2 自带）→ DADA2/QIIME2 ASV → 去嵌合（VSEARCH --uchime_ref 对 SILVA/UNITE）→ SILVA（16S/18S）或 UNITE（ITS）且 classifier 与扩增区域匹配 → 系统发育（适用时）→ alpha/beta 多样性 → 有重复和协变量设计时做差异丰度。需要 97% OTU 视角或大规模去冗余/聚类时用 VSEARCH。必须纳入阴性/阳性对照、污染评估、样本保留率和测序深度敏感性；固定稀释深度不可硬编码为所有项目的通用值。

## 病毒组/病毒基因组

去宿主/质控 → 参考引导共识（有合适近缘参考）或 de novo/meta-viral assembly → geNomad 病毒识别（含 RNA 病毒等更广病毒类群时叠加 VirSorter2）→ CheckV 完整性/污染 → DIAMOND/VADR 注释（VADR 模型家族必须匹配）→ 需要时变异、比对和系统发育。geNomad 与 VirSorter2 结果需互相核对，不要用单一预测器下结论。验收覆盖深度与广度、低频变异阈值、病毒评分、CheckV 分类、末端/环化证据和注释模型兼容性。

## 微生物转录组/宏转录组

先确定 reference-based 还是 de novo、是否去 rRNA/宿主（BBMap/BBTools 可做宿主去除与去重）、链特异性与生物学重复。reference-based 需要参考与 GFF 版本绑定，用 featureCounts（Subread）从 BAM 产生 gene-level count 后才进入 DESeq2/edgeR；Salmon TPM 适合丰度描述但不能直接替代有设计矩阵的差异表达统计。宏转录组还需和宏基因组物种/基因目录对应，避免把组成变化误解为表达调控。

## 最低冻结要求

冻结前必须有：确认的 input manifest、每步唯一软件绑定与版本、数据库运行入口/marker/fingerprint、参数和科学依据、完整 DAG、全部接口的小试证据、预期输出及机器可检查断言、资源估计和失败恢复边界。全量阶段不得新增上述任何内容。
