---
name: Isolate genome and transcriptome analysis
short_description: Single-isolate genome assembly/annotation and microbial transcriptome assembly/abundance/annotation.
license: Apache-2.0
commercial_use: true
---

# 单菌基因组 & 单菌转录组分析

模块：`microbiome.tool.microbial_genomics`、`microbiome.tool.transcriptomics`。工具返回 markdown 研究日志并落盘结果，默认在 conda env `microbiome` 中调 CLI（缺失时给安装提示）。

## 单菌基因组

```python
from microbiome.tool.microbial_genomics import assemble_isolate_genome, annotate_isolate_genome

# 拼接（SPAdes isolate 模式）→ contigs.fasta（含 N50/总长）
assemble_isolate_genome("iso_R1.fastq", "iso_R2.fastq", "asm")

# 注释（Bakta；需先下载数据库并设 BAKTA_DB）
annotate_isolate_genome("asm/contigs.fasta", "anno", genus="Escherichia", species="coli")
```

Bakta 数据库一次性配置：
```bash
bakta_db download --output ~/db/bakta --type light   # 或 full
export BAKTA_DB=~/db/bakta/db-light
```

## 单菌转录组

```python
from microbiome.tool.transcriptomics import assemble_transcriptome, transcript_abundance, annotate_transcriptome

# 拼接（rnaSPAdes）→ transcripts.fasta
assemble_transcriptome("rna_R1.fastq", "rna_R2.fastq", "txasm")

# 丰度（Salmon）→ quant/quant.sf（TPM, NumReads）
transcript_abundance("txasm/transcripts.fasta", "rna_R1.fastq", "rna_R2.fastq", "txquant")

# 注释（DIAMOND blastx 对 Swiss-Prot .dmnd）
annotate_transcriptome("txasm/transcripts.fasta", "~/db/swissprot.dmnd", "txanno")
```

DIAMOND 数据库（Swiss-Prot）一次性构建：
```bash
wget https://ftp.uniprot.org/pub/databases/uniprot/current_release/knowledgebase/complete/uniprot_sprot.fasta.gz
diamond makedb --in uniprot_sprot.fasta.gz --db swissprot
```

## 备注
- 测试见 `tests/test_isolate_transcriptome.py`（拼接/丰度实测通过，注释做缺库降级）。
- 完整流程：转录组丰度可接 `microbiome.tool.metagenomics._tpm/_fpkm` 做进一步归一化/比较。