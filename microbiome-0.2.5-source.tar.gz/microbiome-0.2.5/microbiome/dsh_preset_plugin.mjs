export { name, inject, apply } from './harness/plugin.mjs'
