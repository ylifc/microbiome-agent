"""Per-software execution memory: learn from failures, reuse proven commands.

每次软件执行失败时，把失败命令、错误摘要和原因归类写入该软件的专属档案；
修复成功或经网络检索确认正确用法后，把成功命令与检索结论也写入档案。
规划/执行新命令前读取档案，避免重复同样的错误。

档案位置：``MICROBIOME_SOFTWARE_MEMORY_DIR`` 环境变量指定；默认与 ``Database/``
同级的 ``software_memory/`` 目录；整体可用 ``MICROBIOME_SOFTWARE_MEMORY=0`` 关闭。
"""

from __future__ import annotations

import functools
import os
import re
from datetime import datetime
from pathlib import Path

_ENV_DIR = "MICROBIOME_SOFTWARE_MEMORY_DIR"
_ENV_DISABLE = "MICROBIOME_SOFTWARE_MEMORY"
_MAX_ENTRIES = 20

_SECTION_SUCCESS = "已验证的成功用法"
_SECTION_FAILURE = "失败记录（禁止原样重复）"
_SECTION_WEB = "网络检索笔记"

# ---------------------------------------------------------------------------
# 基础配置
# ---------------------------------------------------------------------------


def enabled() -> bool:
    """Whether the software memory system is active (default on)."""
    return os.environ.get(_ENV_DISABLE, "1").strip().lower() not in {"0", "false", "no", "off"}


def memory_root() -> Path:
    """Directory holding one markdown record per software."""
    override = os.environ.get(_ENV_DIR, "").strip()
    if override:
        return Path(override).expanduser()
    try:
        from microbiome.path_config import get_path_config

        return Path(get_path_config().software_memory_dir).expanduser().resolve()
    except Exception:
        return Path.home() / ".biomni" / "software_memory"


def _slug(name: str) -> str:
    slug = re.sub(r"[^a-z0-9-]+", "-", str(name).lower()).strip("-")
    return slug or "unknown"


def memory_path(software: str, root: Path | None = None) -> Path:
    return (root or memory_root()) / f"{_slug(software)}.md"


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M")


# ---------------------------------------------------------------------------
# 软件识别
# ---------------------------------------------------------------------------


def alias_map_from_registry(registry) -> dict[str, str]:
    """Build alias(lowercase) -> software skill_id from a ResourceSkillRegistry."""
    aliases: dict[str, str] = {}
    try:
        skills = registry.list_skills("software")
    except Exception:
        return aliases
    for skill in skills:
        names = {skill.skill_id, skill.name, str(skill.metadata.get("environment", "") or "")}
        for field in ("executables", "aliases"):
            value = skill.metadata.get(field) or []
            if isinstance(value, str):
                value = [value]
            names.update(str(v) for v in value)
        for name in names:
            name = name.strip().lower()
            if len(name) >= 2:
                aliases.setdefault(name, skill.skill_id)
    return aliases


@functools.lru_cache(maxsize=1)
def _default_alias_map() -> dict[str, str]:
    try:
        from microbiome.resource_skills.registry import ResourceSkillRegistry

        return alias_map_from_registry(ResourceSkillRegistry())
    except Exception:
        return {}


def detect_software(text: str, registry=None) -> list[str]:
    """Return skill_ids of software mentioned in text/code (longest alias first wins)."""
    if not text:
        return []
    aliases = alias_map_from_registry(registry) if registry is not None else _default_alias_map()
    lowered = text.lower()
    found: list[str] = []
    for alias in sorted(aliases, key=len, reverse=True):
        skill_id = aliases[alias]
        if skill_id in found:
            continue
        if re.search(r"[a-z0-9]", alias):
            if not re.search(rf"(?<![a-z0-9_.-]){re.escape(alias)}(?![a-z0-9_.-])", lowered):
                continue
        elif alias not in lowered:  # CJK 等无词边界的别名用子串匹配
            continue
        found.append(skill_id)
    return found


_SHELL_NOISE = {
    "bash", "sh", "zsh", "sudo", "env", "conda", "mamba", "pip", "python", "python3",
    "r", "rscript", "cd", "ls", "cat", "grep", "awk", "sed", "tar", "make", "chmod",
}


def extract_unknown_executable(observation: str) -> str | None:
    """从 'xxx: command not found' 中提取未登记的可执行名（用于临时建档）。"""
    for match in re.finditer(r"([A-Za-z0-9_.+-]{2,}):\s*command not found", observation or ""):
        name = match.group(1)
        if name.lower() not in _SHELL_NOISE and "/" not in name:
            return name
    return None


# ---------------------------------------------------------------------------
# 失败原因归类
# ---------------------------------------------------------------------------

_FAILURE_RULES: list[tuple[str, str, str]] = [
    (r"command not found", "可执行文件缺失", "按软件 skill 用 conda run -n <env> 调用，或用 conda/mamba install -n <env> 安装"),
    (r"unrecognized option|invalid option|unknown option|illegal option|unrecognized arguments", "命令行参数错误", "对照 --help 与官方文档修正参数名/取值"),
    (r"no such file or directory", "输入路径不存在", "先用 ls 核实真实路径再重试"),
    (r"permission denied", "权限不足", "检查文件权限/属主，必要时更换输出目录"),
    (r"\bkilled\b|out of memory|cannot allocate memory|bad_alloc", "内存不足", "降低线程数/批量大小，或换更大内存的节点"),
    (r"segmentation fault|core dumped", "段错误", "检查输入格式与软件版本兼容性"),
    (r"modulenotfounderror|importerror", "Python 依赖缺失", "在该软件的 conda 环境内安装缺失包"),
    (r"version `.*' not found|glibcxx|\.so\.\d+|lib.*\.so", "动态库/版本冲突", "重建环境或固定兼容版本"),
    (r"connection refused|connection reset|timed out|\btimeout\b|\b403\b|\b404\b|could not resolve", "网络/下载失败", "核对 URL 与代理设置后重试"),
    (r"usage:", "用法错误", "阅读 Usage 输出后修正调用方式"),
]


def classify_failure(observation: str) -> tuple[str, str]:
    """Heuristic (原因归类, 修复方向) for a failed observation."""
    lowered = (observation or "").lower()
    for pattern, category, hint in _FAILURE_RULES:
        if re.search(pattern, lowered):
            return category, hint
    return "未归类错误", "阅读完整错误输出定位根因"


def error_excerpt(observation: str, max_chars: int = 280) -> str:
    """Pick the most informative error lines from an observation."""
    lines = [ln.strip() for ln in (observation or "").splitlines() if ln.strip()]
    if not lines:
        return ""
    key = re.compile(r"error|fail|not found|denied|exception|fatal|usage|killed|cannot|unable", re.IGNORECASE)
    picked = [ln for ln in lines if key.search(ln)]
    chosen = picked[:3] if picked else lines[-2:]
    text = " | ".join(chosen)
    return text[:max_chars] + ("…" if len(text) > max_chars else "")


def suggest_query(software: str, observation: str) -> str:
    """Suggested web-search query for the correct usage after a failure."""
    category, _ = classify_failure(observation)
    excerpt = error_excerpt(observation, max_chars=80)
    detail = excerpt if excerpt and category == "未归类错误" else category
    return f"{software} {detail} 正确用法 解决"


# ---------------------------------------------------------------------------
# 档案读写
# ---------------------------------------------------------------------------


def _template(software: str) -> str:
    return (
        f"# {software} 使用记忆（自动维护）\n"
        "> 每次执行失败/成功后自动更新。规划与执行前必读：优先复用已验证命令，"
        "禁止原样重复失败记录中的命令。\n\n"
        f"## {_SECTION_SUCCESS}\n\n## {_SECTION_FAILURE}\n\n## {_SECTION_WEB}\n"
    )


def _sections(text: str) -> tuple[str, list[tuple[str, str]]]:
    parts = re.split(r"(?m)^## ", text)
    header = parts[0]
    sections = []
    for part in parts[1:]:
        title, _, body = part.partition("\n")
        sections.append((title.strip(), body))
    return header, sections


def _render(header: str, sections: list[tuple[str, str]]) -> str:
    out = header.rstrip() + "\n"
    for title, body in sections:
        out += f"\n## {title}\n{body.strip() + chr(10) if body.strip() else ''}"
    return out


def _split_entries(section_body: str) -> list[str]:
    entries: list[str] = []
    current: list[str] = []
    for line in section_body.splitlines():
        if line.startswith("- ["):
            if current:
                entries.append("\n".join(current))
            current = [line]
        elif current and line.strip():
            current.append(line)
    if current:
        entries.append("\n".join(current))
    return entries


def _normalize_command(command: str) -> str:
    return re.sub(r"\s+", " ", (command or "").strip())[:300]


def _trim_command(command: str, max_chars: int = 400) -> str:
    lines = [
        ln.rstrip()
        for ln in (command or "").strip().splitlines()
        if ln.strip() and not ln.strip().startswith("#!")
    ]
    text = "\n".join(lines[:8]).strip()
    return text[:max_chars] + ("…" if len(text) > max_chars else "")


def _one_line(command: str, max_chars: int = 200) -> str:
    return re.sub(r"\s+", " ", (command or "").strip())[:max_chars]


def _load(path: Path, software: str) -> str:
    if path.exists():
        try:
            return path.read_text(encoding="utf-8")
        except OSError:
            pass
    return _template(software)


def _save(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _add_entry(text: str, section_title: str, entry: str) -> str:
    header, sections = _sections(text)
    titles = [title for title, _ in sections]
    if section_title not in titles:
        sections.append((section_title, ""))
    new_sections = []
    for title, body in sections:
        if title == section_title:
            entries = _split_entries(body)
            entries.append(entry)
            body = "\n".join(entries[-_MAX_ENTRIES:]) + "\n"
        new_sections.append((title, body))
    return _render(header, new_sections)


def _bump_failure(text: str, command_norm: str) -> tuple[str, bool]:
    """同一失败命令再次出现时只累加次数并刷新日期，不重复建档。"""
    header, sections = _sections(text)
    for i, (title, body) in enumerate(sections):
        if title != _SECTION_FAILURE:
            continue
        entries = _split_entries(body)
        for j, entry in enumerate(entries):
            match = re.search(r"命令:\s*`(.*?)`", entry, re.DOTALL)
            if not match or _normalize_command(match.group(1)) != command_norm:
                continue
            entry = re.sub(r"^- \[[^\]]+\]", f"- [{_now()}]", entry, count=1)
            if "次数:" in entry:
                entry = re.sub(r"次数: (\d+)", lambda m: f"次数: {int(m.group(1)) + 1}", entry, count=1)
            else:
                entry += "\n  - 次数: 1"
            entries[j] = entry
            sections[i] = (title, "\n".join(entries) + "\n")
            return _render(header, sections), True
    return text, False


def _annotate_fix(text: str, fixed_command: str) -> str:
    """给最近一条尚未标注修复的失败记录补上成功命令。"""
    header, sections = _sections(text)
    for i, (title, body) in enumerate(sections):
        if title != _SECTION_FAILURE:
            continue
        entries = _split_entries(body)
        for j in range(len(entries) - 1, -1, -1):
            if "后续修复" in entries[j]:
                continue
            entries[j] += f"\n  - 后续修复: `{_one_line(fixed_command)}`"
            sections[i] = (title, "\n".join(entries) + "\n")
            return _render(header, sections)
    return text


def record_failure(software: str, command: str, observation: str, root: Path | None = None) -> Path | None:
    """记录一次失败：命令、错误摘要、原因归类；相同命令只累加次数。"""
    try:
        path = memory_path(software, root)
        text = _load(path, software)
        command_norm = _normalize_command(command)
        text, bumped = _bump_failure(text, command_norm)
        if not bumped:
            category, hint = classify_failure(observation)
            entry = (
                f"- [{_now()}] 命令: `{_trim_command(command)}`\n"
                f"  - 错误: {error_excerpt(observation)}\n"
                f"  - 原因: {category}（{hint}）\n"
                f"  - 次数: 1"
            )
            text = _add_entry(text, _SECTION_FAILURE, entry)
        _save(path, text)
        return path
    except OSError:
        return None


def record_success(software: str, command: str, note: str = "", root: Path | None = None) -> Path | None:
    """记录一次验证成功的命令，并给最近一条失败标注后续修复。"""
    try:
        path = memory_path(software, root)
        text = _load(path, software)
        command_norm = _normalize_command(command)
        _, sections = _sections(text)
        for title, body in sections:
            if title != _SECTION_SUCCESS:
                continue
            for entry in _split_entries(body):
                match = re.search(r"`(.*?)`", entry, re.DOTALL)
                if match and _normalize_command(match.group(1)) == command_norm:
                    return path  # 已记录过同一成功命令
        suffix = f" — {note}" if note else ""
        text = _add_entry(text, _SECTION_SUCCESS, f"- [{_now()}] `{_trim_command(command)}`{suffix}")
        text = _annotate_fix(text, command)
        _save(path, text)
        return path
    except OSError:
        return None


def record_web_note(software: str, query: str, summary: str, root: Path | None = None) -> Path | None:
    """持久化一次网络检索得到的正确用法结论（供 agent 在 REPL 中调用）。"""
    try:
        path = memory_path(software, root)
        text = _load(path, software)
        clean_summary = re.sub(r"\s+", " ", (summary or "").strip())[:400]
        entry = f'- [{_now()}] 查询: "{query}" → {clean_summary}'
        text = _add_entry(text, _SECTION_WEB, entry)
        _save(path, text)
        return path
    except OSError:
        return None


def has_failure_history(software: str, root: Path | None = None) -> bool:
    """该软件档案中是否已有失败记录。"""
    path = memory_path(software, root)
    if not path.exists():
        return False
    try:
        body_map = dict(_sections(path.read_text(encoding="utf-8"))[1])
        return bool(_split_entries(body_map.get(_SECTION_FAILURE, "")))
    except OSError:
        return False


# ---------------------------------------------------------------------------
# 读取摘要（注入提示词）
# ---------------------------------------------------------------------------


def memory_brief(software_ids: list[str], max_chars: int = 2400, root: Path | None = None) -> str:
    """Condensed per-software memory block for prompt injection ('' when no records)."""
    blocks: list[str] = []
    for software in software_ids:
        path = memory_path(software, root)
        if not path.exists():
            continue
        try:
            _, sections = _sections(path.read_text(encoding="utf-8"))
        except OSError:
            continue
        body_map = dict(sections)
        parts = [f"### {software} 的使用记忆"]
        successes = _split_entries(body_map.get(_SECTION_SUCCESS, ""))[-5:]
        failures = _split_entries(body_map.get(_SECTION_FAILURE, ""))[-8:]
        notes = _split_entries(body_map.get(_SECTION_WEB, ""))[-3:]
        if successes:
            parts.append("历史成功声明（LEGACY_UNVERIFIED；须查验完整日志和输出，不能直接作为正确调用复用）:\n" + "\n".join(successes))
        if failures:
            parts.append("历史失败（禁止原样重复）:\n" + "\n".join(failures))
        if notes:
            parts.append("网络检索结论:\n" + "\n".join(notes))
        if len(parts) > 1:
            blocks.append("\n".join(parts))
    text = "\n\n".join(blocks)
    return text[:max_chars] + ("\n…（档案已截断）" if len(text) > max_chars else "")


def memory_for_text(text: str, registry=None, max_chars: int = 2400, root: Path | None = None) -> str:
    """Detect software in text and return their combined memory brief."""
    return memory_brief(detect_software(text, registry=registry), max_chars=max_chars, root=root)
