"""
Microbiome Configuration Management

Simple configuration class for centralizing common settings.
Maintains full backward compatibility with existing code.
"""

import os
from dataclasses import dataclass


@dataclass
class MicrobiomeConfig:
    """Central configuration for Microbiome agent.

    All settings are optional and have sensible defaults.
    The active host owns model selection and authentication. Legacy model
    environment variables are read only with MICROBIOME_LEGACY_MODEL_CONFIG=1.
    Explicit constructor settings remain available for library compatibility.

    Usage:
        # Create config with defaults
        config = MicrobiomeConfig()

        # Override specific settings
        config = MicrobiomeConfig(timeout_seconds=1200)

        # Modify after creation
        config.path = "./custom_data"
    """

    # Data and execution settings
    path: str = "./data"
    timeout_seconds: int = 600

    # Model access comes from the host or an explicitly attached endpoint client.
    llm: str = "current-host-model"
    temperature: float = 0.7
    context_length: int = 32768
    max_tokens: int = 8192

    # Tool settings
    use_tool_retriever: bool = True

    # Data licensing settings
    commercial_mode: bool = False  # If True, excludes non-commercial datasets

    # Custom model settings (for custom LLM serving)
    base_url: str | None = None
    api_key: str | None = None  # Only for custom models, not provider API keys

    # LLM source (auto-detected if None)
    source: str | None = None

    # Third-party integrations
    protocols_io_access_token: str | None = None

    def __post_init__(self):
        """Load any environment variable overrides if they exist."""
        # Check for environment variable overrides (optional)
        # Support both old and new names for backwards compatibility
        if os.getenv("MICROBIOME_PATH") or os.getenv("MICROBIOME_DATA_PATH"):
            self.path = os.getenv("MICROBIOME_PATH") or os.getenv("MICROBIOME_DATA_PATH")
        if os.getenv("MICROBIOME_TIMEOUT_SECONDS"):
            self.timeout_seconds = int(os.getenv("MICROBIOME_TIMEOUT_SECONDS"))
        if os.getenv("MICROBIOME_USE_TOOL_RETRIEVER"):
            self.use_tool_retriever = os.getenv("MICROBIOME_USE_TOOL_RETRIEVER").lower() == "true"
        if os.getenv("MICROBIOME_COMMERCIAL_MODE"):
            self.commercial_mode = os.getenv("MICROBIOME_COMMERCIAL_MODE").lower() == "true"
        if os.getenv("MICROBIOME_TEMPERATURE"):
            self.temperature = float(os.getenv("MICROBIOME_TEMPERATURE"))
        if os.getenv("MICROBIOME_LLM_TRANSPORT") == "harness":
            self.llm, self.source = "current-harness-model", "harness"
            self.api_key, self.base_url = None, None
        elif os.getenv("MICROBIOME_LEGACY_MODEL_CONFIG") == "1":
            if os.getenv("MICROBIOME_LLM") or os.getenv("MICROBIOME_LLM_MODEL"):
                self.llm = os.getenv("MICROBIOME_LLM") or os.getenv("MICROBIOME_LLM_MODEL")
            if os.getenv("MICROBIOME_CUSTOM_BASE_URL"):
                self.base_url = os.getenv("MICROBIOME_CUSTOM_BASE_URL")
            if os.getenv("MICROBIOME_CUSTOM_API_KEY"):
                self.api_key = os.getenv("MICROBIOME_CUSTOM_API_KEY")
            if os.getenv("MICROBIOME_SOURCE"):
                self.source = os.getenv("MICROBIOME_SOURCE")

        # Protocols.io access token (prefer specific env vars)
        env_token = os.getenv("PROTOCOLS_IO_ACCESS_TOKEN") or os.getenv("MICROBIOME_PROTOCOLS_IO_ACCESS_TOKEN")
        if env_token:
            self.protocols_io_access_token = env_token

    def to_dict(self) -> dict:
        """Convert config to dictionary for easy access."""
        return {
            "path": self.path,
            "timeout_seconds": self.timeout_seconds,
            "llm": self.llm,
            "temperature": self.temperature,
            "context_length": self.context_length,
            "max_tokens": self.max_tokens,
            "use_tool_retriever": self.use_tool_retriever,
            "commercial_mode": self.commercial_mode,
            "base_url": self.base_url,
            "api_key": self.api_key,
            "source": self.source,
        }


# Global default config instance (optional, for convenience)
default_config = MicrobiomeConfig()
