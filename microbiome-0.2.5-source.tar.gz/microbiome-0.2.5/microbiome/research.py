"""Model-independent, read-only literature retrieval with explicit provenance.

Only bibliographic queries leave the process. Retrieved text is evidence, never
an instruction or executable resource contract. No sample upload is supported.
"""

from __future__ import annotations

from datetime import UTC, datetime
import hashlib
import json
import re
import threading
import time
import xml.etree.ElementTree as ET

import requests


def search_research(query: str, max_results: int = 5) -> str:
    """Search PubMed research methods; return JSON sources, identifiers and status."""
    return json.dumps(PubMedResearch().search(query, max_results=max_results), ensure_ascii=False)


class PubMedResearch:
    _lock = threading.Lock()
    _last_request = 0.0
    base = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/"

    def __init__(self, session=None, timeout: int = 15):
        self.session = session or requests.Session()
        self.timeout = timeout

    def _get(self, *args, **kwargs):
        # NCBI permits three unauthenticated requests per second per IP.
        with self._lock:
            delay = 0.35 - (time.monotonic() - type(self)._last_request)
            if delay > 0:
                time.sleep(delay)
            type(self)._last_request = time.monotonic()
        return self.session.get(*args, **kwargs)

    def search(self, query: str, *, max_results: int = 5) -> dict:
        if not isinstance(query, str) or not query.strip() or len(query) > 2000:
            raise ValueError("research query must contain 1–2000 characters")
        if not 1 <= max_results <= 20:
            raise ValueError("max_results must be between 1 and 20")
        if re.search(r"(?:^|\s)(?:/|~/|[A-Za-z]:\\)|\.(?:fastq|fq|fasta)(?:\.gz)?\b", query, re.I):
            raise ValueError("research queries must not contain local file paths or sequencing filenames")
        result = {
            "provider": "pubmed",
            "query": query.strip(),
            "accessed_at": datetime.now(UTC).isoformat(),
            "status": "unavailable",
            "sources": [],
        }
        try:
            response = self._get(
                self.base + "esearch.fcgi",
                params={
                    "db": "pubmed",
                    "term": query.strip(),
                    "retmax": max_results,
                    "retmode": "json",
                    "tool": "microbiome",
                },
                timeout=self.timeout,
            )
            response.raise_for_status()
            ids = response.json()["esearchresult"]["idlist"]
            if not ids:
                return {**result, "status": "no_results"}
            response = self._get(
                self.base + "efetch.fcgi",
                params={"db": "pubmed", "id": ",".join(ids), "retmode": "xml", "tool": "microbiome"},
                timeout=self.timeout,
            )
            response.raise_for_status()
            root = ET.fromstring(response.content)
            for article in root.findall(".//PubmedArticle"):
                pmid = article.findtext(".//PMID")
                if not pmid or not pmid.isdigit():
                    continue
                title_node = article.find(".//ArticleTitle")
                title = "".join(title_node.itertext()) if title_node is not None else ""
                abstract = "\n".join("".join(node.itertext()) for node in article.findall(".//AbstractText"))
                doi = next((node.text for node in article.findall(".//ArticleId") if node.get("IdType") == "doi"), None)
                result["sources"].append(
                    {
                        "kind": "research_article",
                        "source": f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/",
                        "pmid": pmid,
                        "doi": doi,
                        "title": title,
                        "abstract": abstract[:12000],
                        "accessed_at": result["accessed_at"],
                        "query": query.strip(),
                        "read_scope": "title_and_abstract",
                        "review_status": "retrieved",
                        "content_sha256": hashlib.sha256((title + "\n" + abstract).encode()).hexdigest(),
                        "supports_step": [],
                    }
                )
            result["status"] = "available" if result["sources"] else "no_results"
        except (requests.RequestException, ValueError, KeyError, ET.ParseError) as error:
            result["error"] = str(error)[:1000]
        return result
