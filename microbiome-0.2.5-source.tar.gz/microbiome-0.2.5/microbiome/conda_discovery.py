"""Locate a conda/mamba/micromamba executable regardless of the process PATH.

On machines with several conda installations (anaconda3, miniforge3, ...) and a
bare agent shell with no conda on PATH, ``shutil.which`` alone returns ``None``.
That used to make the environment catalog empty, so every shared-environment tool
was misdetected as ``missing_environment`` and reinstalled into a project-local
``.biomni/envs/<family>`` prefix — the root of the genomad/CheckV/PAML repair loop.

This module is deliberately dependency-free (stdlib only) so it can be imported
from both ``microbiome.pipeline`` and ``microbiome.resource_skills`` without a cycle.
"""

from __future__ import annotations

import os
import shutil
from pathlib import Path

_COMMON_CONDA_LOCATIONS = (
    "~/miniforge3/bin/mamba",
    "~/miniforge3/bin/conda",
    "~/miniforge3/bin/micromamba",
    "~/mambaforge/bin/mamba",
    "~/mambaforge/bin/conda",
    "~/anaconda3/bin/conda",
    "~/miniconda3/bin/conda",
    "~/miniconda/bin/conda",
    "/opt/conda/bin/conda",
    "/opt/miniconda3/bin/conda",
    "/opt/mambaforge/bin/mamba",
    "/usr/local/bin/conda",
    "/usr/local/bin/mamba",
)


def find_conda_manager() -> str | None:
    """Return an executable conda/mamba/micromamba path, or None.

    PATH is tried first, then a bounded list of common install roots, so install,
    resolve, preflight and validation all bind to the same real conda binary even
    when the agent shell has no conda on PATH.
    """
    for name in ("conda", "mamba", "micromamba"):
        path = shutil.which(name)
        if path:
            return str(path)
    for location in _COMMON_CONDA_LOCATIONS:
        path = Path(location).expanduser()
        if path.is_file() and os.access(path, os.X_OK):
            return str(path)
    return None
