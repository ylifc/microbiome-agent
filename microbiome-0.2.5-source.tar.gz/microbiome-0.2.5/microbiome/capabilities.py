"""Machine-readable microbial analysis capability and workflow catalog.

The catalog describes what the agent can *plan and orchestrate*.  It does not
claim that every listed executable or database is installed on the current
machine: live Registry status and the frozen lock remain authoritative.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class WorkflowCapability:
    """One supported microbial analysis family and its resource contract."""

    workflow_id: str
    title_zh: str
    title_en: str
    inputs: tuple[str, ...]
    core_software: tuple[str, ...]
    conditional_software: tuple[str, ...]
    databases: tuple[str, ...]
    outputs: tuple[str, ...]
    acceptance: tuple[str, ...]


WORKFLOW_CAPABILITIES: tuple[WorkflowCapability, ...] = (
    WorkflowCapability(
        workflow_id="short-read-isolate-wgs",
        title_zh="细菌/古菌单菌短读长 WGS",
        title_en="short-read bacterial/archaeal isolate WGS",
        inputs=("paired/single Illumina FASTQ",),
        core_software=("fastp", "spades", "quast", "bakta"),
        conditional_software=(
            "fastqc", "multiqc", "mlst", "amrfinderplus", "abricate", "mob-suite",
            "barrnap", "fastani", "mash",
        ),
        databases=("bakta", "amrfinderplus", "card", "reference-genomes"),
        outputs=("QC reports", "assembly", "annotation", "typing/AMR/mobile-element/ANI reports"),
        acceptance=("paired-read reconciliation", "assembly size/N50", "non-empty GFF/FAA", "database provenance"),
    ),
    WorkflowCapability(
        workflow_id="long-hybrid-isolate",
        title_zh="Nanopore/PacBio 长读长与混合单菌组装",
        title_en="Nanopore/PacBio long-read and hybrid isolate assembly",
        inputs=("ONT/PacBio FASTQ/FASTA", "optional Illumina pairs"),
        core_software=("nanoplot", "chopper", "flye", "minimap2", "racon", "quast", "bakta"),
        conditional_software=("medaka", "unicycler", "pilon"),
        databases=("bakta",),
        outputs=("polished assembly", "assembly graph", "read-back coverage", "annotation"),
        acceptance=("read N50/quality", "coverage continuity", "assembly graph", "polishing delta", "annotation integrity"),
    ),
    WorkflowCapability(
        workflow_id="comparative-outbreak-genomics",
        title_zh="菌株分型、变异、泛基因组与暴发传播分析",
        title_en="strain typing, variants, pangenome and outbreak genomics",
        inputs=("isolate reads or assemblies", "sample metadata", "validated reference"),
        core_software=("snippy", "bcftools", "snp-sites", "snp-dists", "panaroo", "gubbins", "iqtree2"),
        conditional_software=("mlst", "skani", "drep", "treetime", "beast2", "fastani", "mash"),
        databases=("reference-genomes",),
        outputs=("core SNP alignment", "recombination-filtered tree", "distance matrix", "pangenome", "typing/ANI table"),
        acceptance=("reference suitability", "callable-core fraction", "sample QC", "bootstrap/support", "metadata consistency"),
    ),
    WorkflowCapability(
        workflow_id="shotgun-taxonomy-function",
        title_zh="Shotgun 宏基因组物种组成与功能通路分析",
        title_en="shotgun metagenome taxonomic and functional profiling",
        inputs=("quality-controlled shotgun FASTQ", "optional host reference"),
        core_software=("fastp", "bowtie2", "kraken2", "bracken"),
        conditional_software=("metaphlan", "humann", "multiqc", "sylph", "bbmap", "motus", "kneaddata", "phyloseq", "vegan", "maaslin3"),
        databases=("kraken2", "metaphlan", "humann"),
        outputs=("taxonomic profiles", "classified/unclassified counts", "gene-family and pathway tables"),
        acceptance=("host-removal accounting", "classified fraction", "rank/read-length compatibility", "normalized table checks"),
    ),
    WorkflowCapability(
        workflow_id="assembly-mag",
        title_zh="宏基因组组装、基因目录、分箱与 MAG 重建",
        title_en="metagenome assembly, gene catalog, binning and MAG recovery",
        inputs=("short/long metagenomic reads",),
        core_software=("megahit", "prodigal", "metabat2", "samtools", "checkm2", "gtdbtk"),
        conditional_software=(
            "spades", "flye", "maxbin2", "concoct", "dastool", "semibin2", "gunc", "drep",
            "coverm", "barrnap", "mmseqs2",
        ),
        databases=("checkm2", "gtdbtk", "gunc"),
        outputs=("contigs", "genes/proteins", "coverage/abundance", "MAGs", "quality/taxonomy/dereplication tables"),
        acceptance=("assembly statistics", "read mapping", "bin completeness/contamination", "chimerism", "taxonomy"),
    ),
    WorkflowCapability(
        workflow_id="microbial-functional-annotation",
        title_zh="微生物基因与蛋白功能注释",
        title_en="microbial gene and protein functional annotation",
        inputs=("contigs", "predicted proteins", "genes"),
        core_software=("prodigal", "bakta", "diamond", "hmmer", "eggnog-mapper"),
        conditional_software=("antismash", "rgi", "amrfinderplus", "integronfinder", "mmseqs2", "vsearch"),
        databases=("bakta", "swissprot", "cog", "pfam", "eggnog-mapper", "antismash", "card", "amrfinderplus"),
        outputs=("GFF/GenBank", "orthology/function tables", "domains", "BGC/AMR/integron reports"),
        acceptance=("feature-ID consistency", "coverage/identity thresholds", "database release", "no-hit retention"),
    ),
    WorkflowCapability(
        workflow_id="amplicon",
        title_zh="16S/18S/ITS 扩增子 ASV、分类与多样性",
        title_en="16S/18S/ITS amplicon ASVs, taxonomy and diversity",
        inputs=("demultiplexed FASTQ", "sample metadata", "primer sequences"),
        core_software=("dada2", "qiime2", "mafft", "fasttree"),
        conditional_software=("fastp", "multiqc", "ancombc2", "cutadapt", "vsearch", "phyloseq", "vegan", "decontam", "aldex2", "biom-format", "scikit-bio"),
        databases=("silva", "unite"),
        outputs=("ASV table", "representative sequences", "taxonomy", "phylogeny", "alpha/beta diversity"),
        acceptance=("primer removal", "merge/denoise retention", "chimera rate", "controls", "classifier-region compatibility"),
    ),
    WorkflowCapability(
        workflow_id="virome",
        title_zh="病毒组与病毒基因组分析",
        title_en="virome and viral genome analysis",
        inputs=("viral/metagenomic reads or contigs", "optional close reference"),
        core_software=("spades", "genomad", "checkv", "diamond"),
        conditional_software=("bcftools", "vadr", "pvga", "mafft", "iqtree2", "virsorter2", "vibrant"),
        databases=("genomad", "checkv", "virus-genomes", "reference-sequences"),
        outputs=("viral contigs/consensus", "quality/classification", "annotation", "variants", "phylogeny"),
        acceptance=("mapping depth/breadth", "viral score", "completeness/contamination", "model-family compatibility"),
    ),
    WorkflowCapability(
        workflow_id="mobile-amr",
        title_zh="耐药、毒力、质粒、整合子、水平基因转移与移动遗传元件",
        title_en="AMR, virulence, plasmids, integrons, HGT and mobile elements",
        inputs=("assemblies or proteins", "optional reads"),
        core_software=("amrfinderplus", "rgi", "abricate", "mob-suite", "integronfinder"),
        conditional_software=(
            "genomad", "diamond", "antismash", "plasflow", "plasclass", "phispy", "phigaro",
            "macsyfinder", "clonalframeml", "vibrant", "islandpath",
        ),
        databases=("amrfinderplus", "card", "mob-suite", "genomad", "antismash", "vfdb", "plasmidfinder"),
        outputs=(
            "AMR/virulence calls", "point mutations", "plasmid clusters and typing", "prophage/genomic-island calls",
            "conjugation/recombination (HGT) evidence",
        ),
        acceptance=("identity/coverage", "organism-specific mutation model", "contig context", "database provenance", "multi-method HGT corroboration"),
    ),
    WorkflowCapability(
        workflow_id="microbial-rna",
        title_zh="单菌转录组与宏转录组表达分析",
        title_en="microbial transcriptome and metatranscriptome expression",
        inputs=("RNA-seq FASTQ", "reference genome/GFF or de novo targets", "sample design"),
        core_software=("fastp", "bowtie2", "salmon"),
        conditional_software=("spades", "diamond", "deseq2", "edger", "multiqc", "subread", "bbmap"),
        databases=("swissprot", "eggnog-mapper"),
        outputs=("mapping/QC", "count or TPM tables", "differential expression", "functional summaries"),
        acceptance=("rRNA/host policy", "mapping rate", "replicate design", "normalization", "multiple-testing correction"),
    ),
)


def planning_capability_catalog() -> str:
    """Render compact planner context without asserting live readiness."""

    lines = [
        "The following is a planning catalog, not a readiness claim. Registry/Skill status and the frozen lock win:",
        "以下是规划能力目录，并不表示本机资源已就绪；Registry/Skill 状态与冻结锁是事实来源：",
    ]
    for workflow in WORKFLOW_CAPABILITIES:
        core = ", ".join(workflow.core_software)
        conditional = ", ".join(workflow.conditional_software) or "none"
        databases = ", ".join(workflow.databases) or "none"
        acceptance = "; ".join(workflow.acceptance)
        lines.append(
            f"- {workflow.workflow_id}: {workflow.title_zh} / {workflow.title_en}; "
            f"core={core}; conditional={conditional}; databases={databases}; acceptance={acceptance}"
        )
    return "\n".join(lines)


def _bullet(zh: str, en: str) -> str:
    """One bilingual bullet line for the greeting."""
    return f"  • {zh}\n    {en}"


def welcome_banner() -> str:
    """Return the concise bilingual CLI greeting derived from the catalog."""

    workflow_lines = "\n".join(
        _bullet(item.title_zh, item.title_en) for item in WORKFLOW_CAPABILITIES
    )
    return f"""
================================================================================
  Microbiome — 微生物生物信息分析、规划与可复现流水线 Agent
  Microbial bioinformatics planning and reproducible workflow agent
================================================================================

  我可以做什么 / What I can do — 微生物分析能力图谱
  能力总览 / At a glance：质控、拼接/组装、基因预测、分箱、注释、耐药/毒力、
  质粒/移动元件/HGT、系统发育/分子定年、扩增子、宏基因组/宏转录组、病毒组
    QC, assembly, gene prediction, binning, annotation, AMR/virulence,
    plasmid/mobile-element/HGT, phylogeny/dating, amplicon, metagenome/metatranscriptome, virome
{workflow_lines}

  我能规划并编排什么 / What I plan & orchestrate
  • 本地优先解析 FASTQ、FASTA、目录和样本清单；逐样本区分本地文件与明确的 SRA/ENA 远程编号
    Resolve local inputs first; classify each sample independently and gate explicit remote acquisition.
  • 只读盘点所有 Conda/PATH 软件与 READY 数据库，按 Registry/Skill/Knowledge 三层复用
    Reuse validated software & databases via Registry/Skill/Knowledge contracts.
  • 设计完整方案：输入、软件/数据库绑定、参数依据、资源估计、输出与机器可检查验收标准
    Design the plan: inputs, software/database bindings, parameter rationale, estimates, acceptance.
  • 每份方案可讨论、可修改；只有明确确认后才执行，绝不擅自下载或安装
    Every plan is discussable and revisable; nothing downloads or installs without confirmation.

  如何工作 / How it works
  ① 配置原始数据 / 下载 / 数据库 / 结果 / 软件记忆目录
     Configure raw-data, download, database, results and software-memory paths.
  ② 解析每个样本并只读盘点资源，就影响科学设计的关键信息提问
     Resolve samples, inventory resources read-only, ask the few questions that change design.
  ③ 给出可修改方案（含软件/数据库、参数依据、资源估计、验收标准）
     Present a revisable plan with bindings, rationale, estimates and acceptance criteria.
  ④ “确认执行” 只授权已批准的资源准备 + 确定性的 10% 端到端小试
     “确认执行” authorizes only approved prep plus a deterministic 10% end-to-end pilot.
  ⑤ 小试验收后冻结 manifest/DAG/参数/工具链/数据库锁；“确认全量执行”按锁确定性重放
     Freeze the lock after pilot validation; “确认全量执行” replays the full dataset deterministically.
  ⑥ 输出结果报告、失败诊断、审计记录与可复用 analysis_experience
     Emit reports, diagnostics, audit records and reusable analysis experience.

  快速开始 / Quick start
    microbiome-run   # 交互式讨论方案 / interactive plan discussion
    microbiome-run "对 dna_R1.fq dna_R2.fq 做宏基因组拼接、基因预测与分箱"
    microbiome-run "对 sample_list.txt 中的 shotgun 样本做物种组成与功能通路分析"
    microbiome-run "对本地 16S FASTQ 做引物感知 ASV、SILVA 分类与多样性分析"

  Configure → resolve & inventory → revise plan → 确认执行 (pilot) → validate
  & freeze → 确认全量执行 (deterministic production) → report & reuse
================================================================================
"""
