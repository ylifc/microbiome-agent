"""Helpers for dependencies that belong to optional Microbiome feature sets."""

from __future__ import annotations

import importlib
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from types import ModuleType


class LazyModule:
    """Load an optional module on first use and provide an actionable error."""

    def __init__(self, module_name: str, extra: str, distribution: str | None = None):
        self._module_name = module_name
        self._extra = extra
        self._distribution = distribution or module_name
        self._module: ModuleType | None = None

    def _load(self) -> ModuleType:
        if self._module is not None:
            return self._module
        try:
            self._module = importlib.import_module(self._module_name)
        except ModuleNotFoundError as exc:
            message = (
                f"Optional dependency '{self._distribution}' is required for this operation. "
                f"Install it with: pip install 'microbiome[{self._extra}]'"
            )
            raise ModuleNotFoundError(message, name=self._module_name) from exc
        return self._module

    def __getattr__(self, name: str):
        return getattr(self._load(), name)

    def __repr__(self) -> str:
        state = "loaded" if self._module is not None else "not loaded"
        return f"<LazyModule {self._module_name!r} ({state})>"


def lazy_module(module_name: str, *, extra: str, distribution: str | None = None) -> LazyModule:
    """Return a proxy that imports ``module_name`` only when it is used."""

    return LazyModule(module_name, extra, distribution)
