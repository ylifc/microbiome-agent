"""Database inventory & self-learning (know-how) tools for Microbiome.

- list_available_databases: scan the project Database/ root and report, for each
  database found, which tool-ready formats are present (e.g. DIAMOND .dmnd, extracted
  CheckM/CARD data, geNomad/CheckV dirs), so the agent can answer "which databases can
  I use, and with which software".
- add_knowhow_document: internalize newly learned bioinformatics software / workflows
  by writing a markdown note into microbiome/know_how/ (and reloading it), so the agent can
  retrieve and reuse that knowledge in future tasks.
"""

import os

from microbiome.tool.microbial_databases import DEFAULT_DB_ROOT

# Map: database dir name -> (human description, list of (format_marker, software) probes).
# A probe is (glob-or-filename, "software / use"). If the marker exists we report it ready.
_DB_FORMATS = {
    "swissprot": ("UniProt Swiss-Prot proteins", [("swissprot.dmnd", "DIAMOND (blastp/blastx)"), ("uniprot_sprot.fasta.gz", "raw FASTA (build dmnd/BLAST)")]),
    "cog": ("COG2020 (NCBI)", [("cog.dmnd", "DIAMOND"), ("cog-20.fa.gz", "raw FASTA"), ("cog-20.def.tab", "COG definitions")]),
    "card": ("CARD (resistance)", [("card.json", "RGI (`rgi load`)"), (".extracted_ok", "extracted CARD tarball")]),
    "checkm": ("CheckM reference data", [("checkm_data_2015_01_16", "CheckM (`checkm data setRoot` / CHECKM_DATA_PATH)")]),
    "genomad": ("geNomad database", [("genomad_db", "geNomad (GENOMAD_DB)")]),
    "checkv": ("CheckV database", [("checkv-db-v1.5", "CheckV (CHECKVDB)")]),
    "gtdbtk": ("GTDB-Tk reference data", [("gtdbtk_data", "GTDB-Tk (GTDBTK_DATA_PATH)")]),
    "tcdb": ("TCDB (transporters)", [("tcdb.dmnd", "DIAMOND"), ("tcdb.fasta", "raw FASTA")]),
    "bakta": ("Bakta database", [("db-light", "Bakta (BAKTA_DB)")]),
    "kraken2": ("Kraken2 database", [("hash.k2d", "Kraken2")]),
    "kegg": ("KEGG (license)", [("kegg.dmnd", "DIAMOND")]),
    "nr": ("NCBI nr protein database", [("nr.dmnd", "DIAMOND (blastp/blastx)"), ("nr.faa", "raw FASTA (build dmnd)")]),
    "qiime2": ("QIIME 2 classifier (Greengenes/SILVA)", [("classifier.qza", "QIIME 2 feature-classifier"), ("gg_classifier", "QIIME 2 classifier")]),
}


def _resolve_db_path(name, db_root=None):
    """Resolve the on-disk path for a database, auto-detecting common layouts.

    Returns the path to pass to the tool (e.g. GENOMAD_DB), or None if not found.
    Checks:
      1. <db_root>/<name>/ (direct)
      2. <db_root>/<name>/<name>_db/ (e.g. genomad -> genomad/genomad_db)
      3. <db_root>/<name>/<name>-db-v*/ (e.g. checkv -> checkv/checkv-db-v1.5)
      4. <db_root>/<name>/db/ (bakta -> bakta/db)
    """
    if db_root is None:
        db_root = DEFAULT_DB_ROOT
    name = name.lower()
    base = os.path.join(db_root, name)
    if not os.path.isdir(base):
        return None

    file_layouts = {
        "card": "card.json",
        "cog": "cog.dmnd",
        "kegg": "kegg.dmnd",
        "nr": "nr.dmnd",
        "swissprot": "swissprot.dmnd",
        "tcdb": "tcdb.dmnd",
        "kraken2": "hash.k2d",
    }
    marker = file_layouts.get(name)
    if marker:
        marker_path = os.path.join(base, marker)
        if os.path.isfile(marker_path) and os.path.getsize(marker_path) > 0:
            return marker_path if marker.endswith(".dmnd") else base

    if name == "checkm" and os.path.isfile(os.path.join(base, "hmms", "checkm.hmm")):
        return base

    direct_names = [f"{name}_db", f"{name}-db", "db", "db-light"]
    for direct_name in direct_names:
        direct = os.path.join(base, direct_name)
        if os.path.isdir(direct) and any(os.scandir(direct)):
            return direct

    # Versioned database layouts, including checkv-db-v1.5 and GTDB release232.
    # Prefer a clean versioned child (e.g. checkv-db-v1.5) over nested duplicate
    # directories such as checkv-db-v1.5-new / checkv-db-v1.5-old, which otherwise
    # win the reverse-sort and point CHECKVDB at the wrong nesting level.
    def _is_duplicate_suffix(entry_name: str) -> bool:
        lowered = entry_name.lower()
        return any(token in lowered for token in ("-new", "-old", "-copy", "-bak", "-backup", "_copy", "_old", "_new"))

    versioned = []
    for entry in os.listdir(base):
        full = os.path.join(base, entry)
        if not os.path.isdir(full):
            continue
        if not (
            entry.startswith(f"{name}-db")
            or entry.startswith(f"{name}_data")
            or (name == "gtdbtk" and entry.startswith("release"))
            or (name == "checkm" and entry.startswith("checkm_data"))
        ):
            continue
        if any(os.scandir(full)):
            versioned.append(entry)
    clean = [entry for entry in versioned if not _is_duplicate_suffix(entry)]
    for entry in sorted(clean or versioned, reverse=True):
        return os.path.join(base, entry)

    if name == "qiime2":
        classifiers = sorted(entry for entry in os.listdir(base) if entry.endswith(".qza"))
        if classifiers:
            return os.path.join(base, classifiers[0])

    # Generic indexed directories used by tools such as MMseqs2.
    for entry in os.listdir(base):
        full = os.path.join(base, entry)
        if not os.path.isdir(full):
            continue
        try:
            sub = os.listdir(full)
            if any(filename.endswith((".index", ".dbtype", ".lookup")) or filename == "version.txt" for filename in sub):
                return full
        except OSError:
            pass

    return None


def auto_configure_databases(db_root=None, env=None):
    """Scan the project Database/ root and set environment variables for every
    database that is present and ready. Called automatically at agent startup.

    Returns a dict of {database_name: resolved_path} for all databases found.
    """
    if db_root is None:
        db_root = DEFAULT_DB_ROOT
    resolved = {}
    if not os.path.isdir(db_root):
        return resolved

    env_vars = {
        "bakta": "BAKTA_DB",
        "card": "CARD_DB",
        "checkm": "CHECKM_DATA_PATH",
        "checkv": "CHECKVDB",
        "cog": "COG_DB",
        "genomad": "GENOMAD_DB",
        "gtdbtk": "GTDBTK_DATA_PATH",
        "kegg": "KEGG_DB",
        "kraken2": "KRAKEN2_DB",
        "nr": "NR_DB",
        "qiime2": "QIIME2_CLASSIFIER",
        "swissprot": "SWISSPROT_DMND",
        "tcdb": "TCDB_DB",
    }

    for name in os.listdir(db_root):
        path = os.path.join(db_root, name)
        if not os.path.isdir(path) or name not in env_vars:
            continue
        resolved_path = _resolve_db_path(name, db_root)
        if resolved_path:
            resolved[name] = resolved_path
            os.environ[env_vars[name]] = resolved_path
    return resolved

# QIIME 2 pre-trained classifier download (Greengenes2 / SILVA naive-bayes .qza).
_QIIME2_CLASSIFIER_URLS = {
    "gg2": "https://ftp.microbio.me/greengenes_release/2022.10/2022.10.backbone.full-length.nb.qza",
    "silva138": "https://data.qiime2.org/classifiers/sklearn-1.4.2/silva/silva-138-99-nb-classifier.qza",
}


def _has(db_dir, marker):
    # marker may be a file/dir name or a path fragment
    for _root, dirs, files in os.walk(db_dir):
        entries = set(dirs) | set(files)
        if marker in entries or any(marker in e for e in entries):
            return True
    return False


def list_available_databases(db_root=None):
    """List databases present under the project Database/ root and their tool-ready formats.

    Parameters
    ----------
    db_root : str, optional
        Root directory to scan (default DEFAULT_DB_ROOT = <project>/Database).

    Returns
    -------
    str
        Markdown table: database | path | ready formats (software) | status.
    """
    if db_root is None:
        db_root = DEFAULT_DB_ROOT
    lines = ["# Available Databases", f"- root: {os.path.abspath(db_root)}\n"]
    if not os.path.isdir(db_root):
        lines.append("(Database root not found. Use download_database(...) to populate it.)")
        return "\n".join(lines)

    lines.append("| database | description | ready for (software) | status |")
    lines.append("|---|---|---|---|")
    for name in sorted(os.listdir(db_root)):
        d = os.path.join(db_root, name)
        if not os.path.isdir(d) or name.startswith(".") or name == "nonexistent_db":
            continue
        desc, probes = _DB_FORMATS.get(name, ("(custom/unknown database)", []))
        ready = [sw for marker, sw in probes if _has(d, marker)]
        # any content at all?
        nonempty = any(os.scandir(d)) if os.path.isdir(d) else False
        status = "ready" if ready else ("downloaded (needs localization)" if nonempty else "empty")
        lines.append(f"| {name} | {desc} | {'; '.join(ready) if ready else '—'} | {status} |")
    return "\n".join(lines)


def add_knowhow_document(name, content, know_how_dir=None):
    """Internalize a newly learned bioinformatics tool/workflow as a know-how document.

    Writes a markdown note into the know-how directory so the agent can retrieve and
    reuse this knowledge in future tasks (self-learning / capability internalization).

    Parameters
    ----------
    name : str
        Short document name (used as the filename, e.g. "qiime2_pipeline").
    content : str
        Markdown content describing the tool/workflow (usage, commands, parameters,
        troubleshooting).
    know_how_dir : str, optional
        Know-how directory (default <project>/microbiome/know_how).

    Returns
    -------
    str
        Confirmation with the written path.
    """
    if know_how_dir is None:
        know_how_dir = os.path.join(os.path.dirname(__file__), "..", "know_how")
    os.makedirs(know_how_dir, exist_ok=True)
    fname = name if name.endswith(".md") else name + ".md"
    path = os.path.join(know_how_dir, fname)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(f"# {name}\n\n{content}\n")
    return f"Know-how document internalized: {os.path.abspath(path)}. The agent can retrieve it in future tasks."

def _qiime2_classifier_present(d):
    return os.path.isdir(d) and any(f.endswith(".qza") for f in os.listdir(d))


def ensure_database(name, db_root=None, env=None, auto_download=False, qiime2_classifier="silva138"):
    """Ensure a database is downloaded under Database/<name>/ and formatted for its software.

    Guard to call before a tool runs: checks the database subfolder under the project
    Database/ root; if missing/incomplete, downloads + localizes it (idempotent). Returns a
    status string describing the ready path/format, or a note when manual action is needed.

    Parameters
    ----------
    name : str
        Database name (e.g. swissprot, cog, card, checkm, genomad, checkv, gtdbtk, qiime2).
    db_root : str, optional
        Database root (default DEFAULT_DB_ROOT = <project>/Database).
    env : str, optional
        Conda env for tool-wrapped downloads / DIAMOND builds.
    auto_download : bool, optional
        If False (default), only report status. True is allowed only after the
        user confirms a plan containing the database's MICROBIOME_DB_ACQUISITION marker.
    qiime2_classifier : str, optional
        For name="qiime2": which pre-trained classifier to fetch ("silva138" or "gg2").

    Returns
    -------
    str
        Status / path / next-step note.
    """
    from microbiome.tool.microbial_databases import download_database

    if db_root is None:
        db_root = DEFAULT_DB_ROOT
    name = name.lower()
    d = os.path.join(db_root, name)
    log = [f"# ensure_database: {name}", f"- dir: {os.path.abspath(d)}\n"]

    # QIIME2 classifier: direct .qza download into Database/qiime2 (auto).
    if name == "qiime2":
        if _qiime2_classifier_present(d):
            qza = [os.path.join(d, f) for f in os.listdir(d) if f.endswith(".qza")][0]
            log.append(f"- READY: QIIME 2 classifier present: {qza}")
            return "\n".join(log)
        if not auto_download:
            log.append(
                f"- MISSING: no .qza classifier. Place an approved classifier under {os.path.abspath(d)} "
                "and add a marked acquisition proposal during planning if automatic retrieval is supported."
            )
            return "\n".join(log)
        os.makedirs(d, exist_ok=True)
        url = _QIIME2_CLASSIFIER_URLS.get(qiime2_classifier, _QIIME2_CLASSIFIER_URLS["silva138"])
        dest = os.path.join(d, os.path.basename(url))
        log.append(f"$ GET {url}")
        from microbiome.download_utils import download_file

        try:
            download_file(url, dest, desc="QIIME2 分类器 / QIIME2 classifier", log=log.append)
        except RuntimeError as e:
            log.append(f"- ERROR: classifier download failed: {e}")
            return "\n".join(log)
        log.append(f"- READY: downloaded classifier -> {dest}")
        log.append(f"- Use with: amplicon_qiime2_pipeline(..., classifier='{dest}')")
        return "\n".join(log)

    # All other databases: check format probes, else download via download_database.
    desc, probes = _DB_FORMATS.get(name, (None, []))
    ready = [sw for marker, sw in probes if os.path.isdir(d) and _has(d, marker)]
    if ready:
        log.append(f"- READY: {name} formatted for: {'; '.join(ready)}")
        return "\n".join(log)

    if not auto_download:
        log.append(f"- MISSING/needs localization: {name} not ready under {os.path.abspath(d)}. Re-run with auto_download=True.")
        return "\n".join(log)

    log.append(f"- not ready -> downloading/localizing via download_database('{name}') ...")
    log.append(download_database(name, out_dir=db_root, env=env))
    # re-check
    ready = [sw for marker, sw in probes if os.path.isdir(d) and _has(d, marker)]
    log.append(f"- post-download status: {'READY (' + '; '.join(ready) + ')' if ready else 'downloaded; see log above for any manual localization step'}")
    return "\n".join(log)


def check_system_resources():
    """Check available system resources (CPU, GPU, memory) and current Microbiome settings.

    Returns a natural-language summary the agent can relay to the user, plus the
    current resource configuration. Use when the user asks 'how many CPUs/GPUs
    can I use?' or before starting a compute-heavy task.
    """
    import multiprocessing
    import shutil

    from microbiome.resource_config import get_config

    cfg = get_config()
    cpus = multiprocessing.cpu_count()
    gpus = 0
    try:
        import subprocess
        res = subprocess.run(
            ["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader"],
            capture_output=True, text=True, check=False, timeout=5,
        )
        if res.returncode == 0:
            gpus = len(res.stdout.strip().splitlines())
    except Exception:
        pass

    mem_gb = "unknown"
    try:
        with open("/proc/meminfo") as fh:
            for line in fh:
                if line.startswith("MemTotal"):
                    mem_gb = f"{int(line.split()[1]) / 1024**2:.0f} GB"
                    break
    except Exception:
        pass

    disk_free = "unknown"
    try:
        usage = shutil.disk_usage(".")
        disk_free = f"{usage.free / 1024**3:.0f} GB"
    except Exception:
        pass

    log = ["# System Resources"]
    log.append(f"- CPU cores: {cpus}")
    log.append(f"- GPUs: {gpus}")
    log.append(f"- Memory: {mem_gb}")
    log.append(f"- Disk free (cwd): {disk_free}")
    log.append("")
    log.append("## Current Microbiome Configuration")
    log.append(f"- Max threads per tool: {cfg.threads}")
    log.append(f"- GPUs configured: {cfg.gpu}")
    log.append(f"- Max parallel samples: {cfg.max_parallel_samples}")
    log.append("")
    log.append(
        f"当前服务器共有 {cpus} 个 CPU 核心、{gpus} 个 GPU、{mem_gb} 内存。"
        f"Microbiome 当前配置为每个工具最多使用 {cfg.threads} 个线程，"
        f"最多同时并行处理 {cfg.max_parallel_samples} 个样本。"
        f"如需调整，可通过 set_config(threads=N, max_parallel_samples=M) 修改。\n"
        f"This server has {cpus} CPU cores, {gpus} GPU(s), and {mem_gb} of memory. "
        f"Microbiome is configured to use at most {cfg.threads} threads per tool and process at most "
        f"{cfg.max_parallel_samples} samples in parallel. To adjust, use "
        f"set_config(threads=N, max_parallel_samples=M)."
    )
    return "\n".join(log)
