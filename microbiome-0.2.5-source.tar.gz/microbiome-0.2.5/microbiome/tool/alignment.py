"""Generic sequence-database registration & aligner tools for Microbiome.

Let the agent (via natural language) register a NEW database into the project
Database/ root and build/run the common aligners — DIAMOND, Bowtie2, BWA — and hook
QIIME 2 classifiers. Each tool returns a markdown research log and writes to disk.
Missing CLIs yield an install hint.
"""

import os
import shutil

from microbiome.resource_config import threads as _default_threads
from microbiome.tool.metagenomics import DEFAULT_ENV as _DEFAULT_ENV
from microbiome.tool.metagenomics import _cli, _find_cli, _install_hint, _run
from microbiome.tool.microbial_databases import DEFAULT_DB_ROOT

_EXTRA_CLI = {
    "diamond": ("diamond", "diamond"),
    "bowtie2": ("bowtie2", "bowtie2"),
    "bowtie2-build": ("bowtie2-build", "bowtie2"),
    "bwa": ("bwa", "bwa"),
    "qiime": ("qiime", "qiime2"),
}


def build_aligner_index(ref_fasta, aligner="diamond", out_prefix=None, env=None, protein=None):
    """Build an aligner index/db from a reference FASTA (idempotent).

    aligner: 'diamond' (protein .dmnd), 'bowtie2' (nucleotide .bt2), 'bwa' (nucleotide .amb/.sa).

    Parameters
    ----------
    ref_fasta : str
        Path to the reference FASTA (protein for diamond; nucleotide for bowtie2/bwa).
    aligner : str, optional
        'diamond' (default) | 'bowtie2' | 'bwa'.
    out_prefix : str, optional
        Output index prefix/path (default: ref_fasta with extension stripped, next to ref).
    env : str, optional
        Conda env name.
    protein : bool, optional
        For diamond only: True (default) = protein db; set False for nucleotide (rare).

    Returns
    -------
    str
        Research log with the index path.
    """
    if env is None:
        env = _DEFAULT_ENV
    aligner = aligner.lower()
    log = [f"# Build Aligner Index ({aligner})", f"- ref: {ref_fasta}\n"]
    if not os.path.exists(ref_fasta):
        log.append(f"## ERROR\nreference not found: {ref_fasta}")
        return "\n".join(log)
    if out_prefix is None:
        out_prefix = os.path.splitext(ref_fasta)[0]
        if out_prefix.endswith(".fa") or out_prefix.endswith(".fasta") or out_prefix.endswith(".faa"):
            out_prefix = os.path.splitext(out_prefix)[0]

    if aligner == "diamond":
        dmnd = out_prefix if out_prefix.endswith(".dmnd") else out_prefix + ".dmnd"
        if os.path.exists(dmnd):
            log.append(f"## SKIP\nDIAMOND db already present: {dmnd}")
            return "\n".join(log)
        if _find_cli("diamond", env) is None:
            log.append("## ERROR\n" + _install_hint("diamond"))
            return "\n".join(log)
        rc, out = _run(_cli("diamond", env) + ["makedb", "--in", ref_fasta, "--db", dmnd], log)
        log.append("## Results")
        log.append(f"- DIAMOND db: {dmnd} ({'OK' if rc == 0 else 'FAILED'})")
        return "\n".join(log)

    if aligner == "bowtie2":
        if os.path.exists(out_prefix + ".1.bt2"):
            log.append(f"## SKIP\nBowtie2 index already present: {out_prefix}.*.bt2")
            return "\n".join(log)
        if _find_cli("bowtie2-build", env) is None:
            log.append("## ERROR\n" + _install_hint("bowtie2-build"))
            return "\n".join(log)
        rc, out = _run(_cli("bowtie2-build", env) + [ref_fasta, out_prefix], log)
        log.append("## Results")
        log.append(f"- Bowtie2 index: {out_prefix}.*.bt2 ({'OK' if rc == 0 else 'FAILED'})")
        return "\n".join(log)

    if aligner == "bwa":
        if os.path.exists(out_prefix + ".sa"):
            log.append(f"## SKIP\nBWA index already present: {out_prefix}.*")
            return "\n".join(log)
        if _find_cli("bwa", env) is None:
            log.append("## ERROR\n" + _install_hint("bwa"))
            return "\n".join(log)
        rc, out = _run(_cli("bwa", env) + ["index", "-p", out_prefix, ref_fasta], log)
        log.append("## Results")
        log.append(f"- BWA index: {out_prefix}.* ({'OK' if rc == 0 else 'FAILED'})")
        return "\n".join(log)

    log.append(f"## ERROR\nUnknown aligner '{aligner}'. Use diamond|bowtie2|bwa.")
    return "\n".join(log)


def register_custom_database(name, fasta, db_root=None, aligner="diamond", env=None, copy=True):
    """Register a NEW database into the project Database/ root and build its aligner index.

    Copies (or links) the FASTA into Database/<name>/ and builds the requested index so the
    agent can call it later by name. Use for natural-language requests like 'register my
    custom protein set as a database' or 'add this fasta as a DIAMOND database'.

    Parameters
    ----------
    name : str
        New database name (subfolder under Database/).
    fasta : str
        Path to the source FASTA (protein for diamond; nucleotide for bowtie2/bwa).
    db_root : str, optional
        Database root (default DEFAULT_DB_ROOT = <project>/Database).
    aligner : str, optional
        Index to build: 'diamond' (default) | 'bowtie2' | 'bwa' | 'none'.
    env : str, optional
        Conda env name.
    copy : bool, optional
        Copy (True, default) or symlink (False) the FASTA into Database/<name>/.

    Returns
    -------
    str
        Research log with the registered path + index path.
    """
    if db_root is None:
        db_root = DEFAULT_DB_ROOT
    name = name.lower()
    dest_dir = os.path.join(db_root, name)
    os.makedirs(dest_dir, exist_ok=True)
    log = [f"# Register Custom Database: {name}", f"- source: {fasta}", f"- dest: {os.path.abspath(dest_dir)}\n"]

    if not os.path.exists(fasta):
        log.append(f"## ERROR\nsource FASTA not found: {fasta}")
        return "\n".join(log)

    dest_fa = os.path.join(dest_dir, os.path.basename(fasta))
    if not os.path.exists(dest_fa):
        try:
            if copy:
                shutil.copy(fasta, dest_fa)
            else:
                os.symlink(os.path.abspath(fasta), dest_fa)
            log.append(f"- placed FASTA: {dest_fa}")
        except Exception as e:
            log.append(f"## ERROR\ncould not place FASTA: {e}")
            return "\n".join(log)
    else:
        log.append(f"- FASTA already present: {dest_fa}")

    if aligner.lower() != "none":
        log.append(build_aligner_index(dest_fa, aligner=aligner, env=env))
    log.append("## Results")
    log.append(f"- Registered under: {os.path.abspath(dest_dir)}")
    log.append(f"- Now usable by name '{name}' (e.g. ensure_database('{name}') / pass its .dmnd to annotation tools).")
    return "\n".join(log)


def run_aligner(query, index, out_tsv, aligner="diamond", env=None, mode="blastp", reads_2=None, max_evalue=1e-5, threads=None):
    """Run an alignment: DIAMOND blastp/blastx, Bowtie2, or BWA mem.

    Parameters
    ----------
    query : str
        Query FASTA (protein/nucleotide for diamond) or reads FASTQ (bowtie2/bwa).
    index : str
        Aligner index/db path (diamond .dmnd; bowtie2 prefix; bwa prefix or ref fasta).
    out_tsv : str
        Output file (TSV for diamond; SAM for bowtie2/bwa).
    aligner : str, optional
        'diamond' (default) | 'bowtie2' | 'bwa'.
    env : str, optional
        Conda env name.
    mode : str, optional
        For diamond: 'blastp' (default) or 'blastx'.
    reads_2 : str, optional
        Reverse reads for paired-end bowtie2/bwa.
    max_evalue : float, optional
        DIAMOND E-value cutoff (default 1e-5).
    threads : int, optional
        Threads (default 4).

    Returns
    -------
    str
        Research log with the output path and hit/alignment count.
    """
    if env is None:
        env = _DEFAULT_ENV
    if threads is None:
        threads = _default_threads()
    aligner = aligner.lower()
    os.makedirs(os.path.dirname(os.path.abspath(out_tsv)), exist_ok=True)
    log = [f"# Run Aligner ({aligner})", f"- query: {query}", f"- index: {index}\n"]

    if aligner == "diamond":
        if _find_cli("diamond", env) is None:
            log.append("## ERROR\n" + _install_hint("diamond"))
            return "\n".join(log)
        if not os.path.exists(index):
            log.append(f"## ERROR\nDIAMOND db not found: {index}. Build it first (build_aligner_index).")
            return "\n".join(log)
        cmd = _cli("diamond", env) + [mode, "-q", query, "-d", index, "-o", out_tsv,
                                          "-f", "6", "--evalue", str(max_evalue), "--max-target-seqs", "1", "--threads", str(threads)]
        rc, out = _run(cmd, log)
        if rc != 0:
            log.append(f"## ERROR\ndiamond {mode} failed.\n\n```\n{out[-2000:]}\n```")
            return "\n".join(log)
        n = sum(1 for line in open(out_tsv) if line.strip()) if os.path.exists(out_tsv) else 0
        log.append("## Results")
        log.append(f"- Output: {out_tsv}")
        log.append(f"- Hits: {n}")
        return "\n".join(log)

    if aligner in ("bowtie2", "bwa"):
        tool = "bowtie2" if aligner == "bowtie2" else "bwa"
        if _find_cli(tool, env) is None:
            log.append("## ERROR\n" + _install_hint(tool))
            return "\n".join(log)
        import subprocess

        from microbiome.tool.metagenomics import _env_prefix
        if aligner == "bowtie2":
            if reads_2:
                full = " ".join(_cli("bowtie2", env) + ["-x", index, "-1", query, "-2", reads_2, "-S", out_tsv, "-p", str(threads)])
            else:
                full = " ".join(_cli("bowtie2", env) + ["-x", index, "-U", query, "-S", out_tsv, "-p", str(threads)])
        else:
            full = " ".join(_cli("bwa", env) + ["mem", index, query] + ([reads_2] if reads_2 else [])) + f" > {out_tsv}"
        res = subprocess.run(_env_prefix(env) + ["bash", "-c", full], capture_output=True, text=True, check=False)
        log.append(f"$ {full}")
        if res.returncode != 0 or not os.path.exists(out_tsv):
            log.append(f"## ERROR\n{aligner} failed.\n\n```\n{(res.stdout or '') + (res.stderr or '')[-2000:]}\n```")
            return "\n".join(log)
        log.append("## Results")
        log.append(f"- Output (SAM): {out_tsv}")
        return "\n".join(log)

    log.append(f"## ERROR\nUnknown aligner '{aligner}'. Use diamond|bowtie2|bwa.")
    return "\n".join(log)
