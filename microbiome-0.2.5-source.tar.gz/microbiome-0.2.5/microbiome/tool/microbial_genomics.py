"""Single-isolate microbial genomics tools for Microbiome.

Genome assembly (SPAdes isolate mode) and genome annotation (Bakta). Each tool
returns a markdown research log and writes results to disk. Heavy steps run in
the `microbiome` conda env; missing CLIs yield an install hint, not an exception.
"""

import os
import shutil

from microbiome.resource_config import threads as _default_threads
from microbiome.tool.metagenomics import DEFAULT_ENV as _DEFAULT_ENV
from microbiome.tool.metagenomics import (
    _count_fasta,
    _fasta_lengths,
    _find_cli,
    _install_hint,
    _n50,
    _run,
)


def assemble_isolate_genome(reads_1, reads_2=None, out_dir="isolate_assembly", env=None):
    """Assemble a single-isolate bacterial genome using SPAdes (isolate mode).

    Parameters
    ----------
    reads_1 : str
        Path to forward (or interleaved/single-end) reads in FASTQ format.
    reads_2 : str, optional
        Path to reverse reads for paired-end data.
    out_dir : str, optional
        Output directory for the assembly (default "isolate_assembly").
    env : str, optional
        Conda environment name (default MICROBIOME_ENV or "microbiome").

    Returns
    -------
    str
        Research log with contig count, N50 and total assembly size.
    """
    if env is None:
        env = _DEFAULT_ENV
    os.makedirs(out_dir, exist_ok=True)
    log = ["# Isolate Genome Assembly (SPAdes)", f"- reads_1: {reads_1}", f"- reads_2: {reads_2}\n"]

    cmd_prefix = _find_cli("spades.py", env)
    if cmd_prefix is None:
        log.append("## ERROR\n" + _install_hint("spades.py"))
        return "\n".join(log)

    run_dir = os.path.join(out_dir, "_spades_run")
    if os.path.exists(run_dir):
        log.append(
            f"## ERROR\nSPAdes run directory already exists: {run_dir}. "
            "Use a new output directory; existing results are never overwritten."
        )
        return "\n".join(log)
    # isolate mode: default spades (no --meta), with careful mismatch correction
    cmd = cmd_prefix + ["--isolate", "-1", reads_1]
    if reads_2:
        cmd += ["-2", reads_2]
    cmd += ["-o", run_dir]
    rc, out = _run(cmd, log)
    if rc != 0:
        log.append(f"## ERROR\nSPAdes failed (exit {rc}).\n\n```\n{out[-3000:]}\n```")
        return "\n".join(log)

    source_contigs = os.path.join(run_dir, "contigs.fasta")
    contigs = os.path.join(out_dir, "contigs.fasta")
    if not os.path.exists(source_contigs):
        log.append("## ERROR\nNo contigs.fasta produced.")
        return "\n".join(log)
    shutil.copyfile(source_contigs, contigs)

    lengths = _fasta_lengths(contigs)
    n = _count_fasta(contigs)
    log.append("## Results")
    log.append(f"- Contigs file: {contigs}")
    log.append(f"- Number of contigs: {n}")
    log.append(f"- N50: {_n50(lengths)} bp")
    log.append(f"- Total assembly size: {sum(lengths)} bp")
    return "\n".join(log)


def annotate_isolate_genome(contigs, out_dir="isolate_annotation", genus="", species="", env=None):
    """Annotate an isolate genome using Bakta (genes, CDS, rRNA/tRNA, functions).

    Parameters
    ----------
    contigs : str
        Path to the assembled genome FASTA (e.g. from assemble_isolate_genome).
    out_dir : str, optional
        Output directory for annotation (default "isolate_annotation").
    genus : str, optional
        Genus name (optional, improves annotation).
    species : str, optional
        Species name (optional).
    env : str, optional
        Conda environment name (default MICROBIOME_ENV or "microbiome").

    Returns
    -------
    str
        Research log with feature counts and output file paths.
    """
    if env is None:
        env = _DEFAULT_ENV
    os.makedirs(out_dir, exist_ok=True)
    log = ["# Isolate Genome Annotation (Bakta)", f"- contigs: {contigs}\n"]

    cmd_prefix = _find_cli("bakta", env)
    if cmd_prefix is None:
        log.append("## ERROR\n" + _install_hint("bakta"))
        return "\n".join(log)

    # Bakta requires its database via BAKTA_DB or --db
    db = os.environ.get("BAKTA_DB", "")
    if not db:
        from microbiome.tool.db_inventory import _resolve_db_path
        db = _resolve_db_path("bakta") or ""
        if db:
            log.append(f"- auto-detected {'bakta'} database: {db}")
    cmd = cmd_prefix + [contigs, "--output", out_dir, "--force", "--threads", str(_default_threads())]
    if db:
        cmd += ["--db", db]
    else:
        log.append(
            "## NOTE\nBAKTA_DB not set. Bakta needs its database; download it with "
            "`bakta_db download --output <dir>` and set BAKTA_DB=<dir>. Attempting to run.\n"
        )
    if genus:
        cmd += ["--genus", genus]
    if species:
        cmd += ["--species", species]

    rc, out = _run(cmd, log)
    if rc != 0:
        log.append(
            f"## ERROR\nBakta failed (exit {rc}). If this is a database issue, see the NOTE above."
            f"\n\n```\n{out[-2500:]}\n```"
        )
        return "\n".join(log)

    # Bakta writes <prefix>.txt summary with feature counts
    log.append("## Results")
    log.append(f"- Annotation directory: {out_dir}")
    for fname in sorted(os.listdir(out_dir)):
        if fname.endswith((".gff3", ".gbff", ".faa", ".fna", ".txt", ".tsv")):
            log.append(f"  - {os.path.join(out_dir, fname)}")
    return "\n".join(log)
