"""Microbial phylogenetics tools for Microbiome.

Conserved-marker extraction, multiple sequence alignment (MAFFT), phylogenetic
tree building (IQ-TREE/FastTree), and molecular clock analysis (TreeTime).
Each tool returns a markdown research log and writes results to disk.
"""

import os
import re

from microbiome.resource_config import threads as _default_threads
from microbiome.tool.metagenomics import DEFAULT_ENV as _DEFAULT_ENV
from microbiome.tool.metagenomics import (
    _cli,
    _env_prefix,
    _find_cli,
    _install_hint,
    _run,
)

_EXTRA_CLI = {
    "mafft": ("mafft", "mafft"),
    "iqtree": ("iqtree", "iqtree"),
    "fasttree": ("fasttree", "fasttree"),
    "treetime": ("treetime", "treetime"),
    "prodigal": ("prodigal", "prodigal"),
    "muscle": ("muscle", "muscle"),
    # Bayesian / ML molecular dating
    "beast": ("beast", "beast2"),
    "mcmctree": ("mcmctree", "paml"),
    "baseml": ("baseml", "paml"),
    "codeml": ("codeml", "paml"),
}


def extract_marker_genes(sequences_fasta, marker_list=None, out_dir="marker_genes", env=None):
    """Extract conserved marker genes (e.g. 16S, rpoB, recA) from genomes by BLASTX/TBLASTN.

    For a quick marker-based workflow this predicts proteins with Prodigal then
    BLASTPs them against a small marker protein set. If `marker_list` (a protein
    FASTA of reference markers) is provided, each genome's best hits per marker are
    collected into per-marker FASTA files for downstream alignment.

    Parameters
    ----------
    sequences_fasta : str
        Path to a multi-genome/contig nucleotide FASTA.
    marker_list : str, optional
        Path to a protein FASTA of reference marker sequences. If None, returns a
        note asking for a marker reference set.
    out_dir : str, optional
        Output directory (default "marker_genes").
    env : str, optional
        Conda environment name.

    Returns
    -------
    str
        Research log with per-marker FASTA paths.
    """
    if env is None:
        env = _DEFAULT_ENV
    os.makedirs(out_dir, exist_ok=True)
    log = ["# Conserved Marker Gene Extraction", f"- genomes: {sequences_fasta}\n"]

    if marker_list is None:
        log.append(
            "## NOTE\nProvide `marker_list` = a protein FASTA of reference marker "
            "genes (e.g. rpoB/recA/gyrB/16S proteins) to extract orthologs. "
            "This tool will Prodigal-predict proteins then BLASTP them to the markers."
        )
        return "\n".join(log)

    for tool in ("prodigal",):
        if _find_cli(tool, env) is None:
            log.append("## ERROR\n" + _install_hint(tool))
            return "\n".join(log)
    if _find_cli("blastp", env) is None:
        log.append("## ERROR\n" + _install_hint("blastp"))
        return "\n".join(log)

    # 1) predict proteins
    faa = os.path.join(out_dir, "proteins.faa")
    rc, out = _run(_cli("prodigal", env) + ["-i", sequences_fasta, "-a", faa, "-p", "meta"], log)
    if rc != 0:
        log.append(f"## ERROR\nprodigal failed.\n\n```\n{out[-2000:]}\n```")
        return "\n".join(log)

    # 2) blastp to markers
    hits = os.path.join(out_dir, "marker_hits.tsv")
    rc, out = _run(
        _cli("blastp", env) + [
            "-query", faa, "-subject", marker_list, "-out", hits,
            "-outfmt", "6 qseqid sseqid pident evalue bitscore", "-max_target_seqs", "1", "-evalue", "1e-10",
        ],
        log,
    )
    if rc != 0:
        log.append(f"## ERROR\nblastp failed.\n\n```\n{out[-2000:]}\n```")
        return "\n".join(log)

    n = 0
    if os.path.exists(hits):
        with open(hits) as fh:
            n = sum(1 for line in fh if line.strip())
    log.append("## Results")
    log.append(f"- Predicted proteins: {faa}")
    log.append(f"- Marker hits: {hits} ({n} hits)")
    return "\n".join(log)


def align_sequences(sequences_fasta, out_dir="alignment", env=None, aligner="mafft"):
    """Multiple sequence alignment of homologous sequences using MAFFT (or MUSCLE).

    Parameters
    ----------
    sequences_fasta : str
        Path to nucleotide or protein FASTA of homologous sequences.
    out_dir : str, optional
        Output directory (default "alignment").
    env : str, optional
        Conda environment name.
    aligner : str, optional
        "mafft" (default) or "muscle".

    Returns
    -------
    str
        Research log with alignment path and sequence count.
    """
    if env is None:
        env = _DEFAULT_ENV
    os.makedirs(out_dir, exist_ok=True)
    log = ["# Multiple Sequence Alignment", f"- input: {sequences_fasta}", f"- aligner: {aligner}\n"]

    tool = "mafft" if aligner.lower() == "mafft" else "muscle"
    if _find_cli(tool, env) is None:
        log.append("## ERROR\n" + _install_hint(tool))
        return "\n".join(log)

    aln = os.path.join(out_dir, "alignment.fasta")
    if tool == "mafft":
        cmd = _env_prefix(env) + ["bash", "-c", f"mafft --auto {sequences_fasta} > {aln}"]
        import subprocess
        res = subprocess.run(cmd, capture_output=True, text=True, check=False)
        rc, out = res.returncode, (res.stdout or "") + (res.stderr or "")
        log.append(f"$ mafft --auto {sequences_fasta} > {aln}")
    else:
        rc, out = _run(_cli("muscle", env) + ["-align", sequences_fasta, "-output", aln], log)
    if rc != 0 or not os.path.exists(aln):
        log.append(f"## ERROR\nalignment failed.\n\n```\n{out[-2000:]}\n```")
        return "\n".join(log)

    from microbiome.tool.metagenomics import _count_fasta
    log.append("## Results")
    log.append(f"- Alignment: {aln}")
    log.append(f"- Aligned sequences: {_count_fasta(aln)}")
    return "\n".join(log)


def build_phylogenetic_tree(alignment_fasta, out_dir="phylogeny", env=None, method="iqtree", model="GTR+G"):
    """Build a phylogenetic tree from a multiple sequence alignment.

    Parameters
    ----------
    alignment_fasta : str
        Path to the MSA FASTA (from align_sequences).
    out_dir : str, optional
        Output directory (default "phylogeny").
    env : str, optional
        Conda environment name.
    method : str, optional
        "iqtree" (default, ML) or "fasttree" (fast approximate ML).
    model : str, optional
        Substitution model for IQ-TREE (default "GTR+G"). Use "MFP" for auto model selection.

    Returns
    -------
    str
        Research log with Newick tree path.
    """
    if env is None:
        env = _DEFAULT_ENV
    os.makedirs(out_dir, exist_ok=True)
    log = ["# Phylogenetic Tree", f"- alignment: {alignment_fasta}", f"- method: {method}\n"]

    prefix = os.path.join(out_dir, "tree")
    if method.lower() == "iqtree":
        if _find_cli("iqtree", env) is None:
            log.append("## ERROR\n" + _install_hint("iqtree"))
            return "\n".join(log)
        rc, out = _run(
            _cli("iqtree", env) + ["-s", alignment_fasta, "-m", model, "-pre", prefix, "-nt", str(_default_threads()), "-redo"],
            log,
        )
        tree = prefix + ".treefile"
    else:  # fasttree
        if _find_cli("fasttree", env) is None:
            log.append("## ERROR\n" + _install_hint("fasttree"))
            return "\n".join(log)
        import subprocess
        tree = prefix + ".nwk"
        cmd = _env_prefix(env) + ["bash", "-c", f"FastTree -gtr -nt {alignment_fasta} > {tree}"]
        res = subprocess.run(cmd, capture_output=True, text=True, check=False)
        rc, out = res.returncode, (res.stdout or "") + (res.stderr or "")
        log.append(f"$ FastTree -gtr -nt {alignment_fasta} > {tree}")

    if rc != 0 or not os.path.exists(tree):
        log.append(f"## ERROR\ntree building failed.\n\n```\n{out[-2000:]}\n```")
        return "\n".join(log)

    log.append("## Results")
    log.append(f"- Newick tree: {tree}")
    return "\n".join(log)


def molecular_clock_analysis(alignment_fasta, tree_file=None, out_dir="molecular_clock", env=None, dates_tsv=None):
    """Root-to-tip regression / time-tree estimation using TreeTime.

    Parameters
    ----------
    alignment_fasta : str
        Path to the MSA FASTA.
    tree_file : str, optional
        Path to a Newick tree (e.g. from build_phylogenetic_tree). If None, TreeTime
        builds one internally.
    out_dir : str, optional
        Output directory (default "molecular_clock").
    env : str, optional
        Conda environment name.
    dates_tsv : str, optional
        Optional 2-column TSV of sequence_name -> sampling date (for time-scaled tree).

    Returns
    -------
    str
        Research log with molecular clock / root-to-tip results, or a note if TreeTime
        is unavailable.
    """
    if env is None:
        env = _DEFAULT_ENV
    os.makedirs(out_dir, exist_ok=True)
    log = ["# Molecular Clock (TreeTime)", f"- alignment: {alignment_fasta}\n"]

    if _find_cli("treetime", env) is None:
        log.append("## ERROR\n" + _install_hint("treetime"))
        return "\n".join(log)

    cmd = _cli("treetime", env) + ["--aln", alignment_fasta, "--outdir", out_dir]
    if tree_file:
        cmd += ["--tree", tree_file]
    if dates_tsv:
        cmd += ["--dates", dates_tsv]
    rc, out = _run(cmd, log)
    if rc != 0:
        log.append(f"## ERROR\nTreeTime failed (exit {rc}).\n\n```\n{out[-2500:]}\n```")
        return "\n".join(log)

    log.append("## Results")
    log.append(f"- Output directory: {out_dir}")
    for f in ("root_to_tip_regression.pdf", "rtt.csv", "dates.tsv", "timetree.nwk"):
        p = os.path.join(out_dir, f)
        if os.path.exists(p):
            log.append(f"  - {p}")
    return "\n".join(log)


def _read_fasta_headers(fasta_path):
    headers = []
    with open(fasta_path) as fh:
        for line in fh:
            if line.startswith(">"):
                headers.append(line[1:].split()[0])
    return headers


def _fasta_to_beauti_xml(alignment_fasta, chain_length, log_file, tree_file):
    """Build a minimal BEAST2 XML (GTR+Gamma, strict clock, Yule) for a nucleotide alignment."""
    import xml.sax.saxutils as su

    seqs = []
    name, buf = None, []
    with open(alignment_fasta) as fh:
        for line in fh:
            line = line.rstrip("\n")
            if line.startswith(">"):
                if name is not None:
                    seqs.append((name, "".join(buf)))
                name, buf = line[1:].split()[0], []
            elif line:
                buf.append(line.strip())
    if name is not None:
        seqs.append((name, "".join(buf)))

    aln_lines = "\n".join(
        f'        <sequence id="seq_{su.escape(t)}" spec="Sequence" taxon="{su.escape(t)}" totalcount="4" value="{s}"/>'
        for t, s in seqs
    )
    xml = f"""<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<beast beautitemplate="Standard" beautistatus="" namespace="beast.pkgmgmt:beast.base.core:beast.base.inference:beast.base.evolution.alignment:beast.base.evolution.tree.coalescent:beast.pkgmgmt:beast.base.core:beast.base.inference.util:beast.evolution.nuc:beast.base.evolution.operator:beast.base.inference.operator:beast.base.evolution.sitemodel:beast.base.evolution.substitutionmodel:beast.base.evolution.likelihood" required="" version="2.7">
    <data id="alignment" name="alignment">
{aln_lines}
    </data>
    <map name="Uniform">beast.math.distributions.Uniform</map>
    <map name="Exponential">beast.math.distributions.Exponential</map>
    <map name="LogNormal">beast.math.distributions.LogNormalDistributionModel</map>
    <map name="Normal">beast.math.distributions.Normal</map>
    <map name="Gamma">beast.math.distributions.Gamma</map>
    <map name="prior">beast.math.distributions.Prior</map>
    <map name="YuleModel">beast.base.evolution.speciation.YuleModel</map>
    <map name="StrictClockModel">beast.base.evolution.branchratemodel.StrictClockModel</map>
    <map name="RandomTree">beast.base.evolution.tree.RandomTree</map>
    <map name="ConstantPopulation">beast.base.evolution.tree.coalescent.ConstantPopulation</map>
    <map name="CompoundDistribution">beast.base.inference.CompoundDistribution</map>
    <map name="TreeLikelihood">beast.base.evolution.likelihood.TreeLikelihood</map>
    <map name="SiteModel">beast.base.evolution.sitemodel.SiteModel</map>
    <map name="GTR">beast.base.evolution.substitutionmodel.GTR</map>
    <map name="Frequencies">beast.base.evolution.substitutionmodel.Frequencies</map>
    <map name="Logger">beast.base.inference.Logger</map>
    <map name="ESS">beast.base.inference.util.ESS</map>
    <map name="TreeHeightLogger">beast.base.evolution.tree.TreeHeightLogger</map>
    <map name="TreeWithMetaDataLogger">beast.base.evolution.tree.TreeWithMetaDataLogger</map>
    <map name="OperatorSchedule">beast.base.inference.OperatorSchedule</map>
    <map name="MCMC">beast.base.inference.MCMC</map>
    <map name="TaxonSet">beast.base.evolution.alignment.TaxonSet</map>
    <run id="mcmc" spec="MCMC" chainLength="{chain_length}">
        <state id="state" storeEvery="5000">
            <tree id="Tree.t:alignment" spec="beast.base.evolution.tree.Tree" name="stateNode">
                <taxonset id="TaxonSet.alignment" spec="TaxonSet">
                    <alignment idref="alignment"/>
                </taxonset>
            </tree>
            <parameter id="kappa.s:alignment" lower="0.0" name="stateNode">2.0</parameter>
            <parameter id="mutationRate.s:alignment" name="stateNode">1.0</parameter>
            <parameter id="gammaShape.s:alignment" name="stateNode">1.0</parameter>
            <parameter id="freqParameter.s:alignment" dimension="4" lower="0.0" name="stateNode" upper="1.0">0.25</parameter>
            <parameter id="birthRate.t:alignment" name="stateNode">1.0</parameter>
        </state>
        <init id="RandomTree.t:alignment" spec="beast.base.evolution.tree.coalescent.RandomTree" estimate="false" initial="@Tree.t:alignment" taxa="@alignment">
            <populationModel id="ConstantPopulation0.t:alignment" spec="beast.base.evolution.tree.coalescent.ConstantPopulation">
                <parameter id="randomPopSize.t:alignment" name="popSize">0.1</parameter>
            </populationModel>
        </init>
        <distribution id="posterior" spec="beast.base.inference.CompoundDistribution">
            <distribution id="likelihood" spec="beast.base.inference.CompoundDistribution">
                <distribution id="treeLikelihood.alignment" spec="beast.base.evolution.likelihood.TreeLikelihood" data="@alignment" tree="@Tree.t:alignment">
                    <siteModel id="SiteModel.s:alignment" spec="beast.base.evolution.sitemodel.SiteModel">
                        <parameter id="mutationRate.s:alignment.site" estimate="false" name="mutationRate">1.0</parameter>
                        <parameter id="gammaShape.s:alignment.site" estimate="false" name="shape">1.0</parameter>
                        <parameter id="proportionInvariant.s:alignment" estimate="false" lower="0.0" name="proportionInvariant" upper="1.0">0.0</parameter>
                        <substModel id="gtr.s:alignment" spec="beast.base.evolution.substitutionmodel.GTR">
                            <parameter id="rateAC.s:alignment" lower="0.0" name="rateAC">1.0</parameter>
                            <parameter id="rateAG.s:alignment" lower="0.0" name="rateAG">1.0</parameter>
                            <parameter id="rateAT.s:alignment" lower="0.0" name="rateAT">1.0</parameter>
                            <parameter id="rateCG.s:alignment" lower="0.0" name="rateCG">1.0</parameter>
                            <parameter id="rateGT.s:alignment" lower="0.0" name="rateGT">1.0</parameter>
                            <frequencies id="estimatedFreqs.s:alignment" spec="beast.base.evolution.substitutionmodel.Frequencies" frequencies="@freqParameter.s:alignment"/>
                        </substModel>
                    </siteModel>
                    <branchRateModel id="StrictClock.c:alignment" spec="beast.base.evolution.branchratemodel.StrictClockModel">
                        <parameter id="clockRate.c:alignment" estimate="false" name="clock.rate">1.0</parameter>
                    </branchRateModel>
                </distribution>
            </distribution>
            <distribution id="prior" spec="beast.base.inference.CompoundDistribution">
                <distribution id="YuleModel.t:alignment" spec="beast.base.evolution.speciation.YuleModel" tree="@Tree.t:alignment">
                    <parameter id="birthRate.t:alignment.prior" name="birthDiffRate">1.0</parameter>
                </distribution>
            </distribution>
        </distribution>
        <operator id="kappaScaler.s:alignment" spec="ScaleOperator" parameter="@kappa.s:alignment" scaleFactor="0.5" weight="1.0"/>
        <operator id="freqExchanger.s:alignment" spec="DeltaExchangeOperator" delta="0.01" parameter="@freqParameter.s:alignment" weight="1.0"/>
        <operator id="gammaShapeScaler.s:alignment" spec="ScaleOperator" parameter="@gammaShape.s:alignment" scaleFactor="0.5" weight="1.0"/>
        <operator id="birthRateScaler.t:alignment" spec="ScaleOperator" parameter="@birthRate.t:alignment" scaleFactor="0.75" weight="3.0"/>
        <operator id="treeScaler.t:alignment" spec="ScaleOperator" scaleFactor="0.5" tree="@Tree.t:alignment" weight="3.0"/>
        <operator id="treeRootScaler.t:alignment" spec="ScaleOperator" rootOnly="true" scaleFactor="0.5" tree="@Tree.t:alignment" weight="3.0"/>
        <operator id="UniformOperator.t:alignment" spec="Uniform" tree="@Tree.t:alignment" weight="30.0"/>
        <operator id="SubtreeSlide.t:alignment" spec="SubtreeSlide" tree="@Tree.t:alignment" weight="15.0"/>
        <operator id="narrow.t:alignment" spec="Exchange" isNarrow="true" tree="@Tree.t:alignment" weight="15.0"/>
        <operator id="wide.t:alignment" spec="Exchange" isNarrow="false" tree="@Tree.t:alignment" weight="3.0"/>
        <operator id="WilsonBalding.t:alignment" spec="WilsonBalding" tree="@Tree.t:alignment" weight="3.0"/>
        <logger id="tracelog" spec="beast.base.inference.Logger" fileName="{log_file}" logEvery="1000" model="@posterior" sort="smart">
            <log idref="posterior"/>
            <log idref="likelihood"/>
            <log idref="prior"/>
            <log idref="treeLikelihood.alignment"/>
            <log id="TreeHeight.t:alignment" spec="beast.base.evolution.tree.TreeHeightLogger" tree="@Tree.t:alignment"/>
        </logger>
        <logger id="treelog" spec="Logger" fileName="{tree_file}" logEvery="1000" mode="tree">
            <log id="TreeWithMetaDataLogger.t:alignment" spec="beast.base.evolution.TreeWithMetaDataLogger" tree="@Tree.t:alignment"/>
        </logger>
        <logger id="screenlog" spec="Logger" logEvery="10000" model="@posterior">
            <log idref="posterior"/>
            <log id="ESS.c:alignment" spec="util.ESS" arg="@posterior"/>
            <log idref="likelihood"/>
            <log idref="prior"/>
        </logger>
    </run>
</beast>
"""
    return xml


def beast_molecular_dating(alignment_fasta, out_dir="beast_dating", env=None, chain_length=10000000):
    """Bayesian molecular dating using BEAST2 (strict clock, GTR+Gamma, Yule prior).

    Generates a BEAST2 XML config from the alignment, runs `beast`, and reports the
    MCMC log / posterior trees (divergence-time estimates). Bayesian MCMC is slow;
    for large alignments reduce chain_length or use molecular_clock_analysis (TreeTime).

    Parameters
    ----------
    alignment_fasta : str
        Path to the MSA FASTA (nucleotide, e.g. from align_sequences).
    out_dir : str, optional
        Output directory (default "beast_dating").
    env : str, optional
        Conda environment name.
    chain_length : int, optional
        MCMC chain length (default 10,000,000). Reduce for a quick exploratory run.

    Returns
    -------
    str
        Research log with the BEAST2 XML, .log and .trees paths (or an install hint).
    """
    if env is None:
        env = _DEFAULT_ENV
    os.makedirs(out_dir, exist_ok=True)
    log = ["# Bayesian Molecular Dating (BEAST2)", f"- alignment: {alignment_fasta}", f"- chainLength: {chain_length}\n"]

    if _find_cli("beast", env) is None:
        log.append("## ERROR\n" + _install_hint("beast"))
        return "\n".join(log)

    n = len(_read_fasta_headers(alignment_fasta))
    if n < 2:
        log.append(f"## ERROR\nNeed >=2 aligned sequences; found {n} in {alignment_fasta}")
        return "\n".join(log)

    # Use bare relative file names inside the XML: beast runs with cwd=out_dir, and absolute
    # paths would be re-prefixed by the working dir (causing FileNotFoundException).
    xml_path = os.path.join(out_dir, "beast.xml")
    with open(xml_path, "w") as fh:
        fh.write(_fasta_to_beauti_xml(alignment_fasta, chain_length, "beast.log", "beast.trees"))
    log.append(f"- BEAST2 XML written: {xml_path}")

    rc, out = _run(_cli("beast", env) + ["-working", "-seed", "1", xml_path], log, cwd=out_dir)
    if rc != 0:
        log.append(f"## ERROR\nbeast failed (exit {rc}).\n\n```\n{out[-2500:]}\n```")
        return "\n".join(log)

    log.append("## Results")
    for f in ("beast.log", "beast.trees", "beast.xml"):
        p = os.path.join(out_dir, f)
        if os.path.exists(p):
            log.append(f"- {p}")
    log.append(
        "- Next: summarize the posterior with `treeannotator` (MCC tree) and inspect "
        "ESS / divergence times with `tracer` on beast.log."
    )
    return "\n".join(log)


def _parse_mcmctree_divergence(out_txt):
    """Extract the Posterior divergence-time table lines from an mcmctree output."""
    lines = []
    capture = False
    with open(out_txt) as fh:
        for line in fh:
            if "Posterior mean" in line or "95% equal-tail CI" in line:
                capture = True
            if capture:
                lines.append(line.rstrip("\n"))
                if len(lines) > 40:
                    break
    return "\n".join(lines)


def paml_mcmctree_dating(alignment_fasta, tree_file, out_dir="mcmctree_dating", env=None, clock_model=2):
    """Approximate-likelihood molecular dating using PAML mcmctree.

    Writes an mcmctree control file (independent-rates clock by default), the PAML-format
    alignment and a labelled tree, runs `mcmctree`, and parses the divergence-time table.

    Parameters
    ----------
    alignment_fasta : str
        Path to the MSA FASTA (nucleotide).
    tree_file : str
        Path to a Newick tree (rooted, matching the alignment taxa).
    out_dir : str, optional
        Output directory (default "mcmctree_dating").
    env : str, optional
        Conda environment name.
    clock_model : int, optional
        mcmctree `clock` option: 1=global, 2=independent-rates (default), 3=correlated-rates.

    Returns
    -------
    str
        Research log with the control file, output and parsed divergence-time estimates.
    """
    if env is None:
        env = _DEFAULT_ENV
    os.makedirs(out_dir, exist_ok=True)
    log = ["# Molecular Dating (PAML mcmctree)", f"- alignment: {alignment_fasta}", f"- tree: {tree_file}\n"]

    if _find_cli("mcmctree", env) is None:
        log.append("## ERROR\n" + _install_hint("mcmctree"))
        return "\n".join(log)

    headers = _read_fasta_headers(alignment_fasta)
    if len(headers) < 2:
        log.append(f"## ERROR\nNeed >=2 aligned sequences; found {len(headers)} in {alignment_fasta}")
        return "\n".join(log)

    # Convert FASTA -> PAML (PHYLIP) sequential format.
    seqs = {}
    name = None
    with open(alignment_fasta) as fh:
        for line in fh:
            line = line.rstrip("\n")
            if line.startswith(">"):
                name = line[1:].split()[0]
                seqs[name] = []
            elif line and name is not None:
                seqs[name].append(line.strip())
    seqs = {k: "".join(v) for k, v in seqs.items()}
    aln_len = max((len(s) for s in seqs.values()), default=0)
    phy_path = os.path.join(out_dir, "alignment.phy")
    with open(phy_path, "w") as fh:
        fh.write(f" {len(seqs)} {aln_len}\n")
        for k, v in seqs.items():
            fh.write(f"{k}\n{v}\n")

    # Normalise the input tree into a single-line PAML "main tree" (n 1 header + one tree).
    # mcmctree's maintree wants topology (+ optional fossil/time labels like B(L,U)) but
    # NO branch lengths, so strip ":<number>" while keeping calibration parentheses.
    with open(tree_file) as fh:
        raw = fh.read()
    tree_str = " ".join(raw.split())  # collapse newlines/excess whitespace onto one line
    tree_str = re.sub(r":\s*[0-9]+(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?", "", tree_str)
    maintree_path = os.path.join(out_dir, "main_tree.nwk")
    with open(maintree_path, "w") as fh:
        fh.write(f"{len(seqs)} 1\n{tree_str}\n")
    tree_file = maintree_path

    def _write_ctl(path, usedata, outfile_name):
        with open(path, "w") as fh:
            fh.write(
                f"""seed = -1
seqfile = {os.path.abspath(phy_path)}
treefile = {os.path.abspath(tree_file)}
outfile = {os.path.abspath(os.path.join(out_dir, outfile_name))}

ndata = 1
seqtype = 0
usedata = {usedata}
clock = {clock_model}
model = 4
alpha = 0.5
ncatG = 5
cleandata = 0

BDparas = 1 1 0.1 C
kappa_gamma = 6 2
alpha_gamma = 1 1
rgene_gamma = 2 2
sigma2_gamma = 1 10

print = 1
burnin = 2000
sampfreq = 10
nsample = 20000
"""
            )

    # Two-pass approximate-likelihood dating:
    #  pass 1 (usedata=3): estimate branch lengths + Hessian -> writes in.BV
    #  pass 2 (usedata=2): MCMC on the approximated likelihood -> out.txt + FigTree.tre
    ctl_bv = os.path.join(out_dir, "mcmctree_bv.ctl")
    _write_ctl(ctl_bv, 3, "out_pass1.txt")
    rc, out = _run(_cli("mcmctree", env) + [ctl_bv], log, cwd=out_dir)
    # usedata=3 writes the branch-length/Hessian matrix to "out.BV"; usedata=2 reads "in.BV".
    out_bv = os.path.join(out_dir, "out.BV")
    if rc != 0 or not os.path.exists(out_bv):
        log.append(f"## ERROR\nmcmctree pass1 (usedata=3, Hessian) failed (exit {rc}).\n\n```\n{out[-2000:]}\n```")
        return "\n".join(log)
    os.replace(out_bv, os.path.join(out_dir, "in.BV"))
    log.append("- Hessian matrix (in.BV) estimated via usedata=3")

    ctl_path = os.path.join(out_dir, "mcmctree.ctl")
    _write_ctl(ctl_path, 2, "out.txt")
    rc, out = _run(_cli("mcmctree", env) + [ctl_path], log, cwd=out_dir)
    out_txt = os.path.join(out_dir, "out.txt")
    if rc != 0 and not os.path.exists(out_txt):
        log.append(f"## ERROR\nmcmctree pass2 (usedata=2, MCMC) failed (exit {rc}).\n\n```\n{out[-2500:]}\n```")
        return "\n".join(log)

    log.append("## Results")
    log.append(f"- Control file: {ctl_path}")
    log.append(f"- Alignment (PAML): {phy_path}")
    if os.path.exists(out_txt):
        log.append(f"- mcmctree output: {out_txt}")
        table = _parse_mcmctree_divergence(out_txt)
        if table:
            log.append("\n### Divergence-time estimates (posterior)\n```\n" + table + "\n```")
    for f in ("FigTree.tre", "out.txt"):
        p = os.path.join(out_dir, f)
        if os.path.exists(p) and f != "out.txt":
            log.append(f"- {p}")
    return "\n".join(log)
