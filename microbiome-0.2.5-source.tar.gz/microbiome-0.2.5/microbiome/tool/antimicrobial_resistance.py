"""Antimicrobial resistance / virulence / biosynthetic-gene-cluster tools for Microbiome.

Resistance-gene annotation (RGI/CARD, AMRFinderPlus, ABRicate), virulence-factor
screening (VFDB via DIAMOND), and secondary-metabolite BGC detection (antiSMASH).
Each tool returns a markdown research log and writes results to disk. Heavy steps run
in the `microbiome` conda env; missing CLIs yield an install hint. Natural-language
requests ("annotate resistance genes", "find virulence factors", "detect biosynthetic
gene clusters") map onto these tools.
"""

import os

from microbiome.resource_config import threads as _default_threads
from microbiome.tool.metagenomics import DEFAULT_ENV as _DEFAULT_ENV
from microbiome.tool.metagenomics import (
    _cli,
    _find_cli,
    _install_hint,
    _run,
)

_EXTRA_CLI = {
    "rgi": ("rgi", "rgi"),
    "amrfinder": ("amrfinder", "ncbi-amrfinderplus"),
    "abricate": ("abricate", "abricate"),
    "antismash": ("antismash", "antismash"),
    "diamond": ("diamond", "diamond"),
    "prodigal": ("prodigal", "prodigal"),
}


def annotate_resistance_rgi(input_fasta, out_dir="rgi_out", env=None, input_type="contig"):
    """Annotate antimicrobial-resistance genes with RGI against the CARD database.

    RGI (Resistance Gene Identifier) screens assemblies/proteins against CARD
    (Comprehensive Antibiotic Resistance Database). The CARD reference must be loaded
    first (`rgi load` / `rgi card_annotation`), or set RGI_DB / pass a preloaded CARD.

    Parameters
    ----------
    input_fasta : str
        Path to assembled contigs (nucleotide) or predicted proteins (FAA).
    out_dir : str, optional
        Output directory (default "rgi_out").
    env : str, optional
        Conda environment name.
    input_type : str, optional
        "contig" (default, nucleotide) or "protein".

    Returns
    -------
    str
        Research log with the RGI hit table path and resistance-gene count, or a DB hint.
    """
    if env is None:
        env = _DEFAULT_ENV
    os.makedirs(out_dir, exist_ok=True)
    log = ["# Resistance Gene Annotation (RGI / CARD)", f"- input: {input_fasta}", f"- type: {input_type}\n"]

    if _find_cli("rgi", env) is None:
        log.append("## ERROR\n" + _install_hint("rgi"))
        return "\n".join(log)

    db = os.environ.get("RGI_DB", "")
    if not db:
        from microbiome.tool.db_inventory import _resolve_db_path
        db = _resolve_db_path("card") or ""
        if db:
            log.append(f"- auto-detected {'card'} database: {db}")
    if not db:
        log.append(
            "## NOTE\nRGI_DB not set. RGI needs the CARD reference loaded; run "
            "`rgi load -i card.json` (or `rgi card_annotation`) once, or set RGI_DB to a "
            "preloaded CARD directory. Attempting `rgi main` with the default DB.\n"
        )
    out_prefix = os.path.join(out_dir, "rgi")
    cmd = _cli("rgi", env) + [
        "main", "-i", input_fasta, "-o", out_prefix, "-t", input_type, "-n", str(_default_threads()), "--clean",
    ]
    if db:
        cmd += ["-d", db]
    rc, out = _run(cmd, log, cwd=out_dir)
    if rc != 0:
        log.append(f"## ERROR\nrgi main failed (exit {rc}). Likely a CARD DB issue.\n\n```\n{out[-2500:]}\n```")
        return "\n".join(log)

    txt = out_prefix + ".txt"
    log.append("## Results")
    log.append(f"- Output directory: {out_dir}")
    if os.path.exists(txt):
        with open(txt) as fh:
            n = max(0, sum(1 for _ in fh) - 1)
        log.append(f"- Resistance-gene hits: {n}")
        log.append(f"- RGI table: {txt}")
    else:
        log.append("- (no rgi.txt produced; check RGI/CARD output)")
    return "\n".join(log)


def annotate_resistance_amrfinder(input_fasta, out_dir="amrfinder_out", env=None, organism=None, nucleotide=True):
    """Annotate AMR / stress / virulence genes with NCBI AMRFinderPlus.

    AMRFinderPlus uses curated HMMs + BLAST against the NCBI AMR database (downloaded
    via `amrfinder -u`). It also reports stress/heat/metal and some virulence genes.

    Parameters
    ----------
    input_fasta : str
        Path to contigs (nucleotide) or proteins (FAA).
    out_dir : str, optional
        Output directory (default "amrfinder_out").
    env : str, optional
        Conda environment name.
    organism : str, optional
        Optional NCBI organism group for point-mutation calling (e.g. "Escherichia").
    nucleotide : bool, optional
        If True (default) treat input as nucleotide contigs (-n); else proteins (-p).

    Returns
    -------
    str
        Research log with the AMRFinderPlus table path and hit count, or an update hint.
    """
    if env is None:
        env = _DEFAULT_ENV
    os.makedirs(out_dir, exist_ok=True)
    log = ["# AMR Annotation (AMRFinderPlus)", f"- input: {input_fasta}\n"]

    if _find_cli("amrfinder", env) is None:
        log.append("## ERROR\n" + _install_hint("amrfinder"))
        return "\n".join(log)

    out_tsv = os.path.join(out_dir, "amrfinder.tsv")
    cmd = _find_cli("amrfinder", env) + (["-n", input_fasta] if nucleotide else ["-p", input_fasta])
    cmd += ["-o", out_tsv, "--threads", str(_default_threads()), "--plus"]
    if organism:
        cmd += ["-O", organism]
    rc, out = _run(cmd, log)
    if rc != 0:
        log.append(
            f"## ERROR\namrfinder failed (exit {rc}). If the DB is missing run `amrfinder -u`.\n\n```\n{out[-2500:]}\n```"
        )
        return "\n".join(log)

    n = 0
    if os.path.exists(out_tsv):
        with open(out_tsv) as fh:
            n = max(0, sum(1 for _ in fh) - 1)
    log.append("## Results")
    log.append(f"- AMRFinderPlus table: {out_tsv}")
    log.append(f"- AMR/stress/virulence hits: {n}")
    return "\n".join(log)


def annotate_resistance_abricate(contigs, out_dir="abricate_out", env=None, db="card"):
    """Mass-screen contigs for resistance genes with ABRicate (BLAST + bundled DBs).

    ABRicate ships with several resistance DBs (card, resfinder, ncbi, argannot, megares)
    plus vfdb for virulence. First run may need `abricate --setupdb`.

    Parameters
    ----------
    contigs : str
        Path to assembled contigs FASTA.
    out_dir : str, optional
        Output directory (default "abricate_out").
    env : str, optional
        Conda environment name.
    db : str, optional
        ABRicate database to screen against (default "card"; also "resfinder", "ncbi",
        "vfdb", "plasmidfinder", ...).

    Returns
    -------
    str
        Research log with the ABRicate table path and hit count.
    """
    if env is None:
        env = _DEFAULT_ENV
    os.makedirs(out_dir, exist_ok=True)
    log = ["# Resistance Screen (ABRicate)", f"- contigs: {contigs}", f"- db: {db}\n"]

    if _find_cli("abricate", env) is None:
        log.append("## ERROR\n" + _install_hint("abricate"))
        return "\n".join(log)

    out_tsv = os.path.join(out_dir, f"abricate_{db}.tsv")
    import subprocess

    from microbiome.tool.metagenomics import _env_prefix

    full = " ".join(_cli("abricate", env) + ["--db", db, "--threads", str(_default_threads()), contigs]) + f" > {out_tsv}"
    res = subprocess.run(_env_prefix(env) + ["bash", "-c", full], capture_output=True, text=True, check=False)
    log.append(f"$ {full}")
    if res.returncode != 0 or not os.path.exists(out_tsv):
        log.append(
            f"## ERROR\nabricate failed (exit {res.returncode}). On first use run `abricate --setupdb`.\n\n```"
            f"\n{(res.stdout or '') + (res.stderr or '')[-2000:]}\n```"
        )
        return "\n".join(log)

    n = 0
    if os.path.exists(out_tsv):
        with open(out_tsv) as fh:
            n = sum(1 for line in fh if line.strip() and not line.startswith("#"))
    log.append("## Results")
    log.append(f"- ABRicate table: {out_tsv}")
    log.append(f"- Hits: {n}")
    return "\n".join(log)


def annotate_virulence_vfdb(input_fasta, vfdb_dmnd, out_dir="vfdb_out", env=None, max_evalue=1e-5, min_pident=70.0, input_type="protein"):
    """Screen for virulence factors against VFDB using DIAMOND.

    VFDB (Virulence Factor Database) requires a DIAMOND-format build of the VFDB protein
    set (e.g. VFDB_setA_pro.fas -> `diamond makedb`). Provide the path to that .dmnd.

    Parameters
    ----------
    input_fasta : str
        Path to predicted proteins (FAA) or contigs (nucleotide).
    vfdb_dmnd : str
        Path to a DIAMOND-format VFDB protein database (.dmnd).
    out_dir : str, optional
        Output directory (default "vfdb_out").
    env : str, optional
        Conda environment name.
    max_evalue : float, optional
        Maximum E-value for reporting hits (default 1e-5).
    min_pident : float, optional
        Minimum percent identity (default 70.0).
    input_type : str, optional
        "protein" (default, blastp) or "contig" (blastx).

    Returns
    -------
    str
        Research log with the VFDB hit table path and virulence-gene count.
    """
    if env is None:
        env = _DEFAULT_ENV
    os.makedirs(out_dir, exist_ok=True)
    log = ["# Virulence Factor Screen (VFDB / DIAMOND)", f"- input: {input_fasta}", f"- db: {vfdb_dmnd}\n"]

    if _find_cli("diamond", env) is None:
        log.append("## ERROR\n" + _install_hint("diamond"))
        return "\n".join(log)
    if not os.path.exists(vfdb_dmnd):
        log.append(
            f"## ERROR\nVFDB DIAMOND DB not found: {vfdb_dmnd}.\n"
            "Build with: `diamond makedb --in VFDB_setA_pro.fas -d vfdb`."
        )
        return "\n".join(log)

    out_tsv = os.path.join(out_dir, "vfdb_hits.tsv")
    mode = "blastp" if input_type == "protein" else "blastx"
    cmd = _cli("diamond", env) + [
        mode, "-q", input_fasta, "-d", vfdb_dmnd, "-o", out_tsv,
        "-f", "6", "qseqid", "sseqid", "pident", "length", "evalue", "bitscore", "stitle",
        "--evalue", str(max_evalue), "--id", str(min_pident), "--max-target-seqs", "1", "--threads", str(_default_threads()),
    ]
    rc, out = _run(cmd, log)
    if rc != 0:
        log.append(f"## ERROR\nDIAMOND {mode} failed (exit {rc}).\n\n```\n{out[-2500:]}\n```")
        return "\n".join(log)

    n = 0
    if os.path.exists(out_tsv):
        with open(out_tsv) as fh:
            n = sum(1 for line in fh if line.strip())
    log.append("## Results")
    log.append(f"- VFDB hit table: {out_tsv}")
    log.append(f"- Virulence-factor hits: {n}")
    return "\n".join(log)


def detect_biosynthetic_gene_clusters(contigs, out_dir="antismash_out", env=None, taxon="bacteria"):
    """Detect secondary-metabolite biosynthetic gene clusters (BGCs) with antiSMASH.

    antiSMASH annotates BGCs (NRPS, PKS, RiPP, terpene, ...) in bacterial/fungal genomes.
    Its databases download on first run (`download-antismash-databases`).

    Parameters
    ----------
    contigs : str
        Path to assembled genome/contigs FASTA.
    out_dir : str, optional
        Output directory (default "antismash_out").
    env : str, optional
        Conda environment name.
    taxon : str, optional
        "bacteria" (default) or "fungi".

    Returns
    -------
    str
        Research log with BGC count and output paths, or a DB hint.
    """
    if env is None:
        env = _DEFAULT_ENV
    os.makedirs(out_dir, exist_ok=True)
    log = ["# Biosynthetic Gene Cluster Detection (antiSMASH)", f"- contigs: {contigs}", f"- taxon: {taxon}\n"]

    if _find_cli("antismash", env) is None:
        log.append("## ERROR\n" + _install_hint("antismash"))
        return "\n".join(log)

    cmd = _cli("antismash", env) + [
        "--taxon", taxon, "--output-dir", out_dir, "--genefinding-tool", "prodigal", contigs,
    ]
    rc, out = _run(cmd, log)
    if rc != 0:
        log.append(
            f"## ERROR\nantiSMASH failed (exit {rc}). On first use run `download-antismash-databases`.\n\n```\n{out[-2500:]}\n```"
        )
        return "\n".join(log)

    idx = os.path.join(out_dir, "index.html")
    log.append("## Results")
    log.append(f"- Output directory: {out_dir}")
    if os.path.exists(idx):
        log.append(f"- antiSMASH report: {idx}")
    log.append("- Inspect region*.gbk / the HTML report for BGC types and coordinates.")
    return "\n".join(log)
