"""Amplicon (16S/ITS) analysis tools for Microbiome.

Denoising/OTU picking, taxonomic annotation, and diversity analysis. Heavy steps
(DADA2, BLAST) run in the `microbiome` conda env or via R; diversity metrics are
pure Python. Each tool returns a markdown research log and writes results to disk.
"""

import os

from microbiome.tool.metagenomics import DEFAULT_ENV as _DEFAULT_ENV
from microbiome.tool.metagenomics import (
    _cli,
    _find_cli,
    _install_hint,
    _run,
)

_EXTRA_CLI = {
    "usearch": ("usearch", "usearch"),
    "vsearch": ("vsearch", "vsearch"),
    "blastn": ("blastn", "blast"),
    "makeblastdb": ("makeblastdb", "blast"),
    "Rscript": ("Rscript", "r-base"),
}


def amplicon_denoise_dada2(reads_dir, out_dir="dada2_out", pattern_r1="_R1", pattern_r2="_R2", env=None):
    """Denoise paired-end amplicon reads with DADA2 (via Rscript) to get ASVs.

    Parameters
    ----------
    reads_dir : str
        Directory containing paired-end FASTQ files (optionally .gz).
    out_dir : str, optional
        Output directory for the ASV table (default "dada2_out").
    pattern_r1 : str, optional
        Substring identifying R1 files (default "_R1").
    pattern_r2 : str, optional
        Substring identifying R2 files (default "_R2").
    env : str, optional
        Conda environment name (default MICROBIOME_ENV or "microbiome").

    Returns
    -------
    str
        Research log with ASV count and output table path, or an install note if
        R/DADA2 is unavailable.
    """
    if env is None:
        env = _DEFAULT_ENV
    os.makedirs(out_dir, exist_ok=True)
    log = ["# Amplicon Denoising (DADA2)", f"- reads_dir: {reads_dir}\n"]

    if _find_cli("Rscript", env) is None:
        log.append(
            "## ERROR\n" + _install_hint("Rscript")
            + "\nAlso install DADA2 in R:\n```r\n"
            + "if (!requireNamespace('BiocManager')) install.packages('BiocManager')\n"
            + "BiocManager::install('dada2')\n```"
        )
        return "\n".join(log)

    asv_tsv = os.path.abspath(os.path.join(out_dir, "asv_table.tsv"))
    rscript = f"""
suppressMessages(library(dada2))
fnFs <- sort(list.files("{os.path.abspath(reads_dir)}", pattern="{pattern_r1}", full.names=TRUE))
fnRs <- sort(list.files("{os.path.abspath(reads_dir)}", pattern="{pattern_r2}", full.names=TRUE))
filtFs <- file.path(tempdir(), basename(fnFs)); filtRs <- file.path(tempdir(), basename(fnRs))
out <- filterAndTrim(fnFs, filtFs, fnRs, filtRs, truncLen=c(240,200), maxN=0, maxEE=c(2,2), truncQ=2, multithread=TRUE)
errF <- learnErrors(filtFs, multithread=TRUE); errR <- learnErrors(filtRs, multithread=TRUE)
dadaFs <- dada(filtFs, err=errF, multithread=TRUE); dadaRs <- dada(filtRs, err=errR, multithread=TRUE)
mergers <- mergePairs(dadaFs, filtFs, dadaRs, filtRs)
seqtab <- makeSequenceTable(mergers)
write.table(t(seqtab), "{asv_tsv}", sep="\\t", quote=FALSE, col.names=NA)
cat("ASVs:", ncol(seqtab), "\\n")
"""
    rfile = os.path.join(out_dir, "_dada2.R")
    with open(rfile, "w") as fh:
        fh.write(rscript)
    rc, out = _run(_cli("Rscript", env) + [rfile], log)
    if rc != 0:
        log.append(f"## ERROR\nDADA2 failed (exit {rc}). Is the dada2 R package installed?\n\n```\n{out[-2500:]}\n```")
        return "\n".join(log)

    log.append("## Results")
    log.append(f"- ASV table: {asv_tsv}")
    log.append("\n```\n" + "\n".join(out.splitlines()[-3:]) + "\n```")
    return "\n".join(log)


def amplicon_taxonomy_blast(rep_seqs, db_fasta, out_dir="amplicon_taxonomy", env=None, max_evalue=1e-10, min_pident=97.0):
    """Annotate ASV/OTU representative sequences by BLASTN against a 16S/ITS database.

    Parameters
    ----------
    rep_seqs : str
        Path to representative sequences FASTA (ASVs/OTUs).
    db_fasta : str
        Path to a 16S/ITS reference database FASTA (will be makeblastdb'd).
    out_dir : str, optional
        Output directory (default "amplicon_taxonomy").
    env : str, optional
        Conda environment name.
    max_evalue : float, optional
        Max E-value (default 1e-10).
    min_pident : float, optional
        Min percent identity to report (default 97).

    Returns
    -------
    str
        Research log with taxonomy table path and annotated ASV count.
    """
    if env is None:
        env = _DEFAULT_ENV
    os.makedirs(out_dir, exist_ok=True)
    log = ["# Amplicon Taxonomy (BLASTN)", f"- rep_seqs: {rep_seqs}", f"- db: {db_fasta}\n"]

    for tool in ("makeblastdb", "blastn"):
        if _find_cli(tool, env) is None:
            log.append("## ERROR\n" + _install_hint(tool))
            return "\n".join(log)
    if not os.path.exists(db_fasta):
        log.append(f"## ERROR\nDatabase FASTA not found: {db_fasta}")
        return "\n".join(log)

    db_prefix = os.path.join(out_dir, "refdb")
    rc, out = _run(_cli("makeblastdb", env) + ["-in", db_fasta, "-dbtype", "nucl", "-out", db_prefix], log)
    if rc != 0:
        log.append(f"## ERROR\nmakeblastdb failed.\n\n```\n{out[-1500:]}\n```")
        return "\n".join(log)

    out_tsv = os.path.join(out_dir, "taxonomy.tsv")
    cmd = _cli("blastn", env) + [
        "-query", rep_seqs, "-db", db_prefix, "-out", out_tsv,
        "-outfmt", "6 qseqid sseqid pident length evalue bitscore stitle",
        "-evalue", str(max_evalue), "-max_target_seqs", "1", "-num_threads", "4",
    ]
    rc, out = _run(cmd, log)
    if rc != 0:
        log.append(f"## ERROR\nblastn failed (exit {rc}).\n\n```\n{out[-2000:]}\n```")
        return "\n".join(log)

    n = 0
    kept = 0
    if os.path.exists(out_tsv):
        with open(out_tsv) as fh:
            for line in fh:
                if not line.strip():
                    continue
                n += 1
                if float(line.split("\t")[2]) >= min_pident:
                    kept += 1
    log.append("## Results")
    log.append(f"- Taxonomy table: {out_tsv}")
    log.append(f"- ASVs with a hit: {n} (>= {min_pident}% identity: {kept})")
    return "\n".join(log)


def amplicon_diversity(asv_table, out_dir="amplicon_diversity"):
    """Compute alpha (Shannon, Simpson, richness) and beta (Bray-Curtis) diversity.

    Pure Python (no CLI). Input is an ASV/OTU count table (rows = samples, columns
    = features, or the transpose) as TSV with a header.

    Parameters
    ----------
    asv_table : str
        Path to the ASV/OTU count table (TSV). First column = sample IDs.
    out_dir : str, optional
        Output directory (default "amplicon_diversity").

    Returns
    -------
    str
        Research log with per-sample alpha diversity and a Bray-Curtis distance matrix.
    """
    import csv
    import math

    os.makedirs(out_dir, exist_ok=True)
    log = ["# Amplicon Diversity", f"- table: {asv_table}\n"]

    with open(asv_table) as fh:
        rows = [r for r in csv.reader(fh, delimiter="\t") if r]
    header = rows[0]
    samples = [r[0] for r in rows[1:]]
    counts = [[float(x) if x else 0.0 for x in r[1:]] for r in rows[1:]]

    def shannon(c):
        tot = sum(c)
        if tot == 0:
            return 0.0
        return -sum((x / tot) * math.log(x / tot) for x in c if x > 0)

    def simpson(c):
        tot = sum(c)
        if tot == 0:
            return 0.0
        return 1 - sum((x / tot) ** 2 for x in c)

    def richness(c):
        return sum(1 for x in c if x > 0)

    alpha_tsv = os.path.join(out_dir, "alpha_diversity.tsv")
    with open(alpha_tsv, "w", newline="") as fh:
        wr = csv.writer(fh, delimiter="\t")
        wr.writerow(["sample", "richness", "shannon", "simpson"])
        for s, c in zip(samples, counts, strict=True):
            wr.writerow([s, richness(c), f"{shannon(c):.4f}", f"{simpson(c):.4f}"])

    def bray_curtis(a, b):
        num = sum(abs(x - y) for x, y in zip(a, b, strict=True))
        den = sum(a) + sum(b)
        return num / den if den else 0.0

    beta_tsv = os.path.join(out_dir, "beta_braycurtis.tsv")
    with open(beta_tsv, "w", newline="") as fh:
        wr = csv.writer(fh, delimiter="\t")
        wr.writerow([""] + samples)
        for s1, c1 in zip(samples, counts, strict=True):
            wr.writerow([s1] + [f"{bray_curtis(c1, c2):.4f}" for c2 in counts])

    log.append("## Results")
    log.append(f"- Samples: {len(samples)}; Features: {len(header) - 1}")
    log.append(f"- Alpha diversity: {alpha_tsv}")
    log.append(f"- Bray-Curtis matrix: {beta_tsv}\n")
    log.append("| sample | richness | shannon | simpson |")
    log.append("|---|---|---|---|")
    for s, c in zip(samples, counts, strict=True):
        log.append(f"| {s} | {richness(c)} | {shannon(c):.3f} | {simpson(c):.3f} |")
    return "\n".join(log)

def amplicon_qiime2_pipeline(manifest, out_dir="qiime2_out", env=None, steps=None, classifier=None, metadata=None):
    """Run a QIIME 2 amplicon workflow (import -> dada2 -> phylogeny -> diversity -> taxonomy).

    QIIME 2 is a plugin-based 16S/ITS platform. This wraps the standard moving-pictures
    style pipeline as discrete, idempotent steps. Requires the `qiime` CLI (QIIME 2
    conda env). If qiime is not installed, returns an install hint.

    Parameters
    ----------
    manifest : str
        Path to a QIIME 2 manifest CSV (sample-id, absolute-filepath, direction) for
        paired-end or single-end fastq.
    out_dir : str, optional
        Output directory (default "qiime2_out").
    env : str, optional
        Conda env name hosting QIIME 2.
    steps : list, optional
        Subset of steps to run among ["import","dada2","phylogeny","diversity","taxonomy"].
        Default runs import+dada2 (the rest need a classifier/metadata).
    classifier : str, optional
        Path to a QIIME 2 trained classifier (.qza) for the taxonomy step.
    metadata : str, optional
        Path to sample metadata TSV for the diversity step.

    Returns
    -------
    str
        Research log with the artifacts produced and their paths (or an install hint).
    """
    if env is None:
        env = _DEFAULT_ENV
    os.makedirs(out_dir, exist_ok=True)
    log = ["# QIIME 2 Amplicon Pipeline", f"- manifest: {manifest}", f"- out_dir: {out_dir}\n"]

    if _find_cli("qiime", env) is None:
        log.append(
            "## ERROR\nqiime (QIIME 2) not found. Install in a dedicated env, e.g.:\n"
            "```bash\nconda create -n qiime2 -c conda-forge -c bioconda qiime2\n```"
        )
        return "\n".join(log)

    if steps is None:
        steps = ["import", "dada2"]
    demux = os.path.join(out_dir, "demux.qza")
    table = os.path.join(out_dir, "table.qza")
    repseqs = os.path.join(out_dir, "rep-seqs.qza")

    def q(*args):
        return _run(_find_cli("qiime", env) + list(args), log)

    if "import" in steps and not os.path.exists(demux):
        rc, _ = q("tools", "import", "--type", "SampleData[PairedEndSequencesWithQuality]",
                  "--input-path", manifest, "--output-path", demux,
                  "--input-format", "PairedEndFastqManifestPhred33V2")
        if rc != 0:
            log.append("## ERROR\nqiime import failed (check manifest format).")
            return "\n".join(log)
    if "dada2" in steps and not os.path.exists(table):
        rc, _ = q("dada2", "denoise-paired", "--i-demultiplexed-seqs", demux,
                  "--p-trunc-len-f", "240", "--p-trunc-len-r", "200",
                  "--o-table", table, "--o-representative-sequences", repseqs,
                  "--o-denoising-stats", os.path.join(out_dir, "stats.qza"))
        if rc != 0:
            log.append("## ERROR\nqiime dada2 failed.")
            return "\n".join(log)
    if "phylogeny" in steps:
        q("phylogeny", "align-to-tree-mafft-fasttree", "--i-sequences", repseqs,
          "--o-alignment", os.path.join(out_dir, "aligned.qza"),
          "--o-masked-alignment", os.path.join(out_dir, "masked.qza"),
          "--o-tree", os.path.join(out_dir, "tree.qza"),
          "--o-rooted-tree", os.path.join(out_dir, "rooted-tree.qza"))
    if "diversity" in steps and metadata:
        q("diversity", "core-metrics-phylogenetic", "--i-phylogeny", os.path.join(out_dir, "rooted-tree.qza"),
          "--i-table", table, "--p-sampling-depth", "10000", "--m-metadata-file", metadata,
          "--output-dir", os.path.join(out_dir, "core-metrics"))
    if "taxonomy" in steps and classifier:
        q("feature-classifier", "classify-sklearn", "--i-classifier", classifier, "--i-reads", repseqs,
          "--o-classification", os.path.join(out_dir, "taxonomy.qza"))

    log.append("## Results")
    for art in ("demux.qza", "table.qza", "rep-seqs.qza", "taxonomy.qza"):
        p = os.path.join(out_dir, art)
        if os.path.exists(p):
            log.append(f"- {art}: {p}")
    log.append(f"- Output directory: {out_dir}")
    return "\n".join(log)
