"""Mobile genetic elements for Microbiome.

Plasmid / mobile-element identification (geNomad) and horizontal gene transfer
(HGT) candidate detection. Each tool returns a markdown research log and writes
results to disk. Heavy steps run in the `microbiome` conda env; missing CLIs yield
an install hint. Natural-language workflows ("find plasmids", "detect horizontal
gene transfer") map onto these tools.
"""

import os

from microbiome.tool.metagenomics import DEFAULT_ENV as _DEFAULT_ENV
from microbiome.tool.metagenomics import (
    _cli,
    _find_cli,
    _install_hint,
    _run,
)

_EXTRA_CLI = {
    "genomad": ("genomad", "genomad"),
}

# Marker genes that flag mobility / HGT (integrases, transposases, conjugation, ICE).
_MOBILE_KEYWORDS = (
    "integrase", "transposase", "transposon", "resolvase", "recombinase",
    "conjugative", "conjugal", "type iv secretion", "t4ss", "tra", "trb",
    "relaxase", "mob", "mobilization", "insertion sequence", "is element",
    "plasmid", "prophage", "phage integrase",
)


def _read_fasta(path):
    seqs = []
    name, buf = None, []
    with open(path) as fh:
        for line in fh:
            line = line.rstrip("\n")
            if line.startswith(">"):
                if name is not None:
                    seqs.append((name, "".join(buf)))
                name, buf = line[1:].split()[0], []
            elif line:
                buf.append(line.strip())
    if name is not None:
        seqs.append((name, "".join(buf)))
    return seqs


def _tetra_zscores(seq, k=4):
    """Return a per-sequence tetranucleotide frequency dict (upper, canonical)."""
    from collections import Counter

    seq = seq.upper()
    kmers = [seq[i:i + k] for i in range(len(seq) - k + 1) if "N" not in seq[i:i + k]]
    if not kmers:
        return {}
    counts = Counter(kmers)
    total = sum(counts.values())
    return {kmer: c / total for kmer, c in counts.items()}


def _tetra_distance(f1, f2, k=4):
    """Manhattan distance between two k-mer frequency dicts over the full k-mer space."""
    if not f1 or not f2:
        return 0.0
    keys = set(f1) | set(f2)
    return sum(abs(f1.get(x, 0.0) - f2.get(x, 0.0)) for x in keys)


def identify_plasmids(contigs, out_dir="plasmid_id", env=None):
    """Identify plasmid / mobile-element contigs from an assembly using geNomad.

    geNomad classifies each contig as chromosome / plasmid / virus and reports
    conjugation & AMR genes on mobile elements. The geNomad database must be
    configured (GENOMAD_DB or `genomad download-database`).

    Parameters
    ----------
    contigs : str
        Path to assembled contigs FASTA (metagenome or isolate).
    out_dir : str, optional
        Output directory (default "plasmid_id").
    env : str, optional
        Conda environment name (default MICROBIOME_ENV or "microbiome").

    Returns
    -------
    str
        Research log with plasmid contig count and paths (or an install/DB hint).
    """
    if env is None:
        env = _DEFAULT_ENV
    os.makedirs(out_dir, exist_ok=True)
    log = ["# Plasmid / Mobile-Element Identification (geNomad)", f"- contigs: {contigs}\n"]

    if _find_cli("genomad", env) is None:
        log.append("## ERROR\n" + _install_hint("genomad"))
        return "\n".join(log)

    db = os.environ.get("GENOMAD_DB", "")
    if not db:
        from microbiome.tool.db_inventory import _resolve_db_path
        db = _resolve_db_path("genomad") or ""
        if db:
            log.append(f"- auto-detected geNomad database: {db}")
    cmd = _cli("genomad", env) + ["end-to-end", "--cleanup", contigs, out_dir]
    if db:
        cmd.append(db)
    else:
        log.append(
            "## NOTE\nGENOMAD_DB not set and no local database found. "
            "Download with `genomad download-database <dir>` and place it under Database/genomad/.\n"
        )
    rc, out = _run(cmd, log)
    if rc != 0:
        log.append(f"## ERROR\ngeNomad failed (exit {rc}). Likely a database issue.\n\n```\n{out[-2500:]}\n```")
        return "\n".join(log)

    plasmid_summ = None
    for root, _dirs, files in os.walk(out_dir):
        for f in files:
            if f.endswith("plasmid_summary.tsv"):
                plasmid_summ = os.path.join(root, f)
    log.append("## Results")
    log.append(f"- Output directory: {out_dir}")
    if plasmid_summ and os.path.exists(plasmid_summ):
        with open(plasmid_summ) as fh:
            n = max(0, sum(1 for _ in fh) - 1)
        log.append(f"- Plasmid contigs identified: {n}")
        log.append(f"- Plasmid summary: {plasmid_summ}")
    else:
        log.append("- (no plasmid_summary.tsv found; check geNomad output)")
    return "\n".join(log)


def detect_hgt(contigs, out_dir="hgt_detection", env=None, z_threshold=3.0, use_genomad=True):
    """Detect candidate horizontally transferred (HGT) regions in contigs/genomes.

    Compositional approach: compute each contig's tetranucleotide frequency and flag
    contigs whose composition is a strong outlier (|z| > z_threshold on distance) from
    the genome-wide mean — a classic HGT signature (alien composition). Optionally
    corroborate with geNomad mobility genes (integrase/transposase/conjugation).

    Parameters
    ----------
    contigs : str
        Path to contigs FASTA (multiple contigs/scaffolds of one genome or metagenome).
    out_dir : str, optional
        Output directory (default "hgt_detection").
    env : str, optional
        Conda environment name.
    z_threshold : float, optional
        Robust z-score threshold on tetranucleotide distance for flagging HGT candidates
        (default 3.0).
    use_genomad : bool, optional
        If True, also run geNomad to corroborate with mobility-gene evidence.

    Returns
    -------
    str
        Research log with HGT-candidate table path and counts.
    """
    if env is None:
        env = _DEFAULT_ENV
    os.makedirs(out_dir, exist_ok=True)
    log = ["# Horizontal Gene Transfer (HGT) Detection", f"- contigs: {contigs}", f"- z_threshold: {z_threshold}\n"]

    seqs = _read_fasta(contigs)
    if len(seqs) < 3:
        log.append(f"## ERROR\nNeed >=3 contigs to estimate genome-wide composition; found {len(seqs)}.")
        return "\n".join(log)

    # tetranucleotide frequencies per contig + genome-wide pooled reference
    freqs = {name: _tetra_zscores(seq) for name, seq in seqs}
    pooled = {}
    for f in freqs.values():
        for k, v in f.items():
            pooled[k] = pooled.get(k, 0.0) + v
    nseq = len(freqs)
    pooled = {k: v / nseq for k, v in pooled.items()}

    dists = {name: _tetra_distance(f, pooled) for name, f in freqs.items()}
    vals = sorted(dists.values())
    med = vals[len(vals) // 2]
    mad = sorted(abs(v - med) for v in vals)[len(vals) // 2] or 1e-9
    robust_z = {name: 0.6745 * (d - med) / mad for name, d in dists.items()}

    cand = {name: round(z, 3) for name, z in robust_z.items() if z >= z_threshold}
    tsv = os.path.join(out_dir, "hgt_candidates.tsv")
    with open(tsv, "w") as fh:
        fh.write("contig\ttetra_distance\trobust_z\thgt_candidate\n")
        for name in dists:
            fh.write(f"{name}\t{dists[name]:.5f}\t{robust_z[name]:.3f}\t{'yes' if name in cand else 'no'}\n")

    log.append("## Compositional HGT candidates")
    log.append(f"- Contigs analysed: {len(seqs)}")
    log.append(f"- HGT candidates (robust z >= {z_threshold}): {len(cand)}")
    log.append(f"- Candidate table: {tsv}")

    if use_genomad and _find_cli("genomad", env) is not None:
        from microbiome.tool.db_inventory import _resolve_db_path
        _auto_db = _resolve_db_path("genomad")
        if _auto_db and not os.environ.get("GENOMAD_DB"):
            os.environ["GENOMAD_DB"] = _auto_db
        gdir = os.path.join(out_dir, "genomad_mobilome")
        rc, out = _run(_cli("genomad", env) + ["end-to-end", "--cleanup", contigs, gdir, os.environ["GENOMAD_DB"]], log)
        if rc == 0:
            log.append(f"- geNomad mobilome corroboration: {gdir}")
        else:
            log.append(f"- geNomad corroboration skipped (exit {rc}); see log.")
    elif use_genomad:
        log.append(
            "- NOTE: geNomad corroboration skipped (genomad CLI or GENOMAD_DB not set). "
            "Mobility-gene evidence (integrase/transposase/conjugation) strengthens HGT calls."
        )
    return "\n".join(log)


def find_mobile_genes(annotation_tsv, out_dir="mobile_genes", env=None):
    """Flag mobility-associated genes from an annotation table (integrase/transposase/etc.).

    Scans an annotation TSV (contig/gene -> product/description) for mobility keywords
    to flag candidate horizontally transferred / mobilised genes.

    Parameters
    ----------
    annotation_tsv : str
        Path to a TSV with a text column of gene products/descriptions (e.g. from
        annotate_isolate_genome or DIAMOND annotation). Header required.
    out_dir : str, optional
        Output directory (default "mobile_genes").
    env : str, optional
        Conda environment name (unused; kept for interface consistency).

    Returns
    -------
    str
        Research log with flagged mobile-gene table path and count.
    """
    os.makedirs(out_dir, exist_ok=True)
    log = ["# Mobile-Gene Flagging", f"- annotations: {annotation_tsv}\n"]

    if not os.path.exists(annotation_tsv):
        log.append(f"## ERROR\nAnnotation file not found: {annotation_tsv}")
        return "\n".join(log)

    hits = []
    with open(annotation_tsv) as fh:
        header = fh.readline().rstrip("\n").split("\t")
        desc_idx = len(header) - 1  # default: last column is the description
        for line in fh:
            parts = line.rstrip("\n").split("\t")
            text = parts[desc_idx].lower() if len(parts) > desc_idx else ""
            if any(kw in text for kw in _MOBILE_KEYWORDS):
                hits.append(parts[0] if parts else "")

    out_tsv = os.path.join(out_dir, "mobile_genes.tsv")
    with open(out_tsv, "w") as fh:
        fh.write("gene_id\n")
        for g in hits:
            fh.write(f"{g}\n")

    log.append("## Results")
    log.append(f"- Mobile-gene keywords: {', '.join(_MOBILE_KEYWORDS[:6])} ...")
    log.append(f"- Flagged mobile genes: {len(hits)}")
    log.append(f"- Table: {out_tsv}")
    return "\n".join(log)
