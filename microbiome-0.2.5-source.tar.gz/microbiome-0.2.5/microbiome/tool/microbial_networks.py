"""Microbial compound-metabolic interaction network tools for Microbiome.

Build and analyze compound-metabolism interaction networks using networkx.
Edges connect a compound to a metabolic process/function it participates in
(substrate/product/enzyme links), e.g. from a user-supplied edge list or from
KEGG-like reaction tables. Pure Python (networkx); no external CLI needed.
"""

import os

# networkx is an install-time dependency of the microbiome env; degrade gracefully.
try:
    import networkx as nx
except Exception:  # pragma: no cover
    nx = None


def _require_nx(log):
    if nx is None:
        log.append(
            "## ERROR\nnetworkx is not installed. Install with:\n\n"
            "```bash\nmamba install -c conda-forge networkx\n# or: pip install networkx\n```"
        )
        return True
    return False


def build_compound_metabolic_network(edge_list, out_dir="compound_network", source_col="compound", target_col="function"):
    """Build a compound-metabolism interaction network from an edge list.

    Parameters
    ----------
    edge_list : str
        Path to a TSV/CSV edge list with at least two columns (default
        "compound" and "function"). Additional columns (e.g. weight, direction)
        are kept as edge attributes.
    out_dir : str, optional
        Output directory (default "compound_network").
    source_col : str, optional
        Column name for the source node (default "compound").
    target_col : str, optional
        Column name for the target node (default "function").

    Returns
    -------
    str
        Research log with node/edge counts and the saved GraphML path.
    """
    os.makedirs(out_dir, exist_ok=True)
    log = ["# Compound-Metabolic Network", f"- edge_list: {edge_list}\n"]
    if _require_nx(log):
        return "\n".join(log)

    import csv

    # detect delimiter
    with open(edge_list) as fh:
        first = fh.readline()
    delim = "\t" if "\t" in first else ","
    with open(edge_list) as fh:
        rd = csv.DictReader(fh, delimiter=delim)
        if source_col not in rd.fieldnames or target_col not in rd.fieldnames:
            log.append(f"## ERROR\nColumns '{source_col}'/'{target_col}' not found. Header: {rd.fieldnames}")
            return "\n".join(log)
        G = nx.DiGraph()
        for row in rd:
            s = row[source_col].strip()
            t = row[target_col].strip()
            attrs = {k: v for k, v in row.items() if k not in (source_col, target_col)}
            G.add_edge(s, t, **attrs)

    graphml = os.path.join(out_dir, "network.graphml")
    nx.write_graphml(G, graphml)

    log.append("## Results")
    log.append(f"- Nodes: {G.number_of_nodes()}")
    log.append(f"- Edges: {G.number_of_edges()}")
    log.append(f"- GraphML: {graphml}")
    return "\n".join(log)


def analyze_compound_network(graphml, out_dir="compound_network_analysis", top_n=10):
    """Analyze a compound-metabolic network: centrality, communities, hubs.

    Parameters
    ----------
    graphml : str
        Path to a GraphML network (from build_compound_metabolic_network).
    out_dir : str, optional
        Output directory (default "compound_network_analysis").
    top_n : int, optional
        Number of top hub nodes to report (default 10).

    Returns
    -------
    str
        Research log with top-degree hub nodes and basic network stats.
    """
    os.makedirs(out_dir, exist_ok=True)
    log = ["# Network Analysis", f"- graphml: {graphml}\n"]
    if _require_nx(log):
        return "\n".join(log)

    G = nx.read_graphml(graphml)
    UG = G.to_undirected()
    deg = dict(G.degree())
    top = sorted(deg.items(), key=lambda kv: kv[1], reverse=True)[:top_n]

    # connected components + density
    n_comp = nx.number_connected_components(UG) if UG.number_of_nodes() else 0
    density = nx.density(G) if G.number_of_nodes() else 0.0

    out_tsv = os.path.join(out_dir, "hub_nodes.tsv")
    with open(out_tsv, "w") as fh:
        fh.write("node\tdegree\n")
        for n, d in top:
            fh.write(f"{n}\t{d}\n")

    log.append("## Results")
    log.append(f"- Nodes: {G.number_of_nodes()}; Edges: {G.number_of_edges()}")
    log.append(f"- Density: {density:.4f}; Connected components: {n_comp}")
    log.append(f"- Hub table: {out_tsv}\n")
    log.append("| node | degree |")
    log.append("|---|---|")
    for n, d in top:
        log.append(f"| {n} | {d} |")
    return "\n".join(log)
