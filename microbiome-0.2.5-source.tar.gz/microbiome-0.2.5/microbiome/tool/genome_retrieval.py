"""Controlled reference-genome and virus-genome retrieval with gget and NCBI Datasets."""

from __future__ import annotations

import csv
import gzip
import json
import re
import shlex
import shutil
import subprocess
import zipfile
from datetime import UTC, datetime
from pathlib import Path

import yaml

from microbiome.resource_skills.registry import DEFAULT_DB_ROOT

REFERENCE_FOLDER = "reference-genomes"
_ASSEMBLY_ACCESSION = re.compile(r"^GC[AF]_\d+(?:\.\d+)?$", re.IGNORECASE)
_GGET_ASSETS = {"gtf", "cdna", "dna", "cds", "cdrna", "pep"}
_NCBI_ASSET_MAP = {
    "dna": "genome",
    "gtf": "gff3",
    "gff3": "gff3",
    "gbff": "gbff",
    "protein": "protein",
    "rna": "rna",
    "cds": "cds",
}


def _slug(value: str) -> str:
    normalized = re.sub(r"[^A-Za-z0-9._-]+", "-", value.strip()).strip("-.").lower()
    if not normalized or normalized in {".", ".."}:
        raise ValueError("identifier must contain a species name, TaxID, or assembly accession")
    return normalized[:120]


def _asset_list(assets: str | list[str] | tuple[str, ...]) -> list[str]:
    values = assets.split(",") if isinstance(assets, str) else list(assets)
    normalized = [str(value).strip().lower() for value in values if str(value).strip()]
    if not normalized:
        raise ValueError("at least one genome asset is required")
    return list(dict.fromkeys(normalized))


def _choose_source(identifier: str, source: str) -> str:
    normalized = source.strip().lower()
    if normalized == "auto":
        value = identifier.strip()
        # Ensembl species identifiers conventionally use snake_case. Natural taxon
        # names, TaxIDs and assembly accessions belong on the NCBI Datasets path.
        return "gget" if re.fullmatch(r"[a-z][a-z0-9]*_[a-z0-9_]+", value) else "ncbi-datasets"
    if normalized not in {"gget", "ncbi-datasets"}:
        raise ValueError("source must be auto, gget, or ncbi-datasets")
    return normalized


def _extract_zip_safely(package: Path, target: Path) -> None:
    """Extract a trusted data package while rejecting path traversal entries."""
    destination = target.resolve()
    with zipfile.ZipFile(package) as archive:
        for member in archive.infolist():
            member_target = (destination / member.filename).resolve()
            if destination not in member_target.parents and member_target != destination:
                raise ValueError(f"unsafe ZIP path: {member.filename}")
        archive.extractall(target)


def _datasets_summary_records(
    manager: str,
    object_type: str,
    identifier: str,
    reference_only: bool = True,
    assembly_level: str | None = None,
    annotated: bool = False,
    timeout_seconds: int = 300,
) -> list[dict]:
    """Query NCBI Datasets genome summaries and return parsed JSON-lines records."""
    command = [
        manager,
        "run",
        "-n",
        "biomni-ncbi-datasets",
        "--no-capture-output",
        "datasets",
        "summary",
        "genome",
        object_type,
        identifier,
        "--as-json-lines",
    ]
    if object_type == "taxon":
        if reference_only:
            command.append("--reference")
        if assembly_level:
            command.extend(["--assembly-level", assembly_level])
        if annotated:
            command.append("--annotated")
    result = subprocess.run(
        command,
        capture_output=True,
        text=True,
        check=False,
        timeout=timeout_seconds,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"NCBI Datasets summary failed (exit {result.returncode}):\n"
            f"{(result.stderr or result.stdout or '')[-3000:]}"
        )
    records = []
    for line in result.stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            records.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return records


def _assembly_summary_row(record: dict) -> dict[str, str]:
    info = record.get("assembly_info") or {}
    stats = record.get("assembly_stats") or {}
    organism = record.get("organism") or {}
    size: object = stats.get("total_sequence_length") or ""
    try:
        size_text = f"{int(size) / 1e6:.1f} Mb" if size != "" else ""
    except (TypeError, ValueError):
        size_text = str(size)
    return {
        "accession": str(record.get("accession") or record.get("current_accession") or ""),
        "assembly_name": str(info.get("assembly_name") or ""),
        "assembly_level": str(info.get("assembly_level") or ""),
        "organism": str(organism.get("organism_name") or ""),
        "size": size_text,
    }


def resolve_reference_genome_accessions(
    identifier: str,
    reference_only: bool = True,
    assembly_level: str | None = None,
    annotated: bool = False,
    max_results: int = 10,
    timeout_seconds: int = 300,
) -> str:
    """Resolve a species name or TaxID to RefSeq assembly accessions (read-only)."""
    identifier = str(identifier).strip()
    if not identifier:
        raise ValueError("identifier must contain a species name, TaxID, or assembly accession")
    object_type = "accession" if _ASSEMBLY_ACCESSION.fullmatch(identifier) else "taxon"
    records = _datasets_summary_records(
        _conda_manager(),
        object_type,
        identifier,
        reference_only=reference_only,
        assembly_level=assembly_level,
        annotated=annotated,
        timeout_seconds=timeout_seconds,
    )
    rows = [row for row in (_assembly_summary_row(record) for record in records) if row["accession"]]
    if not rows:
        raise RuntimeError(
            f"no {'RefSeq reference ' if reference_only and object_type == 'taxon' else ''}assembly "
            f"resolved for {identifier!r}; try reference_only=False or a broader identifier"
        )
    rows = rows[: max(1, int(max_results))]
    return "\n".join(
        [
            "# Reference genome accession resolution (read-only)",
            f"- query: {identifier} ({object_type})",
            f"- filters: reference_only={reference_only}, assembly_level={assembly_level or 'any'}, "
            f"annotated={annotated}",
            f"- resolved assemblies: {len(rows)}",
            "",
            "| accession | assembly | level | organism | size |",
            "|---|---|---|---|---|",
            *(
                f"| {row['accession']} | {row['assembly_name']} | {row['assembly_level']} | "
                f"{row['organism']} | {row['size']} |"
                for row in rows
            ),
            "",
            "Pin one accession and plan the acquisition with:",
            f"plan_reference_genome_download(identifier={rows[0]['accession']!r}, source='ncbi-datasets')",
        ]
    )


def inspect_local_reference_genomes(db_root: str | None = None, query: str = "") -> str:
    """List locally registered reference genomes and their downloaded assets."""
    root = Path(db_root or DEFAULT_DB_ROOT).expanduser().resolve() / REFERENCE_FOLDER
    manifests = sorted(root.glob("*/release-manifest.yaml")) if root.is_dir() else []
    rows = [
        "# Local reference genomes",
        f"- root: {root}",
        "",
        "| reference | source | release | assets | files | status |",
        "|---|---|---|---|---:|---|",
    ]
    lowered_query = query.lower().strip()
    for manifest_path in manifests:
        try:
            manifest = yaml.safe_load(manifest_path.read_text(encoding="utf-8")) or {}
        except (OSError, yaml.YAMLError):
            continue
        searchable = " ".join(
            str(manifest.get(field, "")) for field in ("identifier", "source", "release", "target")
        ).lower()
        if lowered_query and lowered_query not in searchable:
            continue
        files = [entry for entry in manifest.get("files", []) if isinstance(entry, dict)]
        ready = bool(files) and all(
            (manifest_path.parent / str(entry.get("path", ""))).is_file()
            and (manifest_path.parent / str(entry.get("path", ""))).stat().st_size > 0
            for entry in files
        )
        rows.append(
            f"| {manifest.get('identifier', manifest_path.parent.name)} | {manifest.get('source', '?')} | "
            f"{manifest.get('release') or 'current'} | {', '.join(manifest.get('assets', []))} | "
            f"{len(files)} | {'READY' if ready else 'INCOMPLETE'} |"
        )
    if len(rows) == 6:
        rows.append("| (none) | - | - | - | 0 | MISSING |")
    return "\n".join(rows)


def plan_reference_genome_download(
    identifier: str,
    assets: str | list[str] = "dna,gtf",
    release: int | None = None,
    source: str = "auto",
    db_root: str | None = None,
    reference_only: bool = True,
    assembly_level: str | None = None,
    annotated: bool = False,
    max_assemblies: int = 25,
) -> str:
    """Render a read-only gget/NCBI source comparison and exact confirmed call."""
    selected_source = _choose_source(identifier, source)
    selected_assets = _asset_list(assets)
    target = (
        Path(db_root or DEFAULT_DB_ROOT).expanduser().resolve()
        / REFERENCE_FOLDER
        / _slug(f"{selected_source}-{identifier}-r{release or 'current'}")
    )
    warnings = []
    if selected_source == "gget":
        unsupported = sorted(set(selected_assets) - _GGET_ASSETS)
        if unsupported:
            raise ValueError(f"gget ref does not support assets: {', '.join(unsupported)}")
        warnings.append(
            "gget ref uses Ensembl/Ensembl Genomes and does not support bacterial genomes; use an NCBI assembly accession for bacteria or archaea."
        )
        warnings.append(
            "if biomni-gget exists without gget, repair its SOCKS-capable pip path with `conda install -n "
            "biomni-gget -y -c conda-forge pysocks`, then run `conda run -n biomni-gget "
            '--no-capture-output python -m pip install --upgrade "gget>=0.30.3,<0.31"`.'
        )
    else:
        unsupported = sorted(set(selected_assets) - set(_NCBI_ASSET_MAP))
        if unsupported:
            raise ValueError(f"NCBI Datasets mapping is not defined for assets: {', '.join(unsupported)}")
    filters = (
        f"reference_only={reference_only!r}, assembly_level={assembly_level!r}, "
        f"annotated={annotated!r}, max_assemblies={max(1, int(max_assemblies))!r}"
    )
    call = (
        "download_reference_genome("
        f"identifier={identifier!r}, assets={','.join(selected_assets)!r}, release={release!r}, "
        f"source={selected_source!r}, {filters}, "
        f"db_root={str(Path(db_root).expanduser().resolve())!r}, approved=True)"
        if db_root
        else "download_reference_genome("
        f"identifier={identifier!r}, assets={','.join(selected_assets)!r}, release={release!r}, "
        f"source={selected_source!r}, {filters}, approved=True)"
    )
    return "\n".join(
        [
            "# Reference genome acquisition proposal",
            "[MICROBIOME_DB_ACQUISITION:reference-genomes]",
            f"- identifier: {identifier}",
            f"- selected source: {selected_source}",
            f"- assets: {', '.join(selected_assets)}",
            f"- release: {release or 'current at acquisition time'}",
            f"- target: {target}",
            "- gget advantage: concise Ensembl release-aware DNA/GTF/cDNA/CDS/peptide retrieval for eukaryotic references.",
            "- gget limitation: no bacterial reference genomes; upstream Ensembl schema and current-release content can change, so pin a release when reproducibility matters.",
            "- NCBI Datasets advantage: structured RefSeq/GenBank packages and assembly-accession precision, including bacteria and archaea.",
            "- NCBI Datasets limitation: asset names/package layout differ from Ensembl and a broad taxon query can retrieve many assemblies.",
            *[f"- warning: {warning}" for warning in warnings],
            "- tip: resolve bacterial or archaeal species names to a RefSeq accession first with "
            "resolve_reference_genome_accessions('<name>'), then pin that accession in this plan.",
            f"- confirmed execution call: `{call}`",
            "- localization: retain source package/files, write release-manifest.yaml, then verify every requested file is non-empty before pilot use.",
        ]
    )


def download_reference_genome(
    identifier: str,
    assets: str | list[str] = "dna,gtf",
    release: int | None = None,
    source: str = "auto",
    db_root: str | None = None,
    approved: bool = False,
    reference_only: bool = True,
    assembly_level: str | None = None,
    annotated: bool = False,
    max_assemblies: int = 25,
    timeout_seconds: int = 21600,
) -> str:
    """Download and register one explicitly approved reference genome."""
    if not approved:
        raise PermissionError(
            "reference download requires a confirmed plan containing "
            "[MICROBIOME_DB_ACQUISITION:reference-genomes] and approved=True"
        )
    selected_source = _choose_source(identifier, source)
    selected_assets = _asset_list(assets)
    root = Path(db_root or DEFAULT_DB_ROOT).expanduser().resolve() / REFERENCE_FOLDER
    target = root / _slug(f"{selected_source}-{identifier}-r{release or 'current'}")
    target.mkdir(parents=True, exist_ok=True)
    manager_path = shutil.which("conda") or shutil.which("mamba") or shutil.which("micromamba")
    if not manager_path:
        raise RuntimeError("conda, mamba, or micromamba is required for reference acquisition")
    manager = Path(manager_path).name
    repair_commands = _ensure_download_software(manager, selected_source)

    if selected_source == "gget":
        unsupported = sorted(set(selected_assets) - _GGET_ASSETS)
        if unsupported:
            raise ValueError(f"gget ref does not support assets: {', '.join(unsupported)}")
        command = [
            manager,
            "run",
            "-n",
            "biomni-gget",
            "--no-capture-output",
            "gget",
            "ref",
            "-w",
            ",".join(selected_assets),
        ]
        if release is not None:
            command.extend(["-r", str(release)])
        command.extend(["-d", "-od", str(target), identifier])
    else:
        includes = []
        for asset in selected_assets:
            if asset not in _NCBI_ASSET_MAP:
                raise ValueError(f"NCBI Datasets mapping is not defined for asset: {asset}")
            includes.append(_NCBI_ASSET_MAP[asset])
        package = target / "ncbi_dataset.zip"
        object_type = "accession" if _ASSEMBLY_ACCESSION.fullmatch(identifier.strip()) else "taxon"
        preflight_assemblies = None
        if object_type == "taxon":
            summaries = _datasets_summary_records(
                manager,
                "taxon",
                identifier,
                reference_only=reference_only,
                assembly_level=assembly_level,
                annotated=annotated,
                timeout_seconds=min(timeout_seconds, 900),
            )
            preflight_assemblies = len(summaries)
            if preflight_assemblies == 0:
                raise RuntimeError(
                    f"NCBI Datasets resolved no assemblies for taxon {identifier!r} with the requested "
                    "filters; relax the filters or pin an accession with resolve_reference_genome_accessions()"
                )
            if preflight_assemblies > max(1, int(max_assemblies)):
                raise RuntimeError(
                    f"taxon {identifier!r} resolves to {preflight_assemblies} assemblies "
                    f"(> {max(1, int(max_assemblies))}); narrow the query or pin one accession with "
                    "resolve_reference_genome_accessions() before downloading"
                )
        command = [
            manager,
            "run",
            "-n",
            "biomni-ncbi-datasets",
            "--no-capture-output",
            "datasets",
            "download",
            "genome",
            object_type,
            identifier,
            "--include",
            ",".join(dict.fromkeys(includes)),
            "--filename",
            str(package),
        ]
        if object_type == "taxon":
            if reference_only:
                command.append("--reference")
            if assembly_level:
                command.extend(["--assembly-level", assembly_level])
            if annotated:
                command.append("--annotated")

    from microbiome.download_utils import run_download_command

    result = run_download_command(
        command,
        watch_paths=[target],
        timeout_seconds=timeout_seconds,
        desc=f"下载参考基因组 {identifier}（{selected_source}） / Download reference genome {identifier} ({selected_source})",
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"reference download failed (exit {result.returncode}):\n{(result.stderr or result.stdout)[-4000:]}"
        )
    if selected_source == "ncbi-datasets":
        package = target / "ncbi_dataset.zip"
        if not package.is_file() or package.stat().st_size == 0:
            raise RuntimeError("NCBI Datasets reported success but the ZIP package is missing or empty")
        _extract_zip_safely(package, target)

    data_files = [
        path
        for path in sorted(target.rglob("*"))
        if path.is_file() and path.name != "release-manifest.yaml" and path.stat().st_size > 0
    ]
    sequence_or_annotation = [
        path
        for path in data_files
        if any(
            path.name.lower().endswith(suffix)
            for suffix in (
                ".fa",
                ".fna",
                ".fasta",
                ".fa.gz",
                ".fna.gz",
                ".fasta.gz",
                ".gtf",
                ".gtf.gz",
                ".gff",
                ".gff3",
                ".gff.gz",
                ".gff3.gz",
            )
        )
    ]
    if not sequence_or_annotation:
        raise RuntimeError("download completed but no non-empty sequence, annotation, or package file was found")
    manifest = {
        "identifier": identifier,
        "source": selected_source,
        "release": release,
        "assets": selected_assets,
        "acquired_at": datetime.now(UTC).isoformat(),
        "target": str(target),
        "command": shlex.join(command),
        "repair_commands": repair_commands,
        "files": [{"path": str(path.relative_to(target)), "bytes": path.stat().st_size} for path in data_files],
    }
    if selected_source == "ncbi-datasets":
        manifest["filters"] = {
            "object_type": object_type,
            "reference_only": reference_only,
            "assembly_level": assembly_level,
            "annotated": annotated,
            "preflight_assemblies": preflight_assemblies,
        }
    manifest_path = target / "release-manifest.yaml"
    manifest_path.write_text(yaml.safe_dump(manifest, sort_keys=False), encoding="utf-8")
    return json.dumps(
        {
            "status": "READY",
            "source": selected_source,
            "target": str(target),
            "manifest": str(manifest_path),
            "files": len(data_files),
            "command": shlex.join(command),
            "repair_commands": repair_commands,
        },
        ensure_ascii=False,
        indent=2,
    )


VIRUS_FOLDER = "virus-genomes"
ROTAVIRUS_SEGMENTS = ("VP1", "VP2", "VP3", "VP4", "VP6", "VP7", "NSP1", "NSP2", "NSP3", "NSP4", "NSP5")
_GGET_REPAIR_SPEC = "gget>=0.30.3,<0.31"
_NCBI_VIRUS_PACKAGE = "ncbi_virus_dataset.zip"
_METADATA_ACCESSION_FIELDS = (
    "accession",
    "accession_version",
    "nuccore_accession",
    "nucleotide_accession",
    "genbank_accession",
)
_METADATA_ISOLATE_FIELDS = ("isolate", "isolate_name", "strain")
_METADATA_SEGMENT_FIELDS = ("segment", "segment_name", "gene")
_METADATA_COMPLETENESS_FIELDS = ("nuc_completeness", "completeness", "nucleotide_completeness")


def _accession_list(accessions: str | list[str] | None) -> list[str]:
    """Normalize one or many accessions into a de-duplicated list."""
    if accessions is None:
        return []
    values = accessions.split(",") if isinstance(accessions, str) else list(accessions)
    return list(dict.fromkeys(value.strip() for value in values if value and value.strip()))


def _virus_filters(
    host: str | None,
    nuc_completeness: str | None,
    segment: str | None,
    source_database: str | None,
    min_date: str | None,
    max_date: str | None,
    min_length: int | str | None,
    max_length: int | str | None,
    annotated: bool,
) -> dict[str, object]:
    """Collect the explicit virus query filters shared by planning and execution."""
    filters: dict[str, object] = {}
    for key, value in (
        ("host", host),
        ("nuc_completeness", nuc_completeness),
        ("segment", segment),
        ("source_database", source_database),
        ("min_date", min_date),
        ("max_date", max_date),
    ):
        if value and str(value).strip():
            filters[key] = str(value).strip()
    for key, value in (("min_length", min_length), ("max_length", max_length)):
        if value is not None and str(value).strip():
            filters[key] = int(value)
    if annotated:
        filters["annotated"] = True
    return filters


def _expected_virus_segments(virus: str, expected_segments: str | list[str] | None) -> list[str]:
    if expected_segments:
        return _accession_list(expected_segments)
    if "rotavirus" in (virus or "").lower():
        return list(ROTAVIRUS_SEGMENTS)
    return []


def _virus_target_slug(source: str, virus: str, accessions: list[str], filters: dict[str, object]) -> str:
    identity = _slug(virus) if virus else f"acc-{_slug(accessions[0])}"
    tag_values = [str(value) for key, value in filters.items() if key != "annotated"]
    tag = _slug("-".join(tag_values)) if tag_values else "all-records"
    stamp = datetime.now(UTC).strftime("%Y%m%d")
    return f"{source}-{identity}-{tag}-{stamp}"


def _conda_manager() -> str:
    return shutil.which("conda") or shutil.which("mamba") or shutil.which("micromamba") or "conda"


def _conda_run_prefix(manager: str, environment: str) -> list[str]:
    return [manager, "run", "-n", environment, "--no-capture-output"]


def _probe_download_software(manager: str, source: str) -> tuple[bool, str]:
    """Check that the downloader executable answers inside its isolated environment."""
    if source == "gget":
        probe = [*_conda_run_prefix(manager, "biomni-gget"), "gget", "virus", "--help"]
    else:
        probe = [*_conda_run_prefix(manager, "biomni-ncbi-datasets"), "datasets", "--version"]
    try:
        result = subprocess.run(probe, capture_output=True, text=True, check=False, timeout=300)
    except (OSError, subprocess.SubprocessError) as exc:
        return False, str(exc)
    output = f"{result.stdout}\n{result.stderr}".strip()
    return result.returncode == 0, output[-2000:]


def _repair_command(manager: str, source: str) -> list[str]:
    """In-place repair for an existing downloader environment that lost its executable."""
    if source == "gget":
        return [
            *_conda_run_prefix(manager, "biomni-gget"),
            "python",
            "-m",
            "pip",
            "install",
            "--upgrade",
            _GGET_REPAIR_SPEC,
        ]
    return [manager, "install", "-n", "biomni-ncbi-datasets", "-y", "-c", "conda-forge", "ncbi-datasets-cli"]


def _repair_commands(manager: str, source: str) -> list[list[str]]:
    """Return ordered repairs, including pip's SOCKS transport prerequisite for gget."""
    if source == "gget":
        return [
            [manager, "install", "-n", "biomni-gget", "-y", "-c", "conda-forge", "pysocks"],
            _repair_command(manager, source),
        ]
    return [_repair_command(manager, source)]


def _ensure_download_software(manager: str, source: str, timeout_seconds: int = 3600) -> list[str]:
    """Probe the downloader environment and run the declared repair only when the probe fails."""
    ready, _detail = _probe_download_software(manager, source)
    if ready:
        return []
    repairs = _repair_commands(manager, source)
    completed_repairs = []
    for repair in repairs:
        try:
            result = subprocess.run(repair, capture_output=True, text=True, check=False, timeout=timeout_seconds)
        except (OSError, subprocess.SubprocessError) as exc:
            raise RuntimeError(f"{source} environment repair failed to start: {exc}") from exc
        if result.returncode != 0:
            detail = (result.stderr or result.stdout or "")[-4000:]
            hint = (
                "\nThe gget environment inherits a SOCKS proxy. Ensure the preceding conda pysocks "
                "prerequisite succeeded before retrying pip."
                if source == "gget"
                else ""
            )
            raise RuntimeError(
                f"{source} environment repair failed with exit code {result.returncode}:\n{detail}{hint}"
            )
        completed_repairs.append(shlex.join(repair))
    ready, detail = _probe_download_software(manager, source)
    if not ready:
        raise RuntimeError(f"{source} executable is still unavailable after the in-place repair:\n{detail}")
    return completed_repairs


def _gget_virus_command(
    manager: str,
    virus: str,
    accessions: list[str],
    filters: dict[str, object],
    target: Path,
) -> list[str]:
    command = [*_conda_run_prefix(manager, "biomni-gget"), "gget", "virus"]
    for key in ("nuc_completeness", "host", "segment", "source_database"):
        if filters.get(key):
            command += [f"--{key}", str(filters[key])]
    for key, flag in (
        ("min_date", "--min_release_date"),
        ("max_date", "--max_release_date"),
        ("min_length", "--min_seq_length"),
        ("max_length", "--max_seq_length"),
    ):
        if filters.get(key) is not None:
            command += [flag, str(filters[key])]
    if "annotated" in filters:
        command += ["--annotated", str(bool(filters["annotated"])).lower()]
    command += ["-o", str(target)]
    if accessions:
        command += ["--is_accession", *accessions]
    else:
        command.append(virus)
    return command


def _ncbi_virus_command(
    manager: str,
    virus: str,
    accessions: list[str],
    filters: dict[str, object],
    target: Path,
) -> tuple[list[str], list[str]]:
    warnings = []
    command = [
        *_conda_run_prefix(manager, "biomni-ncbi-datasets"),
        "datasets",
        "download",
        "virus",
        "genome",
    ]
    if accessions:
        command += ["accession", ",".join(accessions)]
    else:
        command += ["taxon", virus]
    if str(filters.get("nuc_completeness", "")).lower() == "complete":
        command.append("--complete-only")
    if filters.get("host"):
        command += ["--host", str(filters["host"])]
    if filters.get("min_date"):
        command += ["--released-after", str(filters["min_date"])]
    unsupported_filters = [key for key in ("max_date", "min_length", "max_length") if filters.get(key) is not None]
    if unsupported_filters:
        raise ValueError(
            "NCBI Datasets does not support the requested virus filters in the installed CLI: "
            f"{', '.join(unsupported_filters)}; select source='gget' for these filters"
        )
    if filters.get("annotated"):
        command.append("--annotated")
    for unsupported in ("segment", "source_database"):
        if filters.get(unsupported):
            warnings.append(
                f"NCBI Datasets cannot apply the {unsupported} filter natively; "
                "it is enforced by post-download validation when the metadata provides the field."
            )
    command += ["--filename", str(target / _NCBI_VIRUS_PACKAGE)]
    return command, warnings


def inspect_local_virus_genomes(db_root: str | None = None, query: str = "") -> str:
    """List manifested local virus genome acquisitions before proposing any new transfer."""
    root = Path(db_root).expanduser().resolve() if db_root else DEFAULT_DB_ROOT
    folder = root / VIRUS_FOLDER
    if not folder.is_dir():
        return (
            f"No local virus genome collection exists at {folder}. "
            "Call plan_virus_genome_download(...) to draft the exact acquisition before any download."
        )
    rows = []
    query_terms = [term.lower() for term in query.split() if term.strip()]
    for manifest_path in sorted(folder.glob("*/release-manifest.yaml")):
        try:
            manifest = yaml.safe_load(manifest_path.read_text(encoding="utf-8")) or {}
        except (OSError, yaml.YAMLError):
            manifest = {}
        child = manifest_path.parent
        files = manifest.get("files") or []
        non_empty = sum(1 for item in files if int(item.get("bytes") or 0) > 0)
        validation = manifest.get("validation") or {}
        rows.append(
            {
                "id": child.name,
                "virus": manifest.get("virus"),
                "source": manifest.get("source"),
                "filters": manifest.get("filters") or {},
                "acquired_at": manifest.get("acquired_at"),
                "records": validation.get("records"),
                "strains": validation.get("strains"),
                "complete_strains": validation.get("complete_strains"),
                "files": f"{non_empty}/{len(files)} non-empty",
                "status": "READY" if files and non_empty == len(files) else "INCOMPLETE",
            }
        )
    if query_terms:
        rows = [row for row in rows if all(term in json.dumps(row).lower() for term in query_terms)]
    if not rows:
        return f"No manifested virus genome acquisitions matched under {folder} for query {query!r}."
    lines = [f"# Local virus genome acquisitions under {folder}"]
    for row in rows:
        lines.append(f"- `{row['id']}` [{row['status']}]")
        for key in ("virus", "source", "acquired_at", "records", "strains", "complete_strains", "files"):
            if row.get(key) is not None:
                lines.append(f"  - {key}: {row[key]}")
        lines.append(f"  - filters: {json.dumps(row['filters'], ensure_ascii=False)}")
    lines.append(
        "Reuse a READY child when its virus, filters and validation match; "
        "otherwise call plan_virus_genome_download(...) before any transfer."
    )
    return "\n".join(lines)


def plan_virus_genome_download(
    virus: str = "",
    accessions: str | list[str] | None = None,
    host: str | None = None,
    nuc_completeness: str | None = None,
    segment: str | None = None,
    source_database: str | None = None,
    min_date: str | None = None,
    max_date: str | None = None,
    min_length: int | str | None = None,
    max_length: int | str | None = None,
    annotated: bool = False,
    expected_segments: str | list[str] | None = None,
    require_complete_strains: bool = False,
    source: str = "auto",
    db_root: str | None = None,
) -> str:
    """Render the deterministic virus-genome acquisition proposal for the confirmed plan."""
    accession_values = _accession_list(accessions)
    virus = (virus or "").strip()
    if not virus and not accession_values:
        raise ValueError("Provide a virus name, TaxID, or one or more accessions before planning a download.")
    filters = _virus_filters(
        host, nuc_completeness, segment, source_database, min_date, max_date, min_length, max_length, annotated
    )
    source = source.lower().strip()
    if source not in {"auto", "gget", "ncbi-datasets"}:
        raise ValueError("source must be 'auto', 'gget', or 'ncbi-datasets'.")
    selected = "gget" if source == "auto" else source
    root = Path(db_root).expanduser().resolve() if db_root else DEFAULT_DB_ROOT
    target = root / VIRUS_FOLDER / _virus_target_slug(selected, virus, accession_values, filters)
    segments = _expected_virus_segments(virus, expected_segments)

    call_parts = []
    if virus:
        call_parts.append(f"virus={virus!r}")
    if accession_values:
        call_parts.append(f"accessions={accession_values!r}")
    for key in (
        "host",
        "nuc_completeness",
        "segment",
        "source_database",
        "min_date",
        "max_date",
        "min_length",
        "max_length",
    ):
        if key in filters:
            call_parts.append(f"{key}={filters[key]!r}")
    if filters.get("annotated"):
        call_parts.append("annotated=True")
    if segments:
        call_parts.append(f"expected_segments={segments!r}")
    if require_complete_strains:
        call_parts.append("require_complete_strains=True")
    call_parts.append(f"source={selected!r}")
    call_parts.append(f"db_root={str(root)!r}")
    call_parts.append("approved=True")
    confirmed_call = f"download_virus_genomes({', '.join(call_parts)})"
    fallback_source = "ncbi-datasets" if selected == "gget" else "gget"
    fallback_call = confirmed_call.replace(f"source={selected!r}", f"source={fallback_source!r}")

    return f"""# Virus genome acquisition proposal
[MICROBIOME_DB_ACQUISITION:virus-genomes]

- virus: {virus or "(accessions only)"}
- accessions: {", ".join(accession_values) or "(none)"}
- filters: {json.dumps(filters, ensure_ascii=False)}
- expected segments: {", ".join(segments) or "(segmented-strain validation disabled)"}
- require complete strains: {require_complete_strains}
- selected source: {selected}
- target: {target}
- gget advantage: native NCBI Virus completeness, host, segment, source-database, date and length filters; \
emits FASTA, CSV, JSONL and a command summary.
- gget limitation: requires a working {_GGET_REPAIR_SPEC} executable inside the existing biomni-gget environment.
- NCBI Datasets advantage: official accession-list downloads with --complete-only, host and lower release-date \
filtering inside the biomni-ncbi-datasets environment.
- NCBI Datasets limitation: the installed CLI has no upper release-date or sequence-length filters and no native \
segment/source-database filter; select gget when those filters are required.
- environment repair (run only when the executable probe fails; never recreate the same-named environment): \
`conda install -n biomni-gget -y -c conda-forge pysocks` then \
`conda run -n biomni-gget --no-capture-output python -m pip install --upgrade "{_GGET_REPAIR_SPEC}"`
- confirmed execution call: `{confirmed_call}`
- fallback if the selected upstream fails after one retry: `{fallback_call}`
- validation: non-empty FASTA/CSV/JSONL/command summary, FASTA accessions match metadata records, every record \
satisfies the requested nuc_completeness, isolate and segment fields preserved, and a per-isolate \
segment-completeness report distinguishes complete segment records from strains carrying every expected segment.
- size: depends on taxon breadth and filters; verify disk headroom in preflight before approval.
- note: new database acquisition is allowed only during pilot preparation, never during the full run.
"""


def download_virus_genomes(
    virus: str = "",
    accessions: str | list[str] | None = None,
    host: str | None = None,
    nuc_completeness: str | None = None,
    segment: str | None = None,
    source_database: str | None = None,
    min_date: str | None = None,
    max_date: str | None = None,
    min_length: int | str | None = None,
    max_length: int | str | None = None,
    annotated: bool = False,
    expected_segments: str | list[str] | None = None,
    require_complete_strains: bool = False,
    source: str = "auto",
    db_root: str | None = None,
    approved: bool = False,
    timeout_seconds: int = 21600,
) -> str:
    """Download one filter-pinned virus genome package into Database/virus-genomes/ after plan approval."""
    if not approved:
        raise PermissionError(
            "Virus genome downloads require explicit approval. Plan first with plan_virus_genome_download(...), "
            "keep the [MICROBIOME_DB_ACQUISITION:virus-genomes] marker in the confirmed plan, then rerun with approved=True."
        )
    accession_values = _accession_list(accessions)
    virus = (virus or "").strip()
    if not virus and not accession_values:
        raise ValueError("Provide a virus name, TaxID, or one or more accessions.")
    filters = _virus_filters(
        host, nuc_completeness, segment, source_database, min_date, max_date, min_length, max_length, annotated
    )
    source = source.lower().strip()
    if source not in {"auto", "gget", "ncbi-datasets"}:
        raise ValueError("source must be 'auto', 'gget', or 'ncbi-datasets'.")
    selected = "gget" if source == "auto" else source
    root = Path(db_root).expanduser().resolve() if db_root else DEFAULT_DB_ROOT
    target = root / VIRUS_FOLDER / _virus_target_slug(selected, virus, accession_values, filters)
    if target.exists() and any(target.iterdir()):
        raise FileExistsError(
            f"{target} already exists. Reuse it via inspect_local_virus_genomes() or plan a new dated acquisition."
        )
    target.mkdir(parents=True, exist_ok=True)

    manager = _conda_manager()
    repair_commands = _ensure_download_software(manager, selected)
    if selected == "gget":
        command = _gget_virus_command(manager, virus, accession_values, filters, target)
        source_warnings: list[str] = []
    else:
        command, source_warnings = _ncbi_virus_command(manager, virus, accession_values, filters, target)

    started = datetime.now(UTC)
    from microbiome.download_utils import run_download_command

    result = run_download_command(
        command,
        watch_paths=[target],
        timeout_seconds=timeout_seconds,
        desc=f"下载病毒基因组 {virus or ','.join(accession_values)}（{selected}） / Download virus genomes {virus or ','.join(accession_values)} ({selected})",
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"{selected} virus download failed with exit code {result.returncode}:\n"
            f"{(result.stderr or result.stdout or '')[-4000:]}"
        )
    if selected == "ncbi-datasets":
        _extract_zip_safely(target / _NCBI_VIRUS_PACKAGE, target)

    validation = _validate_virus_package(
        target,
        filters=filters,
        expected_segments=_expected_virus_segments(virus, expected_segments),
        require_complete_strains=require_complete_strains,
        source=selected,
    )

    files = []
    for path in sorted(target.rglob("*")):
        if path.is_file() and path.name != "release-manifest.yaml":
            files.append({"path": str(path.relative_to(target)), "bytes": path.stat().st_size})
    warnings = [*source_warnings, *validation.get("warnings", [])]
    manifest = {
        "virus": virus or None,
        "accessions": accession_values,
        "source": selected,
        "filters": filters,
        "acquired_at": started.isoformat(),
        "command": shlex.join(command),
        "repair_commands": repair_commands,
        "target": str(target),
        "files": files,
        "validation": validation,
        "warnings": warnings,
    }
    manifest_path = target / "release-manifest.yaml"
    manifest_path.write_text(yaml.safe_dump(manifest, sort_keys=False), encoding="utf-8")
    return json.dumps(
        {
            "status": "READY",
            "target": str(target),
            "manifest": str(manifest_path),
            "source": selected,
            "command": shlex.join(command),
            "repair_commands": repair_commands,
            "file_count": len(files),
            "validation": {key: value for key, value in validation.items() if key != "warnings"},
            "warnings": warnings,
        },
        ensure_ascii=False,
        indent=2,
    )


def _fasta_id_to_accession(header_token: str) -> str:
    parts = header_token.split("|")
    if len(parts) >= 3 and parts[0] in {"gi", "gb", "emb", "dbj", "ref"}:
        return parts[-1] or parts[-2]
    return parts[0]


def _parse_fasta_accessions(path: Path) -> list[str]:
    accessions = []
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
        for line in handle:
            if not line.startswith(">"):
                continue
            token = line[1:].strip().split(maxsplit=1)
            if token:
                accessions.append(_fasta_id_to_accession(token[0]))
    return accessions


def _metadata_field(record: dict, fields: tuple[str, ...]) -> str:
    lowered = {str(key).lower(): value for key, value in record.items()}
    for field in fields:
        value = lowered.get(field)
        if value not in (None, ""):
            return str(value).strip()
    return ""


def _load_metadata_records(target: Path) -> list[dict]:
    """Parse CSV and JSONL acquisition metadata into flat record dictionaries."""
    records: list[dict] = []
    candidates = sorted(target.rglob("*.csv")) + sorted(target.rglob("*.jsonl"))
    for path in candidates:
        if not path.is_file() or path.stat().st_size == 0:
            continue
        try:
            if path.suffix == ".csv":
                with path.open(newline="", encoding="utf-8", errors="replace") as handle:
                    records.extend(dict(row) for row in csv.DictReader(handle))
            else:
                with path.open(encoding="utf-8", errors="replace") as handle:
                    for line in handle:
                        line = line.strip()
                        if not line:
                            continue
                        parsed = json.loads(line)
                        if isinstance(parsed, dict):
                            records.append(parsed)
        except (OSError, json.JSONDecodeError, csv.Error):
            continue
    return records


def _validate_virus_package(
    target: Path,
    filters: dict[str, object],
    expected_segments: list[str],
    require_complete_strains: bool,
    source: str,
) -> dict:
    """Validate FASTA/metadata consistency and per-isolate segment completeness after transfer."""
    fasta_files = sorted(
        path
        for path in target.rglob("*")
        if path.is_file() and re.search(r"\.(?:fa|fna|fasta)(?:\.gz)?$", path.name, re.IGNORECASE)
    )
    if not fasta_files:
        raise RuntimeError(f"Virus download produced no FASTA files under {target}.")
    fasta_accessions: list[str] = []
    for path in fasta_files:
        if path.stat().st_size == 0:
            raise RuntimeError(f"Empty FASTA file: {path}")
        fasta_accessions.extend(_parse_fasta_accessions(path))
    if not fasta_accessions:
        raise RuntimeError(f"Virus FASTA files under {target} contain no records.")

    csv_files = sorted(path for path in target.rglob("*.csv") if path.is_file())
    jsonl_files = sorted(path for path in target.rglob("*.jsonl") if path.is_file())
    if source == "gget":
        for group, label in ((csv_files, "CSV metadata"), (jsonl_files, "JSONL metadata")):
            if not group or all(path.stat().st_size == 0 for path in group):
                raise RuntimeError(f"gget virus download is missing non-empty {label} under {target}.")
        summaries = [path for path in target.rglob("*") if path.is_file() and "command_summary" in path.name]
        if not summaries or all(path.stat().st_size == 0 for path in summaries):
            raise RuntimeError(f"gget virus download is missing a non-empty command summary under {target}.")

    metadata = _load_metadata_records(target)
    if not metadata:
        raise RuntimeError(f"Virus download produced no parseable metadata records under {target}.")

    warnings: list[str] = []
    meta_rows = [
        {
            "accession": _metadata_field(record, _METADATA_ACCESSION_FIELDS),
            "isolate": _metadata_field(record, _METADATA_ISOLATE_FIELDS),
            "segment": _metadata_field(record, _METADATA_SEGMENT_FIELDS),
            "completeness": _metadata_field(record, _METADATA_COMPLETENESS_FIELDS),
        }
        for record in metadata
    ]
    meta_accessions = {row["accession"] for row in meta_rows if row["accession"]}
    if meta_accessions:
        missing = [accession for accession in dict.fromkeys(fasta_accessions) if accession not in meta_accessions]
        if missing:
            raise RuntimeError(
                f"FASTA accessions missing from metadata records ({len(missing)}): {', '.join(missing[:10])}"
            )
    else:
        warnings.append("Metadata has no recognizable accession column; FASTA/metadata consistency is unverified.")

    if str(filters.get("nuc_completeness", "")).lower() == "complete":
        completeness_values = [row["completeness"] for row in meta_rows if row["completeness"]]
        if completeness_values:
            incomplete = [
                row["accession"] or "(unknown accession)"
                for row in meta_rows
                if row["completeness"] and row["completeness"].lower() != "complete"
            ]
            if incomplete:
                raise RuntimeError(
                    f"{len(incomplete)} records are not complete although nuc_completeness='complete' "
                    f"was requested: {', '.join(incomplete[:10])}"
                )
        else:
            warnings.append(
                "Metadata has no completeness column; the nuc_completeness filter could not be re-verified."
            )

    if filters.get("segment"):
        wanted = str(filters["segment"]).lower()
        segment_values = [row["segment"] for row in meta_rows if row["segment"]]
        if segment_values and not any(wanted in value.lower() for value in segment_values):
            raise RuntimeError(f"No metadata record matches the requested segment {filters['segment']!r}.")

    isolates: dict[str, set[str]] = {}
    for row in meta_rows:
        if row["isolate"] and row["segment"]:
            isolates.setdefault(row["isolate"], set()).add(row["segment"])

    complete_strains: int | None = None
    missing_by_isolate: dict[str, list[str]] = {}
    report_path: Path | None = None
    if expected_segments and isolates:
        expected_upper = {segment.upper() for segment in expected_segments}
        complete_strains = 0
        report_rows = []
        for isolate, segments in sorted(isolates.items()):
            present = {segment.upper() for segment in segments}
            missing = sorted(expected_upper - present)
            if missing:
                missing_by_isolate[isolate] = missing
            else:
                complete_strains += 1
            report_rows.append(
                (
                    isolate,
                    len(present & expected_upper),
                    len(expected_upper),
                    ",".join(missing) or "-",
                    "no" if missing else "yes",
                )
            )
        report_path = target / "segment-completeness-report.tsv"
        with report_path.open("w", encoding="utf-8") as handle:
            handle.write("isolate\tsegments_found\tsegments_expected\tmissing_segments\tcomplete_strain\n")
            for row in report_rows:
                handle.write("\t".join(map(str, row)) + "\n")
        if require_complete_strains and complete_strains == 0:
            raise RuntimeError(f"No isolate carries all {len(expected_upper)} expected segments; see {report_path}.")
    elif expected_segments:
        warnings.append(
            "Expected segments were configured but the metadata lacks isolate/segment fields; "
            "per-strain completeness could not be evaluated."
        )
        if require_complete_strains:
            raise RuntimeError(
                "Complete strains were required but the metadata lacks isolate/segment fields to prove them."
            )

    return {
        "records": len(fasta_accessions),
        "metadata_records": len(meta_rows),
        "fasta_files": len(fasta_files),
        "strains": len(isolates),
        "complete_strains": complete_strains,
        "missing_segments": missing_by_isolate or None,
        "segment_report": str(report_path) if report_path else None,
        "warnings": warnings,
    }
