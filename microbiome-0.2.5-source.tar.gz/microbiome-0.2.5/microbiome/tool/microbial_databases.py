"""Microbial database downloaders for Microbiome (idempotent, with localization).

Design rules (from user feedback):
- **Idempotent**: if the target file/db already exists and is non-empty, skip the download.
- **Size check**: when the server reports a Content-Length, compare and re-download if
  the local file size differs (incomplete/stale).
- **Correct sources**: prefer the tool's own `download-database` command (geNomad, CheckV,
  Bakta) since their URLs change; only hard-code stable direct links (UniProt Swiss-Prot).
- **Localization**: after download, build the on-disk format the tool expects
  (e.g. DIAMOND `.dmnd` for Swiss-Prot; note for BLAST dbs).
"""

import os
import subprocess
from pathlib import Path

import requests

from microbiome.tool.metagenomics import DEFAULT_ENV as _DEFAULT_ENV
from microbiome.tool.metagenomics import _cli, _env_prefix, _find_cli, _install_hint

# Unified root for all databases: the fixed `Database/` folder at the project root
# (anchored to this file's location, independent of the caller's CWD), so every tool
# finds DBs at one stable place. Override globally via env MICROBIOME_DB_ROOT, or per-call
# with `out_dir`.
_PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
DEFAULT_DB_ROOT = os.environ.get("MICROBIOME_DB_ROOT", os.path.join(_PROJECT_ROOT, "Database"))

# Stable direct-download links (verified reachable via curl HEAD 200). Only these are hard-coded.
_DB_URLS = {
    "swissprot": "https://ftp.uniprot.org/pub/databases/uniprot/current_release/knowledgebase/complete/uniprot_sprot.fasta.gz",
    "checkm": "https://data.ace.uq.edu.au/public/CheckM_databases/checkm_data_2015_01_16.tar.gz",
    "card": "https://card.mcmaster.ca/download/0/broadstreet-v3.3.0.tar.bz2",
}

# COG2020: several files under one NCBI FTP dir (all verified reachable).
_COG_BASE = "https://ftp.ncbi.nih.gov/pub/COG/COG2020/data/"
_COG_FILES = ["cog-20.fa.gz", "cog-20.cog.csv", "cog-20.def.tab"]

# GTDB-Tk reference data: verified reachable but ~61 GB -> verify + guide only.
_GTDBTK_URL = "https://data.gtdb.ecogenomic.org/releases/latest/auxillary_files/gtdbtk_package/full_package/gtdbtk_data.tar.gz"


def _download_env():
    """Env for DB downloads that works with AND without a network proxy.

    auto 探测（microbiome.proxy_config）：直连可用则清空代理变量（避免损坏的代理
    让 geNomad 等 urllib 下载器报 503）；直连不可达而代理可用则使用归一化后的
    代理。MICROBIOME_PROXY_MODE=direct/proxy 可强制指定通道。
    Auto detection (microbiome.proxy_config): when a direct connection works, proxy
    variables are cleared (so a broken proxy cannot make urllib-based downloaders
    such as geNomad return 503); when the direct connection is unreachable but a
    proxy works, the normalized proxy is used. MICROBIOME_PROXY_MODE=direct/proxy
    forces the channel explicitly.
    """
    from microbiome.proxy_config import download_env

    return download_env()


def _remote_size(url):
    try:
        r = requests.head(url, allow_redirects=True, timeout=30)
        return int(r.headers.get("Content-Length", 0))
    except Exception:
        return 0


def _stream_download(url, dest, log, min_bytes=1000):
    """Download url->dest with live speed/progress, stall-retry and Range resume.

    显示实时网速与进度；停滞自动重试；中断后从 .part 断点续传。
    Displays live network speed and progress; automatically retries on stalls;
    resumes from the .part checkpoint after an interruption.
    Returns True on success. Skips if dest already matches remote size."""
    remote = _remote_size(url)
    if os.path.exists(dest):
        local = os.path.getsize(dest)
        if local >= min_bytes and (remote == 0 or local == remote):
            log.append(f"- already present & size OK ({local} bytes): {dest}")
            return True
        log.append(f"- re-downloading (local {local} != remote {remote}): {dest}")
    log.append(f"$ GET {url}")
    from microbiome.download_utils import download_file

    try:
        download_file(url, dest, expected_size=remote or None, min_bytes=min_bytes, log=log.append)
    except RuntimeError as e:
        log.append(f"- download error: {e}")
        return False
    return os.path.exists(dest) and os.path.getsize(dest) >= min_bytes


def _dir_nonempty(d):
    return os.path.isdir(d) and any(os.scandir(d))


def _run_with_retry(cmd, env, log, attempts=3, watch=None):
    """Run a download command with live progress, stall watchdog and retries.

    实时转发工具自身的进度输出；停滞（无网速/无字节增长）自动终止并重试；
    非零退出仅对瞬态上游错误（如 NERSC 503/超时）重试。Returns the last result.
    Forwards the tool's own progress output in real time; kills and retries on
    stalls (no speed or byte growth); non-zero exits are retried only for
    transient upstream errors (e.g. NERSC 503/timeout).
    """
    from microbiome.download_utils import run_download_command

    res = run_download_command(cmd, watch_paths=watch, env=env, max_retries=attempts, log=log.append)
    if res.returncode == 0:
        log.append("- download succeeded")
    return res


def _extract_tarball(archive, dest_dir, log):
    """Extract a .tar.gz/.tar.bz2 into dest_dir (idempotent marker). Returns True on success."""
    import tarfile

    marker = os.path.join(dest_dir, ".extracted_ok")
    if os.path.exists(marker):
        log.append(f"- already extracted (marker present): {dest_dir}")
        return True
    try:
        with tarfile.open(archive, "r:*") as tf:
            destination = Path(dest_dir).resolve()
            for member in tf.getmembers():
                target = (destination / member.name).resolve()
                if destination not in target.parents and target != destination:
                    raise ValueError(f"unsafe archive path: {member.name}")
                if member.issym() or member.islnk():
                    raise ValueError(f"archive links are not accepted: {member.name}")
            tf.extractall(dest_dir)
    except Exception as e:
        log.append(f"- extraction FAILED: {e}")
        return False
    open(marker, "w").write("ok\n")
    log.append(f"- extracted: {archive} -> {dest_dir}")
    return True


def download_database(name, out_dir=None, env=None, build_dmnd=True):
    """Download (idempotently) and localize a microbial database.

    Supported names:
      Direct download (stable links, verified reachable):
      - swissprot : UniProt Swiss-Prot proteins -> .fasta.gz (+ optional diamond .dmnd)
      - checkm    : CheckM reference data tarball -> extracted, sets CHECKM_DATA_PATH
      - card      : CARD broadstreet tarball -> extracted, then `rgi load` to localize
      - cog       : COG2020 (NCBI FTP): proteins .fa.gz + mapping csv/def (+ optional .dmnd)
      Tool-wrapped (their URLs change):
      - genomad   : geNomad database via `genomad download-database`
      - checkv    : CheckV database via `checkv download_database`
      - bakta     : Bakta database via `bakta_db download`
      Verify-link + guide (very large / license / registration):
      - gtdbtk    : GTDB-Tk reference data (~61 GB) -> link check + manual guide (GTDBTK_DATA_PATH)
      - kegg      : KEGG needs a license -> guide (KEGG API / DIAMOND build)
      - tcdb      : TCDB needs subscription -> manual guide
      - kraken2   : instructions to build/download (large)
      - dbcan, eggnog : point to manual download

    Parameters
    ----------
    name : str
        Database name.
    out_dir : str, optional
        Parent directory for databases. Defaults to DEFAULT_DB_ROOT (env MICROBIOME_DB_ROOT
        or "databases"), a fixed folder so tools find DBs at a stable path.
    env : str, optional
        Conda env for tool-wrapped downloads (default microbiome env).
    build_dmnd : bool, optional
        For swissprot/cog, also run `diamond makedb` to produce a .dmnd (default True).

    Returns
    -------
    str
        Research log with status, path and config hints.
    """
    if env is None:
        env = _DEFAULT_ENV
    if out_dir is None:
        out_dir = DEFAULT_DB_ROOT
    name = name.lower()
    dest_dir = os.path.join(out_dir, name)
    os.makedirs(dest_dir, exist_ok=True)
    log = ["# Database Download", f"- name: {name}", f"- dest: {dest_dir}\n"]

    # ---- tool-wrapped downloaders (preferred; their URLs change) ----
    if name == "genomad":
        if _dir_nonempty(dest_dir):
            log.append(f"## SKIP\ngeNomad DB already present: {dest_dir}")
            return "\n".join(log)
        if _find_cli("genomad", env) is None:
            log.append("## ERROR\n" + _install_hint("genomad"))
            return "\n".join(log)
        cmd = _cli("genomad", env) + ["download-database", dest_dir]
        res = _run_with_retry(cmd, _download_env(), log, watch=[dest_dir])
        log.append(f"$ {' '.join(cmd)}")
        log.append("## Results")
        log.append(f"- {'Downloaded' if res.returncode == 0 else 'FAILED (upstream NERSC may be temporarily down; retry later)'}: {dest_dir}")
        log.append(f"- Set: export GENOMAD_DB={os.path.abspath(dest_dir)}/genomad_db")
        if res.returncode != 0:
            log.append("```\n" + (res.stdout or "")[-1500:] + (res.stderr or "")[-1500:] + "\n```")
        return "\n".join(log)

    if name == "checkv":
        if _dir_nonempty(dest_dir):
            log.append(f"## SKIP\nCheckV DB already present: {dest_dir}")
            return "\n".join(log)
        if _find_cli("checkv", env) is None:
            log.append("## ERROR\n" + _install_hint("checkv"))
            return "\n".join(log)
        cmd = _env_prefix(env) + ["bash", "-lc", f"checkv download_database {dest_dir}"]
        res = _run_with_retry(cmd, _download_env(), log, watch=[dest_dir])
        log.append("$ " + " ".join(cmd))
        log.append("## Results")
        log.append(f"- {'Downloaded' if res.returncode == 0 else 'FAILED (upstream NERSC may be temporarily down; retry later)'}: {dest_dir}")
        log.append(f"- Set: export CHECKVDB={os.path.abspath(dest_dir)}/checkv-db-v1.5")
        if res.returncode != 0:
            log.append("```\n" + (res.stdout or "")[-1500:] + (res.stderr or "")[-1500:] + "\n```")
        return "\n".join(log)

    if name == "bakta":
        if _dir_nonempty(dest_dir):
            log.append(f"## SKIP\nBakta DB already present: {dest_dir}")
            return "\n".join(log)
        if _find_cli("bakta_db", env) is None and _find_cli("bakta", env) is None:
            log.append("## ERROR\n" + _install_hint("bakta"))
            return "\n".join(log)
        cmd = _env_prefix(env) + ["bash", "-lc", f"bakta_db download --output {dest_dir} --type light"]
        res = _run_with_retry(cmd, _download_env(), log, watch=[dest_dir])
        log.append("$ " + " ".join(cmd))
        log.append("## Results")
        log.append(f"- {'Downloaded' if res.returncode == 0 else 'FAILED'}: {dest_dir}")
        log.append(f"- Set: export BAKTA_DB={os.path.abspath(dest_dir)}/db-light")
        if res.returncode != 0:
            log.append("```\n" + (res.stdout or "")[-1500:] + (res.stderr or "")[-1500:] + "\n```")
        return "\n".join(log)

    # ---- checkm: direct tarball + extract -> CHECKM_DATA_PATH ----
    if name == "checkm":
        tarball = os.path.join(dest_dir, _DB_URLS["checkm"].rsplit("/", 1)[-1])
        data_dir = os.path.join(dest_dir, "checkm_data_2015_01_16")
        if os.path.isdir(data_dir) and _dir_nonempty(data_dir):
            log.append(f"## SKIP\nCheckM data already present: {data_dir}")
            log.append(f"- Set: export CHECKM_DATA_PATH={os.path.abspath(data_dir)}")
            return "\n".join(log)
        try:
            if not _stream_download(_DB_URLS["checkm"], tarball, log):
                log.append(f"## ERROR\nDownload failed/too small: {tarball}")
                return "\n".join(log)
        except Exception as e:
            log.append(f"## ERROR\nDownload failed: {e}")
            return "\n".join(log)
        if not _extract_tarball(tarball, dest_dir, log):
            log.append("## ERROR\nExtraction failed (archive may be incomplete); delete and retry.")
            return "\n".join(log)
        log.append("## Results")
        log.append(f"- CheckM data: {os.path.abspath(data_dir)}")
        log.append(f"- Set: export CHECKM_DATA_PATH={os.path.abspath(data_dir)}")
        log.append("- Or run: `checkm data setRoot " + os.path.abspath(data_dir) + "`")
        return "\n".join(log)

    # ---- card: direct tarball + extract + `rgi load` localization ----
    if name == "card":
        tarball = os.path.join(dest_dir, _DB_URLS["card"].rsplit("/", 1)[-1])
        try:
            if not _stream_download(_DB_URLS["card"], tarball, log):
                log.append(f"## ERROR\nDownload failed/too small: {tarball}")
                return "\n".join(log)
        except Exception as e:
            log.append(f"## ERROR\nDownload failed: {e}")
            return "\n".join(log)
        if not _extract_tarball(tarball, dest_dir, log):
            log.append("## ERROR\nExtraction failed (archive may be incomplete); delete and retry.")
            return "\n".join(log)
        log.append("## Results")
        log.append(f"- CARD data extracted under: {os.path.abspath(dest_dir)}")
        if _find_cli("rgi", env) is not None:
            log.append("- Localize with: `rgi load --card_json " + os.path.abspath(os.path.join(dest_dir, "card.json")) + " --local`")
        else:
            log.append("- NOTE: rgi not found; after installing rgi run `rgi load --card_json <card.json> --local` to build the local DB.")
        return "\n".join(log)

    # ---- cog: COG2020 multi-file direct download (+ optional .dmnd) ----
    if name == "cog":
        ok_all = True
        for fn in _COG_FILES:
            try:
                if not _stream_download(_COG_BASE + fn, os.path.join(dest_dir, fn), log):
                    ok_all = False
            except Exception as e:
                log.append(f"- download failed for {fn}: {e}")
                ok_all = False
        if not ok_all:
            log.append("## ERROR\nOne or more COG files failed; re-run to resume (idempotent).")
            return "\n".join(log)
        log.append("## Results")
        log.append(f"- COG2020 files under: {os.path.abspath(dest_dir)}")
        fa = os.path.join(dest_dir, "cog-20.fa.gz")
        if build_dmnd:
            dmnd = os.path.join(dest_dir, "cog.dmnd")
            if os.path.exists(dmnd):
                log.append(f"- DIAMOND db already present: {dmnd}")
            elif _find_cli("diamond", env) is None:
                log.append("- NOTE: diamond not found; build .dmnd later with `diamond makedb --in " + fa + " --db " + dmnd + "`")
            else:
                res = subprocess.run(
                    _cli("diamond", env) + ["makedb", "--in", fa, "--db", dmnd],
                    capture_output=True, text=True, check=False,
                )
                log.append(f"- DIAMOND db: {dmnd} ({'OK' if res.returncode == 0 else 'FAILED'})")
        return "\n".join(log)

    # ---- verify-link + guide: very large / license / registration ----
    if name == "gtdbtk":
        size = _remote_size(_GTDBTK_URL)
        reachable = "reachable (HTTP 200)" if size > 0 else "NOT reachable now (retry later)"
        log.append(
            "## NOTE\nGTDB-Tk reference data is very large (~61 GB). Link status: " + reachable + ".\n"
            f"- URL: {_GTDBTK_URL}  (reported size: {size} bytes)\n"
            "Download & set up manually:\n\n"
            f"```bash\nwget -c {_GTDBTK_URL} -P {os.path.abspath(dest_dir)}\n"
            f"tar -xzf {os.path.abspath(dest_dir)}/gtdbtk_data.tar.gz -C {os.path.abspath(dest_dir)}\n"
            f"export GTDBTK_DATA_PATH={os.path.abspath(dest_dir)}/<release_dir>\n```\n"
            "Or use `gtdbtk download` (tool-wrapped) if your gtdbtk version supports it."
        )
        return "\n".join(log)
    if name == "kegg":
        log.append(
            "## NOTE\nKEGG requires a paid license (no public bulk-download link).\n"
            "- Academic FTP: https://www.bioinformatics.jp/en/keggftp.html\n"
            "- Public REST API (per-record, not bulk): https://rest.kegg.jp\n"
            "- Recommended alternative: build a DIAMOND db from eggNOG/KOfam, e.g.\n"
            "  `diamond makedb --in kegg_prokaryotes.pep.gz --db kegg.dmnd` after obtaining KEGG proteins."
        )
        return "\n".join(log)
    if name == "tcdb":
        log.append(
            "## NOTE\nTCDB requires (free) registration/subscription to download.\n"
            "- Register & download: http://www.tcdb.org/download.php\n"
            "- After downloading tcdb.fasta, build: `diamond makedb --in tcdb.fasta --db tcdb.dmnd`\n"
            f"- Place files under: {os.path.abspath(dest_dir)}"
        )
        return "\n".join(log)

    # ---- manual / very large ----
    if name == "kraken2":
        log.append(
            "## NOTE\nKraken2 databases are large. Build/download with:\n\n"
            f"```bash\nkraken2-build --standard --db {os.path.abspath(dest_dir)}\n"
            "# or a prebuilt db from https://benlangmead.github.io/aws-indexes/k2\n```"
        )
        return "\n".join(log)
    if name in ("gtdb", "dbcan", "eggnog"):
        hints = {
            "gtdb": "use name='gtdbtk' for the GTDB-Tk reference package (verify + guide)",
            "dbcan": "https://bcb.unl.edu/dbCAN2/download/Databases/ (dbCAN-HMMdb + `hmmpress`)",
            "eggnog": "use `download_eggnog_data.py` from eggnog-mapper (builds eggnog.db)",
        }
        log.append(f"## NOTE\n{name}: {hints[name]}")
        return "\n".join(log)

    # ---- nr: user-provided NCBI nr protein FASTA -> build DIAMOND .dmnd ----
    if name == "nr":
        fa = None
        for cand in ("nr.faa", "nr.fasta", "nr.fa", "nr.gz", "nr.faa.gz", "nr.fasta.gz"):
            c = os.path.join(dest_dir, cand)
            if os.path.exists(c):
                fa = c
                break
        if fa is None:
            log.append(
                "## NOTE\nNCBI nr has no small direct link here. Place nr.faa (protein FASTA) under "
                f"{os.path.abspath(dest_dir)} and re-run to build nr.dmnd. (nr.faa already present? it was not found.)"
            )
            return "\n".join(log)
        log.append(f"- using local FASTA: {fa}")
        if build_dmnd:
            dmnd = os.path.join(dest_dir, "nr.dmnd")
            if os.path.exists(dmnd):
                log.append(f"- DIAMOND db already present: {dmnd}")
            elif _find_cli("diamond", env) is None:
                log.append("- NOTE: diamond not found; build with `diamond makedb --in " + fa + " --db " + dmnd + "`")
            else:
                res = subprocess.run(_cli("diamond", env) + ["makedb", "--in", fa, "--db", dmnd], capture_output=True, text=True, check=False)
                log.append(f"$ diamond makedb --in {fa} --db {dmnd}")
                log.append(f"- DIAMOND db: {dmnd} ({'OK' if res.returncode == 0 else 'FAILED'})")
                if res.returncode != 0:
                    log.append("```\n" + (res.stderr or res.stdout or "")[-1500:] + "\n```")
        log.append("## Results")
        log.append(f"- nr ready under: {os.path.abspath(dest_dir)}")
        return "\n".join(log)

    # ---- direct-download (stable links) ----
    if name not in _DB_URLS:
        log.append(
            f"## ERROR\nUnknown database '{name}'. Supported: "
            + str(sorted(_DB_URLS) + ["cog", "genomad", "checkv", "bakta", "nr", "kraken2", "gtdbtk", "kegg", "tcdb", "gtdb", "dbcan", "eggnog"])
        )
        return "\n".join(log)

    url = _DB_URLS[name]
    fname = url.rsplit("/", 1)[-1]
    dest = os.path.join(dest_dir, fname)
    try:
        ok = _stream_download(url, dest, log)
    except Exception as e:
        log.append(f"## ERROR\nDownload failed: {e}")
        return "\n".join(log)
    if not ok:
        log.append(f"## ERROR\nDownloaded file too small / failed: {dest}")
        return "\n".join(log)

    log.append("## Results")
    log.append(f"- Downloaded: {dest}")

    # localization: build DIAMOND db for Swiss-Prot
    if name == "swissprot" and build_dmnd:
        dmnd = os.path.join(dest_dir, "swissprot.dmnd")
        if os.path.exists(dmnd):
            log.append(f"- DIAMOND db already present: {dmnd}")
        elif _find_cli("diamond", env) is None:
            log.append("- NOTE: diamond not found; build .dmnd later with `diamond makedb --in " + dest + " --db " + dmnd + "`")
        else:
            res = subprocess.run(
                _cli("diamond", env) + ["makedb", "--in", dest, "--db", dmnd],
                capture_output=True, text=True, check=False,
            )
            log.append(f"$ diamond makedb --in {dest} --db {dmnd}")
            log.append(f"- DIAMOND db: {dmnd} ({'OK' if res.returncode == 0 else 'FAILED'})")
            if res.returncode != 0:
                log.append("```\n" + (res.stderr or res.stdout or "")[-1500:] + "\n```")
    return "\n".join(log)
