"""Metagenomics tools for Microbiome.

Each tool returns a markdown "research log" string and writes key results to
disk (fasta/tsv). Heavy steps are delegated to external CLI tools detected on
PATH or run inside a dedicated conda env (default: "microbiome"). If a required
CLI is missing, the tool returns a log with an install hint instead of raising.
"""

import os
import shutil
import subprocess

from microbiome.resource_config import threads as _default_threads

# Name of the conda env that holds the metagenomics CLI tools.
DEFAULT_ENV = os.environ.get("MICROBIOME_ENV", "microbiome")

# Map a logical tool name to (executable, conda package) for install hints.
_CLI_PACKAGES = {
    "megahit": ("megahit", "megahit"),
    "spades.py": ("spades.py", "spades"),
    "prodigal": ("prodigal", "prodigal"),
    "metabat2": ("metabat2", "metabat2"),
    "run_MaxBin.pl": ("run_MaxBin.pl", "maxbin2"),
    "checkm": ("checkm", "checkm-genome"),
    "salmon": ("salmon", "salmon"),
    "bwa": ("bwa", "bwa"),
    "bowtie2": ("bowtie2", "bowtie2"),
    "samtools": ("samtools", "samtools"),
    "seqkit": ("seqkit", "seqkit"),
    "kraken2": ("kraken2", "kraken2"),
    "bcftools": ("bcftools", "bcftools"),
    "genomad": ("genomad", "genomad"),
    "checkv": ("checkv", "checkv"),
    "diamond": ("diamond", "diamond"),
    "bakta": ("bakta", "bakta"),
    "concoct": ("concoct", "concoct"),
    "cut_up_fasta.py": ("cut_up_fasta.py", "concoct"),
    "jgi_summarize_bam_contig_depths": ("jgi_summarize_bam_contig_depths", "metabat2"),
    "blastn": ("blastn", "blast"),
    "blastp": ("blastp", "blast"),
    "makeblastdb": ("makeblastdb", "blast"),
    "mafft": ("mafft", "mafft"),
    "muscle": ("muscle", "muscle"),
    "iqtree": ("iqtree", "iqtree"),
    "fasttree": ("fasttree", "fasttree"),
    "FastTree": ("FastTree", "fasttree"),
    "treetime": ("treetime", "treetime"),
    "Rscript": ("Rscript", "r-base"),
    "usearch": ("usearch", "usearch"),
    "vsearch": ("vsearch", "vsearch"),
}


def _env_prefix(env):
    """Return a command prefix that activates the conda env, or [] to use PATH."""
    if env is None:
        return []
    conda = shutil.which("conda") or shutil.which("mamba")
    if not conda:
        return []
    return [conda, "run", "-n", env, "--no-capture-output"]


def _find_cli(tool, env=None):
    """Locate a CLI executable. Returns a list prefix to run it, or None.

    Resolution order:
    1. inside the given conda env via `conda run` (when env is specified),
    2. executable already on PATH (env=None path).

    When a conda env is specified, the env takes priority so that all tools
    in a pipeline come from the same environment, avoiding base/env library
    conflicts (e.g. htslib ABI mismatch between samtools and bcftools).
    """
    exe = _CLI_PACKAGES.get(tool, (tool, tool))[0]
    # 1) inside conda env (preferred when env is given)
    if env:
        prefix = _env_prefix(env)
        if prefix:
            try:
                res = subprocess.run(
                    prefix + ["bash", "-lc", f"command -v {exe}"],
                    capture_output=True,
                    text=True,
                    check=False,
                )
                if res.returncode == 0 and res.stdout.strip():
                    return prefix + [exe]
            except Exception:
                pass
    # 2) on PATH?
    path = shutil.which(exe)
    if path:
        return [path]
    return None


def _cli(tool, env=None):
    """Like _find_cli but always returns a list (empty if not found).

    Safe to use with ``+`` for building command lists. When the tool is not
    found the resulting command will fail at runtime, which callers already
    handle via ``rc != 0`` checks.
    """
    result = _find_cli(tool, env)
    return result if result is not None else []


def _install_hint(tool):
    pkg = _CLI_PACKAGES.get(tool, (tool, tool))[1]
    return (
        f"Required tool '{tool}' was not found. Install it with:\n\n"
        f"```bash\nmamba install -c bioconda -c conda-forge {pkg}\n"
        f"# or create the full environment:\nbash microbiome_env/setup_microbiome.sh\n```\n"
    )


def _run(cmd, log_lines=None, cwd=None):
    """Run a command (list). Returns (returncode, stdout+stderr)."""
    res = subprocess.run(cmd, capture_output=True, text=True, check=False, cwd=cwd)
    out = (res.stdout or "") + (res.stderr or "")
    if log_lines is not None:
        log_lines.append(f"$ {' '.join(cmd)}")
    return res.returncode, out


def _count_fasta(fasta_path):
    """Count records in a FASTA file."""
    n = 0
    with open(fasta_path) as fh:
        for line in fh:
            if line.startswith(">"):
                n += 1
    return n


def _n50(lengths):
    """Compute N50 from a list of contig lengths."""
    if not lengths:
        return 0
    s = sorted(lengths, reverse=True)
    total = sum(s)
    acc = 0
    for L in s:
        acc += L
        if acc >= total / 2:
            return L
    return s[-1]


def _fasta_lengths(fasta_path):
    lengths = []
    cur = 0
    with open(fasta_path) as fh:
        for line in fh:
            if line.startswith(">"):
                if cur:
                    lengths.append(cur)
                cur = 0
            else:
                cur += len(line.strip())
    if cur:
        lengths.append(cur)
    return lengths


def _tpm(lengths, counts):
    """Transcripts Per Million. lengths and counts are parallel sequences."""
    lengths = [float(x) for x in lengths]
    counts = [float(x) for x in counts]
    rpk = [c / (l / 1000.0) if l > 0 else 0.0 for c, l in zip(counts, lengths, strict=True)]
    scaling = sum(rpk)
    if scaling == 0:
        return [0.0 for _ in rpk]
    return [x / scaling * 1e6 for x in rpk]


def _fpkm(lengths, counts):
    """Fragments Per Kilobase per Million mapped fragments."""
    lengths = [float(x) for x in lengths]
    counts = [float(x) for x in counts]
    total = sum(counts)
    if total == 0:
        return [0.0 for _ in counts]
    million = total / 1e6
    return [(c / million) / (l / 1000.0) if l > 0 else 0.0 for c, l in zip(counts, lengths, strict=True)]


def assemble_metagenome(reads_1, reads_2=None, out_dir="metagenome_assembly", assembler="megahit", env=None):
    """Assemble metagenomic reads into contigs.

    Parameters
    ----------
    reads_1 : str
        Path to forward (or interleaved/single-end) reads in FASTQ format.
    reads_2 : str, optional
        Path to reverse reads for paired-end data.
    out_dir : str, optional
        Output directory for the assembly (default "metagenome_assembly").
    assembler : str, optional
        Assembler to use: "megahit" (default) or "metaspades".
    env : str, optional
        Conda environment name to run the assembler in. If None, uses
        DEFAULT_ENV (env var MICROBIOME_ENV or "microbiome"); pass ""
        to force using tools already on PATH.

    Returns
    -------
    str
        Research log summarizing the assembly and output contigs.
    """
    if env is None:
        env = DEFAULT_ENV
    os.makedirs(out_dir, exist_ok=True)
    log = ["# Metagenome Assembly\n", f"- reads_1: {reads_1}", f"- reads_2: {reads_2}", f"- assembler: {assembler}\n"]

    assembler_name = assembler.lower().strip()
    if assembler_name not in {"megahit", "metaspades"}:
        log.append(
            f"## ERROR\nAssembler '{assembler}' not found. Choose 'megahit' or 'metaspades', "
            "or install one with: mamba install -c bioconda megahit spades."
        )
        return "\n".join(log)
    tool = "megahit" if assembler_name == "megahit" else "spades.py"
    cmd_prefix = _find_cli(tool, env)
    if cmd_prefix is None:
        log.append("## ERROR\n" + _install_hint(tool))
        return "\n".join(log)

    contigs_out = os.path.join(out_dir, "contigs.fasta")
    run_name = "_megahit_run" if tool == "megahit" else "_metaspades_run"
    run_dir = os.path.join(out_dir, run_name)
    if os.path.exists(run_dir):
        log.append(
            f"## ERROR\nAssembler run directory already exists: {run_dir}. "
            "Use a new output directory or explicitly archive the prior failed run; existing results are never overwritten."
        )
        return "\n".join(log)
    if tool == "megahit":
        cmd = cmd_prefix + ["-1", reads_1]
        if reads_2:
            cmd += ["-2", reads_2]
        cmd += ["-o", run_dir]
        rc, out = _run(cmd, log)
        src = os.path.join(run_dir, "final.contigs.fa")
    else:  # metaspades
        cmd = cmd_prefix + ["--meta", "-1", reads_1]
        if reads_2:
            cmd += ["-2", reads_2]
        cmd += ["-o", run_dir]
        rc, out = _run(cmd, log)
        src = os.path.join(run_dir, "contigs.fasta")

    if rc != 0:
        log.append(f"## ERROR\nAssembly failed (exit {rc}).\n\n```\n{out[-3000:]}\n```")
        return "\n".join(log)

    # Normalize contigs path
    if os.path.abspath(src) != os.path.abspath(contigs_out):
        if os.path.exists(src):
            shutil.copyfile(src, contigs_out)

    if not os.path.exists(contigs_out):
        log.append("## ERROR\nNo contigs produced.")
        return "\n".join(log)

    n = _count_fasta(contigs_out)
    n50 = _n50(_fasta_lengths(contigs_out))
    log.append("## Results")
    log.append(f"- Contigs file: {contigs_out}")
    log.append(f"- Number of contigs: {n}")
    log.append(f"- N50: {n50} bp")
    return "\n".join(log)


def predict_genes(contigs, out_dir="gene_prediction", env=None):
    """Predict genes (ORFs) from assembled contigs using Prodigal (meta mode).

    Parameters
    ----------
    contigs : str
        Path to the assembled contigs FASTA file.
    out_dir : str, optional
        Output directory for predicted genes (default "gene_prediction").
    env : str, optional
        Conda environment name to run Prodigal in (default DEFAULT_ENV).

    Returns
    -------
    str
        Research log summarizing gene prediction and output files.
    """
    if env is None:
        env = DEFAULT_ENV
    os.makedirs(out_dir, exist_ok=True)
    log = ["# Gene Prediction (Prodigal)", f"- contigs: {contigs}\n"]

    cmd_prefix = _find_cli("prodigal", env)
    if cmd_prefix is None:
        log.append("## ERROR\n" + _install_hint("prodigal"))
        return "\n".join(log)

    fna = os.path.join(out_dir, "genes.fna")
    faa = os.path.join(out_dir, "proteins.faa")
    gff = os.path.join(out_dir, "genes.gff")
    cmd = cmd_prefix + [
        "-i", contigs,
        "-d", fna,
        "-a", faa,
        "-f", "gff",
        "-o", gff,
        "-p", "meta",
    ]
    rc, out = _run(cmd, log)
    if rc != 0:
        log.append(f"## ERROR\nProdigal failed (exit {rc}).\n\n```\n{out[-3000:]}\n```")
        return "\n".join(log)

    n_genes = _count_fasta(faa) if os.path.exists(faa) else 0
    log.append("## Results")
    log.append(f"- Nucleotide genes: {fna}")
    log.append(f"- Protein sequences: {faa}")
    log.append(f"- GFF annotations: {gff}")
    log.append(f"- Predicted genes: {n_genes}")
    return "\n".join(log)


def bin_metagenome(contigs, reads_1, reads_2=None, out_dir="metagenome_bins", binner="metabat2", env=None):
    """Bin metagenomic contigs into putative genomes (MAGs) using MetaBAT2.

    Aligns reads back to contigs (BWA + samtools) to compute per-contig
    coverage, then runs MetaBAT2.

    Parameters
    ----------
    contigs : str
        Path to the assembled contigs FASTA file.
    reads_1 : str
        Path to forward reads (FASTQ) used for coverage estimation.
    reads_2 : str, optional
        Path to reverse reads for paired-end data.
    out_dir : str, optional
        Output directory for bins (default "metagenome_bins").
    binner : str, optional
        Binning tool: "metabat2" (default).
    env : str, optional
        Conda environment name (default DEFAULT_ENV).

    Returns
    -------
    str
        Research log summarizing the binning results.
    """
    if env is None:
        env = DEFAULT_ENV
    os.makedirs(out_dir, exist_ok=True)
    log = ["# Metagenome Binning", f"- contigs: {contigs}", f"- binner: {binner}\n"]

    binner = binner.lower()
    needed = ["bwa", "samtools"]
    if binner == "metabat2":
        needed.append("metabat2")
    elif binner == "maxbin2":
        needed.append("run_MaxBin.pl")
    elif binner == "concoct":
        needed.append("concoct")
    else:
        log.append(f"## ERROR\nUnknown binner '{binner}'. Choose from: metabat2, maxbin2, concoct.")
        return "\n".join(log)

    for tool in needed:
        if _find_cli(tool, env) is None:
            log.append("## ERROR\n" + _install_hint(tool))
            return "\n".join(log)

    work = os.path.join(out_dir, "_align")
    os.makedirs(work, exist_ok=True)
    bam = os.path.join(work, "reads.bam")
    depth = os.path.join(work, "depth.txt")

    # 1) index + align + sort
    rc, out = _run(_cli("bwa", env) + ["index", contigs], log)
    if rc != 0:
        log.append(f"## ERROR\nbwa index failed.\n\n```\n{out[-2000:]}\n```")
        return "\n".join(log)

    aln = _cli("bwa", env) + ["mem", contigs, reads_1]
    if reads_2:
        aln.append(reads_2)
    bwa_cmd = " ".join(aln)
    sort_cmd = " ".join(_cli("samtools", env) + ["sort", "-o", bam, "-"])
    full = f"{bwa_cmd} | {sort_cmd}"
    shell_prefix = _env_prefix(env)
    res = subprocess.run(
        shell_prefix + ["bash", "-c", full],
        capture_output=True, text=True, check=False,
    )
    log.append(f"$ {full}")
    if res.returncode != 0 or not os.path.exists(bam):
        log.append(f"## ERROR\nalignment failed.\n\n```\n{(res.stdout or '') + (res.stderr or '')[-2000:]}\n```")
        return "\n".join(log)

    # 2) depth via metabat2's jgi_summarize_bam_contig_depths
    res = subprocess.run(
        shell_prefix + ["bash", "-lc", f"jgi_summarize_bam_contig_depths --outputDepth {depth} {bam}"],
        capture_output=True, text=True, check=False,
    )
    log.append(f"$ jgi_summarize_bam_contig_depths --outputDepth {depth} {bam}")
    if res.returncode != 0 or not os.path.exists(depth):
        log.append(f"## ERROR\ndepth computation failed.\n\n```\n{(res.stdout or '') + (res.stderr or '')[-2000:]}\n```")
        return "\n".join(log)

    # 3) run the chosen binner
    bins_prefix = os.path.join(out_dir, "bin")
    if binner == "metabat2":
        rc, out = _run(
            _cli("metabat2", env) + ["-i", contigs, "-a", depth, "-o", bins_prefix], log
        )
    elif binner == "maxbin2":
        rc, out = _run(
            _cli("run_MaxBin.pl", env)
            + ["-contig", contigs, "-abund", depth, "-out", bins_prefix],
            log,
        )
    else:  # concoct: needs cut-up contigs + coverage table
        cut = os.path.join(work, "contigs_10K.fa")
        bed = os.path.join(work, "contigs_10K.bed")
        rc1, out1 = _run(
            shell_prefix + ["bash", "-lc", f"cut_up_fasta.py {contigs} -c 10000 -o 0 --merge_last -b {bed} > {cut}"],
            log,
        )
        cov = os.path.join(work, "coverage_table.tsv")
        rc2, out2 = _run(
            shell_prefix + ["bash", "-lc", f"concoct_coverage_table.py {bed} {bam} > {cov}"],
            log,
        )
        rc, out = _run(
            _cli("concoct", env)
            + ["--composition_file", cut, "--coverage_file", cov, "-b", bins_prefix],
            log,
        )
        # concoct writes clustering_gt1000.csv; merge into fasta bins
        merge_csv = bins_prefix + "_clustering_gt1000.csv"
        if rc == 0 and os.path.exists(merge_csv):
            _run(
                shell_prefix + ["bash", "-lc", f"merge_cutup_clustering.py {merge_csv} {contigs} > {bins_prefix}.fa"],
                log,
            )
            _run(
                shell_prefix + ["bash", "-lc", f"extract_fasta_bins.py {contigs} {merge_csv} --output_path {out_dir}"],
                log,
            )

    if rc != 0:
        log.append(f"## ERROR\n{binner} failed (exit {rc}).\n\n```\n{out[-2000:]}\n```")
        return "\n".join(log)

    bins = [
        f for f in os.listdir(out_dir)
        if (f.startswith("bin") or f.startswith("Bin") or f.endswith((".fa", ".fasta")))
        and os.path.isfile(os.path.join(out_dir, f))
        and not f.startswith("_")
    ]
    log.append("## Results")
    log.append(f"- Binner: {binner}")
    log.append(f"- Bins directory: {out_dir}")
    log.append(f"- Number of bins: {len(bins)}")
    for b in sorted(bins)[:20]:
        log.append(f"  - {os.path.join(out_dir, b)}")
    return "\n".join(log)


def assess_bins_quality(bins_dir, out_dir="bins_quality", env=None):
    """Assess genome bin quality (completeness/contamination) using CheckM.

    Parameters
    ----------
    bins_dir : str
        Directory containing genome bins as .fa/.fasta files (e.g. from bin_metagenome).
    out_dir : str, optional
        Output directory for the quality report (default "bins_quality").
    env : str, optional
        Conda environment name (default DEFAULT_ENV).

    Returns
    -------
    str
        Research log with a per-bin completeness/contamination table, or an
        explanatory message if CheckM or its database is unavailable.
    """
    if env is None:
        env = DEFAULT_ENV
    os.makedirs(out_dir, exist_ok=True)
    log = ["# Bin Quality Assessment (CheckM)", f"- bins_dir: {bins_dir}\n"]

    if _find_cli("checkm", env) is None:
        log.append("## ERROR\n" + _install_hint("checkm"))
        return "\n".join(log)

    # CheckM needs its marker database; detect via env var or common locations.
    checkm_data = os.environ.get("CHECKM_DATA_PATH", "")
    if not checkm_data:
        from microbiome.tool.db_inventory import _resolve_db_path
        checkm_data = _resolve_db_path("checkm") or ""
        if checkm_data:
            log.append(f"- auto-detected {'checkm'} database: {checkm_data}")
    if not checkm_data:
        log.append(
            "## NOTE\n"
            "CheckM database not configured (CHECKM_DATA_PATH unset). "
            "Attempting to run; if it fails, download the database with:\n\n"
            "```bash\n"
            "checkm data setRoot <db_dir>   # after downloading CheckM data\n"
            "```\n"
        )

    rc, out = _run(
        _cli("checkm", env)
        + ["lineage_wf", "-x", "fa", "-t", str(_default_threads()), "-f", os.path.join(out_dir, "bins_quality.tsv"), "--tab_table", bins_dir, out_dir],
        log,
    )
    if rc != 0:
        log.append(
            f"## ERROR\nCheckM failed (exit {rc}). This is often because the "
            f"CheckM marker database is not installed.\n\n```\n{out[-2000:]}\n```"
        )
        return "\n".join(log)

    qfile = os.path.join(out_dir, "bins_quality.tsv")
    log.append("## Results")
    if os.path.exists(qfile):
        log.append(f"- Quality table: {qfile}")
        try:
            with open(qfile) as fh:
                head = [next(fh) for _ in range(5)]
            log.append("\n```\n" + "".join(head) + "```")
        except Exception:
            pass
    else:
        log.append("- (no table produced)")
    return "\n".join(log)


# ---------------------------------------------------------------------------
# Stage 2: metatranscriptomics + joint binning x expression analysis
# ---------------------------------------------------------------------------


def assemble_metatranscriptome(reads_1, reads_2=None, out_dir="metatranscriptome_assembly", env=None):
    """De novo assemble a metatranscriptome using rnaSPAdes.

    Parameters
    ----------
    reads_1 : str
        Path to forward (or single-end) metatranscriptomic reads (FASTQ).
    reads_2 : str, optional
        Path to reverse reads for paired-end data.
    out_dir : str, optional
        Output directory (default "metatranscriptome_assembly").
    env : str, optional
        Conda environment name (default DEFAULT_ENV).

    Returns
    -------
    str
        Research log with transcript count and N50.
    """
    if env is None:
        env = DEFAULT_ENV
    os.makedirs(out_dir, exist_ok=True)
    log = ["# Metatranscriptome Assembly (rnaSPAdes)", f"- reads_1: {reads_1}\n"]

    cmd_prefix = _find_cli("spades.py", env)
    if cmd_prefix is None:
        log.append("## ERROR\n" + _install_hint("spades.py"))
        return "\n".join(log)

    run_dir = os.path.join(out_dir, "_rnaspades_run")
    if os.path.exists(run_dir):
        log.append(
            f"## ERROR\nrnaSPAdes run directory already exists: {run_dir}. "
            "Use a new output directory; existing results are never overwritten."
        )
        return "\n".join(log)
    cmd = cmd_prefix + ["--rna", "-1", reads_1]
    if reads_2:
        cmd += ["-2", reads_2]
    cmd += ["-o", run_dir]
    rc, out = _run(cmd, log)
    if rc != 0:
        log.append(f"## ERROR\nrnaSPAdes failed (exit {rc}).\n\n```\n{out[-3000:]}\n```")
        return "\n".join(log)

    source_tx = os.path.join(run_dir, "transcripts.fasta")
    tx = os.path.join(out_dir, "transcripts.fasta")
    if not os.path.exists(source_tx):
        log.append("## ERROR\nNo transcripts.fasta produced.")
        return "\n".join(log)
    shutil.copyfile(source_tx, tx)
    lengths = _fasta_lengths(tx)
    log.append("## Results")
    log.append(f"- Transcripts file: {tx}")
    log.append(f"- Number of transcripts: {_count_fasta(tx)}")
    log.append(f"- N50: {_n50(lengths)} bp")
    return "\n".join(log)


def calculate_gene_abundance(genes_fna, reads_1, reads_2=None, out_dir="gene_abundance", env=None, method="salmon"):
    """Quantify gene/transcript abundance (TPM and FPKM) for metagenomic genes.

    Maps reads to the gene catalog with Salmon (TPM) and additionally reports
    FPKM. Produces abundance_tpm_fpkm.tsv.

    Parameters
    ----------
    genes_fna : str
        Path to the gene catalog nucleotide FASTA (e.g. genes.fna from predict_genes).
    reads_1 : str
        Path to forward (or single-end) reads (FASTQ).
    reads_2 : str, optional
        Path to reverse reads for paired-end data.
    out_dir : str, optional
        Output directory (default "gene_abundance").
    env : str, optional
        Conda environment name (default DEFAULT_ENV).
    method : str, optional
        Quantification backend: "salmon" (default).

    Returns
    -------
    str
        Research log with path to the TPM/FPKM table.
    """
    if env is None:
        env = DEFAULT_ENV
    os.makedirs(out_dir, exist_ok=True)
    log = ["# Gene Abundance (TPM/FPKM)", f"- genes: {genes_fna}\n"]

    cmd_prefix = _find_cli("salmon", env)
    if cmd_prefix is None:
        log.append("## ERROR\n" + _install_hint("salmon"))
        return "\n".join(log)

    index_dir = os.path.join(out_dir, "salmon_index")
    rc, out = _run(cmd_prefix + ["index", "-t", genes_fna, "-i", index_dir], log)
    if rc != 0:
        log.append(f"## ERROR\nsalmon index failed.\n\n```\n{out[-2000:]}\n```")
        return "\n".join(log)

    quant_dir = os.path.join(out_dir, "quant")
    qcmd = cmd_prefix + ["quant", "-i", index_dir, "-l", "A", "-o", quant_dir, "--validateMappings"]
    if reads_2:
        qcmd += ["-1", reads_1, "-2", reads_2]
    else:
        qcmd += ["-r", reads_1]
    rc, out = _run(qcmd, log)
    if rc != 0:
        log.append(f"## ERROR\nsalmon quant failed.\n\n```\n{out[-2500:]}\n```")
        return "\n".join(log)

    quant_sf = os.path.join(quant_dir, "quant.sf")
    out_tsv = os.path.join(out_dir, "abundance_tpm_fpkm.tsv")
    if not os.path.exists(quant_sf):
        log.append("## ERROR\nquant.sf not produced.")
        return "\n".join(log)

    # build TPM + FPKM table (gene lengths from genes_fna)
    import csv

    gene_len = {}
    name, cur = None, 0
    with open(genes_fna) as fh:
        for line in fh:
            if line.startswith(">"):
                if name is not None:
                    gene_len[name] = cur
                name = line[1:].split()[0]
                cur = 0
            else:
                cur += len(line.strip())
    if name is not None:
        gene_len[name] = cur

    genes, lens, counts, tpms = [], [], [], []
    with open(quant_sf) as fh:
        rd = csv.DictReader(fh, delimiter="\t")
        for row in rd:
            genes.append(row["Name"])
            lens.append(gene_len.get(row["Name"], float(row["EffectiveLength"])))
            counts.append(float(row["NumReads"]))
            tpms.append(float(row["TPM"]))
    fpkms = _fpkm(lens, counts)

    with open(out_tsv, "w", newline="") as fh:
        wr = csv.writer(fh, delimiter="\t")
        wr.writerow(["gene", "length", "num_reads", "TPM", "FPKM"])
        for g, l, c, t, f in zip(genes, lens, counts, tpms, fpkms, strict=True):
            wr.writerow([g, int(l), f"{c:.2f}", f"{t:.4f}", f"{f:.4f}"])

    log.append("## Results")
    log.append(f"- Abundance table: {out_tsv}")
    log.append(f"- Quantified genes: {len(genes)}")
    log.append(f"- (Salmon quant: {quant_sf})")
    return "\n".join(log)


def joint_binning_transcriptome_analysis(bins_dir, abundance_tsv, gene_to_contig=None, out_dir="joint_analysis"):
    """Join metagenome binning (MAGs) with metatranscriptome gene expression.

    Aggregates per-gene TPM/FPKM up to each genome bin (MAG), showing which MAGs
    are transcriptionally active and by how much. Contigs are assigned to bins by
    scanning the bin FASTA headers; genes are mapped to contigs via their Prodigal
    IDs (gene_to_contig inferred from the GFF-style "ID_contig" convention or a
    provided mapping).

    Parameters
    ----------
    bins_dir : str
        Directory of bin FASTA files (from bin_metagenome).
    abundance_tsv : str
        Path to abundance_tpm_fpkm.tsv (from calculate_gene_abundance).
    gene_to_contig : str, optional
        Optional 2-column TSV mapping gene_id -> contig_id. If omitted, the gene id
        prefix before the last "_" is used as the contig id (Prodigal convention).
    out_dir : str, optional
        Output directory (default "joint_analysis").

    Returns
    -------
    str
        Research log with a per-bin expression summary table.
    """
    import csv
    import glob

    os.makedirs(out_dir, exist_ok=True)
    log = ["# Joint MAG x Expression Analysis", f"- bins_dir: {bins_dir}", f"- abundance: {abundance_tsv}\n"]

    # 1) contig -> bin
    contig2bin = {}
    for fa in glob.glob(os.path.join(bins_dir, "*.fa")) + glob.glob(os.path.join(bins_dir, "*.fasta")):
        binname = os.path.splitext(os.path.basename(fa))[0]
        with open(fa) as fh:
            for line in fh:
                if line.startswith(">"):
                    contig2bin[line[1:].split()[0]] = binname

    # 2) optional gene->contig mapping
    g2c = {}
    if gene_to_contig and os.path.exists(gene_to_contig):
        with open(gene_to_contig) as fh:
            for line in fh:
                p = line.rstrip("\n").split("\t")
                if len(p) >= 2:
                    g2c[p[0]] = p[1]

    # 3) read abundance and assign genes to bins
    bin_stats = {}
    unassigned = 0
    total_genes = 0
    with open(abundance_tsv) as fh:
        rd = csv.DictReader(fh, delimiter="\t")
        for row in rd:
            total_genes += 1
            gene = row["gene"]
            contig = g2c.get(gene)
            if contig is None:
                # Prodigal convention: gene id = contig_# (contig id = all but last token)
                contig = gene.rsplit("_", 1)[0]
            b = contig2bin.get(contig)
            tpm = float(row["TPM"])
            if b is None:
                unassigned += 1
                continue
            st = bin_stats.setdefault(b, {"genes": 0, "tpm": 0.0})
            st["genes"] += 1
            st["tpm"] += tpm

    out_tsv = os.path.join(out_dir, "bin_expression_summary.tsv")
    rows = sorted(bin_stats.items(), key=lambda kv: kv[1]["tpm"], reverse=True)
    with open(out_tsv, "w", newline="") as fh:
        wr = csv.writer(fh, delimiter="\t")
        wr.writerow(["bin", "expressed_genes", "total_TPM"])
        for b, st in rows:
            wr.writerow([b, st["genes"], f"{st['tpm']:.2f}"])

    log.append("## Results")
    log.append(f"- Bins with detected expression: {len(rows)}")
    log.append(f"- Genes total / unassigned to a bin: {total_genes} / {unassigned}")
    log.append(f"- Summary table: {out_tsv}\n")
    log.append("| bin | expressed_genes | total_TPM |")
    log.append("|---|---|---|")
    for b, st in rows[:15]:
        log.append(f"| {b} | {st['genes']} | {st['tpm']:.2f} |")
    return "\n".join(log)
