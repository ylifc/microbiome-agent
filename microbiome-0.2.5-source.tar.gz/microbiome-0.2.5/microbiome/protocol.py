"""Transport identity shared by portable inspection and the Harness worker."""

PROTOCOL_VERSION = 1
