/** Host-routed models and session-owned Microbiome background operations. */
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { fileURLToPath } from 'node:url'
import { createHash, randomUUID } from 'node:crypto'
import { setTimeout as delay } from 'node:timers/promises'

export const name = 'microbiome-harness'
export const engineVersion = '0.2.5'
export const inject = ['tools', 'llm', 'subprocess', 'jobs']
const directory = path.dirname(fileURLToPath(import.meta.url))
const FRAME_LIMIT = 32 * 1024 * 1024

const contractPath = [path.join(directory, '../pipeline/maintenance_contract.json'),
  path.join(directory, 'maintenance_contract.json')].find(p => fs.existsSync(p))
if (!contractPath) throw new Error('Missing canonical maintenance contract; reinstall the complete bundle')
const maintenanceContract = JSON.parse(fs.readFileSync(contractPath, 'utf8'))
const operationNames = Object.keys(maintenanceContract.operations)
const readOperations = new Set(['inspect', 'list_directory', 'read_artifact', 'read_diagnostic'])
const operationSchema = operation => {
  const definition = Object.hasOwn(maintenanceContract.operations, operation) ? maintenanceContract.operations[operation] : undefined
  return definition && { ...definition.parameters,
    properties: { ...definition.parameters.properties, ...maintenanceContract.common_arguments } }
}
export const maintenanceSchema = { type: 'object', oneOf: operationNames.map(operation => ({
  type: 'object', properties: { operation: { const: operation, description: maintenanceContract.operations[operation].description },
    arguments: operationSchema(operation) }, required: ['operation',
      ...((maintenanceContract.operations[operation].parameters.required?.length || maintenanceContract.operations[operation].parameters.oneOf || maintenanceContract.operations[operation].parameters.anyOf) ? ['arguments'] : [])], additionalProperties: false,
})) }
export function schemaErrors(schema, value, field = 'arguments') {
  const type = schema.type
  const valid = { object: value !== null && typeof value === 'object' && !Array.isArray(value),
    array: Array.isArray(value), string: typeof value === 'string', integer: Number.isInteger(value),
    boolean: typeof value === 'boolean', number: typeof value === 'number' && Number.isFinite(value), null: value === null }
  if (type && !(Array.isArray(type) ? type.some(t => valid[t]) : valid[type])) return [{ field, expected: type }]
  const errors = []
  if ('const' in schema && JSON.stringify(schema.const) !== JSON.stringify(value)) errors.push({ field, expected: schema.const })
  if (schema.enum && !schema.enum.includes(value)) errors.push({ field, expected: schema.enum })
  for (const key of ['oneOf', 'anyOf']) if (schema[key]) {
    const matches = schema[key].filter(branch => schemaErrors(branch, value, field).length === 0).length
    if (key === 'oneOf' ? matches !== 1 : matches < 1) errors.push({ field, issue: `does not satisfy ${key}` })
  }
  for (const branch of schema.allOf ?? []) errors.push(...schemaErrors(branch, value, field))
  if (schema.not && schemaErrors(schema.not, value, field).length === 0) errors.push({ field, issue: 'forbidden field combination' })
  if (valid.object) {
    for (const k of schema.required ?? []) if (!Object.hasOwn(value, k)) errors.push({ field: `${field}.${k}`, issue: 'required' })
    for (const [k, v] of Object.entries(value)) {
      if (Object.hasOwn(schema.properties ?? {}, k)) errors.push(...schemaErrors(schema.properties[k], v, `${field}.${k}`))
      else if (schema.additionalProperties === false) errors.push({ field: `${field}.${k}`, issue: 'unknown field' })
      else if (schema.additionalProperties && typeof schema.additionalProperties === 'object') errors.push(...schemaErrors(schema.additionalProperties, v, `${field}.${k}`))
    }
  } else if (valid.array) {
    if (value.length < (schema.minItems ?? 0) || value.length > (schema.maxItems ?? Infinity)) errors.push({ field, issue: 'invalid array length' })
    if (schema.uniqueItems && new Set(value.map(v => JSON.stringify(v))).size !== value.length) errors.push({ field, issue: 'duplicate items' })
    value.forEach((v, i) => errors.push(...schemaErrors(schema.items ?? {}, v, `${field}[${i}]`)))
  } else if (valid.number) {
    if (value < (schema.minimum ?? -Infinity) || value > (schema.maximum ?? Infinity)) errors.push({ field, issue: 'out of range' })
  } else if (valid.string) {
    if ([...value].length < (schema.minLength ?? 0) || [...value].length > (schema.maxLength ?? Infinity)) errors.push({ field, issue: 'invalid string length' })
    if (schema.pattern && !new RegExp(schema.pattern).test(value)) errors.push({ field, issue: 'pattern mismatch' })
  }
  return errors
}
function maintenanceSuggestion(operation, args, definition) {
  if (operation === 'inspect') {
    const file = args?.path ?? args?.file
    const keys = ['path', 'file'].filter(k => Object.hasOwn(args ?? {}, k))
    const parts = typeof file === 'string' ? file.split('/').filter(Boolean) : []
    if (keys.length === 1 && (!args.root || args.root === 'project') && typeof file === 'string' && !path.isAbsolute(file) && !parts.includes('..') &&
        parts.length > 1 && ['config', 'state', 'requirements', 'pipeline'].includes(parts[0]) && path.extname(file)) {
      return { operation: 'read_artifact', arguments: { root: 'project', path: file } }
    }
    const root = ['raw_data', 'database', 'output', 'download', 'knowledge', 'project'].includes(args?.root) ? args.root : 'project'
    return { operation: 'list_directory', arguments: { root, path: '.' } }
  }
  return { operation, arguments: definition?.example ?? {} }
}
export function validateMaintenance(args) {
  const schema = operationSchema(args.operation)
  const errors = Object.keys(args).filter(k => !['operation', 'arguments'].includes(k)).map(field => ({ field, issue: 'unknown field' }))
  errors.push(...(schema ? schemaErrors(schema, args.arguments === undefined ? {} : args.arguments) : [{ field: 'operation', issue: 'unsupported operation' }]))
  const a = args.arguments ?? {}
  if (args.operation === 'cleanup' && Boolean(a.artifact_ids?.length) === Boolean(a.paths?.length)) errors.push({ field: 'arguments', issue: 'supply exactly one of artifact_ids or paths' })
  if (a.cursor && ('offset' in a || 'snapshot' in a)) errors.push({ field: 'arguments.cursor', issue: 'cursor includes offset/snapshot; omit those fields' })
  if (errors.length) {
    const details = { code: 'INVALID_ARGUMENT', operation: args.operation, field_errors: errors, schema,
      allowed_fields: Object.keys(schema?.properties ?? {}), required_fields: schema?.required ?? [],
      suggested_call: maintenanceSuggestion(schema ? args.operation : 'inspect', args.arguments, maintenanceContract.operations[args.operation]) }
    const error = new Error('Invalid maintenance argument: ' + JSON.stringify(details)); error.details = details; throw error
  }
}

const databaseContractPath = [path.join(directory, '../pipeline/database_contract.json'),
  path.join(directory, 'database_contract.json')].find(p => fs.existsSync(p))
if (!databaseContractPath) throw new Error('Missing database operation contract; reinstall the complete bundle')
const databaseContract = JSON.parse(fs.readFileSync(databaseContractPath, 'utf8'))
const databaseNames = Object.keys(databaseContract.operations)
const databaseSchema = { type: 'object', oneOf: databaseNames.map(operation => ({
  type: 'object', properties: { operation: { const: operation, description: databaseContract.operations[operation].description },
    arguments: databaseContract.operations[operation].parameters },
  required: ['operation', ...(databaseContract.operations[operation].parameters.required?.length ? ['arguments'] : [])], additionalProperties: false,
})) }
export function localCapabilityIdentity() {
  return { engine_version: engineVersion, protocol_version: 1, plugin_sha256: createHash('sha256').update(fs.readFileSync(fileURLToPath(import.meta.url))).digest('hex'),
    contracts: { maintenance: createHash('sha256').update(fs.readFileSync(contractPath)).digest('hex'),
      database: createHash('sha256').update(fs.readFileSync(databaseContractPath)).digest('hex') } }
}
// Capture the loaded code/contracts. Replacing files requires a plugin reload.
const loadedIdentity = localCapabilityIdentity()
export async function probeCapabilities(ctx, config, project, signal) {
  const abort = new AbortController()
  const cancel = () => abort.abort()
  signal?.throwIfAborted(); signal?.addEventListener('abort', cancel, { once: true })
  const timer = setTimeout(cancel, 15000)
  let child
  try {
    child = ctx.subprocess.spawn({ argv: [config.python, '-m', 'microbiome.harness.worker'], cwd: config.runtime,
      env: { PYTHONUNBUFFERED: '1' }, stdio: { stdin: 'pipe', stdout: 'pipe', stderr: { maxBytes: 4096 } }, graceMs: 1000, signal: abort.signal })
    child.stdin.on('error', () => {})
    child.stdin.write(JSON.stringify({ protocol: 1, type: 'capabilities', ...(project ? { project } : {}) }) + '\n')
    let result
    for await (const frame of frames(child.stdout)) {
      if (frame.type !== 'result') throw new Error('Capability probe cannot invoke models or workflow actions')
      result = frame.result
    }
    const outcome = await child.done
    if (!result?.ok || outcome.exitCode !== 0 || !result.capabilities) throw new Error(result?.error ?? 'Backend does not expose runtime capabilities; update the matched plugin/backend installation')
    const actual = result.capabilities, differences = []
    for (const key of ['engine_version', 'protocol_version', 'plugin_sha256']) if (actual[key] !== loadedIdentity[key]) differences.push(key)
    for (const name of ['maintenance', 'database']) if (actual.contracts?.[name]?.sha256 !== loadedIdentity.contracts[name]) differences.push(`contracts.${name}`)
    return { ...actual, compatibility: { compatible: differences.length === 0, mismatched_fields: differences,
      next_action: differences.length ? 'Reload matching plugin and backend artifacts before continuing' : 'Use the listed operations and effective permissions' } }
  } catch (error) {
    abort.abort()
    if (child) await child.done.catch(() => {})
    throw error
  } finally { clearTimeout(timer); signal?.removeEventListener('abort', cancel) }
}

export function latestUser(session) {
  const event = [...session.events].reverse().find(e => e.type === 'user/message' && e.data.source?.kind === 'user')
  if (!event) throw new Error('No actual user message is available')
  const text = event.data.content.filter(b => b.type === 'text').map(b => b.text).join('\n')
  if (!text.trim()) throw new Error('A textual user task or confirmation is required')
  const identity = event.data.id ?? event.seq
  if (identity === undefined || identity === null || !String(identity).trim() || String(identity).length > 256) throw new Error('INVALID_HOST_EVENT_ID')
  return { text, id: String(identity) }
}

/** Import only actual host user events; the model cannot supply this payload. */
export function hostUserHistory(session, currentMessageId) {
  const result = [], known = new Map()
  for (const event of session.events) {
    if (event.type !== 'user/message' || event.data?.source?.kind !== 'user') continue
    const id = event.data.id ?? event.seq
    if (id === undefined || id === null || String(id).length > 256) throw new Error('INVALID_HOST_EVENT_ID')
    const host_event_id = String(id)
    const content = (event.data.content ?? []).filter(block => block.type === 'text').map(block => block.text).join('\n')
    if (host_event_id === currentMessageId || !content.trim()) continue
    if (known.has(host_event_id)) {
      if (known.get(host_event_id) !== content) throw new Error('HOST_HISTORY_EVENT_CONFLICT')
      continue
    }
    known.set(host_event_id, content)
    result.push({ role: 'user', content, host_event_id })
  }
  return result
}

export function hostWorkspace(agent) {
  const workspace = agent?.session?.header?.cwd
  if (typeof workspace !== 'string' || !path.isAbsolute(workspace)) throw new Error('NEEDS_WORKSPACE: the host must provide an absolute workspace')
  return path.resolve(workspace)
}

/** Normalize supplied paths in one host workspace; never reinterpret an absolute path. */
export function normalizeWorkflowPaths(args, agent) {
  const workspace = hostWorkspace(agent), normalized = {}, origins = {}
  const userText = agent.session.events.filter(event => event.type === 'user/message' && event.data?.source?.kind === 'user')
    .flatMap(event => (event.data.content ?? []).filter(block => block.type === 'text').map(block => block.text)).join('\n')
  const roles = { project: 'output', data_dir: 'raw_data', db_dir: 'database', download_dir: 'download', knowledge_dir: 'knowledge' }
  for (const [name, value] of Object.entries(args)) {
    if (typeof value !== 'string' || !value.trim() || value.includes('\0')) throw new Error(`INVALID_PATH_ARGUMENT: ${name}`)
    // This exact labelled breadcrumb denotes a child of the visible workspace.
    // A bare /path continues to mean the filesystem root, without correction.
    const breadcrumb = value.match(/^(?:工作区|工作目录|workspace)\s*[>＞]\s*\/?(.+)$/i)
    let selected = breadcrumb ? breadcrumb[1].replace(/^[/\\]+/, '') : value
    if (breadcrumb && selected.split(/[\\/]/).includes('..')) throw new Error(`WORKSPACE_PATH_ESCAPE: ${name}`)
    if (selected.startsWith('~/')) selected = path.join(os.homedir(), selected.slice(2))
    normalized[name] = path.resolve(workspace, selected)
    origins[roles[name]] = userText.includes(normalized[name]) ? 'user' : 'configured'
  }
  return { normalized, workspace, origins }
}

/** Export conversation content, never transport headers, provider config or credentials. */
export function conversationEvents(session, { pending_call_ids = [] } = {}) {
  const result = [], issues = [], calls = new Map(), results = new Set()
  // These IDs come only from the host execution context, never tool arguments.
  const pendingIds = new Set(pending_call_ids.filter(id => typeof id === 'string' && id))
  const exclusions = new Map()
  const exclude = (type, reason, local) => {
    const key = JSON.stringify([type, reason]), entry = exclusions.get(key) ?? { type, reason, count: 0 }
    entry.count++; exclusions.set(key, entry)
    if (local) {
      const existing = local.find(item => item.type === type && item.reason === reason)
      if (existing) existing.count++
      else local.push({ type, reason, count: 1 })
    }
  }
  const usage = { outer: { assistant_messages: 0, reported_responses: 0, tokens: {} },
    internal: { dispatched_attempts: 0, reported_responses: 0, tokens: {} }, cost: null,
    cost_status: 'host_pricing_not_supplied', scope: 'current visible session events only' }
  const steps = new Set()
  const addUsage = (group, counters) => {
    if (!counters || typeof counters !== 'object') return
    const entries = Object.entries(counters).filter(([key, value]) => /Tokens$/.test(key) && Number.isFinite(value) && value >= 0)
    if (!entries.length) return
    group.reported_responses++
    for (const [key, value] of entries) group.tokens[key] = (group.tokens[key] ?? 0) + value
  }
  const pick = (value, keys) => Object.fromEntries(keys.filter(key => value?.[key] !== undefined).map(key => [key, value[key]]))
  const content = (blocks, failures, excluded, providerReasoning = false) => {
    if (!Array.isArray(blocks)) { failures.push('missing_content'); return [] }
    return blocks.map(block => {
      if (block?.type === 'reasoning' && providerReasoning && typeof block.text === 'string') {
        // Provider reasoning is intentionally outside the visible transcript.
        // Retain only its exclusion metadata, never its text or opaque state.
        const reason = 'provider_reasoning_excluded'
        exclude('reasoning', reason, excluded)
        return { type: 'reasoning', omitted: true, reason }
      }
      if (block?.type === 'text') {
        if (typeof block.text !== 'string') failures.push('invalid_text')
        return pick(block, ['type', 'text'])
      }
      if (block?.type === 'tool-call') {
        if (!block.id || !block.name || block.arguments === undefined) failures.push('incomplete_tool_call')
        if (block.id) calls.set(block.id, block.name)
        return pick(block, ['type', 'id', 'name', 'arguments'])
      }
      if (block?.type === 'tool-result') {
        if (!block.toolCallId) failures.push('missing_tool_call_id')
        if (block.toolCallId) results.add(block.toolCallId)
        return { ...pick(block, ['type', 'toolCallId', 'isError']), content: content(block.content, failures, excluded) }
      }
      // Binary/opaque provider blocks are deliberately excluded. An explicit
      // incomplete marker is safer than claiming a lossless text transcript.
      failures.push('unsupported_content_block')
      const type = typeof block?.type === 'string' ? block.type : 'unknown'
      exclude(type, 'unsupported_content_block', excluded)
      return { type, omitted: true, reason: 'unsupported_content_block' }
    })
  }
  for (const event of session.events) {
    const data = event.data ?? {}, base = { type: event.type, ...pick(event, ['seq', 'time', 'timestamp', 'surfaceOp']) }, failures = [], excluded = []
    if (event.sourceEventSeqs !== undefined) {
      if (!Array.isArray(event.sourceEventSeqs) || event.sourceEventSeqs.some(value => !Number.isSafeInteger(value) || value < 0)) {
        failures.push('invalid_source_event_seqs')
      } else {
        const ranges = []
        for (const seq of event.sourceEventSeqs) {
          const previous = ranges.at(-1)
          if (previous && seq === previous[1] + 1) previous[1] = seq
          else ranges.push([seq, seq])
        }
        base.source_event_seq_ranges = ranges
        base.source_event_seq_count = event.sourceEventSeqs.length
      }
    }
    if (event.type === 'assistant/message') {
      usage.outer.assistant_messages++
      if (data.step !== undefined) steps.add(data.step)
      addUsage(usage.outer, data.usage)
    }
    if (event.type === 'microbiome/model-request') usage.internal.dispatched_attempts++
    if (event.type === 'microbiome/model-result') addUsage(usage.internal, data.result?.usage)
    if (event.type === 'microbiome/model-error') addUsage(usage.internal, data.usage)
    let row
    if (['user/message', 'assistant/message', 'tool/result'].includes(event.type)) {
      // rc.12 wraps assistant/tool messages; user messages remain unwrapped.
      const message = data.message ?? data
      const legacyResult = event.type === 'tool/result' && !data.message && data.result !== undefined
      row = { ...base, ...pick(message, ['id', 'role']),
        ...(message.source?.kind ? { source: message.source.kind,
          provenance: pick(message.source, ['kind', 'provider', 'model', 'plugin', 'callId']) } : {}) }
      if (legacyResult) {
        Object.assign(row, pick(data, ['name', 'arguments', 'result']))
      } else {
        row.content = content(message.content, failures, excluded,
          event.type === 'assistant/message' && message.source?.kind === 'model')
        if (!message.id) failures.push('missing_message_id')
      }
      const callId = message.source?.callId ?? data.callId ?? data.toolCallId
      if (callId) { row.call_id = callId; if (event.type === 'tool/result') results.add(callId) }
      if (event.type === 'tool/result' && !callId && !row.content?.some(block => block.toolCallId)) failures.push('missing_tool_call_id')
      // Usage counters are known numeric metadata, never request config.
      if (data.usage) row.usage = Object.fromEntries(Object.entries(data.usage).filter(([key, value]) =>
        /Tokens$/.test(key) && Number.isFinite(value) && value >= 0))
      Object.assign(row, pick(data, ['step', 'stopReason']))
    } else if (event.type === 'microbiome/model-result') {
      row = { ...base, result: data.result }
    } else if (event.type === 'microbiome/model-error') {
      row = { ...base, ...pick(data, ['error', 'code']) }
      if (data.usage) row.usage = Object.fromEntries(Object.entries(data.usage).filter(([key, value]) =>
        /Tokens$/.test(key) && Number.isFinite(value) && value >= 0))
    } else if (event.type === 'tool/call') {
      const callId = data.callId ?? data.id
      row = { ...base, ...pick(data, ['name', 'arguments']), ...(callId ? { call_id: callId } : {}) }
      if (!callId) failures.push('missing_tool_call_id')
      else calls.set(callId, data.name)
    }
    if (!row) { exclude(event.type, 'non_transcript_event'); continue }
    row.export_integrity = { complete: failures.length === 0, raw_event_complete: false,
      issues: failures, exclusions: excluded }
    if (failures.length) issues.push({ ...base, issues: failures })
    result.push(row)
  }
  for (const row of result) if (row.type === 'tool/result' && row.call_id && calls.get(row.call_id)) row.name = calls.get(row.call_id)
  const pendingCalls = [...calls].filter(([id]) => !results.has(id) && pendingIds.has(id))
    .map(([call_id, name]) => ({ call_id, ...(name ? { name } : {}), status: 'pending_at_export',
      reason: 'current_export_call_result_not_yet_visible' }))
  const pendingVisibleIds = new Set(pendingCalls.map(call => call.call_id))
  for (const row of result) {
    if (row.type === 'tool/call' && pendingVisibleIds.has(row.call_id)) row.pending_at_export = true
    for (const block of row.content ?? []) if (block.type === 'tool-call' && pendingVisibleIds.has(block.id)) block.pending_at_export = true
  }
  const missingResults = [...calls.keys()].filter(id => !results.has(id) && !pendingVisibleIds.has(id))
  if (missingResults.length) issues.push({ issue: 'tool_results_not_available', call_ids: missingResults })
  usage.outer.observed_steps = steps.size || null
  usage.outer.responses_without_usage = usage.outer.assistant_messages - usage.outer.reported_responses
  usage.internal.attempts_without_usage = Math.max(0, usage.internal.dispatched_attempts - usage.internal.reported_responses)
  usage.known_total_tokens = {}
  for (const group of [usage.outer, usage.internal]) for (const [key, value] of Object.entries(group.tokens))
    usage.known_total_tokens[key] = (usage.known_total_tokens[key] ?? 0) + value
  result.push({ type: 'microbiome/export-integrity', schema_version: 1,
    complete: issues.length === 0, raw_event_complete: false,
    scope: 'supported visible text/tool content and selected metadata at export time; declared provider reasoning and non-transcript events excluded; current export call results may still be pending',
    pending_calls: pendingCalls,
    exclusions: [...exclusions.values()], excluded_types: [...new Set([...exclusions.values()].map(item => item.type))],
    source_event_seq_encoding: 'inclusive_contiguous_ranges_v1; expand [first,last] in stored order without sorting or deduplication',
    exported_event_count: result.length, issues, model_usage: usage })
  return result
}

function bound(text, limit) {
  const bytes = Buffer.from(text)
  return bytes.length <= limit ? text : bytes.subarray(0, limit - 80).toString('utf8') + '\n[完整记录已保存到项目文件]'
}

function hostMessages(messages, route) {
  return messages.map(m => {
    let content = typeof m.content === 'string' ? [{ type: 'text', text: m.content }] : m.content
    if (!Array.isArray(content) || content.some(b => b.type !== 'text')) throw new Error('Unsupported input; provide text summaries')
    if (m.tool_calls?.length) content = [...content, ...m.tool_calls.map(c => ({
      type: 'tool-call', id: c.id, name: c.name, arguments: JSON.stringify(c.args),
    }))]
    if (m.role === 'tool') return { id: randomUUID(), role: 'user', source: { kind: 'tool', callId: m.tool_call_id },
      content: [{ type: 'tool-result', toolCallId: m.tool_call_id, content }] }
    if (!['system', 'user', 'assistant'].includes(m.role)) throw new Error('Unsupported message role')
    return { id: randomUUID(), role: m.role, content, source: m.role === 'assistant'
      ? { kind: 'model', provider: route.provider, model: route.model }
      : { kind: 'plugin', plugin: name } }
  })
}

export function hostModelProfile(config = {}, profileKind = 'session_route', context = {}, metadataSource) {
  const capacity = [context.contextWindow, config.contextWindow, config.contextLength, config.context_length, config.maxContextTokens]
    .find(value => Number.isSafeInteger(value) && value > 0)
  return { ...(config.provider ? { provider: config.provider } : {}), ...(config.model ? { model: config.model } : {}), profile_kind: profileKind,
    ...(capacity ? { context_window_tokens: capacity } : {}),
    ...(Number.isSafeInteger(config.maxTokens) && config.maxTokens > 0 ? { output_reserve_tokens: config.maxTokens } : {}),
    capacity_metadata_source: capacity ? (Number.isSafeInteger(context.contextWindow) && context.contextWindow > 0
      ? metadataSource ?? 'prepared.context' : 'legacy_host_config') : 'unavailable',
    source: capacity ? 'host_declared_capacity' : 'host_capacity_unavailable' }
}

/** Resolve exact route metadata before Python performs its own preflight. */
export async function resolveHostModelProfile(ctx, route, signal) {
  signal?.throwIfAborted()
  if (typeof ctx.llm?.resolveModelInfo !== 'function') {
    // Older hosts expose exact metadata only from prepareCall. Preparing is
    // read-only and does not send a model request; the eventual request still
    // performs a fresh, registration-bound final check.
    if (typeof ctx.llm?.prepareCall === 'function') {
      const prepared = await ctx.llm.prepareCall(route, signal)
      return hostModelProfile(prepared.config, 'prepared_request', prepared.context, 'prepared.context')
    }
    return hostModelProfile(route)
  }
  const info = await ctx.llm.resolveModelInfo(route.provider, route.model, signal)
  if (info.provider !== route.provider || info.id !== route.model) throw new Error('INVALID_HOST_PROFILE: resolved model identity differs from the session route')
  return hostModelProfile({ ...route, maxTokens: route.maxTokens ?? info.defaultMaxTokens },
    'resolved_model_info', info.context, 'resolveModelInfo.context')
}

export function measureHostRequest(request, budget = {}, context = {}) {
  const limits = budget.limits ?? {}
  const profile = hostModelProfile(request, 'prepared_request', context, 'prepared.context')
  const configuredCapacity = budget.project_context_limit_tokens ??
    (budget.capacity_source === 'administrator_configured' ? limits.context_window_tokens : undefined)
  // A generic default is not a verified host ceiling. The final prepared call
  // owns current capacity; an explicit administrator ceiling may only lower it.
  const hostCapacity = profile.context_window_tokens
  const capacity = hostCapacity ? Math.min(hostCapacity, configuredCapacity ?? hostCapacity) : configuredCapacity
  const outputReserve = Math.max(profile.output_reserve_tokens ?? 0, limits.output_reserve_tokens ?? 8192)
  const protocolMargin = limits.protocol_margin_tokens ?? 2048
  const reserved = outputReserve + protocolMargin
  // Measure the actual message envelope and tool schema. No provider secrets,
  // transport objects or AbortSignals enter this persisted diagnostic.
  const body = { messages: request.messages, tools: request.tools ?? [],
    ...(request.stop ? { stop: request.stop } : {}) }
  const bytes = Buffer.byteLength(JSON.stringify(body), 'utf8')
  const estimated = bytes + 16 * request.messages.length
  const fits = Boolean(capacity && estimated + reserved <= capacity)
  const report = { code: !capacity ? 'MODEL_CONTEXT_METADATA_MISSING' : fits ? 'MODEL_CONTEXT_FITS' : 'MODEL_CONTEXT_LIMIT', category: 'PLANNING_POLICY',
    ...(budget.policy_fingerprint ? { policy_fingerprint: budget.policy_fingerprint } : {}), host_profile: profile,
    capacity_source: hostCapacity ? profile.capacity_metadata_source : configuredCapacity ? 'administrator_configured' : 'unavailable',
    host_context_window_tokens: hostCapacity ?? null, project_context_limit_tokens: configuredCapacity ?? null,
    token_count_method: 'conservative_utf8_byte_upper_estimate', exact_token_count: false,
    serialized_bytes: bytes, estimated_input_tokens: estimated, reserved_tokens: reserved,
    output_reserve_tokens: outputReserve, protocol_margin_tokens: protocolMargin,
    request_fingerprint: createHash('sha256').update(JSON.stringify(body)).digest('hex'),
    measured: estimated + reserved, limit: capacity ?? null, fits,
    ...(!capacity ? { missing_metadata: ['contextWindow'], next_action: { owner: 'host_adapter',
      reason: 'Expose verified model context metadata or an administrator-configured context limit; changing evidence fragments cannot supply host metadata' } } : {}),
    breakdown: { messages: Buffer.byteLength(JSON.stringify(request.messages)), tools: Buffer.byteLength(JSON.stringify(request.tools ?? [])) } }
  return report
}

/** Never resolve credentials: serve calls through the captured host model route. */
export async function hostCompletion(ctx, session, route, params, signal, attempts = 3) {
  if (!route?.provider || !route?.model) throw new Error('HARNESS_UNAVAILABLE: current session has no model route')
  const messages = hostMessages(params.messages, route)
  const tools = (params.tools ?? []).map(t => ({ name: t.function.name,
    description: t.function.description ?? '', parameters: t.function.parameters }))
  if (params.transport_attempt_limit !== undefined) attempts = Math.min(attempts, params.transport_attempt_limit)
  for (let attempt = 1; attempt <= attempts; attempt++) {
    signal.throwIfAborted()
    const prepared = await ctx.llm.prepareCall({ ...route, ...(params.stop?.length ? { stop: params.stop } : {}) }, signal)
    const request = { ...prepared.config, messages, sessionId: session.id, signal,
      ...(tools.length ? { tools } : {}) }
    const budget = measureHostRequest(request, params.planning_budget, prepared.context)
    if (!budget.fits) {
      const error = new Error(budget.code + (budget.code === 'MODEL_CONTEXT_METADATA_MISSING'
        ? ': host model context capacity is unavailable' : ': complete host request exceeds the available context'))
      error.code = budget.code; error.details = { ...budget, model_request_dispatched: false, transport_attempts: 0 }
      session.append('microbiome/model-error', { attempt, code: error.code, error: error.message, budget })
      throw error
    }
    // The host may attach credentials/headers to effective config. Persist only
    // request semantics, never the transport configuration object.
    const record = { provider: route.provider, model: route.model, messages,
      ...(tools.length ? { tools } : {}), ...(request.maxTokens ? { maxTokens: request.maxTokens } : {}),
      ...(request.stop ? { stop: request.stop } : {}) }
    session.append('microbiome/model-request', { attempt, request: record, budget })
    let text = '', usage = {}, finish, failure
    const calls = new Map(), completed = new Map()
    try {
      for await (const chunk of prepared.stream(request)) {
        if (chunk.type === 'text-delta') text += chunk.text
        if (chunk.type === 'block-end') completed.set(chunk.index, chunk.block)
        if (chunk.type === 'tool-call-delta') {
          const c = calls.get(chunk.index) ?? { id: chunk.id, name: '', arguments: '' }
          if (chunk.name) c.name = chunk.name
          c.arguments += chunk.argumentsDelta
          calls.set(chunk.index, c)
        }
        if (chunk.type === 'usage') usage = chunk.usage
        if (chunk.type === 'finish') { finish = chunk.reason; failure = chunk.reason.failure }
        if (Buffer.byteLength(text) + [...calls.values()].reduce((n, c) => n + Buffer.byteLength(c.arguments), 0) > FRAME_LIMIT / 2) throw new Error('Model response exceeds transport limit')
      }
      if (!finish) throw new Error('Model stream ended without a terminal result')
      if (finish.kind === 'error' || finish.kind === 'aborted') {
        const error = new Error(failure?.message ?? 'Model request failed')
        error.code = failure?.code
        throw error
      }
      if (finish.kind === 'max-tokens') {
        const error = new Error('Model response truncated; inspect the host output budget')
        error.code = 'MODEL_OUTPUT_LIMIT'; error.details = { code: error.code, category: 'PLANNING_POLICY', transport_attempts: attempt }
        throw error
      }
      if (!text) text = [...completed.values()].filter(b => b.type === 'text').map(b => b.text).join('')
      for (const [index, block] of completed) if (block.type === 'tool-call') calls.set(index, block)
      const result = { text, usage, planning_budget: budget, transport_attempts: attempt, tool_calls: [...calls.values()].map(c => ({
        id: c.id, name: c.name, args: JSON.parse(c.arguments || '{}'), type: 'tool_call',
      })) }
      session.append('microbiome/model-result', { attempt, result })
      return result
    } catch (error) {
      session.append('microbiome/model-error', { attempt, error: error.message, code: error.code ?? 'MODEL_ERROR', usage })
      const policy = prepared.retryPolicy
      if (signal.aborted || ['MODEL_CONTEXT_LIMIT', 'MODEL_OUTPUT_LIMIT'].includes(error.code) || attempt === attempts ||
          (policy.mode !== 'always' && (!policy.retryableCodes.includes(error.code) || attempt > policy.maxRetries))) throw error
      await delay(Math.min(1000 * 2 ** (attempt - 1), 10000), undefined, { signal })
    }
  }
}

async function* frames(stream) {
  let pending = Buffer.alloc(0)
  for await (const chunk of stream) {
    pending = Buffer.concat([pending, Buffer.from(chunk)])
    let index
    while ((index = pending.indexOf(10)) >= 0) {
      if (index > FRAME_LIMIT) throw new Error('Worker frame exceeds limit')
      const value = JSON.parse(pending.subarray(0, index).toString('utf8'))
      pending = pending.subarray(index + 1)
      if (value.protocol !== 1) throw new Error('Worker protocol version mismatch')
      yield value
    }
    if (pending.length > FRAME_LIMIT) throw new Error('Worker frame exceeds limit')
  }
  if (pending.length) throw new Error('Worker ended with a partial frame')
}

/** Transfer process ownership to ctx.jobs after successful admission. */
export function startWorker(ctx, config, request, agent, route, profile) {
  const abort = new AbortController()
  const child = ctx.subprocess.spawn({ argv: [config.python, '-m', 'microbiome.harness.worker'],
    cwd: config.runtime, env: { MICROBIOME_LLM_TRANSPORT: 'harness', PYTHONUNBUFFERED: '1' },
    stdio: { stdin: 'pipe', stdout: 'pipe', stderr: { maxBytes: 65536 } }, graceMs: 10000, signal: abort.signal })
  child.stdin.on('error', () => {}) // Process settlement reports closed input.
  const send = value => child.stdin.write(JSON.stringify({ protocol: 1, ...value }) + '\n')
  send({ ...request, ...(route ? { host_model_profile: profile ?? hostModelProfile(route) } : {}), expected_capabilities: loadedIdentity })
  let pending = '', result
  const done = (async () => {
    try {
      for await (const frame of frames(child.stdout)) {
        if (frame.type === 'model_request') {
          try {
            const reply = await hostCompletion(ctx, agent.session, route, frame.params, abort.signal, config.modelAttempts)
            send({ type: 'model_response', id: frame.id, result: reply })
          } catch (error) {
            send({ type: 'model_response', id: frame.id, result: { error: error.message, details: error.details } })
          }
        } else if (frame.type === 'progress') {
          pending = bound(pending + JSON.stringify(frame.event) + '\n', config.outputBytes)
        } else if (frame.type === 'result') {
          result = frame.result
          pending = bound(pending + JSON.stringify(result, null, 2), config.outputBytes)
        } else throw new Error('Unknown worker event')
      }
      const outcome = await child.done
      if (!result || outcome.exitCode !== 0 || result.ok === false) {
        if (!result) pending = bound(pending + '\n' + (child.collected.stderr?.readFrom(0).text ?? ''), config.outputBytes)
        return { status: abort.signal.aborted ? 'killed' : 'failed', detail: result?.error ?? 'Worker failed; inspect project state' }
      }
      return { status: 'completed', detail: result.state ?? 'done' }
    } catch (error) {
      pending = bound(pending + '\n' + error.message, config.outputBytes)
      abort.abort()
      await child.done.catch(() => {})
      return { status: 'failed', detail: error.message }
    }
  })()
  return { cancel: () => abort.abort(), done, readOutput: () => { const text = pending; pending = ''; return text } }
}

export async function runReadOnlyOperation(ctx, config, request, signal) {
  const allowed = (request.type === 'maintenance' && (readOperations.has(request.operation) ||
    (request.operation === 'planning_policy' && ['inspect', 'estimate'].includes(request.arguments?.action)))) ||
    (request.type === 'checkpoint' && request.action === 'inspect')
  if (!allowed) throw new Error('INLINE_OPERATION_DENIED: only bounded read operations may run inline')
  const abort = new AbortController(), cancel = () => abort.abort(signal?.reason)
  signal?.throwIfAborted(); signal?.addEventListener('abort', cancel, { once: true })
  const timeout = setTimeout(() => abort.abort(new Error('READ_OPERATION_TIMEOUT')), 20000)
  let child
  try {
    child = ctx.subprocess.spawn({ argv: [config.python, '-m', 'microbiome.harness.worker'], cwd: config.runtime,
      env: { PYTHONUNBUFFERED: '1' }, stdio: { stdin: 'pipe', stdout: 'pipe', stderr: { maxBytes: 4096 } },
      graceMs: 1000, signal: abort.signal })
    child.stdin.on('error', () => {})
    child.stdin.write(JSON.stringify({ protocol: 1, ...request, expected_capabilities: loadedIdentity }) + '\n')
    let result
    for await (const frame of frames(child.stdout)) {
      if (frame.type !== 'result' || result !== undefined || !frame.result ||
          typeof frame.result !== 'object' || Array.isArray(frame.result) || typeof frame.result.ok !== 'boolean')
        throw new Error('INVALID_READ_ONLY_RESPONSE')
      result = frame.result
    }
    const settled = await child.done
    abort.signal.throwIfAborted()
    if (!result || typeof result.ok !== 'boolean' ||
        (settled.exitCode !== 0 && !(settled.exitCode === 1 && result.ok === false)))
      throw new Error('READ_OPERATION_FAILED: worker did not return a completed response')
    return { ...result, delivery: 'inline', status: result.ok ? 'completed' : 'failed' }
  } catch (error) {
    abort.abort(error)
    if (child) await child.done.catch(() => {})
    throw error
  } finally { clearTimeout(timeout); signal?.removeEventListener('abort', cancel) }
}

export function apply(ctx, supplied = {}) {
  const file = path.join(directory, 'runtime.json')
  const config = { ...(fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : {}), ...supplied }
  for (const key of ['python', 'runtime', 'stateDir']) if (!path.isAbsolute(config[key] ?? '')) throw new Error(`Installation needs absolute ${key}; rerun install.sh`)
  if (config.protocol !== 1 || !Number.isInteger(config.modelAttempts) || config.modelAttempts < 1 ||
      !Number.isInteger(config.outputBytes) || config.outputBytes < 4096) throw new Error('Unsupported Microbiome runtime configuration')
  fs.mkdirSync(config.stateDir, { recursive: true, mode: 0o700 })
  const modeTools = new Set(['microbiome_workflow', 'microbiome_project_status', 'microbiome_maintenance', 'microbiome_resume_planning', 'microbiome_capabilities', 'microbiome_database', 'microbiome_checkpoint',
    'job_output', 'job_list', 'job_kill'])
  // A standing preset's allow-list also filters its own tools when inherited
  // by agents. Mask only registered global tools, and guard later additions.
  const inherited = ctx.tools.schemas().map(t => t.name).filter(n => !modeTools.has(n) && n !== 'run_code')
  if (inherited.length) ctx.effect(() => ctx.tools.restrict({ deny: inherited }))
  ctx.effect(() => ctx.tools.guard(exec => modeTools.has(exec.name) ? undefined : '请通过 Microbiome 工作流执行分析并保留确认和冻结校验。'))
  const pending = new Map()
  const bindingFile = agent => path.join(config.stateDir, createHash('sha256').update(agent.session.id).digest('hex') + '.json')
  const render = (_args, result) => [{ type: 'text', text: JSON.stringify(result, null, 2) }]
  const ensureRuntime = async (project, signal) => {
    const actual = await probeCapabilities(ctx, config, project, signal)
    if (!actual.compatibility.compatible) {
      const error = new Error('CAPABILITY_MISMATCH: ' + JSON.stringify(actual.compatibility)); error.details = actual; throw error
    }
    return actual
  }
  ctx.effect(() => ctx.tools.register({ name: 'microbiome_capabilities',
    description: '读取实际加载的插件/后端版本、契约校验值、可用操作、绑定目录和阶段权限；无需项目或模型，不启动分析。开始任务先检查兼容性。',
    parameters: { type: 'object', properties: {}, additionalProperties: false }, output: { schema: {}, render },
    async execute(args, exec) {
      if (Object.keys(args).length) throw new Error('Capabilities takes no arguments')
      const file = exec.agent ? bindingFile(exec.agent) : null
      const project = file && fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')).project : undefined
      const capabilities = await probeCapabilities(ctx, config, project, exec.signal)
      return { ...capabilities, host_workspace: exec.agent ? hostWorkspace(exec.agent) : null }
    },
  }))
  const properties = Object.fromEntries(['project', 'data_dir', 'db_dir', 'download_dir', 'knowledge_dir'].map(k => [k, { type: 'string' }]))
  ctx.effect(() => ctx.tools.register({ name: 'microbiome_workflow',
    description: '处理用户最近一条真实消息：设计生信流程、接受实际确认、预检或冻结全量运行。新项目提供原始数据、数据库和结果项目路径。返回后台任务编号；用宿主任务工具查询。不能传入替用户编写的确认。',
    parameters: { type: 'object', properties, additionalProperties: false }, output: { schema: {}, render },
    async execute(args, exec) {
      if (!exec.agent) throw new Error('Microbiome requires a Harness session')
      for (const [key, value] of Object.entries(args)) if (!(key in properties) || typeof value !== 'string') throw new Error('Invalid workflow argument')
      exec.signal.throwIfAborted()
      const agent = exec.agent, user = latestUser(agent.session), file = bindingFile(agent)
      const prior = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : {}
      const { normalized, workspace, origins } = normalizeWorkflowPaths(args, agent)
      const project = normalized.project ?? prior.project ?? path.join(workspace, '.microbiome', 'project')
      if (!normalized.project && !prior.project) origins.output = 'default'
      if (prior.project && project !== prior.project) throw new Error('Session bound to another project; open a new session')
      if (!prior.project && !fs.existsSync(path.join(project, "project_config.yaml")) &&
          (!normalized.data_dir || !normalized.db_dir)) {
        const missing = ['data_dir', 'db_dir'].filter(key => !normalized[key])
        const error = new Error(`NEEDS_PATHS: missing ${missing.join(', ')}; host workspace is ${workspace}`)
        error.details = { code: 'NEEDS_PATHS', missing_fields: missing, host_workspace: workspace,
          proposed_project: project, supplied_paths: normalized, workspace_is_not_implicitly_raw_data: true }
        throw error
      }
      await ensureRuntime(fs.existsSync(path.join(project, 'project_config.yaml')) ? project : undefined, exec.signal)
      const key = `${agent.session.id}:${user.id}:${project}`
      if (pending.has(key)) return { job_id: pending.get(key), reused: true, project }
      const route = structuredClone(agent.session.requestHeader()?.config ?? agent.options)
      if (!route?.provider || !route?.model) throw new Error('HARNESS_UNAVAILABLE: current session has no model route')
      const profile = await resolveHostModelProfile(ctx, route, exec.signal)
      exec.signal.throwIfAborted()
      if (pending.has(key)) return { job_id: pending.get(key), reused: true, project }
      const historical_context = hostUserHistory(agent.session, user.id)
      const id = ctx.jobs.start({ kind: 'microbiome', label: `Microbiome: ${project}`, owner: agent,
        outputLimitBytes: config.outputBytes,
        run: () => startWorker(ctx, config, { ...normalized, type: 'run', project, session_id: agent.session.id,
          message_id: user.id, message: user.text, historical_context, host_workspace: workspace,
          path_origins: origins }, agent, route, profile) })
      pending.set(key, id)
      const temporary = file + '.' + randomUUID()
      fs.writeFileSync(temporary, JSON.stringify({ project }), { mode: 0o600 })
      fs.renameSync(temporary, file)
      return { job_id: id, project, status: 'started', model: route.model, provider: route.provider }
    },
  }))
  ctx.effect(() => ctx.tools.register({ name: 'microbiome_maintenance',
    description: '检查项目、列绑定目录、读取文件和完整诊断、保存草稿、结构化修正输入、清理登记文件或导出真实会话。维护独立于分析，不触发规划、安装或生产。已有授权范围内直接执行；不得编造用户消息或通过删除项目修复输入错误。',
    parameters: maintenanceSchema, output: { schema: {}, render },
    async execute(args, exec) {
      if (!exec.agent) throw new Error('A Harness session is required')
      validateMaintenance(args)
      exec.signal.throwIfAborted()
      const agent = exec.agent, user = latestUser(agent.session), file = bindingFile(agent)
      if (!fs.existsSync(file)) throw new Error('NEEDS_PROJECT: bind designated project paths first')
      const { project } = JSON.parse(fs.readFileSync(file, 'utf8'))
      await ensureRuntime(project, exec.signal)
      const parameters = structuredClone(args.arguments ?? {})
      const hostEvents = args.operation === 'export' ? structuredClone(conversationEvents(agent.session,
        { pending_call_ids: typeof exec.callId === 'string' ? [exec.callId] : [] })) : undefined
      // Hash exactly the captured safe transcript, not headers or model config.
      // New visible content must produce a new durable export even if a model
      // repeats the same explicit request_id. Other writes keep their identity.
      const snapshotFingerprint = hostEvents ? createHash('sha256').update(JSON.stringify(hostEvents)).digest('hex') : undefined
      if (hostEvents) hostEvents.at(-1).snapshot_fingerprint = snapshotFingerprint
      const identityParts = [agent.session.id, user.id, args.operation, parameters]
      if (snapshotFingerprint) identityParts.push(snapshotFingerprint)
      const identity = createHash('sha256').update(JSON.stringify(identityParts)).digest('hex')
      if (hostEvents) parameters.request_id = identity
      else parameters.request_id ??= identity
      const request = { type: 'maintenance', project, session_id: agent.session.id,
        message_id: user.id, message: user.text, operation: args.operation, arguments: parameters }
      const readOnly = readOperations.has(args.operation) ||
        (args.operation === 'planning_policy' && ['inspect', 'estimate'].includes(parameters.action))
      if (readOnly) return runReadOnlyOperation(ctx, config, request, exec.signal)
      const key = `${agent.session.id}:maintenance:${identity}:${project}`
      const snapshot = snapshotFingerprint ? { snapshot_fingerprint: snapshotFingerprint } : {}
      if (pending.has(key)) return { job_id: pending.get(key), reused: true, project, ...snapshot }
      if (hostEvents) request.host_events = hostEvents
      // Maintenance is local and deterministic; it must work without a model route.
      const id = ctx.jobs.start({ kind: 'microbiome', label: `Microbiome ${args.operation}: ${project}`, owner: agent,
        outputLimitBytes: Math.max(config.outputBytes, 1024 * 1024), run: () => {
          const worker = startWorker(ctx, { ...config, outputBytes: Math.max(config.outputBytes, 1024 * 1024) }, request, agent, null)
          worker.done.then(outcome => {
            // A failed admission is retryable; short reads are handled inline.
            if (outcome.status !== 'completed' && pending.get(key) === id) pending.delete(key)
          }, () => { if (pending.get(key) === id) pending.delete(key) })
          return worker
        } })
      pending.set(key, id)
      return { job_id: id, project, operation: args.operation, status: 'started', ...snapshot }
    },
  }))
  ctx.effect(() => ctx.tools.register({ name: 'microbiome_resume_planning',
    description: '在输入或内部结构错误修复后，沿用持久事实恢复规划。先 inspect 获取 recovery_token；无需用户重复发言。只返回待审阅方案，不重放确认、预检或生产。相同证据只尝试一次。',
    parameters: { type: 'object', properties: { recovery_token: { type: 'string', pattern: '^[a-f0-9]{64}$' } }, required: ['recovery_token'], additionalProperties: false },
    output: { schema: {}, render },
    async execute(args, exec) {
      if (!exec.agent) throw new Error('A Harness session is required')
      if (Object.keys(args).some(k => k !== 'recovery_token') || !/^[a-f0-9]{64}$/.test(args.recovery_token ?? '')) throw new Error('Invalid recovery token')
      exec.signal.throwIfAborted()
      const agent = exec.agent, user = latestUser(agent.session), file = bindingFile(agent)
      if (!fs.existsSync(file)) throw new Error('NEEDS_PROJECT: bind the existing project first')
      const { project } = JSON.parse(fs.readFileSync(file, 'utf8'))
      await ensureRuntime(project, exec.signal)
      const key = `${agent.session.id}:planning-recovery:${project}:${args.recovery_token}`
      if (pending.has(key)) return { job_id: pending.get(key), project, reused: true }
      const route = structuredClone(agent.session.requestHeader()?.config ?? agent.options)
      if (!route?.provider || !route?.model) throw new Error('HARNESS_UNAVAILABLE: current session has no model route')
      const profile = await resolveHostModelProfile(ctx, route, exec.signal)
      exec.signal.throwIfAborted()
      if (pending.has(key)) return { job_id: pending.get(key), project, reused: true }
      const request = { type: 'resume_planning', project, recovery_token: args.recovery_token,
        session_id: agent.session.id, message_id: user.id, message: user.text }
      const id = ctx.jobs.start({ kind: 'microbiome', label: `Microbiome planning recovery: ${project}`, owner: agent,
        outputLimitBytes: config.outputBytes, run: () => {
          const worker = startWorker(ctx, config, request, agent, route, profile)
          worker.done.then(outcome => {
            if (outcome.status !== 'completed' && pending.get(key) === id) pending.delete(key)
          }, () => { if (pending.get(key) === id) pending.delete(key) })
          return worker
        } })
      pending.set(key, id)
      return { job_id: id, project, status: 'started', scope: 'planning_only' }
    },
  }))
  ctx.effect(() => ctx.tools.register({ name: 'microbiome_database',
    description: '在绑定数据库根内发现候选、核验现有文件、检查可信注册或在现有批准范围内绑定。discover/inspect只读，validate仅保存验证回执；bind受阶段与依赖批准约束。不会下载或让模型直接改注册表。',
    parameters: databaseSchema, output: { schema: {}, render },
    async execute(args, exec) {
      if (!exec.agent) throw new Error('A Harness session is required')
      const errors = schemaErrors(databaseSchema, args)
      if (errors.length) throw new Error('Invalid database arguments: ' + JSON.stringify(errors))
      const agent = exec.agent, user = latestUser(agent.session), file = bindingFile(agent)
      if (!fs.existsSync(file)) throw new Error('NEEDS_PROJECT: bind the existing project first')
      const { project } = JSON.parse(fs.readFileSync(file, 'utf8'))
      await ensureRuntime(project, exec.signal)
      const identity = createHash('sha256').update(JSON.stringify([agent.session.id, user.id, args])).digest('hex')
      const key = `database:${project}:${identity}`
      if (pending.has(key)) return { job_id: pending.get(key), project, reused: true }
      const request = { type: 'database', project, session_id: agent.session.id, message_id: user.id, message: user.text,
        operation: args.operation, arguments: args.arguments ?? {} }
      const id = ctx.jobs.start({ kind: 'microbiome', label: `Microbiome database ${args.operation}: ${project}`, owner: agent,
        outputLimitBytes: Math.max(config.outputBytes, 1024 * 1024), run: () => {
          const worker = startWorker(ctx, { ...config, outputBytes: Math.max(config.outputBytes, 1024 * 1024) }, request, agent, null)
          const release = () => { if (pending.get(key) === id) pending.delete(key) }
          worker.done.then(release, release)
          return worker
        } })
      pending.set(key, id)
      return { job_id: id, project, operation: args.operation, status: 'started' }
    },
  }))
  ctx.effect(() => ctx.tools.register({ name: 'microbiome_checkpoint',
    description: '审阅当前预检方案或冻结生产快照。inspect 仅需 action/checkpoint，返回完整审阅材料及指纹；confirm 必须提供 review_fingerprint、authorization_fingerprint 和 reason；execute 必须复用已确认的 review_fingerprint，不能带授权或理由字段。confirm 成功后按返回的 next_action 执行，无需再次 inspect 同一预检。仅使用项目已有真实宿主委托，不能创建授权或替用户确认。',
    parameters: { type: 'object', properties: {
      action: { type: 'string', enum: ['inspect', 'confirm', 'execute'] },
      checkpoint: { type: 'string', enum: ['pretest', 'production'] },
      review_fingerprint: { type: 'string', pattern: '^[a-f0-9]{64}$', description: 'confirm 和 execute 必填；来自当前 inspect，并在 confirm 后原样传给 execute。inspect 时不得传入。' },
      authorization_fingerprint: { type: 'string', pattern: '^[a-f0-9]{64}$', description: '仅 confirm 必填；引用项目已有真实委托。' },
      reason: { type: 'string', minLength: 1, maxLength: 4000, description: '仅 confirm 必填；说明对本次完整审阅材料的判断。' },
    }, required: ['action', 'checkpoint'], additionalProperties: false,
    oneOf: [
      { properties: { action: { const: 'inspect' } }, not: { anyOf: [
        { required: ['review_fingerprint'] }, { required: ['authorization_fingerprint'] }, { required: ['reason'] }] } },
      { properties: { action: { const: 'confirm' } }, required: ['review_fingerprint', 'authorization_fingerprint', 'reason'] },
      { properties: { action: { const: 'execute' } }, required: ['review_fingerprint'], not: { anyOf: [
        { required: ['authorization_fingerprint'] }, { required: ['reason'] }] } },
    ] }, output: { schema: {}, render },
    async execute(args, exec) {
      if (!exec.agent) throw new Error('A Harness session is required')
      const allowed = ['action', 'checkpoint', 'review_fingerprint', 'authorization_fingerprint', 'reason']
      if (Object.keys(args).some(key => !allowed.includes(key)) ||
          !['inspect', 'confirm', 'execute'].includes(args.action) || !['pretest', 'production'].includes(args.checkpoint))
        throw new Error('Invalid checkpoint arguments')
      if (args.action === 'inspect' && Object.keys(args).some(key => !['action', 'checkpoint'].includes(key)))
        throw new Error('Checkpoint inspect takes only action and checkpoint')
      if (args.action !== 'inspect' && !/^[a-f0-9]{64}$/.test(args.review_fingerprint ?? ''))
        throw new Error('Checkpoint requires the current review_fingerprint')
      if (args.action === 'confirm' && (!/^[a-f0-9]{64}$/.test(args.authorization_fingerprint ?? '') ||
          typeof args.reason !== 'string' || !args.reason.trim() || args.reason.length > 4000))
        throw new Error('Checkpoint confirmation requires existing authorization and a review reason')
      if (args.action === 'execute' && (args.authorization_fingerprint !== undefined || args.reason !== undefined))
        throw new Error('Checkpoint execution consumes an existing decision, not new approval fields')
      exec.signal.throwIfAborted()
      const agent = exec.agent, user = latestUser(agent.session), file = bindingFile(agent)
      if (!fs.existsSync(file)) throw new Error('NEEDS_PROJECT: bind the existing project first')
      const { project } = JSON.parse(fs.readFileSync(file, 'utf8'))
      await ensureRuntime(project, exec.signal)
      const identity = createHash('sha256').update(JSON.stringify([agent.session.id, user.id, args])).digest('hex')
      const request = { type: 'checkpoint', ...args, project, session_id: agent.session.id,
        message_id: user.id, message: user.text, request_id: identity }
      if (args.action === 'inspect') return runReadOnlyOperation(ctx, config, request, exec.signal)
      const key = `checkpoint:${project}:${identity}`
      if (pending.has(key)) return { job_id: pending.get(key), project, reused: true }
      // Reviewed checkpoint execution consumes persisted contracts only.
      exec.signal.throwIfAborted()
      if (pending.has(key)) return { job_id: pending.get(key), project, reused: true }
      const id = ctx.jobs.start({ kind: 'microbiome', label: `Microbiome ${args.checkpoint} ${args.action}: ${project}`, owner: agent,
        outputLimitBytes: Math.max(config.outputBytes, 1024 * 1024), run: () => {
          const worker = startWorker(ctx, { ...config, outputBytes: Math.max(config.outputBytes, 1024 * 1024) }, request, agent, null)
          worker.done.then(outcome => { if (outcome.status !== 'completed' && pending.get(key) === id) pending.delete(key) },
            () => { if (pending.get(key) === id) pending.delete(key) })
          return worker
        } })
      pending.set(key, id)
      return { job_id: id, project, checkpoint: args.checkpoint, action: args.action, status: 'started' }
    },
  }))
  ctx.effect(() => ctx.tools.register({ name: 'microbiome_project_status',
    description: '读取本会话生信项目的阶段、路径和结果报告，不启动分析或安装。',
    parameters: { type: 'object', properties: {}, additionalProperties: false }, output: { schema: {}, render },
    async execute(_args, exec) {
      if (!exec.agent) throw new Error('A Harness session is required')
      const file = bindingFile(exec.agent)
      if (!fs.existsSync(file)) return { status: 'unbound', host_workspace: hostWorkspace(exec.agent),
        missing_fields: ['data_dir', 'db_dir'], message: '当前工作区已知；尚未绑定原始数据和持久数据库目录。工作区路径本身不代表输入授权。' }
      const { project } = JSON.parse(fs.readFileSync(file, 'utf8'))
      const capabilities = await ensureRuntime(project, exec.signal)
      const snapshotFile = path.join(project, '.microbiome-harness-status.json')
      const snapshot = fs.existsSync(snapshotFile) ? JSON.parse(fs.readFileSync(snapshotFile, 'utf8')) : {}
      const outputRoot = snapshot.output_root ?? project
      const read = (relative, root = project) => {
        const p = path.join(root, relative)
        return fs.existsSync(p) ? bound(fs.readFileSync(p, 'utf8'), config.outputBytes) : null
      }
      return { project, capabilities, paths: read('project_config.yaml'), state: read('project_state.yaml', outputRoot),
        diagnostic_reader: { tool: 'microbiome_maintenance', operation: 'read_diagnostic', arguments: { diagnostic_id: 'input_resolution' } },
        requirement_draft: read('requirements/requirements_draft.json', outputRoot),
        maintenance: { tool: 'microbiome_maintenance', operations: operationNames },
        reports: fs.existsSync(path.join(outputRoot, 'reports')) ? fs.readdirSync(path.join(outputRoot, 'reports')) : [],
        recovery: '先用 maintenance inspect 读取当前阻塞与 planning_recovery；读取文件用 list_directory/read_artifact/read_diagnostic。修复后以 recovery_token 调用 microbiome_resume_planning，无需再次发送用户消息。历史诊断不等于当前错误。' }
    },
  }))
}
