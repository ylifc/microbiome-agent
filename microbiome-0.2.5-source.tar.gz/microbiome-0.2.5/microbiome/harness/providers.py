"""One model adapter for configured providers, budgets and structured output."""

from pydantic import PrivateAttr

from microbiome.harness.context import prepare_context
from microbiome.harness.model import HarnessChatModel
from microbiome.harness.settings import PROVIDERS, ModelConfig


class ManagedChatModel(HarnessChatModel):
    _backend = PrivateAttr(default=None)
    _settings = PrivateAttr()
    _state = PrivateAttr(default=None)
    _record = PrivateAttr(default=None)
    _capacity = PrivateAttr(default=None)

    def __init__(self, settings: ModelConfig, *, state=None, record=None, backend=None):
        super().__init__(lambda _: None)
        self._settings, self._state, self._record, self._backend = settings, state, record, backend

    @property
    def _llm_type(self):
        return "biomni-managed-" + self._settings.provider

    def _generate(self, messages, stop=None, run_manager=None, **kwargs):
        from langchain_core.outputs import ChatGeneration, ChatResult

        from microbiome.llm import get_llm

        config = self._settings
        if any(
            key in kwargs
            for key in (
                "model",
                "api_key",
                "base_url",
                "max_completion_tokens",
                "max_output_tokens",
                "num_predict",
                "num_ctx",
                "options",
            )
        ):
            raise ValueError("Provider settings and budget aliases cannot override the frozen model configuration")
        requested = kwargs.pop("max_tokens", config.max_tokens)
        if not isinstance(requested, int) or requested <= 0:
            raise ValueError("max_tokens must be a positive integer")
        maximum = min(requested, config.max_tokens)
        if self._capacity is None:
            from microbiome.harness.capabilities import context_capacity

            self._capacity = context_capacity(config)
        prepared, report = prepare_context(
            messages,
            context_length=self._capacity["context_length"],
            max_tokens=maximum,
            tools=kwargs.get("tools"),
            state=self._state() if callable(self._state) else self._state,
        )
        report["capacity_source"] = self._capacity["source"]
        if self._record:
            self._record(report)
        if self._backend is None:
            if config.provider in {"openai", "anthropic", "deepseek"} and not config.resolved_key():
                raise ValueError(f"Configure an API key for {config.provider} before requesting the model")
            self._backend = get_llm(
                model=config.model,
                source=PROVIDERS[config.provider],
                base_url=config.base_url,
                api_key=config.resolved_key(),
                temperature=config.temperature,
                max_tokens=config.max_tokens,
                context_length=config.context_length,
                prefer_host=False,
            )
        # Native Ollama uses num_predict for the output bound.
        budget = (
            {
                "options": {
                    "num_predict": maximum,
                    "num_ctx": self._capacity["context_length"],
                    "temperature": config.temperature,
                    **({"stop": stop} if stop else {}),
                }
            }
            if config.provider == "ollama"
            else {"max_tokens": maximum}
        )
        reply = self._backend.invoke(prepared, stop=stop, **budget, **kwargs)
        finish = reply.response_metadata.get("finish_reason") or reply.response_metadata.get("stop_reason")
        if finish in {"length", "max_tokens"} or reply.response_metadata.get("done_reason") == "length":
            raise ValueError("Model response truncated; increase output budget before retrying")
        if not reply.content and not reply.tool_calls:
            raise ValueError("Model returned an empty response")
        return ChatResult(generations=[ChatGeneration(message=reply)])


def create_model(config, **kwargs):
    return ManagedChatModel(config if isinstance(config, ModelConfig) else ModelConfig.model_validate(config), **kwargs)
