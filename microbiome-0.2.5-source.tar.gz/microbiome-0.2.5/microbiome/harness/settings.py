"""Versioned, portable model configuration. Secrets never enter public snapshots."""

from __future__ import annotations

import json
import os
import re
import tempfile
from pathlib import Path
from urllib.parse import urlparse

from pydantic import BaseModel, ConfigDict, Field, model_validator

PROVIDERS = {
    "openai": "OpenAI",
    "anthropic": "Anthropic",
    "deepseek": "DeepSeek",
    "openai-compatible": "Custom",
    "ollama": "Ollama",
}
KEY_ENV = {
    "openai": "OPENAI_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
    "deepseek": "DEEPSEEK_API_KEY",
    "openai-compatible": "OPENAI_API_KEY",
}


class ModelConfig(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    provider: str
    model: str = Field(min_length=1)
    base_url: str | None = None
    api_key: str | None = Field(default=None, repr=False)
    context_length: int = Field(default=65536, ge=512, le=10_000_000)
    temperature: float = Field(default=0.7, ge=0, le=2)
    max_tokens: int = Field(default=8192, ge=1)

    @model_validator(mode="after")
    def validate_contract(self):
        if self.provider not in PROVIDERS:
            raise ValueError(f"provider must be one of {', '.join(PROVIDERS)}")
        if not self.model.strip() or self.max_tokens + 256 >= self.context_length:
            raise ValueError("model is required and context_length must exceed max_tokens + 256")
        if self.provider == "openai-compatible" and not self.base_url:
            raise ValueError("openai-compatible requires base_url")
        if self.base_url:
            url = urlparse(self.base_url)
            if (
                url.scheme not in {"http", "https"}
                or not url.hostname
                or url.username
                or url.password
                or url.query
                or url.fragment
            ):
                raise ValueError("base_url must be an HTTP(S) URL without credentials, query or fragment")
        return self

    def resolved_key(self):
        value = self.api_key
        if value and (match := re.fullmatch(r"\$\{([A-Z][A-Z0-9_]*)\}", value)):
            value = os.environ.get(match[1])
        return value or os.environ.get(KEY_ENV.get(self.provider, "BIOMNI_NO_KEY"))

    def public(self):
        value = self.model_dump(exclude={"api_key"})
        value["api_key_configured"] = bool(self.resolved_key())
        value["api_key"] = ""  # An empty GUI update preserves the existing secret.
        return value


class HarnessConfig(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    schema_version: int = 1
    active_model: str = "local"
    models: dict[str, ModelConfig] = Field(
        default_factory=lambda: {
            "local": ModelConfig(provider="ollama", model="qwen3:8b", temperature=0.7),
        }
    )
    integrations: dict[str, dict] = Field(default_factory=dict)

    @model_validator(mode="after")
    def validate_active(self):
        if self.schema_version != 1 or self.active_model not in self.models:
            raise ValueError("schema_version must be 1 and active_model must name a configured profile")
        if any(not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", name) for name in self.models):
            raise ValueError("profile names must contain only letters, digits, underscores and hyphens")
        return self

    def public(self):
        return {
            "schema_version": 1,
            "active_model": self.active_model,
            "models": {name: model.public() for name, model in self.models.items()},
            "integrations": {name: {"configured": bool(value)} for name, value in self.integrations.items()},
        }


def user_home():
    return Path(os.environ.get("BIOMNI_HOME", "~/.local/share/biomni")).expanduser().resolve()


def config_path():
    return user_home() / "config.json"


def load_config(path=None):
    target = Path(path or config_path())
    return HarnessConfig.model_validate(json.loads(target.read_text())) if target.is_file() else HarnessConfig()


def save_config(config, path=None):
    target = Path(path or config_path())
    target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    descriptor, temporary = tempfile.mkstemp(prefix=".config-", dir=target.parent)
    try:
        with os.fdopen(descriptor, "w") as stream:
            stream.write(config.model_dump_json(indent=2) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, target)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    return target
