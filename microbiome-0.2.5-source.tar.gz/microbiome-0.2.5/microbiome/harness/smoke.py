"""Explicit synthetic installation acceptance: real pilot, frozen replay and cohort counts."""
import argparse
import copy
import json
from pathlib import Path
import sys
from types import SimpleNamespace


def exercise(root):
    from microbiome.agent.workflow import ConversationWorkflow
    from microbiome.pipeline.approval import ProductionController
    from microbiome.pipeline.project import PipelineProject
    from microbiome.pipeline.io import read_json
    root = Path(root).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=False)
    raw = root / "raw"
    raw.mkdir()
    for name, count in (("one", 20), ("two", 30)):
        (raw / f"{name}.fastq").write_text("".join(f"@{name}{i}\nACGT\n+\nIIII\n" for i in range(count)))
    project = PipelineProject.initialize(root / "project", raw_data_path=raw,
        database_path=root / "db", output_path=root / "out", download_path=root / "downloads")
    workflow = ConversationWorkflow(project)
    workflow._resolve(str(raw))
    step = {"step_id": "copy_reads", "scope": "sample", "purpose": "copy synthetic reads",
            "tool": "cp", "tool_version_requirement": "any", "environment": {"executable": "cp", "version_args": ["--version"]},
            "input": {"reads": "{runtime.reads}"}, "output": {"copied": "{run_dir}/{sample_id}.fastq"},
            "database": {}, "command_template": ["{executable}", "{input.reads}", "{output.copied}"],
            "parameters": [], "dependencies": [], "success_criteria": ["exists:output.copied", "non_empty:output.copied",
                {"type": "parseable", "target": "output.copied", "format": "fastq"}],
            "failure_criteria": ["nonzero_exit"], "threads_policy": {"min": 1, "max": 1, "default": 1},
            "memory_policy": {"max_gb": 1}, "gpu_policy": {"enabled": False, "min": 0, "max": 0}}
    summary = copy.deepcopy(step)
    summary.update(step_id="cohort_qc", scope="cohort", tool="python", purpose="count synthetic reads by sample",
        environment={"executable": sys.executable}, input={}, output={"counts": "{run_dir}/cohort-counts.tsv"},
        command_template=["{executable}", "asset://cohort_tables.py", "qc-counts", "--inputs", "{cohort.copy_reads.copied}",
                          "--sample-ids", "{cohort.sample_ids}", "--output", "{output.counts}"],
        dependencies=["copy_reads"], success_criteria=["non_empty:output.counts",
            {"type": "table_columns", "target": "output.counts", "columns": ["sample_id", "reads"]}])
    payload = {"requirements": {"input": {"type": "single_end"}, "dataset": {"sample_count": 2},
        "target": {"scope": "synthetic reads"}, "analysis_goal": {"objective": "installation acceptance"}},
        "comparative_analysis": False, "plan": {"objective": "Synthetic installation acceptance", "execution_scope": "cohort",
        "steps": [step, summary], "deliverables": [{"name": "read count audit", "step_id": "cohort_qc", "output": "counts",
        "purpose": "installation acceptance"}]}}
    workflow.stage(payload, "Synthetic installation acceptance only: copy 2 files and count records.")
    # This command is an explicitly requested, fixed synthetic test, never a user analysis auto-approval.
    workflow.approve("确认执行")
    events = list(workflow.run_pilot(SimpleNamespace()))
    if not project.pipeline_lock_path.is_file():
        raise RuntimeError(f"Pilot did not freeze: {events}")
    suite = read_json(project.pipeline_dir / "validation_suite.json")
    result = ProductionController(project).handle_user_message("确认全量执行", run_id="installation-smoke")
    if result["status"] != "COMPLETED":
        raise RuntimeError(f"Frozen replay failed: {result}")
    output = Path(result["manifest"]["runs"][0]["outputs_path"])
    counts = next(output.rglob("cohort-counts.tsv")).read_text()
    if "one\t20" not in counts or "two\t30" not in counts:
        raise RuntimeError(f"Wrong cohort counts: {counts}")
    resumed = ProductionController(project).handle_user_message("确认全量执行", run_id="installation-smoke", resume=True)
    return {"ok": resumed["status"] == "COMPLETED", "suite": suite["status"], "counts": counts,
            "project": str(project.root), "report": result["manifest"]["final_report"]["markdown"],
            "scope": "synthetic filesystem/pipeline acceptance; no biological tools, databases or remote model tested"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", required=True, help="A NEW directory; existing directories are refused")
    args = parser.parse_args()
    print(json.dumps(exercise(args.directory), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
