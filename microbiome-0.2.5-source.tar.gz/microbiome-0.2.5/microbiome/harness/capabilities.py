"""Read provider-advertised capacity when available; never infer it from a model name."""

import os
from urllib.parse import urlparse


def context_capacity(config):
    report = {"context_length": config.context_length, "source": "configured_conservative_cap"}
    if config.provider != "ollama":
        return report
    try:
        from ollama import Client

        url = (
            (config.base_url or os.getenv("OLLAMA_BASE_URL") or "http://127.0.0.1:11434")
            .rstrip("/")
            .removesuffix("/v1")
        )
        client = Client(host=url, timeout=2, trust_env=urlparse(url).hostname not in {"127.0.0.1", "localhost", "::1"})
        try:
            info = client.show(config.model).model_info or {}
        finally:
            client._client.close()
        values = [v for k, v in info.items() if k.endswith(".context_length") and type(v) is int and v >= 512]
        if values:
            report = {
                "context_length": min(config.context_length, min(values)),
                "source": "ollama_metadata_capped_by_configuration",
            }
    except Exception:
        # Metadata absence never authorizes model downloads or expansion of the configured cap.
        pass
    return report
