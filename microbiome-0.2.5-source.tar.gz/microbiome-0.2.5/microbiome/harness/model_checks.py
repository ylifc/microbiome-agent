"""Explicit model discovery/probes; never pull or install a model."""

import os
from urllib.parse import urlparse

from microbiome.harness.conversations import ConversationError
from microbiome.harness.settings import load_config


def ollama_models(config_file, profile=None):
    from ollama import Client

    config = load_config(config_file)
    model = config.models[profile or config.active_model]
    if model.provider != "ollama":
        raise ConversationError("请先选择 Ollama 模型配置。")
    url = (model.base_url or os.getenv("OLLAMA_BASE_URL") or "http://127.0.0.1:11434").rstrip("/").removesuffix("/v1")
    client = Client(host=url, timeout=10, trust_env=urlparse(url).hostname not in {"127.0.0.1", "localhost", "::1"})
    try:
        entries = client.list().models
        return {
            "models": [entry.model for entry in entries],
            "selected": model.model,
            "available": any(entry.model == model.model or entry.model == model.model + ":latest" for entry in entries),
        }
    except Exception:
        raise ConversationError("无法读取 Ollama 模型列表，请检查服务地址与服务状态。") from None
    finally:
        client._client.close()


def probe_model(config_file, profile=None):
    from microbiome.harness.providers import create_model

    config = load_config(config_file)
    model = config.models[profile or config.active_model]
    try:
        reply = create_model(model).invoke("这是对话连通测试。请只回复：连接成功。")
        return {"ok": True, "model": model.model, "reply": reply.content}
    except Exception:
        raise ConversationError(
            "模型测试失败，请检查模型是否已安装、服务地址、密钥和输出预算。未下载或更改模型。"
        ) from None
