"""Narrow optional HTTP discovery. Never registers, publishes or executes assets."""

from __future__ import annotations

import hashlib
import ipaddress
import json
import os
import random
import re
import socket
import time
from pathlib import Path

import requests

from microbiome.harness.integrations.common import engineering_snapshot


class EvoMapAdapter:
    endpoint = "https://evomap.ai"

    def __init__(
        self,
        quarantine,
        *,
        enabled=False,
        authorized=False,
        max_requests=3,
        timeout=8,
        cache_ttl=600,
        token_env="EVOMAP_NODE_SECRET",
        transport=None,
    ):
        self.root = Path(quarantine)
        self.enabled, self.authorized = enabled, authorized
        if not 1 <= max_requests <= 5 or not 1 <= timeout <= 15:
            raise ValueError("EvoMap request budget exceeds allowed limits")
        self.remaining, self.timeout, self.cache_ttl = max_requests, timeout, cache_ttl
        self.token_env, self.transport, self.failures = token_env, transport, 0
        self.cache = {}

    def _get(self, path, params):
        if not self.enabled or not self.authorized:
            return {"status": "disabled"}
        if self.failures >= 3:
            return {"status": "circuit_open"}
        cache_key = json.dumps([path, params], sort_keys=True)
        if cache_key in self.cache and time.monotonic() - self.cache[cache_key][0] < self.cache_ttl:
            return self.cache[cache_key][1]
        while self.remaining:
            self.remaining -= 1
            try:
                if self.transport is None:
                    addresses = socket.getaddrinfo("evomap.ai", 443, type=socket.SOCK_STREAM)
                    if not addresses or any(not ipaddress.ip_address(row[4][0]).is_global for row in addresses):
                        raise ValueError("Hub resolved to a non-public address")
                headers = {"Accept": "application/json"}
                secret = os.environ.get(self.token_env)
                if secret:
                    headers["Authorization"] = "Bearer " + secret
                session = self.transport or requests.Session()
                if self.transport is None:
                    session.trust_env = False
                with session.get(
                    self.endpoint + path,
                    params=params,
                    headers=headers,
                    timeout=self.timeout,
                    allow_redirects=False,
                    stream=True,
                ) as response:
                    if response.status_code in (401, 403):
                        return {"status": "authentication_failed", "credential_configured": bool(secret)}
                    if 300 <= response.status_code < 400:
                        return {"status": "redirect_rejected"}
                    if response.status_code == 429:
                        self.failures += 1
                        wait = response.headers.get("Retry-After", "1")
                        if not wait.isdigit() or int(wait) > 5 or not self.remaining:
                            return {"status": "rate_limited"}
                        time.sleep(min(5, max(int(wait), 2 ** (self.failures - 1)) + random.random() / 4))
                        continue
                    response.raise_for_status()
                    if "application/json" not in response.headers.get("Content-Type", ""):
                        return {"status": "content_type_rejected"}
                    content = bytearray()
                    for chunk in response.iter_content(16384):
                        content.extend(chunk)
                        if len(content) > 256_000:
                            return {"status": "content_too_large"}
                    payload = json.loads(content)
                if not isinstance(payload, (dict, list)):
                    return {"status": "format_changed"}
                # The pinned public search documentation does not define a pagination cursor.
                # Never follow a server-supplied next URL to an unapproved route or host.
                if isinstance(payload, dict) and any(k in payload for k in ("next", "next_url", "next_cursor")):
                    return {"status": "pagination_unsupported", "payload": payload}
                result = {
                    "status": "success",
                    "payload": payload,
                    "source_url": self.endpoint + path,
                    "credential_configured": bool(secret),
                    "authentication": "not_proven_public_endpoint",
                }
                self.cache[cache_key] = time.monotonic(), result
                return result
            except (requests.RequestException, ValueError, OSError):
                self.failures += 1
                return {"status": "unavailable", "fallback": "local_only"}
        return {"status": "budget_exhausted"}

    def query(self, snapshot, *, local_insufficient=False):
        if not local_insufficient:
            return {"status": "local_experience_preferred"}
        facts = engineering_snapshot(snapshot)
        return self._get("/a2a/assets/search", {"signals": facts["error_code"], "status": "promoted", "limit": 10})

    def fetch_selected(self, asset_id):
        if not re.fullmatch(r"sha256:[0-9a-f]{64}", asset_id):
            raise ValueError("An explicit content-addressed asset ID is required")
        # Metadata only: detailed/content-fetch purchases are outside this client's authority.
        result = self._get("/a2a/assets/" + asset_id, {})
        if result.get("status") != "success":
            return result
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
        payload = result["payload"]
        body = json.dumps(payload, sort_keys=True, ensure_ascii=False)
        metadata = payload.get("asset", payload) if isinstance(payload, dict) else {}
        if not isinstance(metadata, dict):
            return {"status": "format_changed"}
        status = "quarantined" if metadata.get("license") and metadata.get("version") else "incomplete_metadata"
        record = {
            "status": status,
            "source_url": result["source_url"],
            "asset_id": asset_id,
            "body_sha256": hashlib.sha256(body.encode()).hexdigest(),
            "source_object": payload,
            "license": metadata.get("license"),
            "version": metadata.get("version"),
            "source_type": metadata.get("type"),
            "applicable_environment": metadata.get("environment"),
            "platform_claims": {key: metadata.get(key) for key in ("validated", "gdi", "verification")},
            "local_validation": "NOT_VALIDATED",
            "execution_authority": False,
        }
        path = self.root / (asset_id.split(":")[1] + ".json")
        path.write_text(json.dumps(record, ensure_ascii=False, indent=2))
        return {**record, "quarantine_path": str(path)}

    def to_proposal(self, record, *, baseline_version, reviewed_candidate):
        """Only an explicitly reviewed engineering candidate may enter the common validator.

        The raw Gene/Capsule and platform claims remain in quarantine. No extraction,
        installation, code preview execution or implicit metadata completion occurs.
        """
        from microbiome.harness.proposals import Proposal

        if record.get("status") != "quarantined" or not record.get("license") or not record.get("version"):
            return {"status": "rejected", "reason": "incomplete_metadata"}
        if record.get("source_type") not in {"Gene", "Capsule"}:
            return {"status": "rejected", "reason": "unsupported_source_type"}
        try:
            proposal = Proposal(
                source=record["source_url"] + "@" + str(record["version"]),
                baseline_version=baseline_version,
                target_files=list(reviewed_candidate),
                intent="Independently evaluate reviewed external engineering guidance",
                preconditions=["synthetic engineering task only", "license and environment review required"],
                candidate_content=reviewed_candidate,
                evidence=[record["quarantine_path"]],
                expected_risk="untrusted external experience",
                expected_cost={"model_calls": 0.0},
                validation_plan="Frozen local correctness and regression gates; platform labels confer no authority",
            )
            return {"status": "proposed", "proposal": proposal.model_dump()}
        except (ValueError, KeyError, TypeError):
            return {"status": "rejected", "reason": "candidate_contract"}

    def prepare_export(self, snapshot):
        payload = engineering_snapshot(snapshot)
        return {
            "status": "prepared_only",
            "payload": payload,
            "sha256": hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest(),
            "estimated_cost": "UNKNOWN",
            "publish_authorized": False,
        }
