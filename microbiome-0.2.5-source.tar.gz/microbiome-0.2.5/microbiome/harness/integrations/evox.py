"""SkyDiscover EvoX boundary. Startup/dry-run are distinct from an authorized search."""

from __future__ import annotations

import hashlib
import json
import subprocess
import tempfile
from pathlib import Path

from microbiome.harness.integrations.common import verify_source
from microbiome.harness.proposals import OptimizationTask


class SearchAdapter:
    """Fail closed until the upstream search and model broker are independently validated.

    Never substitutes an in-house candidate loop for upstream EvoX. The independent
    CandidateValidator is usable on agent proposals without claiming an EvoX search.
    """

    def __init__(self, source_dir=None, python=None, *, enabled=False):
        self.source_dir, self.python, self.enabled = source_dir, python, enabled

    def prepare(self, task: OptimizationTask, model_config, archive):
        root = Path(archive)
        root.mkdir(parents=True, exist_ok=True)
        # No credentials, raw data or evaluator/heldout content in this upstream-facing plan.
        plan = {
            "task": task.model_dump(mode="json"),
            "model": model_config.model_dump(exclude={"api_key"}),
            "upstream": "skydiscover.optimize.api.run_discovery",
            "search": "evox",
            "config": {
                "max_iterations": task.max_candidates,
                "checkpoint_interval": 1,
                "evaluator": {"inject_evaluator_context": False},
            },
            "network": "model broker required; candidates always offline",
            "state": "DRY_RUN",
            "production_write": False,
        }
        identity = hashlib.sha256(json.dumps(plan, sort_keys=True).encode()).hexdigest()
        path = root / "search-state.json"
        if path.is_file():
            old = json.loads(path.read_text())
            if old["plan_sha256"] != identity:
                raise ValueError("Cannot resume after changing task, model or budgets")
            return old
        reason = "feature_disabled"
        startup = {"status": "not_attempted"}
        if self.enabled:
            if not self.source_dir or not self.python:
                reason = "locked_upstream_runtime_missing"
            else:
                try:
                    lock = verify_source(self.source_dir, "evox")
                    # Actual pinned CLI entrypoint, --help only. No fictitious --dry-run flag.
                    # Candidate execution and model traffic are deliberately not started here.
                    with tempfile.TemporaryDirectory(prefix="biomni-sky-startup-") as scratch:
                        command = [str(self.python), "-m", "skydiscover.main", "optimize", "--help"]
                        env = {
                            "HOME": scratch,
                            "PATH": "/usr/bin:/bin",
                            "PYTHONPATH": str(Path(self.source_dir).resolve()),
                            "PYTHONDONTWRITEBYTECODE": "1",
                            "NO_COLOR": "1",
                        }
                        result = subprocess.run(
                            command, cwd=scratch, env=env, capture_output=True, text=True, timeout=15
                        )
                    startup = {
                        "command": command,
                        "returncode": result.returncode,
                        "stdout": result.stdout[:32000],
                        "stderr": result.stderr[:4000],
                        "commit": lock["commit"],
                        "mode": "CLI_HELP_ONLY",
                    }
                    reason = (
                        "model_budget_not_authorized"
                        if not task.max_tokens or not task.max_cost
                        else "upstream_sandbox_model_broker_not_validated"
                    )
                    if result.returncode or "--search" not in result.stdout or "evox" not in result.stdout:
                        reason = "upstream_startup_failed"
                except (OSError, ValueError, subprocess.TimeoutExpired) as error:
                    startup = {"status": "blocked", "reason": type(error).__name__}
                    reason = "upstream_startup_failed"
        state = {
            "status": "disabled" if not self.enabled else "BLOCKED",
            "LIVE_SEARCH": "BLOCKED",
            "reason": reason,
            "plan_sha256": identity,
            "plan": plan,
            "startup": startup,
            "ledger": {"model_requests": 0, "tokens": 0, "cost": 0, "candidates": []},
            "baseline_retained": True,
            "result": "NO_PROMOTION",
        }
        path.write_text(json.dumps(state, indent=2))
        return state
