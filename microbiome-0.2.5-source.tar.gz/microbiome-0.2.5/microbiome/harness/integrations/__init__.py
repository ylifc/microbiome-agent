"""Optional integrations. Importing these modules never starts upstream software."""
