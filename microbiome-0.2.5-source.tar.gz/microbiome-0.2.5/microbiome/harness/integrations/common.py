"""Allowlisted engineering facts; arbitrary source logs are never exported."""

import hashlib
import json
import re
from pathlib import Path

SUMMARIES = {
    "TABLE_SHAPE": "Synthetic table rows have inconsistent lengths",
    "CONFIG_PARSE": "Configuration parser rejected a synthetic input",
    "TIMEOUT": "Engineering task exceeded its configured timeout",
    "UNKNOWN": "Unclassified engineering error",
}


def engineering_snapshot(source):
    source = source if isinstance(source, dict) else {}
    code = source.get("error_code")
    code = code if isinstance(code, str) and code in SUMMARIES else "UNKNOWN"
    tool = source.get("tool")
    tool = tool if isinstance(tool, str) and tool in {"python", "node", "git", "jsonschema"} else "unknown"
    version = str(source.get("tool_version", ""))
    version = version if re.fullmatch(r"\d{1,3}\.\d{1,3}(?:\.\d{1,3})?", version) else "unknown"
    platform = source.get("platform")
    return {
        "error_code": code,
        "tool": tool,
        "tool_version": version,
        "platform": platform if isinstance(platform, str) and platform in {"linux", "macos", "windows"} else "unknown",
        "summary": SUMMARIES[code],
    }


def lock_entry(name):
    return json.loads((Path(__file__).parent / "integration-lock.json").read_text())[name]


def verify_source(root, name):
    root = Path(root).resolve(strict=True)
    locked = lock_entry(name)
    for relative, expected in locked["files"].items():
        file = root / relative
        if (
            file.is_symlink()
            or not file.is_file()
            or not file.resolve().is_relative_to(root)
            or any(parent.is_symlink() for parent in file.parents if parent != root and parent.is_relative_to(root))
            or hashlib.sha256(file.read_bytes()).hexdigest() != expected
        ):
            raise ValueError(f"{name} installation differs from integration lock: {relative}")
    return locked
