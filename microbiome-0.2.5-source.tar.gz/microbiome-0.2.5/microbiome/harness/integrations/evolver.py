"""Pinned Evolver text CLI in an ephemeral Git repository with network isolation."""

import hashlib
import json
import tempfile
from pathlib import Path

from microbiome.harness.integrations.common import engineering_snapshot, verify_source
from microbiome.harness.proposals import Proposal
from microbiome.harness.sandbox import LinuxSandbox, SandboxUnavailable


class EvolverAdapter:
    def __init__(self, source_dir=None, node=None, *, enabled=False, timeout=30):
        self.source_dir, self.node, self.enabled, self.timeout = source_dir, node, enabled, min(timeout, 60)
        self.failures = 0

    def propose(self, snapshot, *, baseline_version, archive):
        if not self.enabled:
            return {"status": "disabled"}
        if self.failures >= 3:
            return {"status": "circuit_open"}
        if not self.source_dir or not self.node:
            return {"status": "unavailable", "reason": "Configure a locked local source directory and Node executable"}
        root = Path(archive)
        root.mkdir(parents=True, exist_ok=True)
        try:
            lock = verify_source(self.source_dir, "evolver")
            clean = engineering_snapshot(snapshot)
            (root / "input.json").write_text(json.dumps(clean, indent=2))
            with tempfile.TemporaryDirectory(prefix="biomni-evolver-seed-") as seed:
                seed = Path(seed)
                (seed / "memory/evolution").mkdir(parents=True)
                (seed / "memory/engineering.json").write_text(json.dumps(clean))
                (seed / "MEMORY.md").write_text("Reviewed synthetic engineering snapshot:\n" + json.dumps(clean))
                (seed / "README.md").write_text("Synthetic engineering fixture. Produce guidance only.\n")
                script = "cp -r /seed/. /work/ && git init -q && git -c user.name=Fixture -c user.email=fixture@invalid add . && git -c user.name=Fixture -c user.email=fixture@invalid commit -qm baseline && exec /runtime/node --disable-wasm-trap-handler --max-old-space-size=128 --max-opt=0 /opt/evolver/index.js run"
                result = LinuxSandbox(timeout=self.timeout, memory_mb=2048, processes=128).run(
                    ["/bin/sh", "-c", script],
                    readonly={"/seed": seed, "/opt/evolver": self.source_dir, "/runtime/node": self.node},
                    ephemeral_work=True,
                    env={
                        "EVOLVER_REPO_ROOT": "/work",
                        "GEP_ASSETS_DIR": "/work/.evolver/gep",
                        "EVOLVER_SETTINGS_DIR": "/work/.settings",
                        "A2A_HUB_URL": "",
                        "EVOMAP_HUB_URL": "",
                        "EVOLVE_BRIDGE": "false",
                        "EVOLVER_VALIDATOR_ENABLED": "false",
                        "EVOMAP_PROXY": "0",
                        "EVOLVER_ATP": "off",
                        "EVOLVER_ATP_AUTOBUY": "off",
                        "EVOLVER_ATP_AUTODELIVER": "off",
                        "MEMORY_GRAPH_SYNC_HUB": "0",
                        "A2A_NODE_ID": "node_synthetic_offline_fixture",
                    },
                )
            (root / "execution.json").write_text(json.dumps(result, indent=2))
            status = self.classify(result)
            if status != "proposal":
                self.failures += status in {"timeout", "nonzero_exit", "unparseable"}
                return {"status": status, "evidence": str(root / "execution.json")}
            proposal = Proposal(
                source=f"EvoMap/evolver@{lock['commit']}",
                baseline_version=baseline_version,
                target_files=["candidate.py"],
                intent="Review upstream engineering guidance and propose a bounded repair",
                preconditions=["synthetic engineering task only", "independent validation required"],
                candidate_content={"candidate.py": ""},
                evidence=[str(root / "execution.json")],
                expected_risk="untrusted text; no execution authority",
                expected_cost={"model_calls": 0.0},
                validation_plan="Fill candidate.py in isolation, then run the frozen independent evaluator",
            )
            (root / "proposal.json").write_text(proposal.model_dump_json(indent=2))
            return {
                "status": "proposal",
                "proposal": proposal.model_dump(),
                "guidance": result["stdout"],
                "guidance_sha256": hashlib.sha256(result["stdout"].encode()).hexdigest(),
            }
        except (OSError, ValueError, SandboxUnavailable) as error:
            self.failures += 1
            result = {"status": "blocked", "reason": type(error).__name__, "live_local_call": "BLOCKED"}
            (root / "failure.json").write_text(json.dumps(result, indent=2))
            return result

    @staticmethod
    def classify(result):
        if result["status"] != "success":
            return result["status"]
        text = result["stdout"].strip()
        if not text:
            return "no_suggestion"
        # A textual GEP prompt is guidance only, never proof of a repair.
        if "GEP" in text and any(word in text.lower() for word in ("protocol", "gene", "mutation")):
            return "proposal"
        if any(word in text.lower() for word in ("no signal", "no suggestion", "nothing to evolve")):
            return "no_suggestion"
        return "unparseable"
