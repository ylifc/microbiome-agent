'use strict';

const $ = selector => document.querySelector(selector);
const names = {chat: '对话', tasks: '任务', models: '模型', context: '上下文', logs: '日志', settings: '配置与诊断'};
const statusNames = {queued: '等待中', running: '运行中', completed: '已完成', failed: '失败', cancelled: '已取消', interrupted: '已中断'};
const stageStatusNames = {pending: '待开始', current: '进行中', running: '执行中', completed: '已完成', blocked: '需要处理'};
const stageTitles = ['路径设置', '目标与分析思路', '流程确认', '5%–10% 小样本验证', '全量分析', '报告与结果'];
const scientificActions = new Set(['开始分析', '确认路径', '确认方案', '确认执行', '确认全量执行', '生成报告']);
let config, tasks = [], chosen = '';
let conversation = null, selectedConversationId = '', chatBusy = false, chatEpoch = 0;
let chatPollTimer, chatPollInFlight = false, tasksTimer, tasksInFlight = false;
let renderedMessages = '', renderedWorkflow = '', renderedReports = '';
let reportRequest = 0;

// Preserve these keys so existing users keep their authenticated session and history.
const hash = new URLSearchParams(location.hash.slice(1));
if (hash.get('token')) {
  sessionStorage.setItem('biomni-token', hash.get('token'));
  history.replaceState(null, '', location.pathname);
}
const token = sessionStorage.getItem('biomni-token') || '';

async function api(url, data) {
  const response = await fetch(url, {
    method: data === undefined ? 'GET' : 'POST',
    headers: {'Content-Type': 'application/json', 'X-Biomni-Token': token},
    body: data === undefined ? undefined : JSON.stringify(data),
  });
  const value = await response.json();
  if (!response.ok) throw Error(value.error || '操作失败');
  return value;
}

function notice(message, error = false) {
  $('#notice').hidden = false;
  $('#notice').textContent = message;
  $('#notice').className = error ? 'error' : '';
}

function el(tag, text, className) {
  const node = document.createElement(tag);
  if (text !== undefined) node.textContent = text;
  if (className) node.className = className;
  return node;
}

function tab(id) {
  document.querySelectorAll('.page').forEach(node => node.classList.toggle('active', node.id === id));
  document.querySelectorAll('nav button').forEach(node => node.classList.toggle('active', node.dataset.tab === id));
  $('#page-name').textContent = names[id];
  if (id === 'logs') showLogs();
  if (id === 'context') showContext();
}
document.querySelectorAll('nav button').forEach(node => { node.onclick = () => tab(node.dataset.tab); });

function renderModels() {
  const select = $('#task-profile'), list = $('#model-list');
  select.replaceChildren();
  list.replaceChildren();
  Object.entries(config.models).forEach(([name, model]) => {
    const option = el('option', name + ' · ' + model.model);
    option.value = name;
    option.selected = name === config.active_model;
    select.append(option);
    const row = el('div', undefined, 'model-item');
    row.append(el('strong', name + (name === config.active_model ? ' · 默认' : '')),
      el('p', model.provider + ' / ' + model.model), el('p', model.api_key_configured ? '密钥已配置' : '未配置密钥'));
    const button = el('button', '编辑配置');
    button.onclick = () => {
      const form = $('#model-form');
      for (const key of ['provider', 'model', 'base_url', 'context_length', 'max_tokens', 'temperature']) {
        form.elements[key].value = model[key] ?? '';
      }
      form.elements.name.value = name;
      form.elements.api_key.value = '';
    };
    row.append(button);
    list.append(row);
  });
  $('#active-model').textContent = config.models[config.active_model]?.model || '—';
}

function renderTasks() {
  const list = $('#task-list');
  list.replaceChildren();
  $('#total').textContent = tasks.length;
  $('#running').textContent = tasks.filter(task => ['running', 'queued'].includes(task.status)).length;
  $('#completed').textContent = tasks.filter(task => task.status === 'completed').length;
  if (!tasks.length) list.append(el('div', '还没有任务。分析开始后会显示真实运行状态。', 'empty'));
  tasks.forEach(task => {
    const row = el('div', undefined, 'task-item'), top = el('div', undefined, 'top');
    top.append(el('strong', task.message.slice(0, 65)), el('span', statusNames[task.status] || task.status, 'status ' + task.status));
    row.append(top, el('p', task.project), el('p', new Date(task.created * 1000).toLocaleString() + ' · ' + task.profile));
    const actions = el('div', undefined, 'task-actions');
    for (const [label, view] of [['查看日志', 'logs'], ['上下文', 'context']]) {
      const button = el('button', label);
      button.onclick = () => { chosen = task.id; $('#log-task').value = task.id; $('#context-task').value = task.id; tab(view); };
      actions.append(button);
    }
    if (['queued', 'running'].includes(task.status)) {
      const button = el('button', '取消任务');
      button.onclick = async () => {
        try { await api('/api/tasks/' + task.id + '/cancel', {}); await refresh(); }
        catch (error) { notice(error.message, true); }
      };
      actions.append(button);
    }
    row.append(actions);
    list.append(row);
  });
  for (const id of ['log-task', 'context-task']) {
    const select = $('#' + id), old = select.value;
    select.replaceChildren();
    tasks.forEach(task => {
      const option = el('option', task.message.slice(0, 50) + ' · ' + (statusNames[task.status] || task.status));
      option.value = task.id;
      select.append(option);
    });
    select.value = tasks.some(task => task.id === (chosen || old)) ? (chosen || old) : (tasks[0]?.id || '');
  }
}

async function refresh() {
  if (tasksInFlight) return;
  tasksInFlight = true;
  try {
    tasks = await api('/api/tasks');
    renderTasks();
    $('#connection').textContent = '本地连接正常';
    if ($('#logs').classList.contains('active')) await showLogs();
    if ($('#context').classList.contains('active')) showContext();
  } catch (error) {
    notice(error.message, true);
    $('#connection').textContent = '连接需要检查';
  } finally {
    tasksInFlight = false;
    clearTimeout(tasksTimer);
    tasksTimer = setTimeout(refresh, 4000);
  }
}

async function showLogs() {
  const id = $('#log-task').value;
  if (!id) return;
  try {
    const response = await api('/api/tasks/' + id + '/logs');
    if ($('#log-task').value === id) $('#log-view').textContent = response.text || '任务尚未产生日志。';
  } catch (error) { notice(error.message, true); }
}

function showContext() {
  const task = tasks.find(item => item.id === $('#context-task').value), box = $('#context-view');
  box.replaceChildren();
  let context;
  try { context = JSON.parse(task?.context || '{}'); } catch { context = {}; }
  if (!context.input_budget) { box.textContent = '此任务尚未调用模型。冻结生产可以不调用模型。'; return; }
  const progress = document.createElement('progress');
  progress.max = context.input_budget;
  progress.value = context.estimated_input_tokens;
  box.append(el('p', context.estimated_input_tokens + ' / ' + context.input_budget + ' 输入预算'), progress);
  const details = el('dl');
  for (const [key, value] of [['上下文长度', context.context_length], ['输出预留', context.max_tokens],
    ['发送消息', context.sent_messages], ['压缩历史轮次', context.compressed_turns],
    ['状态保留', context.state_preserved ? '是' : '无项目状态'], ['历史摘要', context.summary_included ? '已加入' : '未加入']]) {
    details.append(el('dt', key), el('dd', String(value)));
  }
  box.append(details);
}

$('#log-task').onchange = () => { chosen = $('#log-task').value; showLogs(); };
$('#context-task').onchange = () => { chosen = $('#context-task').value; showContext(); };
$('#refresh').onclick = refresh;
$('#task-form').onsubmit = async event => {
  event.preventDefault();
  const button = event.target.querySelector('button[type=submit]');
  button.disabled = true;
  try {
    const data = Object.fromEntries(new FormData(event.target));
    for (const key of Object.keys(data)) if (!data[key]) delete data[key];
    const task = await api('/api/tasks', data);
    chosen = task.id;
    notice('任务已提交。可以查看日志与真实完成状态。');
    await refresh();
  } catch (error) { notice(error.message, true); }
  finally { button.disabled = false; }
};
$('#model-form').onsubmit = async event => {
  event.preventDefault();
  const button = event.target.querySelector('button[type=submit]');
  button.disabled = true;
  try {
    const data = Object.fromEntries(new FormData(event.target)), name = data.name;
    delete data.name;
    for (const key of ['context_length', 'max_tokens', 'temperature']) data[key] = Number(data[key]);
    if (!data.base_url) data.base_url = null;
    const models = structuredClone(config.models);
    models[name] = data;
    config = await api('/api/config', {models, active_model: name});
    renderModels();
    event.target.elements.api_key.value = '';
    notice('模型配置已保存。新任务将使用该配置。');
  } catch (error) { notice(error.message, true); }
  finally { button.disabled = false; }
};
$('#doctor').onclick = async () => {
  const button = $('#doctor');
  button.disabled = true;
  try {
    const result = await api('/api/doctor'), view = $('#doctor-view');
    view.replaceChildren();
    for (const [name, status, detail] of [['Python', result.python.supported ? '支持' : '不支持', result.python.version],
      ['GPU', result.gpu.status, result.gpu.detail || '未发现可用 GPU'], ['CUDA', result.cuda.status, result.cuda.detail || '未发现 CUDA 工具链'],
      ['Ollama', result.ollama.status, result.ollama.detail || '命令未发现'], ['Agent', result.agent.status, '资源文件 ' + Object.keys(result.agent.assets).length + ' 项'],
      ['API', '未进行网络探测', Object.keys(result.api).length + ' 个配置']]) {
      const item = el('div');
      item.append(el('h3', name + ' · ' + status), el('p', detail));
      view.append(item);
    }
  } catch (error) { notice(error.message, true); }
  finally { button.disabled = false; }
};

function activeTask() {
  const task = conversation?.workflow?.active_task;
  return task && ['queued', 'running'].includes(task.status) ? task : null;
}

function renderWorkflow() {
  const workflow = conversation.workflow || {};
  const signature = JSON.stringify(workflow);
  if (signature !== renderedWorkflow) {
    renderedWorkflow = signature;
    const stages = $('#workflow-stages');
    stages.replaceChildren();
    let completed = 0;
    for (let index = 0; index < stageTitles.length; index++) {
      const stage = (workflow.stages || []).find(item => Number(item.id) === index + 1) || {};
      const status = stageStatusNames[stage.status] ? stage.status : 'pending';
      if (status === 'completed') completed++;
      const item = el('li', undefined, 'workflow-stage ' + status);
      if (Number(workflow.current_stage) === index + 1 && workflow.enabled) item.setAttribute('aria-current', 'step');
      const number = el('span', String(index + 1), 'stage-number');
      number.setAttribute('aria-hidden', 'true');
      const text = el('div', undefined, 'stage-label');
      text.append(el('strong', (stage.title || stageTitles[index]) + (status === 'completed' ? ' ✓' : '')), el('span', stageStatusNames[status]));
      item.append(number, text);
      if (stage.detail) item.title = stage.detail;
      stages.append(item);
    }
    $('#workflow-summary').textContent = completed + ' / 6 阶段完成';
    const current = (workflow.stages || []).find(stage => Number(stage.id) === Number(workflow.current_stage));
    const currentView = $('#workflow-current');
    currentView.className = 'workflow-current' + (current?.status === 'blocked' ? ' blocked' : '');
    currentView.replaceChildren();
    currentView.append(el('strong', workflow.enabled ? (current?.title || '当前阶段') : '开始一次分析'));
    if (current?.detail) currentView.append(el('p', current.detail));
    if (workflow.prompt && workflow.prompt !== current?.detail) currentView.append(el('p', workflow.prompt));
    if (!workflow.enabled) currentView.append(el('p', '输入“开始分析”，依次设置原始数据、持久数据库和输出目录。也可以直接与模型对话。'));
    const taskView = $('#workflow-task'), task = workflow.active_task;
    taskView.hidden = !task;
    taskView.replaceChildren();
    if (task) {
      taskView.append(el('span', statusNames[task.status] || task.status, 'status ' + task.status));
      taskView.append(el('span', '任务 ' + task.id.slice(0, 8)));
      if (task.progress) taskView.append(el('p', typeof task.progress === 'string' ? task.progress : JSON.stringify(task.progress), 'task-progress'));
    }
    const actions = $('#workflow-suggestions');
    actions.replaceChildren();
    const suggestions = workflow.suggestions?.length ? workflow.suggestions : (workflow.enabled ? [] : ['开始分析']);
    for (const message of suggestions) {
      const button = el('button', message, message === '取消任务' ? 'cancel-task' : 'workflow-action');
      button.type = 'button';
      button.dataset.message = message;
      button.onclick = () => sendChat(message);
      actions.append(button);
    }
    if (activeTask() && !suggestions.includes('取消任务')) {
      const button = el('button', '取消任务', 'cancel-task');
      button.type = 'button';
      button.dataset.message = '取消任务';
      button.onclick = () => sendChat('取消任务');
      actions.append(button);
    }
  }
  renderReports(workflow.reports || []);
}

function renderReports(reports) {
  const signature = JSON.stringify(reports);
  if (signature === renderedReports) return;
  renderedReports = signature;
  $('#chat-reports').hidden = reports.length === 0;
  const list = $('#report-list');
  list.replaceChildren();
  for (const report of reports) {
    const button = el('button', report.name, 'report-link');
    button.type = 'button';
    button.title = report.path || report.name;
    button.onclick = () => openReport(report.name);
    list.append(button);
  }
}

async function openReport(name) {
  const id = selectedConversationId, epoch = chatEpoch, request = ++reportRequest;
  try {
    const report = await api('/api/conversations/' + encodeURIComponent(id) + '/reports/' + encodeURIComponent(name));
    if (id !== selectedConversationId || epoch !== chatEpoch || request !== reportRequest) return;
    $('#report-name').textContent = report.name || name;
    $('#report-text').textContent = report.text;
    $('#report-preview').hidden = false;
    $('#report-text').focus({preventScroll: true});
  } catch (error) { if (id === selectedConversationId && request === reportRequest) notice(error.message, true); }
}
$('#close-report').onclick = () => { reportRequest++; $('#report-preview').hidden = true; };

function renderChat({forceScroll = false} = {}) {
  if (!conversation) return;
  const box = $('#chat-messages'), signature = JSON.stringify(conversation.messages || []);
  if (signature !== renderedMessages) {
    const oldScroll = box.scrollTop, nearBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 70;
    renderedMessages = signature;
    box.replaceChildren();
    let previousStage = null;
    for (const message of conversation.messages || []) {
      const stage = Number.isInteger(message.stage) && message.stage >= 1 && message.stage <= 6 ? message.stage : null;
      if (stage !== null && stage !== previousStage) {
        const marker = el('div', '阶段 ' + stage + ' · ' + stageTitles[stage - 1], 'chat-stage-marker');
        marker.setAttribute('role', 'separator');
        box.append(marker);
      }
      previousStage = stage;
      const role = message.role === 'user' ? 'user' : 'assistant';
      const row = el('div', undefined, 'chat-message ' + role);
      const title = message.role === 'user' ? '你' : 'Microbiome';
      row.append(el('strong', title), el('div', message.content));
      if (message.task_id) row.append(el('span', '任务 ' + String(message.task_id).slice(0, 8), 'message-task'));
      box.append(row);
    }
    if (forceScroll || nearBottom) box.scrollTop = box.scrollHeight;
    else box.scrollTop = oldScroll;
  } else if (forceScroll) box.scrollTop = box.scrollHeight;
  const bindings = conversation.bindings || {};
  $('#chat-binding').textContent = '模型配置：' + conversation.profile + ' · 输出项目：' + (bindings.project || '尚未设置');
  $('#cancel-setup').hidden = !conversation.configuring;
  $('#chat-input').placeholder = conversation.setting === 'api_key' ? '只输入 ${ENV_VAR}，不要输入明文密钥'
    : conversation.configuring ? '回答当前设置问题；可输入“保留”或“清空”'
      : activeTask() ? '任务正在运行，进度会自动更新。需要停止时输入“取消任务”。'
        : '回答当前阶段问题，或点击上方建议操作；模型参数可通过“模型设置”调整。';
  renderWorkflow();
  updateChatControls();
}

function updateChatControls() {
  $('#chat-input').disabled = chatBusy;
  $('#chat-form button').disabled = chatBusy;
  for (const id of ['new-chat', 'setup-chat', 'cancel-setup', 'list-ollama', 'test-model', 'chat-list']) {
    $('#' + id).disabled = chatBusy;
  }
  // A running job owns its scientific state. Model settings remain separate.
  document.querySelectorAll('#workflow-suggestions button').forEach(button => {
    button.disabled = chatBusy || conversation?.configuring || (Boolean(activeTask()) && button.dataset.message !== '取消任务');
  });
  $('#chat-status').textContent = chatBusy ? '正在等待回复…'
    : conversation?.configuring ? '模型与工作台设置 · ' + (conversation.setting || '等待保存确认')
      : activeTask() ? '正在执行 · 进度自动更新，可取消任务'
        : conversation?.workflow?.enabled ? '按当前阶段继续对话' : '可以继续对话';
}

async function loadChatList() {
  const list = await api('/api/conversations'), select = $('#chat-list');
  select.replaceChildren();
  for (const item of list) {
    const option = el('option', (item.project || '新分析 / 对话') + ' · ' + item.profile + ' · ' + item.id.slice(0, 8));
    option.value = item.id;
    select.append(option);
  }
  if (selectedConversationId) select.value = selectedConversationId;
  return list;
}

function applyConversation(value, {newSelection = false, forceScroll = false} = {}) {
  conversation = value;
  selectedConversationId = value.id;
  localStorage.setItem('biomni-conversation', value.id);
  if (newSelection) {
    renderedMessages = renderedWorkflow = renderedReports = '';
    reportRequest++;
    $('#report-preview').hidden = true;
    $('#model-check').hidden = true;
    $('#chat-input').value = '';
  }
  renderChat({forceScroll: forceScroll || newSelection});
}

async function initChat() {
  const list = await loadChatList(), saved = localStorage.getItem('biomni-conversation');
  const id = list.find(item => item.id === saved)?.id || list[0]?.id;
  const value = id ? await api('/api/conversations/' + id) : await api('/api/conversations', {});
  applyConversation(value, {newSelection: true});
  await loadChatList();
  scheduleChatPoll();
}

function scheduleChatPoll() {
  clearTimeout(chatPollTimer);
  if (selectedConversationId) chatPollTimer = setTimeout(pollChat, activeTask() ? 2000 : 10000);
}

async function pollChat() {
  if (chatBusy || chatPollInFlight || !selectedConversationId) { scheduleChatPoll(); return; }
  chatPollInFlight = true;
  const id = selectedConversationId, epoch = chatEpoch;
  try {
    const value = await api('/api/conversations/' + id);
    if (id !== selectedConversationId || epoch !== chatEpoch || chatBusy) return;
    applyConversation(value);
  } catch (error) {
    if (id === selectedConversationId && epoch === chatEpoch) {
      $('#chat-status').textContent = '进度暂时无法刷新，将自动重试：' + error.message;
    }
  } finally {
    chatPollInFlight = false;
    scheduleChatPoll();
  }
}

async function sendChat(message) {
  message = message.trim();
  if (chatBusy || !conversation || !message) return;
  if (activeTask() && (scientificActions.has(message) || message.startsWith('/运行'))) {
    notice('当前任务正在执行。请等待结果，或在对话中取消任务后继续。', true);
    return;
  }
  const id = selectedConversationId, epoch = ++chatEpoch;
  const inputBeforeSend = $('#chat-input').value;
  const secret = conversation.setting === 'api_key';
  chatBusy = true;
  clearTimeout(chatPollTimer);
  if (secret) $('#chat-input').value = '';
  updateChatControls();
  try {
    const value = await api('/api/conversations/' + id + '/messages', {message});
    if (id !== selectedConversationId || epoch !== chatEpoch) return;
    // A quick action should not erase a draft already in the message box.
    if ($('#chat-input').value === inputBeforeSend && inputBeforeSend.trim() === message) $('#chat-input').value = '';
    applyConversation(value, {forceScroll: true});
    config = await api('/api/config');
    renderModels();
    await loadChatList();
    await refresh();
  } catch (error) {
    if (id === selectedConversationId && epoch === chatEpoch) notice(error.message, true);
  } finally {
    chatBusy = false;
    renderChat();
    scheduleChatPoll();
  }
}
$('#chat-form').onsubmit = event => { event.preventDefault(); sendChat($('#chat-input').value); };
$('#setup-chat').onclick = () => sendChat('开始设置');
$('#cancel-setup').onclick = () => sendChat('取消设置');
$('#new-chat').onclick = async () => {
  if (chatBusy) return;
  const epoch = ++chatEpoch;
  chatBusy = true;
  updateChatControls();
  try {
    const value = await api('/api/conversations', {});
    if (epoch !== chatEpoch) return;
    applyConversation(value, {newSelection: true});
    await loadChatList();
  } catch (error) { notice(error.message, true); }
  finally { chatBusy = false; renderChat(); scheduleChatPoll(); }
};
$('#chat-list').onchange = async () => {
  const id = $('#chat-list').value, epoch = ++chatEpoch;
  selectedConversationId = id;
  clearTimeout(chatPollTimer);
  chatBusy = true;
  updateChatControls();
  try {
    const value = await api('/api/conversations/' + id);
    if (id !== selectedConversationId || epoch !== chatEpoch) return;
    applyConversation(value, {newSelection: true});
  } catch (error) {
    if (epoch === chatEpoch) {
      selectedConversationId = conversation?.id || '';
      $('#chat-list').value = selectedConversationId;
      notice(error.message, true);
    }
  } finally {
    if (epoch === chatEpoch) { chatBusy = false; renderChat(); scheduleChatPoll(); }
  }
};
for (const [id, path] of [['list-ollama', 'list'], ['test-model', 'test']]) {
  $('#' + id).onclick = async () => {
    if (chatBusy || !conversation) return;
    chatBusy = true;
    ++chatEpoch;
    updateChatControls();
    try {
      const result = await api('/api/models/' + path, {profile: conversation.profile}), box = $('#model-check');
      box.hidden = false;
      box.textContent = path === 'list'
        ? '已安装模型：\n' + result.models.join('\n') + '\n当前模型：' + result.selected + '（' + (result.available ? '已安装' : '未安装，请通过模型设置选择列表中的模型') + '）'
        : result.model + '：' + (typeof result.reply === 'string' ? result.reply : JSON.stringify(result.reply));
    } catch (error) { notice(error.message, true); }
    finally { chatBusy = false; renderChat(); scheduleChatPoll(); }
  };
}

(async () => {
  try {
    config = await api('/api/config');
    renderModels();
    await initChat();
    await refresh();
  } catch (error) { notice(error.message, true); }
})();
