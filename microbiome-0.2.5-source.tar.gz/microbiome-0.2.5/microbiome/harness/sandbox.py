"""Fail-closed Linux execution: no network, no home, bounded tmpfs and resources."""

from __future__ import annotations

import os
import shutil
import signal
import subprocess
import time
from pathlib import Path


class SandboxUnavailable(RuntimeError):
    pass


class LinuxSandbox:
    def __init__(self, *, timeout=60, memory_mb=512, disk_mb=32, processes=64):
        if (
            not 1 <= timeout <= 60
            or not 64 <= memory_mb <= 2048
            or not 1 <= disk_mb <= 128
            or not 1 <= processes <= 256
        ):
            raise ValueError("Sandbox budget exceeds supported limits")
        self.timeout, self.memory_mb, self.disk_mb, self.processes = timeout, memory_mb, disk_mb, processes

    def run(self, argv, *, readonly=None, writable=None, stdin="", env=None, ephemeral_work=False):
        if not shutil.which("bwrap") or not shutil.which("prlimit"):
            raise SandboxUnavailable("bubblewrap and prlimit are required; unsandboxed fallback is forbidden")
        limits = [
            "/usr/bin/prlimit",
            f"--as={self.memory_mb * 1024**2}",
            f"--cpu={self.timeout}",
            f"--nproc={self.processes}",
            f"--fsize={self.disk_mb * 1024**2}",
            "--nofile=64",
            "--",
        ]
        command = [
            "bwrap",
            "--unshare-all",
            "--die-with-parent",
            "--new-session",
            "--cap-drop",
            "ALL",
            "--clearenv",
            "--setenv",
            "PATH",
            "/usr/bin:/bin",
            "--setenv",
            "HOME",
            "/home/sandbox",
            "--setenv",
            "PYTHONDONTWRITEBYTECODE",
            "1",
        ]
        for directory in ("/usr", "/bin", "/lib", "/lib64"):
            if Path(directory).exists():
                command += ["--ro-bind", directory, directory]
        command += [
            "--proc",
            "/proc",
            "--dev",
            "/dev",
            "--dir",
            "/home/sandbox",
            "--size",
            str(self.disk_mb * 1024**2),
            "--tmpfs",
            "/tmp",
        ]
        if ephemeral_work:
            command += ["--size", str(self.disk_mb * 1024**2), "--tmpfs", "/work"]
        for mapping, flag in ((readonly or {}, "--ro-bind"), (writable or {}, "--bind")):
            for target, source in mapping.items():
                if target in {"/", "/usr", "/bin", "/lib", "/lib64", "/proc", "/dev", "/tmp", "/home"}:
                    raise ValueError("Sandbox mount would replace a protected root")
                command += [flag, str(Path(source).resolve(strict=True)), target]
        for key, value in (env or {}).items():
            command += ["--setenv", key, str(value)]
        command += ["--chdir", "/work", "--", *limits, *argv]
        # Store output outside the candidate namespace; fsize bounds it independently.
        import tempfile

        with tempfile.TemporaryFile() as stdout, tempfile.TemporaryFile() as stderr:
            start = time.monotonic()
            child = subprocess.Popen(
                command, stdin=subprocess.PIPE, stdout=stdout, stderr=stderr, start_new_session=True
            )
            timed_out = False
            try:
                child.communicate(stdin.encode(), timeout=self.timeout)
            except subprocess.TimeoutExpired:
                timed_out = True
                os.killpg(child.pid, signal.SIGKILL)
                child.communicate()
            stdout.seek(0)
            stderr.seek(0)
            output, error = (
                stdout.read(1024 * 1024).decode(errors="replace"),
                stderr.read(16384).decode(errors="replace"),
            )
        if child.returncode and (
            "bwrap:" in error and any(x in error for x in ("Operation not permitted", "Creating new namespace failed"))
        ):
            raise SandboxUnavailable(error[:300])
        return {
            "status": "timeout" if timed_out else ("success" if child.returncode == 0 else "nonzero_exit"),
            "returncode": child.returncode,
            "stdout": output,
            "stderr": error,
            "elapsed_seconds": time.monotonic() - start,
            "network": "unshared_namespace",
            "command": command,
        }
