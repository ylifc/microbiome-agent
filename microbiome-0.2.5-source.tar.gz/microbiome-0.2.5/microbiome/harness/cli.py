"""Explicit legacy local Harness command line; not the default product entrypoint."""

import argparse
import errno
import json
import sys
from pathlib import Path

from microbiome.harness.settings import config_path, load_config, save_config, user_home


def main(argv=None):
    parser = argparse.ArgumentParser(prog="microbiome-legacy-harness", description="Legacy standalone Harness (optional compatibility interface)")
    parser.add_argument("--config", type=Path, default=config_path())
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("init", help="Write a user configuration; preserves an existing file")
    check = sub.add_parser("doctor", help="Inspect Python, GPU/CUDA, model and Agent readiness")
    check.add_argument(
        "--network", action="store_true", help="Opt in to configured provider model-list checks (no generation)"
    )
    gui = sub.add_parser("gui", help="Start an authenticated browser GUI on loopback")
    gui.add_argument("--port", type=int, default=8765)
    gui.add_argument("--open", action="store_true")
    run = sub.add_parser("run", help="Execute one actual user message against a persistent project")
    run.add_argument("--project", required=True)
    for name in ("data-dir", "db-dir", "download-dir", "knowledge-dir", "profile"):
        run.add_argument("--" + name)
    run.add_argument("message")
    args = parser.parse_args(argv)
    if args.command == "init":
        if not args.config.exists():
            save_config(load_config(args.config), args.config)
        print(args.config)
        return 0
    if args.command == "doctor":
        from microbiome.harness.diagnostics import doctor

        report = doctor(args.config, network=args.network)
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0 if report["ok"] else 1
    if args.command == "gui":
        from microbiome.harness.instance import find_instance, publish_instance, remove_instance
        from microbiome.harness.server import make_server
        from microbiome.harness.tasks import TaskManagerBusy

        home = user_home()
        try:
            server = make_server(home, args.config, port=args.port)
        except TaskManagerBusy:
            existing = find_instance(home)
            if existing is None:
                print(
                    "工作台已占用此任务目录，但尚未取得有效访问地址。请使用原启动终端的地址；"
                    "如需重启，在原终端按 Ctrl+C。更换端口无效，请勿删除锁文件。",
                    file=sys.stderr,
                )
                return 1
            if existing["config"] != str(args.config.resolve()):
                print(
                    "已有工作台使用另一配置文件：" + existing["config"] + "。请先在原终端停止服务，再使用新配置启动。",
                    file=sys.stderr,
                )
                return 1
            print("工作台已运行，复用原地址（--port 不改变已有服务端口）：", flush=True)
            print(existing["access_url"], flush=True)
            if args.open:
                _open_browser(existing["access_url"])
            return 0
        except OSError as error:
            if error.errno != errno.EADDRINUSE:
                raise
            print(f"端口 {args.port} 已被其他服务占用，请使用 --port 指定空闲端口。", file=sys.stderr)
            return 1

        record = None
        try:
            record = publish_instance(home, args.config, server.access_url)
            print(server.access_url, flush=True)
            if args.open:
                _open_browser(server.access_url)
            server.serve_forever()
        except KeyboardInterrupt:
            pass
        finally:
            if record is not None:
                remove_instance(home, record)
            server.manager.close()
            server.server_close()
        return 0
    if args.command == "run":
        import time

        from microbiome.harness.tasks import TaskManager

        manager = TaskManager(user_home() / "cli-tasks", args.config)
        payload = {
            key: getattr(args, key)
            for key in ("project", "data_dir", "db_dir", "download_dir", "knowledge_dir", "profile", "message")
            if getattr(args, key) is not None
        }
        try:
            task = manager.submit(payload)
            print("task_id=" + task["id"], flush=True)
            while (task := manager.get(task["id"]))["status"] in {"queued", "running"}:
                time.sleep(0.2)
            print(manager.logs(task["id"]))
            return 0 if task["status"] == "completed" else 1
        finally:
            manager.close()


def _open_browser(url):
    import webbrowser

    try:
        opened = webbrowser.open(url)
    except (webbrowser.Error, OSError):
        opened = False
    if not opened:
        print("无法自动打开浏览器，请手动打开上方完整地址。", file=sys.stderr)


if __name__ == "__main__":
    raise SystemExit(main())
