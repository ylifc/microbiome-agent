"""Private discovery of an already running GUI; ownership stays with flock."""

import json
import os
import tempfile
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import requests


def instance_identity(home, config_file):
    return {"pid": os.getpid(), "home": str(Path(home).resolve()), "config": str(Path(config_file).resolve())}


def publish_instance(home, config_file, access_url):
    directory = Path(home)
    record = instance_identity(home, config_file) | {"access_url": access_url}
    descriptor, temporary = tempfile.mkstemp(prefix=".gui-instance-", dir=directory)
    try:
        with os.fdopen(descriptor, "w") as stream:
            json.dump(record, stream)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, directory / "gui-instance.json")
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    return record


def remove_instance(home, record):
    path = Path(home) / "gui-instance.json"
    try:
        if json.loads(path.read_text()) == record:
            path.unlink()
    except (OSError, ValueError):
        pass


def find_instance(home):
    """Return only an authenticated live instance at an exact loopback origin."""
    path = Path(home) / "gui-instance.json"
    try:
        if path.is_symlink() or path.stat().st_mode & 0o077:
            return None
        record = json.loads(path.read_text())
        if not isinstance(record, dict) or record.get("home") != str(Path(home).resolve()):
            return None
        if not isinstance(record.get("access_url"), str) or not isinstance(record.get("config"), str):
            return None
        if type(record.get("pid")) is not int or record["pid"] <= 0:
            return None
        url = urlparse(record["access_url"])
        if (
            url.scheme != "http"
            or url.hostname != "127.0.0.1"
            or not url.port
            or url.username
            or url.password
            or url.path != "/"
            or url.query
        ):
            return None
        fragment = parse_qs(url.fragment, strict_parsing=True)
        if set(fragment) != {"token"} or len(fragment["token"]) != 1:
            return None
        with requests.Session() as session:
            session.trust_env = False
            response = session.get(
                f"http://127.0.0.1:{url.port}/api/instance",
                headers={"X-Biomni-Token": fragment["token"][0]},
                timeout=2,
                allow_redirects=False,
            )
        identity = {key: record[key] for key in ("pid", "home", "config")}
        return record if response.status_code == 200 and response.json() == identity else None
    except (OSError, ValueError, KeyError, TypeError, requests.RequestException):
        return None
