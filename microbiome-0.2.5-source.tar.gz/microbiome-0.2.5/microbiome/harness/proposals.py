"""Untrusted improvement proposals and independent, synthetic engineering evaluation."""

from __future__ import annotations

import difflib
import hashlib
import json
import statistics
import subprocess
import tempfile
import time
from pathlib import Path, PurePosixPath

from pydantic import BaseModel, ConfigDict, Field, model_validator

from microbiome.harness.sandbox import LinuxSandbox

FORBIDDEN_PARTS = {".git", "tests", "test", "evaluator", "validator", "permissions", "budgets", "config", "pipeline"}


class Proposal(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    source: str
    baseline_version: str
    target_files: list[str]
    intent: str
    preconditions: list[str]
    candidate_content: dict[str, str]
    evidence: list[str]
    expected_risk: str
    expected_cost: dict[str, float]
    validation_plan: str
    status: str = "proposed"

    @model_validator(mode="after")
    def validate_paths(self):
        if self.status != "proposed":
            raise ValueError("Proposals cannot grant themselves verified status")
        if set(self.target_files) != set(self.candidate_content) or not self.target_files:
            raise ValueError("Candidate files must exactly match target_files")
        for value in self.target_files:
            path = PurePosixPath(value)
            if (
                not path.parts
                or "\x00" in value
                or path.is_absolute()
                or ".." in path.parts
                or "\\" in value
                or str(path) != value
                or any(p.lower() in FORBIDDEN_PARTS for p in path.parts)
            ):
                raise ValueError("Candidate path is outside the permitted engineering surface")
            if any(
                word in path.name.lower()
                for word in ("lock", "test", "eval", "validat", "budget", "permission", "agents.md", "skill.md")
            ):
                raise ValueError("Candidate cannot change acceptance, frozen locks or permissions")
        if sum(len(c.encode()) for c in self.candidate_content.values()) > 64_000:
            raise ValueError("Candidate content exceeds 64 KB")
        return self


class OptimizationTask(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True, frozen=True)
    task_id: str = "rectangular-table-v1"
    objective: str = "Validate synthetic rectangular integer tables"
    allowed_files: tuple[str, ...] = ("candidate.py",)
    function_interface: str = "stdin JSON list of rows -> stdout JSON {valid: bool, rows: int}"
    baseline_version: str
    evaluator_version: str = "rectangular-oracle-v2"
    semantic_constraints: tuple[str, ...] = ("reject bool/float/string cells", "nonempty rectangular integer rows")
    allowed_operations: tuple[str, ...] = ("replace candidate.py",)
    scoring: str = "hard correctness repair only; timing is diagnostic, never a promotion metric"
    stop_condition: str = "first independently verified repair or exhausted budget"
    max_candidates: int = Field(default=5, ge=1, le=5)
    concurrency: int = Field(default=1, ge=1, le=1)
    candidate_seconds: int = Field(default=5, ge=1, le=60)
    wall_seconds: int = Field(default=600, ge=1, le=600)
    max_holdout_queries: int = Field(default=5, ge=1, le=5)
    max_tokens: int = Field(default=0, ge=0)
    max_cost: float = Field(default=0.0, ge=0)


def oracle(rows):
    valid = isinstance(rows, list) and bool(rows) and all(isinstance(row, list) for row in rows)
    valid = bool(
        valid
        and len(rows[0]) > 0
        and all(len(row) == len(rows[0]) and all(type(v) is int for v in row) for row in rows)
    )
    return {"valid": valid, "rows": len(rows) if valid else 0}


class CandidateValidator:
    """The candidate sees only its file and the current input, never the oracle or holdout."""

    def __init__(self, task, store):
        self.task, self.store = task, Path(store)
        self.store.mkdir(parents=True, exist_ok=True)
        self.ledger_path = self.store / "ledger.json"
        self.ledger = (
            json.loads(self.ledger_path.read_text())
            if self.ledger_path.is_file()
            else {
                "task": task.model_dump(mode="json"),
                "started_at": time.time(),
                "spent_seconds": 0,
                "holdout_queries": 0,
                "candidates": {},
                "promotions": [],
            }
        )
        if self.ledger["task"] != task.model_dump(mode="json"):
            raise ValueError("Task/evaluator/budgets changed; cannot reuse this ledger")

    def _save(self):
        temporary = self.ledger_path.with_suffix(".tmp")
        temporary.write_text(json.dumps(self.ledger, indent=2))
        temporary.replace(self.ledger_path)

    def evaluate(self, proposal, *, baseline=False):
        if proposal.baseline_version != self.task.baseline_version or set(proposal.target_files) != set(
            self.task.allowed_files
        ):
            raise ValueError("Proposal does not match the frozen task baseline or allowed files")
        identity = hashlib.sha256(proposal.model_dump_json().encode()).hexdigest()
        if identity in self.ledger["candidates"]:
            return self.ledger["candidates"][identity]
        previous = next((v for v in self.ledger["candidates"].values() if v.get("baseline")), None)
        if baseline and previous:
            raise ValueError("Baseline is already frozen")
        if not baseline and previous is None:
            raise ValueError("Freeze a baseline before evaluating candidates")
        if self.ledger["promotions"]:
            raise ValueError("Stop condition reached; final acceptance cannot be reused for selection")
        if (
            len(self.ledger["candidates"]) >= self.task.max_candidates + 1
            or self.ledger["spent_seconds"] >= self.task.wall_seconds
        ):
            raise ValueError("Candidate budget exhausted")
        # Three disjoint sets. Only development results may inform subsequent candidate creation.
        suites = {
            "development": [[[1, 2], [3, 4]], [], [[1], [2, 3]], [[True]]],
            "holdout": [[[17, -4, 8]], [[1.5]], [["x"]], [[], []]],
            "final": [[[23], [-9], [0]], [[None]], {"rows": [[1]]}, [[2, 7], [8]]],
        }
        self.ledger["candidates"][identity] = {"status": "interrupted", "identity": identity, "baseline": baseline}
        (self.store / (identity + ".proposal.json")).write_text(proposal.model_dump_json(indent=2))
        self._save()  # A restart never repeats an unconfirmed invocation.
        start = time.monotonic()
        records = []
        try:
            with tempfile.TemporaryDirectory(prefix="biomni-candidate-") as temporary:
                directory = Path(temporary)
                # The scratch Git repository is separate from production and is not visible to the candidate.
                subprocess.run(["git", "init", "-q", str(directory)], check=True, capture_output=True)
                code_dir = directory / "payload"
                code_dir.mkdir()
                for name, content in proposal.candidate_content.items():
                    target = code_dir / name
                    if target.is_symlink() or not target.resolve().is_relative_to(code_dir.resolve()):
                        raise ValueError("Candidate path escapes workspace")
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_text(content)
                for stage, cases in suites.items():
                    if stage == "final" and (baseline or not previous or previous.get("correct", False)):
                        continue  # Final acceptance is used once, only for a prospective correctness repair.
                    if stage == "holdout" and not baseline:
                        if self.ledger["holdout_queries"] >= self.task.max_holdout_queries:
                            records.append({"stage": stage, "passed": False, "reason": "holdout_budget"})
                            break
                        self.ledger["holdout_queries"] += 1
                        self._save()
                    for rows in cases:
                        remaining = min(
                            self.task.candidate_seconds - (time.monotonic() - start),
                            self.task.wall_seconds - self.ledger["spent_seconds"] - (time.monotonic() - start),
                        )
                        if remaining < 1:
                            records.append({"stage": stage, "passed": False, "reason": "timeout_budget"})
                            break
                        result = LinuxSandbox(timeout=max(1, int(remaining)), processes=1).run(
                            ["/usr/bin/python3", "-I", "/work/candidate.py"],
                            readonly={"/work": code_dir},
                            stdin=json.dumps(rows),
                        )
                        try:
                            output = json.loads(result["stdout"])
                        except ValueError:
                            output = None
                        # bool is an int subclass; require exact output types as well as value equality.
                        contract = (
                            isinstance(output, dict)
                            and type(output.get("valid")) is bool
                            and type(output.get("rows")) is int
                        )
                        records.append(
                            {
                                "stage": stage,
                                "passed": result["status"] == "success" and contract and output == oracle(rows),
                                "status": result["status"],
                                "elapsed_seconds": result["elapsed_seconds"],
                            }
                        )
                    if not all(r["passed"] for r in records if r["stage"] == stage):
                        if not baseline:
                            break
        except Exception as error:
            records.append({"stage": "sandbox", "passed": False, "reason": type(error).__name__})
        elapsed = time.monotonic() - start
        self.ledger["spent_seconds"] += elapsed
        correct = bool(records) and all(r["passed"] for r in records)
        promoted = bool(
            correct
            and not baseline
            and previous
            and not previous.get("correct", False)
            and len([r for r in records if r["stage"] == "final"]) == len(suites["final"])
        )
        timings = [r["elapsed_seconds"] for r in records if "elapsed_seconds" in r]
        record = {
            "identity": identity,
            "parent": previous.get("identity") if previous else None,
            "strategy_version": "agent-proposal-v1",
            "baseline": baseline,
            "correct": correct,
            "status": "locally_verified" if promoted else ("baseline" if baseline else "NO_PROMOTION"),
            "reason": "correctness_repair" if promoted else "no_independently_verified_improvement",
            "evaluator": self.task.evaluator_version,
            "records": records,
            "timing_diagnostic": {
                "median_seconds": statistics.median(timings) if timings else None,
                "range_seconds": max(timings) - min(timings) if timings else None,
                "performance_improvement_claimed": False,
            },
            "elapsed_seconds": elapsed,
            "source": proposal.source,
            "cost": {"model_tokens": 0, "model_cost": 0},
            "rollback": "production_unchanged; scratch_removed",
        }
        self.ledger["candidates"][identity] = record
        if promoted:
            before = json.loads((self.store / (previous["identity"] + ".proposal.json")).read_text())[
                "candidate_content"
            ]
            patch = "".join(
                "".join(
                    difflib.unified_diff(
                        before[name].splitlines(True),
                        content.splitlines(True),
                        fromfile="a/" + name,
                        tofile="b/" + name,
                    )
                )
                for name, content in proposal.candidate_content.items()
            )
            (self.store / (identity + ".patch")).write_text(patch)
            self.ledger["promotions"].append(identity)
        self._save()
        return record
