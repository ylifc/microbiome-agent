"""Inject one host model; this module never reads credentials or opens HTTP."""
from contextlib import contextmanager
from contextvars import ContextVar
import json
import os
from typing import Any

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from pydantic import PrivateAttr

_MODEL = ContextVar("microbiome_host_model", default=None)


def host_model():
    model = _MODEL.get()
    if model is None and os.environ.get("MICROBIOME_LLM_TRANSPORT") == "harness":
        raise RuntimeError("HARNESS_UNAVAILABLE: no host model transport is attached")
    return model


@contextmanager
def use_host_model(model):
    token = _MODEL.set(model)
    try:
        yield
    finally:
        _MODEL.reset(token)


class HarnessChatModel(BaseChatModel):
    """LangChain adapter whose requests are served by the current Harness route."""
    _exchange: Any = PrivateAttr()
    _project: Any = PrivateAttr(default=None)

    def __init__(self, exchange, *, project=None, **kwargs):
        super().__init__(**kwargs)
        self._exchange = exchange
        self._project = project

    @property
    def _llm_type(self):
        return "deepseek-harness"

    def _generate(self, messages, stop=None, run_manager=None, **kwargs):
        wire = []
        for message in messages:
            entry = {"role": {"human": "user", "ai": "assistant"}.get(message.type, message.type),
                     "content": message.content}
            if getattr(message, "tool_calls", None):
                entry["tool_calls"] = message.tool_calls
            if getattr(message, "tool_call_id", None):
                entry["tool_call_id"] = message.tool_call_id
            wire.append(entry)
        params = {"messages": wire, "stop": stop, "tools": kwargs.get("tools", [])}
        if self._project is not None:
            from microbiome.pipeline.planning_policy import preflight_model_messages, get_effective_policy
            preflight_model_messages(self._project, wire, tools=params["tools"], purpose="harness_final_wire")
            policy = get_effective_policy(self._project)
            params["planning_budget"] = {"limits": policy["limits"], "policy_fingerprint": policy["policy_fingerprint"],
                                         "capacity_source": policy["capacity_source"],
                                         "project_context_limit_tokens": policy["project_context_limit_tokens"]}
            # Each transport invocation is admitted by the durable planning
            # ledger; nested host retries must not multiply that allowance.
            params["transport_attempt_limit"] = 1
        result = self._exchange(params)
        if not isinstance(result, dict) or result.get("error"):
            if isinstance(result, dict) and isinstance(result.get("details"), dict):
                from microbiome.pipeline.planning_policy import PlanningPolicyError
                details = dict(result["details"])
                if self._project is not None and isinstance(details.get("host_profile"), dict):
                    from microbiome.pipeline.maintenance import _save
                    from microbiome.pipeline.planning_policy import record_host_profile
                    _save(self._project.state_dir / "last_host_budget.json", details)
                    record_host_profile(self._project, details["host_profile"])
                code = details.pop("code", "MODEL_CONTEXT_LIMIT")
                raise PlanningPolicyError(code, str(result["error"]), **details)
            raise RuntimeError(f"HARNESS_MODEL_ERROR: {result.get('error') if isinstance(result, dict) else 'invalid response'}")
        text = result.get("text", "")
        if self._project is not None and isinstance(result.get("planning_budget"), dict):
            from microbiome.pipeline.maintenance import _save
            from microbiome.pipeline.planning_policy import record_host_profile
            _save(self._project.state_dir / "last_host_budget.json", result["planning_budget"])
            record_host_profile(self._project, result["planning_budget"].get("host_profile", {}))
        calls = result.get("tool_calls", [])
        if not text and not calls:
            raise RuntimeError("HARNESS_EMPTY_RESPONSE")
        message = AIMessage(content=text, tool_calls=calls, response_metadata={"harness_usage": result.get("usage", {})})
        return ChatResult(generations=[ChatGeneration(message=message)])

    def bind_tools(self, tools, *, tool_choice=None, **kwargs):
        from langchain_core.utils.function_calling import convert_to_openai_tool
        if tool_choice not in (None, "auto"):
            raise ValueError("Harness transport does not support forced tool choice")
        return self.bind(tools=[convert_to_openai_tool(tool) for tool in tools], **kwargs)

    def with_structured_output(self, schema, *, include_raw=False, **kwargs):
        from langchain_core.runnables import RunnableLambda
        spec = schema.model_json_schema() if hasattr(schema, "model_json_schema") else schema

        def generate(value):
            from langchain_core.messages import SystemMessage
            messages = value.to_messages() if hasattr(value, "to_messages") else value
            if isinstance(messages, str):
                from langchain_core.messages import HumanMessage
                messages = [HumanMessage(content=messages)]
            raw = self.invoke([SystemMessage(content="Return only JSON matching this schema: " + json.dumps(spec)), *messages])
            try:
                text = raw.content.strip()
                if text.startswith("```"):
                    text = text.split("\n", 1)[1].rsplit("```", 1)[0]
                parsed = json.loads(text)
                if hasattr(schema, "model_validate"):
                    parsed = schema.model_validate(parsed)
                elif isinstance(schema, dict):
                    import jsonschema
                    jsonschema.validate(parsed, schema)
            except Exception as exc:
                if include_raw:
                    return {"raw": raw, "parsed": None, "parsing_error": exc}
                raise
            return {"raw": raw, "parsed": parsed, "parsing_error": None} if include_raw else parsed
        return RunnableLambda(generate)
