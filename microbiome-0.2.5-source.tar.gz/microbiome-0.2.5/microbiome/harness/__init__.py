"""Harness-owned model transport and portable workflow integration."""

from microbiome.protocol import PROTOCOL_VERSION
