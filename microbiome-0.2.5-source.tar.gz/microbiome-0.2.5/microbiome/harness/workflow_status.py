"""Read-only projection of durable workflow evidence into six conversation stages.

This is a display projection, never an execution authorization. Polling validates
small persisted contracts; production still performs its full resource/input
preflight. No discovery, model call, repair, or directory creation occurs here.
"""

from __future__ import annotations

import re
from pathlib import Path

from microbiome.conversation_memory import pending_design_questions
from microbiome.pipeline.io import object_fingerprint, read_json, read_yaml
from microbiome.pipeline.project import PipelineProject

TITLES = ("目录设置", "目标与研究思路", "流程确认", "5%–10% 小数据验证", "全量分析", "报告与结果")
REPORT_LIMIT = 512_000


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _fingerprinted(value, field):
    return (
        isinstance(value, dict)
        and bool(value.get(field))
        and value[field] == object_fingerprint({key: item for key, item in value.items() if key != field})
    )


def _within(path, root):
    path, root = Path(path).resolve(), Path(root).resolve()
    _require(path != root and path.is_relative_to(root), "记录路径不在当前项目目录内。")
    return path


def _report_path(project, name):
    _require(isinstance(name, str) and name and Path(name).name == name, "报告名称无效。")
    _require(Path(name).suffix.lower() in {".md", ".json"}, "只支持 Markdown 和 JSON 报告。")
    root = project.output_root / "reports"
    _require(not root.is_symlink(), "报告目录不能链接到其他目录。")
    path = _within(root / name, root)
    _require(path.is_file(), "报告文件不存在。")
    return path


def read_report(project_path, name):
    """Read bounded report text without allowing path traversal or symlink escape."""
    project = PipelineProject(project_path)
    project.load_config()
    path = _report_path(project, name)
    with path.open("rb") as stream:
        content = stream.read(REPORT_LIMIT + 1)
    text = content[:REPORT_LIMIT].decode("utf-8", errors="replace")
    return text + ("\n[报告较长，仅展示前 512 KB；完整文件保存在项目报告目录。]" if len(content) > REPORT_LIMIT else "")


def _finish(result, blocked=None, detail=None):
    if blocked:
        result["stages"][blocked - 1].update(status="blocked", detail=detail)
    first = next((row for row in result["stages"] if row["status"] != "completed"), None)
    result["current_stage"] = first["id"] if first else 6
    if first and first["status"] == "pending":
        first["status"] = "current"
    return result


def _done(result, stage, detail):
    result["stages"][stage - 1].update(status="completed", detail=detail)


def _manifest(project, paths):
    value = read_yaml(project.requirements_dir / "input_manifest.yaml")
    _require(_fingerprinted(value, "manifest_fingerprint"), "输入清单缺失、损坏或已改变。")
    samples = value.get("samples")
    _require(isinstance(samples, list) and samples, "输入清单没有有效样本。")
    ids = [sample.get("sample_id") for sample in samples if isinstance(sample, dict)]
    _require(
        len(ids) == len(samples) and all(isinstance(i, str) and i.strip() for i in ids) and len(set(ids)) == len(ids),
        "输入清单包含无效或重复样本。",
    )
    _require(not value.get("unresolved"), "输入来源尚未确认。")
    if value.get("input_kind") == "external_cohort_tables":
        from microbiome.pipeline.external_cohort import verify_external_manifest
        return verify_external_manifest(project, value)
    if value.get("input_kind") == "completed_run_artifacts":
        from microbiome.pipeline.derived import verify_derived_manifest
        return verify_derived_manifest(project, value)
    remote = [sample for sample in samples if sample.get("source_type") == "REMOTE_SRA_RUN"]
    for sample in samples:
        if sample in remote:
            transfers = [
                item for item in value.get("remote_transfers", []) if item.get("sample_id") == sample["sample_id"]
            ]
            _require(
                re.fullmatch(r"(?:SRR|ERR|DRR)\d+", sample.get("accession", ""))
                and transfers
                and all(
                    item.get("accession") == sample["accession"]
                    and item.get("url")
                    and item.get("checksum")
                    and isinstance(item.get("bytes"), int)
                    and item["bytes"] > 0
                    and Path(item["path"]).is_absolute()
                    for item in transfers
                ),
                "远程样本尚未形成明确、可确认的逐记录获取方案。",
            )
        else:
            files = [sample[key] for key in ("r1", "r2", "fasta") if sample.get(key)]
            _require(
                files and all(Path(item["path"] if isinstance(item, dict) else item).is_file() for item in files),
                "本地样本文件缺失；这不会触发远程下载。",
            )
    _require(
        value.get("resolution_status") == "CONFIRMED"
        or (value.get("resolution_status") == "PENDING" and remote and value.get("requires_raw_data_download")),
        "输入来源尚未确认。",
    )
    _require(
        Path(value["raw_data_root"]).resolve() == Path(paths["raw_data"]).resolve(), "输入清单与已确认数据目录不一致。"
    )
    return value


def _draft(project, manifest, state):
    from microbiome.pipeline.models import validate_experiment_plan

    draft = state.get("draft")
    _require(_fingerprinted(draft, "draft_fingerprint"), "分析思路尚未形成有效方案，或方案已改变。")
    manifest_matches = draft.get("input_fingerprint") == object_fingerprint(manifest)
    if not manifest_matches and manifest.get("acquisition_approval_input_fingerprint") == draft.get(
        "input_fingerprint"
    ):
        receipt = read_json(project.state_dir / "user_execution_approval.json")
        requirements = read_yaml(project.requirements_path)
        manifest_matches = (
            not manifest.get("requires_raw_data_download")
            and receipt.get("draft_fingerprint") == state.get("approved_draft") == draft["draft_fingerprint"]
            and requirements.get("input", {}).get("manifest_fingerprint") == draft["input_fingerprint"]
        )
    _require(not state.get("input_error") and manifest_matches, "当前方案与输入清单不一致，请重新设计。")
    plan = validate_experiment_plan(draft["plan"])
    _require(plan["plan_fingerprint"] == draft["plan"]["plan_fingerprint"], "分析方案指纹无效。")
    _require(
        state.get("failed_design") != object_fingerprint([plan["plan_fingerprint"], draft["dependency_scope"]]),
        "当前方案的小数据验证失败，需要修订后重新确认。",
    )
    return draft


def _research(project, draft):
    from microbiome.pipeline.evidence import evidence_gaps
    from microbiome.pipeline.planning_context import PlanningContext

    receipt = draft["planning_evidence"]
    path = _within(receipt["path"], project.plans_dir / "planning_evidence")
    context = read_json(path)
    _require(
        _fingerprinted(context, "context_fingerprint")
        and context["context_fingerprint"] == receipt["context_fingerprint"],
        "软件知识检索记录缺失或已改变。",
    )
    # Use the same pure scope function as the evidence producer. A second
    # formula drifts when resource/workflow/figure contracts gain fields.
    scope = PlanningContext.scope(draft["plan"])
    _require(
        context.get("scope_fingerprint") == receipt.get("scope_fingerprint") == scope,
        "软件知识检索记录不属于当前分析方案。",
    )
    evidence = draft.get("evidence", {})
    status = evidence.get("external_evidence_status", "not_requested")
    source_evidence = evidence
    # Empty legacy registries are valid evidence of no search, never a completed search.
    if status != "not_requested":
        if evidence.get("gaps_are_derived") is True:
            # The view retains the registry's seal. Derived presentation fields
            # must match their source, but are not part of that original seal.
            source_evidence = {key: value for key, value in evidence.items()
                               if key not in {"evidence_gaps", "gaps_are_derived"}}
            _require(evidence.get("evidence_gaps") == evidence_gaps(source_evidence),
                     "研究依据缺口视图与来源记录不一致。")
        _require(_fingerprinted(source_evidence, "evidence_fingerprint"), "网络研究记录指纹无效。")
    sources = evidence.get("sources", [])
    retrieved = [
        source
        for source in sources
        if isinstance(source, dict)
        and str(source.get("source", "")).startswith(("https://", "http://"))
        and source.get("review_status") == "retrieved"
        and source.get("read_scope") in {"title_and_abstract", "document", "full_text"}
        and (source.get("content_sha256") or source.get("content_fingerprint"))
    ]
    if status == "available":
        _require(retrieved, "网络检索没有可核验的已读取来源，请补充依据或重新检索。")
    return status, len(context.get("tools", {})), len(retrieved), evidence_gaps(source_evidence)


def _execution_approval(project, state, draft):
    from microbiome.pipeline.approval import ProductionApprovalManager, ProductionIntent
    from microbiome.pipeline.models import validate_experiment_plan
    from microbiome.pipeline.requirements import RequirementManager

    receipt = read_json(project.state_dir / "user_execution_approval.json")
    if "approved_pretest" in state:
        _require(receipt.get("pretest") == state["approved_pretest"], "小数据采样设置与执行确认不一致。")
    _require(
        receipt.get("draft_fingerprint") == state.get("approved_draft") == draft["draft_fingerprint"],
        "执行确认不属于当前方案。",
    )
    from microbiome.agent.checkpoint_review import validate_execution_approval
    validate_execution_approval(project, receipt, draft=draft)
    requirements = RequirementManager(project).require_confirmed()
    _require(receipt.get("requirements_version") == requirements["requirements_version"], "需求修改后需要重新确认。")
    plan = validate_experiment_plan(read_yaml(project.plan_path))
    expected = validate_experiment_plan({**draft["plan"], "requirements_version": requirements["requirements_version"]})
    _require(
        plan["plan_fingerprint"] == expected["plan_fingerprint"] == receipt.get("plan_fingerprint"),
        "已批准流程与当前方案不一致。",
    )
    for name in ("analysis_plan", "dependencies"):
        approval = requirements.get("approvals", {}).get(name, {})
        _require(
            approval.get("status") == "CONFIRM"
            and approval.get("requirements_version") == requirements["requirements_version"]
            and approval.get("plan_fingerprint") == plan["plan_fingerprint"]
            and approval.get("source") != "auto_backfilled_from_successful_pretest",
            "流程或依赖确认已失效。",
        )
    return plan, requirements


def _pretest(project, plan, requirements, phase):
    from microbiome.pipeline.cases import verify_validation_suite
    from microbiome.pipeline.freeze import _verified_report
    from microbiome.pipeline.lock_schema import validate_pipeline_lock
    from microbiome.pipeline.readiness import load_current_readiness

    _require(
        phase
        in {
            "PRODUCTION_READY",
            "AWAITING_PRODUCTION_APPROVAL",
            "PAUSED",
            "PRODUCTION_APPROVED",
            "PRODUCTION_PREFLIGHT",
            "PRODUCTION_RUNNING",
            "COMPLETED",
        },
        "小数据验证及冻结尚未全部通过。",
    )
    pipeline = validate_pipeline_lock(read_yaml(project.pipeline_lock_path))
    _require(
        pipeline["plan_fingerprint"] == plan["plan_fingerprint"]
        and pipeline["requirements_fingerprint"] == requirements["requirements_fingerprint"],
        "冻结流程与当前批准方案不一致。",
    )
    readiness = load_current_readiness(project, pipeline)
    _require(
        isinstance(readiness.get("areas"), dict)
        and readiness["areas"]
        and all(area.get("status") in {"PASSED", "WARNING"} for area in readiness["areas"].values()),
        "生产就绪记录存在未通过检查。",
    )
    for path, field in (
        (project.toolchain_lock_path, "toolchain_lock_fingerprint"),
        (project.database_lock_path, "database_lock_fingerprint"),
    ):
        value = read_yaml(path)
        _require(
            _fingerprinted(value, "manifest_fingerprint") and value["manifest_fingerprint"] == pipeline[field],
            "软件或数据库锁已改变。",
        )
    report = _verified_report(project.validation_report_path, plan)
    _require(
        report["report_fingerprint"] == pipeline["validation_report_fingerprint"], "小数据验证报告与冻结流程不一致。"
    )
    fraction = report.get("pretest_fraction")
    complete_cohort = plan.get("pilot_mode") in {"complete_external_cohort", "complete_derived_samples"}
    if complete_cohort:
        _require(fraction is None and report.get("representative_subset", {}).get("sampling_performed") is False,
                 "完整表格预检必须保留全表，不能冒充 reads 抽样。")
    else:
        _require(isinstance(fraction, (float, int)) and 0.05 <= fraction <= 0.10, "当前验证未使用 5%–10% 的数据比例。")
    suite = verify_validation_suite(project, plan)
    pretest = read_json(project.state_dir / "user_execution_approval.json").get("pretest") or {}
    _require(pretest.get("fraction") in (None, fraction), "小数据报告与用户批准的采样比例不一致。")
    if pretest.get("all_samples"):
        _require(
            suite and suite.get("sampling_scope") in {"all_samples", "cohort"}, "小数据验证没有覆盖用户批准的全部样本。"
        )
    return pipeline, fraction


def _run_manifest(project, path, pipeline):
    manifest = read_yaml(_within(path, project.runs_dir))
    _require(
        manifest.get("status") == "COMPLETED"
        and manifest.get("pipeline_hash") == pipeline["pipeline_hash"]
        and manifest.get("requirements_version") == pipeline["requirements_version"],
        "全量运行未完成或不属于当前冻结流程。",
    )
    _require(
        manifest.get("preflight", {}).get("status") == "PASSED"
        and manifest.get("preflight", {}).get("input_rebinding", {}).get("status") == "PASSED"
        and manifest["preflight"].get("pipeline_hash") == pipeline["pipeline_hash"],
        "全量输入预检记录未通过。",
    )
    steps = manifest.get("steps", {})
    _require(
        all(steps.get(step["step_id"], {}).get("status") in {"COMPLETED", "REUSED"} for step in pipeline["steps"]),
        "全量运行存在未完成步骤。",
    )
    for step in pipeline["steps"]:
        checkpoint = read_json(_within(steps[step["step_id"]]["checkpoint"], project.runs_dir))
        _require(
            checkpoint.get("completion_status") == "COMPLETED"
            and checkpoint.get("step_id") == step["step_id"]
            and checkpoint.get("pipeline_hash") == pipeline["pipeline_hash"]
            and checkpoint.get("output_fingerprint"),
            "全量步骤检查点缺失、未完成或版本不匹配。",
        )
        for metadata in checkpoint["output_fingerprint"].values():
            output = _within(metadata["path"], project.runs_dir)
            stat = output.stat()
            _require(
                not metadata.get("missing")
                and (
                    metadata.get("kind") != "file"
                    or (
                        output.is_file()
                        and stat.st_size == metadata["bytes"]
                        and stat.st_mtime_ns == metadata["mtime_ns"]
                    )
                ),
                "全量交付文件缺失或已改变。",
            )
    return manifest


def _production(project, pipeline, manifest, phase):
    from microbiome.pipeline.approval import ProductionApprovalManager

    _require(phase == "COMPLETED", "全量分析尚未完成。")
    ProductionApprovalManager(project).require_valid_approval()
    # Select the latest attempt, including failures: old successes cannot mask it.
    batches = list(project.runs_dir.glob("*.production_batch.yaml"))
    runs = list(project.runs_dir.glob("*/run_manifest.yaml"))
    candidates = batches + runs
    _require(candidates, "没有已完成的全量运行记录。")
    path = max(candidates, key=lambda item: (item.stat().st_mtime_ns, item.name))
    if not path.name.endswith(".production_batch.yaml"):
        run = _run_manifest(project, path, pipeline)
        _require(
            len(manifest["samples"]) == 1 and run.get("sample_id") == manifest["samples"][0]["sample_id"],
            "单次运行没有覆盖全部输入样本。",
        )
        return run, [run], None
    batch = read_yaml(path)
    _require(_fingerprinted(batch, "batch_fingerprint"), "全量批次记录损坏或已改变。")
    _require(
        batch.get("status") == "COMPLETED"
        and batch.get("pipeline_hash") == pipeline["pipeline_hash"]
        and batch.get("pipeline_version") == pipeline["pipeline_version"],
        "最新全量批次未完成或流程版本已改变。",
    )
    ids = [sample["sample_id"] for sample in manifest["samples"]]
    rows = batch.get("runs", [])
    completed_ids = [identity for row in rows for identity in row.get("sample_ids", [row.get("sample_id")])]
    _require(
        batch.get("total_samples") == batch.get("completed_samples") == len(ids)
        and sorted(completed_ids) == sorted(ids)
        and not batch.get("pending_samples")
        and not batch.get("failed_samples")
        and rows
        and all(row.get("status") == "COMPLETED" for row in rows),
        "全量批次没有成功覆盖持久清单中的所有样本。",
    )
    manifests = [_run_manifest(project, row["manifest_path"], pipeline) for row in rows]
    _require(
        all(run.get("run_id") == row.get("run_id") for run, row in zip(manifests, rows, strict=True)),
        "批次与逐样本运行记录不一致。",
    )
    return batch, manifests, batch


def _reports(project, pipeline, record, runs, batch):
    files, payloads = [], []

    def add(path):
        path = Path(path)
        actual = _report_path(project, path.name)
        _require(actual == path.resolve() and actual.stat().st_size > 0, "报告路径不属于当前项目，或报告为空。")
        files.append({"name": actual.name, "path": str(actual)})
        return actual

    for run in runs:
        report = run.get("final_report") or {}
        path = add(report["json"])
        payload = read_json(path)
        _require(
            _fingerprinted(payload, "report_fingerprint")
            and payload["report_fingerprint"] == report.get("report_fingerprint")
            and payload.get("run_id") == run["run_id"]
            and payload.get("status") == "COMPLETED"
            and payload.get("pipeline_hash") == pipeline["pipeline_hash"],
            "结果报告损坏、未完成或流程版本不匹配。",
        )
        _require(
            payload.get("steps") and all(step.get("status") in {"COMPLETED", "REUSED"} for step in payload["steps"]),
            "结果报告存在未完成步骤。",
        )
        markdown = add(report["markdown"])
        text = read_report(project.root, markdown.name)
        _require(
            text.startswith(f"# Frozen pipeline run report: {run['run_id']}\n")
            and pipeline["pipeline_hash"] in text
            and "Status: **COMPLETED**" in text,
            "Markdown 报告内容与当前运行不一致。",
        )
        payloads.append(payload)
    if batch:
        final = batch["final_report"]
        index = read_json(add(final["artifact_index"]))
        expected = [
            {"sample_id": row["sample_id"], "status": row["status"], "artifacts": payload.get("artifacts", [])}
            for row, payload in zip(batch["runs"], payloads, strict=True)
        ]
        _require(
            index.get("pipeline_hash") == pipeline["pipeline_hash"] and index.get("samples") == expected,
            "全量交付索引与逐样本结果不一致。",
        )
        markdown = add(final["markdown"])
        text = read_report(project.root, markdown.name)
        _require(
            text.startswith(f"# 全量分析报告：{batch['batch_id']}\n")
            and "执行状态：COMPLETED" in text
            and f"完成样本：{batch['completed_samples']}/{batch['total_samples']}" in text,
            "全量 Markdown 报告与当前批次不一致。",
        )
        files = [item for item in files if item["name"] == markdown.name] + [
            item for item in files if item["name"] != markdown.name
        ]
    summary = (
        f"研究目标：{record.get('objective') or pipeline['objective']}\n"
        f"执行状态：COMPLETED；完成样本：{record.get('completed_samples', 1)}/{record.get('total_samples', 1)}\n"
        f"冻结流程版本：{pipeline['pipeline_version']}\n"
        f"已验证交付记录：{sum(len(payload.get('artifacts', [])) for payload in payloads)} 项。\n"
        "报告汇总计算结果及验证状态；科学结论以已完成并验证的分析步骤为准。"
    )
    return files, summary


def workflow_progress(project_path, *, plan_confirmation=None):
    """Return six-stage progress, failing closed on missing or corrupt evidence."""
    result = {
        "stages": [
            {"id": i, "title": title, "status": "pending", "detail": "等待前一阶段完成。"}
            for i, title in enumerate(TITLES, 1)
        ],
        "current_stage": 1,
        "phase": "UNINITIALIZED",
        "draft_fingerprint": None,
        "plan_ready": False,
        "pending_questions": [],
        "compiler_repair": False,
        "pretest_ready": False,
        "production_complete": False,
        "research_status": "not_requested",
        "research_warnings": [],
        "reports": [],
        "report_summary": "",
    }
    result["stages"][0]["detail"] = "请通过对话依次设置原始数据、数据库和输出目录。"
    if not project_path:
        return _finish(result)
    try:
        project = PipelineProject(project_path)
        if not project.config_path.is_file():
            return _finish(result)
        paths = project.load_config()["paths"]
        _require(
            paths.get("confirmed", paths.get("confirmed_by_user")) is True
            and all(Path(paths[key]).is_dir() for key in ("raw_data", "database", "output")),
            "已配置目录缺失或尚未确认，请检查原始数据、数据库及输出目录。",
        )
        from microbiome.pipeline.state import ProjectStateMachine

        result["phase"] = ProjectStateMachine(project).current.value
        _done(result, 1, "原始数据、数据库与输出目录已确认并保存在项目中。")
    except Exception:
        return _finish(result, 1, "项目路径或生命周期记录无效，请核对目录和项目状态。")
    result["stages"][1]["detail"] = "请描述具体分析目标；将结合软件知识库和网络研究设计思路。"
    try:
        state_path = project.state_dir / "conversation.json"
        if not state_path.is_file():
            return _finish(result)
        state = read_json(state_path)
        _require(isinstance(state, dict), "对话工作流状态无效。")
        result["pending_questions"] = pending_design_questions(state)
        result["compiler_repair"] = bool(state.get("compiler_repair"))
        if not result["compiler_repair"]:
            last = next((item for item in reversed(state.get("history", []))
                         if item.get("role") == "assistant" and item.get("event") != "status"), {})
            result["compiler_repair"] = (last.get("event") == "workflow_blocked"
                                         and "内部方案编译未通过格式检查" in last.get("content", ""))
        if not state.get("draft"):
            return _finish(result)
        manifest = _manifest(project, paths)
        draft = _draft(project, manifest, state)
        result.update(plan_ready=True, draft_fingerprint=draft["draft_fingerprint"])
        research, tool_count, source_count, gaps = _research(project, draft)
        result["research_status"] = research
        result["research_warnings"] = gaps
        if research != "available":
            label = {
                "not_requested": "尚未进行网络检索",
                "unavailable": "网络检索失败",
                "no_results": "网络检索无结果",
            }.get(research, "网络依据无效")
            if research not in {"no_results", "unavailable"} or any(gap.get("blocking") for gap in gaps):
                return _finish(result, 2, label + "，请完成检索或补齐必需依据后确认方案。")
            _done(result, 2, f"输入清单与分析方案已保存；已核对 {tool_count} 项软件知识。"
                  + label + "；缺口已记录，未获得外部文献支持，可继续审阅方案。")
        else:
            _done(result, 2, f"输入清单与分析方案已保存；已核对 {tool_count} 项软件知识、读取 {source_count} 项网络来源。")
    except Exception:
        return _finish(result, 2, "输入、当前方案或研究依据记录无效，请修订或重新生成方案。")
    result["stages"][2]["detail"] = "请核对具体步骤、工具参数、资源和交付物，明确回复“确认方案”。"
    approved = None
    try:
        approved = _execution_approval(project, state, draft)
    except Exception:
        pass
    if not approved and plan_confirmation != draft["draft_fingerprint"]:
        return _finish(result)
    _done(result, 3, "当前方案已有可核验的确认记录，绑定指纹对应的分析流程。")
    result["stages"][3]["detail"] = "请明确批准执行；使用 5%–10% 数据串联流程，全部验证通过后冻结。"
    if not approved:
        return _finish(result)
    try:
        if not project.pipeline_lock_path.is_file() and result["phase"] not in {
            "PRETEST_REPAIR",
            "PRETEST_FINALIZATION_FAILED",
            "REVALIDATION_REQUIRED",
        }:
            return _finish(result)
        pipeline, fraction = _pretest(project, *approved, result["phase"])
        result["pretest_ready"] = True
        label = "完整表格" if fraction is None else f"{fraction:.0%} 数据"
        if fraction is None:
            result["stages"][3]["title"] = "完整表格预检"
        _done(result, 4, f"{label}验证通过；冻结锁、批准记录与生产就绪证据一致。")
    except Exception:
        return _finish(result, 4, "小数据验证或冻结证据未通过、缺失或已失效；请查看运行结果并修复。")
    result["stages"][4]["detail"] = "等待“确认全量执行”；复用已测试的冻结流程处理全部原始数据。"
    try:
        if result["phase"] != "COMPLETED":
            return _finish(result)
        record, runs, batch = _production(project, pipeline, manifest, result["phase"])
        result["production_complete"] = True
        _done(result, 5, "最新全量运行已成功覆盖持久输入清单中的所有样本。")
    except Exception:
        return _finish(result, 5, "最新全量运行没有完整有效的成功证据；旧结果不会计为当前完成。")
    result["stages"][5]["detail"] = "等待当前全量运行的有效报告与交付索引。"
    try:
        result["reports"], result["report_summary"] = _reports(project, pipeline, record, runs, batch)
        _done(result, 6, "当前运行的结果报告与交付索引已核验，可在对话中阅读。")
    except Exception:
        return _finish(result, 6, "当前运行的报告缺失、损坏或与结果不一致，请检查报告生成。")
    return _finish(result)
