"""One project operation over bidirectional NDJSON; stdout is protocol-only."""
from __future__ import annotations

import contextlib
import fcntl
import hashlib
import json
import os
import signal
import sys
import threading
import uuid
from pathlib import Path

from microbiome.harness import PROTOCOL_VERSION

MAX_FRAME = 32 * 1024 * 1024


class Protocol:
    def __init__(self, reader=None, writer=None):
        self.reader = reader or sys.stdin
        self.writer = writer or sys.__stdout__
        self.exchange_lock = threading.RLock()

    def read(self):
        line = self.reader.readline(MAX_FRAME + 1)
        if not line or len(line.encode("utf8")) > MAX_FRAME:
            raise RuntimeError("HARNESS_PROTOCOL_CLOSED_OR_OVERSIZED")
        value = json.loads(line)
        if not isinstance(value, dict) or value.get("protocol") != PROTOCOL_VERSION:
            raise ValueError("HARNESS_PROTOCOL_VERSION_MISMATCH")
        return value

    def emit(self, kind, **fields):
        line = json.dumps({"protocol": PROTOCOL_VERSION, "type": kind, **fields}, ensure_ascii=False)
        if len(line.encode("utf8")) > MAX_FRAME:
            raise ValueError("HARNESS_PROTOCOL_FRAME_TOO_LARGE")
        self.writer.write(line + "\n")
        self.writer.flush()

    def model(self, params):
        with self.exchange_lock:
            return self._model(params)

    def _model(self, params):
        request_id = uuid.uuid4().hex
        self.emit("model_request", id=request_id, params=params)
        reply = self.read()
        if reply.get("type") != "model_response" or reply.get("id") != request_id:
            raise RuntimeError("HARNESS_PROTOCOL_RESPONSE_MISMATCH")
        return reply.get("result", {"error": "missing model result"})


def _user_path_attribution(request, values):
    """Only role-labelled, actual host user text can attribute a binding to a user.

    Tool path arguments and path_origins are configuration suggestions. Relative
    user declarations share the host workspace anchor, never the worker cwd.
    """
    import re
    labels = {
        "raw_data": r"原始(?:数据|文件|输入)(?:目录|路径)?|输入(?:数据|目录|路径)|raw(?:[ _-]data)?(?:[ _-](?:directory|dir|path|root))?|data_dir",
        "database": r"(?:持久)?数据库(?:根目录|目录|路径)?|db_dir|database(?:[ _-](?:directory|dir|path|root))?",
        "output": r"输出(?:目录|路径)?|结果(?:目录|路径)|项目(?:目录|路径)|project|output(?:[ _-](?:directory|dir|path|root))?",
        "download": r"下载(?:缓存)?(?:目录|路径)?|download_dir|download(?:[ _-](?:directory|path|root))?",
        "knowledge": r"知识(?:库)?(?:目录|路径)?|knowledge_dir|knowledge(?:[ _-](?:directory|path|root))?",
    }
    quoted = r'''(?:`([^`\n]+)`|"([^"\n]+)"|'([^'\n]+)'|“([^”\n]+)”|([^\s，。；,;]+))'''
    patterns = {role: re.compile(r"(?<![A-Za-z0-9_/\\.-])(?:" + label + r")\s*(?:[:：=]|位于|使用|设为|设置为|保存在|保存到|在|为|是|\s)\s*(?:((?:工作区|工作目录|workspace)\s*[>＞]\s*)?)" + quoted, re.I)
                for role, label in labels.items()}
    breadcrumbs = re.compile(r"((?:工作区|工作目录|workspace)\s*[>＞]\s*)" + quoted, re.I)
    workspace = request.get("host_workspace")
    workspace = Path(workspace).expanduser().resolve() if workspace and Path(workspace).is_absolute() else None
    history = request.get("historical_context") or []
    messages = [(str(row.get("host_event_id", "")), row.get("content", "")) for row in history
                if isinstance(row, dict) and row.get("role") == "user" and row.get("host_event_id")]
    if isinstance(request.get("message"), str):
        messages.append((str(request.get("message_id", "current")), request["message"]))
    selected = {}
    seen = {}
    for event_id, text in messages:
        if not isinstance(text, str):
            continue
        if event_id in seen and seen[event_id] != text:
            raise ValueError("HOST_HISTORY_EVENT_CONFLICT")
        seen[event_id] = text
        matches = [(role, match) for role, pattern in patterns.items() for match in pattern.finditer(text)]
        matches += [("output", match) for match in breadcrumbs.finditer(text)
                    if not any(label.start() <= match.start() < label.end() for _, label in matches)]
        for role, match in sorted(matches, key=lambda item: item[1].start()):
            if re.search(r"(?:不要使用|不使用|不用|不要|并非|not|don't use)\s*$", text[max(0, match.start()-20):match.start()], re.I):
                continue
            breadcrumb = match.group(1)
            value = next(part for part in match.groups()[1:] if part is not None).rstrip("。.;，,；")
            candidate = Path(value).expanduser()
            if breadcrumb:
                if workspace is None:
                    continue
                candidate = (workspace / value.lstrip("/\\")).resolve()
                if not candidate.is_relative_to(workspace):
                    continue
            elif not candidate.is_absolute():
                if workspace is None:
                    continue
                candidate = workspace / candidate
            selected[role] = (str(candidate.resolve()), event_id)
    hints = request.get("path_origins") or {}
    hints = hints if isinstance(hints, dict) else {}
    origins = {role: "user" if selected.get(role, (None,))[0] == str(Path(value).resolve()) else
               "default" if hints.get(role) == "default" else "configured" for role, value in values.items()}
    direct = all(origins[role] == "user" for role in ("raw_data", "database", "output"))
    confirmation = {"type": "user_direct" if direct else "configured",
                    "source": ("harness_user_path_declarations:" + str(request.get("session_id", "unknown")) + ":" +
                               ",".join(dict.fromkeys(selected[role][1] for role in ("raw_data", "database", "output")))) if direct else "harness_path_configuration_requires_review"}
    return origins, confirmation


def _confirm_configured_paths(project, confirmation):
    """Publish the effective path flag last, after real review has been recorded.

    An interrupted update remains fail-closed through the existing false config
    flag. Retrying the same attributable confirmation finishes idempotently.
    """
    from datetime import UTC, datetime
    from microbiome.pipeline.io import object_fingerprint, read_json, write_json, write_yaml
    from microbiome.pipeline.locking import project_operation_lock
    from microbiome.pipeline.requirements import ConfirmationAction, RequirementManager
    from microbiome.pipeline.state import LifecycleState, ProjectStateMachine
    with project_operation_lock(project, reentrant=True):
        config = project.load_config()
        if config["paths"].get("confirmed", config["paths"].get("confirmed_by_user", False)):
            return
        machine, manager = ProjectStateMachine(project), RequirementManager(project)
        if project.pipeline_lock_path.exists() or machine.current not in {LifecycleState.NEW, LifecycleState.PATH_CONFIRMATION, LifecycleState.DATA_DISCOVERY}:
            raise ValueError("PATH_CONFIRMATION_PHASE_DENIED: path confirmation requires the initial path phase")
        requirements = manager.load()
        expected = {"raw_data": config["paths"]["raw_data"], "database_root": config["paths"]["database"], "output_root": config["paths"]["output"]}
        if requirements.get("paths") != expected:
            raise ValueError("PATH_CONFIRMATION_CONFLICT: persisted path requirements differ from the configured bindings")
        identity = object_fingerprint({"paths": expected, "confirmation": confirmation})
        journal = project.state_dir / "path_confirmations" / f"{identity}.json"
        receipt = read_json(journal) if journal.is_file() else {
            "schema_version": 1, "status": "PREPARED", "confirmation_fingerprint": identity,
            "source": confirmation, "paths": expected, "created_at": datetime.now(UTC).isoformat()}
        write_json(journal, receipt)
        if not requirements["confirmed_fields"].get("paths"):
            requirements["confirmed_fields"]["paths"] = True
            requirements["unresolved_questions"] = [key for key in requirements.get("unresolved_questions", []) if key != "paths"]
            requirements["last_updated"] = receipt["created_at"]
            requirements["requirements_fingerprint"] = manager._fingerprint(requirements)
            write_yaml(manager.path, requirements)
        decisions = [json.loads(line) for line in manager.log_path.read_text().splitlines() if line.strip()]
        source = {**confirmation, "confirmation_fingerprint": identity}
        if not any(row.get("source", {}).get("confirmation_fingerprint") == identity for row in decisions):
            manager._append_decision(topic="paths", previous_value=expected, new_value=expected,
                action=ConfirmationAction.CONFIRM, confirmed_by_user=confirmation["type"] == "user_direct",
                requirements_version=requirements["requirements_version"], decision_source=source)
        manager._write_summary(requirements)
        if machine.current in {LifecycleState.NEW, LifecycleState.PATH_CONFIRMATION}:
            machine.advance_to(LifecycleState.DATA_DISCOVERY, reason="configured paths reviewed through their recorded confirmation source")
        config["paths"].update(confirmed=True, confirmed_by_user=confirmation["type"] == "user_direct", confirmed_at=receipt["created_at"])
        config["path_confirmation"] = confirmation
        write_json(journal, {**receipt, "status": "RECORDED"})
        write_yaml(project.config_path, config)


def open_project(request, *, path_confirmation=None):
    from microbiome.pipeline.project import PipelineProject
    # This keyword is for trusted Python UI adapters after an actual review;
    # it is deliberately absent from the model tool schema and JSON request.
    if "path_confirmation" in request:
        raise ValueError("PATH_CONFIRMATION_SOURCE_REQUIRED: model request fields cannot supply path approval")
    root = Path(request["project"]).expanduser().resolve()
    if (root / "project_config.yaml").is_file():
        project = PipelineProject(root)
        # A resumed project owns its paths, not the latest tool arguments.
        paths = project.load_config()["paths"]
        for arg, key in (("data_dir", "raw_data"), ("db_dir", "database"), ("download_dir", "download"), ("knowledge_dir", "knowledge")):
            if request.get(arg) and Path(request[arg]).expanduser().resolve() != Path(paths[key]).resolve():
                raise ValueError(f"Persisted {arg} differs; open the correct project instead of changing its paths")
        if paths.get("confirmed", paths.get("confirmed_by_user", False)):
            return project
        values = {key: paths[key] for key in ("raw_data", "database", "output", "download", "knowledge") if paths.get(key)}
        _, confirmation = _user_path_attribution(request, values)
        confirmation = path_confirmation or confirmation
        if confirmation.get("type") in {"user_direct", "host_delegation"}:
            _confirm_configured_paths(project, confirmation)
            return project
        raise ValueError("PATH_CONFIRMATION_REQUIRED: 请核对已保存的三个目录，并在真实消息中逐项明确确认：" + json.dumps(
            {"原始数据": paths["raw_data"], "数据库": paths["database"], "输出目录": paths["output"]}, ensure_ascii=False))
    if not request.get("data_dir") or not request.get("db_dir"):
        raise ValueError("NEEDS_PATHS: 新项目需要原始数据 data_dir、持久数据库 db_dir 和结果项目 project 路径")
    values = {"raw_data": request["data_dir"], "database": request["db_dir"], "output": root,
              "download": request.get("download_dir") or root / "downloads", "knowledge": request.get("knowledge_dir") or root / "knowledge"}
    origins, confirmation = _user_path_attribution(request, values)
    origins.update({key: "default" for key, arg in (("download", "download_dir"), ("knowledge", "knowledge_dir")) if not request.get(arg)})
    project = PipelineProject.initialize(root, raw_data_path=request["data_dir"],
        database_path=request["db_dir"], output_path=root,
        download_path=request.get("download_dir") or root / "downloads",
        knowledge_path=request.get("knowledge_dir") or root / "knowledge",
        path_origins=origins, path_confirmation=path_confirmation or confirmation, host_workspace=request.get("host_workspace"))
    if not project.load_config()["paths"].get("confirmed"):
        return open_project(request)
    return project


def run_operation(request, protocol):
    if request.get("protocol") != PROTOCOL_VERSION or request.get("type") not in {"run", "maintenance", "resume_planning", "capabilities", "database", "checkpoint"}:
        raise ValueError("HARNESS_PROTOCOL_VERSION_MISMATCH")
    if any(key in request for key in ("api_key", "base_url", "turns", "model", "source")):
        raise ValueError("Host model configuration cannot be supplied to the workflow worker")
    from microbiome.integrations.capabilities import runtime_capabilities, check_host_contract
    if request["type"] == "capabilities":
        return {"ok": True, "capabilities": runtime_capabilities(request.get("project"))}
    check_host_contract(request.get("expected_capabilities"))
    for key in ("project", "session_id", "message_id", "message"):
        if not isinstance(request.get(key), str) or not request[key].strip():
            raise ValueError(f"Missing {key}")
    root = Path(request["project"]).expanduser().resolve()
    if request["type"] == "checkpoint":
        if not (root / "project_config.yaml").is_file():
            raise ValueError("NEEDS_PROJECT: checkpoint review requires an initialized project")
        return _checkpoint_operation(request, protocol)
    if request["type"] == "database":
        if not (root / "project_config.yaml").is_file():
            raise ValueError("NEEDS_PROJECT: database services require an initialized project")
        from microbiome.pipeline.database_service import database_operation
        from microbiome.pipeline.project import PipelineProject
        from microbiome.agent.recovery import planning_recovery_snapshot
        project = PipelineProject(root)
        result = database_operation(project, request.get("operation"), request.get("arguments", {}),
            user_message=request["message"], message_id=request["message_id"], session_id=request["session_id"])
        return {"ok": True, "project": str(root), "result": result,
                "planning_recovery": planning_recovery_snapshot(project)}
    if request["type"] == "maintenance":
        if not (root / "project_config.yaml").is_file():
            raise ValueError("NEEDS_PROJECT: maintenance requires an initialized project")
        from microbiome.pipeline.maintenance import execute_maintenance
        from microbiome.pipeline.project import PipelineProject
        result = execute_maintenance(PipelineProject(root), request.get("operation"), request.get("arguments", {}),
            user_message=request["message"], message_id=request["message_id"], session_id=request["session_id"],
            host_events=request.get("host_events"))
        from microbiome.agent.recovery import planning_recovery_snapshot
        recovery = result.get("planning_recovery")
        if recovery is None and request["operation"] in {"repair_input", "planning_policy"}:
            recovery = planning_recovery_snapshot(PipelineProject(root))
        return {"ok": True, "project": str(root), "operation": request["operation"], "result": result,
                **({"planning_recovery": recovery} if recovery is not None else {})}
    if request["type"] == "resume_planning":
        import re
        if not (root / "project_config.yaml").is_file():
            raise ValueError("NEEDS_PROJECT: planning recovery requires an initialized project")
        if not re.fullmatch(r"[a-f0-9]{64}", request.get("recovery_token", "")):
            raise ValueError("INVALID_RECOVERY_TOKEN: inspect current planning recovery first")
    root.mkdir(parents=True, exist_ok=True)
    # Serialize first initialization as well as every later operation.
    from microbiome.pipeline.locking import project_operation_lock
    with project_operation_lock(root):
        return _run_project_operation(request, protocol)


def _checkpoint_operation(request, protocol):
    """Native review bridge; the request cannot create a delegation grant."""
    import re
    from microbiome.agent.checkpoint_review import inspect_checkpoint, confirm_checkpoint, execute_checkpoint
    from microbiome.agent.workflow import ConversationWorkflow
    from microbiome.pipeline.project import PipelineProject
    from microbiome.pipeline.locking import project_operation_lock
    from microbiome.pipeline.state import ProjectStateMachine
    allowed = {"protocol", "type", "expected_capabilities", "project", "session_id", "message_id", "message",
               "action", "checkpoint", "review_fingerprint", "authorization_fingerprint", "reason", "request_id"}
    if set(request) - allowed:
        raise ValueError("UNSUPPORTED_CHECKPOINT_ARGUMENT")
    action, checkpoint = request.get("action"), request.get("checkpoint")
    if action not in {"inspect", "confirm", "execute"} or checkpoint not in {"pretest", "production"}:
        raise ValueError("INVALID_CHECKPOINT_ACTION")
    if action == "inspect" and any(key in request for key in ("review_fingerprint", "authorization_fingerprint", "reason")):
        raise ValueError("CHECKPOINT_INSPECT_IS_READ_ONLY")
    if action != "inspect" and not re.fullmatch(r"[a-f0-9]{64}", request.get("review_fingerprint", "")):
        raise ValueError("INVALID_CHECKPOINT_REVIEW_FINGERPRINT")
    if action == "execute" and any(key in request for key in ("authorization_fingerprint", "reason")):
        raise ValueError("CHECKPOINT_EXECUTION_CONSUMES_EXISTING_DECISION")
    project = PipelineProject(request["project"])
    with project_operation_lock(project.root):
        if action == "inspect":
            return {"ok": True, "project": str(project.root), "result": inspect_checkpoint(project, checkpoint=checkpoint)}
        if action == "confirm":
            result = confirm_checkpoint(project, checkpoint=checkpoint,
                review_fingerprint=request["review_fingerprint"],
                authorization_fingerprint=request.get("authorization_fingerprint"), reason=request.get("reason"))
            return {"ok": True, "project": str(project.root), "result": result}
        if not re.fullmatch(r"[a-f0-9]{64}", request.get("request_id", "")):
            raise ValueError("INVALID_CHECKPOINT_REQUEST_ID")
        from types import SimpleNamespace
        project.export_paths()
        workflow = ConversationWorkflow(project)
        workflow.turn_id = request["message_id"]
        workflow.state["host_session_id"] = request["session_id"]
        agent = None
        if checkpoint == "pretest":
            from microbiome.resource_skills.registry import ResourceSkillRegistry, PACKAGE_SKILL_ROOT
            registry = ResourceSkillRegistry(skill_roots=[PACKAGE_SKILL_ROOT, project.resource_skills_dir],
                db_root=project.load_config()["paths"]["database"], tolerate_invalid=True)
            agent = SimpleNamespace(resource_skill_registry=registry)
            workflow.registry = registry
        events = []
        for event in execute_checkpoint(workflow, agent, checkpoint=checkpoint,
                request_id=request["request_id"], review_fingerprint=request["review_fingerprint"]):
            events.append(event)
            protocol.emit("progress", event=event)
        return {"ok": not any(e.get("type") in {"error", "validation_failed", "workflow_blocked"} for e in events),
                "project": str(project.root), "events": events, "state": ProjectStateMachine(project).current.value,
                "reports": [str(p) for p in sorted(project.output_root.glob("reports/*")) if p.is_file()]}


def _run_project_operation(request, protocol):
    project = open_project(request)
    if request.get("host_model_profile"):
        from microbiome.pipeline.planning_policy import record_host_profile
        record_host_profile(project, request["host_model_profile"])
    project.export_paths()
    os.environ["MICROBIOME_RESOURCE_SKILL_ROOT"] = str(project.resource_skills_dir)
    state = project.state_dir / "harness"
    state.mkdir(parents=True, exist_ok=True)
    recovering = request["type"] == "resume_planning"
    identity = ("recovery-" + request["recovery_token"] if recovering else
                hashlib.sha256(json.dumps([request["session_id"], request["message_id"], str(project.root)]).encode()).hexdigest())
    receipt = state / f"{identity}.json"
    from microbiome.pipeline.io import read_json, write_json
    write_json(project.root / ".microbiome-harness-status.json", {
        "protocol": 1, "output_root": str(project.output_root), "paths": project.load_config()["paths"]})
    with (state / "operation.lock").open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise RuntimeError("PROJECT_BUSY: 同一项目已有活动操作，请查询任务状态") from exc
        from microbiome.agent.recovery import planning_recovery_snapshot
        if receipt.is_file():
            previous = read_json(receipt)
            # Older workers could persist a transient busy result. Such a
            # receipt is not evidence that planning used its bounded attempt.
            if not recovering or not _nonconsuming_failure(previous):
                return {**previous, "reused": True,
                        "planning_recovery": planning_recovery_snapshot(project)}
        if recovering:
            snapshot = planning_recovery_snapshot(project)
            if not snapshot["available"] or snapshot["recovery_token"] != request["recovery_token"]:
                raise ValueError("STALE_OR_UNAVAILABLE_RECOVERY: inspect current evidence before continuing")
        from microbiome.harness.model import HarnessChatModel, use_host_model
        os.environ["MICROBIOME_LLM_TRANSPORT"] = "harness"
        with use_host_model(HarnessChatModel(protocol.model, project=project)):
            from microbiome.agent import A1
            from microbiome.agent.workflow import ConversationWorkflow
            from microbiome.conversation_memory import merge_task_outcomes
            from microbiome.pipeline.state import ProjectStateMachine
            workflow = ConversationWorkflow(project)
            workflow.state["host_session_id"] = request["session_id"]
            workflow.turn_id = request["message_id"]
            if not recovering and "prior_task_outcomes" in request:
                history = workflow.state["history"]
                updated = merge_task_outcomes(history, request["prior_task_outcomes"])
                if len(updated) != len(history):
                    workflow.state["history"] = updated
                    workflow.save()
            if not recovering and request.get("historical_context"):
                workflow.import_history(request["historical_context"], source=request["session_id"])
            agent = A1(path=str(project.state_dir / "agent_runtime"),
                       enable_datalake_download=False, require_frozen_production=True,
                       resource_skill_dirs=[str(project.resource_skills_dir)])
            agent.harness_planning = True
            workflow.guided_confirmation = bool(request.get("pretest_all_samples"))
            workflow.registry = agent.resource_skill_registry
            workflow.auto_install = True
            if "pretest_fraction" in request:
                workflow.pretest_fraction = request["pretest_fraction"]
            if "pretest_all_samples" in request:
                workflow.pretest_all_samples = request["pretest_all_samples"]
            events = []
            stream = workflow.resume_planning(agent) if recovering else workflow.handle(agent, request["message"])
            try:
                for event in stream:
                    events.append(event)
                    protocol.emit("progress", event=event)
            except Exception as error:
                if not recovering:
                    raise
                from microbiome.pipeline.diagnostics import error_diagnostic
                # This branch may persist the admitted recovery attempt below;
                # an interrupted workflow is not itself a compiler repair.
                diagnostic = error_diagnostic(error, context="planning_recovery")
                if not diagnostic["consumes_recovery_attempt"]:
                    raise
                event = {"type": "error", "code": "PLANNING_RECOVERY_INTERRUPTED",
                         "diagnostic": diagnostic,
                         "content": f"规划恢复未完成（{type(error).__name__}）；持久记录已保留，检查诊断后再修复。"}
                events.append(event)
                protocol.emit("progress", event=event)
            result = {"ok": not any(e.get("type") in {"error", "validation_failed", "workflow_blocked"} for e in events),
                      "project": str(project.root), "events": events,
                      "state": ProjectStateMachine(project).current.value,
                      "receipt": str(receipt), "reused": False,
                      "reports": [str(p) for p in sorted(project.output_root.glob("reports/*")) if p.is_file()]}
            if recovering and _nonconsuming_failure(result):
                return {**result, "receipt": None, "retryable": True,
                        "planning_recovery": planning_recovery_snapshot(project)}
            write_json(receipt, result)
            if recovering and not result["ok"]:
                # Resolution/compilation may materialize canonical facts during
                # the attempt. Consume that equivalent post-attempt key too,
                # otherwise journaling a failed candidate allows an endless loop.
                after = planning_recovery_snapshot(project)
                alternate = state / f"recovery-{after['recovery_token']}.json"
                if not alternate.exists():
                    write_json(alternate, {**result, "canonical_receipt": str(receipt)})
            return {**result, "planning_recovery": planning_recovery_snapshot(project)}


def _nonconsuming_failure(result):
    """Recognize diagnostics whether raised by a worker or yielded by workflow."""
    error = result.get("error")
    if error and ("PROJECT_BUSY" in str(error)):
        return True
    candidates = [result.get("diagnostic"), result.get("blocker")]
    for event in result.get("events", []):
        if isinstance(event, dict) and event.get("type") in {"error", "validation_failed", "workflow_blocked"}:
            candidates.extend((event.get("diagnostic"), event.get("blocker"), event))
    return any(isinstance(item, dict) and (item.get("code") == "PROJECT_BUSY"
               or item.get("consumes_recovery_attempt") is False) for item in candidates)


def main():
    protocol = Protocol()
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(143))
    request = {}
    try:
        request = protocol.read()
        with contextlib.redirect_stdout(sys.stderr):
            result = run_operation(request, protocol)
        protocol.emit("result", result=result)
    except Exception as exc:
        from microbiome.pipeline.diagnostics import error_diagnostic
        # This boundary only reports the escaping error. It neither increments
        # the planning ledger nor writes a recovery receipt. Earlier model
        # usage, if any, remains solely in the persisted ledger; do not infer it
        # from the exception category or turn it into candidate-format repair.
        context = "worker_boundary"
        if isinstance(request, dict):
            if request.get("type") == "checkpoint":
                context = "checkpoint"
            elif (request.get("type") == "capabilities" or
                  request.get("type") == "maintenance" and request.get("operation") in
                  {"inspect", "list_directory", "read_artifact", "read_diagnostic"}):
                context = "read_only"
        protocol.emit("result", result={"ok": False, "error": str(exc),
                                       "diagnostic": error_diagnostic(exc, context=context),
                                       **({"details": exc.details} if hasattr(exc, "details") else {})})
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
