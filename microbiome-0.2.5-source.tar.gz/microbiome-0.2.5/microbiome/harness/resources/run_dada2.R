# Explicit single-run, multi-sample DADA2 adapter; parameters are never tuned automatically.
args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 3L) stop("Usage: Rscript run_dada2.R manifest.tsv output_dir parameters.json")
stopifnot(requireNamespace("dada2", quietly = TRUE), requireNamespace("jsonlite", quietly = TRUE))
p <- jsonlite::fromJSON(args[3], simplifyVector = TRUE)
required <- c("seed", "threads", "filter", "learn", "infer", "chimera", "primers_removed")
if (!all(required %in% names(p)) || !isTRUE(p$primers_removed)) stop("Declare all parameters and primer removal")
if (p$threads < 1 || p$threads != as.integer(p$threads)) stop("threads must be a positive integer")
set.seed(p$seed)
manifest <- read.delim(args[1], check.names = FALSE, stringsAsFactors = FALSE)
if (!all(c("sample_id", "r1") %in% names(manifest)) || anyDuplicated(manifest$sample_id) || !nrow(manifest))
    stop("Manifest needs unique sample_id and r1 columns")
if ("run_id" %in% names(manifest) && length(unique(manifest$run_id)) > 1) stop("Error learning must be separated by sequencing run")
paired <- "r2" %in% names(manifest) && all(nzchar(manifest$r2))
if ("r2" %in% names(manifest) && any(nzchar(manifest$r2)) && !paired) stop("Mixed layouts require separate denoising designs")
if (!all(file.exists(c(manifest$r1, if (paired) manifest$r2)))) stop("Manifest input is missing")
out <- args[2]
dir.create(out, recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(out, "filtered"), showWarnings = FALSE)
capture.output(sessionInfo(), file = file.path(out, "sessionInfo.txt"))
jsonlite::write_json(p, file.path(out, "parameters.json"), auto_unbox = TRUE, pretty = TRUE)
invoke <- function(fun, fixed, chosen) {
    if (length(intersect(names(fixed), names(chosen)))) stop("Parameters cannot override fixed paths or thread limits")
    supported <- names(formals(fun))
    if (!"..." %in% supported && length(setdiff(names(chosen), supported))) stop("Unsupported option for installed DADA2")
    do.call(fun, c(fixed, chosen))
}
ff <- setNames(file.path(out, "filtered", paste0(seq_len(nrow(manifest)), "_R1.fastq.gz")), manifest$sample_id)
fixed <- list(fwd = manifest$r1, filt = unname(ff), multithread = p$threads, compress = TRUE)
if (paired) {
    rr <- setNames(file.path(out, "filtered", paste0(seq_len(nrow(manifest)), "_R2.fastq.gz")), manifest$sample_id)
    fixed$rev <- manifest$r2; fixed$filt.rev <- unname(rr)
}
tracking <- invoke(dada2::filterAndTrim, fixed, p$filter)
if (any(tracking[, "reads.out"] == 0)) stop("A sample lost all reads; revise the approved design")
errF <- invoke(dada2::learnErrors, list(fls = ff, multithread = p$threads), p$learn)
pdf(file.path(out, "error-models.pdf")); print(dada2::plotErrors(errF, nominalQ = TRUE))
df <- invoke(dada2::dada, list(derep = ff, err = errF, multithread = p$threads), p$infer)
if (paired) {
    if (is.null(p$merge)) stop("Paired data require explicit merge parameters")
    errR <- invoke(dada2::learnErrors, list(fls = rr, multithread = p$threads), p$learn)
    print(dada2::plotErrors(errR, nominalQ = TRUE))
    dr <- invoke(dada2::dada, list(derep = rr, err = errR, multithread = p$threads), p$infer)
    inferred <- invoke(dada2::mergePairs, list(dadaF = df, derepF = ff, dadaR = dr, derepR = rr), p$merge)
} else inferred <- df
dev.off()
table <- dada2::makeSequenceTable(inferred)
clean <- invoke(dada2::removeBimeraDenovo, list(unqs = table, multithread = p$threads), p$chimera)
if (!ncol(clean) || any(rowSums(clean) == 0)) stop("No validated nonchimeric ASVs for one or more samples")
clean <- clean[, order(colnames(clean)), drop = FALSE]
sequences <- colnames(clean); ids <- paste0("ASV", seq_along(sequences))
rownames(clean) <- manifest$sample_id; colnames(clean) <- ids
write.table(data.frame(feature_id = ids, t(clean), check.names = FALSE), file.path(out, "counts.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
writeLines(as.vector(rbind(paste0(">", ids), sequences)), file.path(out, "asv.fasta"))
write.table(data.frame(sample_id = manifest$sample_id, tracking, inferred = rowSums(table), nonchimeric = rowSums(clean)),
            file.path(out, "read-tracking.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
saveRDS(list(counts = clean, sequences = setNames(sequences, ids), parameters = p), file.path(out, "dada2.rds"))
if (!is.null(p$taxonomy)) {
    reference <- p$taxonomy$reference; options <- p$taxonomy; options$reference <- NULL
    if (is.null(reference) || !file.exists(reference)) stop("Declared taxonomy reference is unavailable")
    taxonomy <- invoke(dada2::assignTaxonomy, list(seqs = sequences, refFasta = reference, multithread = p$threads), options)
    write.table(data.frame(feature_id = ids, taxonomy), file.path(out, "taxonomy.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
}
