"""Validated tabular adapters. All paths and sample order are explicit CLI inputs."""
import argparse
import csv
import gzip
import math
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("operation", choices=["merge", "manifest", "qc-counts"])
    parser.add_argument("--inputs", nargs="+", required=True)
    parser.add_argument("--sample-ids", nargs="+", required=True)
    parser.add_argument("--mates", nargs="+")
    parser.add_argument("--output", required=True)
    parser.add_argument("--feature-column", default="feature_id")
    parser.add_argument("--value-column", default="count")
    parser.add_argument("--units", choices=["counts", "abundance"], default="counts")
    args = parser.parse_args()
    samples = args.sample_ids
    if len(samples) != len(args.inputs) or len(set(samples)) != len(samples):
        parser.error("unique sample IDs must align exactly with input paths")
    if any("\t" in s or "\n" in s or not s for s in samples):
        parser.error("sample IDs cannot be empty or contain tabs/newlines")
    if args.mates and len(args.mates) != len(samples):
        parser.error("mate paths must align with sample IDs")
    for path in args.inputs + (args.mates or []):
        if not Path(path).is_file():
            parser.error(f"missing input: {path}")
    if args.operation == "manifest":
        rows = [["sample_id", "r1", "r2"], *[
            [s, str(Path(p).resolve()), str(Path(args.mates[i]).resolve()) if args.mates else ""]
            for i, (s, p) in enumerate(zip(samples, args.inputs))]]
    elif args.operation == "qc-counts":
        rows = [["sample_id", "reads"]]
        for sample, path in zip(samples, args.inputs):
            count = 0
            with (gzip.open(path, "rt") if path.endswith(".gz") else open(path)) as stream:
                while header := stream.readline():
                    sequence, plus, quality = stream.readline().strip(), stream.readline(), stream.readline().strip()
                    if not header.startswith("@") or not plus.startswith("+") or not sequence or len(sequence) != len(quality):
                        parser.error(f"invalid FASTQ record in {path}")
                    count += 1
            rows.append([sample, count])
    else:
        features, tables = set(), []
        for path in args.inputs:
            table = {}
            with open(path) as stream:
                reader = csv.DictReader(stream, delimiter="\t")
                if not {args.feature_column, args.value_column} <= set(reader.fieldnames or []):
                    parser.error(f"missing feature/value columns in {path}")
                for row in reader:
                    feature = row[args.feature_column]
                    value = float(row[args.value_column])
                    if not feature or feature in table or not math.isfinite(value) or value < 0:
                        parser.error(f"duplicate feature or invalid value in {path}")
                    if args.units == "counts" and not value.is_integer():
                        parser.error("fractional abundances cannot be used as raw integer counts")
                    table[feature] = int(value) if args.units == "counts" else value
                if not table:
                    parser.error(f"empty feature table: {path}")
            features.update(table)
            tables.append(table)
        rows = [["feature_id", *samples], *[[f, *[t.get(f, 0) for t in tables]] for f in sorted(features)]]
    target = Path(args.output)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", newline="") as stream:
        csv.writer(stream, delimiter="\t").writerows(rows)


if __name__ == "__main__":
    main()
