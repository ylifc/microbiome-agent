# Explicit cohort adapter. No installation, downloads, automatic covariate removal or tuning.
args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 4L) stop("Usage: Rscript run_ancombc2.R counts.tsv metadata.tsv output_dir parameters.json")
stopifnot(requireNamespace("ANCOMBC", quietly = TRUE), requireNamespace("jsonlite", quietly = TRUE))
parameters <- jsonlite::fromJSON(args[4], simplifyVector = FALSE)
if (is.null(parameters$seed) || is.null(parameters$model)) stop("Declare seed and model options")
options <- parameters$model
if (is.null(options$fix_formula) || is.null(options$p_adj_method) || is.null(options$n_cl))
    stop("Declare fix_formula, p_adj_method and n_cl")
if (any(c("data", "meta_data") %in% names(options))) stop("Model options cannot override input tables")
supported <- names(formals(ANCOMBC::ancombc2))
if (!"meta_data" %in% supported) stop("Installed ANCOMBC lacks the validated matrix/meta_data API")
if (length(setdiff(names(options), supported))) stop("Unsupported model option for installed ANCOMBC")
counts <- as.matrix(read.delim(args[1], row.names = 1, check.names = FALSE))
meta <- read.delim(args[2], row.names = 1, check.names = FALSE, stringsAsFactors = FALSE)
if (!is.numeric(counts) || any(!is.finite(counts)) || any(counts < 0) || any(counts != round(counts)))
    stop("Counts must be finite nonnegative integers, not relative abundances")
if (anyDuplicated(colnames(counts)) || anyDuplicated(rownames(counts)) ||
    !setequal(colnames(counts), rownames(meta))) stop("Counts and metadata sample IDs differ")
meta <- meta[colnames(counts), , drop = FALSE]
for (column in names(parameters$factor_levels)) {
    levels <- unlist(parameters$factor_levels[[column]])
    if (!column %in% colnames(meta) || any(!meta[[column]] %in% levels)) stop("Invalid factor levels")
    meta[[column]] <- factor(meta[[column]], levels = levels)
}
formula <- as.formula(paste("~", options$fix_formula))
check_expression <- function(x) {
    if (is.name(x)) return(as.character(x) %in% names(meta))
    if (is.numeric(x)) return(TRUE)
    if (!is.call(x) || !as.character(x[[1]]) %in% c("~", "+", "-", "*", "/", ":", "^", "(", "|", "||")) return(FALSE)
    all(vapply(as.list(x)[-1], check_expression, logical(1)))
}
if (!check_expression(formula)) stop("Formula contains unsupported terms")
for (column in all.vars(formula)) {
    if (is.character(meta[[column]]) && !column %in% names(parameters$factor_levels))
        stop("Declare factor_levels for every categorical fixed-effect variable")
}
if (!is.null(options$rand_formula) && !check_expression(as.formula(options$rand_formula))) stop("Invalid random formula")
design <- model.matrix(formula, meta, na.action = na.fail)
if (nrow(design) != nrow(meta) || qr(design)$rank < ncol(design) || nrow(design) <= ncol(design))
    stop("Missing data, rank deficiency or no residual degrees of freedom")
set.seed(as.integer(parameters$seed))
dir.create(args[3], recursive = TRUE, showWarnings = FALSE)
capture.output(sessionInfo(), file = file.path(args[3], "sessionInfo.txt"))
jsonlite::write_json(parameters, file.path(args[3], "parameters.json"), auto_unbox = TRUE, pretty = TRUE)
result <- do.call(ANCOMBC::ancombc2, c(list(data = counts, meta_data = meta), options))
if (!is.data.frame(result$res) || !nrow(result$res)) stop("ANCOM-BC2 returned no primary results")
saveRDS(result, file.path(args[3], "ancombc2.rds"))
for (name in names(result)) {
    if (is.data.frame(result[[name]]) || is.matrix(result[[name]]))
        write.table(result[[name]], file.path(args[3], paste0(name, ".tsv")), sep = "\t", quote = FALSE, row.names = FALSE)
}
