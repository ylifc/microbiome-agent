"""Durable local tasks with process ownership, cancellation and bounded logs."""

from __future__ import annotations

import fcntl
import json
import os
import re
import signal
import sqlite3
import subprocess
import sys
import threading
import time
import uuid
from pathlib import Path

from microbiome.harness.settings import load_config

MAX_LOG_BYTES = 4 * 1024 * 1024
MAX_HISTORY_BYTES = 32 * 1024


class TaskManagerBusy(ValueError):
    """Another live process owns this task directory; never remove its lock file."""


class TaskManager:
    def __init__(self, home, config_file):
        self.home, self.config_file = Path(home), Path(config_file)
        self.home.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.database = self.home / "tasks.sqlite"
        self.owner = (self.home / ".manager.lock").open("a+")
        try:
            fcntl.flock(self.owner.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            self.owner.close()
            raise TaskManagerBusy("Another task manager already owns this task directory") from None
        self.lock = threading.RLock()
        self.processes = {}
        with self.connect() as db:
            db.execute(
                "CREATE TABLE IF NOT EXISTS tasks (id TEXT PRIMARY KEY, project TEXT, profile TEXT, "
                "message TEXT, status TEXT, created REAL, updated REAL, context TEXT, result TEXT, pid INTEGER)"
            )
            # Keep correlation separate from the legacy task schema so old
            # journals and interrupted-task recovery remain compatible.
            db.execute(
                "CREATE TABLE IF NOT EXISTS task_sessions (task_id TEXT PRIMARY KEY, "
                "conversation_id TEXT, session_id TEXT NOT NULL, message_id TEXT NOT NULL)"
            )
            # Server shutdown kills its process groups. A crash leaves durable work interrupted;
            # never repeat a production approval automatically on restart.
            db.execute(
                "UPDATE tasks SET status='interrupted', updated=? WHERE status IN ('queued','running')", (time.time(),)
            )
            for row in db.execute("SELECT id FROM tasks WHERE status='interrupted'"):
                if len(row["id"]) == 32 and all(c in "0123456789abcdef" for c in row["id"]):
                    (self.home / row["id"] / "request.json").unlink(missing_ok=True)

    def connect(self):
        connection = sqlite3.connect(self.database, timeout=10)
        connection.row_factory = sqlite3.Row
        return connection

    def list(self):
        with self.connect() as db:
            return [
                dict(row)
                for row in db.execute(
                    "SELECT t.*, s.conversation_id, COALESCE(s.session_id, 'local-' || t.id) AS session_id, "
                    "COALESCE(s.message_id, t.id) AS message_id FROM tasks t "
                    "LEFT JOIN task_sessions s ON s.task_id=t.id ORDER BY t.created DESC LIMIT 200"
                )
            ]

    def get(self, identity):
        with self.connect() as db:
            row = db.execute(
                "SELECT t.*, s.conversation_id, COALESCE(s.session_id, 'local-' || t.id) AS session_id, "
                "COALESCE(s.message_id, t.id) AS message_id FROM tasks t "
                "LEFT JOIN task_sessions s ON s.task_id=t.id WHERE t.id=?",
                (identity,),
            ).fetchone()
        if row is None:
            raise KeyError("Unknown task")
        return dict(row)

    def update(self, identity, **fields):
        if not fields.keys() <= {"status", "context", "result", "pid"}:
            raise ValueError("Invalid task update")
        fields["updated"] = time.time()
        with self.connect() as db:
            db.execute(
                "UPDATE tasks SET " + ", ".join(f"{key}=?" for key in fields) + " WHERE id=?",
                (*fields.values(), identity),
            )

    def _prior_task_outcomes(self, db, project, conversation_id):
        """Import only real terminal outcomes from this conversation and project.

        A killed worker cannot write its final conversation turn. The next
        explicit request carries a bounded set of these durable supervisor
        facts; historical messages and approvals are deliberately excluded.
        """
        if not conversation_id:
            return []
        rows = db.execute(
            "SELECT t.* FROM tasks t JOIN task_sessions s ON s.task_id=t.id "
            "WHERE t.project=? AND s.conversation_id=? AND t.status IN ('cancelled','interrupted','failed') "
            "ORDER BY t.created DESC LIMIT 8",
            (project, conversation_id),
        ).fetchall()
        summaries = {
            "cancelled": "先前任务已取消；保留已有记录，本次请求不会自动重放执行批准。",
            "interrupted": "先前任务因服务中断而未完成；需核对已有记录，不自动重放执行批准。",
            "failed": "先前任务失败；需依据已有记录补充信息或修复方案，不自动重放执行批准。",
        }
        outcomes = []
        for row in reversed(rows):
            stage = (
                5
                if row["message"] == "确认全量执行" or row["message"].startswith("恢复批次 ")
                else (4 if row["message"] in {"确认执行", "重试预检", "重试冻结"} else 2)
            )
            try:
                events = self.progress_events(row["id"])
            except OSError:
                events = []
            try:
                result = json.loads(row["result"] or "{}")
            except (TypeError, ValueError):
                result = {}
            if isinstance(result, dict) and isinstance(result.get("events"), list):
                events += result["events"]
            for event in events:
                if isinstance(event, dict) and type(event.get("stage")) is int and 1 <= event["stage"] <= 6:
                    stage = event["stage"]
            outcomes.append(
                {"task_id": row["id"], "status": row["status"], "stage": stage, "summary": summaries[row["status"]]}
            )
        return outcomes

    def submit(self, payload):
        allowed = {
            "project",
            "data_dir",
            "db_dir",
            "download_dir",
            "knowledge_dir",
            "message",
            "profile",
            "pretest_fraction",
            "pretest_all_samples",
            "conversation_id",
            "historical_context",
        }
        if not isinstance(payload, dict) or payload.keys() - allowed:
            raise ValueError("Invalid task fields")
        for key in ("project", "message"):
            if not isinstance(payload.get(key), str) or not payload[key].strip():
                raise ValueError(f"{key} is required")
        if len(payload["message"].encode()) > 128_000:
            raise ValueError("Message exceeds 128 KB")
        if "pretest_fraction" in payload and (
            type(payload["pretest_fraction"]) not in (int, float) or not 0.05 <= payload["pretest_fraction"] <= 0.10
        ):
            raise ValueError("pretest_fraction must be between 0.05 and 0.10")
        if "pretest_all_samples" in payload and type(payload["pretest_all_samples"]) is not bool:
            raise ValueError("pretest_all_samples must be a boolean")
        conversation_id = payload.get("conversation_id")
        if conversation_id is not None and (
            not isinstance(conversation_id, str) or not re.fullmatch(r"[a-f0-9]{32}", conversation_id)
        ):
            raise ValueError("conversation_id must be a persisted conversation identifier")
        if "historical_context" in payload:
            history = payload["historical_context"]
            if (
                not conversation_id
                or not isinstance(history, list)
                or any(
                    not isinstance(item, dict)
                    or set(item) != {"role", "content"}
                    or item["role"] not in {"user", "assistant"}
                    or not isinstance(item["content"], str)
                    for item in history
                )
            ):
                raise ValueError("historical_context requires a conversation and user/assistant text records")
            if len(json.dumps(history, ensure_ascii=False).encode("utf-8")) > MAX_HISTORY_BYTES:
                raise ValueError("普通聊天背景超过 32 KiB；请新建对话并提供完整分析目标，原历史记录保留。")
        request = {key: value for key, value in payload.items() if key != "profile"}
        for key in ("project", "data_dir", "db_dir", "download_dir", "knowledge_dir"):
            if key in request:
                if not isinstance(request[key], str) or not Path(request[key]).expanduser().is_absolute():
                    raise ValueError(f"{key} must be an absolute server path")
                request[key] = str(Path(request[key]).expanduser().resolve())
        project = request["project"]
        if not (Path(project) / "project_config.yaml").is_file() and not (
            request.get("data_dir") and request.get("db_dir")
        ):
            raise ValueError("New projects require data_dir and db_dir")
        config = load_config(self.config_file)
        profile = payload.get("profile", config.active_model)
        if profile not in config.models:
            raise ValueError("Unknown model profile")
        identity = uuid.uuid4().hex
        session_id = "conversation-" + conversation_id if conversation_id else "local-" + identity
        request.update(session_id=session_id, message_id=identity)
        with self.lock:
            with self.connect() as db:
                if db.execute(
                    "SELECT id FROM tasks WHERE project=? AND status IN ('queued','running')", (project,)
                ).fetchone():
                    raise ValueError("Project already has an active task")
                request["prior_task_outcomes"] = self._prior_task_outcomes(db, project, conversation_id)
                now = time.time()
                db.execute(
                    "INSERT INTO tasks VALUES (?,?,?,?,?,?,?,?,?,?)",
                    (identity, project, profile, request["message"], "queued", now, now, "{}", "{}", None),
                )
                db.execute(
                    "INSERT INTO task_sessions VALUES (?,?,?,?)",
                    (identity, conversation_id, session_id, identity),
                )
            directory = self.home / identity
            directory.mkdir(mode=0o700)
            task = directory / "request.json"
            with os.fdopen(os.open(task, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), "w") as stream:
                json.dump({"request": request, "model_config": config.models[profile].model_dump()}, stream)
            thread = threading.Thread(target=self._run, args=(identity, task), daemon=True)
            thread.start()
        return self.get(identity)

    def _run(self, identity, task):
        directory = task.parent
        try:
            with self.lock:
                if self.get(identity)["status"] == "cancelled":
                    return
                child = subprocess.Popen(
                    [sys.executable, "-m", "microbiome.harness.agent_adapter", "--task", str(task)],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.DEVNULL,
                    text=True,
                    start_new_session=True,
                )
                self.processes[identity] = child
                self.update(identity, status="running", pid=child.pid)
            written = 0
            with (directory / "events.jsonl").open("w") as log:
                for line in child.stdout:
                    size = len(line.encode())
                    if written + size <= MAX_LOG_BYTES:
                        log.write(line)
                        log.flush()
                        written += size
                    try:
                        event = json.loads(line)
                    except ValueError:
                        continue
                    if event.get("type") == "context":
                        self.update(identity, context=json.dumps(event["data"]))
                    elif event.get("type") == "result":
                        self.update(identity, result=json.dumps(event["data"], ensure_ascii=False))
                code = child.wait()
            if self.get(identity)["status"] != "cancelled":
                self.update(identity, status="completed" if code == 0 else "failed", pid=None)
        except Exception:
            self.update(identity, status="failed", pid=None)
        finally:
            with self.lock:
                self.processes.pop(identity, None)
            # Remove literal API secrets as soon as the per-task snapshot is consumed.
            task.unlink(missing_ok=True)

    def cancel(self, identity):
        with self.lock:
            task = self.get(identity)
            if task["status"] not in {"queued", "running"}:
                return task
            self.update(identity, status="cancelled", pid=None)
            child = self.processes.get(identity)
            if child and child.poll() is None:
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    child.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
        return self.get(identity)

    def logs(self, identity):
        self.get(identity)
        path = self.home / identity / "events.jsonl"
        return path.read_text()[-256_000:] if path.is_file() else ""

    def progress_events(self, identity):
        """Return only durable user-facing workflow events, never model requests."""
        self.get(identity)
        path = self.home / identity / "events.jsonl"
        if not path.is_file():
            return []
        events = []
        for line in path.read_text()[:MAX_LOG_BYTES].splitlines():
            try:
                frame = json.loads(line)
            except ValueError:
                continue  # The worker may be halfway through writing the last line.
            if frame.get("type") == "progress":
                event = frame.get("data", {}).get("event", {})
                if isinstance(event, dict):
                    events.append(event)
            elif frame.get("type") == "error":
                events.append({"type": "error", "content": frame.get("data", {}).get("message", "Task failed")})
        return events

    def close(self):
        for task in self.list():
            if task["status"] in {"queued", "running"}:
                self.cancel(task["id"])
        if not self.owner.closed:
            fcntl.flock(self.owner.fileno(), fcntl.LOCK_UN)
            self.owner.close()
