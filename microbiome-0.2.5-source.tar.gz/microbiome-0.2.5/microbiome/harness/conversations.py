"""Persistent text conversations and deterministic, model-independent setup questions."""

from __future__ import annotations

import hashlib
import json
import re
import sqlite3
import threading
import time
import uuid
from pathlib import Path

from microbiome.harness.guided_conversation import PATH_QUESTIONS, GuidedConversation, new_guided_state
from microbiome.harness.settings import HarnessConfig, ModelConfig, load_config, save_config

# Stable order is part of the setup protocol. Configuration text never reaches the LLM.
QUESTIONS = (
    ("profile", "模型配置名称（例如 local）"),
    ("provider", "模型提供商：ollama / openai / anthropic / deepseek / openai-compatible"),
    ("model", "模型名称（须为服务中已经存在的模型；可先点击“列出 Ollama 模型”）"),
    ("base_url", "模型服务地址（Ollama 通常为 http://127.0.0.1:11434）"),
    ("api_key", "API 密钥环境变量引用，例如 ${OPENAI_API_KEY}；Ollama 可填“清空”。请勿输入明文密钥"),
    ("context_length", "上下文长度（整数，至少 512）"),
    ("max_tokens", "最大输出 token（正整数，必须小于上下文长度减 256）"),
    ("temperature", "Temperature（0 到 2）"),
    ("project", "本次对话绑定的结果项目目录（服务器绝对路径；纯聊天可填“清空”）"),
    ("data_dir", "本地原始数据目录（必须存在；不会推断为 SRA 下载）"),
    ("db_dir", "持久数据库目录（必须存在；复用现有资源）"),
    ("download_dir", "下载缓存目录（可选绝对路径）"),
    ("knowledge_dir", "知识目录（可选绝对路径）"),
    ("integrations", "可选集成设置（JSON 对象；默认 {}。仅保存配置，网络操作仍走各自授权流程）"),
)
PATH_FIELDS = {"project", "data_dir", "db_dir", "download_dir", "knowledge_dir"}
WELCOME = (
    "欢迎使用 Microbiome。我们将通过对话完成目录设置、目标与思路、流程确认、抽样预检、全量分析和报告六个阶段。上方显示真实进度。输入“开始分析”或直接输入原始数据目录开始；也可以先普通聊天。模型参数可输入“模型设置”。\n\n"
    + PATH_QUESTIONS[0][1]
)


def fingerprint(config):
    return hashlib.sha256(config.model_dump_json().encode()).hexdigest()


class ConversationError(ValueError):
    """Safe, user-facing error (never include raw provider errors or credentials)."""


class ConversationStore(GuidedConversation):
    def __init__(self, home, config_file, manager, config_lock=None):
        self.home = Path(home)
        self.home.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.database = self.home / "conversations.sqlite"
        self.config_file, self.manager = config_file, manager
        self.lock = threading.RLock()
        self.session_locks = {}
        self.config_lock = config_lock or threading.RLock()
        with self.connect() as db:
            db.execute("CREATE TABLE IF NOT EXISTS conversations (id TEXT PRIMARY KEY, updated REAL, state TEXT)")
        self.database.chmod(0o600)

    def connect(self):
        return sqlite3.connect(self.database, timeout=10)

    def _read(self, identity):
        with self.connect() as db:
            row = db.execute("SELECT state FROM conversations WHERE id=?", (identity,)).fetchone()
        if row is None:
            raise KeyError("Unknown conversation")
        return json.loads(row[0])

    def _write(self, state):
        with self.connect() as db:
            db.execute(
                "INSERT OR REPLACE INTO conversations VALUES (?,?,?)", (state["id"], time.time(), json.dumps(state))
            )

    def public(self, state):
        wizard = state.get("wizard")
        return {key: state[key] for key in ("id", "messages", "bindings", "profile")} | {
            "setting": QUESTIONS[wizard["step"]][0] if wizard and wizard["step"] < len(QUESTIONS) else None,
            "configuring": bool(wizard),
            "workflow": self._guided_public(state),
        }

    def get(self, identity):
        with self._session_lock(identity):
            state = self._read(identity)
            if self._sync_guided(state):
                self._write(state)
            return self.public(state)

    def report(self, identity, name):
        from microbiome.harness.workflow_status import read_report

        with self._session_lock(identity):
            state = self._read(identity)
            progress = self._progress(state)
            if not any(report["name"] == name for report in progress.get("reports", [])):
                raise ConversationError("报告尚未生成或未通过当前项目验收。")
            return {"name": name, "text": read_report(state["bindings"]["project"], name)}

    def list(self):
        with self.connect() as db:
            rows = db.execute("SELECT state FROM conversations ORDER BY updated DESC LIMIT 200").fetchall()
        return [
            {"id": s["id"], "project": s["bindings"].get("project"), "profile": s["profile"]}
            for s in (json.loads(row[0]) for row in rows)
        ]

    def create(self):
        state = {
            "id": uuid.uuid4().hex,
            "profile": load_config(self.config_file).active_model,
            "bindings": {},
            "messages": [{"role": "assistant", "content": WELCOME, "stage": 1}],
            "history": [],
            "guided": new_guided_state(),
        }
        with self.lock:
            self._write(state)
        return self.public(state)

    def _question(self, wizard):
        key, question = QUESTIONS[wizard["step"]]
        value = wizard["draft"].get(key)
        shown = ("已配置" if value else "未配置") if key in {"api_key", "integrations"} else str(value or "未设置")
        return f"{wizard['step'] + 1}/{len(QUESTIONS)} · {question}\n当前：{shown}。回答“保留”沿用当前值。"

    def _setup(self, state, message):
        wizard = state["wizard"]
        if message in {"取消设置", "/cancel"}:
            state.pop("wizard")
            return "已取消，已保存的配置没有改变。", message
        if wizard["step"] == len(QUESTIONS):
            if message != "保存配置":
                return "请回答“保存配置”或“取消设置”。", message
            with self.config_lock:
                config = load_config(self.config_file)
                if fingerprint(config) != wizard["base"]:
                    state.pop("wizard")
                    return "配置已被其他页面或对话修改，请重新输入“开始设置”。", message
                updated, bindings = self._validated(wizard["draft"], config)
                if state.get("guided", {}).get("ready") and bindings != state["bindings"]:
                    state.pop("wizard")
                    return "当前分析已绑定项目，不能通过模型设置更换目录；请新建对话设置另一个项目。", message
                save_config(updated, self.config_file)
                state.update(profile=updated.active_model, bindings=bindings)
            state.pop("wizard")
            migrated = self._prepare_guided_paths(state, refresh=True)
            answer = "配置与对话目录已保存。可以直接聊天，或点击“测试模型对话”。"
            if migrated and not state["guided"].get("ready"):
                answer += "\n" + self._guided_public(state)["prompt"]
            return answer, message
        key = QUESTIONS[wizard["step"]][0]
        logged = "[密钥设置已隐藏]" if key == "api_key" else ("[集成设置已隐藏]" if key == "integrations" else message)
        value = wizard["draft"].get(key)
        if message != "保留":
            value = None if message == "清空" else message
            try:
                if key in {"context_length", "max_tokens"}:
                    value = int(message)
                    if value < (512 if key == "context_length" else 1):
                        raise ValueError()
                elif key == "temperature":
                    value = float(message)
                    if not 0 <= value <= 2:
                        raise ValueError()
                elif key == "integrations":
                    value = {} if value is None else json.loads(message)
                    if not isinstance(value, dict) or any(not isinstance(v, dict) for v in value.values()):
                        raise ValueError()
                elif key == "api_key" and value and not re.fullmatch(r"\$\{[A-Z][A-Z0-9_]*\}", value):
                    raise ValueError()
                elif key == "profile" and (not value or not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", value)):
                    raise ValueError()
                elif key == "provider" and value not in {
                    "ollama",
                    "openai",
                    "anthropic",
                    "deepseek",
                    "openai-compatible",
                }:
                    raise ValueError()
                elif key == "model" and not value:
                    raise ValueError()
                elif key == "base_url" and value:
                    ModelConfig(provider="ollama", model="validation", base_url=value)
                elif key in PATH_FIELDS and value:
                    path = Path(value).expanduser()
                    if not path.is_absolute() or (path.exists() and not path.is_dir()):
                        raise ValueError()
                    if key in {"data_dir", "db_dir"} and not path.is_dir():
                        raise ValueError()
                    value = str(path.resolve())
            except (ValueError, TypeError):
                return (
                    "格式或路径无效，请重答当前问题。密钥只接受 ${ENV_VAR}，本地输入缺失不会触发下载。\n"
                    + self._question(wizard),
                    logged,
                )
        wizard["draft"][key] = value
        if key == "profile" and value in load_config(self.config_file).models:
            wizard["draft"].update(load_config(self.config_file).models[value].model_dump())
            if wizard["draft"].get("api_key"):
                wizard["draft"]["api_key"] = "__KEEP_EXISTING__:" + value
        wizard["step"] += 1
        if wizard["step"] < len(QUESTIONS):
            return self._question(wizard), logged
        try:
            updated, bindings = self._validated(wizard["draft"], load_config(self.config_file))
        except ValueError:
            wizard["step"] = 0
            return "配置组合无效（请检查上下文预算、目录和提供商）；草稿已保留，请重新逐项修改。\n" + self._question(
                wizard
            ), logged
        summary = {
            "profile": updated.active_model,
            "model": updated.models[updated.active_model].public(),
            "bindings": bindings,
            "integrations": updated.public()["integrations"],
        }
        return "请核对配置：\n" + json.dumps(
            summary, ensure_ascii=False, indent=2
        ) + "\n回答“保存配置”才会生效；或“取消设置”。", logged

    def _validated(self, draft, config):
        values = {key: draft[key] for key in ModelConfig.model_fields}
        if (values["api_key"] or "").startswith("__KEEP_EXISTING__:"):
            values["api_key"] = config.models[values["api_key"].split(":", 1)[1]].api_key
        model = ModelConfig.model_validate(values)
        updated = config.model_copy(deep=True)
        updated.models[draft["profile"]] = model
        updated.active_model = draft["profile"]
        updated.integrations = draft["integrations"]
        updated = HarnessConfig.model_validate(updated.model_dump())
        bindings = {key: draft[key] for key in PATH_FIELDS if draft.get(key)}
        return updated, bindings

    def send(self, identity, message):
        if not isinstance(message, str) or not message.strip() or len(message.encode()) > 128_000:
            raise ConversationError("请输入非空消息（不超过 128 KB）。")
        message = message.strip()
        # One model call must not block unrelated conversations or setup sessions.
        with self._session_lock(identity):
            state = self._read(identity)
            self._sync_guided(state)
            logged = message
            setting_message = bool(state.get("wizard")) or message in {"开始设置", "模型设置", "设置", "/setup"}
            user_stage = None if setting_message else self._message_stage(state)
            active = any(not t.get("finished") for t in state.get("guided", {}).get("tasks", []))
            if active:
                answer = self._guided_message(state, message)
            elif message in {"开始设置", "模型设置", "设置", "/setup"}:
                config = load_config(self.config_file)
                profile = state["profile"] if state["profile"] in config.models else config.active_model
                draft = config.models[profile].model_dump() | {key: state["bindings"].get(key) for key in PATH_FIELDS}
                if draft.get("api_key"):
                    draft["api_key"] = "__KEEP_EXISTING__:" + profile
                draft.update(profile=profile, integrations=config.integrations)
                state["wizard"] = {"step": 0, "draft": draft, "base": fingerprint(config)}
                answer = self._question(state["wizard"])
            elif state.get("wizard"):
                answer, logged = self._setup(state, message)
            elif message.startswith("/运行 "):
                answer = self._guided_message(state, message[4:].strip())
                if answer is None:
                    answer = "分析操作需要先完成目录确认。\n" + PATH_QUESTIONS[0][1]
            else:
                answer = self._guided_message(state, message)
            if answer is None:
                from microbiome.harness.providers import create_model

                config = load_config(self.config_file)
                if state["profile"] not in config.models:
                    raise ConversationError("模型配置已删除，请输入“开始设置”。")
                history = state["history"] + [{"role": "user", "content": message}]
                try:
                    reply = create_model(config.models[state["profile"]]).invoke(
                        [
                            (
                                "system",
                                "你是 Microbiome 工作台的中文对话助手。普通聊天没有执行工具，不能声称运行过分析或保存过配置。分析请提示输入“开始分析”，将通过六阶段对话处理；模型设置请提示“模型设置”。",
                            ),
                            *[(item["role"], item["content"]) for item in history],
                        ]
                    )
                    answer = reply.content
                    if not isinstance(answer, str):
                        answer = "\n".join(block.get("text", "") for block in answer if isinstance(block, dict))
                    if not answer.strip():
                        raise ValueError()
                except Exception:
                    raise ConversationError(
                        "模型对话失败；请检查服务地址、已安装模型、输出预算及密钥。消息未写入历史，可修正后重试。"
                    ) from None
                state["history"] = history + [{"role": "assistant", "content": answer}]
            assistant_stage = None if setting_message else self._message_stage(state)
            # A stage belongs to the message at the time it was exchanged, not
            # to whatever stage happens to be current when history is reloaded.
            user_record = {"role": "user", "content": logged}
            assistant_record = {"role": "assistant", "content": answer}
            if user_stage or assistant_stage:
                user_record["stage"] = user_stage or assistant_stage
            if assistant_stage:
                assistant_record["stage"] = assistant_stage
            state["messages"].extend([user_record, assistant_record])
            self._write(state)
            return self.public(state)
