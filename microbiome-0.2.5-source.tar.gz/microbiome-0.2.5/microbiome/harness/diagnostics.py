"""Read-only diagnostics with explicit opt-in network probes."""

import importlib.util
import platform
import shutil
import subprocess
import sys
from urllib.parse import urlparse

import requests

from microbiome.harness.settings import load_config


def command_probe(argv):
    if not shutil.which(argv[0]):
        return {"status": "unavailable"}
    try:
        result = subprocess.run(argv, capture_output=True, text=True, timeout=8)
        return {
            "status": "ready" if result.returncode == 0 else "failed",
            "exit_code": result.returncode,
            "detail": result.stdout.strip()[:1000],
        }
    except subprocess.TimeoutExpired:
        return {"status": "timeout"}


def doctor(config_file=None, *, network=False):
    from microbiome.harness.assets import ASSET_NAMES, asset_path

    config = load_config(config_file)
    assets = {}
    for name in sorted(ASSET_NAMES):
        try:
            assets[name] = {"status": "ready", "path": str(asset_path(name))}
        except (ValueError, OSError):
            assets[name] = {"status": "missing"}
    api = {}
    for name, model in config.models.items():
        entry = {
            "provider": model.provider,
            "model": model.model,
            "credential_configured": bool(model.resolved_key()),
            "authentication": "not_probed",
            "request": "not_probed",
        }
        if network:
            endpoint = model.base_url or {
                "openai": "https://api.openai.com/v1",
                "anthropic": "https://api.anthropic.com",
                "deepseek": "https://api.deepseek.com/v1",
                "ollama": "http://127.0.0.1:11434",
            }.get(model.provider)
            suffix = (
                "/api/tags"
                if model.provider == "ollama"
                else ("/v1/models" if model.provider == "anthropic" else "/models")
            )
            if model.provider == "ollama":
                endpoint = endpoint.rstrip("/").removesuffix("/v1")
            headers = {}
            if model.resolved_key():
                headers = (
                    {"x-api-key": model.resolved_key(), "anthropic-version": "2023-06-01"}
                    if model.provider == "anthropic"
                    else {"Authorization": "Bearer " + model.resolved_key()}
                )
            try:
                with requests.Session() as session:
                    if urlparse(endpoint).hostname in {"localhost", "127.0.0.1", "::1"}:
                        session.trust_env = False
                    response = session.get(
                        endpoint.rstrip("/") + suffix, headers=headers, timeout=8, allow_redirects=False
                    )
                entry.update(
                    request="success" if response.ok else "failed",
                    http_status=response.status_code,
                    authentication="accepted"
                    if response.ok and headers
                    else ("rejected" if response.status_code in (401, 403) else "not_proven"),
                )
            except requests.RequestException:
                entry["request"] = "unreachable"
        api[name] = entry
    anthropic = importlib.util.find_spec("langchain_anthropic") is not None
    return {
        "ok": all(v["status"] == "ready" for v in assets.values()) and anthropic,
        "python": {
            "version": platform.python_version(),
            "executable": sys.executable,
            "supported": sys.version_info >= (3, 11),
        },
        "platform": platform.platform(),
        "cuda": command_probe(["nvcc", "--version"]),
        "gpu": command_probe(["nvidia-smi", "--query-gpu=name,memory.total,driver_version", "--format=csv,noheader"]),
        "ollama": command_probe(["ollama", "--version"]),
        "api": api,
        "agent": {
            "status": "ready" if all(v["status"] == "ready" for v in assets.values()) else "missing_assets",
            "assets": assets,
            "anthropic_adapter_installed": anthropic,
        },
        "integrations": {
            key: {"enabled": bool(config.integrations.get(key, {}).get("enabled", False))}
            for key in ("evolver", "evomap", "evox")
        },
        "network_probe": network,
        "scientific_resources": "NOT_PROBED",
    }
