"""Authenticated loopback GUI. No remote shell, arbitrary downloads or auto approvals."""

from __future__ import annotations

import hmac
import json
import secrets
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

from microbiome.harness.settings import HarnessConfig, load_config, save_config
from microbiome.harness.tasks import TaskManager


def make_server(home, config_file, *, port=8765):
    manager = TaskManager(Path(home) / "tasks", config_file)
    from microbiome.harness.conversations import ConversationError, ConversationStore

    config_lock = threading.RLock()
    try:
        conversations = ConversationStore(Path(home) / "conversations", config_file, manager, config_lock)
    except Exception:
        manager.close()
        raise
    token = secrets.token_urlsafe(32)
    web = Path(__file__).parent / "web"

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def send(self, status, data, content_type="application/json"):
            encoded = json.dumps(data, ensure_ascii=False).encode() if content_type == "application/json" else data
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(encoded)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header(
                "Content-Security-Policy",
                "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; frame-ancestors 'none'",
            )
            self.end_headers()
            self.wfile.write(encoded)

        def authorized(self):
            host = f"127.0.0.1:{self.server.server_port}"
            if self.headers.get("Host") != host or self.headers.get("Origin", "http://" + host) != "http://" + host:
                self.send(403, {"error": "Origin rejected"})
                return False
            if not hmac.compare_digest(self.headers.get("X-Biomni-Token", ""), token):
                self.send(401, {"error": "Open the authenticated URL printed by biomni gui"})
                return False
            return True

        def do_GET(self):
            route = urlparse(self.path).path
            if route in {"/", "/app.js", "/style.css"}:
                file = web / ({"/": "index.html"}.get(route, route[1:]))
                kind = {
                    ".html": "text/html; charset=utf-8",
                    ".js": "text/javascript; charset=utf-8",
                    ".css": "text/css; charset=utf-8",
                }[file.suffix]
                return self.send(200, file.read_bytes(), kind)
            if not self.authorized():
                return
            try:
                if route == "/api/instance":
                    from microbiome.harness.instance import instance_identity

                    return self.send(200, instance_identity(home, config_file))
                if route == "/api/conversations":
                    return self.send(200, conversations.list())
                if route.startswith("/api/conversations/"):
                    parts = route.split("/")
                    if len(parts) == 6 and parts[4] == "reports":
                        return self.send(200, conversations.report(parts[3], unquote(parts[5])))
                    return self.send(200, conversations.get(route.split("/")[3]))
                if route == "/api/config":
                    return self.send(200, load_config(config_file).public())
                if route == "/api/tasks":
                    return self.send(200, manager.list())
                if route == "/api/doctor":
                    from microbiome.harness.diagnostics import doctor

                    return self.send(200, doctor(config_file))
                if route.startswith("/api/tasks/"):
                    parts = route.split("/")
                    identity = parts[3]
                    return self.send(
                        200,
                        {"text": manager.logs(identity)}
                        if len(parts) == 5 and parts[4] == "logs"
                        else manager.get(identity),
                    )
                self.send(404, {"error": "Not found"})
            except ConversationError as error:
                self.send(400, {"error": str(error)})
            except KeyError:
                self.send(404, {"error": "Unknown task"})
            except Exception:
                self.send(500, {"error": "Unable to read local state"})

        def do_POST(self):
            if not self.authorized():
                return
            try:
                length = int(self.headers.get("Content-Length", 0))
                if length < 0 or length > 256_000:
                    return self.send(413, {"error": "Request too large"})
                payload = json.loads(self.rfile.read(length) or b"{}")
                route = urlparse(self.path).path
                if not isinstance(payload, dict):
                    raise ValueError("Expected an object")
                if route == "/api/conversations":
                    return self.send(201, conversations.create())
                if route.startswith("/api/conversations/") and route.endswith("/messages"):
                    return self.send(200, conversations.send(route.split("/")[3], payload.get("message")))
                if route in {"/api/models/list", "/api/models/test"}:
                    from microbiome.harness.model_checks import ollama_models, probe_model

                    operation = ollama_models if route.endswith("/list") else probe_model
                    return self.send(200, operation(config_file, payload.get("profile")))
                if route == "/api/tasks":
                    return self.send(201, manager.submit(payload))
                if route == "/api/config":
                    with config_lock:
                        current = load_config(config_file)
                        # Network/evolution authorization is a separate operator configuration.
                        models = payload.get("models", {})
                        for name, model in models.items():
                            model.pop("api_key_configured", None)
                            if not model.get("api_key") and name in current.models:
                                model["api_key"] = current.models[name].api_key
                        updated = HarnessConfig.model_validate(
                            {
                                "schema_version": 1,
                                "active_model": payload["active_model"],
                                "models": models,
                                "integrations": current.integrations,
                            }
                        )
                        save_config(updated, config_file)
                        return self.send(200, updated.public())
                if route.startswith("/api/tasks/") and route.endswith("/cancel"):
                    return self.send(200, manager.cancel(route.split("/")[3]))
                self.send(404, {"error": "Not found"})
            except ConversationError as error:
                self.send(400, {"error": str(error)})
            except (ValueError, KeyError, TypeError, AttributeError):
                self.send(
                    400,
                    {"error": "Invalid configuration, paths or task request. Check the required fields and budgets."},
                )
            except Exception:
                self.send(500, {"error": "Local operation failed"})

    try:
        server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    except OSError:
        manager.close()
        raise
    server.daemon_threads = True
    server.conversations = conversations
    server.manager = manager
    server.access_url = f"http://127.0.0.1:{server.server_port}/#token={token}"
    return server
