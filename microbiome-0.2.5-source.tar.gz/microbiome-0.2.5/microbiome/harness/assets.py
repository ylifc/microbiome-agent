"""Compatibility import for existing Harness integrations and frozen projects."""
from microbiome.assets import ASSET_NAMES, asset_path, main, resolve_asset_token

__all__ = ["ASSET_NAMES", "asset_path", "main", "resolve_asset_token"]
