"""Read-only catalog audit: python -m microbiome.resource_skills.audit [--strict]."""
import argparse
import json
import re

from microbiome.resource_skills.registry import PACKAGE_SKILL_ROOT, ResourceSkillRegistry
from microbiome.resource_skills.runtime import package_probe


def audit_catalog(roots=None):
    registry = ResourceSkillRegistry(skill_roots=roots or [PACKAGE_SKILL_ROOT],
                                    environment_catalog={}, tolerate_invalid=True)
    errors = [{"resource": str(path), "issue": issue} for path, issue in registry.load_errors.items()]
    warnings, entries = [], []
    repository = PACKAGE_SKILL_ROOT.parents[1]
    for skill in registry.list_skills():
        meta = skill.metadata
        identity = f"{skill.kind}:{skill.skill_id}"
        fields = ("tasks", "capabilities", "inputs", "outputs") if skill.kind == "software" else ("contents", "formats", "consumers")
        for field in fields:
            if not meta.get(field):
                warnings.append({"resource": identity, "issue": f"unresolved guidance: {field}"})
        for relative in set(re.findall(r"scripts/[A-Za-z0-9_./-]+\.(?:R|py|sh)", skill.body)):
            if not (repository / relative).is_file():
                from pathlib import Path
                from microbiome.assets import asset_path
                try:
                    asset_path(Path(relative).name)
                except (ValueError, FileNotFoundError):
                    errors.append({"resource": identity, "issue": f"missing adapter: {relative}"})
        if meta.get("runtime"):
            try:
                package_probe(meta["runtime"])
            except (ValueError, TypeError, KeyError) as error:
                errors.append({"resource": identity, "issue": str(error)})
        for name in meta.get("databases", []):
            if not registry.find_skill("database", name):
                warnings.append({"resource": identity, "issue": f"database discovery required: {name}"})
        if not meta.get("parameter_guidance") and skill.kind == "software":
            warnings.append({"resource": identity, "issue": "parameter guidance is prose; no structured parameter coverage"})
        entries.append({"resource": identity, "documentation_status": meta.get("documentation_status", "CURATED_PROSE"),
                        "runtime_contract": meta.get("runtime"), "local_runtime_status": "NOT_PROBED",
                        "skill_path": str(skill.path)})
    return {"software_count": len(registry.list_skills("software")),
            "database_count": len(registry.list_skills("database")),
            "errors": errors, "warnings": warnings, "entries": entries}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()
    result = audit_catalog()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return int(args.strict and bool(result["errors"]))


if __name__ == "__main__":
    raise SystemExit(main())
