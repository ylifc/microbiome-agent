"""Conservative parameter documentation extracted from the installed tool's help."""

from __future__ import annotations

import re


def schema_from_help(executable: str, version: str, help_text: str) -> dict:
    parameters = []
    for number, line in enumerate(help_text.splitlines(), 1):
        if not re.match(r"^\s+-[A-Za-z-]", line):
            continue
        declaration, *description = re.split(r"\s{2,}|\t+", line.strip(), maxsplit=1)
        flags = re.findall(r"(?<!\w)--?[A-Za-z][\w-]*", declaration)
        if not flags:
            continue
        prose = description[0].strip() if description else ""
        remainder = re.sub(r"--?[A-Za-z][\w-]*", "", declaration).strip(" ,=|")
        default = re.search(r"default\s*[:=]\s*([^;)\]]+)", prose, re.I)
        parameters.append(
            {
                "flags": flags,
                "metavar": remainder or None,
                "takes_value": True if remainder else "unknown",
                "description": prose or "See captured help context",
                "default": default.group(1).strip() if default else None,
                "required": "unknown",
                "type": "unknown",
                "source_line": number,
                "declaration": declaration,
            }
        )
    return {
        "schema_version": 2,
        "executable": executable,
        "version": version,
        "source": "docs/help.txt",
        "coverage": "partial_help_extraction",
        "parameters": parameters,
        "rules": [
            "Do not invent flags or positional argument ordering.",
            "A smoke test validates availability; task invocations require output validation.",
            "Unlisted options require checking the installed version's subcommand help.",
        ],
    }


def render_parameter_reference(schema: dict) -> str:
    lines = [
        "\n## Parameter reference\n",
        "Captured from this executable's help. Unknown types, requiredness and defaults remain unknown.\n",
        "| Flags | Value placeholder | Description | Help line |",
        "| --- | --- | --- | --- |",
    ]
    for item in schema["parameters"]:
        description = item["description"].replace("|", "\\|")
        lines.append(
            f"| {', '.join(item['flags'])} | {item['metavar'] or 'unknown'} | {description} | {item['source_line']} |"
        )
    lines.extend(
        [
            "\n## Invocation checks\n",
            "Correct: use the registered executable and its version-specific documented arguments; verify every declared output.",
            "Incorrect: substitute another tool's flags, omit required inputs, write into a database or raw-data tree, or treat exit code zero alone as a validated analysis.",
            "Validated task examples and failed invocations are recorded in Knowledge. No task example is claimed validated by this generated Skill.",
        ]
    )
    return "\n".join(lines) + "\n"
