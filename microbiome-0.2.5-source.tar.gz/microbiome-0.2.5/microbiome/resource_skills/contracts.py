"""Data-driven database consumer checks; never acquire, index or mutate resources."""
from pathlib import Path
import re

from microbiome.pipeline.errors import ConfigurationError


def _nonempty(path):
    return path.is_file() and path.stat().st_size > 0


def valid_entrypoint(path, kind="existing", suffix_sets=None):
    path = Path(path)
    if kind == "index_prefix":
        return bool(suffix_sets) and any(all(_nonempty(Path(str(path) + suffix)) for suffix in group)
                                         for group in suffix_sets if group)
    if kind not in {"existing", "directory", "file"}:
        raise ConfigurationError(f"unknown database entrypoint kind: {kind}")
    return ((kind != "directory" and _nonempty(path))
            or (kind != "file" and path.is_dir() and any(path.iterdir())))


def validate_database_contract(root, contract, *, consumer=None, parameters=None, command=None):
    root = Path(root)
    errors = []
    if not contract:
        return errors
    manifest_file = contract.get("component_manifest")
    if manifest_file:
        from microbiome.pipeline.io import read_yaml
        path = root / manifest_file
        manifest = read_yaml(path) if path.is_file() else {}
        if not isinstance(manifest, dict) or not all(manifest.get(k) for k in
                ("release", "files", "consumer_entrypoints", "provenance")):
            errors.append("release component manifest is missing required fields")
        else:
            for item in manifest["files"]:
                relative = item.get("path") if isinstance(item, dict) else item
                if not isinstance(relative, str):
                    errors.append("invalid component path")
                    continue
                target = (root / relative).resolve()
                if not target.is_relative_to(root.resolve()) or not _nonempty(target):
                    errors.append(f"missing or invalid component: {relative}")
    groups = contract.get("any_complete_set", [])
    if groups:
        complete = False
        for group in groups:
            suffixes = group.get("suffixes", [])
            if not suffixes:
                raise ConfigurationError("database complete-set contract needs suffixes")
            for first in root.glob("**/*" + suffixes[0]):
                stem = str(first)[:-len(suffixes[0])]
                if all(_nonempty(Path(stem + suffix)) for suffix in suffixes):
                    complete = True
                    break
        if not complete:
            errors.append("no complete index set with the same directory and release prefix")
    for pattern in contract.get("nonempty_globs", []):
        if not any(_nonempty(p) for p in root.glob(pattern)):
            errors.append(f"missing non-empty component: {pattern}")
    selected = contract.get("consumers", {}).get(consumer, {})
    for rule in selected.get("parameter_files", []):
        flag = rule["flag"]
        tokens = command or []
        value = None
        for index, token in enumerate(tokens):
            if token == flag and index + 1 < len(tokens):
                value = tokens[index + 1]
            elif token.startswith(flag + "="):
                value = token.split("=", 1)[1]
        if isinstance(value, str):
            match = re.fullmatch(r"\{parameters\.([^}]+)\}", value)
            if match:
                value = (parameters or {}).get(match.group(1))
        if value is None or not re.fullmatch(r"[A-Za-z0-9_.-]+", str(value)) or str(value) in {".", ".."}:
            errors.append(f"consumer requires an explicit validated {flag} value")
            continue
        filename = rule["pattern"].replace("{value}", str(value))
        if not _nonempty(root / filename):
            errors.append(f"missing consumer parameter file: {filename}")
    return errors


def catalog_contract(resource_id):
    from microbiome.resource_skills.registry import PACKAGE_SKILL_ROOT, _parse_skill
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]*", resource_id):
        return {}
    path = PACKAGE_SKILL_ROOT / "database" / resource_id / "SKILL.md"
    return _parse_skill(path).metadata.get("validation_contract", {}) if path.is_file() else {}
