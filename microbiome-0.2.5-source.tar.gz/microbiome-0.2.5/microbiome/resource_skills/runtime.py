"""Declarative package capabilities, independent of interpreter/environment names."""
import json
import re


def package_probe(contract):
    if not contract:
        return None
    kind = contract.get("kind")
    package = contract.get("package", "")
    functions = contract.get("functions", [])
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_.]*", package) or not all(
        isinstance(f, str) and re.fullmatch(r"[A-Za-z][A-Za-z0-9_.]*", f) for f in functions
    ):
        raise ValueError("invalid package capability contract")
    marker = "MICROBIOME_CAPABILITY_VERSION="
    if kind == "r_package":
        code = f'p <- {json.dumps(package)}; stopifnot(requireNamespace(p, quietly=TRUE)); '
        for dependency in contract.get("requires_packages", []):
            if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_.]*", dependency):
                raise ValueError("invalid required R package")
            code += f'stopifnot(requireNamespace({json.dumps(dependency)}, quietly=TRUE)); '
        for fn in functions:
            code += f'stopifnot(is.function(getExportedValue(p, {json.dumps(fn)}))); '
        code += f'cat("{marker}", as.character(utils::packageVersion(p)), "\\n", sep="")'
        return ["--vanilla", "-e", code], marker
    if kind == "python_package":
        distribution = contract.get("distribution", package)
        code = "import importlib, importlib.metadata; "
        code += f'm = importlib.import_module({package!r}); '
        for fn in functions:
            code += f'assert callable(getattr(m, {fn!r})); '
        code += f'print({marker!r} + importlib.metadata.version({distribution!r}))'
        return ["-I", "-c", code], marker
    raise ValueError("runtime kind must be r_package or python_package")
