---
name: NCBI AMRFinderPlus
description: NCBI detection of antimicrobial resistance genes, curated point mutations, stress genes, and selected virulence
  factors.
kind: software
id: amrfinderplus
version: 2
selection_tier: default
environment: biomni-amrfinderplus
executables:
- amrfinder
- amrfinder_update
- amrfinder_index
packages:
- ncbi-amrfinderplus
channels:
- conda-forge
- bioconda
tasks:
- AMR gene detection
- resistance mutation detection
- stress and virulence screening
databases:
- amrfinderplus
aliases:
- AMRFinderPlus
- amrfinder
- NCBI AMR
- 耐药基因检测
keywords:
- AMR
- antimicrobial resistance
- point mutation
- acquired gene
- virulence
- stress
- NCBI Pathogen Detection
capabilities:
- identify acquired AMR genes
- call curated resistance-associated mutations
- report plus genes for supported organisms
- combine nucleotide protein and GFF evidence
inputs:
- assembled nucleotide FASTA and optionally matching protein FASTA plus GFF
- READY AMRFinderPlus database
outputs:
- tab-delimited AMR mutation stress and virulence hit report
- optional nucleotide/protein hit sequences
upstream:
- bakta
- spades
- flye
- metabat2
- semibin2
downstream: []
software_family: amrfinderplus
documentation_status: CURATED_PROSE
parameter_guidance:
- '| `-n` | Nucleotide assembly input. |'
- '| `-p` | Protein FASTA; pair with matching nucleotide/GFF evidence where available. |'
- '| `-g` | GFF annotation linking proteins and coordinates; validate identifiers first. |'
- '| `-O`, `--organism` | Enable supported organism-specific mutation/search rules only after taxonomy confirmation. |'
- '| `--plus` | Include stress/virulence/biocide categories in addition to core AMR. |'
- '| `--ident_min`, `--coverage_min` | Override curated thresholds only for a justified sensitivity analysis. |'
- '| `--mutation_all` | Broaden mutation reporting where supported; increases interpretation burden. |'
- '| `--nucleotide_output`, `--protein_output` | Export matched sequences for audit/follow-up. |'
- '| `-d`, `--database` | Bind exact `Database/amrfinderplus/` localized release. |'
- '| `--threads` | Bound CPU. |'
- For protein-plus-GFF mode, validate that every CDS identifier resolves to the corresponding protein and nucleotide contig
  before execution.
- Separate core AMR and `--plus` categories in summaries. Report method, coverage and identity with each call so curated exact
  hits and weaker hierarchy/HMM evidence remain distinguishable.
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# NCBI AMRFinderPlus

Use AMRFinderPlus as the default bacterial assembled-genome AMR screen. Keep RGI for CARD model categories and ABRicate for explicitly prepared custom sequence databases.

## Capabilities and selection

AMRFinderPlus combines curated protein/nucleotide similarity, HMMs, and organism-specific mutation catalogs. `--plus` adds selected stress, biocide, heat, and virulence genes. Genotype does not automatically establish phenotype or clinical treatment advice.

## Inputs and upstream

At minimum provide assembled nucleotide FASTA. Protein plus matching GFF can improve hierarchy/context but sequence IDs and coordinates must agree. Use `-O` only for an organism listed by the installed database; wrong organism selection can apply inappropriate mutation rules.

## Outputs and downstream

Primary output is a TSV containing element symbol, sequence name, coordinates, subtype, method, identity, coverage, accession, class/subclass, and hierarchy fields depending on version. Preserve software/database versions and the exact `--plus`/organism policy. Reports feed curated summaries, not automatic prescribing.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `-n` | Nucleotide assembly input. |
| `-p` | Protein FASTA; pair with matching nucleotide/GFF evidence where available. |
| `-g` | GFF annotation linking proteins and coordinates; validate identifiers first. |
| `-O`, `--organism` | Enable supported organism-specific mutation/search rules only after taxonomy confirmation. |
| `--plus` | Include stress/virulence/biocide categories in addition to core AMR. |
| `--ident_min`, `--coverage_min` | Override curated thresholds only for a justified sensitivity analysis. |
| `--mutation_all` | Broaden mutation reporting where supported; increases interpretation burden. |
| `--nucleotide_output`, `--protein_output` | Export matched sequences for audit/follow-up. |
| `-d`, `--database` | Bind exact `Database/amrfinderplus/` localized release. |
| `--threads` | Bound CPU. |

For protein-plus-GFF mode, validate that every CDS identifier resolves to the corresponding protein and nucleotide contig before execution.

Separate core AMR and `--plus` categories in summaries. Report method, coverage and identity with each call so curated exact hits and weaker hierarchy/HMM evidence remain distinguishable.

## Workflow patterns

```bash
conda run -n biomni-amrfinderplus --no-capture-output amrfinder \
  -n genome.fna -p proteins.faa -g annotation.gff3 \
  -d Database/amrfinderplus --plus --threads 8 > amrfinder.tsv
```

## Validation and failure handling

Require database version output, parseable non-empty-header TSV, valid coordinates/IDs, method and hierarchy fields, and organism compatibility. Empty hits may be valid but require a positive-control/tool test. GFF/protein mismatch, unsupported organism, or database/software incompatibility must be corrected rather than bypassed with permissive thresholds.
