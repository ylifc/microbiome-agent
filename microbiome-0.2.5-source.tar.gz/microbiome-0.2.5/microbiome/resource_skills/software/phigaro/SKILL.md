---
name: Phigaro
description: Fast prophage prediction from bacterial genomes using pVOGs HMM profiles and gene density scoring.
kind: software
id: phigaro
version: 2
selection_tier: conditional
environment: biomni-phigaro
executables:
- phigaro
packages:
- phigaro
channels:
- conda-forge
- bioconda
tasks:
- prophage prediction
- phage region identification
- HGT screening via prophage annotation
databases:
- phigaro-pvogs
aliases:
- Phigaro
- prophage predictor
- 前噬菌体识别
keywords:
- prophage
- phage
- pVOGs
- HMM
- HGT
- genome
- 前噬菌体
- 水平基因转移
capabilities:
- predict prophage regions
- score gene windows against pVOGs
- output per-region coordinates
- batch-process many genomes
inputs:
- bacterial genome FASTA (single or directory)
- configured pVOGs HMM database
outputs:
- prophage prediction table
- optional GFF/visualization
upstream:
- spades
- flye
- unicycler
downstream:
- phispy
- vibrant
- checkv
software_family: phigaro
documentation_status: CURATED_PROSE
downstream_tasks:
- phage phylogeny
parameter_guidance:
- '| `-f` | Input genome FASTA or directory. |'
- '| `-o` | Output filename/basename (prefix), e.g. `folder/basename`. |'
- '| `-e` | Output format (`html`, `tsv`, `gff`, `bed`, `stdout`). |'
- '| `-t` | Threads. |'
- '| `-p`, `--print-vogs` | Boolean: print phage pVOGs for each region. |'
- '| `phigaro-setup` | One-time pVOGs HMM database download. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# Phigaro

Use Phigaro for fast, high-throughput prophage prediction. It scans genomes with pVOGs HMM profiles and gene-density scoring to call prophage regions, scaling to many genomes at once.

```bash
# one-time database setup, then predict
conda run -n biomni-phigaro --no-capture-output phigaro-setup
conda run -n biomni-phigaro --no-capture-output phigaro \
  -f genome.fasta -o phigaro_out -e tsv -t 8
```

## Capabilities and selection

Phigaro predicts prophages using pVOGs (prokaryotic Virus Orthologous Groups) HMMs, producing per-region coordinates and scores. Prefer it for rapid prophage screening of isolate genomes; combine with PhiSpy/VIBRANT for consensus and geNomad/VirSorter2 for metagenomes. It predicts regions, not viral completeness.

## Inputs and upstream

Input is a bacterial genome FASTA (or a directory of genomes). The pVOGs HMM database must be installed via `phigaro-setup` before use. Record the pVOGs version.

## Outputs and downstream

Output is a prophage prediction table (TSV) with coordinates, length, and GC, plus optional GFF. Feed prophage regions to VIBRANT/CheckV and phage phylogeny tools.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `-f` | Input genome FASTA or directory. |
| `-o` | Output filename/basename (prefix), e.g. `folder/basename`. |
| `-e` | Output format (`html`, `tsv`, `gff`, `bed`, `stdout`). |
| `-t` | Threads. |
| `-p`, `--print-vogs` | Boolean: print phage pVOGs for each region. |
| `phigaro-setup` | One-time pVOGs HMM database download. |

## Workflow patterns

```bash
conda run -n biomni-phigaro --no-capture-output phigaro-setup
conda run -n biomni-phigaro --no-capture-output phigaro \
  -f genomes/ -o phigaro_out -e tsv -t 8
```

## Validation and failure handling

Record the pVOGs version and threshold. Cross-check prophage calls with PhiSpy/VIBRANT and inspect integrase/att-site evidence. A missing pVOGs database is the usual failure — run `phigaro-setup` first. Weak, low-score regions are candidates, not confirmed prophages.

## Reproducibility and audit

Record Phigaro version, pVOGs database version, threshold, and input genomes. Re-run and diff the prediction table to confirm determinism. Keep the pVOGs database immutable and document its provenance.
