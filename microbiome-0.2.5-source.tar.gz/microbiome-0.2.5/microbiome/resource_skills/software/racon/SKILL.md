---
name: Racon
description: Long-read consensus polishing from read-to-assembly overlaps.
kind: software
id: racon
version: 2
selection_tier: default
environment: microbiome-racon
executables:
- racon
packages:
- racon
channels:
- conda-forge
- bioconda
tasks:
- long-read assembly polishing
- consensus correction
databases: []
aliases:
- Racon polisher
- long-read polishing
- 长读长纠错
keywords:
- Nanopore
- PacBio
- consensus
- polishing
- minimap2
- PAF
- SAM
capabilities:
- sequence-to-graph consensus polishing
- iterative correction from mapped long reads
inputs:
- long reads
- minimap2 PAF or SAM overlaps
- draft assembly
outputs:
- polished assembly FASTA
upstream:
- flye
- minimap2
downstream:
- medaka
- quast
- bakta
software_family: racon
documentation_status: CURATED_PROSE
parameter_guidance:
- '| `-t` | Threads. |'
- '| `-m`, `-x`, `-g`, `-w` | `-m/--match` match score (default 5), `-x/--mismatch` mismatch score (default -4), `-g/--gap`
  gap penalty (default -8), `-w/--window-length` POA window size (default 500). |'
- '| `-u` | Include unpolished windows when no read support exists; use with caution. |'
- '| `reads.fastq` | Long reads. |'
- '| `overlaps.sam` | minimap2 overlaps in PAF or sorted SAM. |'
- '| `assembly.fa` | Draft assembly to polish. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# Use Racon after long-read assembly when read-back evidence supports consensus polishing. Each round must consume the previous round's assembly and write a new immutable output.

## Capabilities and selection

Racon performs sequence-to-graph consensus polishing using read-to-assembly overlaps, correcting base errors without a reference. It is a standard first polishing pass for Flye/Canu assemblies. Use it for both Nanopore and PacBio long reads; follow with Medaka (ONT, model-matched) or Pilon (Illumina) when justified.

## Inputs and upstream

Inputs are long reads, the draft assembly, and overlaps in minimap2 PAF/SAM format. Map reads to the draft with minimap2 (`-x map-ont` / `-x map-pacbio`) and sort the resulting SAM before running Racon.

## Outputs and downstream

Output is a polished assembly FASTA. Run QUAST to quantify improvement, then optionally run a second Racon round or hand off to Medaka/Pilon and finally Bakta.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `-t` | Threads. |
| `-m`, `-x`, `-g`, `-w` | `-m/--match` match score (default 5), `-x/--mismatch` mismatch score (default -4), `-g/--gap` gap penalty (default -8), `-w/--window-length` POA window size (default 500). |
| `-u` | Include unpolished windows when no read support exists; use with caution. |
| `reads.fastq` | Long reads. |
| `overlaps.sam` | minimap2 overlaps in PAF or sorted SAM. |
| `assembly.fa` | Draft assembly to polish. |

## Workflow patterns

```bash
conda run -n microbiome-racon --no-capture-output minimap2 -x map-ont -t 16 draft.fa reads.fastq.gz > overlaps.paf
conda run -n microbiome-racon --no-capture-output racon -t 16 reads.fastq.gz overlaps.paf draft.fa > polished.fa
```

## Validation and failure handling

Each Racon round must write a new immutable file; never overwrite the input in place. Require non-empty output and run QUAST to confirm the delta is an improvement. If polishing worsens metrics, check read quality, mapping mode, or whether the draft already exceeded the read accuracy.

## Reproducibility and audit

Record the Racon version, the number of polishing rounds, and the mapping mode (map-ont/map-pacbio) next to each polished assembly. Re-run on the same inputs and confirm identical output to verify determinism. Keep every round as a new immutable file so the polishing history is auditable.

```bash
# provenance: capture version
conda run -n microbiome-racon --no-capture-output racon --version 2>&1 | head -20
```

If polishing is iterated, keep round-1, round-2, ... outputs and record the mapping mode for each round so the history is fully traceable.
