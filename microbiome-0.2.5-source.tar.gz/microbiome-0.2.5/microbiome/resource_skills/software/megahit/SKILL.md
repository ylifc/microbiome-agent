---
name: MEGAHIT
description: Memory-efficient de novo assembly of metagenomic short reads.
kind: software
id: megahit
version: 2
environment: megahit
executables:
- megahit
packages:
- megahit
channels:
- conda-forge
- bioconda
tasks:
- metagenome assembly
- short-read assembly
databases: []
aliases:
- MEGAHIT
- metagenome assembler
- 宏基因组组装
keywords:
- metagenome
- assembly
- short reads
- de Bruijn graph
- 宏基因组
- 组装
capabilities:
- paired or single short-read metagenome assembly
- multi-k assembly
- memory-efficient assembly
inputs:
- FASTQ or FASTQ.GZ single-end reads
- paired FASTQ or FASTQ.GZ reads
- optional multiple libraries
outputs:
- final.contigs.fa assembly FASTA
- intermediate_contigs directory
- log and options files
upstream:
- seqkit
downstream:
- prodigal
- bwa
- bowtie2
- metabat2
- maxbin2
- concoct
- bakta
- abricate
- genomad
- checkv
software_family: megahit
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Parameter | Meaning and setting rule |'
- '| `-1`, `-2` | Paired reads. Keep file order and sample pairing synchronized. |'
- '| `-r` | Single-end or unpaired reads; do not place normal mate files here. |'
- '| `--12` | Interleaved paired reads only. |'
- '| `--presets meta-sensitive` | More sensitive preset for lower-abundance organisms; costs more time and memory. |'
- '| `--presets meta-large` | Intended for large, complex metagenomes; verify local-version availability with `megahit --help`.
  |'
- '| `--k-list` | Explicit odd k-mer series. Keep k below read length and use an increasing series; defaults are safer unless
  coverage/read length justify tuning. |'
- '| `--min-count` | Minimum multiplicity for solid k-mers. Lowering can recover low-depth sequence but increases error graph
  and memory. |'
- '| `--min-contig-len` | Output length cutoff. Use about 1000-2500 bp for binning, but retain shorter contigs when viral
  or gene-centric recovery requires them. |'
- '| `-t` | Threads. Set from allocated CPUs, not all host CPUs by assumption. |'
- '| `-m` | Maximum memory fraction or bytes according to local help. Leave headroom for the OS and concurrent tasks. |'
- '| `--no-mercy` | May recover low-depth complex regions; use only with adequate read quality because it can admit error-derived
  paths. |'
- '| `--continue` | Resume an interrupted run only when the output directory and inputs/options are unchanged. |'
- '| `-o`, `--out-prefix` | Output directory and file prefix. The output directory must not contain unrelated prior results.
  |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# MEGAHIT

Use paired FASTQ files with matching read counts and names. Write each run to a new output directory.

```bash
conda run -n megahit --no-capture-output megahit -1 reads_R1.fastq.gz -2 reads_R2.fastq.gz -o megahit_out --min-contig-len 1000
```

Verify `final.contigs.fa`, the run log, and assembly statistics before binning or annotation.

## Capabilities and selection

MEGAHIT assembles Illumina-style metagenomic reads with a succinct de Bruijn graph and is usually the first choice when memory, sample size, or community complexity makes metaSPAdes expensive. It accepts single-end, paired-end, interleaved, and multiple libraries. It does not polish long-read assemblies and does not replace read QC, host removal, or assembly validation.

Choose MEGAHIT for large short-read metagenomes and rapid iteration. Prefer metaSPAdes when maximum contiguity on a tractable dataset matters more than memory. Do not mix biological samples into one assembly unless co-assembly is intentional and downstream coverage is retained per sample.

## Inputs and upstream

| Input | Required format | Typical producer | Checks before use |
| --- | --- | --- | --- |
| Forward and reverse reads | Matched FASTQ/FASTQ.GZ via `-1` and `-2` | sequencer, adapter/quality trimming | equal pair counts, consistent sample identity, valid Phred encoding |
| Single reads | FASTQ/FASTQ.GZ via `-r` | unpaired reads after QC | no accidental mate mixing |
| Interleaved pairs | FASTQ/FASTQ.GZ via `--12` | read preprocessing | strict alternating mate order |
| Multiple libraries | comma-separated files per option | intentional co-assembly | preserve library and sample provenance for later mapping |

SeqKit can check read counts and formats. Host filtering may be performed with Bowtie 2 before assembly, but retained and removed read counts must be reported.

## Outputs and downstream

`final.contigs.fa` is the canonical assembly FASTA. `intermediate_contigs/`, `log`, and `options.json` support reproducibility and debugging. Rename or copy the final FASTA deliberately if downstream code expects `assembly.fasta`; never pass an intermediate k-mer assembly by accident.

The assembly can feed Prodigal gene calling, BWA/Bowtie 2 coverage mapping, MetaBAT 2/MaxBin 2/CONCOCT binning, geNomad and CheckV viral analysis, Bakta annotation, or ABRicate screening. Binning requires reads mapped back to this exact FASTA so contig identifiers remain unchanged.

## Parameters and decision rules

| Parameter | Meaning and setting rule |
| --- | --- |
| `-1`, `-2` | Paired reads. Keep file order and sample pairing synchronized. |
| `-r` | Single-end or unpaired reads; do not place normal mate files here. |
| `--12` | Interleaved paired reads only. |
| `--presets meta-sensitive` | More sensitive preset for lower-abundance organisms; costs more time and memory. |
| `--presets meta-large` | Intended for large, complex metagenomes; verify local-version availability with `megahit --help`. |
| `--k-list` | Explicit odd k-mer series. Keep k below read length and use an increasing series; defaults are safer unless coverage/read length justify tuning. |
| `--min-count` | Minimum multiplicity for solid k-mers. Lowering can recover low-depth sequence but increases error graph and memory. |
| `--min-contig-len` | Output length cutoff. Use about 1000-2500 bp for binning, but retain shorter contigs when viral or gene-centric recovery requires them. |
| `-t` | Threads. Set from allocated CPUs, not all host CPUs by assumption. |
| `-m` | Maximum memory fraction or bytes according to local help. Leave headroom for the OS and concurrent tasks. |
| `--no-mercy` | May recover low-depth complex regions; use only with adequate read quality because it can admit error-derived paths. |
| `--continue` | Resume an interrupted run only when the output directory and inputs/options are unchanged. |
| `-o`, `--out-prefix` | Output directory and file prefix. The output directory must not contain unrelated prior results. |

## Workflow patterns

```bash
conda run -n seqkit --no-capture-output seqkit stats reads_R1.fastq.gz reads_R2.fastq.gz
conda run -n megahit --no-capture-output megahit \
  -1 reads_R1.fastq.gz -2 reads_R2.fastq.gz \
  --min-contig-len 1000 -t 16 -o megahit_out
conda run -n seqkit --no-capture-output seqkit stats megahit_out/final.contigs.fa
```

For binning, map every sample separately to `final.contigs.fa`, sort BAM files with SAMtools, and retain sample-specific depth rather than pooling alignments.

## Validation and failure handling

Require exit code zero, non-empty `final.contigs.fa`, sensible total assembly size, N50/L50, contig count, maximum contig length, and read mapping rate back to the assembly. An empty output usually indicates malformed/empty reads or an earlier fatal log message. A killed process usually indicates memory pressure; reduce threads, use a less sensitive preset, or split intentional work rather than silently changing biological grouping. Very fragmented output suggests low coverage, residual errors, strain complexity, or unsuitable k-mers; inspect QC and mapping before tuning. Never compare N50 alone across biologically different assemblies.
