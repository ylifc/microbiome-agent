---
name: Flye
description: Repeat-graph de novo assembly for Oxford Nanopore and PacBio long reads, including metagenome mode.
kind: software
id: flye
version: 2
selection_tier: default
environment: biomni-flye
executables:
- flye
packages:
- flye
channels:
- conda-forge
- bioconda
tasks:
- long-read genome assembly
- long-read metagenome assembly
- repeat graph generation
databases: []
aliases:
- Flye assembler
- metaFlye
- long-read assembly
- 长读长组装
keywords:
- ONT
- Nanopore
- PacBio
- HiFi
- repeat graph
- circular contig
- meta assembly
- 长读长
capabilities:
- assemble noisy or high-quality long reads
- metagenomic long-read assembly
- generate repeat graphs and assembly statistics
inputs:
- quality-controlled ONT PacBio CLR or PacBio HiFi FASTQ/FASTA reads
outputs:
- assembly.fasta
- assembly_graph.gfa
- assembly_info.txt
- flye.log
- intermediate repeat and consensus files
upstream:
- nanoplot
- chopper
downstream:
- minimap2
- quast
- bakta
- genomad
- checkv
- panaroo
software_family: flye
documentation_status: CURATED_PROSE
parameter_guidance:
- '| `--nano-raw`, `--nano-hq` | ONT noisy versus high-quality reads; choose from basecaller/QC evidence and installed help.
  |'
- '| `--pacbio-raw`, `--pacbio-hifi` | PacBio CLR versus HiFi. Never interchange. |'
- '| `--meta` | Uneven-coverage metagenome mode, not a generic quality boost for isolates. |'
- '| `--genome-size` | Expected haploid size used for coverage-related decisions; provide a plausible estimate. |'
- '| `--out-dir`, `--threads` | New isolated output and bounded CPU allocation. |'
- '| `--iterations` | Internal polishing iterations. Increase only when logs/read quality justify it. |'
- '| `--min-overlap` | Minimum overlap; tune for read length and repeats only after a failed/default run is understood. |'
- '| `--asm-coverage` | Limit longest-read coverage for initial disjointig assembly in high-coverage data. |'
- '| `--read-error` | Override expected error only for characterized technologies. |'
- '| `--resume`, `--resume-from`, `--stop-after` | Controlled recovery/debugging; never resume after changing inputs or incompatible
  parameters. |'
- '| `--keep-haplotypes` | Retain alternate paths where supported; interpret strain/haplotype duplication cautiously. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# Flye

Use Flye as the default long-read assembler and SPAdes for short-read isolate assembly. Select exactly one read-type option that matches the basecaller/platform.

## Capabilities and selection

Flye builds a repeat graph and performs consensus polishing for ONT/PacBio reads; `--meta` adapts repeat/coverage assumptions to uneven metagenomes. It can report circular paths but circularity still requires coverage/read-bridge validation. It is not a short-read hybrid assembler and does not replace independent polishing or assembly QC.

## Inputs and upstream

Inputs are quality-reviewed long reads after NanoPlot and optional Chopper. Estimate genome size, coverage, read N50, quality, contamination, and whether the sample is isolate or metagenome. Do not pool unrelated barcodes or biological samples to raise coverage.

## Outputs and downstream

`assembly.fasta` is the primary assembly, `assembly_graph.gfa` captures unresolved graph structure, `assembly_info.txt` reports coverage/circularity/repeats, and `flye.log` is required for diagnosis. Outputs feed minimap2 read-back mapping, QUAST, Bakta, viral detection, or long-read metagenomic binning.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `--nano-raw`, `--nano-hq` | ONT noisy versus high-quality reads; choose from basecaller/QC evidence and installed help. |
| `--pacbio-raw`, `--pacbio-hifi` | PacBio CLR versus HiFi. Never interchange. |
| `--meta` | Uneven-coverage metagenome mode, not a generic quality boost for isolates. |
| `--genome-size` | Expected haploid size used for coverage-related decisions; provide a plausible estimate. |
| `--out-dir`, `--threads` | New isolated output and bounded CPU allocation. |
| `--iterations` | Internal polishing iterations. Increase only when logs/read quality justify it. |
| `--min-overlap` | Minimum overlap; tune for read length and repeats only after a failed/default run is understood. |
| `--asm-coverage` | Limit longest-read coverage for initial disjointig assembly in high-coverage data. |
| `--read-error` | Override expected error only for characterized technologies. |
| `--resume`, `--resume-from`, `--stop-after` | Controlled recovery/debugging; never resume after changing inputs or incompatible parameters. |
| `--keep-haplotypes` | Retain alternate paths where supported; interpret strain/haplotype duplication cautiously. |

## Workflow patterns

```bash
conda run -n biomni-flye --no-capture-output flye \
  --nano-hq reads.filtered.fastq.gz --genome-size 5m \
  --out-dir flye_out --threads 16
```

For metagenomes, add `--meta` and expect substantially greater memory/runtime; plan binning and coverage mapping separately.

## Validation and failure handling

Require non-empty assembly, graph and log, total size near biological expectation, contig count/N50, read-back coverage, graph/circularity inspection, and QUAST results. No disjointigs usually indicates insufficient usable coverage, wrong read type, extreme contamination, or thresholds incompatible with read lengths. Crashes after parameter/input changes must start a new output directory rather than unsafe resume.
