---
name: ANCOM-BC2
description: Bias-corrected differential abundance analysis for microbiome count data with covariates and repeated measures.
kind: software
id: ancombc2
version: 2
selection_tier: conditional
environment: biomni-ancombc2
executables:
- Rscript
runtime:
  kind: r_package
  package: ANCOMBC
  functions:
  - ancombc2
  requires_packages:
  - jsonlite
packages:
- r-base
- bioconductor-ancombc
- r-jsonlite
channels:
- conda-forge
- bioconda
tasks:
- microbiome differential abundance
- covariate-adjusted testing
- repeated-measures differential abundance
databases: []
aliases:
- ANCOMBC2
- ANCOM-BC2
- 差异丰度
- 微生物组差异分析
keywords:
- differential abundance
- compositional bias
- sampling fraction
- covariates
- repeated measures
- structural zero
capabilities:
- bias-correct abundance estimates
- fit multivariable and mixed-effect models
- perform global pairwise Dunnett and trend tests
- detect structural zeros
inputs:
- raw nonnegative feature counts
- sample metadata
- optional taxonomy and phylogeny in a supported R container
outputs:
- bias-corrected coefficients
- standard errors
- p-values and q-values
- differential abundance flags
- structural-zero and sensitivity diagnostics
upstream:
- dada2
- qiime2
- kraken2
- phyloseq
downstream: []
software_family: ancombc2
documentation_status: CURATED_PROSE
downstream_tasks:
- statistical reporting
- effect-size visualization
- confirmatory analysis
parameter_guidance:
- '| `ancombc2(data=...)` | Main model; pass raw counts through a supported object and verify orientation. |'
- '| `fix_formula` | Fixed-effect model without leading `~`; include exposure and prespecified confounders, avoiding rank-deficient
  terms. |'
- '| `rand_formula` | Random effects such as subject intercepts for repeated measures; omit for independent samples. |'
- '| `group` | Primary grouping variable used by structural-zero and multiple-group procedures. |'
- '| `p_adj_method` | Multiple-testing correction, commonly BH; prespecify and report. |'
- '| `prv_cut` | Remove features below prevalence threshold; choose before looking at significance and report retained features.
  |'
- '| `lib_cut` | Remove samples with very low library size only using a defensible QC threshold. |'
- '| `struc_zero` | Detect taxa absent in all samples of a group; interpret separately from model-based effects. |'
- '| `neg_lb` | Apply conservative negative lower-bound handling for structural zeros when appropriate. |'
- '| `global` | Omnibus test across multi-level groups before/alongside contrasts. |'
- '| `pairwise` | All pairwise contrasts; account for larger multiplicity and define reference levels. |'
- '| `dunnet` | Compare multiple groups with a chosen reference. |'
- '| `trend` | Ordered-group trend tests; order and contrast constraints must be scientifically defined. |'
- '| `iter_control` | Outer optimization tolerance/iterations; change only when convergence diagnostics demand it. |'
- '| `em_control` | EM algorithm controls; preserve defaults unless convergence is documented. |'
- '| `lme_control` | Mixed-model optimizer settings for random-effect fits. |'
- '| `pseudo_sens` | Sensitivity analysis to pseudo-count choices; important when zeros are extensive. |'
- '| `n_cl` | Parallel workers bounded to available CPUs/memory. |'
- '| `verbose` | Retain diagnostic output during model development and failure investigation. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# ANCOM-BC2

Use ANCOM-BC2 for differential abundance when compositional sampling-fraction bias, covariates, multiple groups or repeated measures need explicit modeling. It is not a substitute for study design, batch control or adequate replication, and it should receive raw counts rather than percentages or rarefied abundances.

## Capabilities and selection

ANCOM-BC2 estimates bias-corrected log abundance effects and supports fixed effects, random effects, structural-zero detection, global tests, pairwise contrasts, Dunnett-type comparisons and ordered-group trend tests. Use simpler tests only when their assumptions and inferential target match the design.

## Inputs and upstream

Construct a supported `phyloseq`, `TreeSummarizedExperiment`, `SummarizedExperiment` or matrix-plus-metadata object according to the installed API. Counts must be nonnegative integers with feature/sample names aligned exactly. Metadata variables need intentional factor reference levels; subject IDs and batch covariates must be declared before fitting.

## Outputs and downstream

Retain coefficients, standard errors, test statistics, raw/adjusted p-values, differential flags, prevalence filters, structural-zero results, sensitivity outputs and model/session provenance. Report effect direction and uncertainty alongside q-values; do not present significance alone.

## Parameters and decision rules

| Function/argument | Meaning and setting rule |
| --- | --- |
| `ancombc2(data=...)` | Main model; pass raw counts through a supported object and verify orientation. |
| `fix_formula` | Fixed-effect model without leading `~`; include exposure and prespecified confounders, avoiding rank-deficient terms. |
| `rand_formula` | Random effects such as subject intercepts for repeated measures; omit for independent samples. |
| `group` | Primary grouping variable used by structural-zero and multiple-group procedures. |
| `p_adj_method` | Multiple-testing correction, commonly BH; prespecify and report. |
| `prv_cut` | Remove features below prevalence threshold; choose before looking at significance and report retained features. |
| `lib_cut` | Remove samples with very low library size only using a defensible QC threshold. |
| `struc_zero` | Detect taxa absent in all samples of a group; interpret separately from model-based effects. |
| `neg_lb` | Apply conservative negative lower-bound handling for structural zeros when appropriate. |
| `global` | Omnibus test across multi-level groups before/alongside contrasts. |
| `pairwise` | All pairwise contrasts; account for larger multiplicity and define reference levels. |
| `dunnet` | Compare multiple groups with a chosen reference. |
| `trend` | Ordered-group trend tests; order and contrast constraints must be scientifically defined. |
| `iter_control` | Outer optimization tolerance/iterations; change only when convergence diagnostics demand it. |
| `em_control` | EM algorithm controls; preserve defaults unless convergence is documented. |
| `lme_control` | Mixed-model optimizer settings for random-effect fits. |
| `pseudo_sens` | Sensitivity analysis to pseudo-count choices; important when zeros are extensive. |
| `n_cl` | Parallel workers bounded to available CPUs/memory. |
| `verbose` | Retain diagnostic output during model development and failure investigation. |

## Workflow patterns

```bash
conda run -n biomni-ancombc2 --no-capture-output Rscript scripts/run_ancombc2.R \
  counts.tsv metadata.tsv ancombc2_out parameters.json
```

The script must write its formulas, factor levels, filters, contrasts, package versions and random seed to a run manifest.

## Validation and failure handling

Check feature/sample alignment, count integrality, design-matrix rank, group sizes, convergence and the number of tested features. Singular mixed models require study-design review or a justified simpler random structure; they are not fixed by silently dropping covariates. Compare strong findings with prevalence/raw-count plots and sensitivity output, and label exploratory contrasts as such.

## Bundled adapter contract

The repository adapter requires an explicit JSON parameter file. The pipeline must declare and fingerprint the adapter and its parameter source. No parameters are tuned automatically. See `docs/cohort_workflows.md` for the schemas and output checks. Local package and scientific acceptance tests remain required before production.
