---
name: QIIME 2
description: Provenance-aware framework for reproducible microbiome and amplicon analysis with typed artifacts and plugins.
kind: software
id: qiime2
version: 2
selection_tier: conditional
environment: rachis-qiime2-2026.7
environment_file: https://raw.githubusercontent.com/qiime2/distributions/refs/heads/dev/2026.7/qiime2/released/rachis-qiime2-linux-64-conda.yml
executables:
- qiime
channels:
- conda-forge
- bioconda
tasks:
- amplicon analysis
- microbiome diversity analysis
- taxonomic classification
- artifact provenance
databases: []
optional_databases:
- silva
- unite
aliases:
- QIIME2
- QIIME 2
- 扩增子分析平台
- 微生物组分析
keywords:
- qza
- qzv
- microbiome
- amplicon
- feature table
- diversity
- metadata
- provenance
capabilities:
- enforce semantic types and provenance
- integrate denoising taxonomy phylogeny and diversity plugins
- export reproducible visualizations and artifacts
inputs:
- manifest-imported reads or typed QIIME artifacts
- validated sample metadata
- optional SILVA or UNITE classifier
outputs:
- QZA artifacts
- QZV visualizations
- feature tables
- representative sequences
- taxonomy
- phylogeny and diversity statistics
upstream:
- sra-toolkit
- fastp
- dada2
downstream:
- ancombc2
- phyloseq
software_family: qiime2
documentation_status: CURATED_PROSE
downstream_tasks:
- ecological statistics
- report generation
parameter_guidance:
- '| Command/option | Meaning and setting rule |'
- '| `qiime tools import --type` | Declare the biological semantic type; a format-compatible file with the wrong type is still
  invalid. |'
- '| `--input-format` | Match manifest/read encoding exactly, including paired/single and Phred format. |'
- '| `qiime demux summarize` | Inspect per-position quality before trimming and denoising. |'
- '| `qiime dada2 denoise-paired` | Paired Illumina denoising when sufficient post-trim overlap remains. |'
- '| `qiime dada2 denoise-single` | Single-end denoising or paired data intentionally analyzed as one read direction. |'
- '| `--p-trim-left-f/r` | Remove primers/residual leading bases based on primer length and quality. |'
- '| `--p-trunc-len-f/r` | Quality truncation while preserving amplicon overlap; zero disables truncation. |'
- '| `--p-max-ee-f/r` | Expected-error filtering when exposed by the installed plugin version. |'
- '| `--p-n-threads` | Bound DADA2/classifier parallelism; zero may consume all CPUs and should be avoided on shared hosts.
  |'
- '| `qiime feature-classifier classify-sklearn` | Apply a compatible pre-trained classifier; never use a 16S classifier for
  ITS or a mismatched region silently. |'
- '| `--p-confidence` | Taxonomy confidence threshold; lower increases rank assignments and uncertainty. |'
- '| `qiime phylogeny align-to-tree-mafft-fasttree` | Typical 16S phylogenetic workflow; ITS may not support meaningful global
  alignment/tree assumptions. |'
- '| `qiime diversity core-metrics-phylogenetic` | Rarefaction-based core metrics; choose sampling depth from table summaries
  and attrition, not the largest possible value. |'
- '| `--m-metadata-file` | Validated TSV metadata; categorical/numeric interpretation must be checked before statistics. |'
- '| `--use-cache` | Shared cache path for parallel/HPC work where local temporary storage is unsuitable. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# QIIME 2

Use QIIME 2 when typed artifacts, plugin interoperability and end-to-end provenance are important. Keep it in its official release-specific environment; its coordinated plugin stack should not be assembled by independently adding arbitrary packages to a generic environment.

## Capabilities and selection

QIIME 2 records provenance within `.qza`/`.qzv`, validates semantic types and coordinates demultiplexing, DADA2/Deblur, taxonomy, phylogeny, diversity and statistical plugins. Direct DADA2 R workflows may be preferable for custom diagnostics; QIIME 2 is preferable when artifact provenance and standardized plugin exchange are primary requirements.

## Inputs and upstream

Import FASTQ through an explicit manifest and choose the correct semantic type and input format for single-end/paired-end and Phred offset. Metadata IDs must exactly match feature-table sample IDs. Taxonomic classifiers must match the marker locus, primer region, sequence orientation, QIIME release and scikit-learn compatibility; store them under the corresponding SILVA/UNITE database folder.

## Outputs and downstream

Retain every `.qza`, `.qzv`, command/action provenance and validated metadata. Core outputs include feature table, representative sequences, denoising stats, taxonomy, rooted tree, alpha/beta diversity and statistical visualizations. Export only at interoperability boundaries; prefer artifacts internally to retain semantic validation and provenance.

## Parameters and decision rules

| Command/option | Meaning and setting rule |
| --- | --- |
| `qiime tools import --type` | Declare the biological semantic type; a format-compatible file with the wrong type is still invalid. |
| `--input-format` | Match manifest/read encoding exactly, including paired/single and Phred format. |
| `qiime demux summarize` | Inspect per-position quality before trimming and denoising. |
| `qiime dada2 denoise-paired` | Paired Illumina denoising when sufficient post-trim overlap remains. |
| `qiime dada2 denoise-single` | Single-end denoising or paired data intentionally analyzed as one read direction. |
| `--p-trim-left-f/r` | Remove primers/residual leading bases based on primer length and quality. |
| `--p-trunc-len-f/r` | Quality truncation while preserving amplicon overlap; zero disables truncation. |
| `--p-max-ee-f/r` | Expected-error filtering when exposed by the installed plugin version. |
| `--p-n-threads` | Bound DADA2/classifier parallelism; zero may consume all CPUs and should be avoided on shared hosts. |
| `qiime feature-classifier classify-sklearn` | Apply a compatible pre-trained classifier; never use a 16S classifier for ITS or a mismatched region silently. |
| `--p-confidence` | Taxonomy confidence threshold; lower increases rank assignments and uncertainty. |
| `qiime phylogeny align-to-tree-mafft-fasttree` | Typical 16S phylogenetic workflow; ITS may not support meaningful global alignment/tree assumptions. |
| `qiime diversity core-metrics-phylogenetic` | Rarefaction-based core metrics; choose sampling depth from table summaries and attrition, not the largest possible value. |
| `--m-metadata-file` | Validated TSV metadata; categorical/numeric interpretation must be checked before statistics. |
| `--use-cache` | Shared cache path for parallel/HPC work where local temporary storage is unsuitable. |

## Workflow patterns

```bash
conda run -n rachis-qiime2-2026.7 --no-capture-output qiime tools import \
  --type 'SampleData[PairedEndSequencesWithQuality]' \
  --input-path manifest.tsv --output-path demux.qza \
  --input-format PairedEndFastqManifestPhred33V2
conda run -n rachis-qiime2-2026.7 --no-capture-output qiime dada2 denoise-paired \
  --i-demultiplexed-seqs demux.qza --p-trim-left-f 17 --p-trim-left-r 21 \
  --p-trunc-len-f 240 --p-trunc-len-r 200 --p-n-threads 16 \
  --o-table table.qza --o-representative-sequences rep-seqs.qza \
  --o-denoising-stats denoising-stats.qza
```

## Validation and failure handling

Run `qiime info`, validate metadata, and use `qiime tools peek`/provenance before consuming artifacts. Check denoising read attrition, feature-table sparsity, negative controls and classifier compatibility. Plugin action names/options are release-specific; if a planned option is absent, inspect `qiime <plugin> <action> --help` in the pinned environment and amend the command without changing the scientific intent.
