---
name: antiSMASH
description: Detects, annotates, and compares microbial secondary-metabolite biosynthetic gene clusters.
kind: software
id: antismash
version: 2
selection_tier: conditional
environment: biomni-antismash
executables:
- antismash
- download-antismash-databases
packages:
- antismash
channels:
- conda-forge
- bioconda
tasks:
- biosynthetic gene cluster detection
- secondary metabolite annotation
- BGC comparison
databases:
- antismash
aliases:
- antiSMASH
- antismash
- 次级代谢基因簇
- BGC预测
keywords:
- BGC
- biosynthetic gene cluster
- secondary metabolite
- NRPS
- PKS
- RiPP
- MIBiG
- clusterblast
capabilities:
- rule-based BGC detection
- domain and gene-cluster annotation
- known-cluster and neighborhood comparison
- GenBank and HTML reporting
inputs:
- annotated GenBank or genome FASTA
- organism taxon
- READY version-matched antiSMASH databases
outputs:
- interactive HTML report
- annotated GenBank
- JSON
- region GenBank files
- module-specific tables
upstream:
- flye
- spades
- bakta
downstream:
- hmmer
software_family: antismash
documentation_status: CURATED_PROSE
upstream_tasks:
- prokka
downstream_tasks:
- bigscape
- clinker
- manual BGC curation
parameter_guidance:
- '| Command/option | Meaning and setting rule |'
- '| `--taxon bacteria|fungi` | Required biological mode; do not infer fungi from filename alone. |'
- '| `--output-dir` | Empty/dedicated output directory for one assembly and configuration. |'
- '| `--output-basename` | Stable sample prefix used across generated artifacts. |'
- '| `--databases` | Explicit localized antiSMASH database root when it is not the package default. |'
- '| `--genefinding-tool prodigal` | Use for unannotated bacterial FASTA; prefer curated CDS in GenBank when available. |'
- '| `--minimal` | Detection-focused run with optional modules off; useful for fast screening. |'
- '| `--fullhmmer` | Whole-genome HMM annotation; enable when broader domain context is needed. |'
- '| `--clusterhmmer` | HMM annotation concentrated around detected regions. |'
- '| `--cb-general` | Compare regions with general cluster databases. |'
- '| `--cb-knownclusters` | Compare with characterized reference clusters; requires matching database content. |'
- '| `--cc-mibig` | MIBiG comparison module; similarity does not establish identical product. |'
- '| `--asf` | Active-site finder for supported biosynthetic domains. |'
- '| `--rre` | RiPP recognition element analysis for relevant clusters. |'
- '| `--pfam2go` | Attach Pfam-derived GO terms when database/module support is present. |'
- '| `--smcog-trees` | Build smCOG trees; computationally costly and mainly for detailed inspection. |'
- '| `--cpus` | CPU limit; keep module/database versions in provenance. |'
- '| `--skip-sanitisation` | Avoid unless a previously validated record fails normalization; it can preserve malformed annotations.
  |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# antiSMASH

Use antiSMASH for bacterial or fungal biosynthetic gene-cluster discovery. It is a specialized genome annotation stage, not a general functional annotator, and complete or high-quality assemblies give more defensible cluster boundaries than fragmented contigs.

## Capabilities and selection

antiSMASH combines detection rules for NRPS, PKS, RiPP and many other cluster types with optional domain, regulatory, resistance and reference-cluster analyses. The default analysis is suitable for screening; optional modules increase runtime and database requirements and should be enabled only when their output answers the research question.

## Inputs and upstream

Prefer a GenBank file with valid CDS features and translations from Bakta/Prokka, or provide genome FASTA and explicitly choose gene finding. Keep one organism/assembly per run and set bacterial versus fungal taxon correctly. Bind a database prepared for the installed major release under `Database/antismash/`.

## Outputs and downstream

Archive the top-level HTML, JSON, full annotated GenBank, per-region GenBank files and logs. Region GenBank files can feed BiG-SCAPE or clinker; domain/protein IDs can feed HMMER and manual curation. Treat predicted product classes and similarity as hypotheses, not proof of compound production.

## Parameters and decision rules

| Command/option | Meaning and setting rule |
| --- | --- |
| `--taxon bacteria|fungi` | Required biological mode; do not infer fungi from filename alone. |
| `--output-dir` | Empty/dedicated output directory for one assembly and configuration. |
| `--output-basename` | Stable sample prefix used across generated artifacts. |
| `--databases` | Explicit localized antiSMASH database root when it is not the package default. |
| `--genefinding-tool prodigal` | Use for unannotated bacterial FASTA; prefer curated CDS in GenBank when available. |
| `--minimal` | Detection-focused run with optional modules off; useful for fast screening. |
| `--fullhmmer` | Whole-genome HMM annotation; enable when broader domain context is needed. |
| `--clusterhmmer` | HMM annotation concentrated around detected regions. |
| `--cb-general` | Compare regions with general cluster databases. |
| `--cb-knownclusters` | Compare with characterized reference clusters; requires matching database content. |
| `--cc-mibig` | MIBiG comparison module; similarity does not establish identical product. |
| `--asf` | Active-site finder for supported biosynthetic domains. |
| `--rre` | RiPP recognition element analysis for relevant clusters. |
| `--pfam2go` | Attach Pfam-derived GO terms when database/module support is present. |
| `--smcog-trees` | Build smCOG trees; computationally costly and mainly for detailed inspection. |
| `--cpus` | CPU limit; keep module/database versions in provenance. |
| `--skip-sanitisation` | Avoid unless a previously validated record fails normalization; it can preserve malformed annotations. |

## Workflow patterns

```bash
conda run -n biomni-antismash --no-capture-output antismash genome.gbk \
  --taxon bacteria --databases Database/antismash --output-dir antismash_out \
  --output-basename sample --cb-knownclusters --cc-mibig --clusterhmmer --cpus 16
```

## Validation and failure handling

Before a full run, execute `antismash --check-prereqs --databases Database/antismash`. Require a successful completion message, parseable JSON/GenBank and intact region coordinates. Database-version or prerequisite failures block analysis and must be repaired through the database/environment instructions. Apparent clusters at contig edges should be marked truncated; do not compare their boundaries as complete loci.
