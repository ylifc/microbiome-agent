---
name: ABRicate
description: Screening assembled contigs for antimicrobial-resistance and virulence loci.
kind: software
id: abricate
version: 2
environment: bioinfo-abricate
executables:
- abricate
packages:
- abricate
channels:
- conda-forge
- bioconda
tasks:
- AMR gene screening requiring a prepared reference
- virulence gene screening requiring a prepared reference
databases: []
aliases:
- ABRicate
- AMR screening
- 耐药基因筛查
- 毒力基因筛查
keywords:
- AMR
- resistance
- virulence
- contigs
- BLAST
- card
- resfinder
- vfdb
- 耐药
capabilities:
- assembled-contig screening against ABRicate-formatted gene databases
- tabular hit summarization across samples
inputs:
- assembled nucleotide FASTA
- an explicitly prepared ABRicate database with recorded version
outputs:
- per-hit TSV with identity and coverage
- multi-sample summary matrix
upstream:
- megahit
- spades
- metabat2
- maxbin2
- concoct
downstream: []
software_family: abricate
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Parameter | Meaning and setting rule |'
- '| `--list` | Inspect available database names, sequence counts, and dates before selecting one. |'
- '| `--db NAME` | Choose exactly one prepared database for a run. Run separate commands for distinct evidence sources. |'
- '| `--datadir DIR` | Use an alternate prepared ABRicate database root. It must follow ABRicate layout and remain under a
  registered database resource. |'
- '| `--minid FLOAT` | Minimum nucleotide identity percentage. Higher values are specific but can miss divergent alleles.
  |'
- '| `--mincov FLOAT` | Minimum reference-gene coverage percentage. Lower values admit fragments; report partial hits explicitly.
  |'
- '| `--threads INT` | Search threads within allocated resources. |'
- '| `--nopath` | Suppress input directory in sample/file labels; useful for clean summaries but retain a separate provenance
  map. |'
- '| `--quiet` | Reduce messages only in stable runs; capture stderr during development. |'
- '| `--debug` | Diagnostic output for database/index/search failures. |'
- '| `--setupdb` | Builds indexes for already prepared database files. Treat as database localization before analysis, never
  an implicit download/update. |'
- '| `abricate --summary FILES...` | Aggregate completed per-sample TSVs. Use consistent database and thresholds or keep runs
  separated. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# ABRicate

Do not assume an environment-bundled database is current. The plan must name a separately validated database resource and record the selected ABRicate database.

```bash
conda run -n bioinfo-abricate --no-capture-output abricate --list
conda run -n bioinfo-abricate --no-capture-output abricate --db card assembly.fasta > abricate.tsv
```

Record database name and version, then review coverage, identity, contig coordinates, and duplicate hits.

## Capabilities and selection

ABRicate screens assembled nucleotide sequences against BLAST-formatted gene collections and reports locus-level coverage and identity. Typical database themes include AMR, virulence, and plasmid genes. It is fast for presence/absence screening but does not apply CARD model logic, infer phenotype, resolve gene expression, or reliably distinguish chromosomal/plasmid context without additional evidence.

Use ABRicate on isolate assemblies or MAG/contig FASTA when a specific, versioned ABRicate-format database is available. Prefer RGI for CARD ontology/model-aware resistance interpretation. Any missing database preparation requires its own Skill and a marked acquisition proposal in the confirmed plan.

## Inputs and upstream

Input FASTA comes from SPAdes/MEGAHIT or selected bins. Very fragmented contigs can produce partial hits. The selected database must appear in `abricate --list` with recorded sequence count/date or be supplied through a validated `--datadir`. Environment-bundled databases are not assumed current merely because the executable is READY.

## Outputs and downstream

Per-hit TSV includes file, sequence, start/end, strand, gene, coverage, identity, database, accession, and product fields depending on release. `abricate --summary` combines multiple TSVs into a sample-by-gene overview. Downstream interpretation should retain individual hits, thresholds, database release, and assembly quality rather than only a binary matrix.

## Parameters and decision rules

| Parameter | Meaning and setting rule |
| --- | --- |
| `--list` | Inspect available database names, sequence counts, and dates before selecting one. |
| `--db NAME` | Choose exactly one prepared database for a run. Run separate commands for distinct evidence sources. |
| `--datadir DIR` | Use an alternate prepared ABRicate database root. It must follow ABRicate layout and remain under a registered database resource. |
| `--minid FLOAT` | Minimum nucleotide identity percentage. Higher values are specific but can miss divergent alleles. |
| `--mincov FLOAT` | Minimum reference-gene coverage percentage. Lower values admit fragments; report partial hits explicitly. |
| `--threads INT` | Search threads within allocated resources. |
| `--nopath` | Suppress input directory in sample/file labels; useful for clean summaries but retain a separate provenance map. |
| `--quiet` | Reduce messages only in stable runs; capture stderr during development. |
| `--debug` | Diagnostic output for database/index/search failures. |
| `--setupdb` | Builds indexes for already prepared database files. Treat as database localization before analysis, never an implicit download/update. |
| `abricate --summary FILES...` | Aggregate completed per-sample TSVs. Use consistent database and thresholds or keep runs separated. |

## Workflow patterns

```bash
conda run -n bioinfo-abricate --no-capture-output abricate --list
conda run -n bioinfo-abricate --no-capture-output bash -lc \
  "abricate --db card --minid 80 --mincov 60 --threads 8 assembly.fasta > sample.card.tsv"
conda run -n bioinfo-abricate --no-capture-output bash -lc \
  "abricate --summary *.card.tsv > card.summary.tsv"
```

Do not compare hits generated from different database releases or thresholds as if directly equivalent. Confirm whether partial genes are biologically/reporting relevant.

## Validation and failure handling

Check `--list`, database sequence count/date, TSV header, assembly input count, hit count, identity/coverage distributions, duplicate/overlapping hits, and sample labels. A zero-hit result can be valid but first test database readiness and a known sequence. `No databases found` or BLAST index errors require database preparation outside execution. High numbers of fragmented hits can indicate fragmented/contaminated assembly or thresholds too permissive.
