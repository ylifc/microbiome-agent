---
name: BCFtools
description: Variant calling, normalization, filtering, querying, and VCF/BCF manipulation.
kind: software
id: bcftools
version: 2
environment: microbiome
executables:
- bcftools
packages:
- bcftools
channels:
- conda-forge
- bioconda
tasks:
- variant calling
- VCF filtering
- variant normalization
- genotype querying
databases: []
aliases:
- BCFtools
- variant caller
- VCF tools
- 变异检测
keywords:
- VCF
- BCF
- mpileup
- call
- norm
- filter
- consensus
- variants
- SNP
- indel
- 变异
capabilities:
- pileup-based small-variant calling
- VCF or BCF normalization and filtering
- sample and region queries
- consensus generation
inputs:
- coordinate-sorted indexed BAM or CRAM
- exact indexed reference FASTA
- VCF or BCF for post-processing
outputs:
- VCF or BCF plus index
- query tables
- statistics
- consensus FASTA
upstream:
- bwa
- bowtie2
- samtools
downstream:
- mafft
- iqtree2
- iqtree3
- treetime
software_family: bcftools
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Command/parameter | Meaning and setting rule |'
- '| `mpileup -f REF` | Exact reference FASTA. Keep `.fai` and contig names identical to BAM. |'
- '| `mpileup -Ou` | Uncompressed BCF stream for piping to `call`; avoids intermediate conversion. |'
- '| `mpileup -q`, `-Q` | Minimum mapping and base quality. Tune to mapper/platform and report thresholds. |'
- '| `mpileup -d` | Maximum per-file depth. Ensure it does not silently cap high-depth viral/amplicon data. |'
- '| `mpileup -a FORMAT/DP,AD,...` | Add annotation fields needed for depth/allele-fraction filtering. |'
- '| `-r` / `-R` | Restrict regions directly or from file. Requires indexed inputs and correct coordinate semantics. |'
- '| `call -m` | Multiallelic calling model, common for general germline/sample calls. |'
- '| `call -c` | Legacy consensus caller; use only for a workflow designed around it. |'
- '| `call -v` | Emit variant sites only. Omit when reference-site likelihoods are needed. |'
- '| `--ploidy` / ploidy file | Set organism/region ploidy. Haploid microbes should not inherit diploid assumptions. |'
- '| `-Oz`, `-Ob`, `-Ou` | Compressed VCF, BCF, or uncompressed BCF stream. Match downstream/index needs. |'
- '| `norm -f REF` | Left-align/normalize alleles against reference. Reference mismatches are provenance errors. |'
- '| `norm -m -any` | Split multiallelic records; use `+any` to join only when semantics permit. |'
- '| `norm -a --atomize` | Decompose complex variants as supported; record transformation. |'
- '| `view -i/-e EXPR` | Include/exclude records by expressions; distinguish site-level INFO from sample FORMAT fields. |'
- '| `view -m/-M`, `-v` | Filter allele count and variant type. |'
- '| `filter -s NAME`, `-i/-e` | Soft-label failed records instead of dropping; preferable for auditable filtering. |'
- '| `query -f FORMAT` | Export fields with explicit sample loops/brackets; test format on a few records. |'
- '| `index -t` / `-c` | Tabix for VCF.gz or CSI for BCF/large coordinates. Index after final content changes. |'
- '| `consensus -f`, `-s`, `-H` | Apply selected sample/haplotype variants to reference. Define heterozygous/haploid handling
  and masking. |'
- '| `stats` | Produce variant/QC summary; compare before and after filters. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# BCFtools

Use the same reference FASTA for alignment, pileup, calling, and normalization.

```bash
conda run -n microbiome --no-capture-output bcftools mpileup -Ou -f reference.fasta sample.sorted.bam
conda run -n microbiome --no-capture-output bcftools norm -f reference.fasta -m -any calls.vcf.gz -Oz -o calls.norm.vcf.gz
```

When piping commands, keep every stage inside the declared environment and inspect sample names, contigs, filters, and index files.

## Capabilities and selection

BCFtools creates genotype likelihoods from BAM/CRAM, calls small variants, normalizes/filter/query VCF/BCF, computes statistics, and applies variants to references. It is not a mapper and does not by itself establish a validated somatic, polyploid, or low-frequency viral calling model. Ploidy, sample design, depth, error profile, and filtering must be explicit.

## Inputs and upstream

`mpileup` requires coordinate-sorted indexed BAM/CRAM from BWA/Bowtie 2 plus SAMtools and the exact indexed reference FASTA used for alignment. Post-processing commands require valid VCF/BCF with compatible contig dictionaries. Sample names come from read groups/header and must be checked before multi-sample calling.

## Outputs and downstream

VCF/BCF plus tabix/CSI indexes feed annotation, consensus generation, epidemiological summaries, or sequence reconstruction. Consensus FASTA can feed MAFFT and IQ-TREE/TreeTime, but only after masking/quality rules prevent uncertain positions from becoming false substitutions. `stats` and `query` outputs support QC/reporting.

## Parameters and decision rules

| Command/parameter | Meaning and setting rule |
| --- | --- |
| `mpileup -f REF` | Exact reference FASTA. Keep `.fai` and contig names identical to BAM. |
| `mpileup -Ou` | Uncompressed BCF stream for piping to `call`; avoids intermediate conversion. |
| `mpileup -q`, `-Q` | Minimum mapping and base quality. Tune to mapper/platform and report thresholds. |
| `mpileup -d` | Maximum per-file depth. Ensure it does not silently cap high-depth viral/amplicon data. |
| `mpileup -a FORMAT/DP,AD,...` | Add annotation fields needed for depth/allele-fraction filtering. |
| `-r` / `-R` | Restrict regions directly or from file. Requires indexed inputs and correct coordinate semantics. |
| `call -m` | Multiallelic calling model, common for general germline/sample calls. |
| `call -c` | Legacy consensus caller; use only for a workflow designed around it. |
| `call -v` | Emit variant sites only. Omit when reference-site likelihoods are needed. |
| `--ploidy` / ploidy file | Set organism/region ploidy. Haploid microbes should not inherit diploid assumptions. |
| `-Oz`, `-Ob`, `-Ou` | Compressed VCF, BCF, or uncompressed BCF stream. Match downstream/index needs. |
| `norm -f REF` | Left-align/normalize alleles against reference. Reference mismatches are provenance errors. |
| `norm -m -any` | Split multiallelic records; use `+any` to join only when semantics permit. |
| `norm -a --atomize` | Decompose complex variants as supported; record transformation. |
| `view -i/-e EXPR` | Include/exclude records by expressions; distinguish site-level INFO from sample FORMAT fields. |
| `view -m/-M`, `-v` | Filter allele count and variant type. |
| `filter -s NAME`, `-i/-e` | Soft-label failed records instead of dropping; preferable for auditable filtering. |
| `query -f FORMAT` | Export fields with explicit sample loops/brackets; test format on a few records. |
| `index -t` / `-c` | Tabix for VCF.gz or CSI for BCF/large coordinates. Index after final content changes. |
| `consensus -f`, `-s`, `-H` | Apply selected sample/haplotype variants to reference. Define heterozygous/haploid handling and masking. |
| `stats` | Produce variant/QC summary; compare before and after filters. |

## Workflow patterns

```bash
conda run -n microbiome --no-capture-output bash -lc \
  "set -o pipefail; bcftools mpileup -Ou -f reference.fasta -q 20 -Q 20 -a FORMAT/DP,AD sample.sorted.bam | \
   bcftools call -mv --ploidy 1 -Oz -o raw.vcf.gz"
conda run -n microbiome --no-capture-output bcftools norm \
  -f reference.fasta -m -any raw.vcf.gz -Oz -o norm.vcf.gz
conda run -n microbiome --no-capture-output bcftools index -t norm.vcf.gz
conda run -n microbiome --no-capture-output bcftools stats norm.vcf.gz > norm.stats.txt
```

For viral consensus, define minimum depth, allele fraction, strand/bias behavior, and low-coverage masking before `consensus`. Do not use a generic haploid call as a validated minority-variant workflow.

## Validation and failure handling

Check sample names, reference/contig dictionaries, depth distributions, transition/transversion and variant-type counts, QUAL/filter distributions, missing genotypes, and normalization stability. Reference mismatch errors must be fixed by locating the exact reference, not by unsafe check-ref skipping. Empty calls can be biologically valid but also result from ploidy, thresholds, wrong BAM/reference, or depth caps. In pipelines use `set -o pipefail` so upstream failures are not hidden by a successful final command.
