---
name: QUAST and metaQUAST
description: Reference-aware or reference-free quality assessment and comparison of genome and metagenome assemblies.
kind: software
id: quast
version: 2
selection_tier: default
environment: biomni-quast
executables:
- quast.py
- metaquast.py
packages:
- quast
channels:
- conda-forge
- bioconda
tasks:
- genome assembly quality assessment
- metagenome assembly comparison
- misassembly detection
databases: []
aliases:
- QUAST
- metaQUAST
- assembly QC
- 组装质量评估
keywords:
- N50
- NGA50
- misassembly
- genome fraction
- contigs
- reference
- assembly report
- 组装质控
capabilities:
- compute contiguity statistics
- compare assemblies
- detect reference-relative errors
- evaluate metagenome assemblies
inputs:
- one or more assembly FASTA files
- optional trusted reference FASTA and GFF/GTF/BED feature annotations
outputs:
- report.tsv report.txt report.html
- aligned and unaligned statistics
- optional plots and misassembly details
upstream:
- spades
- megahit
- flye
downstream:
- bakta
- skani
- panaroo
- snippy
- metabat2
- semibin2
software_family: quast
documentation_status: CURATED_PROSE
parameter_guidance:
- '| assembly positional arguments | Compare outputs only when generated from the same sample/read set and preprocessing.
  |'
- '| `-r` | Trusted reference; omit rather than using a distant reference that distorts error metrics. |'
- '| `-g`, `--features` | Reference gene/feature annotations in supported formats and matching coordinates (`-G` is deprecated).
  |'
- '| `-o`, `-t` | Isolated output directory and bounded threads. |'
- '| `--labels` | Stable labels corresponding one-to-one with assemblies. |'
- '| `--min-contig` | Reporting threshold; retain raw assembly separately and disclose filtering. |'
- '| `--large`, `--eukaryote` | Adapt assumptions for large/eukaryotic genomes, not bacteria. |'
- '| `--fragmented` | Use when the reference is intentionally fragmented. |'
- '| `--gene-finding`, `--conserved-genes-finding` | Optional gene metrics; dedicated annotation/completeness tools remain
  authoritative. |'
- '| `metaquast.py` | Use for mixed communities; reference download/discovery must be a separate confirmed preparation task.
  |'
- For multiple assemblies, keep identical `--min-contig`, reference and feature settings so report columns remain comparable.
- Reference-free N50 and contig counts measure continuity, not correctness. Pair them with read mapping, coverage, contamination/completeness,
  and reference-based misassembly evidence where appropriate.
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# QUAST and metaQUAST

Run QUAST after every assembly. A high N50 alone is not evidence of correctness; use reference-relative metrics only when the reference is sufficiently close and appropriate.

## Capabilities and selection

`quast.py` evaluates isolate/eukaryotic assemblies and can compare multiple FASTA files. `metaquast.py` handles metagenomic assemblies and multiple references. Without a reference, report contiguity/composition only and do not claim misassembly or genome fraction.

## Inputs and upstream

Assemblies come from SPAdes, MEGAHIT, Flye, or alternatives and must have unique stable contig IDs. Optional reference FASTA must match expected organism/ploidy and be documented by accession/version. GFF/GTF/BED features must use the same reference coordinates.

## Outputs and downstream

Use `report.tsv` as the machine-readable summary and retain HTML/text reports, plots, and detailed output. Accepted assemblies feed Bakta, skani, Snippy reference selection, pangenome analysis, or metagenomic binning. QUAST does not choose biological thresholds automatically.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| assembly positional arguments | Compare outputs only when generated from the same sample/read set and preprocessing. |
| `-r` | Trusted reference; omit rather than using a distant reference that distorts error metrics. |
| `-g`, `--features` | Reference gene/feature annotations in supported formats and matching coordinates (`-G` is deprecated). |
| `-o`, `-t` | Isolated output directory and bounded threads. |
| `--labels` | Stable labels corresponding one-to-one with assemblies. |
| `--min-contig` | Reporting threshold; retain raw assembly separately and disclose filtering. |
| `--large`, `--eukaryote` | Adapt assumptions for large/eukaryotic genomes, not bacteria. |
| `--fragmented` | Use when the reference is intentionally fragmented. |
| `--gene-finding`, `--conserved-genes-finding` | Optional gene metrics; dedicated annotation/completeness tools remain authoritative. |
| `metaquast.py` | Use for mixed communities; reference download/discovery must be a separate confirmed preparation task. |

For multiple assemblies, keep identical `--min-contig`, reference and feature settings so report columns remain comparable.

Reference-free N50 and contig counts measure continuity, not correctness. Pair them with read mapping, coverage, contamination/completeness, and reference-based misassembly evidence where appropriate.

## Workflow patterns

```bash
conda run -n biomni-quast --no-capture-output quast.py \
  spades/contigs.fasta flye/assembly.fasta \
  --labels spades,flye -r reference.fasta -o quast_compare -t 8
```

## Validation and failure handling

Require parseable reports, every assembly represented, plausible total length/GC/contig counts, and clear separation of reference-free and reference-based metrics. Zero genome fraction or excessive misassemblies may indicate wrong/distant reference, contamination, haplotype/strain mixture, or real assembly errors. Missing alignments require checking reference/assembly alphabets and dependencies before changing thresholds.
