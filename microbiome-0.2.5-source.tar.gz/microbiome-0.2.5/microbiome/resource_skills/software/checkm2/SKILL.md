---
name: CheckM2
description: Machine-learning completeness and contamination assessment for MAGs, SAGs, and isolate genomes.
kind: software
id: checkm2
version: 2
selection_tier: default
environment: biomni-checkm2
executables:
- checkm2
packages:
- checkm2
channels:
- conda-forge
- bioconda
tasks:
- MAG quality assessment
- genome completeness estimation
- contamination estimation
databases:
- checkm2
aliases:
- CheckM2
- MAG quality
- 基因组完整度
- MAG质量评估
keywords:
- MAG
- SAG
- completeness
- contamination
- machine learning
- low memory
- quality_report.tsv
capabilities:
- predict genome completeness and contamination across lineages
- handle unusual/reduced genomes
- run built-in validation test
inputs:
- directory/list of genome FASTA or predicted protein FASTA
- READY CheckM2 DIAMOND database
outputs:
- quality_report.tsv
- protein/DIAMOND intermediates and logs depending on retention settings
upstream:
- metabat2
- semibin2
- dastool
- maxbin2
- concoct
- flye
downstream:
- gunc
- drep
- gtdbtk
- bakta
software_family: checkm2
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Command/option | Meaning and setting rule |'
- '| `checkm2 predict` | Main quality prediction mode. |'
- '| `--input` | Directory or file list; ensure one genome per file. |'
- '| `--output-directory` | New output directory. |'
- '| `--database_path` | Explicit compatible database under `Database/checkm2/`. |'
- '| `--threads` | Bound CPU used by annotation/prediction. |'
- '| `--extension` | Required when directory files use non-default/gzip extension. |'
- '| `--genes` | Treat input as predicted proteins, ideally consistently generated with Prodigal. |'
- '| `--lowmem` | Reduce DIAMOND memory at runtime cost on constrained hosts. |'
- '| `--tmpdir` | Put temporary files on adequate local storage. |'
- '| `--resume` | Resume only with identical input/database/settings. |'
- '| `--force` | Replace output only after preserving prior provenance. |'
- '| `--remove_intermediates` | Save disk after a validated run; retain intermediates while debugging. |'
- '| `checkm2 testrun` | Mandatory readiness test after environment/database setup. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# CheckM2

Use CheckM2 as the default new MAG/SAG quality estimator. Keep CheckM1 for historical reproducibility and marker-set cross-checks, especially when methods must match earlier work.

## Capabilities and selection

CheckM2 applies universal machine-learning models and automatically selects between general/specific completeness predictions. It can handle novel or reduced lineages better than a strict lineage-marker workflow in many cases. Quality estimates remain predictions and should be paired with GUNC, assembly statistics, coverage, and taxonomy.

## Inputs and upstream

Provide one genome per FASTA file with stable unique filenames, or use `--genes` for precomputed protein inputs. Do not include unbinned contigs or mixed multi-genome FASTA as one bin. Bind a version-compatible local CheckM2 database.

## Outputs and downstream

`quality_report.tsv` reports completeness, contamination, model choice, coding density and related features by version. Filtered candidate MAGs feed GUNC, dRep, GTDB-Tk, and Bakta. Retain raw report for all bins, including failed thresholds, to avoid selection bias.

## Parameters and decision rules

| Command/option | Meaning and setting rule |
| --- | --- |
| `checkm2 predict` | Main quality prediction mode. |
| `--input` | Directory or file list; ensure one genome per file. |
| `--output-directory` | New output directory. |
| `--database_path` | Explicit compatible database under `Database/checkm2/`. |
| `--threads` | Bound CPU used by annotation/prediction. |
| `--extension` | Required when directory files use non-default/gzip extension. |
| `--genes` | Treat input as predicted proteins, ideally consistently generated with Prodigal. |
| `--lowmem` | Reduce DIAMOND memory at runtime cost on constrained hosts. |
| `--tmpdir` | Put temporary files on adequate local storage. |
| `--resume` | Resume only with identical input/database/settings. |
| `--force` | Replace output only after preserving prior provenance. |
| `--remove_intermediates` | Save disk after a validated run; retain intermediates while debugging. |
| `checkm2 testrun` | Mandatory readiness test after environment/database setup. |

## Workflow patterns

```bash
conda run -n biomni-checkm2 --no-capture-output checkm2 testrun --database_path Database/checkm2/uniref100.KO.1.dmnd
conda run -n biomni-checkm2 --no-capture-output checkm2 predict \
  --input bins --output-directory checkm2_out \
  --database_path Database/checkm2/uniref100.KO.1.dmnd --threads 16
```

## Validation and failure handling

Require passing `testrun`, all input bins represented exactly once, parseable report, plausible completeness/contamination/coding density, and explicit handling of missing/failed bins. Database key/version errors mean incompatible or incomplete localization. Divergence between CheckM2 and CheckM1/GUNC is evidence for review, not permission to choose the more favorable score.
