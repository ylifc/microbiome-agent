---
name: VSEARCH
description: Fast open-source toolkit for amplicon dereplication, chimera detection, OTU clustering, and rRNA/reference searches.
kind: software
id: vsearch
version: 2
selection_tier: conditional
environment: biomni-vsearch
executables:
- vsearch
packages:
- vsearch
channels:
- conda-forge
- bioconda
tasks:
- amplicon dereplication and chimera removal
- de novo and closed-reference OTU clustering
- rRNA gene extraction from genomes
- pairwise and reference sequence search
databases:
- silva
- unite
aliases:
- VSEARCH
- vsearch
- OTU 聚类
- 嵌合体去除
- 去冗余
keywords:
- amplicon
- dereplication
- chimera
- OTU
- ASV
- clustering
- rRNA
- 扩增子
- 聚类
capabilities:
- dereplicate full-length or prefix sequences
- cluster OTUs at a chosen identity
- detect chimeras against a reference or de novo
- search against a database
- sort and filter FASTA/FASTQ
inputs:
- amplicon FASTA/FASTQ
- optional chimera or taxonomy reference database
outputs:
- dereplicated sequences
- OTU representatives and mapping table
- chimera-free sequences
- search/alignment tables
upstream:
- dada2
- cutadapt
- qiime2
downstream:
- mafft
- fasttree
software_family: vsearch
documentation_status: CURATED_PROSE
downstream_tasks:
- taxonomy assignment
- diversity analysis
parameter_guidance:
- '| `--derep_fulllength` / `--derep_prefix` | Full-length or prefix dereplication; full-length for exact ASV-style uniques.
  |'
- '| `--sizeout` | Preserve cluster sizes in headers (abundance). |'
- '| `--cluster_otus` | Greedy OTU clustering (commonly `--id 0.97`); use `--id 1.0` for exact uniques. |'
- '| `--uchime_ref` / `--uchime_denovo` | Reference or de novo chimera removal; require a matching reference for the former.
  |'
- '| `--usearch_global` / `--search_exact` | Database search with identity threshold or exact matching. |'
- '| `--id` | Identity cutoff; region-appropriate (97% for species-level OTUs, lower for genus-level). |'
- '| `--threads` | Threads. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# VSEARCH

Use VSEARCH for classic OTU-based amplicon processing and for extracting rRNA genes from genomes/metagenomes. It complements DADA2/QIIME 2 ASV pipelines when a 97%-identity OTU view or a fast reference search is needed.

```bash
# Dereplicate, sort by abundance, remove chimeras against SILVA, then cluster OTUs
conda run -n biomni-vsearch --no-capture-output vsearch --derep_fulllength merged.fa --output uniques.fa --sizeout
conda run -n biomni-vsearch --no-capture-output vsearch --sortbysize uniques.fa --output sorted.fa
conda run -n biomni-vsearch --no-capture-output vsearch --uchime_ref sorted.fa --db silva_16s.fa --nonchimeras nonchim.fa
conda run -n biomni-vsearch --no-capture-output vsearch --cluster_otus nonchim.fa --otus otus.fa --relabel OTU --id 0.97

# Extract near-full-length 16S from a genome by searching a reference set
conda run -n biomni-vsearch --no-capture-output vsearch --usearch_global genome.fa --db ref16s.fa --id 0.8 --maxaccepts 1 --blast6out rrna_hits.tsv
```

## Capabilities and selection

VSEARCH provides deterministic dereplication, size sorting, OTU clustering (`--cluster_otus`, `--cluster_fast`, `--cluster_size`), reference and de novo chimera removal (`--uchime_ref`, `--uchime_denovo`), and sequence search (`--usearch_global`, `--search_exact`). It is memory-efficient and suited to large amplicon datasets.

Prefer DADA2/QIIME 2 for exact ASV/denoising pipelines; add VSEARCH for OTU clustering, reference chimera screening against SILVA/UNITE, or high-throughput genome rRNA extraction. Do not stack ASV and OTU approaches into the same primary result without an explicit comparison goal.

## Inputs and upstream

Inputs are merged amplicon FASTA/FASTQ (after cutadapt primer removal and DADA2 denoising when appropriate). Chimera reference databases must match the target region (e.g., SILVA for 16S/18S, UNITE for ITS). Genome extraction uses a curated reference rRNA set and an identity threshold appropriate to the domain.

## Outputs and downstream

Outputs include unique/sorted FASTA, non-chimeric sequences, OTU representatives plus a mapping table, and search tables. Representatives feed alignment (MAFFT), tree building (FastTree/IQ-TREE), taxonomy assignment, and diversity analysis. Preserve dereplication counts so abundance is not lost.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `--derep_fulllength` / `--derep_prefix` | Full-length or prefix dereplication; full-length for exact ASV-style uniques. |
| `--sizeout` | Preserve cluster sizes in headers (abundance). |
| `--cluster_otus` | Greedy OTU clustering (commonly `--id 0.97`); use `--id 1.0` for exact uniques. |
| `--uchime_ref` / `--uchime_denovo` | Reference or de novo chimera removal; require a matching reference for the former. |
| `--usearch_global` / `--search_exact` | Database search with identity threshold or exact matching. |
| `--id` | Identity cutoff; region-appropriate (97% for species-level OTUs, lower for genus-level). |
| `--threads` | Threads. |

## Workflow patterns

Dereplicate, sort by abundance, remove chimeras against a region-matched reference, and cluster OTUs; then map reads back to build an OTU table and proceed to MAFFT/FastTree and taxonomy assignment.

```bash
conda run -n biomni-vsearch --no-capture-output vsearch --derep_fulllength merged.fa --output uniques.fa --sizeout
conda run -n biomni-vsearch --no-capture-output vsearch --sortbysize uniques.fa --output sorted.fa
conda run -n biomni-vsearch --no-capture-output vsearch --uchime_ref sorted.fa --db silva_16s.fa --nonchimeras nonchim.fa
```

## Validation and failure handling

Record retention after each step (dereplication, chimera removal, clustering) and the exact identity cutoffs. A sudden collapse of sequence count usually means over-aggressive chimera filtering, wrong region reference, or double-dereplication. Keep unassigned/no-hit sequences visible rather than silently discarding them.
