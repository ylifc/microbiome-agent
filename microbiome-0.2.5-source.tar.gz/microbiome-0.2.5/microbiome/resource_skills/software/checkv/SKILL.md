---
name: CheckV
description: Quality assessment and host contamination trimming for viral contigs.
kind: software
id: checkv
version: 2
environment: microbiome
executables:
- checkv
packages:
- checkv
channels:
- conda-forge
- bioconda
tasks:
- viral genome quality assessment
databases:
- checkv
aliases:
- CheckV
- viral quality
- 病毒完整度
- 病毒污染修剪
keywords:
- virus
- completeness
- contamination
- provirus
- host boundary
- quality
- 病毒
- 完整性
- 病毒质量
capabilities:
- viral genome completeness estimation
- host contamination detection and trimming
- closed-genome and provirus quality reporting
inputs:
- viral or proviral nucleotide FASTA
- READY CheckV database
outputs:
- quality summary TSV
- contamination TSV
- completeness TSV
- provirus TSV
- trimmed virus FASTA
upstream:
- genomad
- pvga
- megahit
- spades
downstream: []
software_family: checkv
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Parameter | Meaning and setting rule |'
- '| `checkv end_to_end INPUT OUTPUT` | Run contamination, completeness, complete-genome, and summary stages. |'
- '| `-d PATH` | Explicit READY reference database. Prefer over implicit environment state for provenance. |'
- '| `-t INT` | Threads. Installed default may be 256, so always specify allocated CPUs. |'
- '| `--remove_tmp` | Remove intermediates after success. Omit when troubleshooting or reusing module outputs. |'
- '| `--restart` | Overwrite existing intermediate files; default can continue an interrupted compatible run. |'
- '| `--quiet` | Suppress logging only after pipeline behavior is established. |'
- '| `--conservative-trimming` | Identify fewer host regions, retaining more sequence and potentially more contamination.
  |'
- '| `--aggressive-trimming` | Identify more host regions, risking removal of genuine viral sequence. Compare evidence before
  use. |'
- '| `contamination` module | Detect host-virus boundaries and produce proviral/trim evidence. |'
- '| `completeness` module | Estimate completeness from reference or gene-content evidence. Some novel viruses remain NA.
  |'
- '| `complete_genomes` module | Detect terminal repeats/integrated provirus signals for closed-genome evidence. |'
- '| `quality_summary` module | Integrate prior module outputs. Inputs must come from the same run/database. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# CheckV

Use after viral-contig identification. Pass `Database/checkv/checkv-db-v1.5` as the database or set `CHECKVDB` for the isolated command.

Run through `conda run -n microbiome`. Validate `quality_summary.tsv` and report the number of complete/high-quality viral genomes.

## Capabilities and selection

CheckV estimates viral genome completeness, detects/removes host contamination, identifies proviruses and closed genomes, and assigns quality categories using reference/provirus and gene-content evidence. It is intended for viral candidates, not bacterial MAG completeness. Estimates can be unavailable or uncertain for highly novel viruses.

Use after geNomad/PVGA or another defensible viral-identification step. Keep original sequences because trimming changes coordinates and sequence length. Run end-to-end for standard analysis or individual contamination/completeness/complete-genomes/quality-summary modules for controlled reanalysis.

## Inputs and upstream

Input is nucleotide FASTA containing viral contigs or proviral regions. IDs must match geNomad/PVGA records. `-d` points to the READY CheckV release, normally `Database/checkv/checkv-db-v1.5`, or the same path is set as `CHECKVDB` inside `conda run`. Do not provide whole mixed assemblies without a viral-candidate selection rationale.

## Outputs and downstream

`quality_summary.tsv` integrates quality, completeness method/value, contamination, provirus, and warnings. `contamination.tsv`, `completeness.tsv`, `complete_genomes.tsv`, `proviruses.fna`, and `viruses.fna`/trimmed outputs depend on version/modules. Trimmed viral FASTA can feed gene annotation, clustering, taxonomy, read mapping, and phylogenetics, while coordinate mappings preserve the original context.

## Parameters and decision rules

| Parameter | Meaning and setting rule |
| --- | --- |
| `checkv end_to_end INPUT OUTPUT` | Run contamination, completeness, complete-genome, and summary stages. |
| `-d PATH` | Explicit READY reference database. Prefer over implicit environment state for provenance. |
| `-t INT` | Threads. Installed default may be 256, so always specify allocated CPUs. |
| `--remove_tmp` | Remove intermediates after success. Omit when troubleshooting or reusing module outputs. |
| `--restart` | Overwrite existing intermediate files; default can continue an interrupted compatible run. |
| `--quiet` | Suppress logging only after pipeline behavior is established. |
| `--conservative-trimming` | Identify fewer host regions, retaining more sequence and potentially more contamination. |
| `--aggressive-trimming` | Identify more host regions, risking removal of genuine viral sequence. Compare evidence before use. |
| `contamination` module | Detect host-virus boundaries and produce proviral/trim evidence. |
| `completeness` module | Estimate completeness from reference or gene-content evidence. Some novel viruses remain NA. |
| `complete_genomes` module | Detect terminal repeats/integrated provirus signals for closed-genome evidence. |
| `quality_summary` module | Integrate prior module outputs. Inputs must come from the same run/database. |

## Workflow patterns

```bash
conda run -n microbiome --no-capture-output checkv end_to_end \
  genomad_out/summary/virus.fna checkv_out \
  -d Database/checkv/checkv-db-v1.5 -t 16
```

Compare original versus trimmed coordinates/lengths. Report completeness method and confidence, not only the quality label. NA completeness is not zero and should not be converted to low quality automatically.

## Validation and failure handling

Require input/output ID reconciliation, parseable `quality_summary.tsv`, contamination coordinates within sequence, non-empty retained viruses, completeness method/value distinction, and counts by quality/warning. Database errors require local resource correction. No completeness estimate can reflect novelty or insufficient genes rather than failure. Aggressive trimming that removes most sequence calls for boundary review and conservative sensitivity analysis.
