---
name: FastQC
description: Per-sample sequence-quality diagnostics for raw or processed FASTQ files.
kind: software
id: fastqc
version: 2
selection_tier: conditional
environment: microbiome-fastqc
executables:
- fastqc
packages:
- fastqc
channels:
- conda-forge
- bioconda
tasks:
- FASTQ quality diagnostics
- adapter and overrepresented-sequence screening
- per-base quality review
databases: []
aliases:
- FastQC
- FASTQ QC
- 测序质量报告
keywords:
- FASTQ
- quality
- adapter
- duplication
- GC
- overrepresented sequence
- 质控
capabilities:
- HTML and zip QC reports
- module-level PASS WARN FAIL summaries
- raw versus cleaned read comparison
inputs:
- single-end or paired-end FASTQ optionally gzip-compressed
outputs:
- FastQC HTML report
- FastQC zip archive
- summary.txt and fastqc_data.txt
upstream:
- sra-toolkit
downstream:
- fastp
- multiqc
- spades
- megahit
- bowtie2
software_family: fastqc
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Option | Rule |'
- '| `--threads` | Bound to the approved CPU allocation. |'
- '| `--outdir` | New result directory, never a raw-data directory. |'
- '| `--extract`/`--noextract` | Keep ZIP by default; extract only when a parser requires it. |'
- '| `--contaminants` | Use only a reviewed contaminant definition file. |'
- '| `--adapters` | Use only a reviewed adapter definition file. |'
- Module flags are heuristics. Per-base sequence content often warns for amplicons and biased libraries without indicating
  failed sequencing.
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# FastQC

## Capabilities and selection

Use FastQC when detailed per-cycle/per-sequence diagnostic plots are needed. fastp remains the default short-read filtering tool; FastQC is complementary evidence, not a second trimming step. Select it for raw/cleaned comparisons or when cohort outliers require plots beyond fastp JSON.

## Inputs and upstream

Accept validated FASTQ/FASTQ.GZ. Paired files remain separate inputs and sample IDs must be unique. Record platform, read layout and whether reads have already been trimmed.

## Outputs and downstream

Preserve HTML and ZIP for every input; `summary.txt` and `fastqc_data.txt` are machine-readable validation evidence. MultiQC consumes these files without modifying reads.

## Parameters and decision rules

| Option | Rule |
| --- | --- |
| `--threads` | Bound to the approved CPU allocation. |
| `--outdir` | New result directory, never a raw-data directory. |
| `--extract`/`--noextract` | Keep ZIP by default; extract only when a parser requires it. |
| `--contaminants` | Use only a reviewed contaminant definition file. |
| `--adapters` | Use only a reviewed adapter definition file. |

Module flags are heuristics. Per-base sequence content often warns for amplicons and biased libraries without indicating failed sequencing.

## Workflow patterns

```bash
conda run -n microbiome-fastqc --no-capture-output fastqc --threads 8 --outdir qc sample_R1.fastq.gz sample_R2.fastq.gz
```

Plan FastQC before and, when useful, after filtering. Aggregate multiple samples with MultiQC and bind raw/clean report names unambiguously.

## Validation and failure handling

Validate that every input has exactly one report and inspect per-base quality, adapter content, sequence length, GC, duplication and overrepresented-sequence modules in biological context. A WARN/FAIL flag is evidence to investigate, not by itself permission to discard reads. Truncated input or Java memory failures block downstream use until the input or resource allocation is corrected.

## Reproducibility and audit

Record the FastQC version, the input FASTQ path, and the per-module outcomes for every sample. Re-run on a subsample and confirm the same per-base and per-sequence summaries to verify reproducibility. Treat adapter and overrepresented-sequence flags as hypotheses to confirm, not final calls.

```bash
# provenance: capture version
conda run -n microbiome-fastqc --no-capture-output fastqc --version
```
