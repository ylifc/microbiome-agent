---
name: NCBI Datasets CLI
description: Official structured retrieval of NCBI genome, gene, taxonomy, and virus data packages.
kind: software
id: ncbi-datasets
version: 3
selection_tier: default
environment: biomni-ncbi-datasets
executables:
- datasets
- dataformat
packages:
- ncbi-datasets-cli
channels:
- conda-forge
tasks:
- reference genome retrieval
- genome metadata query
- fuzzy species-name resolution
- taxonomy normalization
- virus reference retrieval
databases: []
optional_databases:
- reference-genomes
- virus-genomes
aliases:
- NCBI Datasets
- datasets CLI
- dataformat
- NCBI数据下载
keywords:
- NCBI
- accession
- TaxID
- RefSeq
- GenBank
- genome package
- JSONL
- 参考基因组
- 结构化下载
capabilities:
- query genome gene taxonomy and virus records
- resolve scientific common abbreviated and misspelled species names to reviewed TaxIDs
- download versioned NCBI data packages
- convert JSON Lines reports to TSV
inputs:
- NCBI assembly or gene accession
- TaxID or exact or approximate taxon name
- optional accession list file and structured filters
outputs:
- ZIP data package
- FASTA GFF3 GBFF protein files as requested
- data_report.jsonl
- dataset_catalog.json
- normalized TSV metadata
upstream: []
downstream:
- seqkit
- bakta
- skani
- panaroo
- snippy
- ncbi-blast
software_family: ncbi-datasets
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Command/option | Meaning and setting rule |'
- '| `datasets summary genome taxon|accession` | Inspect counts and metadata before downloading. |'
- '| `datasets summary taxonomy taxon` | Normalize an exact/common name or TaxID; fuzzy suggestions must be revalidated by
  TaxID before use. |'
- '| `datasets download genome accession` | Retrieve named assemblies; safest path for a fixed accession list. |'
- '| `datasets download genome taxon` | Taxon-wide retrieval; require TaxID and restrictive filters. |'
- '| `datasets download virus genome taxon\|accession` | Limited virus fallback; the installed CLI supports completeness,
  host and lower release-date filtering, but gget is required for upper-date and sequence-length filters. |'
- '| `--inputfile` | Read accessions from a reviewed file; keep this file as provenance. |'
- '| `--assembly-level` | Restrict to complete/chromosome/scaffold/contig as scientifically appropriate. |'
- '| `--reference`, `--annotated` | Limit to reference or annotated records only when the task requires it. |'
- '| `--include` | Request only needed assets such as genome, gff3, gbff, protein, rna, or cds. |'
- '| `--filename` | Set deterministic ZIP output and never overwrite an unrelated package. |'
- '| `--dehydrated` / `datasets rehydrate` | Separate manifest creation from transfer for large packages or controlled networks.
  |'
- '| `dataformat tsv ... --fields` | Select explicit report fields; do not parse JSONL with ad hoc text splitting. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# NCBI Datasets CLI

Use the official CLI as the default NCBI reference-data acquisition layer. This is a data acquisition tool, not permission to download a missing registered analysis database.

## Capabilities and selection

`datasets summary` returns structured metadata and `datasets download` creates reproducible data packages for genomes, genes, taxonomy, and supported viruses. `dataformat` converts JSON Lines reports into stable tabular fields. Prefer it over webpage automation, `ncbi-genome-download`, or free-form Entrez XML when the requested object is supported.

Use SRA Toolkit for raw run reads. Use Entrez only for a query not represented by Datasets. Resolve ambiguous organism names to TaxID before a large download and distinguish RefSeq from GenBank explicitly.

The Agent's `resolve_fuzzy_species_name()` is the controlled natural-language taxonomy entry point. Exact scientific/common names are accepted from structured JSON Lines. If Datasets reports suggestions, only lines matching the TaxID suggestion grammar are considered and every TaxID is re-queried as a structured record. Similarity scoring, rank checks and a candidate-margin gate prevent a genus or close species from becoming an automatic download. `plan_species_reference_download()` then pins an assembly accession; it does not download by taxon name.

## Inputs and upstream

Accept assembly/gene accessions, TaxIDs, taxon names, or a newline-delimited accession file. The plan must state object type, accession scope, RefSeq/GenBank choice, assembly level, annotation requirements, output directory, and expected record count. Never silently widen a species query to a genus.

## Outputs and downstream

Genome packages contain `ncbi_dataset/data/`, `data_report.jsonl`, and `dataset_catalog.json`; requested assets may include genomic FASTA, protein FASTA, GFF3, GBFF, RNA, CDS, and sequence reports. Preserve the original ZIP and JSONL. Extracted genomes feed SeqKit validation, skani reference selection, Bakta comparison, Snippy references, and pangenome workflows.

## Parameters and decision rules

| Command/option | Meaning and setting rule |
| --- | --- |
| `datasets summary genome taxon|accession` | Inspect counts and metadata before downloading. |
| `datasets summary taxonomy taxon` | Normalize an exact/common name or TaxID; fuzzy suggestions must be revalidated by TaxID before use. |
| `datasets download genome accession` | Retrieve named assemblies; safest path for a fixed accession list. |
| `datasets download genome taxon` | Taxon-wide retrieval; require TaxID and restrictive filters. |
| `datasets download virus genome taxon\|accession` | Limited virus fallback; the installed CLI supports completeness, host and lower release-date filtering, but gget is required for upper-date and sequence-length filters. |
| `--inputfile` | Read accessions from a reviewed file; keep this file as provenance. |
| `--assembly-level` | Restrict to complete/chromosome/scaffold/contig as scientifically appropriate. |
| `--reference`, `--annotated` | Limit to reference or annotated records only when the task requires it. |
| `--include` | Request only needed assets such as genome, gff3, gbff, protein, rna, or cds. |
| `--filename` | Set deterministic ZIP output and never overwrite an unrelated package. |
| `--dehydrated` / `datasets rehydrate` | Separate manifest creation from transfer for large packages or controlled networks. |
| `dataformat tsv ... --fields` | Select explicit report fields; do not parse JSONL with ad hoc text splitting. |

## Workflow patterns

```bash
conda run -n biomni-ncbi-datasets --no-capture-output datasets summary genome accession GCF_000005845.2 > summary.json
conda run -n biomni-ncbi-datasets --no-capture-output datasets download genome accession GCF_000005845.2 --include genome,gff3,gbff,protein --filename reference.zip
conda run -n biomni-ncbi-datasets --no-capture-output dataformat tsv genome --inputfile ncbi_dataset/data/assembly_data_report.jsonl --fields accession,organism-name,assminfo-level > assemblies.tsv
```

Downloads are allowed only in a user-confirmed acquisition task. They must not be used to bypass the `Database/<id>/` preparation policy for registered tool databases.

## Validation and failure handling

Require a successful exit, non-empty ZIP, readable catalog and JSONL, expected accession count, unique accessions, non-empty requested files, and checksums after extraction. Zero results usually mean an invalid accession, taxon ambiguity, or incompatible filters. Rate/transport failures may be retried with backoff; schema changes require checking `datasets --help` and `dataformat --help`, not guessing field names.
