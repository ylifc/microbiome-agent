---
name: Sylph
description: Ultra-fast, low-memory k-mer/ANI-based metagenome profiling and genome querying against a sketch database.
kind: software
id: sylph
version: 2
selection_tier: conditional
environment: biomni-sylph
executables:
- sylph
packages:
- sylph
channels:
- conda-forge
- bioconda
tasks:
- rapid metagenomic taxonomic profiling
- genome containment and abundance screening
- database sketching and querying
databases:
- reference-genomes
aliases:
- Sylph
- sylph
- 快速宏基因组物种组成
- k-mer 丰度
keywords:
- metagenomics
- profiling
- ANI
- k-mer
- containment
- abundance
- taxonomy
- 物种组成
capabilities:
- sketch reads into a compressed profile
- estimate genome coverage and relative abundance
- query genomes against a sketch database
- profile large cohorts with minimal RAM
inputs:
- shotgun FASTQ (single or paired)
- a sketched reference database or a genome collection
outputs:
- taxonomic abundance table
- per-genome coverage and ANI estimates
upstream:
- fastp
- bbmap
- sra-toolkit
downstream: []
software_family: sylph
documentation_status: CURATED_PROSE
downstream_tasks:
- bracken comparison
- diversity and differential-abundance analysis
parameter_guidance:
- '| `sketch -g` | Build a sketch database from reference genomes (`-g`/`--genomes`), named by `-o`/`--out-name-db` (produces
  `<name>.syldb`). |'
- '| `profile <db>` | First positional arg is the sketch DB; pass reads with `-1`/`-2` (paired) or `-r`/`--reads` (single-end).
  |'
- '| `query <db> <query.fa>` | Report containment/coverage of sequences against the sketch database. |'
- '| `-t` | Threads. |'
- '| `-M`/`--min-number-kmers`, `-a`/`--minimum-ani` | Minimum evidence and ANI thresholds; record the chosen values. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# Sylph

Use Sylph for extremely fast, low-memory shotgun metagenome profiling when Kraken2 databases are too large or RAM is limited. It estimates which reference genomes are present, their coverage, and their relative abundance via a k-mer/ANI model.

```bash
# Build a sketch database from reference genomes (outputs sketch_db.syldb)
conda run -n biomni-sylph --no-capture-output sylph sketch -g refs/*.fna -o sketch_db

# Profile one or many samples against the sketch database
conda run -n biomni-sylph --no-capture-output sylph profile sketch_db.syldb \
  -1 sample_R1.fastq.gz -2 sample_R2.fastq.gz -t 16 -o sample.profile.tsv

# Query which references contain an assembly/contigs
conda run -n biomni-sylph --no-capture-output sylph query sketch_db.syldb query.fa -o containment.tsv
```

## Capabilities and selection

Sylph sketches reads into compact k-mer summaries and profiles them against a database of genome sketches, reporting per-genome coverage and relative abundance. Its memory footprint is tiny relative to Kraken2 and it scales to many thousands of samples. Prefer Sylph when the goal is genome-resolved relative abundance against a known reference set; prefer Kraken2/Bracken for broad taxonomy against a curated RefSeq/GTDB database and MetaPhlAn for marker-based clade abundance. Do not stack profilers into one primary result without a comparison goal.

## Inputs and upstream

Input is quality-controlled shotgun FASTQ. The sketch database is built from the reference genome collection; its composition (e.g., GTDB representatives vs. RefSeq) defines what Sylph can detect. Record the database build and version.

## Outputs and downstream

`profile` writes a table of detected genomes with coverage, ANI, and relative abundance; `query` reports containment of input sequences. Feed profiles to downstream composition, diversity, and differential-abundance analyses. Coverage and abundance are relative, not absolute cell counts.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `sketch -g` | Build a sketch database from reference genomes (`-g`/`--genomes`), named by `-o`/`--out-name-db` (produces `<name>.syldb`). |
| `profile <db>` | First positional arg is the sketch DB; pass reads with `-1`/`-2` (paired) or `-r`/`--reads` (single-end). |
| `query <db> <query.fa>` | Report containment/coverage of sequences against the sketch database. |
| `-t` | Threads. |
| `-M`/`--min-number-kmers`, `-a`/`--minimum-ani` | Minimum evidence and ANI thresholds; record the chosen values. |

## Workflow patterns

Sketch the reference genome set once, profile every sample against it, and query new assemblies for containment. Use Sylph as a fast screen, then confirm key taxa with Kraken2/Bracken or assembly coverage.

```bash
conda run -n biomni-sylph --no-capture-output sylph sketch -g refs/*.fna -o sketch_db
conda run -n biomni-sylph --no-capture-output sylph profile sketch_db.syldb \
  -1 sample_R1.fastq.gz -2 sample_R2.fastq.gz -t 16 -o sample.profile.tsv
```

## Validation and failure handling

Require a non-empty sketch database and record its reference composition. A profile with only low-coverage hits may indicate an out-of-scope database or heavy host contamination. Cross-check key taxa against Kraken2/Bracken or assembly coverage rather than trusting a single profiler's abundance ranking.
