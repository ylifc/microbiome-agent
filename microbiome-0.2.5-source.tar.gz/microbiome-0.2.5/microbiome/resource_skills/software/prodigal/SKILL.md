---
name: Prodigal
description: Protein-coding gene prediction for prokaryotic genomes and metagenomes.
kind: software
id: prodigal
version: 2
environment: microbiome
executables:
- prodigal
packages:
- prodigal
channels:
- conda-forge
- bioconda
tasks:
- gene prediction
- protein calling
- metagenomic ORF prediction
databases: []
aliases:
- Prodigal
- ORF caller
- gene caller
- 基因预测
keywords:
- prokaryotic genes
- proteins
- CDS
- ORF
- metagenome
- 基因预测
- 蛋白预测
capabilities:
- prokaryotic CDS prediction
- metagenomic gene prediction
- protein and nucleotide CDS export
inputs:
- assembled nucleotide FASTA for isolates
- contig or MAG FASTA for metagenomes
outputs:
- protein FASTA
- nucleotide CDS FASTA
- GFF or GenBank feature table
- gene score file
upstream:
- megahit
- spades
- metabat2
- maxbin2
- concoct
downstream:
- diamond
- ncbi-blast
- rgi
- paml
software_family: prodigal
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Parameter | Meaning and setting rule |'
- '| `-i` | Required nucleotide FASTA. Use one genome/bin collection with clear provenance. |'
- '| `-p single` | Learn from one genome; suitable for isolates and sufficiently complete MAGs. |'
- '| `-p meta` | Use metagenomic models for fragmented or mixed contigs; safer for short contigs. |'
- '| `-g` | NCBI translation table. Default 11 suits many bacteria/archaea; change only from known taxonomy or biology. |'
- '| `-a` | Protein FASTA output. Required before DIAMOND/BLASTP and many annotation tools. |'
- '| `-d` | Nucleotide CDS output for codon analysis or gene abundance. |'
- '| `-o` and `-f` | Feature output path and format (`gff`, `gbk`, or `sco` in supported versions). GFF is usually easiest
  to integrate. |'
- '| `-c` | Require genes to be closed at sequence ends. Avoid on fragmented contigs because genuine edge-truncated genes
  would be lost. |'
- '| `-m` | Prevent genes from spanning runs of ambiguous `N`; useful for scaffold gaps. |'
- '| `-t` | Read a saved training file in single-genome workflows; it must match the intended organism/model. |'
- '| `-s` | Write potential-gene score information for diagnostics. |'
- '| `-q` | Quiet output; use only after commands are stable because warnings aid diagnosis. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# Prodigal

Use normal mode for isolate genomes and `-p meta` for fragmented metagenomic contigs.

```bash
conda run -n microbiome --no-capture-output prodigal -i contigs.fasta -a proteins.faa -d genes.fna -f gff -o genes.gff -p meta
```

Confirm that protein, nucleotide, and GFF identifiers agree and that output files are non-empty.

## Capabilities and selection

Prodigal predicts prokaryotic protein-coding sequences and translation starts. It supports a whole-genome mode that learns a model from one sufficiently complete genome and a metagenomic mode that uses precomputed models for fragmented contigs. It does not predict eukaryotic exon-intron genes and is not a functional annotator.

Use normal/single mode for an isolate or good-quality MAG when sequence context is sufficient. Use `-p meta` for short, fragmented, mixed-taxonomy contigs. For tiny genomes, organelles, or alternative genetic codes, set the translation table deliberately and verify biological suitability.

## Inputs and upstream

Input is nucleotide FASTA from MEGAHIT/SPAdes assemblies or bin FASTA files from MetaBAT 2, MaxBin 2, or CONCOCT. Each sequence identifier must be unique and should contain no whitespace-dependent semantics. Remove zero-length records and document whether contigs were length-filtered. Do not feed protein FASTA to Prodigal.

## Outputs and downstream

`-a` writes translated proteins (`.faa`), `-d` writes nucleotide CDS (`.fna`), and `-o` writes feature coordinates in the format selected by `-f`. Protein IDs must remain traceable to contig and coordinates.

Protein FASTA can feed DIAMOND, BLASTP, RGI protein-oriented workflows, phylogenetic marker extraction, and PAML after homolog selection/alignment. CDS nucleotide FASTA can feed codon-aware alignment and abundance quantification. GFF can feed annotation integration and coordinate-aware reporting.

## Parameters and decision rules

| Parameter | Meaning and setting rule |
| --- | --- |
| `-i` | Required nucleotide FASTA. Use one genome/bin collection with clear provenance. |
| `-p single` | Learn from one genome; suitable for isolates and sufficiently complete MAGs. |
| `-p meta` | Use metagenomic models for fragmented or mixed contigs; safer for short contigs. |
| `-g` | NCBI translation table. Default 11 suits many bacteria/archaea; change only from known taxonomy or biology. |
| `-a` | Protein FASTA output. Required before DIAMOND/BLASTP and many annotation tools. |
| `-d` | Nucleotide CDS output for codon analysis or gene abundance. |
| `-o` and `-f` | Feature output path and format (`gff`, `gbk`, or `sco` in supported versions). GFF is usually easiest to integrate. |
| `-c` | Require genes to be closed at sequence ends. Avoid on fragmented contigs because genuine edge-truncated genes would be lost. |
| `-m` | Prevent genes from spanning runs of ambiguous `N`; useful for scaffold gaps. |
| `-t` | Read a saved training file in single-genome workflows; it must match the intended organism/model. |
| `-s` | Write potential-gene score information for diagnostics. |
| `-q` | Quiet output; use only after commands are stable because warnings aid diagnosis. |

## Workflow patterns

```bash
conda run -n microbiome --no-capture-output prodigal \
  -i MAG_001.fasta -p single -g 11 \
  -a MAG_001.faa -d MAG_001.fna -f gff -o MAG_001.gff
```

For unbinned metagenomic contigs, switch to `-p meta`. Keep FASTA, FAA, FNA, and GFF under the same sample/bin prefix so downstream hits can be joined safely.

## Validation and failure handling

Require non-empty protein/CDS/feature outputs, matching feature counts, valid coordinates within contig lengths, and plausible protein length distributions. Very few genes can indicate protein input passed as nucleotide, an incorrect genetic code, aggressive `-c`, extremely short contigs, or damaged FASTA. Excessive tiny proteins can reflect fragmented assembly or wrong mode. Never infer genome completeness from Prodigal gene count; use CheckM and domain-specific evidence.
