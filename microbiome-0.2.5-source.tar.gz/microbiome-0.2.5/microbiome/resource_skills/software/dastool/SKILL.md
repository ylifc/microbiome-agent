---
name: DAS Tool
description: Integrates and scores bins from multiple metagenomic binners using single-copy genes.
kind: software
id: dastool
version: 2
selection_tier: conditional
environment: biomni-dastool
executables:
- DAS_Tool
- Fasta_to_Contig2Bin.sh
packages:
- das_tool
channels:
- conda-forge
- bioconda
tasks:
- bin set integration
- MAG dereplication within assembly
- consensus bin selection
databases: []
aliases:
- DAS Tool
- DAS_Tool
- 分箱整合
- bin refinement
keywords:
- MAG
- MetaBAT2
- MaxBin2
- CONCOCT
- SemiBin2
- contig2bin
- single-copy genes
capabilities:
- score candidate bins from several binners
- resolve overlapping contig assignments
- emit a nonredundant optimized bin set
inputs:
- assembly contig FASTA
- comma-separated contig-to-bin tables
- matching binner labels
outputs:
- optimized bin FASTA files
- contig-to-bin table
- bin quality scores
- summary tables
- optional evaluation plots
upstream:
- metabat2
- maxbin2
- concoct
- semibin2
downstream:
- checkm2
- gunc
- drep
- gtdbtk
- bakta
software_family: dastool
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Command/option | Meaning and setting rule |'
- '| `-i` | Comma-separated contig-to-bin tables from independent binners. |'
- '| `-l` | Comma-separated labels in exactly the same order as `-i`. |'
- '| `-c` | Assembly contig FASTA shared by all candidate bin sets. |'
- '| `-o` | Output prefix including a dedicated result path. |'
- '| `--search_engine` | `diamond` (default), `blastp`, or `usearch`; use the alternatives only for controlled compatibility
  needs. |'
- '| `--score_threshold` | Minimum accepted bin score; lower values recover weaker bins but increase false/contaminated candidates.
  |'
- '| `--duplicate_penalty` | Penalty for duplicated single-copy genes; increase when purity is more important than recovery.
  |'
- '| `--megabin_penalty` | Discourages unrealistically large bins; change only with organism/community context. |'
- '| `--dbDirectory` | Persistent directory for DAS Tool''s bundled marker database/intermediates when explicitly managed.
  |'
- '| `--write_bin_evals` | Emit per-bin evaluation details for audit and threshold review. |'
- '| `--write_bins` | Materialize selected genome FASTA files for downstream tools. |'
- '| `--threads` | CPU allocation for marker searches. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# DAS Tool

Use DAS Tool only when at least two meaningfully different bin sets exist for the same assembly. It is a consensus selector, not a replacement for mapping, coverage calculation, or independent post-selection quality assessment.

## Capabilities and selection

DAS Tool identifies single-copy genes, scores bins for completeness and redundancy, and chooses a nonredundant set while resolving overlaps among binners. Complementary inputs such as MetaBAT2, MaxBin2, CONCOCT and SemiBin2 usually provide more value than repeated runs of one algorithm with nearly identical settings.

## Inputs and upstream

Provide the exact assembly FASTA used by every binner. Each contig-to-bin table has two tab-separated columns without an ambiguous header: contig ID and bin ID. Convert bin directories with `Fasta_to_Contig2Bin.sh` and confirm IDs exactly match FASTA headers. The number and order of `-l` labels must match `-i` inputs.

## Outputs and downstream

Keep the optimized bin FASTA directory, `*_DASTool_contig2bin.tsv`, `*_DASTool_summary.tsv`, score tables and log. Reassess selected bins with CheckM2 and GUNC because DAS Tool's internal score is a selection signal, not a final universal quality certificate.

## Parameters and decision rules

| Command/option | Meaning and setting rule |
| --- | --- |
| `-i` | Comma-separated contig-to-bin tables from independent binners. |
| `-l` | Comma-separated labels in exactly the same order as `-i`. |
| `-c` | Assembly contig FASTA shared by all candidate bin sets. |
| `-o` | Output prefix including a dedicated result path. |
| `--search_engine` | `diamond` (default), `blastp`, or `usearch`; use the alternatives only for controlled compatibility needs. |
| `--score_threshold` | Minimum accepted bin score; lower values recover weaker bins but increase false/contaminated candidates. |
| `--duplicate_penalty` | Penalty for duplicated single-copy genes; increase when purity is more important than recovery. |
| `--megabin_penalty` | Discourages unrealistically large bins; change only with organism/community context. |
| `--dbDirectory` | Persistent directory for DAS Tool's bundled marker database/intermediates when explicitly managed. |
| `--write_bin_evals` | Emit per-bin evaluation details for audit and threshold review. |
| `--write_bins` | Materialize selected genome FASTA files for downstream tools. |
| `--threads` | CPU allocation for marker searches. |

## Workflow patterns

```bash
conda run -n biomni-dastool --no-capture-output Fasta_to_Contig2Bin.sh \
  -i metabat2_bins -e fa > metabat2.contig2bin.tsv
conda run -n biomni-dastool --no-capture-output DAS_Tool \
  -i metabat2.contig2bin.tsv,semibin2.contig2bin.tsv,maxbin2.contig2bin.tsv \
  -l metabat2,semibin2,maxbin2 -c assembly.fa -o dastool/result \
  --search_engine diamond --write_bin_evals --write_bins --threads 16
```

## Validation and failure handling

Before execution, verify every assigned contig exists exactly once in the assembly and table delimiters are tabs. After execution, require a parseable summary and FASTA/table consistency. Zero selected bins can be a valid quality outcome; inspect score distribution and upstream bin quality before lowering thresholds. Marker-search failures usually indicate environment/database setup or malformed protein/contig input.
