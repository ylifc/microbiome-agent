---
name: Snippy
description: Reproducible haploid bacterial variant calling and multi-isolate core-genome alignment from reads or contigs.
kind: software
id: snippy
version: 2
selection_tier: default
environment: biomni-snippy
executables:
- snippy
- snippy-core
- snippy-clean_full_aln
- snippy-multi
packages:
- snippy
channels:
- conda-forge
- bioconda
tasks:
- bacterial SNP calling
- indel calling
- core genome alignment
- outbreak phylogenomics
databases: []
aliases:
- Snippy
- bacterial variant pipeline
- 细菌SNP流程
keywords:
- haploid
- FreeBayes
- core SNP
- FASTQ
- VCF
- outbreak
- reference mapping
- 变异检测
capabilities:
- call haploid variants against one reference
- annotate variants from GenBank reference
- combine same-reference runs into core alignments
inputs:
- reference FASTA or GenBank
- paired/single short-read FASTQ or assembled contigs
- optional mask or target BED
outputs:
- VCF GFF BED TSV CSV HTML variants
- sorted BAM and index
- consensus FASTA
- full and SNP-only core alignments
upstream:
- fastp
- ncbi-datasets
- skani
- quast
downstream:
- gubbins
- snp-sites
- snp-dists
- iqtree2
software_family: snippy
documentation_status: CURATED_PROSE
parameter_guidance:
- '| `--ref` | Fixed FASTA/GenBank reference; GenBank enables feature/effect fields. |'
- '| `--R1/--R2`, `--se`, `--ctgs` | Mutually exclusive evidence modes. Prefer raw reads for outbreak inference. |'
- '| `--outdir`, `--prefix`, `--rgid` | Stable sample/output/read-group identity; never reuse an existing run directory. |'
- '| `--cpus`, `--ram` | Bound compute resources. |'
- '| `--mincov` | Minimum depth to call a site; coordinate with core-site missingness policy. |'
- '| `--minfrac` | Minimum alternate fraction; high values fit clonal haploid isolates, not mixed samples. |'
- '| `--minqual`, `--mapqual`, `--basequal` | Variant, mapping, and base-quality filters; report any changes. |'
- '| `--maxsoft` | Exclude excessively soft-clipped alignments that can create false calls. |'
- '| `--targets` | Restrict calls to reviewed BED intervals; unsuitable for whole-genome tree claims. |'
- '| `--subsample` | Reduce extreme depth only after estimating coverage and preserving a deterministic policy. |'
- '| `--unmapped`, `--report`, `--cleanup` | Retain unmapped reads, detailed reports, or remove intermediates; cleanup can
  affect `snippy-core` reference discovery. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# Snippy

Use Snippy to reduce fragile manual construction of a bacterial short-read mapping/calling pipeline. All samples in `snippy-core` must use the identical reference sequence.

## Capabilities and selection

Snippy maps reads, calls haploid SNP/indel/complex variants, filters calls, annotates effects when given GenBank, and emits consistent sample outputs. It is designed for haploid microbial genomes, not mixed populations, polyploid eukaryotes, or low-frequency intrahost variants.

## Inputs and upstream

Choose a close, high-quality reference using skani and biological context. Supply paired reads with `--R1/--R2`, single reads with `--se`, or contigs with `--ctgs`; do not treat contig-shredding calls as equivalent evidence to read calls. Use the same reference checksum and mask for every cohort sample.

## Outputs and downstream

Per-sample outputs include `snps.vcf`, tables, HTML, BAM/BAI, logs, aligned and consensus FASTA. `snippy-core` creates `core.full.aln`, SNP-only `core.aln`, VCF, statistics, and reference. Clean the full alignment before Gubbins; use SNP-sites and IQ-TREE ascertainment correction appropriately for SNP-only data.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `--ref` | Fixed FASTA/GenBank reference; GenBank enables feature/effect fields. |
| `--R1/--R2`, `--se`, `--ctgs` | Mutually exclusive evidence modes. Prefer raw reads for outbreak inference. |
| `--outdir`, `--prefix`, `--rgid` | Stable sample/output/read-group identity; never reuse an existing run directory. |
| `--cpus`, `--ram` | Bound compute resources. |
| `--mincov` | Minimum depth to call a site; coordinate with core-site missingness policy. |
| `--minfrac` | Minimum alternate fraction; high values fit clonal haploid isolates, not mixed samples. |
| `--minqual`, `--mapqual`, `--basequal` | Variant, mapping, and base-quality filters; report any changes. |
| `--maxsoft` | Exclude excessively soft-clipped alignments that can create false calls. |
| `--targets` | Restrict calls to reviewed BED intervals; unsuitable for whole-genome tree claims. |
| `--subsample` | Reduce extreme depth only after estimating coverage and preserving a deterministic policy. |
| `--unmapped`, `--report`, `--cleanup` | Retain unmapped reads, detailed reports, or remove intermediates; cleanup can affect `snippy-core` reference discovery. |

## Workflow patterns

```bash
conda run -n biomni-snippy --no-capture-output snippy --check
conda run -n biomni-snippy --no-capture-output snippy \
  --cpus 8 --outdir S1 --ref reference.gbk --R1 S1_R1.fastq.gz --R2 S1_R2.fastq.gz \
  --mincov 10 --minfrac 0.9
conda run -n biomni-snippy --no-capture-output snippy-core --prefix core S1 S2 S3
conda run -n biomni-snippy --no-capture-output snippy-clean_full_aln core.full.aln > core.clean.full.aln
```

## Validation and failure handling

Require `snippy --check`, mapping/coverage statistics, BAM index, parseable VCF, plausible variant counts, cohort-wide reference equality, core size/missingness, and no mixed/contaminated samples. Very high variants suggest distant/wrong reference or contamination; very low core size suggests coverage/reference/quality inconsistency. Do not lower `mincov/minfrac` solely to force a tree.
