---
name: gget
description: Lightweight CLI and Python access to Ensembl, UniProt, NCBI and related genomic resources, with release-aware
  reference-genome retrieval through gget ref.
kind: software
id: gget
version: 3
selection_tier: default
environment: biomni-gget
executables:
- gget
packages:
- python>=3.12,<3.15
- pip
- curl
- pysocks
pip_packages:
- gget>=0.30.3,<0.31
channels:
- conda-forge
tasks:
- Ensembl reference genome retrieval
- gene search
- gene metadata lookup
- sequence retrieval
- virus sequence retrieval
databases: []
optional_databases:
- reference-genomes
- virus-genomes
aliases:
- scverse gget
- gget ref
- Ensembl下载
- 基因组下载
- 基因检索
keywords:
- gget
- Ensembl
- reference genome
- GTF
- cDNA
- CDS
- peptide
- gene ID
- UniProt
- virus
- 参考基因组
- 下载基因组
capabilities:
- resolve and download Ensembl reference assets
- search genes and return stable identifiers
- retrieve gene metadata and sequences
- retrieve curated virus sequence packages
inputs:
- Ensembl species identifier or release
- Ensembl gene/transcript/protein ID
- free-text gene query with species
- virus name TaxID or accession
outputs:
- reference DNA FASTA and GTF/cDNA/CDS/peptide files
- JSON or CSV metadata
- nucleotide or amino-acid FASTA
- virus FASTA and metadata
upstream: []
downstream:
- seqkit
- bwa
- bowtie2
- minimap2
- snippy
- salmon
- ncbi-blast
excludes:
- bacterial genome retrieval with gget ref
- raw SRA read download
- bulk analysis database installation
software_family: gget
documentation_status: CURATED_PROSE
upstream_tasks:
- user species or accession selection
- inspect-local-reference-genomes
- taxonomy normalization
downstream_tasks:
- phylogenetic alignment
parameter_guidance:
- '| Command or option | Meaning and setting rule |'
- '| `gget ref <species>` | Return Ensembl reference metadata and links; inspect this before transferring files. |'
- '| `-w/--which gtf,cdna,dna,cds,cdrna,pep` | Select only assets required by downstream software; DNA plus GTF is the usual
  genome/annotation pair. |'
- '| `-r/--release` | Pin the Ensembl release for reproducibility and assembly/annotation compatibility. |'
- '| `-ftp/--ftp` | Return FTP URLs without downloading; useful for planning and provenance. |'
- '| `-d/--download` | Transfer selected files; allowed only after the marked acquisition plan is confirmed. |'
- '| `-od/--out_dir` | Must point to the planned child of `Database/reference-genomes/`. |'
- '| `gget search` | Find Ensembl IDs from terms; constrain species and review ambiguous matches. |'
- '| `gget info` | Retrieve metadata for reviewed IDs; request only fields required by the workflow. |'
- '| `gget seq` | Retrieve nucleotide or protein sequence for reviewed IDs; validate molecule type and count. |'
- '| `gget virus` | Retrieve virus FASTA/metadata; record all filters because they define the downloaded population; packages
  belong in `Database/virus-genomes/`. |'
- '| `--min_release_date/--max_release_date` | Bound NCBI Virus release dates; use collection-date flags instead when sampling
  time is the scientific criterion. |'
- '| `--min_seq_length/--max_seq_length` | Bound nucleotide record length; do not use legacy `--min_length/--max_length` spellings.
  |'
- '| `--annotated true\|false` | Annotation filter requires an explicit boolean value. |'
- '| `--is_accession` | Interpret following positional values as accessions rather than a virus name or TaxID. |'
- '| `-o/--out` | Output location for `gget virus`; `-od/--out_dir` belongs to `gget ref`, not virus. |'
- Run `gget --help` and the selected subcommand's help in `biomni-gget` before using flags not documented here. Upstream schemas
  can change, so never infer a renamed field from an old example.
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# gget

## Capabilities and selection

Use gget as the preferred concise interface for Ensembl/Ensembl Genomes reference files and for small, structured gene or sequence lookups. `gget ref` returns release metadata and FTP links and can download selected DNA, GTF, cDNA, CDS, coding RNA, or peptide assets. `search`, `info`, and `seq` connect a natural-language gene request to stable identifiers and sequences. `virus` provides a separate NCBI Virus/INSDC retrieval path.

Do not use `gget ref` for bacterial genomes because that module does not support Ensembl Bacteria. Use the `ncbi-datasets` skill with an exact RefSeq/GenBank assembly accession for bacteria and archaea. Use SRA Toolkit for raw sequencing runs. A registered local reference under `Database/reference-genomes/` is preferred over a new transfer when its organism, assembly/release, annotation and coordinate system match.

## Inputs and upstream

`ref` accepts an Ensembl species identifier such as `homo_sapiens`; pin `--release` when reproducibility matters. Resolve ambiguous common names before download. `search` accepts one or more terms plus an Ensembl species/database; `info` and `seq` should receive reviewed Ensembl IDs from search or upstream metadata. `virus` accepts virus names, TaxIDs or accessions and optional host/completeness/date filters.

Before reference acquisition, call `inspect_local_reference_genomes()` and compare gget with NCBI Datasets. The plan must name the species/accession, source, release, requested assets, destination, expected downstream coordinate system and acquisition marker. Never silently widen a species request.

## Outputs and downstream

Keep downloaded reference assets together under one child of `Database/reference-genomes/` and write `release-manifest.yaml` with the identifier, Ensembl release, source, command, file sizes and paths. DNA plus GTF feed aligners, Salmon index construction, variant workflows and annotation-aware analyses. cDNA/CDS/peptide outputs feed transcript/protein alignment and annotation. Gene query JSON/CSV should retain stable IDs and release metadata.

Do not mix a GTF from one assembly/release with DNA from another. Preserve compressed source files unless a downstream tool requires decompression, and record any derived FASTA index, sequence dictionary, BWA/Bowtie2/Minimap2 index or Salmon index as a consumer-specific localization artifact.

## Parameters and decision rules

| Command or option | Meaning and setting rule |
| --- | --- |
| `gget ref <species>` | Return Ensembl reference metadata and links; inspect this before transferring files. |
| `-w/--which gtf,cdna,dna,cds,cdrna,pep` | Select only assets required by downstream software; DNA plus GTF is the usual genome/annotation pair. |
| `-r/--release` | Pin the Ensembl release for reproducibility and assembly/annotation compatibility. |
| `-ftp/--ftp` | Return FTP URLs without downloading; useful for planning and provenance. |
| `-d/--download` | Transfer selected files; allowed only after the marked acquisition plan is confirmed. |
| `-od/--out_dir` | Must point to the planned child of `Database/reference-genomes/`. |
| `gget search` | Find Ensembl IDs from terms; constrain species and review ambiguous matches. |
| `gget info` | Retrieve metadata for reviewed IDs; request only fields required by the workflow. |
| `gget seq` | Retrieve nucleotide or protein sequence for reviewed IDs; validate molecule type and count. |
| `gget virus` | Retrieve virus FASTA/metadata; record all filters because they define the downloaded population; packages belong in `Database/virus-genomes/`. |
| `--min_release_date/--max_release_date` | Bound NCBI Virus release dates; use collection-date flags instead when sampling time is the scientific criterion. |
| `--min_seq_length/--max_seq_length` | Bound nucleotide record length; do not use legacy `--min_length/--max_length` spellings. |
| `--annotated true\|false` | Annotation filter requires an explicit boolean value. |
| `--is_accession` | Interpret following positional values as accessions rather than a virus name or TaxID. |
| `-o/--out` | Output location for `gget virus`; `-od/--out_dir` belongs to `gget ref`, not virus. |

Run `gget --help` and the selected subcommand's help in `biomni-gget` before using flags not documented here. Upstream schemas can change, so never infer a renamed field from an old example.

## Workflow patterns

```bash
conda run -n biomni-gget --no-capture-output gget ref -w dna,gtf -r 113 -ftp homo_sapiens
conda run -n biomni-gget --no-capture-output gget ref -w dna,gtf -r 113 -d -od Database/reference-genomes/gget-homo-sapiens-r113 homo_sapiens
conda run -n biomni-gget --no-capture-output gget search TP53 -s homo_sapiens
conda run -n biomni-gget --no-capture-output gget info ENSG00000141510
conda run -n biomni-gget --no-capture-output gget seq ENSG00000141510
conda run -n biomni-gget --no-capture-output gget virus --nuc_completeness complete --host human -o Database/virus-genomes/gget-rotavirus-complete-human-<date> "Rotavirus"
```

In Agent execution prefer `plan_reference_genome_download()` and, after confirmation, `download_reference_genome(..., approved=True)` so the destination and manifest are deterministic. For virus acquisitions prefer `plan_virus_genome_download()` then `download_virus_genomes(..., approved=True)`. A new environment must use Python 3.12-3.14 and include `pysocks`, because pip inherits `ALL_PROXY`/`all_proxy` and cannot use a SOCKS proxy without that package.

When the `gget` executable is missing from an existing `biomni-gget` environment, repair it in place without deleting the environment:

```bash
conda install -n biomni-gget -y -c conda-forge pysocks
conda run -n biomni-gget --no-capture-output python -m pip install --upgrade "gget>=0.30.3,<0.31"
```

The first command is a network prerequisite, not a second gget installation. If pip reports `No matching distribution` while a compatible gget exists, inspect the preceding transport/proxy error before changing the gget version constraint. Each subsequent software runs through its own Skill environment; do not install aligners or analysis packages into `biomni-gget`.

## Validation and failure handling

Require exit code zero, a non-empty response, the expected number and type of downloaded files, parseable FASTA/GTF, matching sequence names between DNA and GTF, a pinned release when requested, and a complete manifest. Validate FASTA records with SeqKit before pilot use.

No result or an unknown species usually means an invalid Ensembl identifier, unsupported division or release. Bacterial `ref` failure requires switching to NCBI Datasets, not guessing an Ensembl URL. `Missing dependencies for SOCKS support` requires installing `pysocks` in `biomni-gget`; it is not evidence that gget has no releases. HTTP/FTP failures may be retried with backoff; repeated upstream schema errors require checking current gget help/version. Partial files must be removed or resumed only after size/checksum validation. Never mark the reference READY merely because a destination directory exists.
