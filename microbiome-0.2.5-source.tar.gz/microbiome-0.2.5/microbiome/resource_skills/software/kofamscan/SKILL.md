---
name: KofamScan
description: KEGG Orthology HMM annotation / KO功能注释
kind: software
id: kofamscan
version: 3
selection_tier: conditional
documentation_status: DOCUMENTED
software_family: kofamscan
environment: microbiome-kofamscan
executables:
- exec_annotation
packages:
- kofamscan
channels:
- conda-forge
- bioconda
tasks:
- KEGG Orthology HMM annotation / KO功能注释
databases:
- kofam
aliases:
- KofamScan
- kofamscan
keywords:
- kofamscan
- KEGG Orthology HMM annotation / KO功能注释
capabilities:
- KEGG Orthology HMM annotation / KO功能注释
inputs:
- protein FASTA with stable IDs
outputs:
- KO assignments and HMM scores
upstream:
- prodigal
downstream: []
parameter_guidance:
- '--profile: exact profile directory or approved profile-list file.'
- '--ko-list: matching ko_list from the same release.'
- '--cpu: number of concurrent HMM searches; freeze the score/threshold interpretation.'
validation:
- Validate version and required package/functions before use.
- Run the task on representative data and require output assertions.
failure_handling:
- Do not replace KOfam profiles with KEGG protein FASTA or mix ko_list and profile releases.
- Consult version-matched Knowledge history; repair only in an approved maintenance phase.
references:
- https://github.com/takaram/kofam_scan
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# KofamScan

## Capabilities and selection

KEGG Orthology HMM annotation / KO功能注释.
Select this capability only when its input and statistical assumptions match the study.
Catalog documentation does not assert that this software is installed or task-validated.

## Inputs and upstream

- protein FASTA with stable IDs

Keep sample identifiers, feature identifiers, orientation, units and reference releases explicit.
Reject missing inputs rather than acquiring substitutes during analysis.

## Outputs and downstream

- KO assignments and HMM scores

Save the complete invocation, output schema, software version and database fingerprints.
Do not overwrite raw data, reference resources or outputs from a different run.

## Parameters and decision rules

- --profile: exact profile directory or approved profile-list file.
- --ko-list: matching ko_list from the same release.
- --cpu: number of concurrent HMM searches; freeze the score/threshold interpretation.

The reference below is the full manual source. This catalog covers the supported task decisions;
option availability and defaults must be checked against the installed version and captured help.
Unknown values must not be guessed. Package functions are verified independently of R/Python.

## Workflow patterns

The following is a discovery probe, not a successful analysis recipe:

```bash
conda run -n microbiome-kofamscan --no-capture-output exec_annotation --help
```

Resolve the actual environment prefix first. During production replay the frozen argv and paths.
R/Python workflows require a reviewed adapter with explicit parameters and output assertions.

## Validation and failure handling

Correct: use aligned input IDs, the approved method, compatible reference resources and validated outputs.
Incorrect: Do not replace KOfam profiles with KEGG protein FASTA or mix ko_list and profile releases.
A zero exit code without output validation is unverified history.
On failure record the complete command, exit code, stderr, version, input and database context.
Promote a repair only after a matching regression validation report passes.

## References and documentation coverage

- Official source: https://github.com/takaram/kofam_scan
- Documentation reviewed for catalog integration; this is not a local runtime acceptance claim.
- Parameter coverage: curated task guidance; full version-specific help is captured on discovery.
