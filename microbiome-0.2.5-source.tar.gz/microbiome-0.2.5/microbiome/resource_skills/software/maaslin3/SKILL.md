---
name: MaAsLin 3
description: Multivariable abundance and prevalence associations / 多变量关联
kind: software
id: maaslin3
version: 3
selection_tier: conditional
documentation_status: DOCUMENTED
software_family: maaslin3
environment: microbiome-maaslin3
executables:
- Rscript
packages:
- bioconductor-maaslin3
channels:
- conda-forge
- bioconda
tasks:
- Multivariable abundance and prevalence associations / 多变量关联
databases: []
aliases:
- MaAsLin 3
- maaslin3
keywords:
- maaslin3
- Multivariable abundance and prevalence associations / 多变量关联
capabilities:
- Multivariable abundance and prevalence associations / 多变量关联
inputs:
- microbial feature table
- sample metadata and declared formula
outputs:
- abundance and prevalence associations
- diagnostic and multiple-testing outputs
upstream:
- humann
- metaphlan
- phyloseq
downstream: []
parameter_guidance:
- 'formula: include prespecified exposures, covariates and repeated-measure structure.'
- 'normalization and transformation: disclose units and avoid processing twice.'
- 'reference levels and contrasts: declare before model fitting.'
validation:
- Validate version and required package/functions before use.
- Run the task on representative data and require output assertions.
failure_handling:
- Do not turn an association into causality or remove covariates automatically to obtain significance.
- Consult version-matched Knowledge history; repair only in an approved maintenance phase.
references:
- https://huttenhower.sph.harvard.edu/maaslin
runtime:
  kind: r_package
  package: maaslin3
  functions:
  - maaslin3
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# MaAsLin 3

## Capabilities and selection

Multivariable abundance and prevalence associations / 多变量关联.
Select this capability only when its input and statistical assumptions match the study.
Catalog documentation does not assert that this software is installed or task-validated.

## Inputs and upstream

- microbial feature table
- sample metadata and declared formula

Keep sample identifiers, feature identifiers, orientation, units and reference releases explicit.
Reject missing inputs rather than acquiring substitutes during analysis.

## Outputs and downstream

- abundance and prevalence associations
- diagnostic and multiple-testing outputs

Save the complete invocation, output schema, software version and database fingerprints.
Do not overwrite raw data, reference resources or outputs from a different run.

## Parameters and decision rules

- formula: include prespecified exposures, covariates and repeated-measure structure.
- normalization and transformation: disclose units and avoid processing twice.
- reference levels and contrasts: declare before model fitting.

The reference below is the full manual source. This catalog covers the supported task decisions;
option availability and defaults must be checked against the installed version and captured help.
Unknown values must not be guessed. Package functions are verified independently of R/Python.

## Workflow patterns

The following is a discovery probe, not a successful analysis recipe:

```bash
conda run -n microbiome-maaslin3 --no-capture-output Rscript --vanilla -e 'library(maaslin3); packageVersion("maaslin3")'
```

Resolve the actual environment prefix first. During production replay the frozen argv and paths.
R/Python workflows require a reviewed adapter with explicit parameters and output assertions.

## Validation and failure handling

Correct: use aligned input IDs, the approved method, compatible reference resources and validated outputs.
Incorrect: Do not turn an association into causality or remove covariates automatically to obtain significance.
A zero exit code without output validation is unverified history.
On failure record the complete command, exit code, stderr, version, input and database context.
Promote a repair only after a matching regression validation report passes.

## References and documentation coverage

- Official source: https://huttenhower.sph.harvard.edu/maaslin
- Documentation reviewed for catalog integration; this is not a local runtime acceptance claim.
- Parameter coverage: curated task guidance; full version-specific help is captured on discovery.
