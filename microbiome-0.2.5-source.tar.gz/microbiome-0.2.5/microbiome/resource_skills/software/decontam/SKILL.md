---
name: decontam
description: Control-aware contaminant identification / 污染特征识别
kind: software
id: decontam
version: 3
selection_tier: conditional
documentation_status: DOCUMENTED
software_family: decontam
environment: microbiome-decontam
executables:
- Rscript
packages:
- bioconductor-decontam
channels:
- conda-forge
- bioconda
tasks:
- Control-aware contaminant identification / 污染特征识别
databases: []
aliases:
- decontam
- decontam
keywords:
- decontam
- Control-aware contaminant identification / 污染特征识别
capabilities:
- Control-aware contaminant identification / 污染特征识别
inputs:
- sample-by-feature counts
- negative-control status or DNA concentration
outputs:
- per-feature contaminant scores and flags
- retained and removed feature lists
upstream:
- dada2
- phyloseq
downstream:
- vegan
- ancombc2
parameter_guidance:
- 'method: prevalence requires sequenced negative controls; frequency requires DNA concentration.'
- 'threshold: prespecify and record sensitivity analysis.'
- 'batch: separate preparation batches when the declared design requires it.'
validation:
- Validate version and required package/functions before use.
- Run the task on representative data and require output assertions.
failure_handling:
- Do not invent controls or apply frequency mode without concentration measurements.
- Consult version-matched Knowledge history; repair only in an approved maintenance phase.
references:
- https://bioconductor.org/packages/release/bioc/html/decontam.html
runtime:
  kind: r_package
  package: decontam
  functions:
  - isContaminant
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# decontam

## Capabilities and selection

Control-aware contaminant identification / 污染特征识别.
Select this capability only when its input and statistical assumptions match the study.
Catalog documentation does not assert that this software is installed or task-validated.

## Inputs and upstream

- sample-by-feature counts
- negative-control status or DNA concentration

Keep sample identifiers, feature identifiers, orientation, units and reference releases explicit.
Reject missing inputs rather than acquiring substitutes during analysis.

## Outputs and downstream

- per-feature contaminant scores and flags
- retained and removed feature lists

Save the complete invocation, output schema, software version and database fingerprints.
Do not overwrite raw data, reference resources or outputs from a different run.

## Parameters and decision rules

- method: prevalence requires sequenced negative controls; frequency requires DNA concentration.
- threshold: prespecify and record sensitivity analysis.
- batch: separate preparation batches when the declared design requires it.

The reference below is the full manual source. This catalog covers the supported task decisions;
option availability and defaults must be checked against the installed version and captured help.
Unknown values must not be guessed. Package functions are verified independently of R/Python.

## Workflow patterns

The following is a discovery probe, not a successful analysis recipe:

```bash
conda run -n microbiome-decontam --no-capture-output Rscript --vanilla -e 'library(decontam); packageVersion("decontam")'
```

Resolve the actual environment prefix first. During production replay the frozen argv and paths.
R/Python workflows require a reviewed adapter with explicit parameters and output assertions.

## Validation and failure handling

Correct: use aligned input IDs, the approved method, compatible reference resources and validated outputs.
Incorrect: Do not invent controls or apply frequency mode without concentration measurements.
A zero exit code without output validation is unverified history.
On failure record the complete command, exit code, stderr, version, input and database context.
Promote a repair only after a matching regression validation report passes.

## References and documentation coverage

- Official source: https://bioconductor.org/packages/release/bioc/html/decontam.html
- Documentation reviewed for catalog integration; this is not a local runtime acceptance claim.
- Parameter coverage: curated task guidance; full version-specific help is captured on discovery.
