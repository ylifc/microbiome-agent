---
name: Subread
description: High-performance read aligner and featureCounts gene-level quantification from BAM against a reference annotation.
kind: software
id: subread
version: 2
selection_tier: conditional
environment: biomni-subread
executables:
- featureCounts
- subread-align
- subread-buildindex
packages:
- subread
channels:
- conda-forge
- bioconda
tasks:
- gene-level read counting
- feature quantification against GFF/GTF
- alignment for reference-based RNA-seq
databases: []
aliases:
- Subread
- featureCounts
- 基因计数
- 表达定量
keywords:
- featureCounts
- counting
- GFF
- GTF
- RNA-seq
- expression
- 基因计数
capabilities:
- count reads per gene from BAM
- handle paired-end and strand-specific data
- produce count tables for differential expression
inputs:
- coordinate-sorted BAM files
- reference GFF/GTF annotation
outputs:
- gene-level count table
- per-feature summary
upstream:
- bowtie2
- bwa
- minimap2
- samtools
- salmon
downstream:
- deseq2
- edger
software_family: subread
documentation_status: CURATED_PROSE
downstream_tasks:
- differential expression and functional summary
parameter_guidance:
- '| `-a` | Reference GFF/GTF; must match the reference used for alignment. |'
- '| `-t` / `-g` | Feature type and attribute used as feature ID (gene/ID, CDS/locus_tag). |'
- '| `-p` / `--countReadPairs` | Count fragments for paired-end data. |'
- '| `-s` | Strandedness: 0 unstranded, 1 stranded, 2 reversely stranded. |'
- '| `-M` / `--fraction` | Multi-mapping policy; record the choice. |'
- '| `-T` | Threads. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# Subread / featureCounts

Use `featureCounts` (part of Subread) to produce gene-level read-count tables from aligned BAMs against a reference annotation. Count tables are the standard input for DESeq2/edgeR differential expression.

```bash
conda run -n biomni-subread --no-capture-output featureCounts \
  -a ref.gff -o counts.txt -t gene -g ID \
  -p --countReadPairs -s 0 \
  S1.sorted.bam S2.sorted.bam S3.sorted.bam
```

## Capabilities and selection

featureCounts assigns reads to features (genes) using a GFF/GTF and outputs a count matrix plus summary statistics. It handles paired-end, strand-specific, and multi-mapping options. Prefer it for reference-based microbial RNA-seq differential expression; use Salmon for transcript-level TPM/abundance when no gene-level statistical design is needed. Bind the annotation version to the reference genome exactly.

## Inputs and upstream

Inputs are coordinate-sorted BAMs aligned to the reference genome, plus the matching GFF/GTF. Feature type (`-t`) and ID attribute (`-g`) must match the annotation schema (e.g., `gene`/`ID` for Prokka/Bakta-derived GFF, `CDS`/`locus_tag` when counting CDS).

## Outputs and downstream

Output is a count matrix (`counts.txt`) with one column per BAM and per-gene rows, plus `counts.txt.summary`. The count matrix feeds DESeq2/edgeR. Record strandedness and multi-mapping policy because they change counts.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `-a` | Reference GFF/GTF; must match the reference used for alignment. |
| `-t` / `-g` | Feature type and attribute used as feature ID (gene/ID, CDS/locus_tag). |
| `-p` / `--countReadPairs` | Count fragments for paired-end data. |
| `-s` | Strandedness: 0 unstranded, 1 stranded, 2 reversely stranded. |
| `-M` / `--fraction` | Multi-mapping policy; record the choice. |
| `-T` | Threads. |

## Workflow patterns

Align reads to the reference genome, coordinate-sort and index, then run featureCounts for gene-level counts and pass the count matrix to DESeq2/edgeR for differential expression.

```bash
conda run -n biomni-subread --no-capture-output featureCounts \
  -a ref.gff -o counts.txt -t gene -g ID -p --countReadPairs -s 0 S1.sorted.bam S2.sorted.bam
```

## Validation and failure handling

Require BAM reference names and annotation sequence names to match. Inspect the summary file for assigned vs. unassigned read fractions; a very low assignment rate suggests a wrong feature type/ID or annotation/reference mismatch. Verify strandedness against the library protocol before trusting counts.
