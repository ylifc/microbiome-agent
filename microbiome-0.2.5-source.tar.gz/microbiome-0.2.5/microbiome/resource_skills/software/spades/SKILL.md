---
name: SPAdes
description: De novo assembly for isolates, metagenomes, plasmids, and careful genome reconstruction.
kind: software
id: spades
version: 2
environment: microbiome
executables:
- spades.py
packages:
- spades
channels:
- conda-forge
- bioconda
tasks:
- isolate assembly
- metagenome assembly
- plasmid assembly
databases: []
aliases:
- SPAdes
- metaSPAdes
- plasmidSPAdes
- RNA-SPAdes
- 基因组组装
keywords:
- isolate assembly
- metagenome assembly
- plasmid
- transcriptome
- 组装
- 宏基因组
capabilities:
- isolate genome assembly
- metaSPAdes assembly
- plasmid assembly
- RNA-SPAdes transcriptome assembly
inputs:
- paired or single FASTQ reads
- interlaced FASTQ reads
- optional trusted or untrusted contigs
outputs:
- contigs.fasta
- scaffolds.fasta
- assembly_graph.fastg
- spades.log
upstream:
- seqkit
downstream:
- prodigal
- bwa
- bowtie2
- metabat2
- maxbin2
- concoct
- bakta
- abricate
- genomad
- checkv
software_family: spades
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Parameter | Meaning and setting rule |'
- '| `-1`, `-2`, `-s`, `--12` | Declare read layout exactly; wrong layout invalidates graph construction. |'
- '| `--isolate` | Optimized for high-coverage isolate data; do not use for mixed communities. |'
- '| `--meta` | metaSPAdes mode for metagenomes; some standard options such as careful correction may be unsupported. |'
- '| `--plasmid` | PlasmidSPAdes mode; interpret circular/plasmid candidates with coverage and annotation evidence. |'
- '| `--rna` | RNA-SPAdes mode; output represents transcripts, not genomic scaffolds. |'
- '| `--careful` | Attempts mismatch/indel reduction for isolate assembly; costs time and is not a universal metagenome flag.
  |'
- '| `-k` | K-mer sizes. Defaults adapt to read length; custom values must be odd, increasing, and below read length. |'
- '| `--cov-cutoff` | Coverage-based contig cutoff. `auto` suits many isolates; avoid aggressive cutoffs in uneven metagenomes.
  |'
- '| `--only-assembler` | Skip read error correction when reads are already corrected or when resuming a controlled workflow.
  |'
- '| `--trusted-contigs`, `--untrusted-contigs` | Add prior contigs with different confidence. Use only when provenance and
  biological compatibility are clear. |'
- '| `--continue` | Resume with unchanged parameters after interruption. |'
- '| `--restart-from` | Restart a selected checkpoint; verify which parameters may legally change. |'
- '| `-t`, `-m`, `-o` | Threads, memory in GB, and new output directory. Reserve memory headroom and never merge runs in one
  directory. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# SPAdes

Select the mode that matches the sample. Use `--meta` for metagenomes and `--careful` only where its assumptions are appropriate.

```bash
conda run -n microbiome --no-capture-output spades.py --meta -1 reads_R1.fastq.gz -2 reads_R2.fastq.gz -o spades_out
```

Inspect `spades.log`, `contigs.fasta`, `scaffolds.fasta`, and assembly statistics before downstream use.

## Capabilities and selection

SPAdes is a mode-driven assembler. Standard SPAdes targets isolate genomes, `--meta` invokes metaSPAdes, `--plasmid` targets plasmid sequence, and `--rna`/RNA-SPAdes targets transcriptomes. These modes are not interchangeable. Select one according to the biological sample and installed-version help rather than treating every FASTQ pair as an isolate.

Use standard SPAdes for cultured isolates and metaSPAdes for manageable metagenomes where extra memory is acceptable. MEGAHIT is often more practical for very large metagenomes. Assembly does not by itself establish completeness, taxonomic identity, or absence of contamination.

## Inputs and upstream

| Input | Required format | Typical producer | Checks before use |
| --- | --- | --- | --- |
| Paired reads | FASTQ/FASTQ.GZ with `-1/-2` and optional library number | read QC pipeline | synchronized mates and correct orientation |
| Single reads | FASTQ/FASTQ.GZ with `-s` | orphan read output | no duplicate use as paired reads |
| Interleaved pairs | FASTQ/FASTQ.GZ with `--12` | preprocessing pipeline | alternating mate records |
| Trusted/untrusted contigs | nucleotide FASTA | earlier assembly or known references | same organism/context; avoid reference-driven contamination |
| Long reads | FASTQ/FASTA via installed-version long-read options | ONT/PacBio preprocessing | only for supported hybrid modes |

SeqKit can validate records and basic lengths. Input quality trimming and contamination decisions belong upstream and must be documented.

## Outputs and downstream

`contigs.fasta` contains unambiguous contigs; `scaffolds.fasta` can include gaps and should not be substituted silently. `assembly_graph.fastg`/GFA and path files preserve graph evidence. `spades.log` and `params.txt` are required provenance.

Isolate or MAG contigs can feed Prodigal/Bakta, ABRicate, BWA/Bowtie 2, or phylogenomic extraction. metaSPAdes contigs can feed MetaBAT 2, MaxBin 2, CONCOCT, geNomad, and CheckV. RNA-SPAdes transcripts can feed Salmon, but do not send transcript contigs into prokaryotic genome binning.

## Parameters and decision rules

| Parameter | Meaning and setting rule |
| --- | --- |
| `-1`, `-2`, `-s`, `--12` | Declare read layout exactly; wrong layout invalidates graph construction. |
| `--isolate` | Optimized for high-coverage isolate data; do not use for mixed communities. |
| `--meta` | metaSPAdes mode for metagenomes; some standard options such as careful correction may be unsupported. |
| `--plasmid` | PlasmidSPAdes mode; interpret circular/plasmid candidates with coverage and annotation evidence. |
| `--rna` | RNA-SPAdes mode; output represents transcripts, not genomic scaffolds. |
| `--careful` | Attempts mismatch/indel reduction for isolate assembly; costs time and is not a universal metagenome flag. |
| `-k` | K-mer sizes. Defaults adapt to read length; custom values must be odd, increasing, and below read length. |
| `--cov-cutoff` | Coverage-based contig cutoff. `auto` suits many isolates; avoid aggressive cutoffs in uneven metagenomes. |
| `--only-assembler` | Skip read error correction when reads are already corrected or when resuming a controlled workflow. |
| `--trusted-contigs`, `--untrusted-contigs` | Add prior contigs with different confidence. Use only when provenance and biological compatibility are clear. |
| `--continue` | Resume with unchanged parameters after interruption. |
| `--restart-from` | Restart a selected checkpoint; verify which parameters may legally change. |
| `-t`, `-m`, `-o` | Threads, memory in GB, and new output directory. Reserve memory headroom and never merge runs in one directory. |

## Workflow patterns

```bash
conda run -n seqkit --no-capture-output seqkit stats isolate_R1.fastq.gz isolate_R2.fastq.gz
conda run -n microbiome --no-capture-output spades.py \
  --isolate --careful -1 isolate_R1.fastq.gz -2 isolate_R2.fastq.gz \
  -t 16 -m 64 -o spades_isolate
```

For a metagenome replace isolate flags with `--meta`, then map reads back to `contigs.fasta` before binning. For transcriptomes select RNA-SPAdes and quantify resulting transcript FASTA with Salmon.

## Validation and failure handling

Require exit code zero and inspect the final section of `spades.log`; file existence alone is insufficient because SPAdes may leave partial outputs. Check total size, contig/scaffold count, N50, maximum length, ambiguous bases, graph complexity, and read mapping. A memory failure calls for more memory, fewer threads, or MEGAHIT, not arbitrary sample splitting. Poor isolate assembly can result from contamination, uneven coverage, wrong mode, or adapter/error burden. If `--continue` rejects changed options, restart into a new directory and preserve the failed run for diagnosis.
