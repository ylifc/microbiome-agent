---
name: Cutadapt
description: Precise adapter, primer, poly-A and quality trimming for single-end and paired-end sequencing reads.
kind: software
id: cutadapt
version: 2
selection_tier: default
environment: biomni-cutadapt
executables:
- cutadapt
packages:
- cutadapt
channels:
- conda-forge
- bioconda
tasks:
- adapter removal
- amplicon primer trimming
- poly-A trimming
- quality trimming
- paired-end read filtering
databases: []
aliases:
- Cutadapt
- cutadapt
- 接头去除
- 引物去除
keywords:
- adapter trimming
- primer trimming
- paired-end
- amplicon
- quality
- demultiplexing
- 接头
- 引物
capabilities:
- remove 3'/5' adapters and primers
- trim low-quality ends
- filter by length and quality
- demultiplex inline barcodes
- handle paired-end synchronized trimming
inputs:
- FASTQ (single or paired)
- adapter/primer sequences
outputs:
- trimmed FASTQ
- optional per-read or summary reports
upstream:
- sra-toolkit
downstream:
- fastp
- dada2
- vsearch
- bowtie2
- spades
- megahit
software_family: cutadapt
documentation_status: CURATED_PROSE
parameter_guidance:
- '| `-a`/`-A`, `-g`/`-G` | 3'' and 5'' adapter/primer sequences for forward/reverse reads. |'
- '| `^` prefix | Anchor a 5'' primer to the read start for strict primer trimming. |'
- '| `-q` | Trim low-quality 3'' bases below this Phred score. |'
- '| `-m` / `-M` | Minimum/maximum read length; discard pairs failing the minimum. |'
- '| `--discard-untrimmed` | Drop reads missing the primer (amplicon); keep them for shotgun screening. |'
- '| `--pair-filter=both` / `any` | Require both or any mate to pass filtering. |'
- '| `-e` | Maximum allowed error rate for adapter matching (default 0.1). |'
- '| `-j` | Cores. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# Cutadapt

Use Cutadapt for precise adapter and primer removal, especially amplicon primers and the anchored/anchored-linker trimming DADA2/QIIME 2 expect. It is deterministic and keeps mate files synchronized for paired-end data.

```bash
# Remove Illumina 3' adapter and trim low-quality tails
conda run -n biomni-cutadapt --no-capture-output cutadapt \
  -a AGATCGGAAGAGCACACGTCTGAACTCCAGTCA -A AGATCGGAAGAGCGTCGTGTAGGGAAAGAGTGT \
  -q 20 -m 30 -o R1.trim.fastq.gz -p R2.trim.fastq.gz R1.fastq.gz R2.fastq.gz

# Remove amplicon primers with anchors (forward primer on R1, reverse primer on R2)
conda run -n biomni-cutadapt --no-capture-output cutadapt \
  -g ^CCTACGGGNGGCWGCAG -G ^GGACTACHVGGGTATCTAATCC --discard-untrimmed \
  -o R1.trim.fastq.gz -p R2.trim.fastq.gz R1.fastq.gz R2.fastq.gz
```

## Capabilities and selection

Cutadapt removes 3' adapters (`-a`/`-A`), 5' adapters (`-g`/`-G`), anchored (fixed-position) adapters, poly-A tails, and low-quality ends, and can filter reads by length or quality. Use it for primer/anchor trimming upstream of DADA2/QIIME 2, or as a precise alternative to fastp's adapter detection when sequences are known. Prefer fastp for general short-read QC and MultiQC-integrated reports; they can be composed (Cutadapt for primers, then fastp for quality).

## Inputs and upstream

Input is FASTQ from the sequencer or SRA. For amplicon, pass the exact primer sequences and use `^` anchoring when primers must be at read start. Paired-end adapters use `-A`/`-G` for the reverse read; Cutadapt trims both mates together and drops pairs where one mate fails length filtering.

## Outputs and downstream

Outputs are trimmed FASTQ files plus a summary of how many reads had adapters/primers, how many were too short, and basepair trimming. Feed trimmed reads to DADA2/QIIME 2 (amplicon), or fastp/Bowtie2/SPAdes/MEGAHIT (WGS/meta).

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `-a`/`-A`, `-g`/`-G` | 3' and 5' adapter/primer sequences for forward/reverse reads. |
| `^` prefix | Anchor a 5' primer to the read start for strict primer trimming. |
| `-q` | Trim low-quality 3' bases below this Phred score. |
| `-m` / `-M` | Minimum/maximum read length; discard pairs failing the minimum. |
| `--discard-untrimmed` | Drop reads missing the primer (amplicon); keep them for shotgun screening. |
| `--pair-filter=both` / `any` | Require both or any mate to pass filtering. |
| `-e` | Maximum allowed error rate for adapter matching (default 0.1). |
| `-j` | Cores. |

## Workflow patterns

Use anchored Cutadapt primer removal before denoising, or adapter trimming before general QC, then hand reads to fastp/DADA2/QIIME2 (amplicon) or Bowtie2/SPAdes (WGS). Confirm primer removal with the expected amplicon length.

```bash
conda run -n biomni-cutadapt --no-capture-output cutadapt \
  -g ^CCTACGGGNGGCWGCAG -G ^GGACTACHVGGGTATCTAATCC --discard-untrimmed \
  -o R1.trim.fastq.gz -p R2.trim.fastq.gz R1.fastq.gz R2.fastq.gz
```

## Validation and failure handling

Record adapter/primer sequences, error rate, and per-step retention. Near-zero retention usually means a wrong primer/adapter sequence or a strand/format mismatch. For amplicon, confirm primer removal with expected amplicon length before denoising.
