---
name: Salmon
description: Fast transcript-level abundance estimation from RNA-seq reads.
kind: software
id: salmon
version: 2
environment: microbiome
executables:
- salmon
packages:
- salmon
channels:
- conda-forge
- bioconda
tasks:
- transcript quantification
- RNA-seq abundance estimation
databases: []
aliases:
- Salmon
- transcript quantifier
- 转录本定量
- 基因丰度
keywords:
- RNA-seq
- transcript abundance
- TPM
- counts
- metatranscriptome
- 定量
- 丰度
capabilities:
- transcriptome indexing
- mapping-based quantification
- selective alignment
- library-type inference
inputs:
- transcript or gene nucleotide FASTA
- single or paired FASTQ reads
- optional decoy-aware genome
outputs:
- quant.sf abundance table
- auxiliary mapping and library metadata
- Salmon index
upstream:
- seqkit
- prodigal
- spades
downstream:
- maxbin2
software_family: salmon
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Parameter | Meaning and setting rule |'
- '| `salmon index -t` / `-i` | Target FASTA and index directory. Rebuild if any target sequence or name changes. |'
- '| `-k` during indexing | K-mer length. Defaults suit common read lengths; reduce only for short reads with sensitivity/specificity
  tradeoff. |'
- '| `--decoys` | Decoy sequence-name list for a combined transcriptome+genome index. Recommended for selective alignment
  when available. |'
- '| `--keepDuplicates` | Retain duplicate target sequences instead of collapsing; needed only when duplicate IDs/sequences
  carry intended meaning. |'
- '| `quant -i` / `-o` | Existing index and new sample-specific output directory. |'
- '| `-l A` | Automatically infer library type. Review inference; specify an explicit library type when protocol is known
  and inference is ambiguous. |'
- '| `-1`, `-2`, `-r` | Paired mates or single reads. Never mix layouts in one quant command. |'
- '| `-p` | Threads within allocated resources. |'
- '| `--validateMappings` | Selective-alignment validation; generally improves specificity and should be considered for modern
  workflows. |'
- '| `--gcBias`, `--seqBias`, `--posBias` | Model GC, sequence, or positional bias. Enable based on protocol/sample bias and
  resource budget, not automatically. |'
- '| `--numBootstraps N` | Generate inferential replicates for uncertainty-aware downstream tools; increases time and disk.
  |'
- '| `--numGibbsSamples N` | Alternative inferential sampling; do not combine casually with bootstraps. |'
- '| `--writeMappings` | Emit mapping information to stdout; large and only needed by a compatible downstream consumer. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# Salmon

Build a sample-specific transcriptome index when needed, then quantify each library into a separate directory.

```bash
conda run -n microbiome --no-capture-output salmon index -t transcripts.fasta -i salmon_index
conda run -n microbiome --no-capture-output salmon quant -i salmon_index -l A -1 reads_R1.fastq.gz -2 reads_R2.fastq.gz -o quant/sample
```

Validate `quant.sf`, mapping rate, library type inference, and transcript identifiers.

## Capabilities and selection

Salmon builds a transcript/gene-sequence index and estimates abundance from RNA-seq or metatranscriptomic reads without producing a conventional BAM by default. It reports estimated counts and TPM while accounting for effective length and multi-mapping. It does not perform differential expression, genome assembly, or gene prediction.

Use a transcriptome from a trusted annotation, RNA-SPAdes, or Prodigal nucleotide CDS when gene-level metatranscriptomic abundance is intended. The index and annotation must represent the same sequence identifiers used downstream. For genome-aware eukaryotic quantification, prefer a decoy-aware index rather than a transcript-only index when resources permit.

## Inputs and upstream

| Input | Required format | Typical producer | Checks before use |
| --- | --- | --- | --- |
| Target sequences | nucleotide FASTA | reference annotation, Prodigal `-d`, RNA-SPAdes | unique IDs, correct strand/content, no protein FASTA |
| Decoy list/genome | text list plus genome FASTA in combined target | genome-aware index preparation | names match combined FASTA exactly |
| Reads | single or paired FASTQ/FASTQ.GZ | RNA-seq QC | mate synchronization, strandedness known or inferable |

## Outputs and downstream

`quant.sf` columns are target name, length, effective length, TPM, and estimated read count. `aux_info/`, `lib_format_counts.json`, logs, and optional bootstrap/Gibbs samples provide diagnostics and uncertainty. Count matrices may feed differential-abundance/statistical tools after transcript-to-gene mapping; TPM should not be treated as raw counts. Abundance tables can support MaxBin 2 only after transforming to the exact contig/sequence abundance format it expects.

## Parameters and decision rules

| Parameter | Meaning and setting rule |
| --- | --- |
| `salmon index -t` / `-i` | Target FASTA and index directory. Rebuild if any target sequence or name changes. |
| `-k` during indexing | K-mer length. Defaults suit common read lengths; reduce only for short reads with sensitivity/specificity tradeoff. |
| `--decoys` | Decoy sequence-name list for a combined transcriptome+genome index. Recommended for selective alignment when available. |
| `--keepDuplicates` | Retain duplicate target sequences instead of collapsing; needed only when duplicate IDs/sequences carry intended meaning. |
| `quant -i` / `-o` | Existing index and new sample-specific output directory. |
| `-l A` | Automatically infer library type. Review inference; specify an explicit library type when protocol is known and inference is ambiguous. |
| `-1`, `-2`, `-r` | Paired mates or single reads. Never mix layouts in one quant command. |
| `-p` | Threads within allocated resources. |
| `--validateMappings` | Selective-alignment validation; generally improves specificity and should be considered for modern workflows. |
| `--gcBias`, `--seqBias`, `--posBias` | Model GC, sequence, or positional bias. Enable based on protocol/sample bias and resource budget, not automatically. |
| `--numBootstraps N` | Generate inferential replicates for uncertainty-aware downstream tools; increases time and disk. |
| `--numGibbsSamples N` | Alternative inferential sampling; do not combine casually with bootstraps. |
| `--writeMappings` | Emit mapping information to stdout; large and only needed by a compatible downstream consumer. |

## Workflow patterns

```bash
conda run -n microbiome --no-capture-output salmon index \
  -t genes.fna -i salmon_index -k 31
conda run -n microbiome --no-capture-output salmon quant \
  -i salmon_index -l A -1 sample_R1.fastq.gz -2 sample_R2.fastq.gz \
  --validateMappings --gcBias -p 12 -o quant/sample
```

Use one quantification directory per biological library. Combine tables by stable target IDs only after checking that every sample used the same index release.

## Validation and failure handling

Require `quant.sf`, nonzero assigned fragments when expression is expected, plausible mapping rate, and a library-type distribution consistent with the protocol. Near-zero mapping suggests wrong target/reference, DNA/protein input confusion, contamination, read-quality issues, or identifier/content mismatch. Extremely high multi-mapping can reflect redundant targets; decide whether duplicate isoforms/genes should be retained. Never compare TPM across incompatible target indices.
