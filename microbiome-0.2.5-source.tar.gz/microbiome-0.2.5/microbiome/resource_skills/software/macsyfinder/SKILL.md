---
name: MacSyFinder
description: Detection of macromolecular systems (conjugation, secretion, defense, motility) from annotated protein sets using
  HMM models.
kind: software
id: macsyfinder
version: 2
selection_tier: conditional
environment: biomni-macsyfinder
executables:
- macsyfinder
- macsydata
packages:
- macsyfinder
channels:
- conda-forge
- bioconda
tasks:
- conjugation system detection
- type IV secretion system detection
- defense system detection
- HGT machinery annotation
databases:
- macsyfinder
aliases:
- MacSyFinder
- MacSyFinder v2
- conjugation detection
- 接合系统检测
- 分泌系统检测
keywords:
- conjugation
- T4SS
- secretion
- defense
- HGT
- HMM
- mobility
- 接合
- 分泌
- 水平基因转移
capabilities:
- detect complete macromolecular systems from proteomes
- search multi-gene systems with HMM profiles
- assess system completeness and quorum
- support TXSScan CONJScan DefenseFinder models
inputs:
- predicted protein FASTA
- MacSyFinder model definitions (e.g. CONJScan)
- optional GFF for ordered systems
outputs:
- system hits
- per-system gene composition
- completeness and quorum assessment
upstream:
- prodigal
- bakta
downstream: []
software_family: macsyfinder
documentation_status: CURATED_PROSE
downstream_tasks:
- mobile-element annotation
- HGT interpretation
- defense/secretome profiling
parameter_guidance:
- '| `--sequence-db` | Predicted protein FASTA. |'
- '| `--models` | REQUIRED: which models to search (e.g. `CONJScan/Chromosome all` or `CONJScan/Plasmids all`). |'
- '| `--db-type` | `ordered_replicon` for gene-order-aware complete genomes, `unordered` for unordered protein sets. |'
- '| `--replicon-topology` | `circular`/`linear`; affects boundary detection. |'
- '| `-w` | Workers. |'
- '| `macsydata install <Model>` | One-time model download (e.g. `CONJScan`, `TXSScan`, `DefenseFinder`); record the model
  version. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# MacSyFinder

Use MacSyFinder to detect macromolecular systems — notably conjugation systems (CONJScan), secretion systems (TXSScan) and defense systems (DefenseFinder) — from predicted proteomes. These systems are the machinery of horizontal gene transfer, so MacSyFinder is a core tool for HGT detection.

```bash
# install models once, then detect conjugation systems
conda run -n biomni-macsyfinder --no-capture-output macsydata install CONJScan
conda run -n biomni-macsyfinder --no-capture-output macsyfinder \
  --sequence-db proteins.faa --db-type ordered_replicon \
  --models CONJScan/Chromosome all --replicon-topology circular -w 8 -o macsyfinder_out
```

## Capabilities and selection

MacSyFinder searches protein sets for multi-gene systems using HMM profiles, assessing system presence, completeness, and quorum. Prefer it to answer "does this genome encode a conjugation/type-IV-secretion/defense system?", which directly supports HGT interpretation. It consumes protein predictions, not raw reads.

## Inputs and upstream

Inputs are a predicted-protein FASTA from Prodigal/Bakta and the chosen model set (`macsydata install CONJScan`; `macsydata` is an alias for `msf_data`). Provide the corresponding GFF/ordered replicon when systems must respect gene order. Record the model set and version.

## Outputs and downstream

Outputs are system hits with per-system gene composition and completeness/quorum. Feed conjugation-system calls into HGT interpretation and mobile-element annotation, and cross-check with geNomad mobility genes.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `--sequence-db` | Predicted protein FASTA. |
| `--models` | REQUIRED: which models to search (e.g. `CONJScan/Chromosome all` or `CONJScan/Plasmids all`). |
| `--db-type` | `ordered_replicon` for gene-order-aware complete genomes, `unordered` for unordered protein sets. |
| `--replicon-topology` | `circular`/`linear`; affects boundary detection. |
| `-w` | Workers. |
| `macsydata install <Model>` | One-time model download (e.g. `CONJScan`, `TXSScan`, `DefenseFinder`); record the model version. |

## Workflow patterns

```bash
conda run -n biomni-macsyfinder --no-capture-output macsydata install CONJScan
conda run -n biomni-macsyfinder --no-capture-output macsyfinder \
  --sequence-db proteins.faa --db-type ordered_replicon \
  --models CONJScan/Chromosome all --replicon-topology circular -w 8 -o macsyfinder_out
```

## Validation and failure handling

Record the model set and version. A missing model directory is the usual failure — run `macsydata install` first. Distinguish a complete system (strong HGT machinery evidence) from a partial/vestigial hit; report completeness and quorum, not just presence. Cross-check conjugation calls with geNomad mobility genes and plasmid typing.

## Reproducibility and audit

Record MacSyFinder version, model set/version, `--db-type`, and topology. Re-run and diff the system table to confirm determinism. Keep the model set immutable and document its provenance.
