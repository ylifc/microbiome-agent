---
name: DIAMOND
description: Fast protein alignment for Swiss-Prot, COG, NR, and TCDB annotation.
kind: software
id: diamond
version: 2
environment: microbiome
executables:
- diamond
packages:
- diamond
channels:
- conda-forge
- bioconda
tasks:
- protein annotation
- translated search
- functional annotation
databases:
- swissprot
- cog
- nr
- tcdb
aliases:
- DIAMOND
- fast BLAST
- 蛋白比对
- 功能注释
keywords:
- blastp
- blastx
- protein homology
- annotation
- taxonomy
- alignment
- 蛋白
- 同源
capabilities:
- protein to protein search
- translated nucleotide to protein search
- DIAMOND database construction
- taxonomic and functional hit reporting
inputs:
- protein FASTA for blastp
- nucleotide FASTA for blastx
- DIAMOND dmnd database
outputs:
- tabular hits
- pairwise or SAM-like alignment formats where supported
- optional unaligned or aligned query FASTA
upstream:
- prodigal
- bakta
- seqkit
downstream: []
software_family: diamond
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Parameter | Meaning and setting rule |'
- '| `makedb --in`, `--db` | Build a `.dmnd` from protein FASTA. Keep source FASTA/release metadata in the database folder.
  |'
- '| `blastp` / `blastx` | Select protein or translated-nucleotide query mode; molecule-type errors can produce meaningless
  or failed searches. |'
- '| `--query`, `--db`, `--out` | Query FASTA, database prefix/file, and output. Bind to registry-verified paths. |'
- '| `--outfmt 6 FIELDS...` | Tabular output with explicit columns. Never assume default columns when downstream code expects
  coverage/taxonomy fields. |'
- '| `--fast`, `--mid-sensitive`, `--sensitive`, `--more-sensitive`, `--very-sensitive`, `--ultra-sensitive` | Sensitivity
  presets supported by recent versions. Increase for remote homology at added compute and possible weak hits. Verify local
  help. |'
- '| `--evalue` | Maximum expected random matches. Combine with score/coverage; large databases require careful thresholds.
  |'
- '| `--min-score` | Minimum bit score, an alternative/additional strength cutoff. |'
- '| `--id` | Minimum percent identity. Avoid universal cutoffs across protein families/evolutionary distances. |'
- '| `--query-cover`, `--subject-cover` | Minimum aligned coverage percentages. Essential to reject short domain-only matches
  when full-length annotation is intended. |'
- '| `-k`, `--max-target-seqs` | Maximum target sequences retained. Small values can hide ambiguity; do not equate `-k 1`
  with rigorous best-hit orthology. |'
- '| `--top` | Keep hits within a score percentage of the top hit, useful for ambiguity-aware reporting. |'
- '| `--max-hsps` | Limit HSPs per target. Multiple domains/repeats may require more than one. |'
- '| `--range-culling` | Suppress lower-scoring hits covered by stronger query ranges; useful for domain-aware searches with
  caution. |'
- '| `--masking`, `--comp-based-stats` | Low-complexity masking/compositional correction. Keep defaults unless benchmarked
  for the target family. |'
- '| `--threads` | CPU allocation. Avoid oversubscription when processing many samples. |'
- '| `--block-size`, `--index-chunks`, `--tmpdir` | Memory/performance controls. Reduce block size or increase chunks under
  memory pressure; ensure temp disk capacity. |'
- '| `--strand` | For `blastx`, restrict translated query strand only when orientation is known. |'
- '| `--query-gencode` | Genetic code for nucleotide translation. Match organism/organelle biology. |'
- '| `--frameshift` | Frameshift-aware alignment penalty for long/error-prone reads; do not enable on clean proteins. |'
- '| `--taxonlist`, `--taxon-exclude` | Restrict by taxonomy only when the database contains compatible taxonomy mappings.
  |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# DIAMOND

Use for protein `blastp` or nucleotide-to-protein `blastx` searches against a local `.dmnd` database.

Run each command through the skill environment, for example:

```bash
conda run -n microbiome --no-capture-output diamond blastp --query proteins.faa --db Database/swissprot/swissprot.dmnd --out hits.tsv --outfmt 6
```

Do not activate the environment persistently. Verify the query and `.dmnd` file before execution and check that the result table is non-empty afterward.

## Capabilities and selection

DIAMOND accelerates protein homology search. `blastp` compares protein query to protein database; `blastx` translates nucleotide query in reading frames and searches protein space. It can build `.dmnd` indexes and emit customizable tabular fields. It is not a nucleotide-to-nucleotide aligner and a hit is not automatically a validated functional assignment.

Use Swiss-Prot for curated, narrower annotation; COG for orthologous functional categories; NR for broad but noisy coverage; TCDB for transporter-focused hypotheses. Database release, sensitivity, coverage, identity, e-value, and hit-selection policy jointly determine interpretation.

## Inputs and upstream

Protein FASTA commonly comes from Prodigal or Bakta. Nucleotide contigs/CDS feed `blastx` when genes are not pre-called or frameshifts are possible. The database must be a READY `.dmnd` in its own `Database/<id>/` directory. Query IDs must be unique and stable.

## Outputs and downstream

Tabular format 6 is preferred for parsing. Explicitly name fields such as `qseqid sseqid pident length mismatch gapopen qstart qend sstart send evalue bitscore qcovhsp scovhsp`. Results feed functional summaries, taxonomy-aware filtering, best-hit/orthology logic, and manual review. Preserve multiple hits when ambiguity or paralogy matters.

## Parameters and decision rules

| Parameter | Meaning and setting rule |
| --- | --- |
| `makedb --in`, `--db` | Build a `.dmnd` from protein FASTA. Keep source FASTA/release metadata in the database folder. |
| `blastp` / `blastx` | Select protein or translated-nucleotide query mode; molecule-type errors can produce meaningless or failed searches. |
| `--query`, `--db`, `--out` | Query FASTA, database prefix/file, and output. Bind to registry-verified paths. |
| `--outfmt 6 FIELDS...` | Tabular output with explicit columns. Never assume default columns when downstream code expects coverage/taxonomy fields. |
| `--fast`, `--mid-sensitive`, `--sensitive`, `--more-sensitive`, `--very-sensitive`, `--ultra-sensitive` | Sensitivity presets supported by recent versions. Increase for remote homology at added compute and possible weak hits. Verify local help. |
| `--evalue` | Maximum expected random matches. Combine with score/coverage; large databases require careful thresholds. |
| `--min-score` | Minimum bit score, an alternative/additional strength cutoff. |
| `--id` | Minimum percent identity. Avoid universal cutoffs across protein families/evolutionary distances. |
| `--query-cover`, `--subject-cover` | Minimum aligned coverage percentages. Essential to reject short domain-only matches when full-length annotation is intended. |
| `-k`, `--max-target-seqs` | Maximum target sequences retained. Small values can hide ambiguity; do not equate `-k 1` with rigorous best-hit orthology. |
| `--top` | Keep hits within a score percentage of the top hit, useful for ambiguity-aware reporting. |
| `--max-hsps` | Limit HSPs per target. Multiple domains/repeats may require more than one. |
| `--range-culling` | Suppress lower-scoring hits covered by stronger query ranges; useful for domain-aware searches with caution. |
| `--masking`, `--comp-based-stats` | Low-complexity masking/compositional correction. Keep defaults unless benchmarked for the target family. |
| `--threads` | CPU allocation. Avoid oversubscription when processing many samples. |
| `--block-size`, `--index-chunks`, `--tmpdir` | Memory/performance controls. Reduce block size or increase chunks under memory pressure; ensure temp disk capacity. |
| `--strand` | For `blastx`, restrict translated query strand only when orientation is known. |
| `--query-gencode` | Genetic code for nucleotide translation. Match organism/organelle biology. |
| `--frameshift` | Frameshift-aware alignment penalty for long/error-prone reads; do not enable on clean proteins. |
| `--taxonlist`, `--taxon-exclude` | Restrict by taxonomy only when the database contains compatible taxonomy mappings. |

## Workflow patterns

```bash
conda run -n microbiome --no-capture-output diamond blastp \
  --query proteins.faa --db Database/swissprot/swissprot.dmnd \
  --sensitive --evalue 1e-5 --query-cover 60 --subject-cover 40 \
  --max-target-seqs 25 --threads 16 \
  --out hits.tsv --outfmt 6 qseqid sseqid pident length evalue bitscore qcovhsp scovhsp
```

For broad discovery, retain several hits and classify confidence from score, coverage, identity, database curation, and agreement among resources. Do not silently transfer a full protein name from a short conserved domain.

## Validation and failure handling

Verify query molecule type/count, database readiness/release, output schema, hit count, no-hit fraction, score/e-value distributions, and coverage. Empty results can be biologically valid but first exclude wrong `.dmnd`, malformed query, overly strict filters, or molecule mismatch. Out-of-memory errors call for smaller block size/more index chunks. A database-format/version error requires rebuilding from the local source under the declared environment, not downloading during execution.
