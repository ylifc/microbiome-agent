---
name: Mash
description: Fast MinHash genome sketching for large-scale distance estimation, containment and contamination screening.
kind: software
id: mash
version: 2
selection_tier: conditional
environment: biomni-mash
executables:
- mash
packages:
- mash
channels:
- conda-forge
- bioconda
tasks:
- genome distance and clustering
- containment and contamination screening
- reference database sketching
databases:
- reference-genomes
aliases:
- Mash
- mash
- MinHash
- 基因组距离
- 污染筛查
keywords:
- MinHash
- sketching
- distance
- containment
- contamination
- genome comparison
- 基因组距离
capabilities:
- sketch genomes into compact signatures
- estimate Mash distance and p-values
- screen reads against reference sketches
- cluster genomes by distance
inputs:
- genome/assembly FASTA or reads
- one or more reference sketches
outputs:
- distance matrix
- containment/screen results
- sketch files
upstream:
- spades
- flye
- unicycler
downstream:
- fastani
- drep
- gtdbtk
software_family: mash
documentation_status: CURATED_PROSE
downstream_tasks:
- taxonomy and contamination triage
parameter_guidance:
- '| `sketch -s` | Sketch size (default 1000); larger improves resolution. |'
- '| `-k` | K-mer size; must match across sketches being compared. |'
- '| `dist` | Pairwise distance between a sketch file and a query sketch/FASTA. |'
- '| `screen -w` | Winner-take-all containment screening of reads against references. |'
- '| `-p` | Threads. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# Mash

Use Mash for fast genome-level distance estimation and containment screening. It is useful for quickly finding the closest reference to a new isolate, clustering many genomes, and screening metagenomes for contamination.

```bash
# Sketch a reference set, then measure distance to a query
conda run -n biomni-mash --no-capture-output mash sketch -o refs.msh refs/*.fna
conda run -n biomni-mash --no-capture-output mash dist refs.msh query.fa > query.mash.dist

# Screen reads against references for containment/contamination
conda run -n biomni-mash --no-capture-output mash screen -w refs.msh sample_R1.fastq.gz sample_R2.fastq.gz > screen.tsv
```

## Capabilities and selection

Mash sketches sequences into fixed-size MinHash signatures and computes approximate distance and containment rapidly, scaling to huge reference collections. Prefer Mash for fast triage (nearest reference, contamination screen); confirm biological conclusions with fastANI (ANI) or dRep because Mash distances are approximate and sketch-size dependent. `skani` offers an ANI-calibrated modern alternative for the same use cases.

## Inputs and upstream

Inputs are genome FASTA files for `sketch`, and reads or FASTA for `dist`/`screen`. Sketches are portable and should be versioned with the reference set. Sketch size (`-s`) trades resolution against size/runtime.

## Outputs and downstream

`dist` outputs reference-query pairs with Mash distance and p-value; `screen` reports per-reference containment and multi-matching. Feed nearest references into fastANI for exact ANI, or into GTDB-Tk/dRep for taxonomy and dereplication.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `sketch -s` | Sketch size (default 1000); larger improves resolution. |
| `-k` | K-mer size; must match across sketches being compared. |
| `dist` | Pairwise distance between a sketch file and a query sketch/FASTA. |
| `screen -w` | Winner-take-all containment screening of reads against references. |
| `-p` | Threads. |

## Workflow patterns

Sketch a reference set once, then use `mash dist` for nearest-reference triage and `mash screen` for contamination screening. Escalate borderline results to fastANI/dRep/GTDB-Tk.

```bash
conda run -n biomni-mash --no-capture-output mash sketch -o refs.msh refs/*.fna
conda run -n biomni-mash --no-capture-output mash dist refs.msh query.fa > query.mash.dist
```

## Validation and failure handling

Use a consistent k-mer size and sketch size across all sketches in a comparison; mismatched sketches yield misleading distances. Treat Mash distance as a screening signal, not a definitive ANI or taxonomy. For borderline calls, escalate to fastANI/dRep/GTDB-Tk.
