---
name: snp-dists
description: Fast pairwise SNP distance matrices from equal-length nucleotide alignments.
kind: software
id: snp-dists
version: 2
selection_tier: default
environment: biomni-snp-dists
executables:
- snp-dists
packages:
- snp-dists
channels:
- conda-forge
- bioconda
tasks:
- pairwise SNP distance
- outbreak neighbor screening
- alignment comparison
databases: []
aliases:
- snp-dists
- SNP distance matrix
- SNP距离矩阵
keywords:
- pairwise distance
- SNP threshold
- core alignment
- outbreak cluster
- TSV matrix
capabilities:
- calculate all-by-all nucleotide difference counts
- report tabular sample distance matrix
inputs:
- equal-length nucleotide multi-FASTA alignment with unique sample names
outputs:
- symmetric tab-delimited pairwise SNP distance matrix
upstream:
- snp-sites
- snippy
- gubbins
- mafft
downstream:
- iqtree2
software_family: snp-dists
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Interface | Meaning and setting rule |'
- '| positional alignment | Required equal-length FASTA; stdin may be used only with explicit provenance. |'
- '| `-j CPUS` | Parallel comparison threads; bound to allocated CPUs. |'
- '| `-a` | Count all character differences instead of only A/C/G/T comparisons; use only when gaps/ambiguities are intended
  evidence. |'
- '| `-k` | Preserve case; useful when lowercase bases encode masks that should not be treated as uppercase calls. |'
- '| `-m` | Emit three-column molten pairs instead of a square matrix. |'
- '| `-t` | Add headers to molten output; meaningful only with `-m`. |'
- '| `-L` | Emit the lower triangle only to avoid duplicate symmetric pairs. |'
- '| `-c` | Use comma-separated rather than tab-separated output. |'
- '| `-b` | Leave the top-left matrix cell blank instead of writing tool name/version. |'
- '| `-x INT` | Stop counting beyond a distance ceiling; only use when exact larger distances are irrelevant. |'
- '| `-q` | Suppress progress messages, not errors. |'
- '| stdout | Redirect to a named `.tsv`; treat empty stdout as failure. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# snp-dists

Use snp-dists for transparent pairwise screening and clustering support. A SNP distance is not a phylogenetic tree or evidence of transmission direction.

## Capabilities and selection

snp-dists counts pairwise nucleotide differences across an alignment and writes a simple matrix that is easy to validate. Use it on the same masked/recombination-filtered alignment used for inference. Do not compare matrices generated from different references, core definitions, masks, or missing-data policies.

## Inputs and upstream

Input is aligned multi-FASTA from Snippy, Gubbins, MAFFT, or SNP-sites. Sequences must be equal length and names unique. Decide whether to use full-core or SNP-only alignment and record how gaps, Ns, ambiguities, and invariant sites are handled by the installed version.

## Outputs and downstream

Output is a square TSV matrix with sample names as headers/rows. It supports nearest-neighbor screening, QC outlier detection, and candidate cluster selection before tree reconstruction. Keep the source alignment checksum with the matrix.

## Parameters and decision rules

| Interface | Meaning and setting rule |
| --- | --- |
| positional alignment | Required equal-length FASTA; stdin may be used only with explicit provenance. |
| `-j CPUS` | Parallel comparison threads; bound to allocated CPUs. |
| `-a` | Count all character differences instead of only A/C/G/T comparisons; use only when gaps/ambiguities are intended evidence. |
| `-k` | Preserve case; useful when lowercase bases encode masks that should not be treated as uppercase calls. |
| `-m` | Emit three-column molten pairs instead of a square matrix. |
| `-t` | Add headers to molten output; meaningful only with `-m`. |
| `-L` | Emit the lower triangle only to avoid duplicate symmetric pairs. |
| `-c` | Use comma-separated rather than tab-separated output. |
| `-b` | Leave the top-left matrix cell blank instead of writing tool name/version. |
| `-x INT` | Stop counting beyond a distance ceiling; only use when exact larger distances are irrelevant. |
| `-q` | Suppress progress messages, not errors. |
| stdout | Redirect to a named `.tsv`; treat empty stdout as failure. |

## Workflow patterns

```bash
conda run -n biomni-snp-dists --no-capture-output snp-dists core.filtered.aln > core.snp_distances.tsv
```

Any epidemiological threshold must be supplied by an organism/study policy, not inferred from this software.

For machine joins, prefer a square TSV with the default header or molten `-m -t`; declare the schema before parsing.

Count comparisons across callable A/C/G/T sites by default. Enabling `-a` changes the metric by counting gaps and ambiguous symbols and must never be mixed with default distances.

## Validation and failure handling

Require a square symmetric matrix, zero diagonal, integer nonnegative entries, row/column name identity, expected sample count, and distances not exceeding comparable alignment sites. Unexpected zeros suggest duplicate samples or excessive masking; extreme distances suggest wrong reference/species or contamination. Missing-data policy must be reported with every threshold analysis.
