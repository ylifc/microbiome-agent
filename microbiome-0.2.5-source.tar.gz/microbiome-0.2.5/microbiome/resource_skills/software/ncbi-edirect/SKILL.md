---
name: NCBI Entrez Direct
description: Official command-line access to NCBI E-utilities for metadata queries and accession-pinned nucleotide or protein
  retrieval.
kind: software
id: ncbi-edirect
version: 3
selection_tier: default
environment: biomni-ncbi-edirect
executables:
- esearch
- esummary
- efetch
- xtract
packages:
- entrez-direct
channels:
- conda-forge
- bioconda
tasks:
- NCBI metadata search
- accession resolution
- nucleotide sequence retrieval
- protein sequence retrieval
- structured XML extraction
databases: []
optional_databases:
- reference-sequences
aliases:
- EDirect
- Entrez Direct
- efetch
- NCBI E-utilities
- NCBI序列下载
keywords:
- NCBI
- Entrez
- esearch
- esummary
- efetch
- xtract
- nuccore
- protein
- accession
capabilities:
- compose fielded Entrez queries
- fetch exact accession records
- return FASTA GenBank GenPept XML and tabular metadata
inputs:
- reviewed Entrez query or exact accession versions
- NCBI database name
- explicit output format
outputs:
- Entrez XML
- accession metadata tables
- nucleotide or protein FASTA
- GenBank or GenPept flat files
upstream: []
downstream:
- seqkit
- ncbi-blast
- mafft
- iqtree2
- minimap2
software_family: ncbi-edirect
documentation_status: CURATED_PROSE
upstream_tasks:
- user biological target
- publication accessions
- NCBI Datasets reports
downstream_tasks:
- reference-sequences
parameter_guidance:
- '| `-db nuccore` | Nucleotide records including genomic regions, transcripts, plasmids and organelles. |'
- '| `-db protein` | Protein records; do not submit nucleotide accessions. |'
- '| `-query` | Use field tags such as `[Organism]`, `[Gene Name]`, `[Accession]`; review ambiguity before transfer. |'
- '| `-id` | Comma-separated reviewed UIDs or accessions. Prefer accession versions for reproducibility. |'
- '| `-format fasta` | Sequence-only interoperability for aligners, mappers and search tools. |'
- '| `-format gbwithparts` | Nucleotide flat file with features and component context. |'
- '| `-format gp` | Protein flat file with annotations. |'
- '| `-retmax` | Bound metadata discovery; never use a huge value to bypass review. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# NCBI Entrez Direct

Use Entrez Direct for NCBI objects that are not best represented by a structured Datasets package: individual nucleotide records, transcripts, gene regions, plasmids, proteins and fielded metadata searches. Use NCBI Datasets for whole genome assemblies and SRA Toolkit only for reviewed run accessions.

## Capabilities and selection

`esearch` selects records, `esummary` inspects identity and size, `efetch` retrieves content, and `xtract` parses XML structurally. Planning may perform metadata-only ESearch/ESummary through the controlled resolver. Sequence transfer with `efetch` requires the confirmed reference-sequences acquisition marker.

Prefer EDirect over ad hoc HTTP parsing when Entrez supports the object. Prefer NCBI Datasets for structured assembly packages, gget for supported Ensembl and virus workflows, and SRA Toolkit for raw run reads.

## Inputs and upstream

Inputs are a reviewed Entrez query or exact accession versions, the correct NCBI database, and a declared output format. Queries may originate from publications, locus annotations, NCBI Datasets reports, or user-supplied identifiers.

Resolve symbols and organism names before transfer. Approximate species names first pass through `resolve_fuzzy_species_name()` and become an explicit TaxID. A gene symbol alone is not stable: combine fielded gene, `txidNNN[Organism:exp]`, molecule and RefSeq filters when appropriate, then inspect every candidate.

## Outputs and downstream

Metadata commands produce Entrez XML or extracted tables. `efetch` produces nucleotide/protein FASTA, GenBank, GenPept or XML. Preserve exact accession versions and the retrieval database in provenance.

FASTA feeds SeqKit, BLAST databases, mapping, MAFFT and IQ-TREE 2. Flat files feed feature-aware extraction and annotation comparison. Build indexes only after record-count and identity checks.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `-db nuccore` | Nucleotide records including genomic regions, transcripts, plasmids and organelles. |
| `-db protein` | Protein records; do not submit nucleotide accessions. |
| `-query` | Use field tags such as `[Organism]`, `[Gene Name]`, `[Accession]`; review ambiguity before transfer. |
| `-id` | Comma-separated reviewed UIDs or accessions. Prefer accession versions for reproducibility. |
| `-format fasta` | Sequence-only interoperability for aligners, mappers and search tools. |
| `-format gbwithparts` | Nucleotide flat file with features and component context. |
| `-format gp` | Protein flat file with annotations. |
| `-retmax` | Bound metadata discovery; never use a huge value to bypass review. |

## Workflow patterns

Run every command in the isolated environment:

```bash
conda run -n biomni-ncbi-edirect --no-capture-output esearch -db nuccore -query 'rpoB[Gene Name] AND Escherichia coli[Organism]' | conda run -n biomni-ncbi-edirect --no-capture-output esummary
conda run -n biomni-ncbi-edirect --no-capture-output efetch -db nuccore -id NC_000913.3 -format fasta
conda run -n biomni-ncbi-edirect --no-capture-output efetch -db protein -id NP_414543.1 -format gp
```

The Agent's controlled downloader avoids shell pipelines and redirects by writing `efetch` stdout to an atomic temporary file.

For natural-language retrieval with an already exact organism, call `resolve_reference_sequence_accessions()` in planning mode, review the candidates, call `plan_reference_sequence_download()` with exact versions, and wait for confirmation before `download_reference_sequences(..., approved=True)`. For an approximate species name plus a gene/locus/protein request, call `plan_species_reference_download()`; it resolves TaxID first and refuses to run without a separate targeted sequence query.

## Validation and failure handling

Check exit status, non-empty output, parsed record count, accession identity and SHA-256. HTTP/rate errors may be retried with backoff. Zero records, wrong molecule type, suppression or merged accessions require a new metadata lookup and plan revision. Never change databases or broaden a query during confirmed execution merely to obtain a non-empty result.
