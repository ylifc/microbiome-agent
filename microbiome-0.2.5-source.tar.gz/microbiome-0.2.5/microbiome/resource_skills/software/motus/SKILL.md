---
name: mOTUs
description: Marker-based community profiling / 标记基因物种丰度
kind: software
id: motus
version: 3
selection_tier: conditional
documentation_status: DOCUMENTED
software_family: motus
environment: microbiome-motus
executables:
- motus
packages:
- motus
channels:
- conda-forge
- bioconda
tasks:
- Marker-based community profiling / 标记基因物种丰度
databases:
- motus
aliases:
- mOTUs
- motus
keywords:
- motus
- Marker-based community profiling / 标记基因物种丰度
capabilities:
- Marker-based community profiling / 标记基因物种丰度
inputs:
- quality-controlled shotgun reads
outputs:
- mOTU abundance profile
- mapping and marker coverage diagnostics
upstream:
- fastp
- kneaddata
downstream:
- phyloseq
- maaslin3
parameter_guidance:
- 'profile -f/-r or -s: paired and single-end sources are distinct.'
- '-db: exact compatible immutable mOTUs database root.'
- '-o and -t: explicit output path and bounded thread count.'
validation:
- Validate version and required package/functions before use.
- Run the task on representative data and require output assertions.
failure_handling:
- Do not mix profiles generated from incompatible mOTUs releases.
- Consult version-matched Knowledge history; repair only in an approved maintenance phase.
references:
- https://github.com/motu-tool/mOTUs
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# mOTUs

## Capabilities and selection

Marker-based community profiling / 标记基因物种丰度.
Select this capability only when its input and statistical assumptions match the study.
Catalog documentation does not assert that this software is installed or task-validated.

## Inputs and upstream

- quality-controlled shotgun reads

Keep sample identifiers, feature identifiers, orientation, units and reference releases explicit.
Reject missing inputs rather than acquiring substitutes during analysis.

## Outputs and downstream

- mOTU abundance profile
- mapping and marker coverage diagnostics

Save the complete invocation, output schema, software version and database fingerprints.
Do not overwrite raw data, reference resources or outputs from a different run.

## Parameters and decision rules

- profile -f/-r or -s: paired and single-end sources are distinct.
- -db: exact compatible immutable mOTUs database root.
- -o and -t: explicit output path and bounded thread count.

The reference below is the full manual source. This catalog covers the supported task decisions;
option availability and defaults must be checked against the installed version and captured help.
Unknown values must not be guessed. Package functions are verified independently of R/Python.

## Workflow patterns

The following is a discovery probe, not a successful analysis recipe:

```bash
conda run -n microbiome-motus --no-capture-output motus --help
```

Resolve the actual environment prefix first. During production replay the frozen argv and paths.
R/Python workflows require a reviewed adapter with explicit parameters and output assertions.

## Validation and failure handling

Correct: use aligned input IDs, the approved method, compatible reference resources and validated outputs.
Incorrect: Do not mix profiles generated from incompatible mOTUs releases.
A zero exit code without output validation is unverified history.
On failure record the complete command, exit code, stderr, version, input and database context.
Promote a repair only after a matching regression validation report passes.

## References and documentation coverage

- Official source: https://github.com/motu-tool/mOTUs
- Documentation reviewed for catalog integration; this is not a local runtime acceptance claim.
- Parameter coverage: curated task guidance; full version-specific help is captured on discovery.
