---
name: PAML
description: Likelihood-based molecular evolution, selection analysis, and molecular dating.
kind: software
id: paml
version: 2
environment: microbiome
executables:
- codeml
- baseml
- mcmctree
version_args: []
packages:
- paml
channels:
- conda-forge
- bioconda
tasks:
- selection analysis
- codon models
- nucleotide models
- molecular dating
databases: []
aliases:
- PAML
- codeml
- baseml
- mcmctree
- 正选择
- 分子钟
keywords:
- codon model
- dN dS
- selection
- branch site
- molecular dating
- likelihood
- 选择压力
capabilities:
- codon substitution and selection models
- nucleotide substitution models
- approximate-likelihood Bayesian molecular dating
inputs:
- strictly formatted aligned sequences
- matching Newick tree
- explicit codeml baseml or mcmctree control file
outputs:
- likelihood and parameter reports
- ancestral or rate outputs
- MCMC samples and summary files
upstream:
- mafft
- muscle
- iqtree2
- iqtree3
downstream: []
software_family: paml
documentation_status: CURATED_PROSE
parameter_guidance:
- '### Shared control-file bindings'
- '| Parameter | Meaning and setting rule |'
- '| `seqfile`, `treefile`, `outfile` | Exact input alignment, matching tree, and unique output. Resolve paths before run.
  |'
- '| `noisy`, `verbose` | Progress/detail level. Keep enough diagnostics for first runs. |'
- '| `runmode` | User tree, pairwise, or tree-search behavior depending on program. Use a fixed known topology for most comparative
  tests. |'
- '| `cleandata` | Complete-case deletion versus retaining ambiguity/gaps according to program. This can change sites/taxa
  and must be reported. |'
- '### codeml'
- '| Parameter | Meaning and setting rule |'
- '| `seqtype` | Codon versus amino-acid analysis. Positive-selection tests require codon data. |'
- '| `CodonFreq` | Codon-frequency model (e.g. equal/F1x4/F3x4/Fcodon variants). Compare/model deliberately. |'
- '| `icode` | Genetic code. Must match Prodigal/biology and absence of true stop codons. |'
- '| `clock` | No/global/local clock options. Most selection tests use no clock. |'
- '| `model` | Branch/site structure: one ratio, free ratios, user foreground branches, etc. Exact combinations define the
  hypothesis. |'
- '| `NSsites` | Site-class models. Common comparisons include M1a vs M2a and M7 vs M8; branch-site Model A uses a specific
  `model` combination. |'
- '| `fix_kappa`, `kappa` | Fix or estimate transition/transversion ratio and its starting value. |'
- '| `fix_omega`, `omega` | Fix or estimate dN/dS and starting value. Branch-site null often fixes omega=1 according to the
  formal test. |'
- '| `fix_alpha`, `alpha`, `ncatG` | Rate-heterogeneity controls/categories. Do not add incompatible complexity without sufficient
  data. |'
- '| `getSE` | Request standard errors where supported; can add computation. |'
- '| `RateAncestor` | Reconstruct ancestral states/rates where supported; retain posterior uncertainty. |'
- '| `method` | Optimization method. Run multiple starting omega/kappa values to detect local optima. |'
- '### baseml and mcmctree'
- '| Parameter | Meaning and setting rule |'
- '| `model` in baseml | Nucleotide substitution model index; choose from justified model family. |'
- '| `usedata` in mcmctree | Prior-only, exact likelihood, approximate likelihood, or gradient/Hessian preparation mode depending
  on version. Follow the required multi-run workflow. |'
- '| `clock` in mcmctree | Global, independent-rates, or autocorrelated-rates clock model. Compare sensitivity. |'
- '| `RootAge` and tree calibrations | Bounds/prior on root and fossils. Avoid conflicting or overly precise calibrations.
  |'
- '| `BDparas` | Birth-death-sampling tree prior parameters. Justify biologically. |'
- '| `rgene_gamma`, `sigma2_gamma` | Priors for overall rate and among-lineage rate variance. Sensitivity analysis is essential.
  |'
- '| `kappa_gamma`, `alpha_gamma` | Priors for substitution parameters. |'
- '| `finetune` | Proposal step sizes. Adjust from pilot acceptance rates, not final posterior preference. |'
- '| `burnin`, `sampfreq`, `nsample` | MCMC burn-in, thinning, and retained samples. Determine from convergence/ESS, not a
  fixed ritual. |'
- '| `seed` | Independent chain seed where available. Run at least two independent chains. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# PAML

Prepare explicit control files and keep their relative input paths valid from the command working directory.

```bash
conda run -n microbiome --no-capture-output codeml codeml.ctl
conda run -n microbiome --no-capture-output mcmctree mcmctree.ctl
```

Review control settings, sequence/tree label agreement, likelihood convergence, and output warnings before interpretation.

## Capabilities and selection

PAML is a family of likelihood/Bayesian programs controlled by text files. `codeml` fits codon/amino-acid models including branch, site, and branch-site selection tests; `baseml` fits nucleotide models; `mcmctree` estimates divergence times using calibrations and approximate/full likelihood modes. PAML does not align sequences, choose valid homologs, detect recombination, or design a statistically valid likelihood-ratio comparison.

Selection analysis requires orthologous, frame-preserving codon alignments without internal stops and a matching phylogeny. Recombination, paralogy, saturation, alignment error, and multinucleotide substitutions can create false positive selection. Molecular dating requires defensible calibrations/priors and convergence across independent chains.

## Inputs and upstream

Sequence files usually use PAML-compatible PHYLIP-like format; taxon names must exactly match the Newick tree. Codon alignments should be projected from protein alignments made by MAFFT/MUSCLE. IQ-TREE can provide a topology, but model/branch lengths may be re-estimated. Control-file relative paths resolve from the process working directory. Calibration syntax belongs in the MCMCtree tree file and must be reviewed.

## Outputs and downstream

Outputs include main text reports, likelihoods, parameter estimates, ancestral/rate files, rst/rub/lnf intermediates, and MCMC sample files. Likelihood-ratio tests require extracting comparable lnL and parameter counts from paired models; multiple testing and boundary distributions must be handled statistically. MCMC samples feed convergence/ESS and posterior summaries, not just a final tree.

## Parameters and decision rules

### Shared control-file bindings

| Parameter | Meaning and setting rule |
| --- | --- |
| `seqfile`, `treefile`, `outfile` | Exact input alignment, matching tree, and unique output. Resolve paths before run. |
| `noisy`, `verbose` | Progress/detail level. Keep enough diagnostics for first runs. |
| `runmode` | User tree, pairwise, or tree-search behavior depending on program. Use a fixed known topology for most comparative tests. |
| `cleandata` | Complete-case deletion versus retaining ambiguity/gaps according to program. This can change sites/taxa and must be reported. |

### codeml

| Parameter | Meaning and setting rule |
| --- | --- |
| `seqtype` | Codon versus amino-acid analysis. Positive-selection tests require codon data. |
| `CodonFreq` | Codon-frequency model (e.g. equal/F1x4/F3x4/Fcodon variants). Compare/model deliberately. |
| `icode` | Genetic code. Must match Prodigal/biology and absence of true stop codons. |
| `clock` | No/global/local clock options. Most selection tests use no clock. |
| `model` | Branch/site structure: one ratio, free ratios, user foreground branches, etc. Exact combinations define the hypothesis. |
| `NSsites` | Site-class models. Common comparisons include M1a vs M2a and M7 vs M8; branch-site Model A uses a specific `model` combination. |
| `fix_kappa`, `kappa` | Fix or estimate transition/transversion ratio and its starting value. |
| `fix_omega`, `omega` | Fix or estimate dN/dS and starting value. Branch-site null often fixes omega=1 according to the formal test. |
| `fix_alpha`, `alpha`, `ncatG` | Rate-heterogeneity controls/categories. Do not add incompatible complexity without sufficient data. |
| `getSE` | Request standard errors where supported; can add computation. |
| `RateAncestor` | Reconstruct ancestral states/rates where supported; retain posterior uncertainty. |
| `method` | Optimization method. Run multiple starting omega/kappa values to detect local optima. |

### baseml and mcmctree

| Parameter | Meaning and setting rule |
| --- | --- |
| `model` in baseml | Nucleotide substitution model index; choose from justified model family. |
| `usedata` in mcmctree | Prior-only, exact likelihood, approximate likelihood, or gradient/Hessian preparation mode depending on version. Follow the required multi-run workflow. |
| `clock` in mcmctree | Global, independent-rates, or autocorrelated-rates clock model. Compare sensitivity. |
| `RootAge` and tree calibrations | Bounds/prior on root and fossils. Avoid conflicting or overly precise calibrations. |
| `BDparas` | Birth-death-sampling tree prior parameters. Justify biologically. |
| `rgene_gamma`, `sigma2_gamma` | Priors for overall rate and among-lineage rate variance. Sensitivity analysis is essential. |
| `kappa_gamma`, `alpha_gamma` | Priors for substitution parameters. |
| `finetune` | Proposal step sizes. Adjust from pilot acceptance rates, not final posterior preference. |
| `burnin`, `sampfreq`, `nsample` | MCMC burn-in, thinning, and retained samples. Determine from convergence/ESS, not a fixed ritual. |
| `seed` | Independent chain seed where available. Run at least two independent chains. |

## Workflow patterns

```bash
conda run -n microbiome --no-capture-output codeml codeml.alt.ctl
conda run -n microbiome --no-capture-output codeml codeml.null.ctl
conda run -n microbiome --no-capture-output mcmctree mcmctree.ctl
```

Keep every model in a separate directory because PAML uses fixed auxiliary filenames. Predefine null/alternative models and run several starting values. For MCMCtree approximate likelihood, preserve the gradient/Hessian artifact and prove it corresponds to the same alignment/tree/model.

## Validation and failure handling

Check taxon/sequence counts, codon frame and stops, matching labels, convergence messages, finite lnL, repeated-start agreement, parameter bounds, and expected output files. For MCMC, compare independent chains, ESS, traces, posterior/prior overlap, and calibration behavior. `oom`/NaN/extreme omega can indicate too little information, alignment/paralogy problems, local optima, or boundary estimates. Never report positive selection from one unvalidated omega>1 value; use the correct nested test, multiple-testing control, site evidence, and biological context.
