---
name: dRep
description: Genome dereplication, comparison, and representative selection for microbial genomes and MAGs.
kind: software
id: drep
version: 2
environment: drep
executables:
- dRep
packages:
- drep
channels:
- conda-forge
- bioconda
tasks:
- genome dereplication
- MAG comparison
- representative genome selection
databases:
- checkm
aliases:
- dRep
- genome dereplication
- 基因组去冗余
- MAG去冗余
keywords:
- ANI
- Mash
- secondary clustering
- representative
- completeness
- contamination
- 去冗余
capabilities:
- genome or MAG dereplication
- primary Mash and secondary ANI clustering
- quality-based representative selection
- genome comparison
inputs:
- multiple uniquely named genome or MAG nucleotide FASTA files
- optional external quality table
outputs:
- dereplicated representative FASTA
- cluster tables
- quality and comparison tables
- figures and work database
upstream:
- checkm
- metabat2
- maxbin2
- concoct
downstream:
- gtdbtk
- bakta
software_family: drep
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Parameter | Meaning and setting rule |'
- '| `dRep dereplicate WORKDIR -g GENOMES...` | Full dereplication workflow. Glob expansion must produce the intended files.
  |'
- '| `dRep compare` | Compute comparisons/clusters without representative selection where appropriate. |'
- '| `-p` | Threads for Mash/ANI/quality stages. |'
- '| `--genomeInfo TABLE` | External completeness/contamination and optional strain values. Validate required columns/name
  mapping. |'
- '| `--ignoreGenomeQuality` | Skip quality calculation/filtering. Only for already validated quality input or comparison-only
  use. |'
- '| `-comp`, `-con` | Minimum completeness and maximum contamination thresholds. Report exclusions. |'
- '| `-l`, `--length` | Minimum genome length filter (default 50000). N50/size are scoring weights (`-N50W`, `-sizeW`), not
  filters. |'
- '| `-pa` | Primary clustering ANI/Mash threshold. Controls candidates entering expensive comparison. |'
- '| `-sa` | Secondary ANI threshold defining final clusters, commonly around 0.95 for species-like groups. |'
- '| `-nc` | Minimum aligned fraction/coverage for secondary comparisons. Prevent high ANI on tiny overlaps. |'
- '| `-cm` | Coverage calculation method (e.g. larger/total) according to version; changes cluster boundaries. |'
- '| `--S_algorithm` | Secondary comparator such as fastANI/ANImf/skani where supported. Record algorithm/version. |'
- '| `--SkipMash`, `--SkipSecondary` | Skip clustering phases only when required prior data exist and are compatible. |'
- '| `--multiround_primary_clustering`, `--primary_chunksize` | Scale primary clustering for large collections; assess chunk/order
  effects. |'
- '| `--greedy_secondary_clustering` | Faster non-exhaustive secondary clustering where supported; can be order-sensitive.
  |'
- '| `--clusterAlg` | Linkage algorithm for clustering; changes chain/cluster behavior. |'
- '| `-ms` | Mash sketch size. Larger improves precision at compute/memory cost. |'
- '| `-comW`, `-conW`, `-strW`, `-N50W`, `-sizeW`, `-centW` | Representative scoring weights. Set before inspecting preferred
  winners and report them. |'
- '| `--extra_weight_table`, `-extraW` | Add external quality priorities. Ensure scale and missing values are controlled.
  |'
- '| warning thresholds | Alignment/similarity warning parameters flag unstable clusters; investigate rather than suppress.
  |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# dRep

Use a new work directory and provide genome FASTA files with unique names.

```bash
conda run -n drep --no-capture-output dRep dereplicate drep_out -g genomes/*.fasta -p 8
```

The CheckM database skill must be READY when quality filtering is enabled. Inspect clustering tables, quality metrics, warnings, and selected representatives.

## Capabilities and selection

dRep groups similar genomes using a fast primary screen followed by secondary ANI comparison and selects representatives with configurable quality scoring. It can compare genomes without dereplication and can use internal CheckM or an external genome-info table. It does not improve bins, infer taxonomy, or prove strains are ecologically interchangeable.

Use after CheckM quality assessment and before GTDB-Tk/Bakta when a nonredundant genome set is desired. ANI and alignment-coverage thresholds define the biological resolution; 95% ANI is often species-like but is not universally appropriate for every clade/question.

## Inputs and upstream

Input genomes/MAGs are nucleotide FASTA with unique basenames. Avoid spaces and basename collisions across directories. Quality data must map exactly to those names. Do not combine viral and cellular genomes or unrelated marker conventions in one run. Preserve the complete input manifest and checksums.

## Outputs and downstream

`dereplicated_genomes/` contains representatives. `data_tables/` includes genome information, primary/secondary clusters, comparison metrics, and winners; `figures/` and the work database support audit/restart. Representatives feed GTDB-Tk and Bakta. Cluster membership must accompany any nonredundant result so excluded genomes remain traceable.

## Parameters and decision rules

| Parameter | Meaning and setting rule |
| --- | --- |
| `dRep dereplicate WORKDIR -g GENOMES...` | Full dereplication workflow. Glob expansion must produce the intended files. |
| `dRep compare` | Compute comparisons/clusters without representative selection where appropriate. |
| `-p` | Threads for Mash/ANI/quality stages. |
| `--genomeInfo TABLE` | External completeness/contamination and optional strain values. Validate required columns/name mapping. |
| `--ignoreGenomeQuality` | Skip quality calculation/filtering. Only for already validated quality input or comparison-only use. |
| `-comp`, `-con` | Minimum completeness and maximum contamination thresholds. Report exclusions. |
| `-l`, `--length` | Minimum genome length filter (default 50000). N50/size are scoring weights (`-N50W`, `-sizeW`), not filters. |
| `-pa` | Primary clustering ANI/Mash threshold. Controls candidates entering expensive comparison. |
| `-sa` | Secondary ANI threshold defining final clusters, commonly around 0.95 for species-like groups. |
| `-nc` | Minimum aligned fraction/coverage for secondary comparisons. Prevent high ANI on tiny overlaps. |
| `-cm` | Coverage calculation method (e.g. larger/total) according to version; changes cluster boundaries. |
| `--S_algorithm` | Secondary comparator such as fastANI/ANImf/skani where supported. Record algorithm/version. |
| `--SkipMash`, `--SkipSecondary` | Skip clustering phases only when required prior data exist and are compatible. |
| `--multiround_primary_clustering`, `--primary_chunksize` | Scale primary clustering for large collections; assess chunk/order effects. |
| `--greedy_secondary_clustering` | Faster non-exhaustive secondary clustering where supported; can be order-sensitive. |
| `--clusterAlg` | Linkage algorithm for clustering; changes chain/cluster behavior. |
| `-ms` | Mash sketch size. Larger improves precision at compute/memory cost. |
| `-comW`, `-conW`, `-strW`, `-N50W`, `-sizeW`, `-centW` | Representative scoring weights. Set before inspecting preferred winners and report them. |
| `--extra_weight_table`, `-extraW` | Add external quality priorities. Ensure scale and missing values are controlled. |
| warning thresholds | Alignment/similarity warning parameters flag unstable clusters; investigate rather than suppress. |

## Workflow patterns

```bash
conda run -p /home/ylifc/anaconda3/envs/drep --no-capture-output dRep dereplicate drep_out \
  -g genomes/*.fasta -p 16 --genomeInfo checkm.genomeInfo.csv \
  -comp 50 -con 10 -pa 0.90 -sa 0.95 -nc 0.30
```

Run GTDB-Tk/Bakta on representatives, but retain cluster tables for mapping annotations back to all members. For strain-level work, design stricter ANI/coverage and comparator choices instead of reusing a species-level recipe.

## Validation and failure handling

Check input count, quality-filter exclusions, primary/secondary cluster counts, pairwise ANI/coverage distributions, warnings, representative score components, and copied representative files. Basename collisions or quality-table mismatches can silently lose genomes. Missing dependencies change available algorithms and must be fixed in the declared environment. Unexpected cluster chaining calls for inspecting linkage, ANI, coverage, and representative comparisons, not manually moving genomes without a record.
