---
name: BWA
description: Burrows-Wheeler read alignment against nucleotide references.
kind: software
id: bwa
version: 2
environment: microbiome
executables:
- bwa
version_args: []
packages:
- bwa
channels:
- conda-forge
- bioconda
tasks:
- short-read alignment
- coverage mapping
- variant-analysis alignment
databases: []
aliases:
- BWA-MEM
- read mapper
- 短读长比对
keywords:
- alignment
- mapping
- coverage
- variant calling
- reads
- 比对
- 覆盖度
capabilities:
- short-read mapping
- paired-end mapping
- coverage alignment
- variant-calling alignment
inputs:
- reference nucleotide FASTA plus BWA index
- single or paired FASTQ reads
outputs:
- SAM alignment stream
- BWA reference index sidecars
upstream:
- seqkit
- megahit
- spades
- pvga
downstream:
- samtools
software_family: bwa
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Parameter | Meaning and setting rule |'
- '| `bwa index -p PREFIX` | Build an index with an explicit prefix. Rebuild whenever reference sequence content changes.
  |'
- '| `bwa mem -t N` | Alignment threads. Coordinate with SAMtools threads and allocated CPUs. |'
- '| `-R ''@RG...''` | Add read group. Required for robust multi-sample/lane provenance; escape tabs correctly. |'
- '| `-M` | Mark shorter split hits as secondary for compatibility with older duplicate/Picard workflows; do not add blindly.
  |'
- '| `-a` | Output all alignments, increasing size; needed only when downstream logic handles secondary hits explicitly. |'
- '| `-T` | Minimum alignment score to output. Raising increases specificity and can remove divergent/short mappings. |'
- '| `-k` | Minimum seed length. Lower values increase sensitivity and compute for divergent reads. |'
- '| `-w` | Band width for gapped extension; increase only for expected long indels. |'
- '| `-A`, `-B` | Match score and mismatch penalty. Keep defaults unless a validated assay requires a custom error model.
  |'
- '| `-O`, `-E` | Gap-open and gap-extension penalties. Changes affect indel representation and variant calling. |'
- '| `-L` | Clipping penalty. Lower clipping penalty can increase soft clipping; inspect CIGARs. |'
- '| `-Y` | Use soft clipping for supplementary alignments when required by downstream tooling. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# BWA

Build indexes beside the workflow reference and keep all generated sidecar files together.

```bash
conda run -n microbiome --no-capture-output bwa index reference.fasta
conda run -n microbiome --no-capture-output bwa mem -t 8 reference.fasta reads_R1.fastq.gz reads_R2.fastq.gz
```

Pipe alignment output into the declared SAMtools environment command, then verify mapped-read and reference statistics.

## Capabilities and selection

BWA indexes nucleotide references and aligns short reads. `bwa mem` is the normal choice for modern Illumina reads and supports paired-end alignment and split alignments. It is useful for assembly coverage, variant calling, and read recruitment. It does not perform trimming, duplicate marking, BAM sorting, or variant calling.

Use BWA when its scoring and MEM behavior fit the workflow or when downstream methods expect BWA-style alignments. Bowtie 2 is an alternative for host filtering and configurable local/end-to-end alignment. Whichever mapper is selected, map every sample against the exact same assembly used by the next stage.

## Inputs and upstream

The reference is nucleotide FASTA from an assembly, curated genome, viral backbone, or bin set. `bwa index` creates `.amb`, `.ann`, `.bwt`, `.pac`, and `.sa` sidecars. Reads are FASTQ/FASTQ.GZ from QC or host-filtering workflows. Reference sequence names must be unique and must not change between indexing, alignment, depth generation, and variant interpretation.

## Outputs and downstream

`bwa mem` writes SAM to stdout. Stream it directly into `samtools sort` to avoid a large intermediate SAM. Coordinate-sorted BAM then feeds SAMtools statistics/depth, MetaBAT 2/CONCOCT coverage, or BCFtools variant calling. Preserve read groups for multi-sample calling.

## Parameters and decision rules

| Parameter | Meaning and setting rule |
| --- | --- |
| `bwa index -p PREFIX` | Build an index with an explicit prefix. Rebuild whenever reference sequence content changes. |
| `bwa mem -t N` | Alignment threads. Coordinate with SAMtools threads and allocated CPUs. |
| `-R '@RG...'` | Add read group. Required for robust multi-sample/lane provenance; escape tabs correctly. |
| `-M` | Mark shorter split hits as secondary for compatibility with older duplicate/Picard workflows; do not add blindly. |
| `-a` | Output all alignments, increasing size; needed only when downstream logic handles secondary hits explicitly. |
| `-T` | Minimum alignment score to output. Raising increases specificity and can remove divergent/short mappings. |
| `-k` | Minimum seed length. Lower values increase sensitivity and compute for divergent reads. |
| `-w` | Band width for gapped extension; increase only for expected long indels. |
| `-A`, `-B` | Match score and mismatch penalty. Keep defaults unless a validated assay requires a custom error model. |
| `-O`, `-E` | Gap-open and gap-extension penalties. Changes affect indel representation and variant calling. |
| `-L` | Clipping penalty. Lower clipping penalty can increase soft clipping; inspect CIGARs. |
| `-Y` | Use soft clipping for supplementary alignments when required by downstream tooling. |

## Workflow patterns

```bash
conda run -n microbiome --no-capture-output bwa index assembly.fasta
conda run -n microbiome --no-capture-output bash -lc \
  "bwa mem -t 12 -R '@RG\\tID:S1\\tSM:S1' assembly.fasta S1_R1.fastq.gz S1_R2.fastq.gz | \
   samtools sort -@ 4 -o S1.sorted.bam -"
conda run -n microbiome --no-capture-output samtools index S1.sorted.bam
```

Because BWA and SAMtools currently share `microbiome`, this pipe is valid. If their skills later declare different environments, write SAM/BAM between separate `conda run` calls instead of assuming a shared shell.

## Validation and failure handling

Check index sidecars, exit status of every pipeline component, BAM quickcheck/flagstat, mapped fraction, proper-pair fraction, insert-size plausibility, duplicate policy, and reference names. A zero mapping rate usually means wrong reference/sample, read corruption, incompatible molecule type, or severe divergence. Broken pipes can hide an upstream BWA failure; enable shell pipe failure handling or run stages separately. Never use a BAM aligned to another assembly to compute contig depth.
