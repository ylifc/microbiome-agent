---
name: Medaka
description: Oxford Nanopore neural-network consensus polishing for compatible basecaller models.
kind: software
id: medaka
version: 2
selection_tier: conditional
environment: microbiome-medaka
executables:
- medaka_consensus
- medaka_variant
packages:
- medaka
channels:
- conda-forge
- bioconda
tasks:
- ONT consensus polishing
- ONT variant calling
databases: []
aliases:
- Medaka
- ONT polishing
- Nanopore consensus
- 纳米孔纠错
keywords:
- Oxford Nanopore
- ONT
- basecaller model
- neural consensus
- polishing
capabilities:
- model-aware ONT consensus correction
- variant calling against a draft
inputs:
- ONT reads
- draft assembly
- compatible Medaka model
outputs:
- consensus.fasta
- alignment and model inference intermediates
upstream:
- flye
- racon
- minimap2
downstream:
- quast
- bakta
software_family: medaka
documentation_status: CURATED_PROSE
downstream_tasks:
- variant review
parameter_guidance:
- '| `medaka_consensus -m` | Model name; must match the basecaller chemistry/model. |'
- '| `-i` / `-d` | Input reads and draft assembly. |'
- '| `-o` | Output directory. |'
- '| `-t` | Threads. |'
- '| `medaka_variant` | Variant calling against the draft; report the model. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# Use Medaka only for Oxford Nanopore reads and only after identifying a model compatible with the basecaller chemistry/model. It is not a PacBio or Illumina polisher.

## Capabilities and selection

Medaka performs neural-network consensus polishing and variant calling using a model trained for a specific ONT basecaller/chemistry. It is model-aware, so the selected model must match the reads' basecalling model. Use it after Racon polishing when a compatible model exists; otherwise Racon alone is sufficient. It is not a substitute for Illumina-based polishing (Pilon).

## Inputs and upstream

Inputs are ONT reads, a draft assembly (Flye/Racon output), and a compatible Medaka model. Run after minimap2/Racon, and record the exact basecaller and model name so the correct Medaka model is selected.

## Outputs and downstream

Outputs are a polished `consensus.fasta`, alignment and model-inference intermediates, and optionally a VCF. Run QUAST before/after to quantify the polishing delta, then annotate with Bakta.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `medaka_consensus -m` | Model name; must match the basecaller chemistry/model. |
| `-i` / `-d` | Input reads and draft assembly. |
| `-o` | Output directory. |
| `-t` | Threads. |
| `medaka_variant` | Variant calling against the draft; report the model. |

## Workflow patterns

```bash
conda run -n microbiome-medaka --no-capture-output medaka_consensus \
  -i reads.fastq.gz -d draft.fa -m r1041_e82_400bps_sup_v5.0.0 -t 16 -o medaka_out
```

## Validation and failure handling

Record the exact Medaka model and basecaller. A model mismatch silently degrades polishing, so verify the model before running. Compare pre/post QUAST and inspect the change delta; an unexpectedly large change count may indicate a wrong model or mismapped reads.

## Reproducibility and audit

Record the exact Medaka model, the basecaller, and the software version beside the consensus output. Re-run on a small subset and confirm identical consensus bases to verify determinism. Never report a polished genome without the model name, since model choice changes the result.

```bash
# provenance: capture version and model
conda run -n microbiome-medaka --no-capture-output medaka_consensus --version
```

Record the CPU allocation and model; current medaka is CPU-only.
