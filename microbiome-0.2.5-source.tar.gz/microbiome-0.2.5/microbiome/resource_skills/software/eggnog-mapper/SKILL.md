---
name: eggNOG-mapper
description: Orthology-based functional annotation of microbial proteins with eggNOG reference data.
kind: software
id: eggnog-mapper
version: 2
selection_tier: default
environment: microbiome-eggnog-mapper
executables:
- emapper.py
- download_eggnog_data.py
packages:
- eggnog-mapper
channels:
- conda-forge
- bioconda
tasks:
- microbial protein functional annotation
- orthology assignment
- COG KEGG GO and EC mapping
databases:
- eggnog-mapper
aliases:
- eggNOG mapper
- emapper
- orthology annotation
- 直系同源功能注释
keywords:
- eggNOG
- orthology
- COG
- KEGG
- GO
- EC
- protein annotation
- metagenome
capabilities:
- ortholog search
- functional transfer
- taxonomic-scope control
- machine-readable annotation tables
inputs:
- predicted microbial protein FASTA or supported nucleotide input mode
outputs:
- annotations TSV
- ortholog hits
- seed-ortholog table
- optional GFF decorations
upstream:
- prodigal
- bakta
downstream: []
software_family: eggnog-mapper
documentation_status: CURATED_PROSE
downstream_tasks:
- functional summaries
- pathway analysis
- comparative genomics
parameter_guidance:
- '| `-i` / `-o` | Input protein FASTA and output prefix. |'
- '| `--tax_scope` | Restrict to a taxonomic scope (e.g., `auto`, `Bacteria`) for speed/accuracy. |'
- '| `-m diamond` | Search mode; diamond is default and fast. |'
- '| `--cpu` | Threads. |'
- '| `--dbmem` | Load database into memory for repeated runs. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# Use eggNOG-mapper as the default broad orthology-based functional annotation layer for predicted microbial proteins. Keep Bakta feature IDs stable and retain proteins without assignments.

## Capabilities and selection

emapper.py assigns orthologs and transfers functional annotations (COG, KEGG, GO, EC) to predicted proteins using the eggNOG database and DIAMOND/HMMER searches. Prefer it for broad, scalable functional annotation of isolate and metagenome proteomes; combine with Bakta for structural/naming annotation and HMMER/Pfam for domain evidence.

## Inputs and upstream

Input is a predicted-protein FASTA from Prodigal/Bakta. Use stable feature IDs so results join back to genes. The eggNOG-mapper database and software major versions must match.

## Outputs and downstream

Outputs are an annotations TSV (`*.emapper.annotations`), ortholog hits, and a seed-ortholog table. Feed annotations into COG/KEGG/GO summaries, pathway analysis, and comparative genomics; retain proteins with no assignment.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `-i` / `-o` | Input protein FASTA and output prefix. |
| `--tax_scope` | Restrict to a taxonomic scope (e.g., `auto`, `Bacteria`) for speed/accuracy. |
| `-m diamond` | Search mode; diamond is default and fast. |
| `--cpu` | Threads. |
| `--dbmem` | Load database into memory for repeated runs. |

## Workflow patterns

```bash
conda run -n microbiome-eggnog-mapper --no-capture-output emapper.py \
  -i proteins.faa -o emapper_out --tax_scope auto -m diamond --cpu 16
```

## Validation and failure handling

Record the eggNOG-mapper and database versions and the seed-ortholog/search modes. A database/software mismatch causes empty or wrong tables. Report the assignment rate and keep no-hit proteins; a short partial match is not a confirmed function.

## Reproducibility and audit

Record the eggNOG-mapper software version, the database release, the taxonomic scope, and the search mode (`-m diamond`) next to every annotations TSV. Re-run on the same proteome and diff the tables to confirm reproducibility. Keep the exact `eggnog.db`/`eggnog.taxa.db` release so orthology IDs remain comparable across samples and studies.

```bash
# provenance: capture software and database versions
conda run -n microbiome-eggnog-mapper --no-capture-output emapper.py --version
ls -la Database/eggnog-mapper/<release>/eggnog.db Database/eggnog-mapper/<release>/eggnog.taxa.db
```

Keep a record of `--tax_scope`, seed-ortholog mode, and CPU count; these change runtime and, in edge cases, assignment output.
