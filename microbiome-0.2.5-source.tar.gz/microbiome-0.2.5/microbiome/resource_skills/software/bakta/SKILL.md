---
name: Bakta
description: Rapid annotation of bacterial genomes using a separately prepared Bakta reference database.
kind: software
id: bakta
version: 3
environment: microbiome
executables:
- bakta
- bakta_db
packages:
- bakta=1.12.0
- diamond=2.1.22
channels:
- conda-forge
- bioconda
tasks:
- bacterial genome annotation requiring a prepared Bakta database
databases:
- bakta
aliases:
- Bakta
- bacterial annotation
- 细菌基因组注释
keywords:
- annotation
- bacterial genome
- CDS
- tRNA
- rRNA
- pseudogene
- 注释
capabilities:
- bacterial genome and MAG annotation
- standardized feature naming
- multi-format annotation export
inputs:
- bacterial isolate or MAG nucleotide FASTA
- optional compliant locus and organism metadata
outputs:
- GFF3
- GenBank
- EMBL
- TSV
- JSON
- nucleotide and protein FASTA
- summary and log
upstream:
- megahit
- spades
- metabat2
- maxbin2
- concoct
- drep
downstream:
- diamond
- ncbi-blast
- rgi
software_family: bakta
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Parameter | Meaning and setting rule |'
- '| `--db` | READY Bakta database directory, usually `Database/bakta/db-light` or full DB. Never point to an empty parent.
  |'
- '| `--output`, `--prefix` | New output directory and stable file prefix. Avoid `--force` unless replacing a known failed
  run. |'
- '| `--genus`, `--species`, `--strain` | Organism metadata. Do not invent taxonomy before GTDB-Tk/other evidence. |'
- '| `--complete` | Mark genome complete only with evidence; changes edge handling and should not be used for drafts/MAGs
  casually. |'
- '| `--plasmid` | Plasmid name for a plasmid input; do not label all contigs as one plasmid. |'
- '| `--translation-table` | NCBI genetic code, commonly 11 for bacteria. Match Prodigal and known biology. |'
- '| `--meta` | Metagenome mode for fragmented/anonymous contigs or MAG context as supported. |'
- '| `--min-contig-length` | Exclude shorter contigs. Coordinate with assembly/binning cutoffs and small-genome goals. |'
- '| `--locus`, `--locus-tag`, `--locus-tag-increment` | Feature ID construction. Ensure uniqueness across samples before
  combined analysis. |'
- '| `--keep-contig-headers` | Preserve input headers; use only when headers satisfy downstream/INSDC constraints. |'
- '| `--compliant` | Produce INSDC-compliant annotations with stricter metadata/format behavior. Validate submission requirements.
  |'
- '| `--replicons` | TSV metadata for replicon names/types/topology. Preferred when chromosome/plasmid structure is known.
  |'
- '| `--proteins` | Trusted protein FASTA for expert annotation. Use only curated, biologically matching evidence. |'
- '| `--regions` | User-supplied regions/features according to Bakta schema; validate coordinates and contig IDs. |'
- '| `--skip-*` | Disable a feature class such as tRNA/rRNA/CRISPR/CDS/sORF. Skip only for a documented reason. |'
- '| `--threads`, `--tmp-dir` | CPU allocation and temp storage. Database search can need substantial temporary space. |'
- '| `--debug`, verbosity options | Preserve detailed logs when diagnosing database, dependency, or sequence problems. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# Bakta

The software requires a registered READY Bakta database directory. Prefer a compatible local release; a missing release may be downloaded only when its database Skill contributes an acquisition marker to the user-confirmed plan.

```bash
conda run -n microbiome --no-capture-output bakta --db Database/bakta/db-light --output bakta_out --prefix sample genome.fasta
```

Validate the database release, input topology and translation table, then inspect the log and all annotation formats.

## Capabilities and selection

Bakta performs standardized bacterial isolate and MAG annotation using intrinsic feature detection plus a versioned local reference database. It predicts CDS, tRNA/tmRNA/rRNA/ncRNA, CRISPRs, gaps, origins, and small ORFs according to installed-version capabilities and exports interoperable formats. It is not intended for eukaryotic genomes and does not replace MAG quality/taxonomy assessment.

Use it after assembly and, for metagenomes, after binning/refinement. Annotating raw mixed-community contigs is possible but produces a metagenome annotation rather than organism-resolved genomes. The Bakta database must be a READY resource; software readiness alone is insufficient.

## Inputs and upstream

Input is nucleotide FASTA from SPAdes/MEGAHIT, a quality-controlled bin from MetaBAT 2/MaxBin 2/CONCOCT, or a dRep representative. Contigs require unique IDs. Supply organism, replicon, topology, and genetic-code metadata only when known. A replicon table can define chromosome/plasmid names and circularity more accurately than filename assumptions.

## Outputs and downstream

Common outputs include `.gff3`, `.gbff`, `.embl`, `.tsv`, `.json`, `.txt`, genome FASTA, CDS nucleotide FASTA (`.ffn`), and protein FASTA (`.faa`). GFF/GenBank feed genome browsers and comparative tools; proteins feed DIAMOND/BLAST/RGI; JSON/TSV support structured summaries. Preserve the database and software versions with every annotation.

## Parameters and decision rules

| Parameter | Meaning and setting rule |
| --- | --- |
| `--db` | READY Bakta database directory, usually `Database/bakta/db-light` or full DB. Never point to an empty parent. |
| `--output`, `--prefix` | New output directory and stable file prefix. Avoid `--force` unless replacing a known failed run. |
| `--genus`, `--species`, `--strain` | Organism metadata. Do not invent taxonomy before GTDB-Tk/other evidence. |
| `--complete` | Mark genome complete only with evidence; changes edge handling and should not be used for drafts/MAGs casually. |
| `--plasmid` | Plasmid name for a plasmid input; do not label all contigs as one plasmid. |
| `--translation-table` | NCBI genetic code, commonly 11 for bacteria. Match Prodigal and known biology. |
| `--meta` | Metagenome mode for fragmented/anonymous contigs or MAG context as supported. |
| `--min-contig-length` | Exclude shorter contigs. Coordinate with assembly/binning cutoffs and small-genome goals. |
| `--locus`, `--locus-tag`, `--locus-tag-increment` | Feature ID construction. Ensure uniqueness across samples before combined analysis. |
| `--keep-contig-headers` | Preserve input headers; use only when headers satisfy downstream/INSDC constraints. |
| `--compliant` | Produce INSDC-compliant annotations with stricter metadata/format behavior. Validate submission requirements. |
| `--replicons` | TSV metadata for replicon names/types/topology. Preferred when chromosome/plasmid structure is known. |
| `--proteins` | Trusted protein FASTA for expert annotation. Use only curated, biologically matching evidence. |
| `--regions` | User-supplied regions/features according to Bakta schema; validate coordinates and contig IDs. |
| `--skip-*` | Disable a feature class such as tRNA/rRNA/CRISPR/CDS/sORF. Skip only for a documented reason. |
| `--threads`, `--tmp-dir` | CPU allocation and temp storage. Database search can need substantial temporary space. |
| `--debug`, verbosity options | Preserve detailed logs when diagnosing database, dependency, or sequence problems. |

## Workflow patterns

```bash
conda run -n microbiome --no-capture-output bakta \
  --db Database/bakta/db-light --output bakta/MAG_001 --prefix MAG_001 \
  --meta --translation-table 11 --threads 16 MAG_001.fasta
```

Run CheckM and GTDB-Tk before assigning organism metadata to MAGs. Use stable dRep representatives when annotating a dereplicated collection. Protein annotation can then be extended with DIAMOND while retaining Bakta feature IDs.

## Validation and failure handling

Require successful database compatibility check, non-empty GFF/FAA/FFN/JSON, matching feature identifiers/counts, valid coordinates, and a summary plausible for genome size/domain. For Bakta 1.12.0 keep DIAMOND at the tested 2.1.22 release; DIAMOND 2.2.1 can segfault with return code `-11` during Bakta's specialized sORF search even when `diamond dbinfo` accepts the database. On an sORF failure, check `diamond version`, inspect both `pscc.dmnd` and `sorf.dmnd` with `diamond dbinfo`, and restore the pinned environment before considering `--skip-sorf`. Skipping sORF is acceptable for a narrowly documented recovery/pilot but changes annotation scope and is not the default fix. Database schema/version errors require preparing the correct Bakta database outside analysis execution. Very few CDS can mean wrong molecule type, genetic code, overstrict length cutoff, or low-quality assembly. Duplicate locus tags make downstream joins unsafe and must be corrected by rerunning with a unique prefix.
