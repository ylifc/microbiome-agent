---
name: VirSorter2
description: Multi-classifier viral contig identification for genomes, metagenomes and viromes using genomic features and
  HMMs.
kind: software
id: virsorter2
version: 2
selection_tier: conditional
environment: biomni-virsorter2
executables:
- virsorter
packages:
- virsorter=2
channels:
- conda-forge
- bioconda
tasks:
- viral contig identification
- prophage and lytic virus detection
- metagenome and virome virus mining
databases:
- virsorter2
aliases:
- VirSorter2
- VirSorter
- 病毒序列识别
- 前噬菌体预测
keywords:
- virus
- viral
- prophage
- virome
- classification
- HMM
- 病毒
- 前噬菌体
capabilities:
- score contigs for viral signal across multiple classifiers
- distinguish viral
- prophage and uncertain categories
- process large metagenomes
- integrate with geNomad and CheckV
inputs:
- assembly or metagenome contig FASTA
- a configured VirSorter2 database
outputs:
- viral/prophage/uncertain classification per contig
- summary metrics
- extracted viral sequences
upstream:
- spades
- megahit
- flye
downstream:
- checkv
- genomad
- diamond
- vadr
- pvga
software_family: virsorter2
documentation_status: CURATED_PROSE
parameter_guidance:
- '| `setup -d` | Download/configure the VirSorter2 database into a persistent directory. |'
- '| `run -i/-w` | Input contigs and output workspace. |'
- '| `--min-length` | Minimum contig length (default 0, i.e. no filter); 1500 is a common metagenome cutoff, not the built-in
  default. |'
- '| `--min-score` | Minimum viral score to retain (default 0.5). |'
- '| `--include-groups` | Restrict to target viral groups; record the groups. |'
- '| `--keep-original-seq` | Retain original sequences in extracted output. |'
- '| `-j` | Threads. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# VirSorter2

Use VirSorter2 to identify viral and prophage sequences from assembled contigs. It combines genomic-feature and HMM-based classifiers and reports a confidence category (`dsDNAphage`, `ssDNA`, `RNA`, `NCLDV`, `lavidaviridae` and a max score). It complements geNomad: run both and reconcile disagreements rather than trusting one predictor.

```bash
# One-time database setup (downloads HMM/viral reference models)
conda run -n biomni-virsorter2 --no-capture-output virsorter setup -d Database/virsorter2 -j 16

# Classify contigs
conda run -n biomni-virsorter2 --no-capture-output virsorter run \
  -w vs2_out -i contigs.fa --min-length 1500 --min-score 0.5 -j 16 --include-groups dsDNAphage,ssDNA,RNA,NCLDV,lavidaviridae \
  --keep-original-seq -d Database/virsorter2
```

## Capabilities and selection

VirSorter2 emits per-contig viral scores and group assignments, and extracts candidate viral sequences. Use it for mining metagenomes/viromes and for prophage detection. Cross-validate candidates with geNomad viral scores and CheckV completeness/contamination; a contig flagged by both is far more trustworthy. Prefer it when diverse viral groups (including RNA viruses) are in scope, since geNomad focuses on DNA viruses.

## Inputs and upstream

Input is an assembled contig FASTA (short-read or long-read assembly). The `--min-length` and `--min-score` thresholds control sensitivity/specificity. The configured database must match the VirSorter2 version.

## Outputs and downstream

Outputs include `final-viral-score.tsv`, `final-viral-combined.fa`, and summary files. Feed candidate viral sequences to CheckV (completeness), geNomad (annotation/score), and DIAMOND/VADR/PVGA for taxonomy and reference-based validation.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `setup -d` | Download/configure the VirSorter2 database into a persistent directory. |
| `run -i/-w` | Input contigs and output workspace. |
| `--min-length` | Minimum contig length (default 0, i.e. no filter); 1500 is a common metagenome cutoff, not the built-in default. |
| `--min-score` | Minimum viral score to retain (default 0.5). |
| `--include-groups` | Restrict to target viral groups; record the groups. |
| `--keep-original-seq` | Retain original sequences in extracted output. |
| `-j` | Threads. |

## Workflow patterns

Assemble, run VirSorter2, cross-check candidates with geNomad, assess completeness with CheckV, then annotate validated candidates with DIAMOND/VADR/PVGA. Reconcile predictors rather than trusting a single call.

```bash
conda run -n biomni-virsorter2 --no-capture-output virsorter run \
  -w vs2_out -i contigs.fa --min-length 1500 --min-score 0.5 -j 16 --include-groups dsDNAphage,ssDNA,RNA -d Database/virsorter2
```

## Validation and failure handling

Require a configured database (setup must succeed) and record the VirSorter2 version and thresholds. Candidates with high viral score but low CheckV completeness may be partial prophages or contamination. Always reconcile with a second predictor before reporting a sequence as a novel virus.
