---
name: scikit-bio
description: Sequence and community data structures / 群落距离与排序
kind: software
id: scikit-bio
version: 3
selection_tier: conditional
documentation_status: DOCUMENTED
software_family: scikit-bio
environment: microbiome-scikit-bio
executables:
- python
packages:
- scikit-bio
channels:
- conda-forge
- bioconda
tasks:
- Sequence and community data structures / 群落距离与排序
databases: []
aliases:
- scikit-bio
- scikit-bio
keywords:
- scikit-bio
- Sequence and community data structures / 群落距离与排序
capabilities:
- Sequence and community data structures / 群落距离与排序
inputs:
- validated sequence or community matrix
- sample IDs and metadata
outputs:
- distance matrices
- ordination and statistical summaries
upstream:
- biom-format
downstream: []
parameter_guidance:
- 'DistanceMatrix: IDs must be unique and ordered consistently.'
- 'diversity functions: confirm count, tree and rootedness requirements of the chosen metric.'
- 'ordination/permutation tests: freeze method, seed and parameters in the adapter.'
validation:
- Validate version and required package/functions before use.
- Run the task on representative data and require output assertions.
failure_handling:
- Do not substitute an unrooted or mismatched-tip tree for a phylogenetic diversity contract.
- Consult version-matched Knowledge history; repair only in an approved maintenance phase.
references:
- https://scikit.bio/docs/latest/
runtime:
  kind: python_package
  package: skbio
  functions:
  - read
  distribution: scikit-bio
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# scikit-bio

## Capabilities and selection

Sequence and community data structures / 群落距离与排序.
Select this capability only when its input and statistical assumptions match the study.
Catalog documentation does not assert that this software is installed or task-validated.

## Inputs and upstream

- validated sequence or community matrix
- sample IDs and metadata

Keep sample identifiers, feature identifiers, orientation, units and reference releases explicit.
Reject missing inputs rather than acquiring substitutes during analysis.

## Outputs and downstream

- distance matrices
- ordination and statistical summaries

Save the complete invocation, output schema, software version and database fingerprints.
Do not overwrite raw data, reference resources or outputs from a different run.

## Parameters and decision rules

- DistanceMatrix: IDs must be unique and ordered consistently.
- diversity functions: confirm count, tree and rootedness requirements of the chosen metric.
- ordination/permutation tests: freeze method, seed and parameters in the adapter.

The reference below is the full manual source. This catalog covers the supported task decisions;
option availability and defaults must be checked against the installed version and captured help.
Unknown values must not be guessed. Package functions are verified independently of R/Python.

## Workflow patterns

The following is a discovery probe, not a successful analysis recipe:

```bash
conda run -n microbiome-scikit-bio --no-capture-output python --help
```

Resolve the actual environment prefix first. During production replay the frozen argv and paths.
R/Python workflows require a reviewed adapter with explicit parameters and output assertions.

## Validation and failure handling

Correct: use aligned input IDs, the approved method, compatible reference resources and validated outputs.
Incorrect: Do not substitute an unrooted or mismatched-tip tree for a phylogenetic diversity contract.
A zero exit code without output validation is unverified history.
On failure record the complete command, exit code, stderr, version, input and database context.
Promote a repair only after a matching regression validation report passes.

## References and documentation coverage

- Official source: https://scikit.bio/docs/latest/
- Documentation reviewed for catalog integration; this is not a local runtime acceptance claim.
- Parameter coverage: curated task guidance; full version-specific help is captured on discovery.
