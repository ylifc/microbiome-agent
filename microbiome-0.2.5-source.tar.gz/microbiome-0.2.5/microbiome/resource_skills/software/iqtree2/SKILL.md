---
name: IQ-TREE 2
description: IQ-TREE 2 maximum-likelihood phylogenetics with model selection and branch support estimation.
kind: software
id: iqtree2
version: 2
environment: iqtree2
executables:
- iqtree2
packages:
- iqtree=2.*
channels:
- conda-forge
- bioconda
tasks:
- maximum-likelihood phylogeny
- model selection
- ultrafast bootstrap
- SH-aLRT support
databases: []
aliases:
- IQ-TREE2
- iqtree2
- maximum likelihood tree
- 最大似然树
keywords:
- phylogeny
- model selection
- bootstrap
- SH-aLRT
- partition
- concordance
- 系统发育
- 建树
capabilities:
- maximum-likelihood tree search
- substitution-model selection
- partition and mixture models
- branch support and topology tests
inputs:
- validated nucleotide or protein multiple alignment
- optional partition file and constraint or starting trees
outputs:
- treefile Newick tree
- iqtree report
- log
- model and bootstrap or consensus files
upstream:
- mafft
- muscle
downstream:
- treetime
- paml
- beast2
software_family: iqtree2
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Parameter | Meaning and setting rule |'
- '| `-s ALIGNMENT` | Required validated alignment. Raw unaligned FASTA is invalid. |'
- '| `-st DNA|AA|CODON|BIN|MORPH` | Force sequence type only when auto-detection is wrong; codon data must be frame-consistent.
  |'
- '| `-m MODEL` | Fixed model, `TEST`/`MF`, or `MFP` ModelFinder plus tree inference. Report selected model and criterion.
  |'
- '| `-mset`, `-msub`, `-madd`, `-mrate` | Restrict/extend candidate model sets and rate heterogeneity. Use to encode scientific
  constraints, not chase fit post hoc. |'
- '| `-AIC`, `-AICc`, `-BIC` | Model-selection criterion; BIC is common, but choice must be consistent across compared analyses.
  |'
- '| `-p` / partition options | Supply partition definitions and branch-length linkage model. Verify exact `-p/-q/-Q` semantics
  in IQ-TREE 2 help. |'
- '| `-B N` | Ultrafast bootstrap replicates, commonly at least 1000. Check convergence and model violations. |'
- '| `-bnni` | Additional optimization to reduce some UFBoot model-violation bias at extra cost. |'
- '| `-alrt N` | SH-aLRT replicates, commonly 1000; its support values are not bootstrap percentages. |'
- '| `-b N` | Standard nonparametric bootstrap, much more expensive than UFBoot. Choose deliberately. |'
- '| `-abayes`, `-lbp` | Alternative branch supports. Interpret each statistic by its own meaning. |'
- '| `-T N|AUTO`, `--threads-max` | Threads/automatic selection and optional cap. Record actual resources. |'
- '| `-mem` | Memory limit where supported; ensure enough for model/partition search. |'
- '| `-seed` | Random seed for reproducibility. |'
- '| `--prefix` / `-pre`, `-redo` | Output prefix and overwrite behavior. Use a new prefix unless intentionally rerunning.
  |'
- '| `-t FILE` | Starting tree or special starting-tree mode. It is not necessarily held fixed. |'
- '| `-te FILE` | Evaluate/optimize parameters on a fixed supplied topology. Distinguish from tree search. |'
- '| `-g FILE` | Constraint tree. Constraints require biological justification and compatible taxa. |'
- '| `-o TAXON` | Root display/output by outgroup; ML search remains fundamentally unrooted. |'
- '| `-z TREES`, `-zb N`, `-au` | Candidate-tree likelihood/topology tests with resampling/AU where supported. Include all
  a priori hypotheses. |'
- '| `--gcf`, `--scf` | Gene/site concordance factors using reference tree and gene trees/alignments. Do not interpret as
  bootstrap. |'
- '| `-asr` | Ancestral-state reconstruction under selected model; report uncertainty. |'
- '| `--safe` | Safer numerical mode for problematic datasets as supported, with extra cost. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# IQ-TREE 2

This skill is pinned to IQ-TREE 2 and deliberately does not reuse an IQ-TREE 3 environment.

```bash
conda run -n iqtree2 --no-capture-output iqtree2 -s alignment.fasta -m MFP -B 1000 -alrt 1000 -T AUTO --prefix results/tree
```

Require a validated multiple-sequence alignment. Check the `.log`, `.iqtree`, `.treefile`, and support values before accepting the result.

## Capabilities and selection

IQ-TREE 2 performs maximum-likelihood tree search, ModelFinder selection, partition/mixture models, ultrafast or standard bootstrap, SH-aLRT and other branch tests, topology tests, ancestral reconstruction, and concordance-factor analysis. It assumes input columns represent homologous characters. It cannot repair an invalid alignment or establish temporal signal.

Use this skill when a workflow explicitly requires IQ-TREE 2 reproducibility. The local environment is currently not created, so the plan must disclose creation of `iqtree2` with `iqtree=2.*` before execution. Do not substitute IQ-TREE 3 without user-approved version change.

## Inputs and upstream

`-s` takes an aligned FASTA/PHYLIP/NEXUS/CLUSTAL-like file from MAFFT/MUSCLE. All sequences must have equal aligned length and unique names. Partition files must match alignment coordinates and molecule/codon structure. Constraint, starting, comparison, and gene trees use valid Newick with compatible taxon labels.

## Outputs and downstream

`PREFIX.treefile` is the best ML Newick tree; `.iqtree` is the detailed report; `.log` records search/model behavior; `.model.gz`, `.ufboot`, `.contree`, `.splits.nex`, and topology-test files depend on options. Trees can feed TreeTime, PAML, BEAST starting-tree workflows, visualization, or concordance analysis. Preserve report/log with the tree so model and support semantics are not lost.

## Parameters and decision rules

| Parameter | Meaning and setting rule |
| --- | --- |
| `-s ALIGNMENT` | Required validated alignment. Raw unaligned FASTA is invalid. |
| `-st DNA|AA|CODON|BIN|MORPH` | Force sequence type only when auto-detection is wrong; codon data must be frame-consistent. |
| `-m MODEL` | Fixed model, `TEST`/`MF`, or `MFP` ModelFinder plus tree inference. Report selected model and criterion. |
| `-mset`, `-msub`, `-madd`, `-mrate` | Restrict/extend candidate model sets and rate heterogeneity. Use to encode scientific constraints, not chase fit post hoc. |
| `-AIC`, `-AICc`, `-BIC` | Model-selection criterion; BIC is common, but choice must be consistent across compared analyses. |
| `-p` / partition options | Supply partition definitions and branch-length linkage model. Verify exact `-p/-q/-Q` semantics in IQ-TREE 2 help. |
| `-B N` | Ultrafast bootstrap replicates, commonly at least 1000. Check convergence and model violations. |
| `-bnni` | Additional optimization to reduce some UFBoot model-violation bias at extra cost. |
| `-alrt N` | SH-aLRT replicates, commonly 1000; its support values are not bootstrap percentages. |
| `-b N` | Standard nonparametric bootstrap, much more expensive than UFBoot. Choose deliberately. |
| `-abayes`, `-lbp` | Alternative branch supports. Interpret each statistic by its own meaning. |
| `-T N|AUTO`, `--threads-max` | Threads/automatic selection and optional cap. Record actual resources. |
| `-mem` | Memory limit where supported; ensure enough for model/partition search. |
| `-seed` | Random seed for reproducibility. |
| `--prefix` / `-pre`, `-redo` | Output prefix and overwrite behavior. Use a new prefix unless intentionally rerunning. |
| `-t FILE` | Starting tree or special starting-tree mode. It is not necessarily held fixed. |
| `-te FILE` | Evaluate/optimize parameters on a fixed supplied topology. Distinguish from tree search. |
| `-g FILE` | Constraint tree. Constraints require biological justification and compatible taxa. |
| `-o TAXON` | Root display/output by outgroup; ML search remains fundamentally unrooted. |
| `-z TREES`, `-zb N`, `-au` | Candidate-tree likelihood/topology tests with resampling/AU where supported. Include all a priori hypotheses. |
| `--gcf`, `--scf` | Gene/site concordance factors using reference tree and gene trees/alignments. Do not interpret as bootstrap. |
| `-asr` | Ancestral-state reconstruction under selected model; report uncertainty. |
| `--safe` | Safer numerical mode for problematic datasets as supported, with extra cost. |

## Workflow patterns

```bash
conda run -n iqtree2 --no-capture-output iqtree2 \
  -s homologs.aln.fasta -m MFP -B 1000 -bnni -alrt 1000 \
  -T AUTO --threads-max 16 -seed 42 --prefix iqtree2/run
```

For partitioned phylogenomics, validate partition coverage/no overlap and choose linkage semantics explicitly. For time trees, pass the supported ML tree and matching alignment/dates to TreeTime only after testing temporal signal.

## Validation and failure handling

Require an equal-length alignment, all expected taxa in `.treefile`, finite likelihood, completed search, selected model, support convergence diagnostics, and no critical warnings. Duplicate/near-identical sequences may be removed or renamed by options/version; inspect logs and preserve mapping. Zero-length branches, extreme composition, excessive gaps, recombination, and model violations can destabilize trees. Out-of-memory/model-space failure calls for justified model restriction, partition revision, or more memory, not silent fallback to a favored model.
