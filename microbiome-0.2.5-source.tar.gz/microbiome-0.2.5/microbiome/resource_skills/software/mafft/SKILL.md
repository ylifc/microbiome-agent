---
name: MAFFT
description: Multiple-sequence alignment of nucleotide or protein sequences.
kind: software
id: mafft
version: 2
environment: mafft
executables:
- mafft
packages:
- mafft
channels:
- conda-forge
- bioconda
tasks:
- multiple-sequence alignment
- protein alignment
- nucleotide alignment
databases: []
aliases:
- MAFFT
- multiple sequence alignment
- 多序列比对
keywords:
- alignment
- nucleotide
- protein
- codon
- add sequences
- profile
- 比对
- 系统发育
capabilities:
- nucleotide or protein multiple alignment
- profile alignment
- incremental sequence addition
- large-sequence alignment
inputs:
- homologous nucleotide or protein FASTA
- optional existing aligned profile and additional sequences
outputs:
- aligned FASTA written to stdout
- optional guide tree and diagnostic text
upstream:
- seqkit
- prodigal
- bakta
- bcftools
downstream:
- iqtree2
- iqtree3
- fasttree
- treetime
- paml
- beast2
software_family: mafft
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Parameter | Meaning and setting rule |'
- '| `--auto` | Select strategy from sequence number/length. Good default, but record the strategy reported on stderr. |'
- '| `--localpair --maxiterate 1000` | L-INS-i; accurate for local motifs and smaller datasets, expensive in memory/time.
  |'
- '| `--globalpair --maxiterate 1000` | G-INS-i; assumes global end-to-end homology. |'
- '| `--genafpair --maxiterate 1000` | E-INS-i; handles conserved blocks separated by long gaps. |'
- '| `--retree N` | Number of guide-tree rebuilds in FFT modes; higher can improve alignment at extra cost. |'
- '| `--maxiterate N` | Iterative refinement count. More iterations are not useful when homology/input is wrong. |'
- '| `--parttree` and related modes | Reduce memory for very large sequence sets, usually with lower accuracy than intensive
  modes. |'
- '| `--add FILE` | Add full-length sequences to an existing alignment while retaining the original core alignment. |'
- '| `--addfragments FILE` | Add short fragments to an alignment; useful for partial reads/amplicons but inspect placement.
  |'
- '| `--addlong FILE` | Add longer sequences according to supported-version semantics. |'
- '| `--keeplength` | Preserve original alignment length while adding sequences; inserted residues may be removed/mapped.
  |'
- '| `--mapout` | Write mapping information when adding sequences, needed to trace residue coordinates. |'
- '| `--adjustdirection` / `--adjustdirectionaccurately` | Detect reverse-complement nucleotide sequences. Review `_R_` renamed
  records and do not use on proteins. |'
- '| `--nuc`, `--amino`, `--anysymbol` | Force molecule/alphabet handling. `--anysymbol` can hide bad characters, so validate
  first. |'
- '| `--op`, `--ep` | Gap-open and offset/extension behavior. Change only with a documented indel model and sensitivity analysis.
  |'
- '| `--thread N` | Threads. `-1` may use all CPUs and should be avoided on shared systems. |'
- '| `--reorder` / `--inputorder` | Tree-based output order versus original input order. Use input order when external metadata
  depends on it. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# MAFFT

Use `--auto` by default and select a more specific algorithm only when sequence number and expected homology justify it.

```bash
conda run -n mafft --no-capture-output mafft --auto sequences.fasta > alignment.fasta
```

Check sequence count, alignment length, gap patterns, and identifier preservation before phylogenetic inference.

## Capabilities and selection

MAFFT aligns homologous nucleotide or protein sequences, adds sequences to an existing alignment, and supports profile/fragment workflows. Alignment is a biological modeling decision: unrelated sequences, mixed domains, reverse-complement errors, frameshifts, or nonhomologous flanks cannot be fixed by choosing a slower algorithm.

Start with `--auto`. Use L-INS-i for a smaller set with conserved local motifs and long gaps, G-INS-i for global homology across full length, and E-INS-i for multiple conserved domains separated by long unalignable regions. Large datasets generally require FFT-NS or PartTree strategies. For coding DNA under selection analysis, align translated proteins and project back to codons with a codon-aware method rather than treating codons as arbitrary nucleotides.

## Inputs and upstream

Input FASTA comes from SeqKit curation, Prodigal/Bakta homolog extraction, consensus generation, or marker pipelines. All records must have unique stable IDs and the same molecule type. Remove duplicate names, orient nucleotide sequences consistently, and decide whether terminal regions are homologous. An existing alignment used with add/profile modes must already be validated.

## Outputs and downstream

Aligned FASTA is written to stdout, so shell redirection and pipeline exit status matter. It feeds IQ-TREE/FastTree, TreeTime, PAML, BEAST XML construction, conservation analysis, and profile-based inspection. Preserve an unmodified input FASTA and an ID map. Trimming, masking, or gap-column removal is a separate transformation and must be recorded.

## Parameters and decision rules

| Parameter | Meaning and setting rule |
| --- | --- |
| `--auto` | Select strategy from sequence number/length. Good default, but record the strategy reported on stderr. |
| `--localpair --maxiterate 1000` | L-INS-i; accurate for local motifs and smaller datasets, expensive in memory/time. |
| `--globalpair --maxiterate 1000` | G-INS-i; assumes global end-to-end homology. |
| `--genafpair --maxiterate 1000` | E-INS-i; handles conserved blocks separated by long gaps. |
| `--retree N` | Number of guide-tree rebuilds in FFT modes; higher can improve alignment at extra cost. |
| `--maxiterate N` | Iterative refinement count. More iterations are not useful when homology/input is wrong. |
| `--parttree` and related modes | Reduce memory for very large sequence sets, usually with lower accuracy than intensive modes. |
| `--add FILE` | Add full-length sequences to an existing alignment while retaining the original core alignment. |
| `--addfragments FILE` | Add short fragments to an alignment; useful for partial reads/amplicons but inspect placement. |
| `--addlong FILE` | Add longer sequences according to supported-version semantics. |
| `--keeplength` | Preserve original alignment length while adding sequences; inserted residues may be removed/mapped. |
| `--mapout` | Write mapping information when adding sequences, needed to trace residue coordinates. |
| `--adjustdirection` / `--adjustdirectionaccurately` | Detect reverse-complement nucleotide sequences. Review `_R_` renamed records and do not use on proteins. |
| `--nuc`, `--amino`, `--anysymbol` | Force molecule/alphabet handling. `--anysymbol` can hide bad characters, so validate first. |
| `--op`, `--ep` | Gap-open and offset/extension behavior. Change only with a documented indel model and sensitivity analysis. |
| `--thread N` | Threads. `-1` may use all CPUs and should be avoided on shared systems. |
| `--reorder` / `--inputorder` | Tree-based output order versus original input order. Use input order when external metadata depends on it. |

## Workflow patterns

```bash
conda run -n seqkit --no-capture-output seqkit stats homologs.faa
conda run -n mafft --no-capture-output bash -lc \
  "set -o pipefail; mafft --localpair --maxiterate 1000 --thread 12 homologs.faa > homologs.aln.faa"
conda run -n seqkit --no-capture-output seqkit stats homologs.aln.faa
```

For adding new samples to a fixed reference alignment, use `--add`/`--addfragments` and retain map output. Do not realign only the new sequences and concatenate columns.

## Validation and failure handling

Require identical input/output record counts and IDs, a consistent aligned length, no illegal symbols, and plausible conserved motifs/gap structure. Inspect alignment visually or with objective QC before tree building. Empty output can be caused by shell redirection despite MAFFT failure, so require pipe failure handling and stderr capture. Extremely gappy sequences may be nonhomologous, partial, wrong strand, or domain-incompatible; investigate before deleting them. Alignment uncertainty should be tested, not hidden by one algorithm.
