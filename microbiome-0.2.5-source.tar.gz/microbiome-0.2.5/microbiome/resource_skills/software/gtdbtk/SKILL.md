---
name: GTDB-Tk
description: Genome taxonomy classification against a local GTDB release.
kind: software
id: gtdbtk
version: 2
environment: gtdbtk-2.7.2
executables:
- gtdbtk
packages:
- gtdbtk=2.7.2
channels:
- conda-forge
- bioconda
tasks:
- genome taxonomy
- bin classification
databases:
- gtdbtk
aliases:
- GTDB-Tk
- GTDB taxonomy
- 基因组分类
- MAG物种分类
keywords:
- taxonomy
- bacteria
- archaea
- marker genes
- ANI
- placement
- GTDB
- 分类
excludes:
- 16S扩增子
- 18S扩增子
- ITS扩增子
- amplicon FASTQ
- 扩增子FASTQ
capabilities:
- bacterial and archaeal genome classification
- marker placement
- reference ANI assignment
- de novo marker phylogeny workflow
inputs:
- directory or batchfile of bacterial or archaeal genome or MAG FASTA files
outputs:
- bacterial and archaeal summary TSV
- marker alignment
- placement trees
- ANI and warning tables
upstream:
- checkm
- drep
- metabat2
- maxbin2
- concoct
downstream:
- bakta
software_family: gtdbtk
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Command/parameter | Meaning and setting rule |'
- '| `classify_wf --genome_dir` / `--batchfile` | Directory mode or explicit genome-ID/path manifest. Batchfiles avoid extension
  and naming ambiguity. |'
- '| `--out_dir`, `-x` | New output directory and genome extension for directory mode. |'
- '| `--cpus`, `--pplacer_cpus` | General and pplacer CPU limits. pplacer memory, not CPU, is often limiting. |'
- '| `--place_species` | Place species in pplacer trees even when they are already classified by skani. |'
- '| `--min_perc_aa` | Minimum percentage of amino acids in marker alignment. Lowering admits incomplete genomes with less
  reliable placement. |'
- '| `--min_perc_aa` | Minimum percentage of amino acids in marker alignment. Lowering admits incomplete genomes with less
  reliable placement. |'
- '| `--min_af` | Minimum ANI alignment fraction used in assignment as supported; small overlap should not drive taxonomy.
  |'
- '| `--genes` | Inputs are already called genes rather than nucleotide genomes where supported; changes identify stage. |'
- '| `--write_single_copy_genes` | Export marker genes for downstream phylogenomics. Preserve genome-marker mapping. |'
- '| `--keep_intermediates` | Retain stage files for audit/debug at disk cost. |'
- '| `--scratch_dir` | Disk-backed pplacer mode to reduce memory, slower and requiring ample fast storage. |'
- '| `--full_tree` | Use full reference tree where supported; much higher memory. |'
- '| `--force` | Continue despite some warnings/failures. Never use without reviewing failed-genome list. |'
- '| `--debug` | Retain detailed logs/intermediates for diagnosis. |'
- '| `de_novo_wf --outgroup_taxon` | Root de novo marker tree with a valid GTDB taxon. Outgroup choice must be external to
  ingroup. |'
- '| taxon/reference filtering options | Reduce reference set for targeted trees where supported; document exclusions. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# GTDB-Tk

Use for bacterial/archaeal genome or MAG classification. Set `GTDBTK_DATA_PATH` to the ready release directory such as `Database/gtdbtk/release232`.

Run only through the dedicated GTDB-Tk environment resolved by the registry, normally `conda run -p <resolved-prefix>`. Do not combine GTDB-Tk with the microbiome environment because its dependency stack and database release are tightly coupled.

## Capabilities and selection

GTDB-Tk classifies bacterial and archaeal genomes using domain marker identification, alignment, phylogenetic placement, and reference ANI. `classify_wf` is the standard end-to-end classification; `identify`, `align`, and `classify` expose phases; `de_novo_wf` builds domain marker trees relative to a selected outgroup. It is not designed for viruses/eukaryotes and classification is tied to a specific GTDB release.

Use quality-controlled genomes/MAGs, preferably dereplicated when analyzing large redundant collections. Do not rename taxonomy across GTDB releases without recording both release and mapping behavior.

## Inputs and upstream

Supply `--genome_dir` plus extension or a batchfile mapping genome paths to IDs. Inputs come from CheckM-screened bins or dRep representatives. IDs must be unique and path-safe. The dedicated environment version and `GTDBTK_DATA_PATH` database release must be compatible; this project currently declares GTDB-Tk 2.7.2 and a local release such as release232.

## Outputs and downstream

Separate bacterial/archaeal summary TSVs contain classification, closest reference, ANI/AF, placement, warnings, and notes. Marker alignments, trees, RED/placement files, identify results, and failed-genome tables support diagnosis. Taxonomy can guide Bakta metadata and phylogenomic grouping, but preserve GTDB strings and release rather than forcing NCBI rank/name equivalence.

## Parameters and decision rules

| Command/parameter | Meaning and setting rule |
| --- | --- |
| `classify_wf --genome_dir` / `--batchfile` | Directory mode or explicit genome-ID/path manifest. Batchfiles avoid extension and naming ambiguity. |
| `--out_dir`, `-x` | New output directory and genome extension for directory mode. |
| `--cpus`, `--pplacer_cpus` | General and pplacer CPU limits. pplacer memory, not CPU, is often limiting. |
| `--place_species` | Place species in pplacer trees even when they are already classified by skani. |
| `--min_perc_aa` | Minimum percentage of amino acids in marker alignment. Lowering admits incomplete genomes with less reliable placement. |
| `--min_perc_aa` | Minimum percentage of amino acids in marker alignment. Lowering admits incomplete genomes with less reliable placement. |
| `--min_af` | Minimum ANI alignment fraction used in assignment as supported; small overlap should not drive taxonomy. |
| `--genes` | Inputs are already called genes rather than nucleotide genomes where supported; changes identify stage. |
| `--write_single_copy_genes` | Export marker genes for downstream phylogenomics. Preserve genome-marker mapping. |
| `--keep_intermediates` | Retain stage files for audit/debug at disk cost. |
| `--scratch_dir` | Disk-backed pplacer mode to reduce memory, slower and requiring ample fast storage. |
| `--full_tree` | Use full reference tree where supported; much higher memory. |
| `--force` | Continue despite some warnings/failures. Never use without reviewing failed-genome list. |
| `--debug` | Retain detailed logs/intermediates for diagnosis. |
| `de_novo_wf --outgroup_taxon` | Root de novo marker tree with a valid GTDB taxon. Outgroup choice must be external to ingroup. |
| taxon/reference filtering options | Reduce reference set for targeted trees where supported; document exclusions. |

## Workflow patterns

```bash
conda run -p /home/ylifc/anaconda3/envs/gtdbtk-2.7.2 --no-capture-output bash -lc \
  "export GTDBTK_DATA_PATH=Database/gtdbtk/release232; \
   gtdbtk classify_wf --genome_dir representatives --extension fasta \
   --out_dir gtdbtk_out --cpus 16 --pplacer_cpus 2"
```

The exact resolved environment/database paths should come from registry bindings. Compare classification and warnings to CheckM domain/quality and inspect ambiguous ANI/placement cases.

## Validation and failure handling

Require database/version report, expected input count, bacterial+archaeal summary coverage, marker alignment percentages, ANI/AF fields, and failed/warning lists. pplacer killed by OOM calls for fewer pplacer CPUs, scratch/reduced strategy, or more memory. A database metadata/version mismatch requires compatible local resource preparation, not mixed-release execution. Low marker coverage, multiple domains, or discordant ANI/placement can indicate incomplete/contaminated bins and should be reported, not force-labeled.
