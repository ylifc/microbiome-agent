---
name: MUSCLE
description: High-accuracy multiple-sequence alignment and ensemble alignment generation.
kind: software
id: muscle
version: 2
environment: microbiome
executables:
- muscle
packages:
- muscle
channels:
- conda-forge
- bioconda
tasks:
- multiple-sequence alignment
- alignment refinement
- alignment ensemble
databases: []
aliases:
- MUSCLE 5
- multiple sequence alignment
- 多序列比对
keywords:
- alignment
- ensemble
- super5
- protein
- nucleotide
- refine
- 比对
- 系统发育
capabilities:
- high-accuracy multiple alignment
- large-data Super5 alignment
- diversified alignment ensemble
- alignment refinement
inputs:
- homologous nucleotide or protein FASTA
- optional existing alignment for refinement
outputs:
- aligned FASTA
- ensemble alignment files
- optional tree and diagnostic outputs
upstream:
- seqkit
- prodigal
- bakta
- bcftools
downstream:
- iqtree2
- iqtree3
- fasttree
- treetime
- paml
- beast2
software_family: muscle
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Parameter | Meaning and setting rule |'
- '| `-align INPUT` | Standard MUSCLE 5 alignment mode for moderate datasets. |'
- '| `-super5 INPUT` | Scalable algorithm for large datasets; trade some exhaustive accuracy for feasibility. |'
- '| `-output FILE` | Explicit output. Do not use MUSCLE 3 `-in/-out` assumptions. |'
- '| `-threads N` | CPU allocation; record it for performance provenance. |'
- '| `-refineiters N` | Number of refinement iterations (default 100). |'
- '| `-replicates N` | Number of ensemble replicates. More replicates estimate alignment uncertainty at added cost. |'
- '| `-stratified` / `-diversified` | Ensemble-generation strategies. Use when downstream conclusions will be tested across
  alignments. |'
- '| `-perm none|abc|acb|bca` | Guide-tree sequence-order permutations used to diversify alignment replicates (use `-stratified`
  for all permutations). |'
- '| `-perturb SEED` | Perturbation seed/parameter for reproducible diversified replicates as supported. |'
- '| `-consiters N` | Consistency iterations. Increase only after checking local help and runtime. |'
- '| `-disperse ENSEMBLE` | Quantify ensemble dispersion where supported; interpret as alignment uncertainty. |'
- '| `-maxcc` | Select a maximum column-confidence alignment from an ensemble where supported. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# MUSCLE

This environment provides MUSCLE 5 syntax.

```bash
conda run -n microbiome --no-capture-output muscle -align sequences.fasta -output alignment.fasta
```

Do not substitute MUSCLE 3 flags. Verify record counts and inspect alignment quality before downstream analysis.

## Capabilities and selection

MUSCLE 5 provides high-accuracy alignment, Super5 scaling for large datasets, iterative refinement, and diversified ensembles that expose alignment uncertainty. Its command syntax differs substantially from MUSCLE 3. A single alignment is not guaranteed to represent ambiguous homology; ensembles can be useful for robustness analysis.

Use `-align` for standard high-accuracy datasets and `-super5` for large sequence collections. Choose MAFFT when profile addition, fragment addition, or specific L/G/E-INS-i behavior is needed. For codon analyses, align proteins and project back to codons with an appropriate method.

## Inputs and upstream

Input is homologous nucleotide or protein FASTA from SeqKit curation, Prodigal/Bakta, consensus sequences, or marker extraction. IDs and molecule types must be consistent. For refinement, the input must be an existing valid multiple alignment, not raw unaligned sequences.

## Outputs and downstream

Aligned FASTA feeds IQ-TREE/FastTree, TreeTime, PAML, and BEAST setup. Ensemble output may contain multiple replicate alignments and should feed an explicit robustness/dispersion analysis rather than be mistaken for one FASTA. Preserve input order/ID mapping and document the exact MUSCLE 5 command.

## Parameters and decision rules

| Parameter | Meaning and setting rule |
| --- | --- |
| `-align INPUT` | Standard MUSCLE 5 alignment mode for moderate datasets. |
| `-super5 INPUT` | Scalable algorithm for large datasets; trade some exhaustive accuracy for feasibility. |
| `-output FILE` | Explicit output. Do not use MUSCLE 3 `-in/-out` assumptions. |
| `-threads N` | CPU allocation; record it for performance provenance. |
| `-refineiters N` | Number of refinement iterations (default 100). |
| `-replicates N` | Number of ensemble replicates. More replicates estimate alignment uncertainty at added cost. |
| `-stratified` / `-diversified` | Ensemble-generation strategies. Use when downstream conclusions will be tested across alignments. |
| `-perm none|abc|acb|bca` | Guide-tree sequence-order permutations used to diversify alignment replicates (use `-stratified` for all permutations). |
| `-perturb SEED` | Perturbation seed/parameter for reproducible diversified replicates as supported. |
| `-consiters N` | Consistency iterations. Increase only after checking local help and runtime. |
| `-disperse ENSEMBLE` | Quantify ensemble dispersion where supported; interpret as alignment uncertainty. |
| `-maxcc` | Select a maximum column-confidence alignment from an ensemble where supported. |

## Workflow patterns

```bash
conda run -n microbiome --no-capture-output muscle \
  -align homologs.faa -output homologs.aln.faa -threads 12
```

For a large collection use `-super5`. For topology robustness, create a diversified ensemble, infer trees consistently from replicates, and report sensitivity rather than selecting a favorable alignment.

## Validation and failure handling

Require output record count/IDs equal input, one aligned length, legal alphabet, and biologically plausible motifs/gaps. A command-line error often means MUSCLE 3 flags were used against MUSCLE 5. Poor alignment can indicate nonhomology, domain architecture differences, fragments, or excessive dataset size; choose a suitable mode or curate input rather than only increasing iterations. Record the installed major version because syntax and algorithm names are not backward compatible.
