---
name: PVGA
description: Virus-focused graph assembly and polishing from reads plus a backbone sequence.
kind: software
id: pvga
version: 2
environment: pvga
executables:
- pvga
packages:
- python=3.10
- pip
- blasr
pip_packages:
- pvga==0.1.2
- networkx
- numpy
- pandas
- biopython
channels:
- conda-forge
- bioconda
tasks:
- virus genome assembly
- backbone-guided viral assembly
databases: []
aliases:
- PVGA
- virus assembler
- 病毒组装
- 骨架引导组装
keywords:
- virus
- assembly
- polishing
- graph
- reads
- backbone
- 病毒
capabilities:
- virus-focused graph assembly
- iterative backbone-guided assembly and polishing
inputs:
- read sequences in FASTA
- related backbone nucleotide FASTA
outputs:
- assembled or polished viral sequence files
- graph and run artifacts in output directory
upstream:
- seqkit
downstream:
- genomad
- checkv
- bwa
- bowtie2
software_family: pvga
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Parameter | Meaning and setting rule |'
- '| `-r`, `--reads READS` | Required reads (FASTQ or FASTA) used to construct the graph. Validate sequence count/alphabet
  and preserve a map to raw reads. |'
- '| `-b`, `--backbone BACKBONE` | Required backbone nucleotide FASTA. Use one biologically justified reference and record
  accession/version. |'
- '| `-n`, `--iterations ITERATIONS` | Maximum graph-construction iterations. More iterations can increase runtime and do
  not guarantee correctness; compare convergence/output stability. |'
- '| `-o`, `--output_dir OUTPUT_DIR` | Required new output directory. Keep each backbone/iteration parameterization separate.
  |'
- '| `-h`, `--help` | Installed CLI help and authoritative syntax for this pinned release. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# PVGA

PVGA requires reads and a related backbone FASTA. Keep it in its dedicated PyPI-backed environment.

```bash
conda run -n pvga --no-capture-output pvga --reads reads.fasta --backbone backbone.fasta --iterations 10 --output_dir pvga_out
```

Inspect warnings, assembled sequences, graph behavior, and output completeness. A Biopython source-tree warning from this installed release should be recorded but is not by itself proof of failure.

## Capabilities and selection

PVGA 0.1.2 is a virus-focused graph assembly/polishing tool that uses reads plus a related backbone. Its small CLI exposes four analysis parameters. It is appropriate only when backbone-guided viral reconstruction matches the study design. It is not a general de novo metagenome assembler and a result can inherit backbone bias.

## Inputs and upstream

`--reads` accepts read sequences in FASTQ or FASTA (FASTQ is the documented primary input, passed directly to blasr). Preserve raw reads and record any preprocessing. `--backbone` is a related viral nucleotide FASTA chosen from independent evidence. A distant, contaminated, or circularity-mismatched backbone can distort assembly.

## Outputs and downstream

The output directory contains assembled/polished sequence and graph/run artifacts according to release. Identify the canonical final FASTA from logs rather than guessing a filename. Output can feed geNomad classification, CheckV quality, BWA/Bowtie 2 read-back mapping, annotation, and phylogenetic alignment after validation.

## Parameters and decision rules

| Parameter | Meaning and setting rule |
| --- | --- |
| `-r`, `--reads READS` | Required reads (FASTQ or FASTA) used to construct the graph. Validate sequence count/alphabet and preserve a map to raw reads. |
| `-b`, `--backbone BACKBONE` | Required backbone nucleotide FASTA. Use one biologically justified reference and record accession/version. |
| `-n`, `--iterations ITERATIONS` | Maximum graph-construction iterations. More iterations can increase runtime and do not guarantee correctness; compare convergence/output stability. |
| `-o`, `--output_dir OUTPUT_DIR` | Required new output directory. Keep each backbone/iteration parameterization separate. |
| `-h`, `--help` | Installed CLI help and authoritative syntax for this pinned release. |

## Workflow patterns

```bash
conda run -n pvga --no-capture-output pvga \
  --reads reads.fastq.gz --backbone backbone.fasta \
  --iterations 10 --output_dir pvga_out
```

After assembly, map original reads back and inspect breadth/depth, discordance, termini, and consensus differences from backbone. Run geNomad and CheckV on the final sequence. Compare at least one alternative backbone or de novo assembly when reference bias is a concern.

## Validation and failure handling

Require a clearly identified non-empty final FASTA, graph/run completion, read-back support across the sequence, plausible length/structure, and downstream viral evidence. An output nearly identical to backbone without read support is not validated. The observed Biopython source-tree warning in this environment should be captured; it is not a fatal result by itself, but any subsequent import/traceback is. Empty graph/output suggests incompatible read format, no overlap/support, wrong backbone, or dependency/runtime failure.
