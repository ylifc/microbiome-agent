---
name: MetaPhlAn
description: Marker-gene taxonomic profiling for microbial shotgun metagenomes.
kind: software
id: metaphlan
version: 2
selection_tier: conditional
environment: microbiome-metaphlan
executables:
- metaphlan
packages:
- metaphlan
channels:
- conda-forge
- bioconda
tasks:
- shotgun taxonomic profiling
- marker-based relative abundance
- strain marker output
databases:
- metaphlan
aliases:
- MetaPhlAn
- marker taxonomy
- 标记基因物种组成
keywords:
- shotgun
- taxonomy
- marker genes
- relative abundance
- Bowtie2
- metagenome
capabilities:
- marker-based clade profiling
- relative abundance tables
- taxonomic read counts
- Bowtie2 mapping output
inputs:
- quality-controlled shotgun FASTQ or Bowtie2 marker alignment
outputs:
- taxonomic profile
- optional Bowtie2 output
- marker and read-count tables
upstream:
- fastp
- bowtie2
downstream:
- humann
software_family: metaphlan
documentation_status: CURATED_PROSE
downstream_tasks:
- cohort merging
- diversity and differential-abundance analysis
parameter_guidance:
- '| `--input_type` | fastq/fasta/mapout/sam; use fastq for reads. |'
- '| `--db_dir` | MetaPhlAn database *folder* (containing the release subfolder); `--bowtie2db` is the legacy alias. |'
- '| `--index` / `-x` | Selects the database release/version inside the folder (e.g. `mpa_vJun23_CHOCOPhlAnSGB_202103`). |'
- '| `--nproc` | Threads. |'
- '| `-t rel_ab` | Report relative abundance (default). |'
- '| `--profile_vsc` | Add viral sequence cluster (VSC) profiling when justified. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# Use MetaPhlAn as a marker-based taxonomic route when database-efficient community profiling is preferred or as a scientifically justified cross-check of Kraken2/Bracken. Do not run both by default merely to list more tools.

## Capabilities and selection

MetaPhlAn profiles shotgun metagenomes by mapping reads to a database of clade-specific marker genes, reporting relative abundance per clade with species-level resolution for many taxa. It is more compact and faster than a full Kraken2 database but covers only taxa represented by markers. Prefer it for focused species-level community profiling; use Kraken2/Bracken for broad read-level taxonomy.

## Inputs and upstream

Input is quality-controlled shotgun FASTQ (fastp output). MetaPhlAn runs its own Bowtie2 mapping, so no separate alignment is required. The MetaPhlAn database release must match the software major version.

## Outputs and downstream

Outputs are a taxonomic profile (clade, relative abundance, estimated read counts) and optional Bowtie2 and marker tables. Feed profiles into HUMAnN, cohort merging, and diversity/differential-abundance analysis. Abundances are relative, not absolute.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `--input_type` | fastq/fasta/mapout/sam; use fastq for reads. |
| `--db_dir` | MetaPhlAn database *folder* (containing the release subfolder); `--bowtie2db` is the legacy alias. |
| `--index` / `-x` | Selects the database release/version inside the folder (e.g. `mpa_vJun23_CHOCOPhlAnSGB_202103`). |
| `--nproc` | Threads. |
| `-t rel_ab` | Report relative abundance (default). |
| `--profile_vsc` | Add viral sequence cluster (VSC) profiling when justified. |

## Workflow patterns

```bash
conda run -n microbiome-metaphlan --no-capture-output metaphlan \
  sample_R1.fastq.gz,sample_R2.fastq.gz --input_type fastq --mapout sample.mapout \
  --db_dir Database/metaphlan/ --index mpa_vJun23_CHOCOPhlAnSGB_202103 -t rel_ab --nproc 16 \
  -o sample.profile.tsv
```

## Validation and failure handling

Record the database release and software version. Check that the profile's read accounting is plausible and that low-confidence/unclassified fractions are reported. Cross-check key taxa against Kraken2/Bracken or assembly before drawing biological conclusions.

## Reproducibility and audit

Record the MetaPhlAn software version and database release (`--bowtie2db`) beside every profile. Re-run on the same reads and diff the profiles to confirm reproducibility. Report unclassified fractions and avoid treating relative abundance as absolute cell counts.

```bash
# provenance: capture version and database
conda run -n microbiome-metaphlan --no-capture-output metaphlan --version
ls -la Database/metaphlan/<release>/
```
