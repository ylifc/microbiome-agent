---
name: CoverM
description: Fast, exact read-mapping coverage and relative abundance of genomes and contigs from sorted BAM files.
kind: software
id: coverm
version: 2
selection_tier: default
environment: biomni-coverm
executables:
- coverm
packages:
- coverm
channels:
- conda-forge
- bioconda
tasks:
- genome and contig coverage calculation
- MAG relative abundance
- genome filtering by breadth and depth
databases: []
aliases:
- CoverM
- coverm genome
- coverm contig
- MAG 相对丰度
- 覆盖度计算
keywords:
- coverage
- relative abundance
- MAG
- contig
- read mapping
- breadth
- depth
- 覆盖度
- 丰度
capabilities:
- compute mean or trimmed coverage per genome or contig
- estimate relative abundance across many samples
- filter genomes by breadth and depth
- TPM/RPKM summaries
inputs:
- one or more coordinate-sorted BAM files
- genome FASTA directory or contig FASTA
outputs:
- coverage or relative-abundance TSV
- optional BAM filtering
- optional per-base coverage
upstream:
- bwa
- bowtie2
- minimap2
- samtools
- megahit
- metabat2
downstream:
- checkm2
- gtdbtk
- drep
software_family: coverm
documentation_status: CURATED_PROSE
downstream_tasks:
- differential abundance and bin refinement
parameter_guidance:
- '| `-m` / `--methods` | Coverage metric; `relative_abundance` for community profiles, `mean`/`trimmed_mean` for depth, `tpm`/`rpkm`
  for normalized summaries. |'
- '| `--min-covered-fraction` | Minimum breadth for a reference to be counted; raise to reject partially recruited/misassigned
  contigs. |'
- '| `--min-read-percent-identity` | Minimum mapping identity (commonly 0.95); lower only with explicit rationale. |'
- '| `--min-read-aligned-percent` | Minimum aligned fraction of each read (commonly 0.75). |'
- '| `--proper-pairs-only` | Require properly paired alignments for paired data; reduces spurious cross-mapping. |'
- '| `--trim-min`, `--trim-max` | Trim extreme depths before `trimmed_mean` to reduce outlier bias. |'
- '| `-t` | Threads; also keep memory bounded because multiple BAMs are streamed. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# CoverM

Use CoverM to turn read mappings into per-genome or per-contig coverage and relative abundance. It is the modern, exact replacement for `jgi_summarize_bam_contig_depths`-style coverage tables and scales cleanly across many samples.

```bash
# Per-MAG relative abundance (default: trimmed mean, --min-covered-fraction filters partial matches)
conda run -n biomni-coverm --no-capture-output coverm genome \
  -d Database/bins/ -b S1.sorted.bam S2.sorted.bam \
  -m relative_abundance --min-covered-fraction 0.4 \
  --min-read-percent-identity 0.95 --min-read-aligned-percent 0.75 \
  -t 16 -o mag_relative_abundance.tsv

# Per-contig mean coverage for binning depth tables
conda run -n biomni-coverm --no-capture-output coverm contig \
  -r assembly/contigs.fasta -b S1.sorted.bam S2.sorted.bam \
  -m mean trimmed_mean --min-covered-fraction 0 \
  -t 16 -o contig_coverage.tsv
```

## Capabilities and selection

CoverM computes coverage by exact read alignment against a reference set rather than heuristics. It reports breadth (covered fraction) and depth (per-base abundance), supporting `mean`, `trimmed_mean`, `relative_abundance`, TPM, RPKM, and per-base outputs. `coverm filter` removes genomes failing breadth/depth thresholds.

Prefer CoverM for MAG/gene abundance once bins exist and BAMs map reads to those exact references. Depth from `coverm contig` also feeds downstream binning/refinement when MetaBAT depth tables are unavailable.

## Inputs and upstream

BAM files must be coordinate-sorted and produced against the exact same reference sequences (byte-identical contig/genome names). `-d` takes a directory of reference FASTA files (one genome per file) for `coverm genome`; `-r` takes a single FASTA for `coverm contig`. Keep per-sample BAMs separate so relative abundance is computed per sample, not merged.

## Outputs and downstream

Output is a long- or wide-format TSV of coverage/abundance per reference per sample. Feed it to CheckM2/GTDB-Tk summary tables, dRep abundance filtering, and any differential-abundance or community-composition analysis. Record mapping identity/aligned-percent thresholds because they change the numbers.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `-m` / `--methods` | Coverage metric; `relative_abundance` for community profiles, `mean`/`trimmed_mean` for depth, `tpm`/`rpkm` for normalized summaries. |
| `--min-covered-fraction` | Minimum breadth for a reference to be counted; raise to reject partially recruited/misassigned contigs. |
| `--min-read-percent-identity` | Minimum mapping identity (commonly 0.95); lower only with explicit rationale. |
| `--min-read-aligned-percent` | Minimum aligned fraction of each read (commonly 0.75). |
| `--proper-pairs-only` | Require properly paired alignments for paired data; reduces spurious cross-mapping. |
| `--trim-min`, `--trim-max` | Trim extreme depths before `trimmed_mean` to reduce outlier bias. |
| `-t` | Threads; also keep memory bounded because multiple BAMs are streamed. |

## Workflow patterns

Map reads to the assembly or genome set (BWA-MEM/Bowtie2), coordinate-sort and index each BAM, then run `coverm genome` across every sample to build a genome × sample relative-abundance matrix. For binning, run `coverm contig` against the assembly and pass the depth table to MetaBAT2.

```bash
conda run -n biomni-coverm --no-capture-output coverm genome \
  -d Database/bins/ -b S1.sorted.bam S2.sorted.bam \
  -m relative_abundance --min-covered-fraction 0.4 -t 16 -o mag_abundance.tsv
```

## Validation and failure handling

Require that reference names, BAM headers, and output row names match exactly, and that all input BAMs are coordinate-sorted and indexed. A missing reference-name match yields zero coverage rather than an error — reconcile the reference FASTA against `samtools idxstats` before trusting the table. Compare breadth and depth jointly; depth alone can mask a reference that only a small region recruits.
