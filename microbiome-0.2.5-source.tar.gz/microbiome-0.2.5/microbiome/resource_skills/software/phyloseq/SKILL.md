---
name: phyloseq
description: Community tables and visualization / 群落数据整合
kind: software
id: phyloseq
version: 3
selection_tier: conditional
documentation_status: DOCUMENTED
software_family: phyloseq
environment: microbiome-phyloseq
executables:
- Rscript
packages:
- bioconductor-phyloseq
channels:
- conda-forge
- bioconda
tasks:
- Community tables and visualization / 群落数据整合
databases: []
aliases:
- phyloseq
- phyloseq
keywords:
- phyloseq
- Community tables and visualization / 群落数据整合
capabilities:
- Community tables and visualization / 群落数据整合
inputs:
- feature-by-sample count matrix
- sample metadata with exact sample IDs
outputs:
- phyloseq RDS object
- diversity and visualization tables
upstream:
- dada2
- qiime2
downstream:
- vegan
- ancombc2
parameter_guidance:
- 'otu_table(taxa_are_rows): declare feature orientation explicitly.'
- 'sample_data: row names must equal count-table sample IDs.'
- 'tax_table: preserve unclassified features and taxonomy ranks.'
validation:
- Validate version and required package/functions before use.
- Run the task on representative data and require output assertions.
failure_handling:
- Do not use percentages as raw counts or silently intersect mismatched sample IDs.
- Consult version-matched Knowledge history; repair only in an approved maintenance phase.
references:
- https://bioconductor.org/packages/release/bioc/html/phyloseq.html
runtime:
  kind: r_package
  package: phyloseq
  functions:
  - phyloseq
  - otu_table
  - sample_data
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# phyloseq

## Capabilities and selection

Community tables and visualization / 群落数据整合.
Select this capability only when its input and statistical assumptions match the study.
Catalog documentation does not assert that this software is installed or task-validated.

## Inputs and upstream

- feature-by-sample count matrix
- sample metadata with exact sample IDs

Keep sample identifiers, feature identifiers, orientation, units and reference releases explicit.
Reject missing inputs rather than acquiring substitutes during analysis.

## Outputs and downstream

- phyloseq RDS object
- diversity and visualization tables

Save the complete invocation, output schema, software version and database fingerprints.
Do not overwrite raw data, reference resources or outputs from a different run.

## Parameters and decision rules

- otu_table(taxa_are_rows): declare feature orientation explicitly.
- sample_data: row names must equal count-table sample IDs.
- tax_table: preserve unclassified features and taxonomy ranks.

The reference below is the full manual source. This catalog covers the supported task decisions;
option availability and defaults must be checked against the installed version and captured help.
Unknown values must not be guessed. Package functions are verified independently of R/Python.

## Workflow patterns

The following is a discovery probe, not a successful analysis recipe:

```bash
conda run -n microbiome-phyloseq --no-capture-output Rscript --vanilla -e 'library(phyloseq); packageVersion("phyloseq")'
```

Resolve the actual environment prefix first. During production replay the frozen argv and paths.
R/Python workflows require a reviewed adapter with explicit parameters and output assertions.

## Validation and failure handling

Correct: use aligned input IDs, the approved method, compatible reference resources and validated outputs.
Incorrect: Do not use percentages as raw counts or silently intersect mismatched sample IDs.
A zero exit code without output validation is unverified history.
On failure record the complete command, exit code, stderr, version, input and database context.
Promote a repair only after a matching regression validation report passes.

## References and documentation coverage

- Official source: https://bioconductor.org/packages/release/bioc/html/phyloseq.html
- Documentation reviewed for catalog integration; this is not a local runtime acceptance claim.
- Parameter coverage: curated task guidance; full version-specific help is captured on discovery.
