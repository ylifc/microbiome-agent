---
name: SAMtools
description: Processing, sorting, indexing, and quality control of SAM, BAM, and CRAM alignments.
kind: software
id: samtools
version: 2
environment: microbiome
executables:
- samtools
packages:
- samtools
channels:
- conda-forge
- bioconda
tasks:
- alignment sorting
- BAM indexing
- alignment statistics
- depth calculation
databases: []
aliases:
- SAMtools
- BAM tools
- 比对文件处理
keywords:
- SAM
- BAM
- CRAM
- sort
- index
- depth
- coverage
- 比对
- 深度
capabilities:
- alignment conversion and sorting
- BAM or CRAM indexing
- mapping QC
- depth and region extraction
inputs:
- SAM or BAM alignment stream
- coordinate-sorted BAM or CRAM
- optional indexed reference FASTA
outputs:
- sorted BAM or CRAM
- BAI or CSI index
- flagstat and depth tables
- extracted alignments
upstream:
- bwa
- bowtie2
downstream:
- metabat2
- concoct
- bcftools
software_family: samtools
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Subcommand/parameter | Meaning and setting rule |'
- '| `view -b` / `-C` | Write BAM or CRAM. CRAM requires reference handling and is not a drop-in choice without provenance.
  |'
- '| `view -q INT` | Minimum mapping quality. Filtering changes coverage; record the cutoff. |'
- '| `view -f FLAG`, `-F FLAG` | Require/exclude bit flags. Typical exclusions may include unmapped, secondary, QC-fail, or
  duplicate reads, but must match the analysis. |'
- '| `view -L regions.bed` | Restrict to BED regions; coordinate conventions must be understood. |'
- '| `sort -o`, `-@`, `-m`, `-T` | Output, threads, memory per thread, temp prefix. Total memory is roughly per-thread memory
  times threads. |'
- '| `sort -n` / `-N` | Name/lexicographic-name sorting for mate workflows, not coordinate indexing. |'
- '| `index -c` | Create CSI rather than BAI when references/coordinates exceed BAI limits. |'
- '| `flagstat` | Quick mapping category counts; use `stats` and `idxstats` for deeper diagnostics. |'
- '| `quickcheck` | Detect missing/truncated headers and EOF; it does not prove biological validity. |'
- '| `depth -a` | Include zero-depth positions; can create huge output. |'
- '| `depth -q`, `-Q` | Base-quality and mapping-quality thresholds; do not swap their meanings. |'
- '| `depth -d` | Maximum depth behavior is version-dependent; inspect local help before relying on a cap. |'
- '| `faidx` | Index FASTA and optionally retrieve regions; preserve the `.fai` with its exact FASTA. |'
- '| `fixmate` then `sort` then `markdup` | Required order for duplicate marking from name-sorted paired alignments; read
  each subcommand''s constraints. |'
- '| `merge` | Merge compatible BAMs. Do not merge samples when downstream sample identity is required. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# SAMtools

Sort before indexing and keep the reference available when working with CRAM.

```bash
conda run -n microbiome --no-capture-output samtools sort -@ 8 -o sample.sorted.bam sample.sam
conda run -n microbiome --no-capture-output samtools index sample.sorted.bam
conda run -n microbiome --no-capture-output samtools flagstat sample.sorted.bam
```

Verify command exit status, index presence, mapped-read counts, and reference sequence names.

## Capabilities and selection

SAMtools converts, filters, sorts, indexes, validates, summarizes, and queries SAM/BAM/CRAM. Its subcommands have different ordering requirements. Coordinate sorting is required for genomic indexing, depth, pileup, and most variant workflows; name sorting is used for mate-aware processing and cannot be indexed as a coordinate BAM.

## Inputs and upstream

SAM input commonly comes from BWA or Bowtie 2. BAM/CRAM may come from an external aligner if headers and references are consistent. CRAM operations require the exact reference or a resolvable reference cache. Always inspect `@SQ`, `@RG`, and sort-order header fields before combining files.

## Outputs and downstream

Coordinate-sorted BAM plus `.bai`/`.csi` can feed MetaBAT depth generation, CONCOCT coverage, BCFtools pileup/calling, region extraction, and visualization. `flagstat`, `stats`, `idxstats`, and `depth` produce QC/coverage text tables. `faidx` creates FASTA indexes used by many downstream tools.

## Parameters and decision rules

| Subcommand/parameter | Meaning and setting rule |
| --- | --- |
| `view -b` / `-C` | Write BAM or CRAM. CRAM requires reference handling and is not a drop-in choice without provenance. |
| `view -q INT` | Minimum mapping quality. Filtering changes coverage; record the cutoff. |
| `view -f FLAG`, `-F FLAG` | Require/exclude bit flags. Typical exclusions may include unmapped, secondary, QC-fail, or duplicate reads, but must match the analysis. |
| `view -L regions.bed` | Restrict to BED regions; coordinate conventions must be understood. |
| `sort -o`, `-@`, `-m`, `-T` | Output, threads, memory per thread, temp prefix. Total memory is roughly per-thread memory times threads. |
| `sort -n` / `-N` | Name/lexicographic-name sorting for mate workflows, not coordinate indexing. |
| `index -c` | Create CSI rather than BAI when references/coordinates exceed BAI limits. |
| `flagstat` | Quick mapping category counts; use `stats` and `idxstats` for deeper diagnostics. |
| `quickcheck` | Detect missing/truncated headers and EOF; it does not prove biological validity. |
| `depth -a` | Include zero-depth positions; can create huge output. |
| `depth -q`, `-Q` | Base-quality and mapping-quality thresholds; do not swap their meanings. |
| `depth -d` | Maximum depth behavior is version-dependent; inspect local help before relying on a cap. |
| `faidx` | Index FASTA and optionally retrieve regions; preserve the `.fai` with its exact FASTA. |
| `fixmate` then `sort` then `markdup` | Required order for duplicate marking from name-sorted paired alignments; read each subcommand's constraints. |
| `merge` | Merge compatible BAMs. Do not merge samples when downstream sample identity is required. |

## Workflow patterns

```bash
conda run -n microbiome --no-capture-output samtools sort -@ 8 -m 2G -o sample.sorted.bam sample.sam
conda run -n microbiome --no-capture-output samtools index -c sample.sorted.bam
conda run -n microbiome --no-capture-output samtools quickcheck -v sample.sorted.bam
conda run -n microbiome --no-capture-output samtools flagstat sample.sorted.bam
```

For metagenomic binning, retain all contigs in the coordinate BAM and use sample-separated BAMs. For variant calling, preserve read groups and apply mapping/base-quality rules consistently with BCFtools.

## Validation and failure handling

Require non-empty headers, expected reference names, correct sort order, successful `quickcheck`, plausible flag counts, and an index matching the BAM timestamp/content. Index errors usually mean unsorted alignments, duplicate coordinates with invalid order, or unsupported reference length for BAI. Out-of-memory sorting can be fixed by reducing `-m` or threads and using a temp directory with space. Reference mismatch in CRAM or pileup is a provenance error, not something to bypass.
