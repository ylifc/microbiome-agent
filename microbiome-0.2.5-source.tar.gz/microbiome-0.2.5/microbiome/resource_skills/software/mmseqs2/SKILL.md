---
name: MMseqs2
description: Ultra-fast, sensitive protein and nucleotide clustering and search for large gene catalogs.
kind: software
id: mmseqs2
version: 2
selection_tier: conditional
environment: biomni-mmseqs2
executables:
- mmseqs
packages:
- mmseqs2
channels:
- conda-forge
- bioconda
tasks:
- protein clustering and dereplication
- gene-catalog ortholog grouping
- fast sequence search and profile search
databases:
- swissprot
- nr
- cog
- pfam
aliases:
- MMseqs2
- mmseqs
- 蛋白聚类
- 基因目录去冗余
keywords:
- clustering
- protein
- dereplication
- orthology
- Linclust
- search
- 聚类
- 蛋白
capabilities:
- cluster millions of proteins quickly
- create/search databases
- build sequence profiles
- dereplicate gene catalogs
inputs:
- predicted protein FASTA
- optional reference database for search
outputs:
- cluster representatives and membership
- similarity search tables
- dereplicated sequence sets
upstream:
- prodigal
downstream:
- diamond
- eggnog-mapper
- hmmer
software_family: mmseqs2
documentation_status: CURATED_PROSE
downstream_tasks:
- functional annotation
parameter_guidance:
- '| `easy-cluster` | One-shot clustering; `--min-seq-id`, `-c`, `--cov-mode`, `-e` set the clustering thresholds. |'
- '| `--min-seq-id` | Sequence identity threshold (e.g., 0.5 for protein families, 0.95 for dereplication). |'
- '| `-c` | Coverage fraction; `--cov-mode 0` uses bidirectional coverage. |'
- '| `createdb` / `search` | `createdb` builds an MMseqs2 DB from FASTA; `search` requires both query and target to be MMseqs2
  DBs (`-s` sets sensitivity, 7.5 near-BLAST). For raw-FASTA search use `easy-search`. |'
- '| `--threads` | Threads; also monitor disk for the temporary directory. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# MMseqs2

Use MMseqs2 to cluster and dereplicate large predicted-protein sets (e.g., metagenome gene catalogs) and to perform fast sensitive searches. It replaces CD-HIT-style clustering with much higher throughput and sensitivity.

```bash
# Cluster proteins (easy workflow, writes representative FASTA + tsv)
conda run -n biomni-mmseqs2 --no-capture-output mmseqs easy-cluster \
  proteins.faa clusterRes tmp --min-seq-id 0.5 -c 0.8 --cov-mode 0 -e 0.001

# Build a searchable database from a FASTA, then search a query set
conda run -n biomni-mmseqs2 --no-capture-output mmseqs createdb proteins.faa proteinsDB
conda run -n biomni-mmseqs2 --no-capture-output mmseqs createdb query.faa queryDB
conda run -n biomni-mmseqs2 --no-capture-output mmseqs search queryDB proteinsDB resultDB tmp -s 7.5
```

## Capabilities and selection

MMseqs2 performs Linclust/cascaded clustering, profile construction, and sequence/profile search with accuracy comparable to BLAST at a fraction of the runtime. Prefer it when a gene catalog must be clustered into representatives before annotation, or when large reference searches are needed. Keep DIAMOND/HMMER for curated orthology (eggNOG/Pfam) rather than replacing them wholesale.

## Inputs and upstream

Input is a predicted-protein FASTA from Prodigal/Bakta. For clustering, sequences should be non-redundant IDs. Large jobs need a writable temporary directory and enough disk for intermediate databases.

## Outputs and downstream

`easy-cluster` writes `clusterRes_rep_seq.fasta` (representatives) and `clusterRes_cluster.tsv` (member→representative). Clustered representatives feed downstream functional annotation (eggNOG-mapper, DIAMOND, HMMER) and reduce redundant compute.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `easy-cluster` | One-shot clustering; `--min-seq-id`, `-c`, `--cov-mode`, `-e` set the clustering thresholds. |
| `--min-seq-id` | Sequence identity threshold (e.g., 0.5 for protein families, 0.95 for dereplication). |
| `-c` | Coverage fraction; `--cov-mode 0` uses bidirectional coverage. |
| `createdb` / `search` | `createdb` builds an MMseqs2 DB from FASTA; `search` requires both query and target to be MMseqs2 DBs (`-s` sets sensitivity, 7.5 near-BLAST). For raw-FASTA search use `easy-search`. |
| `--threads` | Threads; also monitor disk for the temporary directory. |

## Workflow patterns

Cluster predicted proteins into representatives, annotate the representatives with eggNOG-mapper/DIAMOND/HMMER, then map annotations back to members through the cluster table to reduce redundant compute.

```bash
conda run -n biomni-mmseqs2 --no-capture-output mmseqs easy-cluster \
  proteins.faa clusterRes tmp --min-seq-id 0.5 -c 0.8 --cov-mode 0 -e 0.001
```

## Validation and failure handling

Require non-empty input FASTA and a writable temporary directory (disk usage can be several times the input). Record clustering thresholds and rep-set size. A suspiciously small rep-set means over-aggressive clustering or truncated input; verify member counts and identity distribution before annotation.
