---
name: GUNC
description: Detects genome chimerism and contamination using lineage-homogeneity of gene assignments.
kind: software
id: gunc
version: 2
selection_tier: conditional
environment: biomni-gunc
executables:
- gunc
packages:
- gunc
channels:
- conda-forge
- bioconda
tasks:
- MAG contamination detection
- chimerism detection
- contig taxonomy inspection
databases:
- gunc
aliases:
- GUNC
- 嵌合基因组检测
- 污染检测
- MAG污染
keywords:
- MAG
- chimerism
- contamination
- CSS
- RRS
- clade separation score
- lineage homogeneity
capabilities:
- detect contamination missed by marker copy counts
- identify taxonomically discordant contigs
- report the taxonomic rank of maximum clade separation
inputs:
- one genome FASTA per file or consistently called proteins
- READY GUNC DIAMOND database
outputs:
- maxCSS summary
- all-level scores
- gene and optional contig taxonomy tables
- run logs
upstream:
- checkm2
- dastool
- metabat2
- maxbin2
- concoct
- semibin2
downstream:
- drep
- gtdbtk
- bakta
software_family: gunc
documentation_status: CURATED_PROSE
downstream_tasks:
- manual bin refinement
parameter_guidance:
- '| Command/option | Meaning and setting rule |'
- '| `gunc run` | Main batch workflow from genomes/proteins to contamination metrics. |'
- '| `--input_dir` | Directory containing one genome/proteome per file. |'
- '| `--file_suffix` | Exact suffix such as `.fa`; prevents accidental ingestion of unrelated files. |'
- '| `--db_file` | Explicit localized `.dmnd` database path. |'
- '| `--out_dir` | Dedicated output directory for one database/configuration. |'
- '| `--threads` | Parallelism for mapping and scoring. |'
- '| `--gene_calls` | Use only when input is already proteins; do not set for nucleotide genomes. |'
- '| `--detailed_output` | Retain gene-level assignments for contamination diagnosis. |'
- '| `--contig_taxonomy_output` | Emit contig-level taxonomy for manual splitting/refinement. |'
- '| `--use_species_level` | Include species-level scoring only when the chosen reference database supports meaningful resolution.
  |'
- '| `--min_mapped_genes` | Minimum evidence required for assessment; low-gene genomes should be reported as insufficient,
  not silently clean. |'
- Choose one database family for a comparable cohort and keep it fixed; ProGenomes- and GTDB-derived GUNC scores are not interchangeable.
- Join outputs to bins by stable filenames before any filtering so insufficient-data and failed genomes remain visible in
  the cohort table.
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# GUNC

Use GUNC after bin selection as a complementary contamination test. CheckM2 estimates completeness/contamination from genome features; GUNC asks whether genes within a genome are taxonomically coherent. Keep both signals when curating MAGs.

## Capabilities and selection

GUNC maps genes to a reference database and summarizes lineage dispersion as clade separation score (CSS), reference representation score (RRS), contamination proportion and the rank where discordance is strongest. It is especially useful for chimeric bins whose duplicated marker-gene count looks acceptable.

## Inputs and upstream

Input directories must contain one genome per FASTA file with an explicit suffix. For pre-called proteins, all files must use the same gene-calling method and naming convention. The local GUNC database must be a complete compatible DIAMOND file under `Database/gunc/`; record whether it is the ProGenomes or GTDB release because scores are database-dependent.

## Outputs and downstream

Retain `GUNC.maxCSS_level.tsv`, all-level score tables, gene counts, logs and detailed taxonomy outputs used for diagnosis. Join results to CheckM2 using stable genome IDs. Candidate contaminated bins can be split/refined, rerun through CheckM2/GUNC, then dereplicated and classified.

## Parameters and decision rules

| Command/option | Meaning and setting rule |
| --- | --- |
| `gunc run` | Main batch workflow from genomes/proteins to contamination metrics. |
| `--input_dir` | Directory containing one genome/proteome per file. |
| `--file_suffix` | Exact suffix such as `.fa`; prevents accidental ingestion of unrelated files. |
| `--db_file` | Explicit localized `.dmnd` database path. |
| `--out_dir` | Dedicated output directory for one database/configuration. |
| `--threads` | Parallelism for mapping and scoring. |
| `--gene_calls` | Use only when input is already proteins; do not set for nucleotide genomes. |
| `--detailed_output` | Retain gene-level assignments for contamination diagnosis. |
| `--contig_taxonomy_output` | Emit contig-level taxonomy for manual splitting/refinement. |
| `--use_species_level` | Include species-level scoring only when the chosen reference database supports meaningful resolution. |
| `--min_mapped_genes` | Minimum evidence required for assessment; low-gene genomes should be reported as insufficient, not silently clean. |

Choose one database family for a comparable cohort and keep it fixed; ProGenomes- and GTDB-derived GUNC scores are not interchangeable.

Join outputs to bins by stable filenames before any filtering so insufficient-data and failed genomes remain visible in the cohort table.

## Workflow patterns

```bash
conda run -n biomni-gunc --no-capture-output gunc run \
  --input_dir bins --file_suffix .fa \
  --db_file Database/gunc/gunc_db_progenomes2.1.dmnd \
  --out_dir gunc_out --threads 16 --detailed_output --contig_taxonomy_output
```

## Validation and failure handling

Require every eligible input genome to have a row or an explicit insufficient-data status. Do not interpret low CSS with very low mapped-gene support as proof of cleanliness. Missing DIAMOND index/version errors block execution and must be resolved through the database skill. Compare flags with assembly coverage, CheckM2 and taxonomy; conflicting evidence requires review rather than automatic deletion.
