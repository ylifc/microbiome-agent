---
name: minimap2
description: Versatile pairwise alignment for long reads, short reads, assemblies, and spliced nucleotide sequences.
kind: software
id: minimap2
version: 2
selection_tier: default
environment: biomni-minimap2
executables:
- minimap2
packages:
- minimap2
channels:
- conda-forge
- bioconda
tasks:
- long-read mapping
- assembly alignment
- short-read mapping
- splice-aware mapping
databases: []
aliases:
- minimap2
- long-read aligner
- 长读长比对
keywords:
- ONT
- PacBio
- HiFi
- PAF
- SAM
- assembly comparison
- mapping
- map-ont
- asm5
- 比对
capabilities:
- map noisy or accurate long reads
- map short reads
- compare assemblies
- perform splice-aware alignment
inputs:
- reference FASTA or minimap2 index
- FASTQ or FASTA query reads/assemblies
outputs:
- PAF pairwise alignments or SAM alignments with optional CIGAR MD and read-group tags
- reusable mmi index
upstream:
- chopper
- flye
- spades
- megahit
- ncbi-datasets
downstream:
- samtools
- bcftools
- flye
- quast
software_family: minimap2
documentation_status: CURATED_PROSE
parameter_guidance:
- '| `-x map-ont` | ONT genomic reads; use the installed help for newer high-quality ONT presets. |'
- '| `-x map-hifi` / `map-pb` | PacBio HiFi or CLR reads respectively. |'
- '| `-x sr` | Short genomic read mapping; supply paired reads in order. |'
- '| `-x asm5/asm10/asm20` | Assembly alignment at increasing expected divergence. |'
- '| `-x splice` | Spliced transcript alignment; set strand options when library biology is known. |'
- '| `-a` | SAM output instead of PAF; required for BAM-based downstream tools. |'
- '| `-t` | Threads; coordinate with SAMtools pipeline resources. |'
- '| `-R` | Read-group string for sample-aware BAM/variant workflows. |'
- '| `--secondary=no`, `-N`, `-p` | Control secondary alignments and score ratio; affects repeats and abundance estimates.
  |'
- '| `--MD`, `--eqx` | Emit downstream-required mismatch or extended CIGAR representation. |'
- '| `-d`, `-I`, `-K` | Build an index and tune index/batch memory only for large references. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# minimap2

Choose the preset from query/reference biology. Preset mismatch is the main source of plausible-looking but unsuitable alignments.

## Capabilities and selection

minimap2 covers ONT/PacBio/HiFi mapping, assembly-to-reference comparison, short-read mapping, and spliced RNA alignment. It complements BWA for long reads and assembly comparisons. Use Bowtie2 for workflows standardized around its indexes or host-depletion sensitivity; do not select by speed alone.

## Inputs and upstream

Reference FASTA must be the exact coordinate system expected downstream. Query may be filtered long-read FASTQ, short-read pairs, transcript reads, contigs, or another assembly. Record read technology, expected divergence, reference version, sample/read-group identity, and whether secondary alignments are needed.

## Outputs and downstream

Default output is PAF. `-a` emits SAM for SAMtools sorting/indexing, coverage, variant calling, or assembly polishing. `-d` creates `.mmi` indexes. Preserve reference checksum and preset with every BAM/PAF because the same files under another preset are not equivalent.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `-x map-ont` | ONT genomic reads; use the installed help for newer high-quality ONT presets. |
| `-x map-hifi` / `map-pb` | PacBio HiFi or CLR reads respectively. |
| `-x sr` | Short genomic read mapping; supply paired reads in order. |
| `-x asm5/asm10/asm20` | Assembly alignment at increasing expected divergence. |
| `-x splice` | Spliced transcript alignment; set strand options when library biology is known. |
| `-a` | SAM output instead of PAF; required for BAM-based downstream tools. |
| `-t` | Threads; coordinate with SAMtools pipeline resources. |
| `-R` | Read-group string for sample-aware BAM/variant workflows. |
| `--secondary=no`, `-N`, `-p` | Control secondary alignments and score ratio; affects repeats and abundance estimates. |
| `--MD`, `--eqx` | Emit downstream-required mismatch or extended CIGAR representation. |
| `-d`, `-I`, `-K` | Build an index and tune index/batch memory only for large references. |

## Workflow patterns

```bash
conda run -n biomni-minimap2 --no-capture-output minimap2 -d reference.mmi reference.fasta
set -o pipefail
conda run -n biomni-minimap2 --no-capture-output minimap2 -ax map-ont -t 16 -R '@RG\tID:S1\tSM:S1' reference.mmi reads.fastq.gz | \
  conda run -n microbiome --no-capture-output samtools sort -@ 8 -o S1.sorted.bam
```

The pipeline intentionally exits the minimap2 process before SAMtools runs in its own declared environment.

## Validation and failure handling

Require successful index/open, parseable PAF/SAM, correct reference contigs/read groups, non-empty alignment, mapping-rate and depth summaries, sorted/indexed BAM when requested, and no broken pipe. Low mapping may mean wrong reference, preset, contamination, high divergence, or failed read filtering. Excess multimapping requires explicit repeat/secondary policy, not arbitrary deletion.
