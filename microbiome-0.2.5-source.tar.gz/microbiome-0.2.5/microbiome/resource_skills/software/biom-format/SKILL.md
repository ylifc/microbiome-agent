---
name: BIOM format
description: Validated biological observation matrix conversion / BIOM格式转换
kind: software
id: biom-format
version: 3
selection_tier: conditional
documentation_status: DOCUMENTED
software_family: biom-format
environment: microbiome-biom-format
executables:
- python
packages:
- biom-format
channels:
- conda-forge
- bioconda
tasks:
- Validated biological observation matrix conversion / BIOM格式转换
databases: []
aliases:
- BIOM format
- biom-format
keywords:
- biom-format
- Validated biological observation matrix conversion / BIOM格式转换
capabilities:
- Validated biological observation matrix conversion / BIOM格式转换
inputs:
- BIOM JSON/HDF5 or explicitly described TSV
outputs:
- validated BIOM table
- sample and observation metadata
upstream:
- qiime2
- humann
downstream:
- scikit-bio
- phyloseq
parameter_guidance:
- 'load_table: inspect sample and observation IDs before converting.'
- 'biom convert: state output encoding and preserve taxonomy metadata.'
- 'biom validate-table: validation must succeed before downstream use.'
validation:
- Validate version and required package/functions before use.
- Run the task on representative data and require output assertions.
failure_handling:
- Do not transpose observations/samples or lose metadata during format conversion.
- Consult version-matched Knowledge history; repair only in an approved maintenance phase.
references:
- https://biom-format.org/documentation/biom_format.html
runtime:
  kind: python_package
  package: biom
  functions:
  - load_table
  distribution: biom-format
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# BIOM format

## Capabilities and selection

Validated biological observation matrix conversion / BIOM格式转换.
Select this capability only when its input and statistical assumptions match the study.
Catalog documentation does not assert that this software is installed or task-validated.

## Inputs and upstream

- BIOM JSON/HDF5 or explicitly described TSV

Keep sample identifiers, feature identifiers, orientation, units and reference releases explicit.
Reject missing inputs rather than acquiring substitutes during analysis.

## Outputs and downstream

- validated BIOM table
- sample and observation metadata

Save the complete invocation, output schema, software version and database fingerprints.
Do not overwrite raw data, reference resources or outputs from a different run.

## Parameters and decision rules

- load_table: inspect sample and observation IDs before converting.
- biom convert: state output encoding and preserve taxonomy metadata.
- biom validate-table: validation must succeed before downstream use.

The reference below is the full manual source. This catalog covers the supported task decisions;
option availability and defaults must be checked against the installed version and captured help.
Unknown values must not be guessed. Package functions are verified independently of R/Python.

## Workflow patterns

The following is a discovery probe, not a successful analysis recipe:

```bash
conda run -n microbiome-biom-format --no-capture-output python --help
```

Resolve the actual environment prefix first. During production replay the frozen argv and paths.
R/Python workflows require a reviewed adapter with explicit parameters and output assertions.

## Validation and failure handling

Correct: use aligned input IDs, the approved method, compatible reference resources and validated outputs.
Incorrect: Do not transpose observations/samples or lose metadata during format conversion.
A zero exit code without output validation is unverified history.
On failure record the complete command, exit code, stderr, version, input and database context.
Promote a repair only after a matching regression validation report passes.

## References and documentation coverage

- Official source: https://biom-format.org/documentation/biom_format.html
- Documentation reviewed for catalog integration; this is not a local runtime acceptance claim.
- Parameter coverage: curated task guidance; full version-specific help is captured on discovery.
