---
name: fastANI
description: Fast whole-genome Average Nucleotide Identity (ANI) for species-level genome comparison.
kind: software
id: fastani
version: 2
selection_tier: default
environment: biomni-fastani
executables:
- fastani
packages:
- fastani
channels:
- conda-forge
- bioconda
tasks:
- average nucleotide identity
- species delimitation
- genome clustering and novelty screening
databases: []
aliases:
- fastANI
- ANI
- 平均核苷酸一致性
- 物种鉴定
keywords:
- ANI
- species delimitation
- genome comparison
- Mash
- skani
- whole-genome
- 平均核苷酸一致性
capabilities:
- estimate pairwise ANI among many genomes
- cluster at the 95% species threshold
- identify novel genomes against a reference set
inputs:
- two or more genome FASTA files (query and reference lists)
outputs:
- one-line-per-comparison ANI table with aligned fraction and bidirectional fragment mappings
upstream:
- spades
- flye
- unicycler
- drep
- skani
downstream:
- drep
software_family: fastani
documentation_status: CURATED_PROSE
downstream_tasks:
- species clustering
- GTDB-Tk cross-check
- taxonomy curation
parameter_guidance:
- '| `--ql`, `--rl` | Query and reference list files; one genome path per line. |'
- '| `-o` | Output matrix path; append to existing file with `--matrix`-style workflows. |'
- '| `--fragLen` | Fragment length (default 3000); keep consistent across a study for comparable matrices. |'
- '| `--minFraction` | Minimum aligned fraction to report a pair; lower noise when many genomes are distant. |'
- '| `-t` | Threads. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# fastANI

Use fastANI for species-level genome comparison via whole-genome Average Nucleotide Identity. The widely used 95% ANI threshold approximates the species boundary for many prokaryotes; report aligned fraction alongside ANI because low coverage weakens the call.

```bash
conda run -n biomni-fastani --no-capture-output fastani \
  --ql query_list.txt --rl ref_list.txt \
  -o ani.out --fragLen 3000 -t 16
```

## Capabilities and selection

fastANI maps fragments between query and reference genomes and reports bidirectional ANI and aligned fraction. It is orders of magnitude faster than BLAST-based ANI with comparable accuracy for closed or fragmented assemblies. Prefer `skani` for very large databases or when only incomplete genomes are available; both should agree for high-quality isolates.

## Inputs and upstream

Inputs are genome FASTA files listed in query/reference list files (one path per line). Assemblies can be draft, but very short contigs reduce mappable fragments and therefore aligned fraction. Do not mix plasmids-only or viral sequences into a prokaryotic ANI matrix without noting scope.

## Outputs and downstream

`-o` writes one row per query-reference comparison: query, reference, ANI, aligned-fragment counts in both directions, and aligned fraction. Feed the matrix to clustering (95% cut) and to dRep/GTDB-Tk for a cross-validated taxonomy. Keep the fragment length and tool version recorded.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `--ql`, `--rl` | Query and reference list files; one genome path per line. |
| `-o` | Output matrix path; append to existing file with `--matrix`-style workflows. |
| `--fragLen` | Fragment length (default 3000); keep consistent across a study for comparable matrices. |
| `--minFraction` | Minimum aligned fraction to report a pair; lower noise when many genomes are distant. |
| `-t` | Threads. |

## Workflow patterns

Build query and reference lists, then compute ANI all-vs-all (or one-vs-many) and cluster at the 95% ANI species boundary. For a new isolate, run it one-vs-many against a reference set to find the nearest named species. Cross-check borderline pairs (≈93–97% ANI) with dRep or GTDB-Tk, and record the fragment length and version.

```bash
conda run -n biomni-fastani --no-capture-output fastani \
  --ql query_list.txt --rl ref_list.txt -o ani.out --fragLen 3000 -t 16
```

## Validation and failure handling

Require non-empty FASTA and matching query/reference sets; a zero-mapping row usually means fragmented input, a different genetic code/domain, or a wrong file. Cross-check borderline species calls (≈93–97% ANI) with dRep or GTDB-Tk, and remember ANI depends on assembly quality and fragment length, not just true divergence.

## Reproducibility and audit

Record the fastANI version, fragment length, and the exact query/reference lists alongside the output matrix. Recompute a small comparison subset and confirm identical ANI values to verify reproducibility. Pair every ANI call with its aligned fraction, since ANI without coverage can be misleading.

```bash
# provenance: capture version and inputs
conda run -n biomni-fastani --no-capture-output fastani --version
sha256sum query_list.txt ref_list.txt ani.out
```
