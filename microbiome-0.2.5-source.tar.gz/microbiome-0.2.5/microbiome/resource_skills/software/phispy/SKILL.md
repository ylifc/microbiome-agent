---
name: PhiSpy
description: Prediction of prophage regions in complete or draft bacterial genomes using similarity and composition features.
kind: software
id: phispy
version: 2
selection_tier: conditional
environment: biomni-phispy
executables:
- PhiSpy.py
packages:
- phispy
channels:
- conda-forge
- bioconda
tasks:
- prophage prediction
- phage-mediated HGT detection
- temperate phage region annotation
databases: []
aliases:
- PhiSpy
- PhiSpy.py
- prophage prediction
- 前噬菌体预测
keywords:
- prophage
- phage
- HGT
- temperate phage
- lysogen
- genome
- 前噬菌体
- 水平基因转移
capabilities:
- identify prophage regions in genomes
- distinguish phage from host sequence
- annotate prophage boundaries
- report per-region scores
inputs:
- annotated bacterial genome in GenBank format (complete or draft)
- optional training set
outputs:
- prophage region table and coordinates
- per-region evidence files
upstream:
- bakta
- spades
- flye
- unicycler
downstream:
- phigaro
- vibrant
- checkv
software_family: phispy
documentation_status: CURATED_PROSE
upstream_tasks:
- prokka
downstream_tasks:
- phage phylogeny
parameter_guidance:
- '| `-o` | Output directory. |'
- '| `--threads` | Threads. |'
- '| `-t`/`--training_set` | Optional species-specific training set; record its source. |'
- '| `--keep_dropped_predictions` / `-k`/`--keep` | Retain dropped predictions/intermediate evidence files for review. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# PhiSpy

Use PhiSpy to predict prophage (temperate phage integrated into a bacterial chromosome) regions — a major route of horizontal gene transfer. It combines phage similarity and genomic composition features to call prophage boundaries.

```bash
conda run -n biomni-phispy --no-capture-output PhiSpy.py \
  genome.gb -o phispy_out --threads 8
```

## Capabilities and selection

PhiSpy detects prophages in complete and draft genomes and reports region coordinates and scores. Prefer it for isolate genome prophage annotation; for metagenome-wide viral/prophage mining combine it with geNomad/VirSorter2/VIBRANT. It is a region predictor, not a completeness assessor.

## Inputs and upstream

Input is an annotated bacterial genome in GenBank format (`.gb`/`.gbk`); annotate the assembly first with Prokka/Bakta. A generic training set is bundled; a species-specific training set (`-t`/`--training_set`) can improve calls when available. Draft genomes with short contigs reduce boundary accuracy.

## Outputs and downstream

Outputs are prophage coordinates, per-region evidence, and (in some modes) extracted prophage sequences. Feed prophage regions to VIBRANT/CheckV for viral quality and to phage phylogeny tools for classification.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `-o` | Output directory. |
| `--threads` | Threads. |
| `-t`/`--training_set` | Optional species-specific training set; record its source. |
| `--keep_dropped_predictions` / `-k`/`--keep` | Retain dropped predictions/intermediate evidence files for review. |

## Workflow patterns

```bash
conda run -n biomni-phispy --no-capture-output PhiSpy.py \
  isolate.gb -o phispy_out --threads 8
# cross-check with Phigaro/VIBRANT and assess with CheckV
```

## Validation and failure handling

Record the genome, training set, and PhiSpy version. Cross-check prophage calls with Phigaro/VIBRANT and inspect boundary genes (integrases/att sites). A region with weak similarity and composition evidence is a candidate, not a confirmed prophage.

## Reproducibility and audit

Record PhiSpy version, training set, and input genome. Re-run and diff the region table to confirm determinism. Keep the training set immutable and document its provenance.
