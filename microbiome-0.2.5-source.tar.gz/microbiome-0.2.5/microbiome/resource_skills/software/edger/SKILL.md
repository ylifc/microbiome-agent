---
name: edgeR
description: Bioconductor R package for differential expression analysis of count data using empirical Bayes and generalized
  linear models.
kind: software
id: edger
version: 2
selection_tier: conditional
environment: biomni-r
executables:
- Rscript
runtime:
  kind: r_package
  package: edgeR
  functions:
  - DGEList
  - glmQLFit
  - glmQLFTest
packages:
- bioconductor-edger
channels:
- conda-forge
- bioconda
tasks:
- differential gene expression
- count normalization
- multifactor and time-course testing
databases: []
aliases:
- edgeR
- 差异表达
- 计数数据统计
keywords:
- differential expression
- edgeR
- count matrix
- normalization
- GLM
- RNA-seq
- 差异表达
capabilities:
- normalize counts (TMM)
- estimate dispersion
- test differential expression with quasi-likelihood or exact tests
- support multifactor designs
inputs:
- count matrix (genes x samples)
- sample metadata with condition/design columns
outputs:
- normalized counts
- DE result tables with log2 fold change and FDR
- diagnostic plots
upstream:
- subread
- salmon
- bowtie2
downstream: []
software_family: edger
documentation_status: CURATED_PROSE
downstream_tasks:
- functional enrichment
- eggnog-mapper summaries
- volcano/heatmap reporting
parameter_guidance:
- '| Setting | Meaning and rule |'
- '| `calcNormFactors` | TMM normalization; keep defaults unless composition bias warrants otherwise. |'
- '| `estimateDisp` | Estimate common/trended/tagwise dispersion before fitting. |'
- '| `glmQLFit` / `glmQLFTest` | Quasi-likelihood fitting and testing; robust for low replicate counts. |'
- '| `makeContrasts` | Explicit contrast matrix; always state which condition is numerator vs denominator. |'
- '| `topTags(n=Inf)` | Extract all results with FDR. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# edgeR

Use edgeR for differential expression from gene-level count matrices. It is an R/Bioconductor package invoked through `Rscript`, and is a common companion or alternative to DESeq2.

```r
# de_edger.R — run via: conda run -n biomni-r Rscript de_edger.R counts.txt metadata.tsv out_dir
library(edgeR)
args <- commandArgs(trailingOnly = TRUE)
counts <- as.matrix(read.table(args[1], header = TRUE, row.names = 1, check.names = FALSE))
meta <- read.table(args[2], header = TRUE, row.names = 1, check.names = FALSE)
group <- factor(meta$condition)
y <- DGEList(counts = counts, group = group)
y <- calcNormFactors(y)                      # TMM normalization
design <- model.matrix(~ 0 + group)
colnames(design) <- levels(group)
y <- estimateDisp(y, design)
fit <- glmQLFit(y, design)                   # quasi-likelihood
qlf <- glmQLFTest(fit, contrast = makeContrasts(contrasts = "B-A", levels = design))
write.csv(topTags(qlf, n = Inf)$table, file.path(args[3], "edger_results.csv"))
```

## Capabilities and selection

edgeR normalizes counts with TMM, estimates dispersion, and tests differential expression using exact or quasi-likelihood methods, supporting multifactor and time-course designs. Prefer edgeR for count-based DE when small sample sizes or the quasi-likelihood framework is desired; DESeq2 and edgeR generally agree on strong effects. Do not run DE without replicates or a valid design.

## Inputs and upstream

Inputs are a genes × samples integer count matrix and a metadata table whose group column defines the design. Contrasts must be specified explicitly (e.g., B vs A) so the direction of the fold change is unambiguous.

## Outputs and downstream

Outputs are normalized counts, logFC/logCPM, likelihood-ratio statistics, p-values, and FDR. Feed significant genes into functional enrichment. Record normalization method, design, contrast, and FDR threshold.

## Parameters and decision rules

| Setting | Meaning and rule |
| --- | --- |
| `calcNormFactors` | TMM normalization; keep defaults unless composition bias warrants otherwise. |
| `estimateDisp` | Estimate common/trended/tagwise dispersion before fitting. |
| `glmQLFit` / `glmQLFTest` | Quasi-likelihood fitting and testing; robust for low replicate counts. |
| `makeContrasts` | Explicit contrast matrix; always state which condition is numerator vs denominator. |
| `topTags(n=Inf)` | Extract all results with FDR. |

## Workflow patterns

Load the featureCounts count matrix, normalize with TMM, estimate dispersion, fit a quasi-likelihood model with an explicit contrast, and export topTags for downstream functional enrichment.

```r
conda run -n biomni-r Rscript de_edger.R counts.txt metadata.tsv out_dir
```

## Validation and failure handling

Verify integer counts, sample/metadata name alignment, and replicate presence. A contrast/design mismatch is the usual failure — check that contrast column names match the design matrix. Report FDR and logFC direction explicitly; low-count genes should be filtered only with a documented rationale.
