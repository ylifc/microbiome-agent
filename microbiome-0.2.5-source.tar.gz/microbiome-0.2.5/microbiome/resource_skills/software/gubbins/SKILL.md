---
name: Gubbins
description: Iterative detection and masking of homologous recombination in bacterial whole-genome alignments.
kind: software
id: gubbins
version: 2
selection_tier: default
environment: biomni-gubbins
executables:
- run_gubbins.py
- plot_gubbins.R
- extract_gubbins_clade_statistics.py
packages:
- gubbins
channels:
- conda-forge
- bioconda
tasks:
- bacterial recombination detection
- recombination-filtered phylogeny
- core alignment masking
databases: []
aliases:
- Gubbins
- bacterial recombination
- 细菌重组过滤
keywords:
- recombination
- core genome
- phylogeny
- mask
- r/m
- bacterial evolution
- 同源重组
capabilities:
- iteratively identify elevated SNP-density regions
- infer recombination-filtered tree
- report branch events and r/m statistics
inputs:
- cleaned equal-length whole-core nucleotide alignment
- optional starting tree and clade definitions
outputs:
- filtered polymorphic alignment
- final Newick tree
- recombination GFF
- branch reconstruction
- summary statistics and plots
upstream:
- snippy
- mafft
downstream:
- snp-sites
- snp-dists
- iqtree2
- treetime
- beast2
software_family: gubbins
documentation_status: CURATED_PROSE
parameter_guidance:
- '| `--prefix` | Unique output prefix per cohort/parameterization. |'
- '| `--threads` | Bound CPU used by tree builders and reconstruction. |'
- '| `--tree-builder` | Final tree engine such as IQ-TREE/RAxML-NG; ensure it is installed in this environment. |'
- '| `--first-tree-builder` | Faster initial engine may reduce runtime; record difference from final engine. |'
- '| `--model`, `--first-model` | Substitution models compatible with selected tree builders and nucleotide data. |'
- '| `--iterations` | Maximum iterations; increase only when convergence was not reached. |'
- '| `--converge-method` | Convergence criterion; topology/recombination convergence choices can alter termination. |'
- '| `--min-snps`, window options | Recombination detection sensitivity; tune only with organism-specific evidence. |'
- '| `--starting-tree` | Use a validated same-alignment tree, never a tree from another coordinate set. |'
- '| `--filter-percentage` | Exclude samples with excessive gaps; disclose removals. |'
- '| `--remove-identical-sequences` | Reduce redundant computation but preserve mapping back to all isolates. |'
- '| `--mar` | Marginal reconstruction may reduce memory; compare behavior with default joint reconstruction. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# Gubbins

Use Gubbins for closely related bacterial whole-genome alignments where homologous recombination can distort a clonal tree. It is not designed for arbitrary gene alignments, viral recombination, or highly divergent multi-species datasets.

## Capabilities and selection

Gubbins iteratively builds a tree, reconstructs substitutions, and identifies dense SNP clusters consistent with recombination. The filtered alignment/tree supports clonal phylogeny; recombination calls remain model-based evidence and should be checked against alignment quality and biological context.

## Inputs and upstream

Input should be a cleaned full-core alignment, commonly `snippy-clean_full_aln core.full.aln`. All sequences must use one reference/core definition and unique safe names. Exclude severe contamination, distant outgroups, and alignments with too little shared core before running.

## Outputs and downstream

Outputs include `*.filtered_polymorphic_sites.fasta`, final tree, recombination predictions GFF, branch reconstruction, summary EMBl/text files, and logs. Use the filtered alignment for SNP-sites/IQ-TREE2 and preserve the unfiltered alignment for comparison. Report how much sequence was masked and topology changes.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `--prefix` | Unique output prefix per cohort/parameterization. |
| `--threads` | Bound CPU used by tree builders and reconstruction. |
| `--tree-builder` | Final tree engine such as IQ-TREE/RAxML-NG; ensure it is installed in this environment. |
| `--first-tree-builder` | Faster initial engine may reduce runtime; record difference from final engine. |
| `--model`, `--first-model` | Substitution models compatible with selected tree builders and nucleotide data. |
| `--iterations` | Maximum iterations; increase only when convergence was not reached. |
| `--converge-method` | Convergence criterion; topology/recombination convergence choices can alter termination. |
| `--min-snps`, window options | Recombination detection sensitivity; tune only with organism-specific evidence. |
| `--starting-tree` | Use a validated same-alignment tree, never a tree from another coordinate set. |
| `--filter-percentage` | Exclude samples with excessive gaps; disclose removals. |
| `--remove-identical-sequences` | Reduce redundant computation but preserve mapping back to all isolates. |
| `--mar` | Marginal reconstruction may reduce memory; compare behavior with default joint reconstruction. |

## Workflow patterns

```bash
conda run -n biomni-gubbins --no-capture-output run_gubbins.py \
  --prefix cohort --threads 16 --tree-builder iqtree --model GTR core.clean.full.aln
```

Rebuild/validate the final tree with the project's IQ-TREE2 skill rather than treating the internal tree as the only inference.

## Validation and failure handling

Require converged iterations, non-empty filtered alignment/tree/GFF, retained sample count, masked fraction, plausible event counts, and comparison of pre/post-filter topology. Failure often reflects invalid characters, duplicate names, too few variable sites, too much missing core, distant samples, or absent tree dependencies. Recombination-saturated or extremely short retained core is a stop condition for a simple clonal-tree claim.
