---
name: DESeq2
description: Bioconductor R package for differential expression analysis from count matrices with a design formula.
kind: software
id: deseq2
version: 2
selection_tier: conditional
environment: biomni-r
executables:
- Rscript
runtime:
  kind: r_package
  package: DESeq2
  functions:
  - DESeq
  - results
packages:
- bioconductor-deseq2
channels:
- conda-forge
- bioconda
tasks:
- differential gene expression
- replicate-aware normalization and dispersion estimation
- count-matrix statistical testing
databases: []
aliases:
- DESeq2
- DESeq 2
- 差异表达
keywords:
- differential expression
- DESeq2
- count matrix
- normalization
- dispersion
- RNA-seq
- 差异表达
capabilities:
- normalize counts and estimate dispersion
- test differential expression across conditions
- produce fold-change and adjusted p-value tables
- handle multifactor designs
inputs:
- count matrix (genes x samples)
- sample metadata with condition/design columns
outputs:
- normalized counts
- DE result tables with log2 fold change and padj
- diagnostic plots
upstream:
- subread
- salmon
- bowtie2
downstream: []
software_family: deseq2
documentation_status: CURATED_PROSE
downstream_tasks:
- functional enrichment
- eggnog-mapper summaries
- volcano/heatmap reporting
parameter_guidance:
- '| Setting | Meaning and rule |'
- '| `design = ~ condition` | Experimental design; include covariates only when the study design requires them. |'
- '| `results(contrast=...)` | Choose the comparison level explicitly; the first factor level is the default reference. |'
- '| `lfcShrink()` | Shrink log2 fold changes for ranking; report the method. |'
- '| `alpha = 0.05` | Significance threshold for adjusted p-values. |'
- '| `minReplicatesForReplace` | Keep defaults unless replicates are genuinely absent. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# DESeq2

Use DESeq2 for replicate-aware differential expression from a gene-level count matrix. It is an R/Bioconductor package invoked through `Rscript`, not a standalone binary.

```r
# de.R — run via: conda run -n biomni-r Rscript de.R counts.txt metadata.tsv out_dir
library(DESeq2)
args <- commandArgs(trailingOnly = TRUE)
counts <- as.matrix(read.table(args[1], header = TRUE, row.names = 1, check.names = FALSE))
meta <- read.table(args[2], header = TRUE, row.names = 1, check.names = FALSE)
meta$condition <- factor(meta$condition)
dds <- DESeqDataSetFromMatrix(countData = counts, colData = meta, design = ~ condition)
dds <- DESeq(dds)
res <- results(dds)
write.csv(as.data.frame(res), file.path(args[3], "deseq2_results.csv"))
```

## Capabilities and selection

DESeq2 normalizes counts, estimates dispersion, and tests differential expression with a design formula, producing log2 fold changes and multiple-testing-corrected p-values. It requires biological replicates per condition. Prefer DESeq2 (or edgeR) as the primary DE engine for microbial RNA-seq/metatranscriptomics; do not feed raw Salmon TPM as if it were a count matrix, and do not run DE without a proper design and replicates.

## Inputs and upstream

Inputs are a genes × samples integer count matrix (from featureCounts or Salmon's count output) and a metadata table whose columns match the design formula. The design must reflect the experiment (e.g., `~ condition`, optionally with covariates). Bind the reference/GFF and the count source.

## Outputs and downstream

Outputs are normalized counts, per-gene results (baseMean, log2FoldChange, lfcSE, pvalue, padj), and diagnostic plots. Feed significant genes into functional enrichment (eggNOG/COG/Pfam summaries). Report the design, the reference level, and the multiple-testing method.

## Parameters and decision rules

| Setting | Meaning and rule |
| --- | --- |
| `design = ~ condition` | Experimental design; include covariates only when the study design requires them. |
| `results(contrast=...)` | Choose the comparison level explicitly; the first factor level is the default reference. |
| `lfcShrink()` | Shrink log2 fold changes for ranking; report the method. |
| `alpha = 0.05` | Significance threshold for adjusted p-values. |
| `minReplicatesForReplace` | Keep defaults unless replicates are genuinely absent. |

## Workflow patterns

Build the DESeqDataSet from a featureCounts count matrix and metadata, run DESeq2, shrink fold changes, and export results for volcano/heatmap and functional enrichment. Report the design and reference level.

```r
conda run -n biomni-r Rscript de.R counts.txt metadata.tsv out_dir
```

## Validation and failure handling

Verify the count matrix is integer-valued, sample names match metadata exactly, and every condition has replicates. A design matrix error usually means a metadata/column mismatch. Without replicates, DESeq2's dispersion estimates are unreliable — use a replicate-aware alternative or clearly flag the limitation. Report padj, not raw p-values.
