---
name: Bowtie 2
description: Fast gapped alignment of short reads to nucleotide references.
kind: software
id: bowtie2
version: 2
environment: bowtie2
executables:
- bowtie2
- bowtie2-build
- bowtie2-inspect
packages:
- bowtie2
channels:
- conda-forge
- bioconda
tasks:
- short-read alignment
- metagenomic coverage mapping
- host-read filtering
databases: []
aliases:
- Bowtie2
- short-read aligner
- 短读长比对
keywords:
- alignment
- mapping
- host filtering
- coverage
- paired reads
- 比对
- 去宿主
capabilities:
- gapped short-read alignment
- paired-end alignment
- local or end-to-end mapping
- host depletion
inputs:
- reference nucleotide FASTA plus Bowtie 2 index
- single or paired FASTQ reads
outputs:
- SAM alignments
- Bowtie 2 index files
- alignment summary on stderr
upstream:
- seqkit
- megahit
- spades
- pvga
downstream:
- samtools
software_family: bowtie2
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Parameter | Meaning and setting rule |'
- '| `-x` | Required index prefix, not the FASTA filename unless both happen to match. |'
- '| `-1`, `-2`, `-U` | Paired mates or unpaired reads. Do not provide the same records twice. |'
- '| `--end-to-end` / `--local` | Full-read versus soft-clipped alignment. Use local only when partial alignment is biologically
  acceptable. |'
- '| `--very-sensitive` / `--very-sensitive-local` | Presets that adjust seed effort. More sensitive costs CPU and can increase
  ambiguous mappings. |'
- '| `-N` | Seed mismatches allowed. Keep within supported range; increasing sensitivity can reduce specificity. |'
- '| `-L` | Seed length. Shorter seeds help divergent/short reads but increase candidate alignments. |'
- '| `-i` | Seed interval function. Prefer presets unless benchmarking a defined assay. |'
- '| `--score-min` | Minimum valid score function. Any custom threshold must be documented with read length/error assumptions.
  |'
- '| `-I`, `-X` | Minimum/maximum paired fragment length. Set from library insert-size evidence. |'
- '| `--fr`, `--rf`, `--ff` | Mate orientation. Most Illumina paired libraries are `--fr`; confirm library design. |'
- '| `--no-mixed`, `--no-discordant` | Suppress singleton or discordant paired alignments when downstream analysis requires
  strict pairs. |'
- '| `-k N` / `-a` | Report multiple/all alignments. Avoid for routine coverage unless downstream weighting handles multi-mappers.
  |'
- '| `--no-unal` | Omit unaligned SAM records; reduces file size but changes denominator availability. |'
- '| `--un`, `--un-gz`, `--un-conc-gz` | Save unmapped reads, especially for host depletion. Verify generated mate filenames.
  |'
- '| `--rg-id`, `--rg` | Add read-group fields for sample provenance. |'
- '| `-p`, `--seed` | Threads and deterministic seed. Record both for reproducibility. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# Bowtie 2

Create an index from the exact reference used by the workflow and preserve its `.bt2` files with the run.

```bash
conda run -n bowtie2 --no-capture-output bowtie2-build reference.fasta reference_index
conda run -n bowtie2 --no-capture-output bowtie2 -x reference_index -1 reads_R1.fastq.gz -2 reads_R2.fastq.gz -S alignment.sam
```

Review the alignment summary and ensure paired-read handling matches the experimental design.

## Capabilities and selection

Bowtie 2 performs gapped short-read alignment with end-to-end or local modes and configurable sensitivity presets. It is well suited to host depletion, read recruitment, reference mapping, and contig coverage. It does not trim reads, sort BAM files, or call variants.

End-to-end mode expects the full read to align and is a conservative default for cleaned reads. Local mode allows soft-clipped ends and can improve mapping with residual adapters or divergent ends, but can also create misleading partial matches. Decide before examining desired outcomes.

## Inputs and upstream

`bowtie2-build` consumes nucleotide reference FASTA and produces an index prefix with `.bt2` or `.bt2l` files. `bowtie2` consumes that prefix plus single/paired FASTQ. References may come from MEGAHIT/SPAdes, host genomes, or user-curated sequences. Reads may be inspected with SeqKit and must preserve mate synchronization.

## Outputs and downstream

SAM output feeds SAMtools sort/index/statistics, then coverage-based binning or BCFtools. The stderr alignment summary is a required QC artifact. For host filtering, `--un-conc-gz` or related options can emit unmapped pairs that become assembly input, but filenames and mate layout must be checked.

## Parameters and decision rules

| Parameter | Meaning and setting rule |
| --- | --- |
| `-x` | Required index prefix, not the FASTA filename unless both happen to match. |
| `-1`, `-2`, `-U` | Paired mates or unpaired reads. Do not provide the same records twice. |
| `--end-to-end` / `--local` | Full-read versus soft-clipped alignment. Use local only when partial alignment is biologically acceptable. |
| `--very-sensitive` / `--very-sensitive-local` | Presets that adjust seed effort. More sensitive costs CPU and can increase ambiguous mappings. |
| `-N` | Seed mismatches allowed. Keep within supported range; increasing sensitivity can reduce specificity. |
| `-L` | Seed length. Shorter seeds help divergent/short reads but increase candidate alignments. |
| `-i` | Seed interval function. Prefer presets unless benchmarking a defined assay. |
| `--score-min` | Minimum valid score function. Any custom threshold must be documented with read length/error assumptions. |
| `-I`, `-X` | Minimum/maximum paired fragment length. Set from library insert-size evidence. |
| `--fr`, `--rf`, `--ff` | Mate orientation. Most Illumina paired libraries are `--fr`; confirm library design. |
| `--no-mixed`, `--no-discordant` | Suppress singleton or discordant paired alignments when downstream analysis requires strict pairs. |
| `-k N` / `-a` | Report multiple/all alignments. Avoid for routine coverage unless downstream weighting handles multi-mappers. |
| `--no-unal` | Omit unaligned SAM records; reduces file size but changes denominator availability. |
| `--un`, `--un-gz`, `--un-conc-gz` | Save unmapped reads, especially for host depletion. Verify generated mate filenames. |
| `--rg-id`, `--rg` | Add read-group fields for sample provenance. |
| `-p`, `--seed` | Threads and deterministic seed. Record both for reproducibility. |

## Workflow patterns

```bash
conda run -n bowtie2 --no-capture-output bowtie2-build host.fasta host_idx
conda run -n bowtie2 --no-capture-output bowtie2 \
  --very-sensitive --end-to-end -x host_idx \
  -1 sample_R1.fastq.gz -2 sample_R2.fastq.gz \
  --un-conc-gz clean_R%.fastq.gz -S host.sam -p 12
```

For depth mapping, align to the final assembly and sort with SAMtools in its declared environment. Do not derive abundance from host-filter SAM when the intended reference is the metagenome assembly.

## Validation and failure handling

Capture the alignment summary, validate index prefix/files, and inspect total, concordant, discordant, singleton, and overall rates. Unexpectedly high host mapping can be real or indicate wrong reference/sample; unexpectedly low mapping can reflect wrong mode/index, poor quality, divergence, or mate problems. A truncated SAM can result from disk pressure or failed redirection. When filtering, confirm retained pair counts and that both mate output files exist before assembly.
