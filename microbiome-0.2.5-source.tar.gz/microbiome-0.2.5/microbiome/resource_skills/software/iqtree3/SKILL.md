---
name: IQ-TREE 3
description: Current IQ-TREE maximum-likelihood phylogenetics using the installed IQ-TREE 3 environment.
kind: software
id: iqtree3
version: 2
environment: iqtree
executables:
- iqtree
- iqtree3
packages:
- iqtree
channels:
- conda-forge
- bioconda
tasks:
- maximum-likelihood phylogeny
- model selection
- ultrafast bootstrap
- SH-aLRT support
databases: []
aliases:
- IQ-TREE3
- iqtree
- iqtree3
- maximum likelihood tree
- 最大似然树
keywords:
- phylogeny
- model selection
- bootstrap
- SH-aLRT
- partition
- concordance
- 系统发育
- 建树
capabilities:
- maximum-likelihood tree search
- substitution-model selection
- partition and mixture models
- branch support and topology tests
inputs:
- validated nucleotide or protein multiple alignment
- optional partition file and constraint or starting trees
outputs:
- treefile Newick tree
- iqtree report
- log
- model and bootstrap or consensus files
upstream:
- mafft
- muscle
downstream:
- treetime
- paml
- beast2
software_family: iqtree3
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Parameter | Meaning and setting rule |'
- '| `-s`, `-st` | Alignment and optional forced sequence type. Codon mode needs frame-preserving alignment. |'
- '| `-m MFP` | ModelFinder Plus selection followed by tree inference. Fixed models require scientific justification. |'
- '| `-mset`, `-msub`, `-madd`, `-mrate` | Candidate model controls. Restrict for a priori reasons or feasibility and report
  restrictions. |'
- '| `-AIC`, `-AICc`, `-BIC` | Information criterion. Keep criterion consistent across comparisons. |'
- '| Partition options (`-p/-q/-Q` as documented) | Define data blocks and branch-length linkage. Load `iqtree -h` for exact
  IQ-TREE 3 semantics. |'
- '| `-B N`, `-bnni` | Ultrafast bootstrap and optional extra NNI correction. Use sufficient replicates and inspect convergence.
  |'
- '| `-alrt N` | SH-aLRT support replicates. Report together with its method name. |'
- '| `-b N` | Standard bootstrap; slower and algorithmically distinct. |'
- '| `-abayes`, `-lbp` | Other branch-support measures where appropriate. |'
- '| `-T N|AUTO`, thread cap | CPU strategy. Prevent AUTO from exceeding scheduler allocation. |'
- '| `-mem` | Memory cap where supported. Partition/mixture analyses can need much more memory. |'
- '| `-seed` | Reproducible random seed. |'
- '| `--prefix`, `-redo` | Output namespace and overwrite. Preserve prior runs under separate prefixes. |'
- '| `-t`, `-te`, `-g` | Starting tree, fixed-topology evaluation, or constraint tree; these have different inferential meanings.
  |'
- '| `-o` | Outgroup used to root reported tree. Confirm outgroup homology and placement. |'
- '| `-z`, `-zb`, `-au` | Candidate topology tests. Hypotheses should be specified before seeing test results. |'
- '| `--gcf`, `--scf` | Gene/site concordance factors; require correctly matched gene trees or loci and are not support substitutes.
  |'
- '| `-asr` | Ancestral reconstruction with uncertainty under fitted model. |'
- '| `--safe` | Numerical-safety behavior for difficult alignments where supported. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# IQ-TREE 3

This skill binds the existing IQ-TREE 3 environment. Use the generic `iqtree` entry point and record the exact version in analysis provenance.

```bash
conda run -n iqtree --no-capture-output iqtree -s alignment.fasta -m MFP -B 1000 -alrt 1000 -T AUTO --prefix results/tree
```

Require a validated multiple-sequence alignment. Check the `.log`, `.iqtree`, `.treefile`, and support values before accepting the result.

## Capabilities and selection

IQ-TREE 3 is the installed current major version for maximum-likelihood phylogenetics, ModelFinder, partition/mixture models, branch support, topology testing, ancestral reconstruction, and concordance factors. Its generic entry point is `iqtree`; record `iqtree --version` because published workflows may require IQ-TREE 2 behavior.

Use IQ-TREE 3 for new analyses unless compatibility, citation, or benchmark requirements pin IQ-TREE 2. Major-version substitution must be explicit because available models, defaults, performance, and option aliases can change.

## Inputs and upstream

Input is a validated equal-length nucleotide/protein/codon/morphological alignment from MAFFT/MUSCLE, with unique taxon names. Optional partition, starting tree, constraint tree, gene trees, and comparison trees must use matching labels and valid formats. Raw sequences must be aligned first.

## Outputs and downstream

The prefix anchors `.treefile`, `.iqtree`, `.log`, model, bootstrap/consensus, and optional test/concordance outputs. Newick trees feed TreeTime, PAML, BEAST initialization, visualization, or comparative workflows. Keep the full report and exact version with published trees.

## Parameters and decision rules

| Parameter | Meaning and setting rule |
| --- | --- |
| `-s`, `-st` | Alignment and optional forced sequence type. Codon mode needs frame-preserving alignment. |
| `-m MFP` | ModelFinder Plus selection followed by tree inference. Fixed models require scientific justification. |
| `-mset`, `-msub`, `-madd`, `-mrate` | Candidate model controls. Restrict for a priori reasons or feasibility and report restrictions. |
| `-AIC`, `-AICc`, `-BIC` | Information criterion. Keep criterion consistent across comparisons. |
| Partition options (`-p/-q/-Q` as documented) | Define data blocks and branch-length linkage. Load `iqtree -h` for exact IQ-TREE 3 semantics. |
| `-B N`, `-bnni` | Ultrafast bootstrap and optional extra NNI correction. Use sufficient replicates and inspect convergence. |
| `-alrt N` | SH-aLRT support replicates. Report together with its method name. |
| `-b N` | Standard bootstrap; slower and algorithmically distinct. |
| `-abayes`, `-lbp` | Other branch-support measures where appropriate. |
| `-T N|AUTO`, thread cap | CPU strategy. Prevent AUTO from exceeding scheduler allocation. |
| `-mem` | Memory cap where supported. Partition/mixture analyses can need much more memory. |
| `-seed` | Reproducible random seed. |
| `--prefix`, `-redo` | Output namespace and overwrite. Preserve prior runs under separate prefixes. |
| `-t`, `-te`, `-g` | Starting tree, fixed-topology evaluation, or constraint tree; these have different inferential meanings. |
| `-o` | Outgroup used to root reported tree. Confirm outgroup homology and placement. |
| `-z`, `-zb`, `-au` | Candidate topology tests. Hypotheses should be specified before seeing test results. |
| `--gcf`, `--scf` | Gene/site concordance factors; require correctly matched gene trees or loci and are not support substitutes. |
| `-asr` | Ancestral reconstruction with uncertainty under fitted model. |
| `--safe` | Numerical-safety behavior for difficult alignments where supported. |

## Workflow patterns

```bash
conda run -n iqtree --no-capture-output iqtree \
  -s homologs.aln.fasta -m MFP -B 1000 -bnni -alrt 1000 \
  -T AUTO --threads-max 16 -seed 42 --prefix iqtree3/run
```

For a strict IQ-TREE 2 reproduction, select the separate `iqtree2` skill and create its pinned environment after plan confirmation. Never only rename the executable in provenance.

## Validation and failure handling

Inspect input diagnostics, selected model/criterion, likelihood and search completion, bootstrap convergence, taxon set, support annotations, branch lengths, and warnings. Compare topology stability across alignment/model choices when conclusions are sensitive. Major-version warning or unknown-option errors require consulting local IQ-TREE 3 help and updating the command transparently, not silently dropping an analysis component.
