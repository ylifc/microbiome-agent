---
name: VIBRANT
description: Machine-learning recovery and annotation of viruses and prophages from metagenomic assemblies.
kind: software
id: vibrant
version: 2
selection_tier: conditional
environment: biomni-vibrant
executables:
- VIBRANT_run.py
packages:
- vibrant
channels:
- conda-forge
- bioconda
tasks:
- viral and prophage identification
- viral genome annotation
- AMG and auxiliary metabolic gene prediction
databases:
- vibrant
aliases:
- VIBRANT
- virus identification
- prophage recovery
- 病毒与前噬菌体识别
keywords:
- virus
- prophage
- metagenome
- annotation
- auxiliary metabolic genes
- HGT
- 病毒
- 前噬菌体
capabilities:
- recover viral and prophage sequences from assemblies
- annotate viral genes
- predict auxiliary metabolic genes and viral quality
- output genome maps
inputs:
- assembled metagenome contig FASTA
- a downloaded VIBRANT database
outputs:
- viral/prophage sequences
- gene annotations
- quality estimates
- genome maps
upstream:
- megahit
- spades
- flye
- checkv
downstream:
- checkv
- genomad
- virsorter2
software_family: vibrant
documentation_status: CURATED_PROSE
downstream_tasks:
- phage phylogeny
parameter_guidance:
- '| `-i` | Input contig FASTA. |'
- '| `-d` | VIBRANT database directory. |'
- '| `-t` | Threads. |'
- '| `-folder` | Output folder. |'
- '| `download-db.sh` | One-time database download. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# VIBRANT

Use VIBRANT to recover and annotate viruses and prophages from metagenomic assemblies, and to predict auxiliary metabolic genes (AMGs) that viruses carry — a key route of phage-mediated HGT.

```bash
# one-time database setup, then run
conda run -n biomni-vibrant --no-capture-output download-db.sh
conda run -n biomni-vibrant --no-capture-output VIBRANT_run.py \
  -i contigs.fasta -d vibrant_db -t 8 -folder vibrant_out
```

## Capabilities and selection

VIBRANT uses a machine-learning classifier plus HMM annotation to distinguish viral, prophage, and uncertain sequences and to predict viral quality and AMGs. Prefer it for metagenome-wide virus/prophage recovery with annotation; combine with geNomad and VirSorter2 for consensus. It works on assemblies, not raw reads.

## Inputs and upstream

Input is an assembled contig FASTA and a downloaded VIBRANT database (`download-db.sh`). Record the database version. Longer contigs give more reliable calls.

## Outputs and downstream

Outputs are viral/prophage sequences, gene annotations (VIBRANT format), AMG predictions, quality estimates, and genome maps. Feed viral candidates to CheckV for completeness and to geNomad/VirSorter2 for cross-validation.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `-i` | Input contig FASTA. |
| `-d` | VIBRANT database directory. |
| `-t` | Threads. |
| `-folder` | Output folder. |
| `download-db.sh` | One-time database download. |

## Workflow patterns

```bash
conda run -n biomni-vibrant --no-capture-output download-db.sh
conda run -n biomni-vibrant --no-capture-output VIBRANT_run.py \
  -i metagenome/contigs.fasta -d vibrant_db -t 8 -folder vibrant_out
```

## Validation and failure handling

Record the database version. A missing database is the usual failure — run `download-db.sh` first. Cross-check viral/prophage calls with geNomad/VirSorter2 and assess completeness with CheckV. AMG predictions are evidence of phage-carried metabolism, not proof of active transfer.

## Reproducibility and audit

Record VIBRANT version, database version, and input assembly. Re-run and diff the viral sequence set to confirm determinism. Keep the database immutable and document its provenance.
