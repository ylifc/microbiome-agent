---
name: MultiQC
description: Aggregates FastQC, fastp, alignment, assembly and other bioinformatics logs into a cohort-level report.
kind: software
id: multiqc
version: 2
selection_tier: default
environment: microbiome-multiqc
executables:
- multiqc
packages:
- multiqc
channels:
- conda-forge
- bioconda
tasks:
- multi-sample QC aggregation
- cross-sample outlier detection
- pipeline report generation
databases: []
aliases:
- MultiQC
- cohort QC
- 多样本质控汇总
keywords:
- QC
- report
- FastQC
- fastp
- samtools
- QUAST
- cohort
- outlier
capabilities:
- aggregate supported tool logs
- produce interactive HTML
- emit machine-readable parsed data
inputs:
- one results tree containing supported tool reports and logs
outputs:
- multiqc_report.html
- multiqc_data directory
- parsed metrics and source inventory
upstream:
- fastqc
- fastp
- samtools
- quast
- kraken2
downstream: []
software_family: multiqc
documentation_status: CURATED_PROSE
downstream_tasks:
- sample exclusion review
- frozen validation
- final reporting
parameter_guidance:
- '| Option | Rule |'
- '| search directory | Restrict to the current run tree. |'
- '| `--outdir` | Use a new dedicated summary directory. |'
- '| `--filename` | Give each workflow stage a stable distinct name. |'
- '| `--config` | Freeze custom sample cleaning/modules with the run. |'
- '| `--force` | Do not use in production; choose a new output. |'
- Resolve sample-name collisions before accepting any cohort table.
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# MultiQC

## Capabilities and selection

Use MultiQC once per cohort or workflow stage after the contributing tool reports exist. Do not treat it as a QC algorithm; it is an aggregator whose conclusions depend on source reports. It is the default cohort summary when two or more samples produce supported logs.

## Inputs and upstream

Input is a results tree, not raw sequencing data. Inventory expected FastQC/fastp/alignment/assembly reports and prevent old or unrelated run directories from being scanned.

## Outputs and downstream

The HTML report supports review; `multiqc_data/` supplies parsed tables and source paths for programmatic assertions and final reports.

## Parameters and decision rules

| Option | Rule |
| --- | --- |
| search directory | Restrict to the current run tree. |
| `--outdir` | Use a new dedicated summary directory. |
| `--filename` | Give each workflow stage a stable distinct name. |
| `--config` | Freeze custom sample cleaning/modules with the run. |
| `--force` | Do not use in production; choose a new output. |

Resolve sample-name collisions before accepting any cohort table.

## Workflow patterns

```bash
conda run -n microbiome-multiqc --no-capture-output multiqc results/ --outdir results/qc_summary --filename multiqc_report.html
```

## Validation and failure handling

Require a non-empty HTML report and `multiqc_data/`, retain the source-file inventory, and verify the expected sample count and modules. Missing reports are upstream failures, not permission to omit samples. Record the MultiQC version and configuration because filename cleaning and module selection can alter sample identities.

## Reproducibility and audit

Record the MultiQC version and the exact set of input reports/working directories it scanned. Re-run with the same inputs and confirm identical summary tables to verify reproducibility. Review per-module source data for any sample that MultiQC flags as an outlier before excluding it.

```bash
# provenance: capture version
conda run -n microbiome-multiqc --no-capture-output multiqc --version
```

```bash
# provenance: capture version
conda run -n microbiome-multiqc --no-capture-output multiqc --version
```
