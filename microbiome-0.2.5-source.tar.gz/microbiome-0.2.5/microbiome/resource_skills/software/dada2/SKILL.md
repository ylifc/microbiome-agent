---
name: DADA2
description: R workflow for amplicon quality filtering, error learning, ASV inference, merging, chimera removal, and taxonomy
  assignment.
kind: software
id: dada2
version: 2
selection_tier: conditional
environment: biomni-dada2
executables:
- Rscript
runtime:
  kind: r_package
  package: dada2
  functions:
  - filterAndTrim
  - learnErrors
  - dada
  - mergePairs
  - makeSequenceTable
  - removeBimeraDenovo
  - assignTaxonomy
  requires_packages:
  - jsonlite
packages:
- r-base
- bioconductor-dada2
- r-jsonlite
channels:
- conda-forge
- bioconda
tasks:
- amplicon denoising
- ASV inference
- chimera removal
- amplicon taxonomy assignment
databases: []
optional_databases:
- silva
- unite
aliases:
- DADA2
- ASV去噪
- 扩增子去噪
- 16S去噪
- ITS去噪
keywords:
- ASV
- amplicon
- 16S
- ITS
- quality profile
- error model
- chimera
- taxonomy
capabilities:
- infer exact sequence variants from Illumina reads
- learn run-specific error rates
- track reads through filtering merging and chimera removal
- assign taxonomy from a chosen reference
inputs:
- demultiplexed FASTQ files
- sample manifest
- optional SILVA or UNITE training FASTA for taxonomy
outputs:
- ASV count table
- representative ASV sequences
- taxonomy table
- read tracking table
- error and quality diagnostics
upstream:
- sra-toolkit
- fastp
downstream:
- qiime2
- ancombc2
- phyloseq
software_family: dada2
documentation_status: CURATED_PROSE
upstream_tasks:
- demultiplexing
downstream_tasks:
- ecological statistics
parameter_guidance:
- '| `filterAndTrim()` | Joint filtering/trimming; choose all thresholds from quality profiles and amplicon geometry. |'
- '| `truncLen` | Truncate at declining quality while preserving paired overlap; use `0` for no truncation when appropriate.
  |'
- '| `trimLeft` | Remove primers/adapters only when their exact retained length is known. |'
- '| `maxN=0` | DADA2 does not accept ambiguous bases during inference; keep zero for standard workflows. |'
- '| `maxEE` | Expected-error filter; often more interpretable than average quality and can differ by read direction. |'
- '| `truncQ` | Truncate at very low-quality bases; avoid redundant aggressive truncation. |'
- '| `rm.phix=TRUE` | Remove PhiX in Illumina data unless known absent. |'
- '| `compress` | Compress filtered FASTQ to control disk use. |'
- '| `multithread` | Enable bounded parallelism; set explicitly for reproducibility/resource control. |'
- '| `learnErrors(nbases=...)` | Learn errors from sufficient bases representing the run; inspect convergence and plots. |'
- '| `dada(pool=FALSE)` | Independent sample inference is efficient; `pool=TRUE` improves rare-variant sensitivity at high
  cost, `pool=''pseudo''` is a compromise. |'
- '| `mergePairs(minOverlap=...)` | Require biologically plausible overlap; never lower below what distinguishes random matches
  without justification. |'
- '| `mergePairs(maxMismatch=...)` | Usually zero for strict exact overlap; relax only after inspecting mismatch patterns.
  |'
- '| `makeSequenceTable()` | Build samples-by-ASVs matrix with exact sequences as columns. |'
- '| `removeBimeraDenovo(method=''consensus'')` | Standard multi-sample chimera removal; record large read loss and inspect
  causes. |'
- '| `assignTaxonomy(minBoot=...)` | Naive Bayesian taxonomy; choose SILVA/UNITE matching locus/orientation and record reference
  version. |'
- '| `assignSpecies()` | Exact species matching where supported; absence of match is not an error. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# DADA2

Use DADA2 for sequence-resolved Illumina amplicon denoising. It does not require a taxonomy database to infer ASVs; SILVA (16S/18S) or UNITE (ITS) is only introduced after the sequence table has passed quality and chimera checks.

## Capabilities and selection

DADA2 models run-specific errors and resolves amplicon sequence variants without clustering at an arbitrary identity threshold. It supports paired and single-end workflows; ITS commonly needs different trimming and merging rules from fixed-length 16S loci. QIIME 2 can call DADA2 through a plugin, but direct R use exposes diagnostics and scripting flexibility.

## Inputs and upstream

Provide demultiplexed reads with stable sample IDs and inspect `plotQualityProfile` before choosing trimming. Remove primers with a locus-aware tool or exact `trimLeft` values. Forward and reverse reads must retain enough high-quality overlap after truncation: expected amplicon length plus merging overlap must fit within retained lengths.

## Outputs and downstream

Persist the ASV matrix, ASV FASTA, taxonomy table, sample/read tracking table, filtering parameters, error plots and R session information. Import these artifacts into QIIME 2/phyloseq or construct a TreeSummarizedExperiment for ANCOM-BC2. Never report taxonomy-based abundance without retaining unclassified ASVs.

## Parameters and decision rules

| Function/argument | Meaning and setting rule |
| --- | --- |
| `filterAndTrim()` | Joint filtering/trimming; choose all thresholds from quality profiles and amplicon geometry. |
| `truncLen` | Truncate at declining quality while preserving paired overlap; use `0` for no truncation when appropriate. |
| `trimLeft` | Remove primers/adapters only when their exact retained length is known. |
| `maxN=0` | DADA2 does not accept ambiguous bases during inference; keep zero for standard workflows. |
| `maxEE` | Expected-error filter; often more interpretable than average quality and can differ by read direction. |
| `truncQ` | Truncate at very low-quality bases; avoid redundant aggressive truncation. |
| `rm.phix=TRUE` | Remove PhiX in Illumina data unless known absent. |
| `compress` | Compress filtered FASTQ to control disk use. |
| `multithread` | Enable bounded parallelism; set explicitly for reproducibility/resource control. |
| `learnErrors(nbases=...)` | Learn errors from sufficient bases representing the run; inspect convergence and plots. |
| `dada(pool=FALSE)` | Independent sample inference is efficient; `pool=TRUE` improves rare-variant sensitivity at high cost, `pool='pseudo'` is a compromise. |
| `mergePairs(minOverlap=...)` | Require biologically plausible overlap; never lower below what distinguishes random matches without justification. |
| `mergePairs(maxMismatch=...)` | Usually zero for strict exact overlap; relax only after inspecting mismatch patterns. |
| `makeSequenceTable()` | Build samples-by-ASVs matrix with exact sequences as columns. |
| `removeBimeraDenovo(method='consensus')` | Standard multi-sample chimera removal; record large read loss and inspect causes. |
| `assignTaxonomy(minBoot=...)` | Naive Bayesian taxonomy; choose SILVA/UNITE matching locus/orientation and record reference version. |
| `assignSpecies()` | Exact species matching where supported; absence of match is not an error. |

## Workflow patterns

```bash
conda run -n biomni-dada2 --no-capture-output Rscript scripts/run_dada2.R \
  manifest.tsv dada2_out parameters.json
```

The R script must expose the chosen filtering, inference, merge, chimera and taxonomy arguments in a machine-readable run manifest rather than burying them as undocumented constants.

## Validation and failure handling

Track reads at input, filtered, denoised, merged and non-chimeric stages per sample. Severe loss during filtering suggests bad truncation/primer handling; severe merge loss suggests insufficient overlap or wrong orientation; severe chimera loss suggests residual primers, mixed loci or upstream artifacts. Confirm error plots approximately follow observations and reject samples using declared, reviewable criteria rather than post hoc outcome optimization.

## Bundled adapter contract

The repository adapter requires an explicit JSON parameter file. The pipeline must declare and fingerprint the adapter and its parameter source. No parameters are tuned automatically. See `docs/cohort_workflows.md` for the schemas and output checks. Local package and scientific acceptance tests remain required before production.
