---
name: geNomad
description: Identification and annotation of virus and plasmid sequences.
kind: software
id: genomad
version: 2
environment: microbiome
executables:
- genomad
packages:
- genomad
channels:
- conda-forge
- bioconda
tasks:
- virus identification
- plasmid identification
- mobile element annotation
databases:
- genomad
aliases:
- geNomad
- virus plasmid detection
- 病毒识别
- 质粒识别
- 移动元件
keywords:
- virus
- plasmid
- mobile genetic element
- provirus
- annotation
- 病毒
- 质粒
capabilities:
- virus and plasmid sequence identification
- provirus detection
- gene annotation
- taxonomy and score summaries
inputs:
- assembled nucleotide FASTA from metagenome isolate or viral assembly
- READY geNomad database
outputs:
- virus and plasmid FASTA
- gene annotations
- score and taxonomy summary TSV
- provirus coordinates
upstream:
- megahit
- spades
- pvga
downstream:
- checkv
- bakta
software_family: genomad
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Parameter | Meaning and setting rule |'
- '| `end-to-end INPUT OUTPUT DATABASE` | Standard complete workflow. Use module commands separately when omitted options
  or intermediate control are needed. |'
- '| `--threads`, `-t` | Threads. Installed default may use all host CPUs, so always set an explicit allocation. |'
- '| `--cleanup` | Delete intermediates after success. Omit for auditing/debugging or planned module reuse. |'
- '| `--restart` | Overwrite intermediates. Use only when inputs/options changed intentionally; otherwise resume behavior
  may save work. |'
- '| `--disable-find-proviruses` | Skip host-integrated provirus search when only whole contigs are relevant. |'
- '| `--disable-nn-classification` | Skip neural and aggregated classification, leaving marker-driven evidence. Changes sensitivity.
  |'
- '| `--enable-score-calibration` | Calibrate scores for sample composition; enables meaningful `--max-fdr`. Adds computation.
  |'
- '| `--composition auto|metagenome|virome` | Composition assumption for calibration. Set from sample design when known. |'
- '| `--force-auto` | Force auto composition estimate for sample sizes where it would otherwise be avoided. Review stability.
  |'
- '| `--sensitivity`, `-s` | MMseqs2 marker search sensitivity; higher annotates more remote proteins but costs memory/time.
  |'
- '| `--splits` | Split MMseqs2 work to reduce memory at slower runtime. Increase after memory failure. |'
- '| `--skip-integrase-identification` | Disable integrase-based provirus boundary extension. May be conservative for boundaries.
  |'
- '| `--skip-trna-identification` | Disable tRNA-based boundary extension. |'
- '| `--lenient-taxonomy` | Report virus ranks below family where supported; lower-rank assignments need caution. |'
- '| `--full-ictv-lineage` | Include normally hidden ICTV ranks; combine with taxonomy setting as documented. |'
- '| `--conservative` | Stronger post-classification filters for high-confidence calls. Mutually exclusive with manual thresholds/relaxed.
  |'
- '| `--relaxed` | Disable post-classification filters for sensitive candidate discovery; expect more false positives. |'
- '| `--min-score` | Minimum virus/plasmid score, default 0.7 in this installed version. Tune with validation. |'
- '| `--max-fdr` | Maximum FDR only when score calibration ran; otherwise ignored. |'
- '| `--min-number-genes` | Minimum encoded genes for classification. Higher excludes very short elements. |'
- '| marker-enrichment thresholds | Separate plasmid/virus marker enrichment cutoffs; require annotation module output. |'
- '| hallmark thresholds | Minimum hallmark counts, with separate short-sequence thresholds under 2500 bp. |'
- '| `--max-uscg` | Maximum universal single-copy genes allowed; filters likely cellular contigs. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# geNomad

Use for virus/plasmid discovery from contigs. The final database argument is `Database/genomad/genomad_db`.

Run through `conda run -n microbiome`. Check summary TSV files and identified sequence FASTA files before continuing to CheckV.

## Capabilities and selection

geNomad identifies viruses, plasmids, and proviruses using gene annotation, marker and neural-network classification, aggregation, optional score calibration, and summary filtering. `end-to-end` runs the standard pipeline; individual modules provide granular control. It classifies sequence type and annotates markers, but viral completeness/host contamination should be assessed with CheckV.

Use assembled contigs from metagenomes/isolates or PVGA output. Score calibration can adapt decisions to metagenome versus virome composition. Conservative/relaxed presets alter false-positive sensitivity and cannot be combined with manual summary thresholds in the installed CLI.

## Inputs and upstream

Positional `INPUT` is nucleotide FASTA from MEGAHIT, SPAdes, or PVGA; `OUTPUT` is a new work directory; `DATABASE` is the READY geNomad directory such as `Database/genomad/genomad_db`. Sequence IDs must be unique. Very short contigs have fewer genes/markers and require cautious interpretation.

## Outputs and downstream

Outputs include annotated proteins/genes, provirus coordinates, marker/neural/aggregated classification scores, taxonomy, virus/plasmid summary TSVs, and identified virus/plasmid/provirus FASTA files. Viral FASTA feeds CheckV. Provirus coordinates must be retained if trimming/extracting from host contigs. Bakta or targeted protein analyses may use annotation outputs with provenance.

## Parameters and decision rules

| Parameter | Meaning and setting rule |
| --- | --- |
| `end-to-end INPUT OUTPUT DATABASE` | Standard complete workflow. Use module commands separately when omitted options or intermediate control are needed. |
| `--threads`, `-t` | Threads. Installed default may use all host CPUs, so always set an explicit allocation. |
| `--cleanup` | Delete intermediates after success. Omit for auditing/debugging or planned module reuse. |
| `--restart` | Overwrite intermediates. Use only when inputs/options changed intentionally; otherwise resume behavior may save work. |
| `--disable-find-proviruses` | Skip host-integrated provirus search when only whole contigs are relevant. |
| `--disable-nn-classification` | Skip neural and aggregated classification, leaving marker-driven evidence. Changes sensitivity. |
| `--enable-score-calibration` | Calibrate scores for sample composition; enables meaningful `--max-fdr`. Adds computation. |
| `--composition auto|metagenome|virome` | Composition assumption for calibration. Set from sample design when known. |
| `--force-auto` | Force auto composition estimate for sample sizes where it would otherwise be avoided. Review stability. |
| `--sensitivity`, `-s` | MMseqs2 marker search sensitivity; higher annotates more remote proteins but costs memory/time. |
| `--splits` | Split MMseqs2 work to reduce memory at slower runtime. Increase after memory failure. |
| `--skip-integrase-identification` | Disable integrase-based provirus boundary extension. May be conservative for boundaries. |
| `--skip-trna-identification` | Disable tRNA-based boundary extension. |
| `--lenient-taxonomy` | Report virus ranks below family where supported; lower-rank assignments need caution. |
| `--full-ictv-lineage` | Include normally hidden ICTV ranks; combine with taxonomy setting as documented. |
| `--conservative` | Stronger post-classification filters for high-confidence calls. Mutually exclusive with manual thresholds/relaxed. |
| `--relaxed` | Disable post-classification filters for sensitive candidate discovery; expect more false positives. |
| `--min-score` | Minimum virus/plasmid score, default 0.7 in this installed version. Tune with validation. |
| `--max-fdr` | Maximum FDR only when score calibration ran; otherwise ignored. |
| `--min-number-genes` | Minimum encoded genes for classification. Higher excludes very short elements. |
| marker-enrichment thresholds | Separate plasmid/virus marker enrichment cutoffs; require annotation module output. |
| hallmark thresholds | Minimum hallmark counts, with separate short-sequence thresholds under 2500 bp. |
| `--max-uscg` | Maximum universal single-copy genes allowed; filters likely cellular contigs. |

## Workflow patterns

```bash
conda run -n microbiome --no-capture-output genomad end-to-end \
  assembly.fasta genomad_out Database/genomad/genomad_db \
  --threads 16 --enable-score-calibration --composition metagenome
```

For candidate discovery run a clearly labeled relaxed analysis, but retain the default/conservative result for comparison. Send final viral candidates and proviruses to CheckV rather than equating geNomad score with completeness.

## Validation and failure handling

Require expected input sequence count, module completion, non-empty summary headers, score/class distributions, identified FASTA-to-summary ID agreement, and provirus coordinates within source contigs. MMseqs2 OOM calls for higher `--splits`/lower threads or more memory. Empty calls may be biological or caused by wrong database/path, short contigs, conservative filters, or disabled modules. Record database/software versions and every non-default filter.
