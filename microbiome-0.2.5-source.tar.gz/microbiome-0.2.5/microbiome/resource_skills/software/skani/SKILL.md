---
name: skani
description: Fast approximate nucleotide identity and aligned-fraction comparison for genomes, MAGs, and contigs.
kind: software
id: skani
version: 2
selection_tier: default
environment: biomni-skani
executables:
- skani
packages:
- skani
channels:
- conda-forge
- bioconda
tasks:
- ANI calculation
- reference selection
- genome dereplication screening
- taxonomic similarity
databases: []
aliases:
- skani ANI
- genome similarity
- 基因组ANI
keywords:
- ANI
- aligned fraction
- genome distance
- reference selection
- MAG comparison
- sketch
capabilities:
- pairwise ANI and aligned fraction
- one-to-many genome search
- all-versus-all triangle comparison
- reusable sketching
inputs:
- genome or MAG FASTA files
- file lists
- optional skani sketches
outputs:
- ANI aligned-fraction and fragment statistics in tabular form
- sketch files
upstream:
- quast
- ncbi-datasets
- drep
downstream:
- snippy
- panaroo
- gtdbtk
- drep
software_family: skani
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Command/option | Meaning and setting rule |'
- '| `skani dist QUERY REF` | Pairwise comparison; use for a small reviewed set. |'
- '| `skani search -d <db> <query.fa> ...` | Query a reference/sketch database with positional query genomes. |'
- '| `skani triangle` | All-versus-all matrix/list; estimate quadratic output size first. |'
- '| `skani sketch` | Build reusable sketches for a pinned collection. |'
- '| `-t`, `--threads` | Bound CPU. |'
- '| minimum AF/ANI filters | Apply only after inspecting actual distributions and task requirements. |'
- '| fragment/marker settings | Tune for unusually fragmented MAGs only with benchmark evidence. |'
- '| `--robust` or learned-AF options | Use version-specific advanced modes only after local help validation. |'
- ANI is interpretable only with adequate aligned fraction. Always retain both ANI and AF, and mark comparisons below the
  study's AF criterion as insufficient rather than distant by ANI alone.
- Sketches are versioned derived data. Record the source genome list/checksums, skani version and sketch command before reusing
  a collection.
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# skani

Use skani for rapid similarity screening and reference selection. ANI is not sufficient by itself for nomenclature, contamination diagnosis, or proving strain identity.

## Capabilities and selection

`dist` compares one query/reference pair, `search` compares queries against a reference collection, `triangle` performs all-versus-all comparison, and `sketch` accelerates repeated work. skani is robust for incomplete genomes but very low aligned fraction means ANI may not be interpretable.

## Inputs and upstream

Inputs are quality-controlled isolate genomes or MAG FASTA files. Exclude contaminated/chimeric assemblies or at least carry their quality flags. Use explicit file lists for large sets, stable IDs, and one versioned reference catalog.

## Outputs and downstream

Tables report ANI and aligned-fraction/directional coverage metrics. Use both ANI and coverage to select a Snippy reference, screen dereplication, or contextualize GTDB-Tk results. Preserve exact query/reference direction because coverage may be asymmetric.

## Parameters and decision rules

| Command/option | Meaning and setting rule |
| --- | --- |
| `skani dist QUERY REF` | Pairwise comparison; use for a small reviewed set. |
| `skani search -d <db> <query.fa> ...` | Query a reference/sketch database with positional query genomes. |
| `skani triangle` | All-versus-all matrix/list; estimate quadratic output size first. |
| `skani sketch` | Build reusable sketches for a pinned collection. |
| `-t`, `--threads` | Bound CPU. |
| minimum AF/ANI filters | Apply only after inspecting actual distributions and task requirements. |
| fragment/marker settings | Tune for unusually fragmented MAGs only with benchmark evidence. |
| `--robust` or learned-AF options | Use version-specific advanced modes only after local help validation. |

ANI is interpretable only with adequate aligned fraction. Always retain both ANI and AF, and mark comparisons below the study's AF criterion as insufficient rather than distant by ANI alone.

Sketches are versioned derived data. Record the source genome list/checksums, skani version and sketch command before reusing a collection.

## Workflow patterns

```bash
conda run -n biomni-skani --no-capture-output skani triangle genomes/*.fa -t 8 > genomes.skani.tsv
conda run -n biomni-skani --no-capture-output skani dist query.fasta candidate_reference.fasta -t 4 > reference_check.tsv
```

Select the nearest biologically appropriate reference with adequate aligned fraction, not simply the numerically highest ANI among poor matches.

## Validation and failure handling

Require every intended genome represented, parseable numeric ANI/AF, plausible self-comparisons, adequate aligned fraction for interpreted pairs, and no duplicate IDs. Missing output can mean genomes are below internal similarity/coverage thresholds rather than command failure. Very fragmented or contaminated MAGs should be quality-filtered or treated as uncertain, not forced with aggressive settings.
