---
name: Resistance Gene Identifier
description: CARD-based antimicrobial resistance annotation with RGI.
kind: software
id: rgi
version: 2
environment: biomni-rgi
executables:
- rgi
packages:
- rgi
channels:
- conda-forge
- bioconda
tasks:
- antimicrobial resistance annotation
databases:
- card
aliases:
- RGI
- Resistance Gene Identifier
- CARD annotation
- 耐药基因识别
keywords:
- AMR
- resistance
- CARD
- perfect strict loose
- contig
- protein
- 耐药
capabilities:
- CARD ontology-aware AMR prediction
- nucleotide contig analysis
- protein sequence analysis
- metagenomic read screening where supported
inputs:
- nucleotide contig FASTA or protein FASTA
- localized CARD database loaded into the RGI environment
outputs:
- main tabular report
- JSON report
- optional predicted protein or nucleotide sequences and visualization files
upstream:
- megahit
- spades
- prodigal
- bakta
downstream: []
software_family: rgi
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Command/parameter | Meaning and setting rule |'
- '| `rgi load --card_json ... --local` | Localize the prepared CARD JSON into this environment. Run only during resource
  preparation and record release. |'
- '| `rgi main --input_sequence` | Nucleotide or protein FASTA. Validate molecule type against `--input_type`. |'
- '| `--output_file` | Output prefix, not only a directory. Use unique sample/run prefixes. |'
- '| `--input_type contig|protein` | `contig` invokes gene finding/context; `protein` uses translated sequences. Choose from
  upstream artifact. |'
- '| `--alignment_tool DIAMOND|BLAST` | Search backend where supported. Record backend because sensitivity/performance can
  differ. |'
- '| `--include_loose` | Include lower-confidence Loose hits. Useful for discovery, but report separately and validate. |'
- '| `--include_nudge` | Include nudged calls where supported. Preserve nudge reason and original category. |'
- '| `--local` | Use locally loaded CARD data; required for the isolated offline resource policy. |'
- '| `--low_quality` | Relax behavior for fragmented/low-quality contigs. Use only with explicit input-quality caveat. |'
- '| `--clean` | Remove temporary files after success. Disable/omit when debugging. |'
- '| `-n`, `--threads` | CPU allocation. |'
- '| `--orf_finder` | ORF method for contig input where supported. Keep consistent with project gene-calling assumptions.
  |'
- '| `rgi database` | Inspect loaded database/version rather than assuming `rgi load` succeeded. |'
- '| `rgi bwt`, `kmer_query`, `heatmap` | Separate workflows with distinct input/output contracts; load their detailed help
  before planning them. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# RGI

Use for CARD resistance-gene annotation. If `biomni-rgi` does not exist, its creation must be disclosed in the plan before execution.

After the user places CARD files in `Database/card/`, localize once inside this environment:

```bash
conda run -n biomni-rgi --no-capture-output rgi load --card_json Database/card/card.json --local
```

Run analysis with a separate `conda run -n biomni-rgi` command. Do not install RGI into another workflow environment at runtime.

## Capabilities and selection

RGI applies CARD's Antibiotic Resistance Ontology and model-specific rules to identify resistance determinants. Results are classified as Perfect, Strict, or Loose according to CARD models rather than a single identity cutoff. It supports contig and protein inputs, and some releases provide metagenomic read workflows through separate subcommands. RGI predictions are genotype evidence, not automatic proof of phenotype.

Use RGI when CARD model semantics and mutation/variant logic matter. Use ABRicate for simpler nucleotide presence/absence screening across other gene databases. The CARD release must be explicitly loaded into the dedicated `biomni-rgi` environment from `Database/card/card.json`.

## Inputs and upstream

`contig` input is nucleotide FASTA from assemblies/bins; RGI performs ORF calling according to options. `protein` input is amino-acid FASTA from Prodigal/Bakta and bypasses nucleotide ORF context. Low-quality draft sequence may require the low-quality mode but should not be used to normalize poor input silently.

## Outputs and downstream

RGI writes a main tabular report and JSON, with optional predicted sequences, clean intermediate policy, and visualization/heatmap outputs depending on subcommand/version. Preserve ARO accession, model type, hit category, drug class, resistance mechanism, identity, coverage, SNP details, and CARD release. Downstream summaries should keep Perfect/Strict/Loose separate.

## Parameters and decision rules

| Command/parameter | Meaning and setting rule |
| --- | --- |
| `rgi load --card_json ... --local` | Localize the prepared CARD JSON into this environment. Run only during resource preparation and record release. |
| `rgi main --input_sequence` | Nucleotide or protein FASTA. Validate molecule type against `--input_type`. |
| `--output_file` | Output prefix, not only a directory. Use unique sample/run prefixes. |
| `--input_type contig|protein` | `contig` invokes gene finding/context; `protein` uses translated sequences. Choose from upstream artifact. |
| `--alignment_tool DIAMOND|BLAST` | Search backend where supported. Record backend because sensitivity/performance can differ. |
| `--include_loose` | Include lower-confidence Loose hits. Useful for discovery, but report separately and validate. |
| `--include_nudge` | Include nudged calls where supported. Preserve nudge reason and original category. |
| `--local` | Use locally loaded CARD data; required for the isolated offline resource policy. |
| `--low_quality` | Relax behavior for fragmented/low-quality contigs. Use only with explicit input-quality caveat. |
| `--clean` | Remove temporary files after success. Disable/omit when debugging. |
| `-n`, `--threads` | CPU allocation. |
| `--orf_finder` | ORF method for contig input where supported. Keep consistent with project gene-calling assumptions. |
| `rgi database` | Inspect loaded database/version rather than assuming `rgi load` succeeded. |
| `rgi bwt`, `kmer_query`, `heatmap` | Separate workflows with distinct input/output contracts; load their detailed help before planning them. |

## Workflow patterns

```bash
conda run -n biomni-rgi --no-capture-output rgi database --version
conda run -n biomni-rgi --no-capture-output rgi main \
  --input_sequence assembly.fasta --output_file rgi/sample \
  --input_type contig --alignment_tool DIAMOND \
  --include_loose --local --threads 12
```

For high-confidence surveillance, summarize Perfect and Strict first and retain Loose as hypothesis-generating evidence. For protein workflows, keep Prodigal/Bakta IDs mapped to contig coordinates.

## Validation and failure handling

Verify the loaded CARD version, non-empty structured outputs, input molecule/type agreement, category counts, ARO/model fields, and JSON parseability. Database-not-loaded errors require resource localization, not network access. Very many Loose-only calls can arise from fragmented proteins, permissive settings, or remote homology and need manual/model-aware filtering. Missing mutation context may result from protein-only input or insufficient sequence span.
