---
name: NCBI BLAST+
description: Local nucleotide and protein similarity search plus creation of workflow-specific BLAST databases.
kind: software
id: ncbi-blast
version: 2
environment: ncbi_blast
executables:
- blastn
- blastp
- blastx
- makeblastdb
- blastdbcmd
version_args:
- -version
packages:
- blast
channels:
- conda-forge
- bioconda
tasks:
- nucleotide similarity search
- protein similarity search
- local BLAST database indexing
databases: []
aliases:
- BLAST+
- blastn
- blastp
- blastx
- makeblastdb
- 序列相似性搜索
keywords:
- nucleotide search
- protein search
- translated search
- local database
- homology
- 同源比对
capabilities:
- blastn nucleotide search
- blastp protein search
- blastx translated query search
- local BLAST database construction and inspection
inputs:
- query FASTA
- nucleotide or protein BLAST database
- optional subject FASTA for pairwise search
outputs:
- tabular or XML or JSON or pairwise hits
- archive output
- BLAST database index files
upstream:
- seqkit
- prodigal
- bakta
downstream: []
software_family: ncbi-blast
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Parameter | Meaning and setting rule |'
- '| `makeblastdb -in`, `-dbtype` | Source FASTA and `nucl`/`prot` type. Wrong type cannot be repaired at query time. |'
- '| `makeblastdb -parse_seqids` | Preserve parseable sequence IDs for `blastdbcmd`; ensure IDs satisfy constraints and are
  unique. |'
- '| `-title`, `-taxid`, `-taxid_map` | Database provenance/taxonomy metadata. Use a correct mapping, not inferred filenames.
  |'
- '| `-query`, `-db`, `-subject`, `-out` | Query, indexed database, direct subject, and output. Use either database or subject
  mode as supported. |'
- '| `-task` | Algorithm variant: e.g. `megablast` for near-identical sequences, `dc-megablast` for more divergent nucleotide
  matches, `blastn-short` for short queries. |'
- '| `-evalue` | Statistical significance threshold. Interpret relative to query/database size. |'
- '| `-word_size` | Seed size. Smaller increases sensitivity and cost; short-query tasks set suitable values. |'
- '| `-perc_identity` | Minimum nucleotide percent identity where supported. Combine with query coverage. |'
- '| `-qcov_hsp_perc` | Minimum query coverage per HSP. Prevent short local matches from being treated as full evidence. |'
- '| `-max_target_seqs` | Limit retained targets. Do not use a tiny value when alternate hits or ranking stability matter.
  |'
- '| `-max_hsps` | HSPs per subject; repeated/domain structures may need multiple HSPs. |'
- '| `-culling_limit` | Remove lower-scoring hits enveloped by stronger hits on query; changes biological interpretation.
  |'
- '| `-best_hit_overhang`, `-best_hit_score_edge` | Best-hit heuristics. Use only with documented thresholds and retained
  alternatives where needed. |'
- '| `-dust` / `-seg`, `-soft_masking` | Nucleotide/protein low-complexity masking. Disabling can inflate spurious hits. |'
- '| `-strand` | Nucleotide query strand restriction when orientation is known. |'
- '| `-reward`, `-penalty`, `-gapopen`, `-gapextend` | Nucleotide scoring. Use task-compatible combinations and benchmark
  custom settings. |'
- '| `-matrix`, gap costs | Protein substitution matrix and gaps. Choose for expected divergence/query length. |'
- '| `-query_loc`, `-subject_loc` | Restrict regions using BLAST coordinate syntax; record coordinates. |'
- '| `-outfmt ''6 ...''` | Explicit machine-readable columns; include coverage/length/score fields needed downstream. |'
- '| `-num_threads` | Local CPU threads. It is incompatible with some remote modes; this workflow prioritizes local databases.
  |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# NCBI BLAST+

Local validated documentation: `docs/version.txt` and `docs/help.txt`. Project bootstrap captures a complete version-matched help copy in its Knowledge directory.

Use `makeblastdb` for user-provided workflow references. Persistent public reference databases must have their own database skill under `Database/<id>/`.

```bash
conda run -n ncbi_blast --no-capture-output makeblastdb -in reference.fasta -dbtype nucl -out reference_db
conda run -n ncbi_blast --no-capture-output blastn -query query.fasta -db reference_db -out hits.tsv -outfmt 6
```

Verify database type, query molecule type, output format fields, and non-empty index files.

## Capabilities and selection

BLAST+ provides nucleotide, protein, and translated similarity search plus local database management. Use `blastn` for nucleotide-nucleotide, `blastp` for protein-protein, and `blastx` for translated nucleotide query against protein database. DIAMOND is faster for large protein searches; BLAST+ offers mature task variants and detailed alignment behavior.

## Inputs and upstream

Queries are FASTA from SeqKit, assemblies, Prodigal, or Bakta. A local database is built from nucleotide/protein FASTA with `makeblastdb`, or provided by a separately registered database skill. Query molecule, program, and database type must agree. `-subject` enables small direct pairwise searches without a persistent database.

## Outputs and downstream

Output may be pairwise text, tabular (`-outfmt 6/7`), XML, JSON, ASN.1 archive, or SAM-like formats depending on program/version. For pipelines, select explicit tabular fields. `blastdbcmd` can inspect metadata and retrieve matching database sequences for validation or downstream alignment.

## Parameters and decision rules

| Parameter | Meaning and setting rule |
| --- | --- |
| `makeblastdb -in`, `-dbtype` | Source FASTA and `nucl`/`prot` type. Wrong type cannot be repaired at query time. |
| `makeblastdb -parse_seqids` | Preserve parseable sequence IDs for `blastdbcmd`; ensure IDs satisfy constraints and are unique. |
| `-title`, `-taxid`, `-taxid_map` | Database provenance/taxonomy metadata. Use a correct mapping, not inferred filenames. |
| `-query`, `-db`, `-subject`, `-out` | Query, indexed database, direct subject, and output. Use either database or subject mode as supported. |
| `-task` | Algorithm variant: e.g. `megablast` for near-identical sequences, `dc-megablast` for more divergent nucleotide matches, `blastn-short` for short queries. |
| `-evalue` | Statistical significance threshold. Interpret relative to query/database size. |
| `-word_size` | Seed size. Smaller increases sensitivity and cost; short-query tasks set suitable values. |
| `-perc_identity` | Minimum nucleotide percent identity where supported. Combine with query coverage. |
| `-qcov_hsp_perc` | Minimum query coverage per HSP. Prevent short local matches from being treated as full evidence. |
| `-max_target_seqs` | Limit retained targets. Do not use a tiny value when alternate hits or ranking stability matter. |
| `-max_hsps` | HSPs per subject; repeated/domain structures may need multiple HSPs. |
| `-culling_limit` | Remove lower-scoring hits enveloped by stronger hits on query; changes biological interpretation. |
| `-best_hit_overhang`, `-best_hit_score_edge` | Best-hit heuristics. Use only with documented thresholds and retained alternatives where needed. |
| `-dust` / `-seg`, `-soft_masking` | Nucleotide/protein low-complexity masking. Disabling can inflate spurious hits. |
| `-strand` | Nucleotide query strand restriction when orientation is known. |
| `-reward`, `-penalty`, `-gapopen`, `-gapextend` | Nucleotide scoring. Use task-compatible combinations and benchmark custom settings. |
| `-matrix`, gap costs | Protein substitution matrix and gaps. Choose for expected divergence/query length. |
| `-query_loc`, `-subject_loc` | Restrict regions using BLAST coordinate syntax; record coordinates. |
| `-outfmt '6 ...'` | Explicit machine-readable columns; include coverage/length/score fields needed downstream. |
| `-num_threads` | Local CPU threads. It is incompatible with some remote modes; this workflow prioritizes local databases. |

## Workflow patterns

```bash
conda run -n ncbi_blast --no-capture-output makeblastdb \
  -in reference.fasta -dbtype nucl -parse_seqids -title sample_reference -out reference_db
conda run -n ncbi_blast --no-capture-output blastn \
  -query query.fasta -db reference_db -task megablast \
  -evalue 1e-10 -qcov_hsp_perc 80 -max_target_seqs 20 -num_threads 12 \
  -out hits.tsv -outfmt '6 qseqid sseqid pident length qcovhsp evalue bitscore'
```

Use `blastdbcmd -db reference_db -info` and sequence retrieval to validate database identity. Persistent public databases belong under their own `Database/<id>/` and may be fetched only when their Skill adds a MICROBIOME_DB_ACQUISITION marker to the confirmed plan.

## Validation and failure handling

Check index files/nonzero volume metadata, query count, output fields, hit/no-hit distribution, identity, coverage, and taxonomic/functional plausibility. `BLAST Database error` commonly means wrong prefix, incomplete index volumes, permission issues, or program/database molecule mismatch. Empty output may be valid but must be tested with a known query or relaxed diagnostic search before changing biological thresholds.
