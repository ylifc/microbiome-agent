---
name: mlst
description: Assigns classical seven-locus MLST sequence types to bacterial assemblies.
kind: software
id: mlst
version: 2
selection_tier: conditional
environment: microbiome-mlst
executables:
- mlst
packages:
- mlst
channels:
- conda-forge
- bioconda
tasks:
- bacterial sequence typing
- isolate identity QC
- scheme allele reporting
databases: []
aliases:
- MLST
- sequence type
- ST typing
- 多位点序列分型
keywords:
- bacterial isolate
- PubMLST
- sequence type
- alleles
- typing
capabilities:
- automatic scheme selection
- allele calls
- sequence-type assignment
- tabular multi-isolate output
inputs:
- quality-controlled bacterial isolate assembly FASTA
outputs:
- scheme
- sequence type and per-locus allele table
upstream:
- spades
- flye
- unicycler
- quast
downstream: []
software_family: mlst
documentation_status: CURATED_PROSE
downstream_tasks:
- outbreak metadata
- phylogeny
- sample identity review
parameter_guidance:
- '| `--scheme` | Force a specific scheme (e.g., `ecoli`); use when auto-detection is wrong. |'
- '| `--label` | Sample label for the output row. |'
- '| `--json` / `--legacy` | Output format; keep default tabular for downstream joins. |'
- '| `--threads` | Threads. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# Use `mlst` for classical scheme-based bacterial typing when the target species has a supported scheme. It complements whole-genome SNP/cgMLST analysis and does not replace it.

## Capabilities and selection

mlst assigns seven-locus MLST sequence types by scanning an assembly against curated PubMLST/Enterobase schemes and reporting the scheme, sequence type, and per-locus alleles. Prefer it for quick, standardized isolate typing and identity QC; use cgMLST/wgMLST or core-SNP phylogeny for higher-resolution outbreak resolution.

## Inputs and upstream

Input is a quality-controlled isolate assembly FASTA (SPAdes/Flye/Unicycler output). Pass `--scheme` to force a scheme when auto-detection is ambiguous; otherwise let it auto-select, then confirm the detected scheme is the expected species.

## Outputs and downstream

Output is a TSV with sample, scheme, sequence type, and allele calls per locus. Feed sequence types into outbreak metadata and sample-identity review, and cross-check against SNP/cgMLST clustering.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `--scheme` | Force a specific scheme (e.g., `ecoli`); use when auto-detection is wrong. |
| `--label` | Sample label for the output row. |
| `--json` / `--legacy` | Output format; keep default tabular for downstream joins. |
| `--threads` | Threads. |

## Workflow patterns

```bash
conda run -n microbiome-mlst --no-capture-output mlst \
  --label sample_A assembly.fa > sample_A.mlst.tsv
```

## Validation and failure handling

Confirm the detected scheme matches the expected species; a wrong scheme usually means a misidentified or contaminated isolate. Treat missing/partial allele calls as a QC flag, not a definitive ST. Record the scheme database version so sequence types are reproducible.

## Reproducibility and audit

Record the mlst software version and the scheme database version next to every typing table. Re-run on the same assembly and confirm identical allele calls to verify reproducibility. Treat a scheme change or missing allele as a flag for review, and cross-check the sequence type against SNP/cgMLST clustering.

```bash
# provenance: capture version and scheme list
conda run -n microbiome-mlst --no-capture-output mlst --version
conda run -n microbiome-mlst --no-capture-output mlst --list | head -40
```

If multiple schemes match, record which scheme was chosen and why; the auto-detected scheme must be verified against the expected species.
