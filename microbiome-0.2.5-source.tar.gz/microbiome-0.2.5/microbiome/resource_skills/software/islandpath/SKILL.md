---
name: IslandPath-DIMOB
description: Prediction of genomic islands and horizontally transferred regions in annotated bacterial genomes via dinucleotide
  bias and mobility genes.
kind: software
id: islandpath
version: 2
selection_tier: conditional
environment: biomni-islandpath
executables:
- islandpath
packages:
- islandpath
channels:
- conda-forge
- bioconda
tasks:
- genomic island prediction
- horizontally transferred region detection
- mobility gene annotation
databases: []
aliases:
- IslandPath
- IslandPath-DIMOB
- genomic island prediction
- 基因组岛预测
- 水平转移区域
keywords:
- genomic island
- HGT
- dinucleotide
- mobility genes
- prophage
- 基因组岛
- 水平基因转移
capabilities:
- predict genomic islands using dinucleotide bias and mobility genes
- flag prophage/integron/transposon-associated regions
- output per-island coordinates
inputs:
- annotated bacterial genome in GenBank (.gbk) or EMBL (.embl) format
outputs:
- tab-delimited island table (island id
- start
- end)
upstream:
- bakta
- spades
- flye
- unicycler
downstream:
- phispy
- phigaro
- vibrant
software_family: islandpath
documentation_status: CURATED_PROSE
upstream_tasks:
- prokka
downstream_tasks:
- mobility gene annotation
parameter_guidance:
- '| `<genome.gbk>` | Positional argument: annotated GenBank/EMBL genome; record its accession/version. |'
- '| `<outputfile>` | Positional argument: output tab-delimited island table path. |'
- '| config file | Bundled params; record the tool version. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# IslandPath-DIMOB

Use IslandPath-DIMOB to predict genomic islands — regions acquired by horizontal gene transfer — in annotated bacterial genomes. It combines dinucleotide-composition bias with the presence of mobility genes (integrases, transposases) and is the engine behind IslandViewer's composition-based predictions.

```bash
conda run -n biomni-islandpath --no-capture-output islandpath \
  genome.gbk islandpath.out
```

## Capabilities and selection

IslandPath-DIMOB flags regions whose dinucleotide signature deviates from the genome-wide average and that carry mobility genes, producing per-island coordinates in a tab-delimited table. Prefer it for isolate-genome HGT-region screening; cross-check islands with prophage predictors (PhiSpy/Phigaro) and geNomad mobility genes. It is a composition/mobility heuristic, not a phylogenetic proof of transfer.

## Inputs and upstream

Input is an annotated complete genome in GenBank (`.gbk`) or EMBL (`.embl`) format, NOT raw FASTA. Annotate the assembly first with Bakta or Prokka before running the predictor. The tool relies on HMMER/BioPerl (bundled by the conda package). Record the genome accession and any versioned reference.

## Outputs and downstream

Output is a tab-delimited island table (`GI_<n>  <start>  <end>`) written to the output-file argument, not a GFF and not stdout. Feed predicted islands to PhiSpy/Phigaro/VIBRANT for prophage resolution and to mobility-gene annotation for mechanistic interpretation.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `<genome.gbk>` | Positional argument: annotated GenBank/EMBL genome; record its accession/version. |
| `<outputfile>` | Positional argument: output tab-delimited island table path. |
| config file | Bundled params; record the tool version. |

## Workflow patterns

```bash
# annotate the assembly first, then predict islands
conda run -n biomni-islandpath --no-capture-output islandpath \
  isolate.gbk islandpath.out
```

## Validation and failure handling

Record the genome and tool version. Cross-check predicted islands with prophage predictors and inspect mobility genes at island boundaries. A region with dinucleotide bias but no mobility genes is a weaker HGT candidate. Missing HMMER/BioPerl indicates an incomplete environment.

## Reproducibility and audit

Record the IslandPath-DIMOB version, the genome accession, and the tool configuration. Re-run on the same genome and diff the island table to confirm determinism. Keep the config file immutable and document its provenance so island calls remain traceable across analyses.

Record the output island table and the exact GenBank/EMBL input so each called island can be traced back to its source annotation.
