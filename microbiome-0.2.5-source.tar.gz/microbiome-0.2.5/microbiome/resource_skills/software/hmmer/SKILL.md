---
name: HMMER
description: Profile hidden Markov model search, construction, alignment, and iterative protein homology analysis.
kind: software
id: hmmer
version: 2
selection_tier: conditional
environment: biomni-hmmer
executables:
- hmmsearch
- hmmscan
- phmmer
- jackhmmer
- hmmbuild
- hmmpress
- hmmalign
version_args: []
packages:
- hmmer
channels:
- conda-forge
- bioconda
tasks:
- protein family search
- domain annotation
- profile HMM construction
- iterative homology search
databases:
- pfam
aliases:
- HMMER
- hmmsearch
- hmmscan
- Pfam搜索
- 蛋白结构域搜索
keywords:
- profile HMM
- protein family
- domain
- Pfam
- E-value
- bit score
- domtblout
- sequence homology
capabilities:
- search proteins against profile HMMs
- search protein sequences against pressed libraries
- construct profiles from curated alignments
- align sequences to an existing profile
inputs:
- protein FASTA and profile HMM for hmmsearch
- protein sequence and pressed HMM library for hmmscan
- curated multiple sequence alignment for hmmbuild
outputs:
- human-readable reports
- tabular sequence hits
- domain tables
- profile HMMs
- HMM-guided alignments
upstream:
- prodigal
- bakta
- mafft
downstream:
- antismash
software_family: hmmer
documentation_status: CURATED_PROSE
upstream_tasks:
- prokka
downstream_tasks:
- functional annotation
- marker-gene phylogeny
- custom gene screening
parameter_guidance:
- '| Command/option | Meaning and setting rule |'
- '| `hmmsearch` | HMM query versus protein sequence database. |'
- '| `hmmscan` | Protein sequence(s) versus a pressed profile library such as Pfam. |'
- '| `phmmer` / `jackhmmer` | Single-sequence search / iterative homolog discovery; audit iteration drift. |'
- '| `hmmbuild` | Build a profile from a curated multiple alignment. |'
- '| `hmmpress` | Create binary indexes required for efficient `hmmscan`. |'
- '| `-E`, `--domE` | Reporting E-value thresholds for sequences/domains; database size affects interpretation. |'
- '| `--incE`, `--incdomE` | Inclusion thresholds used by iterative searches and alignments. |'
- '| `-T`, `--domT` | Absolute bit-score thresholds; prefer validated family-specific cutoffs when available. |'
- '| `--cut_ga` | Use curated gathering thresholds from models such as Pfam; preferred over arbitrary E-values when present.
  |'
- '| `--cut_tc` / `--cut_nc` | Trusted/noise cutoffs for controlled sensitivity-specificity choices. |'
- '| `--tblout` / `--domtblout` | Machine-readable sequence/domain outputs; always request the one needed downstream. |'
- '| `--cpu` | CPU threads; record version because heuristic filters and scores can change. |'
- '| `--max` | Disable acceleration heuristics for maximum sensitivity at major cost; reserve for short/remote targets. |'
- '| `--notextw` | Prevent report line wrapping when human-readable output must be archived. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# HMMER

Use HMMER when profile-based protein family or domain detection is required. Pfam is an optional reference library for general domain annotation; custom HMMs remain valid without Pfam, but their provenance, training alignment and thresholds must travel with the run.

## Capabilities and selection

`hmmsearch` compares one or more HMM profiles to protein sequences. `hmmscan` compares protein sequence(s) against a pressed HMM library such as Pfam. `phmmer` searches by a single protein sequence, `jackhmmer` iterates homolog collection, `hmmbuild` creates a profile from an alignment, and `hmmalign` aligns sequences to a profile. Choose the command by query/target type, not by name familiarity.

## Inputs and upstream

Translate genes consistently with Prodigal/Bakta/Prokka and preserve identifiers. Build custom HMMs from a curated homolog alignment, not unreviewed mixed proteins. `hmmscan` libraries must be processed by `hmmpress`; Pfam files and indexes belong under `Database/pfam/` and are prepared by the Pfam database skill.

## Outputs and downstream

Use `--tblout` for sequence-level summaries and `--domtblout` for domain coordinates and independent/conditional domain statistics. These stable tabular files should drive parsing; the console report is for inspection. Coordinates can feed domain architecture, marker extraction, antiSMASH-like custom rules, or phylogenetic sequence selection.

## Parameters and decision rules

| Command/option | Meaning and setting rule |
| --- | --- |
| `hmmsearch` | HMM query versus protein sequence database. |
| `hmmscan` | Protein sequence(s) versus a pressed profile library such as Pfam. |
| `phmmer` / `jackhmmer` | Single-sequence search / iterative homolog discovery; audit iteration drift. |
| `hmmbuild` | Build a profile from a curated multiple alignment. |
| `hmmpress` | Create binary indexes required for efficient `hmmscan`. |
| `-E`, `--domE` | Reporting E-value thresholds for sequences/domains; database size affects interpretation. |
| `--incE`, `--incdomE` | Inclusion thresholds used by iterative searches and alignments. |
| `-T`, `--domT` | Absolute bit-score thresholds; prefer validated family-specific cutoffs when available. |
| `--cut_ga` | Use curated gathering thresholds from models such as Pfam; preferred over arbitrary E-values when present. |
| `--cut_tc` / `--cut_nc` | Trusted/noise cutoffs for controlled sensitivity-specificity choices. |
| `--tblout` / `--domtblout` | Machine-readable sequence/domain outputs; always request the one needed downstream. |
| `--cpu` | CPU threads; record version because heuristic filters and scores can change. |
| `--max` | Disable acceleration heuristics for maximum sensitivity at major cost; reserve for short/remote targets. |
| `--notextw` | Prevent report line wrapping when human-readable output must be archived. |

## Workflow patterns

```bash
conda run -n biomni-hmmer --no-capture-output hmmsearch --cpu 8 \
  --tblout marker.tbl --domtblout marker.domtbl marker.hmm proteins.faa > marker.hmmsearch.txt
conda run -n biomni-hmmer --no-capture-output hmmscan --cpu 8 --cut_ga \
  --domtblout pfam.domtbl Database/pfam/Pfam-A.hmm proteins.faa > pfam.hmmscan.txt
```

## Validation and failure handling

Require valid non-empty query/target files, parseable tabular outputs, explicit threshold provenance, and no duplicate IDs that would corrupt joins. A no-hit result is biological only after confirming alphabet, query orientation, library indexes and permissive diagnostic thresholds. Truncated proteins can yield partial domains; filter by coverage as well as E-value/score.
