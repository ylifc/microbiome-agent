---
name: ClonalFrameML
description: Maximum-likelihood inference of homologous recombination and point mutation in whole bacterial genomes.
kind: software
id: clonalframeml
version: 2
selection_tier: conditional
environment: biomni-clonalframeml
executables:
- ClonalFrameML
packages:
- clonalframeml
channels:
- conda-forge
- bioconda
tasks:
- homologous recombination detection
- recombination vs mutation inference
- HGT quantification in bacterial populations
databases: []
aliases:
- ClonalFrameML
- recombination detection
- 重组检测
- 同源重组
keywords:
- recombination
- homologous recombination
- HGT
- bacterial population
- phylogeny
- 重组
- 水平基因转移
capabilities:
- infer recombination events on a core-genome alignment
- estimate recombination-to-mutation ratio
- correct phylogeny for recombination
- output per-site recombination maps
inputs:
- core-genome alignment (multi-FASTA)
- an initial maximum-likelihood tree
outputs:
- recombination-corrected phylogeny
- per-site recombination map
- parameters R/theta and branch lengths
upstream:
- snippy
- snp-sites
- iqtree2
- panaroo
downstream: []
software_family: clonalframeml
documentation_status: CURATED_PROSE
downstream_tasks:
- phylogenetic interpretation
- outbreak recombination analysis
parameter_guidance:
- '| `<newick_file>` | Positional #1: initial ML tree from IQ-TREE on the same alignment. |'
- '| `<fasta_file>` | Positional #2: core-genome multi-FASTA; must be a single alignment. |'
- '| `<output_file>` | Positional #3: output prefix. |'
- '| `-em` | Expectation-maximization mode (`true` recommended); slower but more accurate. |'
- '| `-emsim` | Number of EM simulations for uncertainty. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# ClonalFrameML

Use ClonalFrameML to detect and quantify homologous recombination — a central mechanism of horizontal gene transfer — in a set of closely related bacterial genomes. It infers recombination events alongside point mutation on a core-genome alignment.

```bash
conda run -n biomni-clonalframeml --no-capture-output ClonalFrameML \
  initial_tree.newick core_aln.fa clonalframeml_out -em true
```

## Capabilities and selection

ClonalFrameML models recombination and mutation jointly, estimating the relative rate R/theta and a per-site recombination map, and producing a recombination-corrected phylogeny. Prefer it for within-species bacterial populations where recombination confounds SNP phylogenies; use Gubbins for a faster per-site recombination filter on the same kind of input. Do not apply it to distantly related or metagenome-binned genomes without a valid core alignment.

## Inputs and upstream

Inputs are a core-genome multi-FASTA alignment (from Snippy/snp-sites/Panaroo) and an initial maximum-likelihood tree (IQ-TREE). Sites must be unambiguously aligned; strip recombined/duplicated regions beforehand. Record the reference and the alignment provenance.

## Outputs and downstream

Outputs are the recombination-corrected tree, per-site recombination probabilities, and estimated parameters (R/theta, branch lengths). Use the corrected tree and recombination map to interpret outbreaks and quantify how much of the variation is recombinational vs mutational.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `<newick_file>` | Positional #1: initial ML tree from IQ-TREE on the same alignment. |
| `<fasta_file>` | Positional #2: core-genome multi-FASTA; must be a single alignment. |
| `<output_file>` | Positional #3: output prefix. |
| `-em` | Expectation-maximization mode (`true` recommended); slower but more accurate. |
| `-emsim` | Number of EM simulations for uncertainty. |

## Workflow patterns

```bash
conda run -n biomni-clonalframeml --no-capture-output ClonalFrameML \
  initial_tree.newick core_aln.fa clonalframeml_out -em true
```

## Validation and failure handling

Record the alignment, tree, and mode. A failure to converge usually means too-distant genomes or a poor initial tree. Interpret the recombination map cautiously: high-recombination regions flag HGT/recombination hotspots, not specific donor species. Cross-check with Gubbins for agreement.

## Reproducibility and audit

Record ClonalFrameML version, alignment, initial tree, and `-em` settings. Re-run and diff the recombination map to confirm determinism. Keep the alignment and tree immutable and document the reference used.
