---
name: NanoPlot
description: Statistical and graphical quality assessment for Oxford Nanopore and other long-read datasets.
kind: software
id: nanoplot
version: 3
selection_tier: default
environment: biomni-nanoplot
executables:
- NanoPlot
- NanoComp
- NanoStat
packages:
- nanoplot
- nanocomp
- nanostat
channels:
- conda-forge
- bioconda
tasks:
- long-read quality control
- read length assessment
- run comparison
databases: []
aliases:
- NanoPlot
- NanoStat
- nanopore QC
- 长读长质控
keywords:
- ONT
- Nanopore
- long reads
- N50
- read quality
- sequencing summary
- 长读长
capabilities:
- summarize long-read length and quality
- plot distributions and yield
- compare multiple runs
inputs:
- Nanopore FASTQ FASTA BAM CRAM or sequencing summary in one supported mode
outputs:
- NanoStats text report
- HTML report
- PNG PDF or SVG plots
- run log
upstream:
- sra-toolkit
downstream:
- chopper
- flye
- minimap2
software_family: nanoplot
documentation_status: CURATED_PROSE
parameter_guidance:
- '| `--fastq/--fasta/--bam/--cram/--summary` | Select one input schema matching the actual file. |'
- '| `-o`, `--outdir` | Output directory. |'
- '| `-p`, `--prefix` | Deterministic filename prefix. |'
- '| `-t`, `--threads` | CPU allocation, especially for compressed FASTQ parsing. |'
- '| `--minlength`, `--maxlength` | Restrict reporting range only for a defined diagnostic question; retain an unfiltered
  baseline report. |'
- '| `--minqual` | Diagnostic quality subset, not a substitute for producing filtered FASTQ. |'
- '| `--downsample` | Bound plotting/memory on very large runs while preserving full summary statistics where supported. |'
- '| `--loglength` | Log-scale length plots for broad distributions. |'
- '| `--plots` | Request only needed plot families to reduce output noise. |'
- '| `--format` | Choose PNG/PDF/SVG based on reporting needs. |'
- Use an unfiltered baseline report before choosing Chopper thresholds, then generate a second report from retained reads
  with a distinct output prefix.
- When `--summary` is used, verify the sequencing-summary rows correspond to the FASTQ/read set under study; stale or pooled
  summaries can produce convincing but unrelated plots.
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# NanoPlot

Run NanoPlot before filtering or assembly to characterize long-read yield, quality, and length distribution. It reports evidence; it does not modify reads.

## Capabilities and selection

NanoPlot accepts several long-read representations and produces standardized statistics and plots. Use NanoComp for direct comparison of independently labelled runs. Do not pass multiple incompatible input modes or interpret read N50 alone as assembly quality.

## Inputs and upstream

Choose exactly one input mode such as `--fastq`, `--fasta`, `--bam`, `--cram`, or `--summary`. Preserve sample/run labels and basecaller information. BAM/CRAM-based quality fields differ from raw FASTQ and must be interpreted in context.

## Outputs and downstream

Outputs include `NanoStats.txt`, plots, an HTML summary, and logs under the named directory. Statistics inform Chopper minimum quality/length settings, Flye read-type choice, coverage estimates, and whether a run should be combined or kept separate.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `--fastq/--fasta/--bam/--cram/--summary` | Select one input schema matching the actual file. |
| `-o`, `--outdir` | Output directory. |
| `-p`, `--prefix` | Deterministic filename prefix. |
| `-t`, `--threads` | CPU allocation, especially for compressed FASTQ parsing. |
| `--minlength`, `--maxlength` | Restrict reporting range only for a defined diagnostic question; retain an unfiltered baseline report. |
| `--minqual` | Diagnostic quality subset, not a substitute for producing filtered FASTQ. |
| `--downsample` | Bound plotting/memory on very large runs while preserving full summary statistics where supported. |
| `--loglength` | Log-scale length plots for broad distributions. |
| `--plots` | Request only needed plot families to reduce output noise. |
| `--format` | Choose PNG/PDF/SVG based on reporting needs. |

Use an unfiltered baseline report before choosing Chopper thresholds, then generate a second report from retained reads with a distinct output prefix.

When `--summary` is used, verify the sequencing-summary rows correspond to the FASTQ/read set under study; stale or pooled summaries can produce convincing but unrelated plots.

## Workflow patterns

```bash
conda run -n biomni-nanoplot --no-capture-output NanoPlot \
  --fastq reads.fastq.gz --threads 8 --loglength --format png --outdir nanoplot_raw
```

Generate a second report after Chopper and compare retained yield, N50, median quality, and length distribution rather than reporting only improvement in one metric.

## Validation and failure handling

Require parseable `NanoStats.txt`, nonzero reads/bases, plausible lengths and qualities, rendered plots, and consistency with file size/read counts. Empty results often mean wrong input mode, malformed FASTQ, unsupported summary columns, or overrestrictive diagnostic filters. Memory problems call for downsampling plots or using NanoStat, not discarding the full dataset.
