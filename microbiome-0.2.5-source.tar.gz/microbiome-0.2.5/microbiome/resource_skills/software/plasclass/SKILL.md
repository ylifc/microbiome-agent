---
name: PlasClass
description: Reference-free logistic-regression classification of plasmid vs chromosomal contigs from metagenomes.
kind: software
id: plasclass
version: 2
selection_tier: conditional
environment: biomni-plasclass
executables:
- classify_fasta.py
packages:
- plasclass
channels:
- conda-forge
- bioconda
tasks:
- plasmid classification
- metagenomic plasmid screening
- reference-free contig labeling
databases: []
aliases:
- PlasClass
- plasmid classifier
- 质粒分类
- 无参考质粒预测
keywords:
- plasmid
- chromosome
- logistic regression
- k-mer
- metagenome
- classification
- 质粒
capabilities:
- classify contigs as plasmid or chromosome
- output per-contig probability
- run without a reference database
inputs:
- assembled contig FASTA (model bundled with the package)
outputs:
- per-contig plasmid probability table
upstream:
- megahit
- spades
- flye
downstream:
- mob-suite
- genomad
software_family: plasclass
documentation_status: CURATED_PROSE
downstream_tasks:
- plasmidfinder
- downstream plasmid typing
parameter_guidance:
- '| `-f`/`--fasta` | Input contig FASTA (required). |'
- '| `-o`/`--outfile` | Output file prefix (default `<input>.probs.out`). |'
- '| `-p`/`--num_processes` | Parallel processes. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# PlasClass

Use PlasClass as a lightweight, reference-free plasmid/chromosome classifier. It trains a logistic-regression model on k-mer frequencies and predicts plasmid probability per contig, complementing PlasFlow and geNomad.

```bash
conda run -n biomni-plasclass --no-capture-output classify_fasta.py \
  -f contigs.fasta -o plasclass_out
```

## Capabilities and selection

PlasClass is fast and needs no reference database, making it suitable for screening many metagenomic contigs. Prefer it alongside PlasFlow for a second ML opinion, and corroborate plasmid candidates with geNomad mobility genes and MOB-suite/PlasmidFinder typing. It does not assess plasmid completeness or circularity.

## Inputs and upstream

Input is an assembled contig FASTA. The trained model ships inside the package (no separate download). Contigs should be reasonably long for informative k-mer statistics.

## Outputs and downstream

Output is a TSV of contig ID and plasmid probability/prediction. Feed predicted-plasmid contigs to MOB-suite/PlasmidFinder for typing and to geNomad for mobility-gene corroboration.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `-f`/`--fasta` | Input contig FASTA (required). |
| `-o`/`--outfile` | Output file prefix (default `<input>.probs.out`). |
| `-p`/`--num_processes` | Parallel processes. |

## Workflow patterns

```bash
conda run -n biomni-plasclass --no-capture-output classify_fasta.py \
  -f metagenome/contigs.fasta -o plasclass
```

## Validation and failure handling

Record the model version and threshold. Cross-check a sample of plasmid calls with geNomad/PlasFlow/mob-suite; agreement across independent methods is far stronger than any single classifier. A collapsed output usually means a missing model or malformed FASTA.

## Reproducibility and audit

Record PlasClass version, model file, threshold, and input assembly. Re-run and diff the probability table to confirm determinism. Keep the model immutable and document its provenance and training data.

Keep the input assembly and the installed package version so per-contig probabilities are reproducible.
