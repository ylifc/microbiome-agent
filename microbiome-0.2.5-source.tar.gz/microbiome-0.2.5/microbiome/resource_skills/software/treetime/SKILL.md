---
name: TreeTime
description: Time-scaled phylogenies, ancestral reconstruction, and molecular-clock analysis.
kind: software
id: treetime
version: 2
environment: microbiome
executables:
- treetime
packages:
- treetime
channels:
- conda-forge
- bioconda
tasks:
- time-scaled phylogeny
- molecular clock
- ancestral reconstruction
databases: []
aliases:
- TreeTime
- time tree
- molecular clock
- 时间树
- 分子钟
keywords:
- dated phylogeny
- ancestral reconstruction
- clock rate
- temporal signal
- dates
- 时间标定
capabilities:
- time-scaled phylogeny
- molecular-clock inference
- ancestral-state reconstruction
- clock outlier handling
inputs:
- rooted or unrooted Newick tree
- matching multiple alignment
- sample date TSV or CSV
outputs:
- time-scaled Newick or Nexus tree
- ancestral sequences
- clock model tables
- plots and logs
upstream:
- mafft
- muscle
- iqtree2
- iqtree3
- fasttree
downstream: []
software_family: treetime
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Parameter | Meaning and setting rule |'
- '| `--tree`, `--aln`, `--dates` | Required topology, matching alignment, and sample-date table. Validate exact ID intersection.
  |'
- '| `--name-column`, `--date-column` | Metadata column names where supported; set explicitly for non-default tables. |'
- '| `--outdir` | New output directory for one run/parameterization. |'
- '| `--clock-rate` | Fix substitution rate from external evidence. Do not fix merely to force plausible dates. |'
- '| `--clock-std-dev` | Uncertainty on supplied clock rate where supported; document source. |'
- '| `--branch-length-mode` | How sequence and input-tree branch lengths are optimized. Choose according to whether branch
  lengths are trusted. |'
- '| `--reroot` | Rooting strategy such as least-squares/best root where supported. Compare with biological outgroup rooting.
  |'
- '| `--keep-root` | Retain supplied root only when it is biologically/analytically justified. |'
- '| `--clock-filter` / IQD option | Detect clock outliers. Report removed samples and sensitivity; do not automatically erase
  discordant biology. |'
- '| `--coalescent` | Population prior: a numeric time scale, `opt`, or `skyline` (use `--n-skyline`/`--gen-per-year` as needed).
  Match sampling and scientific question. |'
- '| `--relax` | Relaxed-clock behavior where supported. More flexibility can reduce identifiability. |'
- '| `--confidence` | Estimate temporal confidence intervals where supported. Interpret conditional on topology/model. |'
- '| `--max-iter` | Optimization iterations. Increase only if convergence warnings persist. |'
- '| `--keep-polytomies` | Do not resolve multifurcations; preferable when data do not support an arbitrary resolution. |'
- '| `--stochastic-resolve` / `--greedy-resolve` | Polytomy resolution strategies; use seed/repeat sensitivity when stochastic.
  |'
- '| `--gtr`, `--custom-gtr`, `--aa` | Sequence substitution model controls. Match molecule type and fitted assumptions. |'
- '| `--reconstruct-tip-states` | Reconstruct ambiguous/missing tip states as supported; retain uncertainty. |'
- '| `--sequence-length` | Genome/alignment length used in clock scaling when needed; do not confuse with ungapped variable
  sites. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# TreeTime

Input tree labels, alignment labels, and date-table labels must match exactly.

```bash
conda run -n microbiome --no-capture-output treetime --tree tree.nwk --aln alignment.fasta --dates dates.tsv --outdir treetime_out
```

Inspect temporal signal, clock-rate estimates, outliers, and warnings before interpreting dated nodes.

## Capabilities and selection

TreeTime fits molecular-clock models to a phylogeny, alignment, and sampling dates; can reroot, identify clock outliers, resolve polytomies, reconstruct ancestral states, and infer time-scaled trees. It is optimized for relatively fast phylodynamic analysis. It does not create trustworthy dates when temporal signal/calibration is absent and does not replace a Bayesian uncertainty analysis when full prior/posterior modeling is required.

Use TreeTime for dated pathogen/viral trees with measurable sampling time span and a defensible ML topology. Use BEAST 2 for richer prior, demographic, and clock uncertainty modeling. Test root-to-tip/temporal signal and perform date randomization or sensitivity analysis where appropriate.

## Inputs and upstream

The alignment comes from MAFFT/MUSCLE and must match the taxon set in an IQ-TREE/FastTree Newick tree. Date metadata is TSV/CSV with sample name and decimal year or accepted date format. Missing/ambiguous dates must be handled explicitly. Sequence names cannot drift between consensus generation, alignment, tree, and metadata.

## Outputs and downstream

The output directory contains a time-scaled tree, branch mutation/time tables, ancestral sequences, clock model diagnostics, and plots/files depending on version/options. These support visualization and epidemiological interpretation. Preserve excluded outliers and original tree so changes are auditable.

## Parameters and decision rules

| Parameter | Meaning and setting rule |
| --- | --- |
| `--tree`, `--aln`, `--dates` | Required topology, matching alignment, and sample-date table. Validate exact ID intersection. |
| `--name-column`, `--date-column` | Metadata column names where supported; set explicitly for non-default tables. |
| `--outdir` | New output directory for one run/parameterization. |
| `--clock-rate` | Fix substitution rate from external evidence. Do not fix merely to force plausible dates. |
| `--clock-std-dev` | Uncertainty on supplied clock rate where supported; document source. |
| `--branch-length-mode` | How sequence and input-tree branch lengths are optimized. Choose according to whether branch lengths are trusted. |
| `--reroot` | Rooting strategy such as least-squares/best root where supported. Compare with biological outgroup rooting. |
| `--keep-root` | Retain supplied root only when it is biologically/analytically justified. |
| `--clock-filter` / IQD option | Detect clock outliers. Report removed samples and sensitivity; do not automatically erase discordant biology. |
| `--coalescent` | Population prior: a numeric time scale, `opt`, or `skyline` (use `--n-skyline`/`--gen-per-year` as needed). Match sampling and scientific question. |
| `--relax` | Relaxed-clock behavior where supported. More flexibility can reduce identifiability. |
| `--confidence` | Estimate temporal confidence intervals where supported. Interpret conditional on topology/model. |
| `--max-iter` | Optimization iterations. Increase only if convergence warnings persist. |
| `--keep-polytomies` | Do not resolve multifurcations; preferable when data do not support an arbitrary resolution. |
| `--stochastic-resolve` / `--greedy-resolve` | Polytomy resolution strategies; use seed/repeat sensitivity when stochastic. |
| `--gtr`, `--custom-gtr`, `--aa` | Sequence substitution model controls. Match molecule type and fitted assumptions. |
| `--reconstruct-tip-states` | Reconstruct ambiguous/missing tip states as supported; retain uncertainty. |
| `--sequence-length` | Genome/alignment length used in clock scaling when needed; do not confuse with ungapped variable sites. |

## Workflow patterns

```bash
conda run -n microbiome --no-capture-output treetime \
  --tree iqtree/run.treefile --aln alignment.fasta --dates dates.tsv \
  --name-column name --date-column date --outdir treetime/run
```

Run an initial clock fit, inspect outliers and temporal regression, then predefine any exclusion/sensitivity run. Do not select the run that best matches an expected historical date without reporting alternatives.

## Validation and failure handling

Require matching IDs, valid dates, nonzero sampling interval, finite positive clock rate when appropriate, plausible root date, outlier report, convergence, and uncertainty. Negative/implausible dates often indicate wrong date units, root, rate, or weak temporal signal. Singular optimization can come from identical sequences/dates, too little variation, polytomies, or overparameterization. If temporal signal is absent, stop claiming a dated phylogeny rather than forcing a rate.
