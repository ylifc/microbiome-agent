---
name: CheckM
description: Marker-based completeness and contamination assessment for microbial bins.
kind: software
id: checkm
version: 2
environment: microbiome
executables:
- checkm
packages:
- checkm-genome
- setuptools<81
channels:
- conda-forge
- bioconda
tasks:
- bin quality assessment
databases:
- checkm
aliases:
- CheckM
- MAG quality
- 完整度
- 污染度
- 基因组质量
keywords:
- MAG
- bin
- completeness
- contamination
- marker lineage
- quality
- 完整度
- 污染
capabilities:
- lineage-specific marker quality estimation
- completeness and contamination reporting
- marker and taxonomy diagnostics
inputs:
- directory of bacterial or archaeal bin FASTA files
- optional extension and lineage settings
outputs:
- quality summary table
- lineage and marker results
- gene and HMM intermediate files
- plots where requested
upstream:
- metabat2
- maxbin2
- concoct
downstream:
- drep
- gtdbtk
software_family: checkm
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Command/parameter | Meaning and setting rule |'
- '| `checkm data setRoot DIR` | Configure the local database for this environment. It is localization, not download. |'
- '| `lineage_wf BIN_DIR OUT_DIR` | Automated lineage placement, marker analysis, and QA. Use a new output directory. |'
- '| `-x EXT` | Bin filename extension such as `fa` or `fasta`; wrong value produces zero bins. |'
- '| `-t N` | General threads. Keep within allocation. |'
- '| `--pplacer_threads N` | Threads for placement; pplacer is often the memory bottleneck. |'
- '| `--reduced_tree` | Use reduced reference tree for lower memory, with potential lineage-resolution tradeoff. |'
- '| `--genes` | Input files contain called genes rather than genomes where supported; do not set for nucleotide bin FASTA.
  |'
- '| `--nt` | Input gene files are nucleotide rather than amino acid where supported. |'
- '| `--aai_strain FLOAT` | AAI threshold used for strain heterogeneity calculation. Report non-default changes. |'
- '| `--ignore_thresholds` | Ignore model-specific score thresholds. Can inflate marker hits/contamination and needs justification.
  |'
- '| `--skip_adj_correction` | Disable marker adjacency correction for contamination. Use only for sensitivity analysis. |'
- '| `--skip_pseudogene_correction` | Disable pseudogene correction; fragmented genomes may be affected. |'
- '| `-f FILE`, `--tab_table` | Write summary to a chosen file and tab-delimited format for parsing. |'
- '| `tree`, `tree_qa`, `lineage_set`, `analyze`, `qa` | Manual workflow components used when lineage sets or intermediate
  control is required. Keep the phase outputs matched. |'
- '| `taxonomy_wf` | Use a specified taxonomic marker set rather than lineage placement; only when that taxon assumption is
  justified. |'
- '| `coverage`, `tetra`, `profile` | Additional coverage/composition/bin profile utilities with their own BAM/table contracts.
  Load detailed help before use. |'
- '| `ssu_finder` | Search SSU rRNA in bins/unbinned contigs for taxonomic/contamination clues. |'
- '| `modify`, `merge`, `outliers`, `unique` | Bin curation utilities. Preserve original bins and explicit contig membership
  changes. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# CheckM

Use after metagenomic binning. Set `CHECKM_DATA_PATH` to `Database/checkm` or run `checkm data setRoot` inside the declared environment before `lineage_wf`.

Run CheckM through `conda run -n microbiome`; never rely on an activated base environment. Verify the output quality table and bin counts.

## Capabilities and selection

CheckM estimates bacterial/archaeal genome completeness and contamination from lineage-specific single-copy markers. `lineage_wf` automates marker placement, analysis, and QA; lower-level commands expose each phase. Estimates are conditional on marker lineage and may be unreliable for novel lineages, reduced genomes, symbionts, CPR taxa, or non-bacterial/archaeal sequences. CheckV is the corresponding viral-quality tool.

Use after binning and before dereplication/taxonomy/annotation. Keep all bins, including poor ones, through initial QA so thresholds are transparent. Typical MIMAG-style quality categories are reporting conventions, not universal biological truth.

## Inputs and upstream

Input is a directory of bin/genome nucleotide FASTA files from MetaBAT 2, MaxBin 2, or CONCOCT. Each filename is the bin ID and must be unique. Use `-x` to declare the extension without a leading dot according to local help. The READY CheckM database path must contain lineage marker data and be configured inside the `microbiome` command environment.

## Outputs and downstream

The workflow produces lineage placement, marker HMM results, gene calls, per-bin QA, and a summary table with completeness, contamination, strain heterogeneity, marker lineage, genome statistics, and marker counts. Quality values feed dRep filtering/scoring and reporting before GTDB-Tk. Keep marker lineage and counts, not only two percentages.

## Parameters and decision rules

| Command/parameter | Meaning and setting rule |
| --- | --- |
| `checkm data setRoot DIR` | Configure the local database for this environment. It is localization, not download. |
| `lineage_wf BIN_DIR OUT_DIR` | Automated lineage placement, marker analysis, and QA. Use a new output directory. |
| `-x EXT` | Bin filename extension such as `fa` or `fasta`; wrong value produces zero bins. |
| `-t N` | General threads. Keep within allocation. |
| `--pplacer_threads N` | Threads for placement; pplacer is often the memory bottleneck. |
| `--reduced_tree` | Use reduced reference tree for lower memory, with potential lineage-resolution tradeoff. |
| `--genes` | Input files contain called genes rather than genomes where supported; do not set for nucleotide bin FASTA. |
| `--nt` | Input gene files are nucleotide rather than amino acid where supported. |
| `--aai_strain FLOAT` | AAI threshold used for strain heterogeneity calculation. Report non-default changes. |
| `--ignore_thresholds` | Ignore model-specific score thresholds. Can inflate marker hits/contamination and needs justification. |
| `--skip_adj_correction` | Disable marker adjacency correction for contamination. Use only for sensitivity analysis. |
| `--skip_pseudogene_correction` | Disable pseudogene correction; fragmented genomes may be affected. |
| `-f FILE`, `--tab_table` | Write summary to a chosen file and tab-delimited format for parsing. |
| `tree`, `tree_qa`, `lineage_set`, `analyze`, `qa` | Manual workflow components used when lineage sets or intermediate control is required. Keep the phase outputs matched. |
| `taxonomy_wf` | Use a specified taxonomic marker set rather than lineage placement; only when that taxon assumption is justified. |
| `coverage`, `tetra`, `profile` | Additional coverage/composition/bin profile utilities with their own BAM/table contracts. Load detailed help before use. |
| `ssu_finder` | Search SSU rRNA in bins/unbinned contigs for taxonomic/contamination clues. |
| `modify`, `merge`, `outliers`, `unique` | Bin curation utilities. Preserve original bins and explicit contig membership changes. |

## Workflow patterns

```bash
conda run -n microbiome --no-capture-output checkm data setRoot Database/checkm
conda run -n microbiome --no-capture-output checkm lineage_wf \
  -x fasta -t 16 --pplacer_threads 4 bins checkm_out
conda run -n microbiome --no-capture-output checkm qa \
  -o 2 --tab_table -f checkm_out/quality.tsv \
  checkm_out/lineage.ms checkm_out
```

Before dRep, export a stable table mapping genome filenames to completeness/contamination and preserve the exact CheckM database release.

## Validation and failure handling

Require discovered bin count equal expected files, database check success, lineage assignment, marker rows, and a parseable non-empty quality table. Zero bins usually means wrong `-x` or directory. pplacer termination often means memory pressure; reduce placement threads/use reduced tree or allocate memory. Extremely high contamination may be real, strain mixture, marker duplication, or chimeric bins; inspect marker/contig evidence. Do not use CheckM on viral sequences or interpret failed-lineage bins as zero quality.
