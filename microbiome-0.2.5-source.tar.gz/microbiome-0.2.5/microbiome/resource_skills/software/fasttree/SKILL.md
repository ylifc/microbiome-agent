---
name: FastTree
description: Approximate maximum-likelihood phylogenetic trees for large alignments.
kind: software
id: fasttree
version: 2
environment: microbiome
executables:
- FastTree
version_args: []
packages:
- fasttree
channels:
- conda-forge
- bioconda
tasks:
- large phylogeny
- approximate maximum-likelihood tree
databases: []
aliases:
- FastTree
- approximate maximum likelihood
- 快速建树
keywords:
- phylogeny
- large alignment
- approximate ML
- support
- nucleotide
- protein
- 系统发育
capabilities:
- fast approximate maximum-likelihood tree inference
- large nucleotide or protein alignment tree building
inputs:
- validated nucleotide or protein multiple alignment
outputs:
- Newick tree on stdout
- progress and likelihood diagnostics on stderr
upstream:
- mafft
- muscle
downstream:
- treetime
software_family: fasttree
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Parameter | Meaning and setting rule |'
- '| `-nt` | Nucleotide alignment mode. Omit for proteins. |'
- '| `-gtr` | GTR nucleotide model instead of simpler nucleotide behavior; normally pair with `-nt`. |'
- '| `-wag`, `-lg` | Protein substitution models where supported; verify installed help. |'
- '| `-cat N` | CAT rate categories used during topology search. More categories cost memory/time. |'
- '| `-nocat` | Disable CAT approximation; understand performance/model consequence. |'
- '| `-gamma` | Rescale final likelihood/branch lengths under a gamma approximation after CAT search; does not redo full topology
  search. |'
- '| `-spr N` | Number/rounds of SPR search effort. More may improve topology at extra cost. |'
- '| `-mlacc N` | Increase ML optimization accuracy; often paired with `-slownni` for a more thorough run. |'
- '| `-slownni` | More exhaustive NNI behavior, slower. |'
- '| `-fastest` | Reduce search effort for huge datasets; suitable for exploration, not precision claims. |'
- '| `-pseudo` | Pseudocount handling for sparse alignments as documented. Use cautiously. |'
- '| `-boot N` | Number of support resamples where supported; `-nosupport` disables support. |'
- '| `-seed N` | Random seed for reproducible support/search stochasticity. |'
- '| `-intree FILE`, `-intree1 FILE` | Starting-tree input for one/all alignments according to mode. It may still be optimized.
  |'
- '| `-constraints FILE`, `-constraintWeight` | Topological split constraints. Use only from a priori evidence. |'
- '| `-nome`, `-noml` | Disable minimum-evolution or ML phases, greatly changing inference; mainly diagnostic/speed modes.
  |'
- '| `-log FILE` | Save intermediate trees/statistics for diagnostics. |'
- '| `-quote` | Quote unusual sequence names in Newick where supported; simpler stable IDs are safer. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# FastTree

Choose nucleotide or protein mode to match the alignment.

```bash
conda run -n microbiome --no-capture-output FastTree -nt -gtr alignment.fasta > tree.nwk
```

Confirm that every expected taxon appears exactly once and treat FastTree support values according to its documentation.

## Capabilities and selection

FastTree rapidly estimates approximately maximum-likelihood trees for large alignments using heuristic neighbor joining, NNI/SPR, and ML optimization. It is useful for exploratory trees, very large datasets, clustering context, and starting trees. It is not a drop-in substitute for a fully searched IQ-TREE analysis when topology/support precision is central.

The default model behavior is protein-oriented. Nucleotide alignments require `-nt`; `-gtr` selects a GTR nucleotide model. Protein model options vary by version. Support values are local support estimates/resampling behavior specific to FastTree and must not be called standard bootstrap unless that exact procedure was used.

## Inputs and upstream

Input is equal-length aligned FASTA/PHYLIP from MAFFT/MUSCLE. Taxon IDs must be unique. Very gappy/unaligned input, codon frame problems, or mixed molecule types invalidate the result. Large alignments may be streamed, but preserve an immutable copy and checksum.

## Outputs and downstream

The Newick tree is written to stdout; diagnostics go to stderr. Redirect them separately. Trees may feed TreeTime, visualization, clustering, or serve as starting trees for a more thorough method. Preserve model flags and stderr because the tree file alone does not state them.

## Parameters and decision rules

| Parameter | Meaning and setting rule |
| --- | --- |
| `-nt` | Nucleotide alignment mode. Omit for proteins. |
| `-gtr` | GTR nucleotide model instead of simpler nucleotide behavior; normally pair with `-nt`. |
| `-wag`, `-lg` | Protein substitution models where supported; verify installed help. |
| `-cat N` | CAT rate categories used during topology search. More categories cost memory/time. |
| `-nocat` | Disable CAT approximation; understand performance/model consequence. |
| `-gamma` | Rescale final likelihood/branch lengths under a gamma approximation after CAT search; does not redo full topology search. |
| `-spr N` | Number/rounds of SPR search effort. More may improve topology at extra cost. |
| `-mlacc N` | Increase ML optimization accuracy; often paired with `-slownni` for a more thorough run. |
| `-slownni` | More exhaustive NNI behavior, slower. |
| `-fastest` | Reduce search effort for huge datasets; suitable for exploration, not precision claims. |
| `-pseudo` | Pseudocount handling for sparse alignments as documented. Use cautiously. |
| `-boot N` | Number of support resamples where supported; `-nosupport` disables support. |
| `-seed N` | Random seed for reproducible support/search stochasticity. |
| `-intree FILE`, `-intree1 FILE` | Starting-tree input for one/all alignments according to mode. It may still be optimized. |
| `-constraints FILE`, `-constraintWeight` | Topological split constraints. Use only from a priori evidence. |
| `-nome`, `-noml` | Disable minimum-evolution or ML phases, greatly changing inference; mainly diagnostic/speed modes. |
| `-log FILE` | Save intermediate trees/statistics for diagnostics. |
| `-quote` | Quote unusual sequence names in Newick where supported; simpler stable IDs are safer. |

## Workflow patterns

```bash
conda run -n microbiome --no-capture-output bash -lc \
  "set -o pipefail; FastTree -nt -gtr -gamma -spr 4 -mlacc 2 -slownni \
   alignment.fasta > fasttree/tree.nwk 2> fasttree/run.log"
```

Use the standard faster flags for exploratory screening, then move high-impact analyses to IQ-TREE with explicit model selection/support. If passing the tree to TreeTime, retain the exact alignment and matching labels.

## Validation and failure handling

Require valid parseable Newick, all expected taxa exactly once, finite branch lengths, non-empty stderr completion, and documented model/support semantics. Empty tree output often means failure hidden by redirection. Unexpectedly long branches can reflect alignment error, contamination, saturation, or model mismatch. Polytomies/low support require biological and data review, not arbitrary node resolution.
