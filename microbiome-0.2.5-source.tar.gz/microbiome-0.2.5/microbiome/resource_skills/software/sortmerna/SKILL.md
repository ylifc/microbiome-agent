---
name: SortMeRNA
description: rRNA filtering for metatranscriptomics / 宏转录组rRNA过滤
kind: software
id: sortmerna
version: 3
selection_tier: conditional
documentation_status: DOCUMENTED
software_family: sortmerna
environment: microbiome-sortmerna
executables:
- sortmerna
packages:
- sortmerna
channels:
- conda-forge
- bioconda
tasks:
- rRNA filtering for metatranscriptomics / 宏转录组rRNA过滤
databases:
- sortmerna-rrna
aliases:
- SortMeRNA
- sortmerna
keywords:
- sortmerna
- rRNA filtering for metatranscriptomics / 宏转录组rRNA过滤
capabilities:
- rRNA filtering for metatranscriptomics / 宏转录组rRNA过滤
inputs:
- FASTQ/FASTA reads
- versioned rRNA reference FASTA and compatible index
outputs:
- rRNA and non-rRNA reads
- alignment and filtering logs
upstream:
- fastp
downstream:
- salmon
parameter_guidance:
- '--ref: frozen rRNA reference; prepare persistent indexes during bootstrap.'
- '--reads: declare all mate files and the selected pairing policy.'
- '--workdir: separate per-run temporary/alignment files from the immutable index directory.'
validation:
- Validate version and required package/functions before use.
- Run the task on representative data and require output assertions.
failure_handling:
- Do not rebuild persistent indexes in production or lose mate pairing while filtering.
- Consult version-matched Knowledge history; repair only in an approved maintenance phase.
references:
- https://github.com/sortmerna/sortmerna
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# SortMeRNA

## Capabilities and selection

rRNA filtering for metatranscriptomics / 宏转录组rRNA过滤.
Select this capability only when its input and statistical assumptions match the study.
Catalog documentation does not assert that this software is installed or task-validated.

## Inputs and upstream

- FASTQ/FASTA reads
- versioned rRNA reference FASTA and compatible index

Keep sample identifiers, feature identifiers, orientation, units and reference releases explicit.
Reject missing inputs rather than acquiring substitutes during analysis.

## Outputs and downstream

- rRNA and non-rRNA reads
- alignment and filtering logs

Save the complete invocation, output schema, software version and database fingerprints.
Do not overwrite raw data, reference resources or outputs from a different run.

## Parameters and decision rules

- --ref: frozen rRNA reference; prepare persistent indexes during bootstrap.
- --reads: declare all mate files and the selected pairing policy.
- --workdir: separate per-run temporary/alignment files from the immutable index directory.

The reference below is the full manual source. This catalog covers the supported task decisions;
option availability and defaults must be checked against the installed version and captured help.
Unknown values must not be guessed. Package functions are verified independently of R/Python.

## Workflow patterns

The following is a discovery probe, not a successful analysis recipe:

```bash
conda run -n microbiome-sortmerna --no-capture-output sortmerna --help
```

Resolve the actual environment prefix first. During production replay the frozen argv and paths.
R/Python workflows require a reviewed adapter with explicit parameters and output assertions.

## Validation and failure handling

Correct: use aligned input IDs, the approved method, compatible reference resources and validated outputs.
Incorrect: Do not rebuild persistent indexes in production or lose mate pairing while filtering.
A zero exit code without output validation is unverified history.
On failure record the complete command, exit code, stderr, version, input and database context.
Promote a repair only after a matching regression validation report passes.

## References and documentation coverage

- Official source: https://github.com/sortmerna/sortmerna
- Documentation reviewed for catalog integration; this is not a local runtime acceptance claim.
- Parameter coverage: curated task guidance; full version-specific help is captured on discovery.
