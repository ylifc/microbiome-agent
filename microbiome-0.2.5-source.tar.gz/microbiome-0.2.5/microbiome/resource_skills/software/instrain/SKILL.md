---
name: inStrain
description: Metagenomic population diversity / 群体微多样性分析
kind: software
id: instrain
version: 3
selection_tier: conditional
documentation_status: DOCUMENTED
software_family: instrain
environment: microbiome-instrain
executables:
- inStrain
packages:
- instrain
channels:
- conda-forge
- bioconda
tasks:
- Metagenomic population diversity / 群体微多样性分析
databases:
- reference-genomes
aliases:
- inStrain
- instrain
keywords:
- instrain
- Metagenomic population diversity / 群体微多样性分析
capabilities:
- Metagenomic population diversity / 群体微多样性分析
inputs:
- coordinate-sorted indexed BAM
- matching reference FASTA
outputs:
- coverage and microdiversity tables
- sample comparison outputs
upstream:
- bowtie2
- samtools
downstream: []
parameter_guidance:
- 'profile: BAM contig names/lengths must match the selected FASTA.'
- 'coverage/read-quality filters: freeze before comparing samples.'
- 'compare: use profiles with compatible reference and filtering contracts.'
validation:
- Validate version and required package/functions before use.
- Run the task on representative data and require output assertions.
failure_handling:
- Do not compare profiles with different reference coordinates or treat low-coverage missingness as absence.
- Consult version-matched Knowledge history; repair only in an approved maintenance phase.
references:
- https://github.com/MrOlm/inStrain
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# inStrain

## Capabilities and selection

Metagenomic population diversity / 群体微多样性分析.
Select this capability only when its input and statistical assumptions match the study.
Catalog documentation does not assert that this software is installed or task-validated.

## Inputs and upstream

- coordinate-sorted indexed BAM
- matching reference FASTA

Keep sample identifiers, feature identifiers, orientation, units and reference releases explicit.
Reject missing inputs rather than acquiring substitutes during analysis.

## Outputs and downstream

- coverage and microdiversity tables
- sample comparison outputs

Save the complete invocation, output schema, software version and database fingerprints.
Do not overwrite raw data, reference resources or outputs from a different run.

## Parameters and decision rules

- profile: BAM contig names/lengths must match the selected FASTA.
- coverage/read-quality filters: freeze before comparing samples.
- compare: use profiles with compatible reference and filtering contracts.

The reference below is the full manual source. This catalog covers the supported task decisions;
option availability and defaults must be checked against the installed version and captured help.
Unknown values must not be guessed. Package functions are verified independently of R/Python.

## Workflow patterns

The following is a discovery probe, not a successful analysis recipe:

```bash
conda run -n microbiome-instrain --no-capture-output inStrain --help
```

Resolve the actual environment prefix first. During production replay the frozen argv and paths.
R/Python workflows require a reviewed adapter with explicit parameters and output assertions.

## Validation and failure handling

Correct: use aligned input IDs, the approved method, compatible reference resources and validated outputs.
Incorrect: Do not compare profiles with different reference coordinates or treat low-coverage missingness as absence.
A zero exit code without output validation is unverified history.
On failure record the complete command, exit code, stderr, version, input and database context.
Promote a repair only after a matching regression validation report passes.

## References and documentation coverage

- Official source: https://github.com/MrOlm/inStrain
- Documentation reviewed for catalog integration; this is not a local runtime acceptance claim.
- Parameter coverage: curated task guidance; full version-specific help is captured on discovery.
