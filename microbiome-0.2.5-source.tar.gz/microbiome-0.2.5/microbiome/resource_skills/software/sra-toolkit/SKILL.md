---
name: SRA Toolkit
description: Official NCBI retrieval, validation, and FASTQ conversion for SRA run accessions.
kind: software
id: sra-toolkit
version: 2
selection_tier: default
environment: biomni-sra-toolkit
executables:
- prefetch
- fasterq-dump
- vdb-validate
- vdb-config
- sra-stat
packages:
- sra-tools
channels:
- conda-forge
- bioconda
tasks:
- SRA run acquisition
- SRA validation
- FASTQ conversion
databases: []
aliases:
- SRA Tools
- SRA Toolkit
- prefetch
- fasterq-dump
- SRA下载
keywords:
- SRR
- ERR
- DRR
- SRA
- FASTQ
- public reads
- accession
- 原始测序数据
capabilities:
- prefetch public SRA runs
- validate VDB archives
- convert runs to paired or single FASTQ
inputs:
- reviewed SRR ERR or DRR run accessions
- optional NCBI cart file and controlled-access credentials
outputs:
- staged Data/sra archive and cache
- paired single or technical FASTQ files
- validation and data manifest
upstream:
- ncbi-datasets
downstream:
- fastp
- nanoplot
- chopper
- spades
- megahit
- flye
- bowtie2
- bwa
- minimap2
software_family: sra-toolkit
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Command/option | Meaning and setting rule |'
- '| `prefetch ACCESSION` | Download one run; use a reviewed loop or cart for batches. |'
- '| `prefetch --max-size` | Raise only after disk estimation when runs exceed the default limit. |'
- '| `prefetch -O DIR` | Set controlled cache root; keep the accession directory structure intact. |'
- '| `vdb-validate` | Validate each downloaded run before conversion. |'
- '| `fasterq-dump --split-files` | Split paired spots into R1/R2 while retaining layout semantics. |'
- '| `--split-3` | Also separate unpaired reads; use when orphan reads must be retained. |'
- '| `-O` / `-t` | Output and temporary directories; put temporary data on sufficiently large fast storage. |'
- '| `-e` | Conversion threads; bound by CPU and storage throughput. |'
- '| `--include-technical` | Include technical reads only when the assay requires them. |'
- '| `--mem` | Conversion memory budget where supported; verify units with local help. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# SRA Toolkit

Use SRA Toolkit for confirmed raw-read acquisition when run accessions are already known. It is not the preferred metadata search layer and it does not estimate disk requirements for the Agent.

## Capabilities and selection

`prefetch` downloads an SRA run into the expected accession directory, `vdb-validate` checks archive integrity, and `fasterq-dump` converts it to FASTQ. Prefer NCBI Datasets/ENA metadata APIs for discovering runs and use SRA Toolkit only after sample/run identity is resolved.

## Inputs and upstream

Require run-level SRR/ERR/DRR accessions and a sample manifest linking each run to BioSample, library layout, platform, study, and intended sample ID. Estimate archive, FASTQ, temporary, and final compressed storage before transfer. Controlled-access data additionally requires approved credentials and must never be inferred from a public accession.

## Outputs and downstream

`prefetch` creates an accession directory containing the SRA object and cache. `fasterq-dump` writes one FASTQ, paired `_1/_2.fastq`, and optionally technical/unpaired files. FASTQ outputs feed fastp, NanoPlot/Chopper, assembly, host depletion, or mapping. Preserve accession manifests and validation logs.

## Parameters and decision rules

| Command/option | Meaning and setting rule |
| --- | --- |
| `prefetch ACCESSION` | Download one run; use a reviewed loop or cart for batches. |
| `prefetch --max-size` | Raise only after disk estimation when runs exceed the default limit. |
| `prefetch -O DIR` | Set controlled cache root; keep the accession directory structure intact. |
| `vdb-validate` | Validate each downloaded run before conversion. |
| `fasterq-dump --split-files` | Split paired spots into R1/R2 while retaining layout semantics. |
| `--split-3` | Also separate unpaired reads; use when orphan reads must be retained. |
| `-O` / `-t` | Output and temporary directories; put temporary data on sufficiently large fast storage. |
| `-e` | Conversion threads; bound by CPU and storage throughput. |
| `--include-technical` | Include technical reads only when the assay requires them. |
| `--mem` | Conversion memory budget where supported; verify units with local help. |

## Workflow patterns

Preferred: treat raw runs as project input data, never as a reusable analysis database. Resolve natural-language targets with the read-only `resolve_sra_accessions()` tool, render the staged plan with `plan_sra_download(...)`, and use the independent `[MICROBIOME_DATA_ACQUISITION:sra-runs]` authorization. The first confirmation downloads only the representative pilot; full confirmation resumes the remaining reviewed runs under `Data/sra/` and writes `run-metadata.tsv` plus `data-manifest.yaml`.

```bash
conda run -n biomni-sra-toolkit --no-capture-output prefetch SRR000001 -O sra_cache
conda run -n biomni-sra-toolkit --no-capture-output vdb-validate sra_cache/SRR000001
conda run -n biomni-sra-toolkit --no-capture-output fasterq-dump sra_cache/SRR000001 -O fastq -t tmp -e 8 --split-files
```

Compress FASTQ in a separately declared command after conversion; do not assume `fasterq-dump` produces gzip files. The Agent executes SRA transfer only through the controlled staged runner; model-generated raw `prefetch` or `fasterq-dump` commands are rejected so they cannot escape the reviewed accession list or pilot/full boundary.

## Validation and failure handling

Require `vdb-validate` success, expected read layout, non-empty FASTQ, matching paired record counts, valid four-line FASTQ structure, and sample/run manifest consistency. Exit errors commonly reflect cache configuration, insufficient disk/temp space, network interruption, protected data, or obsolete Toolkit versions. Retry transfers with backoff; never rerun conversion unchanged when temporary space is the root cause.

Compare converted read counts with run metadata before deleting any local accession cache or temporary provenance.
