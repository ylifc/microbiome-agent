---
name: VADR
description: Viral genome classification, validation and feature annotation from nucleotide FASTA using covariance models,
  BLAST seeding and HMM/CM search.
kind: software
id: vadr
version: 2
selection_tier: conditional
environment: biomni-vadr
executables:
- v-annotate.pl
- v-scan.pl
- v-build.pl
packages:
- vadr
channels:
- conda-forge
- bioconda
tasks:
- viral genome annotation
- viral sequence validation
- virus classification
- GenBank/NGDC feature table preparation
databases:
- vadr-models-rsv
- vadr-models-flavi
- vadr-models-corona
- vadr-models-sarscov2
- vadr-models-flu
- vadr-models-calici
- vadr-models-mpxv
aliases:
- VADR
- Viral Annotation DefineR
- vadr
- 病毒注释
- 病毒基因组注释
keywords:
- virus
- annotation
- validation
- covariance model
- cmsearch
- cmalign
- blastn
- HMM
- RSV
- 病毒
capabilities:
- viral genome classification
- viral sequence validation
- gene/CDS feature annotation
- 5-column feature table output
- per-family model libraries
inputs:
- viral nucleotide FASTA
- per-family model library directory
outputs:
- 5-column feature table (.tbl)
- classification summary (.sqc)
- annotation summary (.sqa)
- pass/fail FASTA
- alert list
upstream:
- pvga
- seqkit
downstream:
- ncbi-blast
software_family: vadr
documentation_status: CURATED_PROSE
upstream_tasks:
- assemble_virus_reference_guided
- assemble_virus_denovo
downstream_tasks:
- NGDC GenBase submission
- phylogenetic analysis
parameter_guidance:
- '| Parameter | Meaning and setting rule |'
- '| `--mkey <s>` | Model file prefix inside `$VADRMODELDIR` (e.g. `rsv`, `flu`). Must match the installed model files. |'
- '| `--mdir <s>` | Explicit model directory, overriding `$VADRMODELDIR`. |'
- '| `--split` | Split input into chunks for parallel annotation. |'
- '| `--cpu <n>` | Workers for parallel annotation (requires `--split`). RSV suggests ~16GB RAM per worker. |'
- '| `-r` | Replace N-stretches with expected nucleotides where possible. |'
- '| `--xnocomp` | Disable composition-based BLAST statistics (used in the rsv config). |'
- '| `--nomisc` | Do not downgrade failed features to `misc_feature`. |'
- '| `-s` | Seed alignment from top-scoring BLAST HSP (faster; recommended for large inputs). |'
- '| `--glsearch`, `--minimap2` | Family-specific alignment accelerators (e.g. corona, mpxv configs). |'
- '| `-f` | Force overwrite an existing output directory. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# VADR

VADR (Viral Annotation DefineR) classifies and annotates viral genomes against a
per-family model library. It is conda-installable from bioconda (`vadr`), which
pulls in its own Infernal, BLAST, Easel, HMMER, FASTA and Perl dependencies, so it
auto-installs into an isolated `biomni-vadr` environment after plan confirmation.
Run the Perl entry points through `conda run -n biomni-vadr --no-capture-output`.

```bash
conda run -n biomni-vadr --no-capture-output v-annotate.pl \
  --mkey rsv --split --cpu 8 -r --xnocomp --nomisc \
  sequences.fasta vadr_output
```

Inspect the classification summary (`*.vadr.sqc`), the per-sequence annotation
summary (`*.vadr.sqa`), and the 5-column feature table (`*.vadr.pass.tbl`).
`VADRMODELDIR` (set by `vadr_env.sh`) selects the model family; `--mkey` selects
the model file prefix inside it.

## Capabilities and selection

VADR 1.7 performs reference-independent viral annotation: it classifies each input
sequence to the best matching model (using a covariance model with BLAST seeding),
validates gene structure and terminin, and emits a submission-grade 5-column feature
table. It is appropriate for full-length or near-full-length viral genomes. It is not
a general de novo assembler or a read classifier; input must be assembled viral
genome FASTA. Per-family model libraries (rsv, flu, sarscov2, corona, flavi, calici,
mpxv) are separate downloads; only `rsv` is currently installed.

## Inputs and upstream

Input is viral nucleotide FASTA (one or more sequences, any length up to the model
library's limits). Upstream, the sequence usually comes from reference-guided or de
novo viral assembly (PVGA, SPAdes, BWA+bcftools consensus), then optional SeqKit
normalization. Validate sequence alphabet, sequence count, and that the selected
`--mkey` model family matches the expected virus. A mismatched family (e.g. bovine
RSV against the human RSV model) can still yield a confident-looking but wrong
classification; cross-check the top model identity and score.

## Outputs and downstream

The output directory contains classification (`*.vadr.sqc`), annotation
(`*.vadr.sqa`), per-feature (`*.vadr.ftr`), the 5-column feature table
(`*.vadr.pass.tbl`), pass/fail FASTA and lists, and the alert list
(`*.vadr.alt.list`). The `.pass.tbl` is directly usable for INSDC-style submission
and converts cleanly to NGDC GenBase format (TBL or GFF3). Downstream: phylogenetic
alignment (MAFFT/muscle + iqtree/fasttree) and database submission.

## Parameters and decision rules

| Parameter | Meaning and setting rule |
| --- | --- |
| `--mkey <s>` | Model file prefix inside `$VADRMODELDIR` (e.g. `rsv`, `flu`). Must match the installed model files. |
| `--mdir <s>` | Explicit model directory, overriding `$VADRMODELDIR`. |
| `--split` | Split input into chunks for parallel annotation. |
| `--cpu <n>` | Workers for parallel annotation (requires `--split`). RSV suggests ~16GB RAM per worker. |
| `-r` | Replace N-stretches with expected nucleotides where possible. |
| `--xnocomp` | Disable composition-based BLAST statistics (used in the rsv config). |
| `--nomisc` | Do not downgrade failed features to `misc_feature`. |
| `-s` | Seed alignment from top-scoring BLAST HSP (faster; recommended for large inputs). |
| `--glsearch`, `--minimap2` | Family-specific alignment accelerators (e.g. corona, mpxv configs). |
| `-f` | Force overwrite an existing output directory. |

## Workflow patterns

```bash
# annotate RSV genomes with the rsv model library
conda run -n biomni-vadr --no-capture-output v-annotate.pl \
  --mkey rsv --split --cpu 8 -r --xnocomp --nomisc \
  RSV/BACDC_3_seq.fasta RSV/vadr_output
```

For a batch of samples, run `v-annotate.pl` per sample (or use `v-scan.pl` for
mixed-content screening) and merge the resulting `.pass.tbl` files for submission.

## Validation and failure handling

A valid run requires: non-empty classification summary, per-sequence PASS/FAIL,
feature table rows for each passing sequence, and zero or understood alerts. A FAIL
commonly means the sequence is truncated, has internal stop codons, or belongs to a
different virus than the selected model. Zero hits in the classification stage
suggests wrong `--mkey`, wrong `VADRMODELDIR`, or a divergent/non-target sequence.
Missing Infernal/BLAST/Easel executables indicate an incomplete `biomni-vadr`
environment; the conda `vadr` package bundles these dependencies, so repair the
environment rather than sourcing a manual `vadr_env.sh`. Model libraries
(`VADRMODELDIR`) are still acquired separately per family.
