---
name: CONCOCT
description: Metagenomic contig binning from sequence composition and multi-sample coverage.
kind: software
id: concoct
version: 2
environment: microbiome
executables:
- concoct
- cut_up_fasta.py
- concoct_coverage_table.py
- merge_cutup_clustering.py
- extract_fasta_bins.py
packages:
- concoct
channels:
- conda-forge
- bioconda
tasks:
- metagenomic binning
- coverage-aware MAG recovery
databases: []
aliases:
- CONCOCT
- composition coverage binning
- 宏基因组分箱
keywords:
- binning
- MAG
- multi-sample coverage
- composition
- cut contigs
- 分箱
- 宏基因组
capabilities:
- composition and coverage clustering
- multi-sample differential-coverage binning
- original-contig cluster merging
inputs:
- cut-contig FASTA
- BED mapping of cut contigs
- coverage TSV from one or more sorted BAM files
outputs:
- clustering CSV
- merged original-contig clusters
- one FASTA per extracted bin
- PCA and log files
upstream:
- megahit
- spades
- bwa
- bowtie2
- samtools
downstream:
- checkm
- drep
- gtdbtk
- bakta
software_family: concoct
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Command/parameter | Meaning and setting rule |'
- '| `cut_up_fasta.py -c` | Fragment length, commonly 10 kbp. Shorter fragments add samples but weaken composition; keep consistent
  with minimum length. |'
- '| `cut_up_fasta.py -o` | Overlap between fragments. Zero is the standard simple mapping; overlap changes coverage/composition
  interpretation. |'
- '| `--merge_last` | Merge a short terminal fragment into the previous fragment to avoid tiny pieces. |'
- '| `-b` on cut command | BED mapping output required by coverage and merge stages. |'
- '| `concoct_coverage_table.py BED BAM...` | Generate sample-separated coverage TSV. BAM order becomes column order. |'
- '| `--composition_file` | Cut-contig FASTA, not the original assembly when using the standard cut workflow. |'
- '| `--coverage_file` | Coverage TSV whose row IDs match cut-contig IDs. |'
- '| `-b`, `--basename` | Output prefix/directory. Keep each parameterization separate. |'
- '| `-c`, `--clusters` | Maximum cluster count. Increase for expected high complexity, but excessive clusters fragment genomes.
  |'
- '| `-k`, `--kmer_length` | K-mer length (default 4). |'
- '| `--total_percentage_pca` | Percentage of variance PCA components must explain (default 90). |'
- '| `-l`, `--length_threshold` | Minimum sequence length for modeling. Coordinate with cut length and assembly filtering.
  |'
- '| `-s`, `--seed` | Random seed for reproducibility (`-r` is `--read_length`, default 100). |'
- '| `-t`, `--threads` | Threads within allocation. |'
- '| `--iterations` | Maximum model iterations. Increase only if convergence diagnostics justify it. |'
- '| `--no_cov_normalization` | Disable sample coverage normalization; use only when coverage scales are already intentionally
  comparable. |'
- '| `--no_total_coverage` | Exclude total coverage feature; may change low-dimensional separation. |'
- '| `merge_cutup_clustering.py` | Merge fragment assignments back to original contigs before FASTA extraction. |'
- '| `extract_fasta_bins.py` | Extract original contigs by merged cluster CSV; use original assembly FASTA. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# CONCOCT

CONCOCT needs an assembly plus sorted BAM coverage data. Keep the cut-contig mapping so clusters can be merged back to original contigs.

```bash
conda run -n microbiome --no-capture-output cut_up_fasta.py assembly.fasta -c 10000 -o 0 --merge_last -b contigs_10K.bed > contigs_10K.fa
conda run -n microbiome --no-capture-output concoct_coverage_table.py contigs_10K.bed sample.sorted.bam > coverage.tsv
conda run -n microbiome --no-capture-output concoct --composition_file contigs_10K.fa --coverage_file coverage.tsv -b concoct/
```

After clustering, run `merge_cutup_clustering.py` and `extract_fasta_bins.py`. Verify that bin FASTA files are non-empty before quality assessment.

## Capabilities and selection

CONCOCT jointly models sequence composition and coverage across samples. Its standard workflow cuts long contigs into fixed-size fragments for modeling, clusters fragments, then merges cluster assignments back to original contigs. This makes the cut/merge mapping a required provenance artifact. It does not directly assess completeness, contamination, or taxonomy.

CONCOCT is especially useful when multiple samples provide differential coverage. A one-sample run is possible but may separate strains/organisms less effectively. Use MetaBAT 2 or MaxBin 2 as alternatives and formal refinement when combining evidence.

## Inputs and upstream

The assembly FASTA comes from MEGAHIT/metaSPAdes. `cut_up_fasta.py` creates cut-contig FASTA plus BED mapping. `concoct_coverage_table.py` consumes that BED and one or more coordinate-sorted BAMs from BWA/Bowtie 2 plus SAMtools. Every BAM must target the original, unchanged assembly and remain a separate sample column.

## Outputs and downstream

CONCOCT writes clustering CSV, coverage/composition tables, PCA/component data, logs, and model outputs under its prefix. `merge_cutup_clustering.py` maps fragment clusters to original contigs; `extract_fasta_bins.py` writes bin FASTA. Those bins feed CheckM, dRep, GTDB-Tk, Bakta, and refinement.

## Parameters and decision rules

| Command/parameter | Meaning and setting rule |
| --- | --- |
| `cut_up_fasta.py -c` | Fragment length, commonly 10 kbp. Shorter fragments add samples but weaken composition; keep consistent with minimum length. |
| `cut_up_fasta.py -o` | Overlap between fragments. Zero is the standard simple mapping; overlap changes coverage/composition interpretation. |
| `--merge_last` | Merge a short terminal fragment into the previous fragment to avoid tiny pieces. |
| `-b` on cut command | BED mapping output required by coverage and merge stages. |
| `concoct_coverage_table.py BED BAM...` | Generate sample-separated coverage TSV. BAM order becomes column order. |
| `--composition_file` | Cut-contig FASTA, not the original assembly when using the standard cut workflow. |
| `--coverage_file` | Coverage TSV whose row IDs match cut-contig IDs. |
| `-b`, `--basename` | Output prefix/directory. Keep each parameterization separate. |
| `-c`, `--clusters` | Maximum cluster count. Increase for expected high complexity, but excessive clusters fragment genomes. |
| `-k`, `--kmer_length` | K-mer length (default 4). |
| `--total_percentage_pca` | Percentage of variance PCA components must explain (default 90). |
| `-l`, `--length_threshold` | Minimum sequence length for modeling. Coordinate with cut length and assembly filtering. |
| `-s`, `--seed` | Random seed for reproducibility (`-r` is `--read_length`, default 100). |
| `-t`, `--threads` | Threads within allocation. |
| `--iterations` | Maximum model iterations. Increase only if convergence diagnostics justify it. |
| `--no_cov_normalization` | Disable sample coverage normalization; use only when coverage scales are already intentionally comparable. |
| `--no_total_coverage` | Exclude total coverage feature; may change low-dimensional separation. |
| `merge_cutup_clustering.py` | Merge fragment assignments back to original contigs before FASTA extraction. |
| `extract_fasta_bins.py` | Extract original contigs by merged cluster CSV; use original assembly FASTA. |

## Workflow patterns

```bash
conda run -n microbiome --no-capture-output bash -lc \
  "cut_up_fasta.py assembly.fasta -c 10000 -o 0 --merge_last -b contigs_10K.bed > contigs_10K.fa"
conda run -n microbiome --no-capture-output bash -lc \
  "concoct_coverage_table.py contigs_10K.bed S1.sorted.bam S2.sorted.bam > coverage.tsv"
conda run -n microbiome --no-capture-output concoct \
  --composition_file contigs_10K.fa --coverage_file coverage.tsv \
  -b concoct/run_ -c 400 -s 42 -t 16
conda run -n microbiome --no-capture-output merge_cutup_clustering.py \
  concoct/run_clustering_gt1000.csv > concoct/clustering_merged.csv
conda run -n microbiome --no-capture-output extract_fasta_bins.py \
  assembly.fasta concoct/clustering_merged.csv --output_path concoct/bins
```

Confirm actual output filenames from the installed version before hard-coding the merge input.

## Validation and failure handling

Check cut FASTA/BED row correspondence, coverage rows/columns, absence of NaN/constant sample columns, clustering output, merged one-cluster-per-original-contig behavior, and non-empty bin FASTA. Identifier errors usually arise from changed FASTA headers or BAMs built against a different assembly. Model failures can result from too few eligible contigs, zero/invalid coverage, overlarge cluster/component settings, or numerical dependencies. Assess bins with CheckM and compare across seeds when stability matters.
