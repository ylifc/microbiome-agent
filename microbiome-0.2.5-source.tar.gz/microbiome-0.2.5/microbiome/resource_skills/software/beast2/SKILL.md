---
name: BEAST 2
description: Bayesian phylogenetic inference and molecular dating from an explicit XML model.
kind: software
id: beast2
version: 2
environment: microbiome
executables:
- beast
- treeannotator
packages:
- beast2
channels:
- conda-forge
- bioconda
tasks:
- Bayesian phylogeny
- molecular dating
- posterior tree summarization
databases: []
aliases:
- BEAST2
- Bayesian phylogenetics
- 贝叶斯系统发育
- 贝叶斯分子钟
keywords:
- Bayesian tree
- molecular dating
- MCMC
- clock model
- coalescent
- calibration
- 系统发育
capabilities:
- Bayesian phylogenetic inference
- strict or relaxed molecular clocks
- demographic and birth-death models
- posterior tree summarization
inputs:
- reviewed BEAST XML encoding alignment models priors clocks calibrations and MCMC
- optional starting tree
outputs:
- parameter log
- posterior trees
- state checkpoint
- maximum-clade-credibility summary tree
upstream:
- mafft
- muscle
- iqtree2
- iqtree3
downstream: []
software_family: beast2
documentation_status: CURATED_PROSE
parameter_guidance:
- '| XML/runtime setting | Meaning and setting rule |'
- '| Alignment partitions | Group loci/codon positions with justified linked or unlinked substitution/clock/tree parameters.
  Overparameterization hurts mixing. |'
- '| Substitution model | HKY/GTR/protein/codon-like model and base frequencies/rate heterogeneity. Match molecule and partition.
  |'
- '| Site heterogeneity | Gamma categories and invariant-sites behavior. Avoid redundant/unidentifiable combinations. |'
- '| Strict vs relaxed clock | Strict assumes one rate; relaxed models branch variation. Compare fit/sensitivity and set rate
  priors in correct units. |'
- '| Tip dates | Sampling times and direction/units. Verify oldest/newest values and date uncertainty. |'
- '| Calibration priors | Fossil/host/event constraints with distribution and monophyly assumptions. Avoid data-derived circular
  calibrations. |'
- '| Tree prior | Coalescent constant/exponential/skyline, birth-death, Yule, etc. Match population/species sampling process.
  |'
- '| Parameter priors | Proper distributions and scales. Run prior-only analysis to detect unintended informativeness. |'
- '| Operator weights/tuning | Proposal frequencies/scales. Adjust from pilot acceptance/mixing, not desired posterior. |'
- '| Chain length | Number of MCMC states. Increase until convergence/ESS across independent runs, not to a universal number.
  |'
- '| `logEvery` / tree logging | Sampling frequency. Balance autocorrelation, ESS, file size, and temporal resolution. |'
- '| State/checkpoint frequency | Enables exact resume after interruption. Keep XML and state synchronized. |'
- '| `beast -threads N` | CPU allocation where model supports parallel likelihood. More threads are not always faster. |'
- '| `-seed N` | Reproducible independent chain seed. Use different seeds for independent replicates. |'
- '| `-resume` | Resume from matching state; never resume after changing model/XML incompatibly. |'
- '| `-overwrite` | Permit replacing outputs. Prefer a new prefix/run directory to preserve evidence. |'
- '| BEAGLE CPU/GPU flags | Select acceleration/precision backend according to installed support; verify numerical consistency.
  |'
- '| validation/strict-version flags | Validate XML/package/version compatibility before long runs when supported. |'
- '| prior-only sampling | Disable sequence likelihood/sample from prior as supported to inspect prior behavior. |'
- '### TreeAnnotator'
- '| Parameter | Meaning and setting rule |'
- '| `-burnin PERCENT` | Remove pre-stationary fraction after trace inspection. A fixed 10% is not automatically adequate.
  |'
- '| `-heights mean|median|ca` | Node-height summary method. State choice and understand common-ancestor behavior. |'
- '| `-limit FLOAT` | Posterior probability threshold for annotation where supported. |'
- '| `-target FILE` | Summarize annotations on a supplied target topology instead of MCC; use intentionally. |'
- '| `-lowMem` | Reduce memory for large tree sets at performance cost. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# BEAST 2

Run only a reviewed BEAST XML containing the intended substitution, clock, tree, calibration, prior, and MCMC settings.

```bash
conda run -n microbiome --no-capture-output beast analysis.xml
conda run -n microbiome --no-capture-output treeannotator -burnin 10 -heights median posterior.trees summary.tree
```

Check effective sample sizes and convergence in the log before summarizing posterior trees. Never infer success from file existence alone.

## Capabilities and selection

BEAST 2 samples phylogenetic, clock, demographic/speciation, and other model parameters with MCMC as encoded in XML. The XML is the analysis: a command that runs successfully can still represent the wrong model, calibration, units, or logging schedule. BEAST is appropriate when full posterior uncertainty and prior-rich time-tree inference are needed; TreeTime is faster for simpler clock fits.

## Inputs and upstream

Create/review XML from a validated MAFFT/MUSCLE alignment, sampling dates, partitions, substitution models, clock model, tree prior, calibrations, priors, operators, and MCMC settings. IQ-TREE can inform an initial topology but must not silently become a fixed tree unless intended. Taxon/date/calibration labels and time units must agree. Check package requirements recorded in XML against installed BEAST packages before execution.

## Outputs and downstream

The XML defines `.log` parameter traces, `.trees` posterior trees, state/checkpoint, and optional operator/diagnostic files. TreeAnnotator summarizes post-burn-in trees into a maximum-clade-credibility tree with chosen node heights. Downstream visualization/reporting must retain posterior support, age HPDs, clock/tree models, priors, and convergence evidence.

## Parameters and decision rules

| XML/runtime setting | Meaning and setting rule |
| --- | --- |
| Alignment partitions | Group loci/codon positions with justified linked or unlinked substitution/clock/tree parameters. Overparameterization hurts mixing. |
| Substitution model | HKY/GTR/protein/codon-like model and base frequencies/rate heterogeneity. Match molecule and partition. |
| Site heterogeneity | Gamma categories and invariant-sites behavior. Avoid redundant/unidentifiable combinations. |
| Strict vs relaxed clock | Strict assumes one rate; relaxed models branch variation. Compare fit/sensitivity and set rate priors in correct units. |
| Tip dates | Sampling times and direction/units. Verify oldest/newest values and date uncertainty. |
| Calibration priors | Fossil/host/event constraints with distribution and monophyly assumptions. Avoid data-derived circular calibrations. |
| Tree prior | Coalescent constant/exponential/skyline, birth-death, Yule, etc. Match population/species sampling process. |
| Parameter priors | Proper distributions and scales. Run prior-only analysis to detect unintended informativeness. |
| Operator weights/tuning | Proposal frequencies/scales. Adjust from pilot acceptance/mixing, not desired posterior. |
| Chain length | Number of MCMC states. Increase until convergence/ESS across independent runs, not to a universal number. |
| `logEvery` / tree logging | Sampling frequency. Balance autocorrelation, ESS, file size, and temporal resolution. |
| State/checkpoint frequency | Enables exact resume after interruption. Keep XML and state synchronized. |
| `beast -threads N` | CPU allocation where model supports parallel likelihood. More threads are not always faster. |
| `-seed N` | Reproducible independent chain seed. Use different seeds for independent replicates. |
| `-resume` | Resume from matching state; never resume after changing model/XML incompatibly. |
| `-overwrite` | Permit replacing outputs. Prefer a new prefix/run directory to preserve evidence. |
| BEAGLE CPU/GPU flags | Select acceleration/precision backend according to installed support; verify numerical consistency. |
| validation/strict-version flags | Validate XML/package/version compatibility before long runs when supported. |
| prior-only sampling | Disable sequence likelihood/sample from prior as supported to inspect prior behavior. |

### TreeAnnotator

| Parameter | Meaning and setting rule |
| --- | --- |
| `-burnin PERCENT` | Remove pre-stationary fraction after trace inspection. A fixed 10% is not automatically adequate. |
| `-heights mean|median|ca` | Node-height summary method. State choice and understand common-ancestor behavior. |
| `-limit FLOAT` | Posterior probability threshold for annotation where supported. |
| `-target FILE` | Summarize annotations on a supplied target topology instead of MCC; use intentionally. |
| `-lowMem` | Reduce memory for large tree sets at performance cost. |

## Workflow patterns

```bash
conda run -n microbiome --no-capture-output beast -threads 8 -seed 12345 analysis.xml
conda run -n microbiome --no-capture-output treeannotator \
  -burnin 20 -heights median posterior.trees summary.mcc.tree
```

Run at least two independent chains with different seeds. Combine only post-burn-in samples from converged identical models, and preserve each run before any combination.

## Validation and failure handling

Before launch, validate XML parsing, package versions, taxa/dates/calibrations, priors, initial likelihood, output paths, and disk estimate. Afterward inspect independent trace overlap, ESS for every important parameter, stationarity, operator acceptance, posterior versus prior, root/clock plausibility, and tree convergence. A completed chain with low ESS is unfinished. `-Infinity` likelihood typically means invalid starting tree/parameters, impossible calibration, sequence/model mismatch, or numerical issues. Resume only from a compatible state; otherwise start a new run and record the change.
