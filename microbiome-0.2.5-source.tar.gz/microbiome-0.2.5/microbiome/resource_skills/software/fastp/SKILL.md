---
name: fastp
description: Fast all-in-one quality control, adapter trimming, filtering, and reporting for short-read FASTQ.
kind: software
id: fastp
version: 2
selection_tier: default
environment: biomni-fastp
executables:
- fastp
packages:
- fastp
channels:
- conda-forge
- bioconda
tasks:
- short-read quality control
- adapter trimming
- read filtering
- paired-read correction
databases: []
aliases:
- fastp
- FASTQ preprocessor
- 短读长质控
keywords:
- FASTQ
- Illumina
- adapter
- quality trimming
- polyG
- paired end
- 质控
- 接头去除
capabilities:
- single and paired FASTQ filtering
- adapter and polyG trimming
- quality and length filtering
- JSON and HTML QC reports
inputs:
- single-end or synchronized paired-end FASTQ optionally gzip-compressed
outputs:
- filtered FASTQ pairs or single reads
- JSON metrics
- HTML report
- optional failed unpaired merged and duplication outputs
upstream:
- sra-toolkit
downstream:
- spades
- megahit
- bowtie2
- bwa
- snippy
- dada2
- qiime2
software_family: fastp
documentation_status: CURATED_PROSE
parameter_guidance:
- '| `-i/-I`, `-o/-O` | R1/R2 inputs and outputs; omit R2 options for true single-end data. |'
- '| `--detect_adapter_for_pe` | Enable paired-end adapter auto-detection when adapter sequence is unknown; inspect report
  evidence. |'
- '| `--adapter_sequence(_r2)` | Use known validated adapters rather than detection. |'
- '| `--trim_poly_g`, `--poly_g_min_len` | Relevant to platforms showing polyG tails; avoid universal use without report evidence.
  |'
- '| `--cut_front`, `--cut_tail`, `--cut_window_size`, `--cut_mean_quality` | Sliding-window trimming; aggressive values can
  shorten reads and break pairing/overlap. |'
- '| `-q`, `-u`, `-n`, `-l` | Qualified-base threshold, maximum low-quality percentage, maximum Ns, and minimum retained length.
  |'
- '| `--correction` | Correct mismatches in reliable paired overlaps; unsuitable when overlap assumptions fail. |'
- '| `--dedup` | Remove duplicates only when library biology and UMI design justify it. |'
- '| `--merge`, `--merged_out` | Merge overlapping pairs for assays that expect merged reads, not routine WGS assembly. |'
- '| `--json`, `--html`, `--thread` | Deterministic reports and bounded CPU allocation. |'
- Keep JSON as the machine-readable QC contract and verify its before/after read and base totals against emitted FASTQ records.
- For paired reads, require synchronized R1/R2 counts after filtering. Orphan/singleton policy must be explicit when downstream
  software accepts them.
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# fastp

Use fastp as the default short-read preprocessing tool when its integrated QC and trimming are sufficient. Keep Cutadapt conditional for exact anchored primer constructs or complex linked adapters.

## Capabilities and selection

fastp performs adapter detection, quality trimming/filtering, polyG/polyX trimming, paired-read overlap correction, optional deduplication/merging, and machine-readable reporting in one stable command. It is not an amplicon denoiser and cannot replace assay-specific primer validation or contamination screening.

## Inputs and upstream

Inputs are raw or previously demultiplexed FASTQ files. Paired files must have synchronized read names and compatible counts. Record platform, library layout, adapters/primers, expected insert size, read length, and whether UMIs are present before selecting options.

## Outputs and downstream

Primary outputs are filtered FASTQ and paired FASTQ plus `.json` and `.html` reports. JSON metrics should drive Agent validation. Filtered reads feed SPAdes/MEGAHIT, mapping, Snippy, or RNA/amplicon workflows. Keep failed/unpaired reads only when the downstream analysis defines their use.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `-i/-I`, `-o/-O` | R1/R2 inputs and outputs; omit R2 options for true single-end data. |
| `--detect_adapter_for_pe` | Enable paired-end adapter auto-detection when adapter sequence is unknown; inspect report evidence. |
| `--adapter_sequence(_r2)` | Use known validated adapters rather than detection. |
| `--trim_poly_g`, `--poly_g_min_len` | Relevant to platforms showing polyG tails; avoid universal use without report evidence. |
| `--cut_front`, `--cut_tail`, `--cut_window_size`, `--cut_mean_quality` | Sliding-window trimming; aggressive values can shorten reads and break pairing/overlap. |
| `-q`, `-u`, `-n`, `-l` | Qualified-base threshold, maximum low-quality percentage, maximum Ns, and minimum retained length. |
| `--correction` | Correct mismatches in reliable paired overlaps; unsuitable when overlap assumptions fail. |
| `--dedup` | Remove duplicates only when library biology and UMI design justify it. |
| `--merge`, `--merged_out` | Merge overlapping pairs for assays that expect merged reads, not routine WGS assembly. |
| `--json`, `--html`, `--thread` | Deterministic reports and bounded CPU allocation. |

Keep JSON as the machine-readable QC contract and verify its before/after read and base totals against emitted FASTQ records.

For paired reads, require synchronized R1/R2 counts after filtering. Orphan/singleton policy must be explicit when downstream software accepts them.

## Workflow patterns

```bash
conda run -n biomni-fastp --no-capture-output fastp \
  -i sample_R1.fastq.gz -I sample_R2.fastq.gz \
  -o clean_R1.fastq.gz -O clean_R2.fastq.gz \
  --detect_adapter_for_pe --json sample.fastp.json --html sample.fastp.html --thread 8
```

## Validation and failure handling

Require non-empty synchronized outputs, parseable JSON, expected before/after read counts, base-quality and adapter improvement, acceptable retained-read fraction, and no unintended sample-name changes. Very low retention indicates wrong quality/length thresholds, already trimmed input, poor sequencing, or adapter/primer mismatch. Pair-count errors require repairing or regenerating inputs, not forcing paired mode.
