---
name: SeqKit
description: Fast inspection, filtering, conversion, and manipulation of FASTA and FASTQ files.
kind: software
id: seqkit
version: 2
environment: seqkit
executables:
- seqkit
version_args:
- version
packages:
- seqkit
channels:
- conda-forge
- bioconda
tasks:
- sequence statistics
- FASTA filtering
- FASTQ filtering
- sequence format conversion
databases: []
aliases:
- SeqKit
- FASTA FASTQ toolkit
- 序列处理
- 序列质控
keywords:
- FASTA
- FASTQ
- stats
- filter
- grep
- subseq
- split
- deduplicate
- 序列
capabilities:
- sequence statistics
- record filtering
- format and case conversion
- subsequence extraction
- splitting and deduplication
inputs:
- FASTA or FASTA.GZ
- FASTQ or FASTQ.GZ
- optional ID list or BED or GTF regions
outputs:
- FASTA or FASTQ
- tabular statistics
- record identifiers
- split sequence files
upstream: []
downstream:
- megahit
- spades
- bwa
- bowtie2
- salmon
- prodigal
- mafft
- muscle
- diamond
- ncbi-blast
- pvga
software_family: seqkit
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Command/parameter | Meaning and setting rule |'
- '| `stats -a` | Extended length/QC statistics. Use `-T` for machine-readable tabular output and `-j` for threads. |'
- '| `seq -m`, `-M` | Minimum/maximum sequence length. Record thresholds because they change assembly/binning sensitivity.
  |'
- '| `seq -g`, `-G` | Remove gaps or set allowed gap characters; never apply to an alignment unless intended. |'
- '| `seq -r -p` | Reverse and complement nucleotide sequences. Use both for reverse-complement, not for proteins. |'
- '| `seq -t dna|rna|protein` | Force molecule type when auto-detection could be wrong. |'
- '| `seq -u` / `-l` | Upper/lower case conversion; case may encode masking, so preserve semantics. |'
- '| `grep -p`, `-f` | Match one pattern or patterns/IDs from a file. Default ID matching differs from full header matching.
  |'
- '| `grep -n`, `-r`, `-i`, `-v` | Match full names, regex, ignore case, or invert. Regex and sequence search can be expensive.
  |'
- '| `subseq -r START:END` | Extract 1-based regions according to SeqKit syntax; negative coordinates count from the end.
  |'
- '| `subseq --bed` / `--gtf` | Region extraction from annotation files; confirm coordinate and strand behavior. |'
- '| `fx2tab` / `tab2fx` | Convert records to/from TSV. Keep sequence and quality columns aligned for FASTQ. |'
- '| `sort -n`, `-l`, `-s`, `-r` | Sort by name, length, sequence, or reverse order. Sorting can use substantial memory. |'
- '| `rmdup -n` / `-s` | Deduplicate by name or sequence. Choose biological identity explicitly and save duplicate mapping
  with `-D`. |'
- '| `sample -p` / `-n`, `-s` | Sample by proportion/count with seed. Sampling paired files independently breaks pairing;
  use paired-aware logic. |'
- '| `split`, `split2` | Split by parts, record count, or size. `split2` supports paired FASTQ; verify generated mate files.
  |'
- '| `replace` | Regex-based header/sequence renaming. Emit a mapping table when IDs feed downstream joins. |'
- '| `concat` / `pair` | Concatenate records by common IDs or repair pairing according to command semantics; inspect unmatched
  records. |'
- '| `-o`, `-w`, `-j` | Output path, FASTA line width, and threads. Use line width 0 only when downstream accepts unwrapped
  FASTA. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# SeqKit

Use SeqKit for non-destructive sequence inspection and explicit transformations.

```bash
conda run -n seqkit --no-capture-output seqkit stats input.fasta
conda run -n seqkit --no-capture-output seqkit seq -m 1000 input.fasta -o filtered.fasta
```

Check record counts before and after filtering and preserve compressed input when no modification is required.

## Capabilities and selection

SeqKit is the general sequence-file utility for inspection and controlled transformations. It can stream compressed FASTA/FASTQ, preserve record order for many commands, and operate on nucleotide or protein data. It is not an assembler, aligner, biological quality trimmer, or annotation engine. Every destructive transformation must have explicit output and before/after counts.

## Inputs and upstream

Inputs are FASTA/FASTQ, optionally gzip-compressed, from sequencing, assembly, gene prediction, databases, or another validated workflow. Auto-detection can be confused by unusual extensions or malformed records; specify sequence type when ambiguity matters. ID matching normally uses the first whitespace-delimited token unless full-name matching is requested.

## Outputs and downstream

SeqKit writes FASTA/FASTQ, IDs, or TSV to stdout or `-o`. Outputs can feed assemblers, mappers, Prodigal, MAFFT/MUSCLE, DIAMOND/BLAST, Salmon, and PVGA. Preserve FASTQ qualities when downstream tools need reads; converting FASTQ to FASTA discards quality information permanently.

## Parameters and decision rules

| Command/parameter | Meaning and setting rule |
| --- | --- |
| `stats -a` | Extended length/QC statistics. Use `-T` for machine-readable tabular output and `-j` for threads. |
| `seq -m`, `-M` | Minimum/maximum sequence length. Record thresholds because they change assembly/binning sensitivity. |
| `seq -g`, `-G` | Remove gaps or set allowed gap characters; never apply to an alignment unless intended. |
| `seq -r -p` | Reverse and complement nucleotide sequences. Use both for reverse-complement, not for proteins. |
| `seq -t dna|rna|protein` | Force molecule type when auto-detection could be wrong. |
| `seq -u` / `-l` | Upper/lower case conversion; case may encode masking, so preserve semantics. |
| `grep -p`, `-f` | Match one pattern or patterns/IDs from a file. Default ID matching differs from full header matching. |
| `grep -n`, `-r`, `-i`, `-v` | Match full names, regex, ignore case, or invert. Regex and sequence search can be expensive. |
| `subseq -r START:END` | Extract 1-based regions according to SeqKit syntax; negative coordinates count from the end. |
| `subseq --bed` / `--gtf` | Region extraction from annotation files; confirm coordinate and strand behavior. |
| `fx2tab` / `tab2fx` | Convert records to/from TSV. Keep sequence and quality columns aligned for FASTQ. |
| `sort -n`, `-l`, `-s`, `-r` | Sort by name, length, sequence, or reverse order. Sorting can use substantial memory. |
| `rmdup -n` / `-s` | Deduplicate by name or sequence. Choose biological identity explicitly and save duplicate mapping with `-D`. |
| `sample -p` / `-n`, `-s` | Sample by proportion/count with seed. Sampling paired files independently breaks pairing; use paired-aware logic. |
| `split`, `split2` | Split by parts, record count, or size. `split2` supports paired FASTQ; verify generated mate files. |
| `replace` | Regex-based header/sequence renaming. Emit a mapping table when IDs feed downstream joins. |
| `concat` / `pair` | Concatenate records by common IDs or repair pairing according to command semantics; inspect unmatched records. |
| `-o`, `-w`, `-j` | Output path, FASTA line width, and threads. Use line width 0 only when downstream accepts unwrapped FASTA. |

## Workflow patterns

```bash
conda run -n seqkit --no-capture-output seqkit stats -a -T -j 8 assembly.fasta > assembly.stats.tsv
conda run -n seqkit --no-capture-output seqkit seq -m 1000 assembly.fasta -o contigs.min1k.fasta
conda run -n seqkit --no-capture-output seqkit grep -f selected_ids.txt contigs.min1k.fasta -o selected.fasta
```

For paired reads, calculate mate counts before and after any operation. Prefer paired-aware filtering tools when a criterion applies to read pairs rather than individual records.

## Validation and failure handling

Compare record count, total bases, min/max/mean length, alphabet, and duplicate IDs before/after. Empty output often means ID parsing (`-n` versus default ID), regex quoting, molecule-type mismatch, or an overstrict threshold. A broken FASTQ quality-length error indicates malformed input and must not be bypassed by converting to FASTA. Never overwrite the only copy of raw data.
