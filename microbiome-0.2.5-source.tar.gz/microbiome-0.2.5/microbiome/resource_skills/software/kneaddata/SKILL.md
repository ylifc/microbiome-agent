---
name: KneadData
description: Host-associated shotgun read quality control / 宿主序列过滤
kind: software
id: kneaddata
version: 3
selection_tier: conditional
documentation_status: DOCUMENTED
software_family: kneaddata
environment: microbiome-kneaddata
executables:
- kneaddata
packages:
- kneaddata
channels:
- conda-forge
- bioconda
tasks:
- Host-associated shotgun read quality control / 宿主序列过滤
databases:
- reference-genomes
aliases:
- KneadData
- kneaddata
keywords:
- kneaddata
- Host-associated shotgun read quality control / 宿主序列过滤
capabilities:
- Host-associated shotgun read quality control / 宿主序列过滤
inputs:
- paired or single FASTQ
- approved host-reference index
outputs:
- clean paired/unpaired reads
- read-removal accounting
upstream:
- fastqc
downstream:
- metaphlan
- humann
parameter_guidance:
- 'reference database: bind the exact index prefix and host assembly release.'
- 'paired input options: verify the selected version help and retain pair synchronization.'
- 'output: use a dedicated run directory; retain contaminant and unpaired read accounting.'
validation:
- Validate version and required package/functions before use.
- Run the task on representative data and require output assertions.
failure_handling:
- Do not assume every sample is human or silently discard unmatched mates.
- Consult version-matched Knowledge history; repair only in an approved maintenance phase.
references:
- https://github.com/biobakery/kneaddata
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# KneadData

## Capabilities and selection

Host-associated shotgun read quality control / 宿主序列过滤.
Select this capability only when its input and statistical assumptions match the study.
Catalog documentation does not assert that this software is installed or task-validated.

## Inputs and upstream

- paired or single FASTQ
- approved host-reference index

Keep sample identifiers, feature identifiers, orientation, units and reference releases explicit.
Reject missing inputs rather than acquiring substitutes during analysis.

## Outputs and downstream

- clean paired/unpaired reads
- read-removal accounting

Save the complete invocation, output schema, software version and database fingerprints.
Do not overwrite raw data, reference resources or outputs from a different run.

## Parameters and decision rules

- reference database: bind the exact index prefix and host assembly release.
- paired input options: verify the selected version help and retain pair synchronization.
- output: use a dedicated run directory; retain contaminant and unpaired read accounting.

The reference below is the full manual source. This catalog covers the supported task decisions;
option availability and defaults must be checked against the installed version and captured help.
Unknown values must not be guessed. Package functions are verified independently of R/Python.

## Workflow patterns

The following is a discovery probe, not a successful analysis recipe:

```bash
conda run -n microbiome-kneaddata --no-capture-output kneaddata --help
```

Resolve the actual environment prefix first. During production replay the frozen argv and paths.
R/Python workflows require a reviewed adapter with explicit parameters and output assertions.

## Validation and failure handling

Correct: use aligned input IDs, the approved method, compatible reference resources and validated outputs.
Incorrect: Do not assume every sample is human or silently discard unmatched mates.
A zero exit code without output validation is unverified history.
On failure record the complete command, exit code, stderr, version, input and database context.
Promote a repair only after a matching regression validation report passes.

## References and documentation coverage

- Official source: https://github.com/biobakery/kneaddata
- Documentation reviewed for catalog integration; this is not a local runtime acceptance claim.
- Parameter coverage: curated task guidance; full version-specific help is captured on discovery.
