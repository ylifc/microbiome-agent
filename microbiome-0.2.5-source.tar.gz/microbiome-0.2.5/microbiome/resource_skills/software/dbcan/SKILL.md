---
name: dbCAN
description: Carbohydrate-active enzyme annotation / 碳水化合物活性酶注释
kind: software
id: dbcan
version: 3
selection_tier: conditional
documentation_status: DOCUMENTED
software_family: dbcan
environment: microbiome-dbcan
executables:
- run_dbcan
packages:
- dbcan
channels:
- conda-forge
- bioconda
tasks:
- Carbohydrate-active enzyme annotation / 碳水化合物活性酶注释
databases:
- dbcan
aliases:
- dbCAN
- dbcan
keywords:
- dbcan
- Carbohydrate-active enzyme annotation / 碳水化合物活性酶注释
capabilities:
- Carbohydrate-active enzyme annotation / 碳水化合物活性酶注释
inputs:
- protein FASTA or a supported declared nucleotide input
outputs:
- annotation evidence tables
- enzyme-family assignments
upstream:
- prodigal
downstream: []
parameter_guidance:
- 'input type: distinguish predicted proteins from nucleotide sequence.'
- 'database directory: exact matching HMM, sequence and mapping release bundle.'
- 'thresholds and evidence combination: retain individual search evidence and the approved consensus policy.'
validation:
- Validate version and required package/functions before use.
- Run the task on representative data and require output assertions.
failure_handling:
- Do not mix database editions or describe sequence-based functional predictions as measured enzyme activity.
- Consult version-matched Knowledge history; repair only in an approved maintenance phase.
references:
- https://dbcan.readthedocs.io/en/latest/
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# dbCAN

## Capabilities and selection

Carbohydrate-active enzyme annotation / 碳水化合物活性酶注释.
Select this capability only when its input and statistical assumptions match the study.
Catalog documentation does not assert that this software is installed or task-validated.

## Inputs and upstream

- protein FASTA or a supported declared nucleotide input

Keep sample identifiers, feature identifiers, orientation, units and reference releases explicit.
Reject missing inputs rather than acquiring substitutes during analysis.

## Outputs and downstream

- annotation evidence tables
- enzyme-family assignments

Save the complete invocation, output schema, software version and database fingerprints.
Do not overwrite raw data, reference resources or outputs from a different run.

## Parameters and decision rules

- input type: distinguish predicted proteins from nucleotide sequence.
- database directory: exact matching HMM, sequence and mapping release bundle.
- thresholds and evidence combination: retain individual search evidence and the approved consensus policy.

The reference below is the full manual source. This catalog covers the supported task decisions;
option availability and defaults must be checked against the installed version and captured help.
Unknown values must not be guessed. Package functions are verified independently of R/Python.

## Workflow patterns

The following is a discovery probe, not a successful analysis recipe:

```bash
conda run -n microbiome-dbcan --no-capture-output run_dbcan --help
```

Resolve the actual environment prefix first. During production replay the frozen argv and paths.
R/Python workflows require a reviewed adapter with explicit parameters and output assertions.

## Validation and failure handling

Correct: use aligned input IDs, the approved method, compatible reference resources and validated outputs.
Incorrect: Do not mix database editions or describe sequence-based functional predictions as measured enzyme activity.
A zero exit code without output validation is unverified history.
On failure record the complete command, exit code, stderr, version, input and database context.
Promote a repair only after a matching regression validation report passes.

## References and documentation coverage

- Official source: https://dbcan.readthedocs.io/en/latest/
- Documentation reviewed for catalog integration; this is not a local runtime acceptance claim.
- Parameter coverage: curated task guidance; full version-specific help is captured on discovery.
