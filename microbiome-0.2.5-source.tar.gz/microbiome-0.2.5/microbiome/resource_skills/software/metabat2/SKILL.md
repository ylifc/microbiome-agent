---
name: MetaBAT 2
description: Robust metagenomic contig binning from assembly composition and depth profiles.
kind: software
id: metabat2
version: 2
environment: microbiome
executables:
- metabat2
- jgi_summarize_bam_contig_depths
version_args:
- -h
packages:
- metabat2
channels:
- conda-forge
- bioconda
tasks:
- metagenomic binning
- depth-based MAG recovery
databases: []
aliases:
- MetaBAT2
- MetaBAT 2
- MAG binner
- 宏基因组分箱
keywords:
- binning
- MAG
- contigs
- abundance
- tetranucleotide
- 分箱
- 宏基因组
capabilities:
- single or multi-sample abundance-aware contig binning
- small-contig recruitment
- cluster export
inputs:
- assembly FASTA
- MetaBAT depth TSV from sorted BAM files
- optional external coverage table
outputs:
- one FASTA per bin
- optional unbinned FASTA
- optional cluster membership matrix
upstream:
- megahit
- spades
- bwa
- bowtie2
- samtools
downstream:
- checkm
- drep
- gtdbtk
- bakta
software_family: metabat2
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Parameter | Meaning and setting rule |'
- '| `jgi_summarize_bam_contig_depths --outputDepth` | Create MetaBAT depth TSV from sorted BAMs; pass each sample BAM separately.
  |'
- '| `-i`, `-a`, `-o` | Assembly FASTA, abundance/depth TSV, and output prefix. These are the core bindings. |'
- '| `-m`, `--minContig` | Minimum contig length used for primary binning; default is commonly 2500. Lowering increases noise
  and compute. |'
- '| `--minSmallContig` | Lower threshold for optional recruitment into established bins; use only with adequate evidence.
  |'
- '| `-s`, `--minClsSize` | Minimum total bin size. Lower for small viral/reduced genomes only when the biological target
  supports it. |'
- '| `-t` | Threads; `0` may use all CPUs, so set an explicit allocation on shared systems. |'
- '| `--minCV`, `--minCVSum` | Per-library and total effective coverage cutoffs. Raising removes low-depth contigs. |'
- '| `--maxP`, `--minS`, `--maxEdges`, `--pTNF` | Graph sensitivity/specificity controls. Tune only with benchmarked expected
  outcomes. |'
- '| `--noAdd` | Disable additional recruitment of leftover/small contigs for a more conservative result. |'
- '| `--recruitToAbdCentroid`, `--recruitWithTNF` | Experimental recruitment constraints; record use and compare contamination.
  |'
- '| `--cvExt` | Treat an external abundance table without the usual variance columns. Confirm exact table schema first. |'
- '| `--saveCls`, `--noBinOut` | Save cluster memberships, optionally without FASTA output; useful for ensemble binning. |'
- '| `--unbinned` | Emit unbinned contigs for alternate binners or recovery. |'
- '| `--seed` | Nonzero seed for reproducibility where supported. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# MetaBAT 2

Generate depth from coordinate-sorted BAM files, then bin the matching assembly.

```bash
conda run -n microbiome --no-capture-output jgi_summarize_bam_contig_depths --outputDepth depth.tsv sample.sorted.bam
conda run -n microbiome --no-capture-output metabat2 -i assembly.fasta -a depth.tsv -o bins/bin
```

Validate assembly names, BAM reference names, and non-empty bin FASTA files before downstream CheckM analysis.
Use `metabat2 -h` to inspect the installed version; this release aborts on the unsupported `--version` option.

## Capabilities and selection

MetaBAT 2 clusters assembled contigs using tetranucleotide composition and abundance covariance. It supports one or many samples and can recruit smaller contigs into established bins in recent releases. It does not assemble reads, calculate biological completeness, or identify taxonomy.

Use it when contigs are long enough and one or more sorted BAM files map reads to the exact assembly. Differential coverage across multiple samples often improves separation, provided the samples share the co-assembly and their BAM columns remain distinct. Compare against MaxBin 2/CONCOCT when ensemble binning is scientifically justified.

## Inputs and upstream

`-i` takes nucleotide assembly FASTA from MEGAHIT or metaSPAdes. `-a` takes the depth table made by `jgi_summarize_bam_contig_depths` from coordinate-sorted BAM files produced by BWA/Bowtie 2 plus SAMtools. Contig names in FASTA, BAM headers, and depth rows must match byte-for-byte. Do not concatenate BAMs if per-sample differential coverage is needed.

## Outputs and downstream

`-o PREFIX` creates `PREFIX.NUMBER.fa` bins by default. `--unbinned` can retain unbinned sequence, and `--saveCls` can export memberships. Bins feed CheckM quality assessment, dRep dereplication, GTDB-Tk taxonomy, Bakta annotation, and targeted phylogenomics. Keep the original assembly and membership table so contigs can be traced back.

## Parameters and decision rules

| Parameter | Meaning and setting rule |
| --- | --- |
| `jgi_summarize_bam_contig_depths --outputDepth` | Create MetaBAT depth TSV from sorted BAMs; pass each sample BAM separately. |
| `-i`, `-a`, `-o` | Assembly FASTA, abundance/depth TSV, and output prefix. These are the core bindings. |
| `-m`, `--minContig` | Minimum contig length used for primary binning; default is commonly 2500. Lowering increases noise and compute. |
| `--minSmallContig` | Lower threshold for optional recruitment into established bins; use only with adequate evidence. |
| `-s`, `--minClsSize` | Minimum total bin size. Lower for small viral/reduced genomes only when the biological target supports it. |
| `-t` | Threads; `0` may use all CPUs, so set an explicit allocation on shared systems. |
| `--minCV`, `--minCVSum` | Per-library and total effective coverage cutoffs. Raising removes low-depth contigs. |
| `--maxP`, `--minS`, `--maxEdges`, `--pTNF` | Graph sensitivity/specificity controls. Tune only with benchmarked expected outcomes. |
| `--noAdd` | Disable additional recruitment of leftover/small contigs for a more conservative result. |
| `--recruitToAbdCentroid`, `--recruitWithTNF` | Experimental recruitment constraints; record use and compare contamination. |
| `--cvExt` | Treat an external abundance table without the usual variance columns. Confirm exact table schema first. |
| `--saveCls`, `--noBinOut` | Save cluster memberships, optionally without FASTA output; useful for ensemble binning. |
| `--unbinned` | Emit unbinned contigs for alternate binners or recovery. |
| `--seed` | Nonzero seed for reproducibility where supported. |

## Workflow patterns

```bash
conda run -n microbiome --no-capture-output jgi_summarize_bam_contig_depths \
  --outputDepth depth.tsv S1.sorted.bam S2.sorted.bam
conda run -n microbiome --no-capture-output metabat2 \
  -i assembly.fasta -a depth.tsv -o bins/metabat/bin \
  -m 2500 -t 16 --seed 42 --unbinned
```

Run CheckM on resulting bins, but do not filter only by completeness: report contamination, strain heterogeneity, size, N50, coverage, and taxonomy. Ensemble use requires a dedicated bin-refinement method, not manual union of FASTA files.

## Validation and failure handling

Require non-empty bins, unique contig assignment unless expected otherwise, total binned/unbinned bases, and plausible bin sizes. A depth-header error means BAM/reference mismatch or malformed external coverage. Too few bins can result from short contigs, low/dull coverage, stringent cutoffs, or a low-complexity community. High CheckM contamination may require more samples, conservative recruitment, alternate parameters/binners, or refinement. This installed release reports its version in `metabat2 -h`; do not probe with unsupported `--version`.
