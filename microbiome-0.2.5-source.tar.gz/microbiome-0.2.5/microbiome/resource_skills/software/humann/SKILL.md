---
name: HUMAnN
description: Species-aware gene-family and metabolic-pathway profiling of shotgun metagenomes and metatranscriptomes.
kind: software
id: humann
version: 2
selection_tier: conditional
environment: microbiome-humann
executables:
- humann
- humann_config
- humann_databases
packages:
- humann
channels:
- conda-forge
- bioconda
tasks:
- shotgun functional profiling
- gene-family quantification
- pathway abundance and coverage
databases:
- humann
aliases:
- HUMAnN
- pathway profiling
- 宏基因组功能通路
keywords:
- shotgun
- function
- UniRef
- ChocoPhlAn
- pathways
- MetaPhlAn
- metagenome
- metatranscriptome
capabilities:
- nucleotide and translated search
- stratified gene-family tables
- pathway abundance and coverage
- table regrouping and renormalization
inputs:
- quality-controlled shotgun FASTQ
- optional compatible MetaPhlAn profile
outputs:
- gene-family abundance
- pathway abundance
- pathway coverage
- temporary alignment evidence
upstream:
- fastp
- bowtie2
- metaphlan
downstream: []
software_family: humann
documentation_status: CURATED_PROSE
downstream_tasks:
- humann_join_tables
- humann_renorm_table
- statistical comparison and visualization
parameter_guidance:
- '| `--input` / `--output` | Input reads and output directory; use --output-basename to choose a basename. |'
- '| `--taxonomic-profile` | Optional MetaPhlAn profile for stratified output. |'
- '| `--nucleotide-database` | ChocoPhlAn directory. |'
- '| `--protein-database` | UniRef DIAMOND database. |'
- '| `--threads` | Threads. |'
- '| `--bypass-nucleotide-search` | Skip nucleotide search (translated-only); use with explicit rationale. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# Use HUMAnN for read-based community functional potential or activity. It requires compatible ChocoPhlAn, UniRef and utility-mapping releases; a Swiss-Prot DIAMOND index is not a substitute.

## Capabilities and selection

HUMAnN profiles gene families (UniRef) and metabolic pathways from shotgun metagenomes/metatranscriptomes, stratifying contributions by species when a compatible MetaPhlAn profile is supplied. Prefer it when read-based functional potential is the goal; use assembly-based annotation when genome-resolved function is required.

## Inputs and upstream

Inputs are quality-controlled shotgun FASTQ and, optionally, a MetaPhlAn taxonomic profile for stratified output. The ChocoPhlAn, UniRef and utility-mapping database releases must be mutually compatible and match the HUMAnN version.

## Outputs and downstream

Outputs are gene-family abundance (`_genefamilies.tsv`), pathway abundance (`_pathabundance.tsv`), and pathway coverage (`_pathcoverage.tsv`). Use `humann_join_tables` and `humann_renorm_table` to merge and normalize cohorts, then run statistical comparisons.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `--input` / `--output` | Input reads and output directory; use --output-basename to choose a basename. |
| `--taxonomic-profile` | Optional MetaPhlAn profile for stratified output. |
| `--nucleotide-database` | ChocoPhlAn directory. |
| `--protein-database` | UniRef DIAMOND database. |
| `--threads` | Threads. |
| `--bypass-nucleotide-search` | Skip nucleotide search (translated-only); use with explicit rationale. |

## Workflow patterns

```bash
conda run -n microbiome-humann --no-capture-output humann \
  --input sample_R1.fastq.gz --output sample_humann \
  --taxonomic-profile sample.metaphlan.tsv --threads 16
```

## Validation and failure handling

Record all database releases (ChocoPhlAn/UniRef/utility mapping). A release mismatch produces wrong or empty tables. Check unmapped fractions and renormalize only with `humann_renorm_table`; report normalization units (CPM, relab) explicitly.

## Reproducibility and audit

Record the HUMAnN software version and the exact ChocoPhlAn, UniRef, and utility-mapping releases next to every output. Re-run with `--bypass-nucleotide-search` only when explicitly justified, and note the search modes used. Renormalize only with `humann_renorm_table` and record the units.

```bash
# provenance: capture version and database layout
conda run -n microbiome-humann --no-capture-output humann --version
humann_config --print | head -40
```
