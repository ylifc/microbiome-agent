---
name: barrnap
description: Rapid ribosomal RNA gene (5S/16S/23S) prediction for bacteria, archaea and fungi using Infernal.
kind: software
id: barrnap
version: 2
selection_tier: conditional
environment: biomni-barrnap
executables:
- barrnap
packages:
- barrnap
- infernal
channels:
- conda-forge
- bioconda
tasks:
- rRNA gene prediction
- 16S/23S/5S extraction
- genome completeness and contamination screening
databases: []
aliases:
- barrnap
- rRNA 预测
- 16S 基因预测
keywords:
- rRNA
- 16S
- 23S
- 5S
- cmsearch
- cmscan
- genome QC
- 核糖体 RNA
capabilities:
- predict 5S/16S/23S rRNA genes across kingdoms
- output GFF/FASTA
- run multithreaded
- detect rRNA operons in genomes and MAGs
inputs:
- genome or MAG FASTA
outputs:
- rRNA gene GFF
- extracted rRNA FASTA
upstream:
- spades
- megahit
- flye
- prodigal
downstream:
- checkm2
- gtdbtk
- vsearch
software_family: barrnap
documentation_status: CURATED_PROSE
downstream_tasks:
- phylogenetics
parameter_guidance:
- '| `--kingdom` | `bac` / `arc` / `fun` model set; must match the target domain. |'
- '| `--threads` | CPU cores passed to Infernal/pyrodigal/diamond. |'
- '| `--evalue` | E-value cutoff for reporting. |'
- '| `--outseq` | Write predicted rRNA sequences to FASTA. |'
- '| `--incseq` | Include original input sequences in the GFF3 output. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# barrnap

Use barrnap to locate ribosomal RNA genes (5S, 16S, 23S) in bacterial, archaeal and fungal genomes and MAGs. It is a quick way to extract 16S/23S for phylogeny or to cross-check genome quality, complementing CheckM2/GTDB-Tk.

```bash
conda run -n biomni-barrnap --no-capture-output barrnap \
  --kingdom bac --threads 16 --evalue 1e-6 \
  genome.fa > rrna.gff

# Extract predicted rRNA FASTA for downstream alignment
conda run -n biomni-barrnap --no-capture-output barrnap \
  --kingdom bac --threads 16 --outseq rrna.fa genome.fa > rrna.gff
```

## Capabilities and selection

barrnap wraps Infernal (`cmsearch`/`cmscan`) against curated rRNA covariance-model HMMs and reports rRNA genes with scores and boundaries. It is fast and works on draft assemblies. Use it when a workflow needs 16S/23S extraction, rRNA operon counts, or a sanity check that a MAG contains expected ribosomal markers. It predicts genes only — it does not assign taxonomy or build trees.

## Inputs and upstream

Input is a genome/MAG FASTA. `--kingdom` selects `bac`/`arc`/`fun` models; choose the domain that matches the sample (bac for most MAGs, arc for archaea, fun for fungi). Note that `euk` and `mito` models are no longer shipped by current releases.

## Outputs and downstream

Output is a GFF of rRNA predictions and optionally an extracted FASTA (`--outseq`). Extracted 16S/23S sequences feed VSEARCH reference search, MAFFT alignment, and phylogenetic placement. Use the gene count as an auxiliary QC signal, not a replacement for CheckM2 completeness.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `--kingdom` | `bac` / `arc` / `fun` model set; must match the target domain. |
| `--threads` | CPU cores passed to Infernal/pyrodigal/diamond. |
| `--evalue` | E-value cutoff for reporting. |
| `--outseq` | Write predicted rRNA sequences to FASTA. |
| `--incseq` | Include original input sequences in the GFF3 output. |

## Workflow patterns

Predict rRNA in each genome/MAG, extract 16S/23S with `--outseq`, then align with MAFFT and build a tree with FastTree/IQ-TREE. Use rRNA gene counts as an auxiliary QC signal alongside CheckM2/GTDB-Tk.

```bash
conda run -n biomni-barrnap --no-capture-output barrnap \
  --kingdom bac --threads 16 --outseq rrna.fa genome.fa > rrna.gff
```

## Validation and failure handling

Record kingdom, thresholds, and the number of each rRNA type found. Zero 16S in a bacterial genome suggests wrong kingdom, a fragmented assembly, or overly strict thresholds; verify with a second tool (e.g., VSEARCH against a reference rRNA set) before concluding the genome lacks rRNA. Do not interpret rRNA copy number alone as contamination.

## Reproducibility and audit

Record the barrnap version, `--kingdom`, `--evalue`, and input genome. Re-run and diff the GFF to confirm determinism. Keep the input genome and the kingdom model set immutable so rRNA calls are traceable.
