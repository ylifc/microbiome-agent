---
name: Kraken2
description: Exact k-mer-based taxonomic classification of metagenomic reads and assembled sequences.
kind: software
id: kraken2
version: 2
selection_tier: conditional
environment: biomni-kraken2
executables:
- kraken2
- kraken2-build
- kraken2-inspect
packages:
- kraken2
channels:
- conda-forge
- bioconda
tasks:
- read taxonomic classification
- metagenomic profiling
- contamination screening
databases:
- kraken2
aliases:
- Kraken2
- Kraken 2
- k-mer物种分类
- 宏基因组物种分类
keywords:
- taxonomy
- metagenomics
- k-mer
- minimizer
- reads
- confidence
- Bracken
- contamination
capabilities:
- classify large read sets rapidly
- emit per-read assignments and taxonomic reports
- use custom or curated local databases
inputs:
- single-end or paired FASTQ/FASTA
- READY Kraken2 database
outputs:
- per-sequence classifications
- Kraken taxonomic report
- classified and unclassified sequence files
upstream:
- fastp
- chopper
- sra-toolkit
downstream:
- bracken
software_family: kraken2
documentation_status: CURATED_PROSE
downstream_tasks:
- abundance reporting
- contamination filtering
- targeted assembly
parameter_guidance:
- '| Command/option | Meaning and setting rule |'
- '| `--db` | Explicit READY Kraken2 database directory. |'
- '| `--paired` | Interpret two input files as synchronized mates. |'
- '| `--threads` | Classification CPU count; storage/RAM can remain the bottleneck. |'
- '| `--report` | Hierarchical taxonomic count/report file; normally always request it. |'
- '| `--use-names` | Include scientific names in primary output for readability; taxids remain preferable join keys. |'
- '| `--confidence` | Minimum fraction of informative k-mer support; higher values reduce weak calls and sensitivity. |'
- '| `--minimum-hit-groups` | Require distinct minimizer groups; useful against isolated spurious matches. |'
- '| `--minimum-base-quality` | Ignore low-quality k-mers for FASTQ input; pair with upstream quality policy. |'
- '| `--classified-out` | Save classified reads; use `#` placeholder for mate-specific paired outputs. |'
- '| `--unclassified-out` | Save unclassified reads for targeted assembly/review; paired placeholder rule also applies. |'
- '| `--report-zero-counts` | Include absent taxa for fixed-schema comparisons at larger output size. |'
- '| `--memory-mapping` | Map database from disk instead of preloading RAM; helps constrained hosts but may be I/O-bound.
  |'
- '| `--quick` | Stop after an early hit; use only for speed-oriented screening because evidence is reduced. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# Kraken2

Use Kraken2 for rapid taxonomic assignment or contamination screening when an appropriate local database exists. Results describe evidence in that database; they do not imply strain-level certainty or quantitative abundance without bias-aware follow-up such as Bracken.

## Capabilities and selection

Kraken2 uses exact minimizer matches and lowest-common-ancestor classification, making it fast and deterministic for a fixed database. Database scope strongly controls sensitivity, specificity, RAM and taxonomic bias. Prefer a documented local database matching the sample domain rather than automatically building a broad new one.

## Inputs and upstream

Use quality-controlled reads from fastp/Chopper or validated contigs. For paired reads, pass mates in the same order with `--paired`. The database directory must contain compatible `hash.k2d`, `opts.k2d` and `taxo.k2d` files under `Database/kraken2/`.

## Outputs and downstream

The standard classification stream contains classified flag, query ID, assigned taxonomy, length and k-mer evidence. `--report` creates hierarchical counts suitable for Bracken and summaries. Preserve total, classified and unclassified counts and the exact database manifest.

## Parameters and decision rules

| Command/option | Meaning and setting rule |
| --- | --- |
| `--db` | Explicit READY Kraken2 database directory. |
| `--paired` | Interpret two input files as synchronized mates. |
| `--threads` | Classification CPU count; storage/RAM can remain the bottleneck. |
| `--report` | Hierarchical taxonomic count/report file; normally always request it. |
| `--use-names` | Include scientific names in primary output for readability; taxids remain preferable join keys. |
| `--confidence` | Minimum fraction of informative k-mer support; higher values reduce weak calls and sensitivity. |
| `--minimum-hit-groups` | Require distinct minimizer groups; useful against isolated spurious matches. |
| `--minimum-base-quality` | Ignore low-quality k-mers for FASTQ input; pair with upstream quality policy. |
| `--classified-out` | Save classified reads; use `#` placeholder for mate-specific paired outputs. |
| `--unclassified-out` | Save unclassified reads for targeted assembly/review; paired placeholder rule also applies. |
| `--report-zero-counts` | Include absent taxa for fixed-schema comparisons at larger output size. |
| `--memory-mapping` | Map database from disk instead of preloading RAM; helps constrained hosts but may be I/O-bound. |
| `--quick` | Stop after an early hit; use only for speed-oriented screening because evidence is reduced. |

## Workflow patterns

```bash
conda run -n biomni-kraken2 --no-capture-output kraken2 \
  --db Database/kraken2/standard --paired reads_R1.fastq.gz reads_R2.fastq.gz \
  --threads 16 --confidence 0.1 --use-names \
  --report sample.kraken2.report --output sample.kraken2.out \
  --classified-out 'classified_#.fastq' --unclassified-out 'unclassified_#.fastq'
```

## Validation and failure handling

Run `kraken2-inspect --db <dir>` before classification and record database date/content. Require classified plus unclassified sequence counts to reconcile with input after paired-read accounting. Database load failures, missing `.k2d` files or taxonomy mismatch block execution. Unexpected classifications should be tested against confidence/evidence and possible contaminants, not removed by taxon name alone.
