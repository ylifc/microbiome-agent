---
name: Chopper
description: Streaming quality and length filtering for Oxford Nanopore FASTQ reads.
kind: software
id: chopper
version: 2
selection_tier: default
environment: biomni-chopper
executables:
- chopper
packages:
- chopper
channels:
- conda-forge
- bioconda
tasks:
- Nanopore read filtering
- long-read quality filtering
- long-read length filtering
databases: []
aliases:
- Chopper
- NanoPack Chopper
- nanopore filter
- 长读长过滤
keywords:
- ONT
- Nanopore
- FASTQ
- minimum quality
- minimum length
- headcrop
- tailcrop
- 过滤
capabilities:
- stream FASTQ quality filtering
- length range selection
- end cropping
- optional read-name contamination filtering
inputs:
- Nanopore FASTQ stream optionally gzip-compressed
outputs:
- filtered FASTQ written to standard output and filtering statistics written to log streams
upstream:
- nanoplot
downstream:
- flye
- minimap2
software_family: chopper
documentation_status: CURATED_PROSE
parameter_guidance:
- '| `-q`, `--quality` | Minimum mean read quality. Set from the observed distribution and basecaller model, not a universal
  threshold. |'
- '| `-l`, `--minlength` | Minimum length. Raising favors assembly continuity but can lose small replicons and coverage. |'
- '| `--maxlength` | Remove implausibly long/chimeric reads only with supporting QC evidence. |'
- '| `--trim-approach fixed-crop --headcrop N --tailcrop N` | Fixed terminal cropping; head/tailcrop only take effect under
  `--trim-approach`. |'
- '| `-c`, `--contam <fasta>` | Filter reads that align to a contaminant reference FASTA. |'
- '| `-t`, `--threads` | Bound decompression/filtering threads according to local help. |'
- '| stdin/stdout | Chopper is stream oriented; make redirection and compression failures visible with `pipefail`. |'
- Re-run NanoPlot on retained reads using the same summary policy and compare read count, bases, N50, quality and length quantiles
  against the unfiltered report.
- Filtering thresholds belong in the run manifest together with basecaller version and read type. Keep the original FASTQ
  immutable so threshold changes remain reproducible.
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# Chopper

Use Chopper after inspecting raw long reads with NanoPlot. It is a deterministic filter, not a basecaller, adapter trimmer, or assembly polisher.

## Capabilities and selection

Chopper filters reads by mean quality and length while streaming FASTQ, making it easy to pipe compressed data without temporary decompression. Prefer it over keeping both Chopper and Filtlong as defaults. Use a specialized adapter tool when adapters, barcodes, or chimeras require sequence-aware processing.

## Inputs and upstream

Input is a valid Nanopore FASTQ stream. Derive thresholds from raw NanoPlot metrics, expected genome size, required coverage, assembler requirements, and the biological importance of short plasmid/viral reads. Filtering before reviewing yield can remove the only reads spanning repeats.

## Outputs and downstream

Standard output is filtered FASTQ, usually redirected and gzip-compressed. Filtered reads feed Flye or minimap2. Keep raw-read and filtered-read NanoPlot reports plus the exact command so changes in yield and read spectrum are auditable.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `-q`, `--quality` | Minimum mean read quality. Set from the observed distribution and basecaller model, not a universal threshold. |
| `-l`, `--minlength` | Minimum length. Raising favors assembly continuity but can lose small replicons and coverage. |
| `--maxlength` | Remove implausibly long/chimeric reads only with supporting QC evidence. |
| `--trim-approach fixed-crop --headcrop N --tailcrop N` | Fixed terminal cropping; head/tailcrop only take effect under `--trim-approach`. |
| `-c`, `--contam <fasta>` | Filter reads that align to a contaminant reference FASTA. |
| `-t`, `--threads` | Bound decompression/filtering threads according to local help. |
| stdin/stdout | Chopper is stream oriented; make redirection and compression failures visible with `pipefail`. |

Re-run NanoPlot on retained reads using the same summary policy and compare read count, bases, N50, quality and length quantiles against the unfiltered report.

Filtering thresholds belong in the run manifest together with basecaller version and read type. Keep the original FASTQ immutable so threshold changes remain reproducible.

## Workflow patterns

```bash
set -o pipefail
gzip -dc reads.fastq.gz | conda run -n biomni-chopper --no-capture-output chopper \
  --quality 10 --minlength 1000 | gzip -c > reads.filtered.fastq.gz
```

Run NanoPlot again on `reads.filtered.fastq.gz` and confirm enough total bases and long reads remain for the planned assembly.

## Validation and failure handling

Require valid FASTQ, nonzero retained reads, reported/independently counted input and output totals, expected quality improvement, retained coverage, and no truncated gzip stream. Zero output usually means thresholds are incompatible with the data or the input stream failed. Recalculate thresholds from QC; do not repeatedly lower them without recording the scientific consequence.
