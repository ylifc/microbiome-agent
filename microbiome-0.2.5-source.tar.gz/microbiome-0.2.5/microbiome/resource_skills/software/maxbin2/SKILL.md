---
name: MaxBin 2
description: Automatic metagenomic binning using tetranucleotide frequencies and abundance profiles.
kind: software
id: maxbin2
version: 2
environment: microbiome
executables:
- run_MaxBin.pl
version_args:
- -h
packages:
- maxbin2
channels:
- conda-forge
- bioconda
tasks:
- metagenomic binning
- MAG recovery
databases: []
aliases:
- MaxBin2
- MaxBin 2
- MAG binner
- 宏基因组分箱
keywords:
- binning
- MAG
- abundance
- marker genes
- contigs
- 分箱
- 宏基因组
capabilities:
- automatic abundance-aware contig binning
- single or multiple abundance profiles
- marker-guided bin recovery
inputs:
- assembly FASTA
- abundance TSV or reads used to estimate abundance
outputs:
- numbered bin FASTA files
- summary table
- abundance table
- marker-gene and probability reports
upstream:
- megahit
- spades
- salmon
downstream:
- checkm
- drep
- gtdbtk
- bakta
software_family: maxbin2
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Parameter | Meaning and setting rule |'
- '| `-contig` | Required assembly FASTA with unique contig IDs. |'
- '| `-out` | Required output prefix, not merely a directory. Use a new prefix per run. |'
- '| `-abund` | One abundance file for contigs. Validate schema and IDs. |'
- '| `-abund_list` | File listing multiple abundance files for differential-coverage binning. Preserve sample order/provenance.
  |'
- '| `-reads`, `-reads2` | First/second read files for abundance estimation. Use matching pairs. |'
- '| `-reads_list` | Multiple read libraries as supported by local help; do not confuse with abundance lists. |'
- '| `-min_contig_length` | Minimum contig length. Lowering may recover small genomes but weakens composition signal. |'
- '| `-thread` | CPU threads within the allocated limit. |'
- '| `-max_iteration` | Maximum EM iterations. Increase only when logs show non-convergence, not as a default quality boost.
  |'
- '| `-prob_threshold` | Assignment probability threshold. Higher is conservative; lower can increase contamination. |'
- '| `-markerset` | Marker set selection such as bacterial 107 or universal 40 where supported; match expected domain/community.
  |'
- '| `-plotmarker` | Produce marker visualization when its graphics dependency is available. |'
- '| `-preserve_intermediate` | Keep intermediate abundance/alignment files for audit or debugging, at disk cost. |'
- '| `-verbose` | More diagnostic output; useful during new workflow development. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# MaxBin 2

Provide assembled contigs and either an abundance table or reads accepted by MaxBin. Use a dedicated output prefix.

```bash
conda run -n microbiome --no-capture-output run_MaxBin.pl -contig assembly.fasta -abund abundance.tsv -out bins/maxbin
```

Inspect the summary, marker-gene report, and every generated `.fasta` bin. Do not treat empty or very small bins as valid MAGs.

## Capabilities and selection

MaxBin 2 bins contigs using nucleotide composition, abundance, and lineage marker evidence. It can calculate abundance from reads or consume one/multiple abundance files. It is useful as an independent binner for comparison or ensemble refinement. It does not assess final MAG quality or taxonomy.

Use abundance files when coverage has already been calculated reproducibly and their first-column identifiers exactly match contigs. Use read inputs when a simple single-sample workflow is acceptable. For co-assemblies, multiple sample-specific abundance profiles are more informative than pooled abundance.

## Inputs and upstream

Assembly FASTA comes from MEGAHIT/metaSPAdes. Abundance is a tabular mapping from contig ID to abundance, with schema verified against `run_MaxBin.pl -help`; it may be derived from mapped reads/Salmon only after ensuring its estimator and identifier format are compatible. Read inputs are FASTQ/FASTA accepted by the installed version.

## Outputs and downstream

The output prefix yields numbered `.fasta` bins, `.summary`, `.abundance`, `.marker`, `.marker_of_each_gene`, `.prob_dist`, and logs/intermediates depending on options. Bins feed CheckM, dRep, GTDB-Tk, Bakta, or refinement. Summary/marker files are evidence and must stay with FASTA bins.

## Parameters and decision rules

| Parameter | Meaning and setting rule |
| --- | --- |
| `-contig` | Required assembly FASTA with unique contig IDs. |
| `-out` | Required output prefix, not merely a directory. Use a new prefix per run. |
| `-abund` | One abundance file for contigs. Validate schema and IDs. |
| `-abund_list` | File listing multiple abundance files for differential-coverage binning. Preserve sample order/provenance. |
| `-reads`, `-reads2` | First/second read files for abundance estimation. Use matching pairs. |
| `-reads_list` | Multiple read libraries as supported by local help; do not confuse with abundance lists. |
| `-min_contig_length` | Minimum contig length. Lowering may recover small genomes but weakens composition signal. |
| `-thread` | CPU threads within the allocated limit. |
| `-max_iteration` | Maximum EM iterations. Increase only when logs show non-convergence, not as a default quality boost. |
| `-prob_threshold` | Assignment probability threshold. Higher is conservative; lower can increase contamination. |
| `-markerset` | Marker set selection such as bacterial 107 or universal 40 where supported; match expected domain/community. |
| `-plotmarker` | Produce marker visualization when its graphics dependency is available. |
| `-preserve_intermediate` | Keep intermediate abundance/alignment files for audit or debugging, at disk cost. |
| `-verbose` | More diagnostic output; useful during new workflow development. |

## Workflow patterns

```bash
conda run -n microbiome --no-capture-output run_MaxBin.pl \
  -contig assembly.fasta -abund S1.abundance.tsv \
  -out bins/maxbin/maxbin -min_contig_length 1000 -thread 16
```

For multiple samples, construct and validate the abundance-list file rather than averaging coverages. Compare MaxBin bins with MetaBAT 2/CONCOCT using a formal refinement strategy and then reassess quality.

## Validation and failure handling

Require numbered non-empty bins, a summary consistent with output count, marker reports, and traceable contig IDs. Missing abundance matches often come from FASTA header truncation or a table built against another assembly. Very few bins may reflect stringent contig length/probability, low coverage, or limited community complexity. Excess marker duplication/CheckM contamination calls for conservative thresholds or refinement, not deletion of inconvenient markers.
