---
name: Pilon
description: Automated genome assembly improvement and variant detection using Illumina reads to polish draft assemblies.
kind: software
id: pilon
version: 2
selection_tier: conditional
environment: biomni-pilon
executables:
- pilon
packages:
- pilon
channels:
- conda-forge
- bioconda
tasks:
- Illumina-based assembly polishing
- structural and single-nucleotide error correction
- hybrid assembly refinement
databases: []
aliases:
- Pilon
- pilon
- 组装校正
- 杂交组装抛光
keywords:
- polishing
- assembly
- Illumina
- hybrid
- correction
- 组装
- 校正
capabilities:
- correct SNPs
- small indels and local misassemblies using read evidence
- polish long-read or draft assemblies with short reads
- detect variants relative to a reference
inputs:
- draft assembly FASTA
- coordinate-sorted BAM of Illumina reads aligned to that assembly
outputs:
- polished FASTA
- optional VCF of changes
- optional corrected BAM
upstream:
- flye
- unicycler
- spades
- bwa
- minimap2
- samtools
downstream:
- quast
- bakta
- checkm2
- gtdbtk
software_family: pilon
documentation_status: CURATED_PROSE
parameter_guidance:
- '| `--genome` | Draft assembly to polish. |'
- '| `--frags` | Sorted, indexed Illumina BAM aligned to the draft. |'
- '| `--changes` | Emit a plain-text list of applied changes; always request for auditability. |'
- '| `--vcf` | Emit a VCF of applied changes. |'
- '| `--fix` | Restrict to specific error classes (`snps`, `indels`, `gaps`, `local`, `all`). |'
- '| `--diploid` | Diploid mode; not appropriate for haploid bacterial isolates. |'
- '| `--threads` | Threads. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# Pilon

Use Pilon to polish a long-read or draft assembly with Illumina read evidence. It corrects single-nucleotide errors, small indels, and local misassemblies, and can emit a VCF of the changes it applies.

```bash
# Align Illumina reads to the draft, then polish
conda run -n biomni-pilon --no-capture-output bwa index draft.fa
conda run -n biomni-pilon --no-capture-output bwa mem -t 16 draft.fa il_R1.fastq.gz il_R2.fastq.gz | \
  samtools sort -@ 8 -o il.sorted.bam && samtools index il.sorted.bam
conda run -n biomni-pilon --no-capture-output pilon \
  --genome draft.fa --frags il.sorted.bam --output polished --changes --vcf --threads 16
```

## Capabilities and selection

Pilon integrates read alignments, read pairs, and local reassembly to correct errors and report changes. Use it for hybrid polishing (long-read backbone + Illumina) or to fix a draft before annotation. Choose Medaka/Racon for long-read-only polishing; Pilon specifically requires Illumina (or similarly accurate short-read) evidence. Record the BAM provenance and the Pilon changes VCF so the polishing delta is auditable.

## Inputs and upstream

`--genome` is the draft FASTA; `--frags` is a coordinate-sorted, indexed BAM of Illumina reads mapped to that exact assembly (BWA-MEM is standard). The BAM reference and the draft FASTA must be byte-identical. Do not polish a metagenome co-assembly the same way as a single isolate without verifying isolate purity.

## Outputs and downstream

Outputs are `polished.fasta` and an optional `polished.changes` VCF describing each edit. Run QUAST before/after to quantify the polishing delta, then annotate with Bakta and assess with CheckM2/GTDB-Tk. Keep the pre-polish assembly for comparison.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `--genome` | Draft assembly to polish. |
| `--frags` | Sorted, indexed Illumina BAM aligned to the draft. |
| `--changes` | Emit a plain-text list of applied changes; always request for auditability. |
| `--vcf` | Emit a VCF of applied changes. |
| `--fix` | Restrict to specific error classes (`snps`, `indels`, `gaps`, `local`, `all`). |
| `--diploid` | Diploid mode; not appropriate for haploid bacterial isolates. |
| `--threads` | Threads. |

## Workflow patterns

Polish a long-read backbone with Illumina evidence: align with BWA-MEM, sort/index, run Pilon with `--changes --vcf`, quantify the delta with QUAST, then annotate the polished assembly with Bakta.

```bash
conda run -n biomni-pilon --no-capture-output pilon \
  --genome draft.fa --frags il.sorted.bam --output polished --changes --vcf --threads 16
```

## Validation and failure handling

Require a sorted, indexed BAM and matching reference names. If Pilon exits on a BAM/reference mismatch, re-align against the exact draft FASTA. Compare pre/post QUAST metrics and inspect the changes VCF for a reasonable number of edits; an unusually high edit count may indicate misaligned reads or a contaminated draft. Never silently discard the original assembly.
