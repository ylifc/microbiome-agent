---
name: Unicycler
description: Bacterial isolate assembly with short reads, long reads, or hybrid data.
kind: software
id: unicycler
version: 2
selection_tier: conditional
environment: microbiome-unicycler
executables:
- unicycler
packages:
- unicycler
channels:
- conda-forge
- bioconda
tasks:
- hybrid bacterial assembly
- short-read bacterial assembly
- circular replicon resolution
databases: []
aliases:
- Unicycler
- hybrid assembly
- 混合组装
keywords:
- Illumina
- Nanopore
- PacBio
- hybrid
- bacterial isolate
- circular plasmid
- assembly graph
capabilities:
- hybrid assembly
- short-read graph resolution with long reads
- rotation and polishing orchestration
inputs:
- synchronized Illumina pairs and optional ONT or PacBio long reads from one isolate
outputs:
- assembly.fasta
- assembly.gfa
- unicycler.log
upstream:
- fastp
- nanoplot
- chopper
downstream:
- quast
- minimap2
- bakta
- mob-suite
software_family: unicycler
documentation_status: CURATED_PROSE
parameter_guidance:
- '| `-1` / `-2` | Paired Illumina reads. |'
- '| `-l` | Long reads (ONT/PacBio). |'
- '| `-o` | Output directory. |'
- '| `--mode` | normal/bold/conservative; bold for more long-read bridging, conservative for fewer spurious joins. |'
- '| `-t` | Threads. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# Use Unicycler conditionally for bacterial isolate hybrid assembly. Do not use it for mixed-community metagenomes or pool unrelated samples.

## Capabilities and selection

Unicycler assembles bacterial isolates from Illumina alone, long reads alone, or hybrid data, building a short-read assembly graph and using long reads to bridge repeats and resolve circular chromosomes/plasmids. Prefer it for hybrid isolate assembly when Illumina + ONT/PacBio data exist for the same isolate; use Flye for long-read-only and SPAdes for short-read-only.

## Inputs and upstream

Inputs are synchronized Illumina pairs and optional ONT/PacBio long reads from a single isolate. Trim adapters with fastp and quality-filter long reads (Chopper/NanoPlot) first. Do not mix isolates or samples.

## Outputs and downstream

Outputs are `assembly.fasta`, `assembly.gfa` (the graph), and `unicycler.log`. Run QUAST and read-back mapping for QC, then annotate with Bakta and run MOB-suite for plasmid typing.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `-1` / `-2` | Paired Illumina reads. |
| `-l` | Long reads (ONT/PacBio). |
| `-o` | Output directory. |
| `--mode` | normal/bold/conservative; bold for more long-read bridging, conservative for fewer spurious joins. |
| `-t` | Threads. |

## Workflow patterns

```bash
conda run -n microbiome-unicycler --no-capture-output unicycler \
  -1 il_R1.fastq.gz -2 il_R2.fastq.gz -l ont.fastq.gz -o unicycler_out -t 16
```

## Validation and failure handling

Require one isolate per run and synchronized mates. Inspect `assembly.gfa` and QUAST for circularity and unexpected small contigs; a highly fragmented hybrid assembly may indicate low long-read coverage or mixed samples. Never pool unrelated samples to raise coverage.

## Reproducibility and audit

Record the Unicycler version, the read sets used, and the `--mode` next to the output. Re-run on the same isolate and confirm identical assembly statistics to verify reproducibility. Inspect the graph and QUAST for circularity and unexpected contigs, and never pool unrelated samples.

```bash
# provenance: capture version
conda run -n microbiome-unicycler --no-capture-output unicycler --version
```

Record long-read coverage and whether circular replicons were resolved; unresolved plasmids are a follow-up, not an automatic failure.
