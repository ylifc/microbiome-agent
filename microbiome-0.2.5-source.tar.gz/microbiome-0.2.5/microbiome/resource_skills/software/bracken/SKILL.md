---
name: Bracken
description: Re-estimates taxonomic abundance from Kraken2 reports at a selected rank and read length.
kind: software
id: bracken
version: 2
selection_tier: default
environment: microbiome-bracken
executables:
- bracken
- bracken-build
packages:
- bracken
channels:
- conda-forge
- bioconda
tasks:
- shotgun taxonomic abundance estimation
- species genus and higher-rank profile generation
databases:
- kraken2
aliases:
- Bracken
- Kraken abundance
- 物种丰度重估
keywords:
- Kraken2
- abundance
- taxonomy
- read length
- Bayesian redistribution
- metagenome
capabilities:
- redistribute Kraken2 assignments
- estimate abundance at selected rank
- produce compositional count tables
inputs:
- Kraken2 report
- matching Kraken2 database with read-length distribution files
outputs:
- rank-specific Bracken abundance table
upstream:
- kraken2
downstream: []
software_family: bracken
documentation_status: CURATED_PROSE
downstream_tasks:
- cohort abundance matrix
- diversity and differential-abundance analysis
parameter_guidance:
- '| `-d` | The same immutable Kraken2 database used for classification. |'
- '| `-i` | Kraken2 report file from the same run. |'
- '| `-o` | Output abundance table path. |'
- '| `-r` | Read length for the distribution file; must match the processed reads. |'
- '| `-l` | Reporting rank (S/G/F/...); choose by the study question. |'
- '| `-t` | Threshold for including a taxon (default 10 reads). |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# Run Bracken only after Kraken2 with the exact same immutable database. The database needs a `database<read_length>mers.kmer_distrib` file matching the effective read length; membership in a Kraken2 database alone is not enough.

## Capabilities and selection

Bracken redistributes Kraken2's per-read assignments across the taxonomy using Bayesian abundance estimation, producing compositional abundance at a chosen rank (species, genus, etc.). It does not classify reads itself; it depends entirely on a Kraken2 report and the same database. Prefer Bracken for relative-abundance tables; keep raw Kraken2 classified/unclassified counts for reconciliation.

## Inputs and upstream

Inputs are a Kraken2 `--report` file and the exact same immutable database, which must contain the `database<read_length>mers.kmer_distrib` file whose read length matches the processed reads. Run Kraken2 first with `--report`, then Bracken on that report.

## Outputs and downstream

Output is a rank-specific abundance table (`sample.bracken.species.tsv`). Merge per-sample tables into a cohort matrix for diversity and differential-abundance analysis. Bracken estimates are relative, not absolute biomass.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `-d` | The same immutable Kraken2 database used for classification. |
| `-i` | Kraken2 report file from the same run. |
| `-o` | Output abundance table path. |
| `-r` | Read length for the distribution file; must match the processed reads. |
| `-l` | Reporting rank (S/G/F/...); choose by the study question. |
| `-t` | Threshold for including a taxon (default 10 reads). |

## Workflow patterns

```bash
conda run -n microbiome-bracken --no-capture-output bracken \
  -d Database/kraken2/standard-YYYYMMDD -i sample.kraken2.report \
  -o sample.bracken.species.tsv -r 150 -l S -t 10
```

## Validation and failure handling

Record the Kraken database fingerprint, Bracken distribution file, threshold, and rank. Validate that redistributed reads do not exceed the Kraken report total and keep unclassified reads explicit. A missing distribution file means the read length is wrong or the database is incomplete; rebuild or select the correct distribution rather than guessing.

## Reproducibility and audit

Record the Kraken2 database fingerprint, the Bracken distribution file and read length, the reporting rank, and the threshold together with the output table. Recompute on the same inputs and diff the tables to confirm reproducibility. Never change the database between a Bracken pass and its Kraken2 source report; the two must share one immutable database child.

```bash
# provenance: capture the distribution file actually used
ls -la Database/kraken2/standard-YYYYMMDD/database*mers.kmer_distrib
sha256sum sample.kraken2.report sample.bracken.species.tsv
```
