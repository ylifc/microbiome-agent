---
name: BBMap
description: BBMap/BBTools suite for adapter/quality trimming, host removal, deduplication, read repair and reference coverage.
kind: software
id: bbmap
version: 2
selection_tier: conditional
environment: biomni-bbmap
executables:
- bbduk.sh
- bbmap.sh
- repair.sh
- dedupe.sh
- stats.sh
- pileup.sh
- clumpify.sh
packages:
- bbmap
channels:
- conda-forge
- bioconda
tasks:
- adapter and quality trimming
- host and contaminant removal
- read deduplication
- paired-read repair
- reference mapping and coverage
- k-mer screening
databases:
- reference-genomes
aliases:
- BBMap
- BBTools
- bbduk
- 宿主去除
- 接头去除
- 去重
keywords:
- bbduk
- bbmap
- host removal
- adapter trimming
- deduplication
- k-mer
- coverage
- 宿主
- 去重
capabilities:
- trim adapters and low-quality bases
- filter reads by k-mer match to a reference
- deduplicate and repair paired reads
- map reads for coverage and assembly QC
inputs:
- FASTQ (single or paired)
- optional host/contaminant reference FASTA
outputs:
- trimmed/filtered FASTQ
- mapping statistics
- coverage files
upstream:
- sra-toolkit
- cutadapt
downstream:
- fastp
- bowtie2
- spades
- megahit
- kraken2
- salmon
software_family: bbmap
documentation_status: CURATED_PROSE
parameter_guidance:
- '| `ref=`, `k=`, `hdist=` | Reference and k-mer settings for filtering; longer k and lower hdist are more specific. |'
- '| `ktrim=r` / `l` | Trim from the right or left end of reads matching a reference. |'
- '| `qtrim=rl`, `trimq=` | Quality trim both ends below a Phred score. |'
- '| `minlen=` | Minimum read length after trimming. |'
- '| `stats=` | Write per-stage retention statistics; always request. |'
- '| `dedupe` (clumpify) | Remove PCR duplicates; pair with `groups=1` for read groups when relevant. |'
- '| `threads=` | Threads. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# BBMap / BBTools

Use BBTools (bbduk.sh, bbmap.sh, repair.sh, dedupe.sh) for robust adapter/quality trimming, host and contaminant removal, deduplication, and read repair. It is especially useful for host-removal against a large eukaryotic genome before microbial assembly or classification.

```bash
# Host/contaminant removal by k-mer match against a reference
conda run -n biomni-bbmap --no-capture-output bbduk.sh \
  in=R1.fastq.gz in2=R2.fastq.gz out=clean_R1.fastq.gz out2=clean_R2.fastq.gz \
  ref=host.fa k=31 hdist=1 stats=host_filter.stats.txt

# Adapter + quality trimming
conda run -n biomni-bbmap --no-capture-output bbduk.sh \
  in=R1.fastq.gz in2=R2.fastq.gz out=t_R1.fastq.gz out2=t_R2.fastq.gz \
  ref=adapters.fa ktrim=r k=23 mink=11 hdist=1 qtrim=rl trimq=20 minlen=50

# Read deduplication (PCR duplicates)
conda run -n biomni-bbmap --no-capture-output clumpify.sh in=t_R1.fastq.gz in2=t_R2.fastq.gz out=d_R1.fastq.gz out2=d_R2.fastq.gz dedupe
```

## Capabilities and selection

BBTools covers a wide surface: `bbduk.sh` for k-mer-based filtering/trimming, `bbmap.sh` for splice-aware or standard mapping, `repair.sh` for re-pairing orphaned mates, `dedupe.sh`/`clumpify.sh` for duplicate removal, and `stats.sh` for FASTQ metrics. Prefer fastp as the default general QC; add BBMap when host/contaminant removal by k-mer, deduplication, or reference-based coverage is required. Record the reference and its version whenever filtering reads.

## Inputs and upstream

Input is FASTQ, with an optional reference for filtering (`ref=`) or mapping. For host removal the reference should be the host genome (human/mouse/plant) appropriate to the sample. Adapter files must match the library kit.

## Outputs and downstream

Outputs are filtered/trimmed FASTQ plus `stats=` files with in/out counts per stage. Preserve the host-removal accounting (input reads, retained reads, host-matching reads) for the acceptance report. Cleaned reads feed assembly, classification, and quantification.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `ref=`, `k=`, `hdist=` | Reference and k-mer settings for filtering; longer k and lower hdist are more specific. |
| `ktrim=r` / `l` | Trim from the right or left end of reads matching a reference. |
| `qtrim=rl`, `trimq=` | Quality trim both ends below a Phred score. |
| `minlen=` | Minimum read length after trimming. |
| `stats=` | Write per-stage retention statistics; always request. |
| `dedupe` (clumpify) | Remove PCR duplicates; pair with `groups=1` for read groups when relevant. |
| `threads=` | Threads. |

## Workflow patterns

Run host removal, then adapter/quality trimming, then deduplication and read repair before assembly or classification. Preserve the host-removal accounting (input/retained/host reads) in the acceptance report.

```bash
conda run -n biomni-bbmap --no-capture-output bbduk.sh \
  in=R1.fastq.gz in2=R2.fastq.gz out=clean_R1.fastq.gz out2=clean_R2.fastq.gz \
  ref=host.fa k=31 hdist=1 stats=host_filter.stats.txt
```

## Validation and failure handling

Record exact reference paths/versions and k-mer settings because host removal changes downstream community composition. A near-total loss of reads usually means the wrong reference or an overly aggressive k-mer; a retention near 100% for a host-heavy sample suggests the reference failed to load. Reconcile paired files with `repair.sh` before assembly.
