---
name: VAMB
description: Metagenomic binning / 宏基因组分箱
kind: software
id: vamb
version: 3
selection_tier: conditional
documentation_status: DOCUMENTED
software_family: vamb
environment: microbiome-vamb
executables:
- vamb
packages:
- vamb
channels:
- conda-forge
- bioconda
tasks:
- Metagenomic binning / 宏基因组分箱
databases: []
aliases:
- VAMB
- vamb
keywords:
- vamb
- Metagenomic binning / 宏基因组分箱
capabilities:
- Metagenomic binning / 宏基因组分箱
inputs:
- contigs and aligned coverage/composition inputs
outputs:
- bins and sequence-to-bin assignments
- training diagnostics
upstream:
- megahit
- spades
downstream:
- checkm2
- gunc
- gtdbtk
parameter_guidance:
- 'input IDs: contigs and abundance rows must align exactly.'
- 'model and random seed: freeze the selected supported mode and resource limits.'
- 'minimum sequence/bin size: prespecify and report all filtering.'
validation:
- Validate version and required package/functions before use.
- Run the task on representative data and require output assertions.
failure_handling:
- Do not interpret bins as validated genomes before independent quality checks.
- Consult version-matched Knowledge history; repair only in an approved maintenance phase.
references:
- https://github.com/RasmussenLab/vamb
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# VAMB

## Capabilities and selection

Metagenomic binning / 宏基因组分箱.
Select this capability only when its input and statistical assumptions match the study.
Catalog documentation does not assert that this software is installed or task-validated.

## Inputs and upstream

- contigs and aligned coverage/composition inputs

Keep sample identifiers, feature identifiers, orientation, units and reference releases explicit.
Reject missing inputs rather than acquiring substitutes during analysis.

## Outputs and downstream

- bins and sequence-to-bin assignments
- training diagnostics

Save the complete invocation, output schema, software version and database fingerprints.
Do not overwrite raw data, reference resources or outputs from a different run.

## Parameters and decision rules

- input IDs: contigs and abundance rows must align exactly.
- model and random seed: freeze the selected supported mode and resource limits.
- minimum sequence/bin size: prespecify and report all filtering.

The reference below is the full manual source. This catalog covers the supported task decisions;
option availability and defaults must be checked against the installed version and captured help.
Unknown values must not be guessed. Package functions are verified independently of R/Python.

## Workflow patterns

The following is a discovery probe, not a successful analysis recipe:

```bash
conda run -n microbiome-vamb --no-capture-output vamb --help
```

Resolve the actual environment prefix first. During production replay the frozen argv and paths.
R/Python workflows require a reviewed adapter with explicit parameters and output assertions.

## Validation and failure handling

Correct: use aligned input IDs, the approved method, compatible reference resources and validated outputs.
Incorrect: Do not interpret bins as validated genomes before independent quality checks.
A zero exit code without output validation is unverified history.
On failure record the complete command, exit code, stderr, version, input and database context.
Promote a repair only after a matching regression validation report passes.

## References and documentation coverage

- Official source: https://github.com/RasmussenLab/vamb
- Documentation reviewed for catalog integration; this is not a local runtime acceptance claim.
- Parameter coverage: curated task guidance; full version-specific help is captured on discovery.
