---
name: PlasFlow
description: Neural-network classification of plasmid vs chromosomal sequences from metagenomic assemblies.
kind: software
id: plasflow
version: 2
selection_tier: conditional
environment: biomni-plasflow
executables:
- PlasFlow.py
packages:
- plasflow
channels:
- conda-forge
- bioconda
tasks:
- plasmid identification
- metagenomic plasmid prediction
- plasmid vs chromosome classification
databases: []
aliases:
- PlasFlow
- plasmid classifier
- 质粒预测
- 质粒染色体分类
keywords:
- plasmid
- chromosome
- metagenome
- neural network
- TensorFlow
- classification
- 质粒
capabilities:
- classify assembled contigs as plasmid or chromosome
- report per-contig probability
- work on metagenomes and isolate assemblies
inputs:
- assembled contig FASTA
- a downloaded PlasFlow trained model
outputs:
- per-contig plasmid/chromosome probability table
upstream:
- megahit
- spades
- flye
downstream:
- mob-suite
- genomad
software_family: plasflow
documentation_status: CURATED_PROSE
downstream_tasks:
- plasmidfinder
- downstream plasmid typing
parameter_guidance:
- '| `--input` | Input contig FASTA. |'
- '| `--output` | Output TSV filename (required), not a directory. |'
- '| `--threshold` | Plasmid probability cutoff (default 0.7); lower increases recall and false positives. |'
- '| model file | The downloaded trained model; record its path and version. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# PlasFlow

Use PlasFlow to classify assembled contigs as plasmid or chromosome using a neural network trained on tetranucleotide composition and gene features. It is especially useful for metagenomes, where reference-based plasmid detection (geNomad) and PlasFlow provide complementary evidence.

```bash
# download the pre-trained model once, then classify
conda run -n biomni-plasflow --no-capture-output PlasFlow.py --input contigs.fasta \
  --output plasflow_out --threshold 0.7
```

## Capabilities and selection

PlasFlow predicts a plasmid probability per contig without needing a reference database, so it generalizes to novel plasmid sequences. Prefer it for metagenome-wide plasmid mining; cross-check with geNomad and PlasClass, and follow plasmid candidates with MOB-suite/PlasmidFinder typing. It is a classifier, not a completeness assessor — do not use it to judge plasmid circularity or integrity.

## Inputs and upstream

Input is an assembled contig FASTA from MEGAHIT/SPAdes/metaFlye. The pre-trained model (downloaded once via the PlasFlow instructions) must be available to the script. Record the model version because it changes predictions.

## Outputs and downstream

Output is a table of contig IDs with plasmid/chromosome probabilities and predicted labels. Feed plasmid-classified contigs to MOB-suite/PlasmidFinder for replicon typing and to geNomad for mobility-gene corroboration.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `--input` | Input contig FASTA. |
| `--output` | Output TSV filename (required), not a directory. |
| `--threshold` | Plasmid probability cutoff (default 0.7); lower increases recall and false positives. |
| model file | The downloaded trained model; record its path and version. |

## Workflow patterns

```bash
# assemble a metagenome, then screen for plasmids
conda run -n biomni-plasflow --no-capture-output PlasFlow.py \
  --input metagenome/contigs.fasta --output plasflow --threshold 0.7
# corroborate with geNomad and type with MOB-suite
```

## Validation and failure handling

Record the model version and threshold. A near-zero plasmid call rate may mean a genuinely chromosome-dominated assembly, a missing model, or fragmented contigs below the informative length. Cross-check a sample of plasmid calls with geNomad/mob-suite before reporting; a contig is not a proven plasmid on probability alone.

## Reproducibility and audit

Record the PlasFlow version, model version, threshold, and input assembly. Re-run on the same contigs and diff the probability table to confirm determinism. Keep the model file immutable and note its provenance, since a model swap changes every prediction.
