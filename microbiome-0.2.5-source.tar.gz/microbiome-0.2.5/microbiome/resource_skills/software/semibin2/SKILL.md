---
name: SemiBin2
description: Semi-supervised metagenomic binning for short-read, long-read, single-sample, and multi-sample assemblies.
kind: software
id: semibin2
version: 2
selection_tier: conditional
environment: biomni-semibin2
executables:
- SemiBin2
packages:
- semibin
channels:
- conda-forge
- bioconda
tasks:
- metagenomic binning
- long-read binning
- multi-sample binning
databases: []
aliases:
- SemiBin
- SemiBin2
- 半监督分箱
- 宏基因组分箱
keywords:
- MAG
- binning
- contigs
- abundance
- BAM
- short reads
- long reads
- co-binning
capabilities:
- learn sample-specific contig representations
- combine composition and abundance for binning
- use pretrained habitats or self-supervised training
inputs:
- assembled contig FASTA
- sorted read-to-contig BAM files for short-read modes
- sequencing type and optional habitat
outputs:
- reconstructed_bins FASTA files
- binning result tables
- training and reclustering logs
upstream:
- megahit
- spades
- flye
- minimap2
- samtools
downstream:
- dastool
- checkm2
- gunc
- drep
- gtdbtk
software_family: semibin2
documentation_status: CURATED_PROSE
parameter_guidance:
- '| Command/option | Meaning and setting rule |'
- '| `SemiBin2 single_easy_bin` | Preferred integrated workflow for one sample or one co-assembly. |'
- '| `SemiBin2 multi_easy_bin` | Use for multiple sample assemblies/coverage profiles; keep input ordering and labels explicit.
  |'
- '| `-i`, `--input-fasta` | Assembly FASTA; headers must match every BAM reference name. |'
- '| `-b`, `--input-bam` | One or more sorted BAMs for short-read abundance; do not provide long-read mappings as a silent
  substitute. |'
- '| `-o`, `--output` | Dedicated output directory; never merge unrelated runs. |'
- '| `--environment` | Select a matching pretrained/semi-supervised habitat. Prefer local model/reference assets; any missing
  asset requires a registered, marked acquisition proposal rather than an implicit first-run download. |'
- '| `--sequencing-type long_read` | Enable long-read behavior for HiFi/ONT assemblies; confirm support in the pinned version.
  |'
- '| `--threads` | CPU allowance for feature generation, training and reclustering. |'
- '| `--minfasta-kbs` | Minimum total bin size; lower only for expected tiny genomes and document the rationale. |'
- '| `--compression` | Compression used for emitted bin FASTA files; downstream suffix handling must agree. |'
- '| `--random-seed` | Pin for repeatable model training and comparisons. |'
- '| `--no-recluster` | Disable reclustering only for diagnosis or a controlled comparison; default reclustering often improves
  bins. |'
- '| training subcommands | Use self-supervised/semi-supervised custom training only when easy mode or pretrained models do
  not fit the habitat. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# SemiBin2

Use SemiBin2 when sample-specific representation learning or long-read-aware binning is valuable. For robust MAG recovery, run it as one complementary binner beside MetaBAT2/MaxBin2/CONCOCT and consolidate with DAS Tool instead of assuming one binner is universally best.

## Capabilities and selection

SemiBin2 learns contig embeddings from sequence composition and, for short reads, abundance links. `single_easy_bin` is the normal one-sample entry point; `multi_easy_bin` handles multiple samples while preserving sample-aware outputs. Long-read mode can work from long-read assemblies without short-read abundance BAMs. Habitat-specific pretrained models reduce training cost only when the sample matches the declared environment.

## Inputs and upstream

Use contigs from MEGAHIT/SPAdes/Flye after assembly QC. Short-read modes require coordinate-sorted BAM files produced by mapping each library back to the exact same assembly, normally with Bowtie2 or Minimap2 followed by Samtools sort/index. Do not mix BAMs mapped to different contig FASTA versions. Remove or consistently retain short contigs according to the selected minimum length.

## Outputs and downstream

The final bin directory contains one FASTA per predicted genome; mapping tables and logs retain contig-to-bin provenance. Feed bins to CheckM2 and GUNC, then optionally dRep, GTDB-Tk and Bakta. Feed SemiBin2's contig-to-bin assignment to DAS Tool when combining independent binners.

## Parameters and decision rules

| Command/option | Meaning and setting rule |
| --- | --- |
| `SemiBin2 single_easy_bin` | Preferred integrated workflow for one sample or one co-assembly. |
| `SemiBin2 multi_easy_bin` | Use for multiple sample assemblies/coverage profiles; keep input ordering and labels explicit. |
| `-i`, `--input-fasta` | Assembly FASTA; headers must match every BAM reference name. |
| `-b`, `--input-bam` | One or more sorted BAMs for short-read abundance; do not provide long-read mappings as a silent substitute. |
| `-o`, `--output` | Dedicated output directory; never merge unrelated runs. |
| `--environment` | Select a matching pretrained/semi-supervised habitat. Prefer local model/reference assets; any missing asset requires a registered, marked acquisition proposal rather than an implicit first-run download. |
| `--sequencing-type long_read` | Enable long-read behavior for HiFi/ONT assemblies; confirm support in the pinned version. |
| `--threads` | CPU allowance for feature generation, training and reclustering. |
| `--minfasta-kbs` | Minimum total bin size; lower only for expected tiny genomes and document the rationale. |
| `--compression` | Compression used for emitted bin FASTA files; downstream suffix handling must agree. |
| `--random-seed` | Pin for repeatable model training and comparisons. |
| `--no-recluster` | Disable reclustering only for diagnosis or a controlled comparison; default reclustering often improves bins. |
| training subcommands | Use self-supervised/semi-supervised custom training only when easy mode or pretrained models do not fit the habitat. |

## Workflow patterns

```bash
conda run -n biomni-semibin2 --no-capture-output SemiBin2 single_easy_bin \
  -i assembly.fa -b sample.sorted.bam -o semibin2_out \
  --threads 16 --random-seed 42

conda run -n biomni-semibin2 --no-capture-output SemiBin2 single_easy_bin \
  -i longread_assembly.fa -o semibin2_long --sequencing-type long_read --threads 16
```

## Validation and failure handling

Require non-empty bins, unique contig assignment within a result, valid FASTA, recorded excluded contigs, and complete logs. Empty output commonly means contigs are too short, BAM/reference names disagree, coverage is missing, or the wrong sequencing mode was selected. CUDA or memory failure should trigger a documented CPU/lower-resource retry, not changed biological thresholds without approval.
