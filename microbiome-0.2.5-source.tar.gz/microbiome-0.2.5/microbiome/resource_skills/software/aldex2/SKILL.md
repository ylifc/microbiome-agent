---
name: ALDEx2
description: Compositional differential abundance / 组成数据差异分析
kind: software
id: aldex2
version: 3
selection_tier: conditional
documentation_status: DOCUMENTED
software_family: aldex2
environment: microbiome-aldex2
executables:
- Rscript
packages:
- bioconductor-aldex2
channels:
- conda-forge
- bioconda
tasks:
- Compositional differential abundance / 组成数据差异分析
databases: []
aliases:
- ALDEx2
- aldex2
keywords:
- aldex2
- Compositional differential abundance / 组成数据差异分析
capabilities:
- Compositional differential abundance / 组成数据差异分析
inputs:
- feature-by-sample nonnegative integer counts
- aligned condition vector or supported design
outputs:
- effect sizes
- test statistics and adjusted probabilities
upstream:
- phyloseq
- dada2
downstream: []
parameter_guidance:
- 'aldex.clr(mc.samples, denom): freeze Monte Carlo count, random seed and denominator choice.'
- 'aldex.ttest(paired.test): paired design requires correctly ordered matched subjects.'
- 'aldex.effect: retain effect size and within-group variability, not only significance.'
validation:
- Validate version and required package/functions before use.
- Run the task on representative data and require output assertions.
failure_handling:
- Do not pass already log-transformed values or choose denominator after seeing significance.
- Consult version-matched Knowledge history; repair only in an approved maintenance phase.
references:
- https://bioconductor.org/packages/release/bioc/html/ALDEx2.html
runtime:
  kind: r_package
  package: ALDEx2
  functions:
  - aldex.clr
  - aldex.ttest
  - aldex.effect
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# ALDEx2

## Capabilities and selection

Compositional differential abundance / 组成数据差异分析.
Select this capability only when its input and statistical assumptions match the study.
Catalog documentation does not assert that this software is installed or task-validated.

## Inputs and upstream

- feature-by-sample nonnegative integer counts
- aligned condition vector or supported design

Keep sample identifiers, feature identifiers, orientation, units and reference releases explicit.
Reject missing inputs rather than acquiring substitutes during analysis.

## Outputs and downstream

- effect sizes
- test statistics and adjusted probabilities

Save the complete invocation, output schema, software version and database fingerprints.
Do not overwrite raw data, reference resources or outputs from a different run.

## Parameters and decision rules

- aldex.clr(mc.samples, denom): freeze Monte Carlo count, random seed and denominator choice.
- aldex.ttest(paired.test): paired design requires correctly ordered matched subjects.
- aldex.effect: retain effect size and within-group variability, not only significance.

The reference below is the full manual source. This catalog covers the supported task decisions;
option availability and defaults must be checked against the installed version and captured help.
Unknown values must not be guessed. Package functions are verified independently of R/Python.

## Workflow patterns

The following is a discovery probe, not a successful analysis recipe:

```bash
conda run -n microbiome-aldex2 --no-capture-output Rscript --vanilla -e 'library(ALDEx2); packageVersion("ALDEx2")'
```

Resolve the actual environment prefix first. During production replay the frozen argv and paths.
R/Python workflows require a reviewed adapter with explicit parameters and output assertions.

## Validation and failure handling

Correct: use aligned input IDs, the approved method, compatible reference resources and validated outputs.
Incorrect: Do not pass already log-transformed values or choose denominator after seeing significance.
A zero exit code without output validation is unverified history.
On failure record the complete command, exit code, stderr, version, input and database context.
Promote a repair only after a matching regression validation report passes.

## References and documentation coverage

- Official source: https://bioconductor.org/packages/release/bioc/html/ALDEx2.html
- Documentation reviewed for catalog integration; this is not a local runtime acceptance claim.
- Parameter coverage: curated task guidance; full version-specific help is captured on discovery.
