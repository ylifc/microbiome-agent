---
name: Panaroo
description: Error-aware bacterial pangenome analysis from consistently annotated GFF3 genomes.
kind: software
id: panaroo
version: 2
selection_tier: default
environment: biomni-panaroo
executables:
- panaroo
- panaroo-qc
- panaroo-merge
packages:
- panaroo
channels:
- conda-forge
- bioconda
tasks:
- bacterial pangenome analysis
- gene presence absence
- core gene alignment
- annotation QC
databases: []
aliases:
- Panaroo
- pangenome pipeline
- 泛基因组
keywords:
- pangenome
- core genes
- accessory genes
- GFF3
- gene presence absence
- paralog
- bacterial genomes
capabilities:
- cluster homologous bacterial genes
- correct annotation fragmentation errors
- infer core/accessory genome
- generate core alignments
inputs:
- one GFF3 per quality-controlled bacterial genome produced by one compatible annotation pipeline
outputs:
- gene_presence_absence.csv
- presence/absence Rtab
- pangenome graph
- gene FASTA files
- core or pan alignment and QC summaries
upstream:
- bakta
- quast
- skani
downstream:
- mafft
- iqtree2
software_family: panaroo
documentation_status: CURATED_PROSE
upstream_tasks:
- prokka
parameter_guidance:
- '| `-i` / `-o` | Input GFF list/glob and new output directory. |'
- '| `--clean-mode strict|moderate|sensitive` | Error correction tradeoff; strict for high-quality coherent cohorts, sensitive
  for exploratory diversity. |'
- '| `--alignment core|pan` | Generate requested alignment; pan alignment is substantially larger. |'
- '| `--core_threshold` | Fraction of isolates defining core; set with missingness/QC policy and report it. |'
- '| `--family_threshold` | Protein family identity threshold; changing it alters gene-family definitions. |'
- '| `--len_dif_percent` | Length-difference tolerance used in family/error decisions. |'
- '| `--merge_paralogs` | Controls paralog treatment; avoid merging biologically distinct copies without review. |'
- '| `--remove-invalid-genes` | Exclude malformed genes while recording sample/feature impact. |'
- '| `--aligner` | MAFFT or supported aligner; use the declared aligner version. |'
- '| `--codons` | Codon-aware nucleotide alignment where supported; requires valid CDS/frame. |'
- '| `--core_entropy_filter` | Filter problematic core alignment columns only with disclosed threshold. |'
- '| `-t` | Threads. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# Panaroo

Use Panaroo as the default bacterial pangenome tool. Consistent annotation and cohort quality matter more than adding multiple competing pangenome algorithms.

## Capabilities and selection

Panaroo clusters genes while repairing common annotation fragmentation/contamination artifacts and handling paralogs. It is appropriate for related bacteria with compatible GFF3 annotations. It is not a general metagenomic gene catalog or a substitute for orthology validation across distant taxa.

## Inputs and upstream

All genomes should pass QUAST/contamination checks, belong to a defensible cohort, and be annotated with the same Prokka version/settings (Panaroo expects Prokka-format GFF3). If Bakta is used, validate compatibility with the selected Panaroo release first. A conversion requires a separately reviewed adapter and format tests; this repository does not provide a generic Bakta-to-Prokka converter. Confirm that each GFF3 contains or is associated with the nucleotide sequence format Panaroo expects. Stable sample IDs must not contain ambiguous separators.

## Outputs and downstream

Core outputs include `gene_presence_absence.csv`, `gene_presence_absence.Rtab`, `final_graph.gml`, pan-genome reference/representative FASTA, and optional core/pan alignments. These support core phylogeny, accessory association, visualization, and selected-gene analyses. Presence does not by itself prove expression or phenotype.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `-i` / `-o` | Input GFF list/glob and new output directory. |
| `--clean-mode strict|moderate|sensitive` | Error correction tradeoff; strict for high-quality coherent cohorts, sensitive for exploratory diversity. |
| `--alignment core|pan` | Generate requested alignment; pan alignment is substantially larger. |
| `--core_threshold` | Fraction of isolates defining core; set with missingness/QC policy and report it. |
| `--family_threshold` | Protein family identity threshold; changing it alters gene-family definitions. |
| `--len_dif_percent` | Length-difference tolerance used in family/error decisions. |
| `--merge_paralogs` | Controls paralog treatment; avoid merging biologically distinct copies without review. |
| `--remove-invalid-genes` | Exclude malformed genes while recording sample/feature impact. |
| `--aligner` | MAFFT or supported aligner; use the declared aligner version. |
| `--codons` | Codon-aware nucleotide alignment where supported; requires valid CDS/frame. |
| `--core_entropy_filter` | Filter problematic core alignment columns only with disclosed threshold. |
| `-t` | Threads. |

## Workflow patterns

```bash
conda run -n biomni-panaroo --no-capture-output panaroo \
  -i annotations/*.gff3 -o panaroo_out --clean-mode strict \
  --alignment core --core_threshold 0.95 -t 16
```

## Validation and failure handling

Require all intended samples in outputs, plausible gene counts/core fraction, no sample-ID collision, valid graph/tables, non-empty alignment when requested, and outlier QC review. Very small core or extreme singleton counts indicate distant/contaminated genomes, annotation-version differences, fragmentation, or threshold mismatch. Fix cohort/annotation problems before relaxing clustering thresholds.

Confirm every input GFF contributes exactly one named genome and preserve Panaroo's cleaned gene identifiers when joining annotations or traits downstream.
