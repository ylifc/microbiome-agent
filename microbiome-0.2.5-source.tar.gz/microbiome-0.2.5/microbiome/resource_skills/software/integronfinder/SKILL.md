---
name: IntegronFinder
description: Detects complete integrons, In0 elements, and CALIN cassette arrays in DNA sequences.
kind: software
id: integronfinder
version: 2
selection_tier: conditional
environment: biomni-integronfinder
executables:
- integron_finder
packages:
- integron_finder
channels:
- conda-forge
- bioconda
tasks:
- integron detection
- gene cassette detection
- antimicrobial resistance context analysis
databases: []
aliases:
- IntegronFinder
- integron_finder
- 整合子检测
- 基因盒检测
keywords:
- integron
- integrase
- attC
- gene cassette
- CALIN
- In0
- mobile genetic element
capabilities:
- detect integrase and attC components
- classify complete/incomplete integron structures
- annotate cassette arrays and optional functional context
inputs:
- nucleotide FASTA or supported annotated sequence records
outputs:
- integron summary tables
- element and gene tables
- sequence/GenBank outputs
- optional PDF diagrams
upstream:
- spades
- flye
- unicycler
- mob-suite
- bakta
downstream:
- amrfinderplus
software_family: integronfinder
documentation_status: CURATED_PROSE
downstream_tasks:
- mobile element curation
- comparative genomics
parameter_guidance:
- '| Command/option | Meaning and setting rule |'
- '| positional sequence file | Input nucleotide FASTA/record; run one logical sample per output namespace. |'
- '| `--outdir` | Dedicated output root. |'
- '| `--cpu` | CPU allocation for HMM and attC searches. |'
- '| `--local-max` | Search locally around detected components for additional attC sites; useful for sensitivity. |'
- '| `--func-annot` | Add functional annotation of cassette proteins; increases dependencies/runtime. |'
- '| `--promoter-attI` | Search supported promoter/attI features for detailed regulatory context. |'
- '| `--calin-threshold` | Minimum attC count for CALIN classification; lowering increases isolated-site false positives.
  |'
- '| `--eagle-eyes` | More exhaustive attC search mode when sensitivity is prioritized and candidates will be reviewed. |'
- '| `--gbk` | Emit GenBank representation for coordinate-aware inspection. |'
- '| `--pdf` | Generate element diagrams when supported; not needed for batch-only tables. |'
- '| `--keep-tmp` | Retain intermediates only for debugging/reproducibility audits. |'
- When scanning MOB-suite plasmid partitions, preserve original assembly contig IDs and offsets so integron/AMR coordinates
  can be joined without guesswork.
- For batch studies, normalize summary schemas across samples and retain complete, In0 and CALIN classifications as separate
  columns rather than one binary integron flag.
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# IntegronFinder

Use IntegronFinder to detect integron structures and cassette arrays in isolate assemblies, plasmids or selected contigs. It complements AMRFinderPlus: one locates mobile-element architecture while the other identifies resistance genes.

## Capabilities and selection

IntegronFinder combines integrase protein detection and attC-site models to classify complete integrons, integrase-only `In0`, and CALIN arrays lacking a nearby integrase. Local attC detection can recover elements missed by a strict global scan but costs more and can increase questionable candidates.

## Inputs and upstream

Provide nucleotide sequence with unique, simple identifiers. Whole assemblies, MOB-suite plasmid/chromosome partitions or targeted regions are valid, but preserve original contig mapping. Fragmented contigs can split an integron and should be flagged at sequence boundaries.

## Outputs and downstream

Retain summary/integron tables, detailed element coordinates, logs, and optional GenBank/PDF outputs. Intersect cassette coordinates with AMRFinderPlus/Bakta annotations using consistent coordinate systems. Complete integrons, In0 and CALIN are distinct evidence classes and must remain distinguishable downstream.

## Parameters and decision rules

| Command/option | Meaning and setting rule |
| --- | --- |
| positional sequence file | Input nucleotide FASTA/record; run one logical sample per output namespace. |
| `--outdir` | Dedicated output root. |
| `--cpu` | CPU allocation for HMM and attC searches. |
| `--local-max` | Search locally around detected components for additional attC sites; useful for sensitivity. |
| `--func-annot` | Add functional annotation of cassette proteins; increases dependencies/runtime. |
| `--promoter-attI` | Search supported promoter/attI features for detailed regulatory context. |
| `--calin-threshold` | Minimum attC count for CALIN classification; lowering increases isolated-site false positives. |
| `--eagle-eyes` | More exhaustive attC search mode when sensitivity is prioritized and candidates will be reviewed. |
| `--gbk` | Emit GenBank representation for coordinate-aware inspection. |
| `--pdf` | Generate element diagrams when supported; not needed for batch-only tables. |
| `--keep-tmp` | Retain intermediates only for debugging/reproducibility audits. |

When scanning MOB-suite plasmid partitions, preserve original assembly contig IDs and offsets so integron/AMR coordinates can be joined without guesswork.

For batch studies, normalize summary schemas across samples and retain complete, In0 and CALIN classifications as separate columns rather than one binary integron flag.

## Workflow patterns

```bash
conda run -n biomni-integronfinder --no-capture-output integron_finder assembly.fa \
  --outdir integronfinder_out --cpu 8 --local-max --func-annot --gbk
```

## Validation and failure handling

Require successful scan of every sequence, valid coordinates within contig bounds, and consistent element classification. No integron call is credible only after confirming nucleotide input and completed HMM/attC searches. Boundary-truncated elements and CALIN calls require cautious interpretation; preserve temporary files when diagnosing model or dependency failures.
