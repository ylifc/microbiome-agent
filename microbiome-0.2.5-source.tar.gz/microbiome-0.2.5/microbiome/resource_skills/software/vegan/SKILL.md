---
name: vegan
description: Community ecology, diversity and ordination / 多样性与生态统计
kind: software
id: vegan
version: 3
selection_tier: conditional
documentation_status: DOCUMENTED
software_family: vegan
environment: microbiome-vegan
executables:
- Rscript
packages:
- r-vegan
channels:
- conda-forge
- bioconda
tasks:
- Community ecology, diversity and ordination / 多样性与生态统计
databases: []
aliases:
- vegan
- vegan
keywords:
- vegan
- Community ecology, diversity and ordination / 多样性与生态统计
capabilities:
- Community ecology, diversity and ordination / 多样性与生态统计
inputs:
- sample-by-feature matrix
- metadata and explicit permutation design
outputs:
- distance matrix
- ordination coordinates
- PERMANOVA and dispersion results
upstream:
- phyloseq
downstream: []
parameter_guidance:
- 'vegdist(method): choose the distance for the measurement scale.'
- 'adonis2(permutations, by): freeze seed, permutation count, test type and any restricted exchangeability design.'
- 'betadisper: inspect group dispersion alongside location tests.'
validation:
- Validate version and required package/functions before use.
- Run the task on representative data and require output assertions.
failure_handling:
- Do not treat technical replicates as independent or interpret PERMANOVA without checking dispersion.
- Consult version-matched Knowledge history; repair only in an approved maintenance phase.
references:
- https://vegandevs.github.io/vegan/
runtime:
  kind: r_package
  package: vegan
  functions:
  - vegdist
  - adonis2
  - betadisper
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# vegan

## Capabilities and selection

Community ecology, diversity and ordination / 多样性与生态统计.
Select this capability only when its input and statistical assumptions match the study.
Catalog documentation does not assert that this software is installed or task-validated.

## Inputs and upstream

- sample-by-feature matrix
- metadata and explicit permutation design

Keep sample identifiers, feature identifiers, orientation, units and reference releases explicit.
Reject missing inputs rather than acquiring substitutes during analysis.

## Outputs and downstream

- distance matrix
- ordination coordinates
- PERMANOVA and dispersion results

Save the complete invocation, output schema, software version and database fingerprints.
Do not overwrite raw data, reference resources or outputs from a different run.

## Parameters and decision rules

- vegdist(method): choose the distance for the measurement scale.
- adonis2(permutations, by): freeze seed, permutation count, test type and any restricted exchangeability design.
- betadisper: inspect group dispersion alongside location tests.

The reference below is the full manual source. This catalog covers the supported task decisions;
option availability and defaults must be checked against the installed version and captured help.
Unknown values must not be guessed. Package functions are verified independently of R/Python.

## Workflow patterns

The following is a discovery probe, not a successful analysis recipe:

```bash
conda run -n microbiome-vegan --no-capture-output Rscript --vanilla -e 'library(vegan); packageVersion("vegan")'
```

Resolve the actual environment prefix first. During production replay the frozen argv and paths.
R/Python workflows require a reviewed adapter with explicit parameters and output assertions.

## Validation and failure handling

Correct: use aligned input IDs, the approved method, compatible reference resources and validated outputs.
Incorrect: Do not treat technical replicates as independent or interpret PERMANOVA without checking dispersion.
A zero exit code without output validation is unverified history.
On failure record the complete command, exit code, stderr, version, input and database context.
Promote a repair only after a matching regression validation report passes.

## References and documentation coverage

- Official source: https://vegandevs.github.io/vegan/
- Documentation reviewed for catalog integration; this is not a local runtime acceptance claim.
- Parameter coverage: curated task guidance; full version-specific help is captured on discovery.
