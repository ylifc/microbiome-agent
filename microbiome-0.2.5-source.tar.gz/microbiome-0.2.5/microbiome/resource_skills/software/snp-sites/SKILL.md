---
name: SNP-sites
description: Extract polymorphic positions, VCF, or SNP alignments from nucleotide multiple-sequence alignments.
kind: software
id: snp-sites
version: 2
selection_tier: default
environment: biomni-snp-sites
executables:
- snp-sites
packages:
- snp-sites
channels:
- conda-forge
- bioconda
tasks:
- SNP alignment extraction
- alignment to VCF conversion
- ascertainment-aware phylogeny preparation
databases: []
aliases:
- SNP-sites
- SNP site extractor
- SNP位点提取
keywords:
- polymorphic sites
- FASTA alignment
- VCF
- PHYLIP
- invariant sites
- ascertainment bias
capabilities:
- extract variable columns from nucleotide alignment
- emit FASTA PHYLIP or VCF
- optionally retain constant columns
inputs:
- equal-length nucleotide multi-FASTA alignment
outputs:
- SNP-only or constant-inclusive FASTA/PHYLIP alignment
- VCF representation
- summary on retained sites
upstream:
- snippy
- gubbins
- mafft
downstream:
- snp-dists
- iqtree2
- iqtree3
software_family: snp-sites
documentation_status: CURATED_PROSE
parameter_guidance:
- '| `-o` | Output path; otherwise output is stdout and must be redirected safely. |'
- '| `-v` | VCF output; confirm reference/sample coordinate interpretation. |'
- '| `-p` | PHYLIP output for software requiring that format. |'
- '| default FASTA mode | Emit SNP-site FASTA when no alternate format is selected. |'
- '| `-m` | Emit multi-FASTA SNP alignment; this is the default output mode. |'
- '| `-c` | Retain only variable columns containing exclusively A/C/G/T in every sequence, excluding gaps and ambiguity. |'
- '| `-b` | Include monomorphic sites, intended for workflows such as BEAST that need invariant positions. |'
- '| `-r` | Emit the internal pseudo-reference sequence used for VCF coordinate/reference interpretation. |'
- '| `-V` / `-h` | Print version/help and pin behavior in provenance. |'
parameter_coverage:
  level: curated_task_guidance
  source: SKILL.md
  requires_installed_version_help: true
---

# SNP-sites

Use SNP-sites as a format-aware transformation node. It does not call variants from reads and does not correct recombination or alignment error.

## Capabilities and selection

SNP-sites identifies variable columns in a nucleotide alignment and writes common tree/variant formats. It is valuable after Snippy/Gubbins when a SNP-only matrix is explicitly required. For ordinary substitution models, retain full alignments or provide constant-site counts/ascertainment correction.

## Inputs and upstream

Input must be a true equal-length homologous nucleotide alignment, not unaligned genome FASTA. Headers must be unique and sample names stable. Resolve gaps, Ns, masks, recombination regions, and duplicate sequences before extraction.

## Outputs and downstream

Output is a reduced alignment or VCF whose coordinates correspond to alignment columns/reference interpretation. SNP-only output feeds distance calculations or IQ-TREE models with ascertainment-bias handling. Preserve the full input alignment and a count of constant A/C/G/T sites.

## Parameters and decision rules

| Option | Meaning and setting rule |
| --- | --- |
| `-o` | Output path; otherwise output is stdout and must be redirected safely. |
| `-v` | VCF output; confirm reference/sample coordinate interpretation. |
| `-p` | PHYLIP output for software requiring that format. |
| default FASTA mode | Emit SNP-site FASTA when no alternate format is selected. |
| `-m` | Emit multi-FASTA SNP alignment; this is the default output mode. |
| `-c` | Retain only variable columns containing exclusively A/C/G/T in every sequence, excluding gaps and ambiguity. |
| `-b` | Include monomorphic sites, intended for workflows such as BEAST that need invariant positions. |
| `-r` | Emit the internal pseudo-reference sequence used for VCF coordinate/reference interpretation. |
| `-V` / `-h` | Print version/help and pin behavior in provenance. |

## Workflow patterns

```bash
conda run -n biomni-snp-sites --no-capture-output snp-sites -o core.snps.fasta core.filtered.full.aln
conda run -n biomni-snp-sites --no-capture-output snp-sites -v -o core.snps.vcf core.filtered.full.aln
```

When building a tree from `core.snps.fasta`, explicitly use an IQ-TREE ascertainment-bias model or verified constant-site counts.

Do not combine `-c` with a missing-data analysis unless excluding every ambiguous column is the intended callable-core definition.

For VCF output, archive the pseudo-reference and original alignment because alignment-column coordinates are not automatically equivalent to an external genome coordinate system.

## Validation and failure handling

Require equal sequence lengths, stable sample count/order, nonzero sites where expected, valid FASTA/PHYLIP/VCF, and recorded full-versus-variable site counts. Zero SNPs may be biologically valid or indicate masking/format failure. Unequal-length errors mean the input is not a valid multiple alignment and must be fixed upstream.
