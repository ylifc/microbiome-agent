"""Cross-process filesystem locks for shared database maintenance."""

from __future__ import annotations

import fcntl
import os
import re
import time
from contextlib import contextmanager
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Iterator


@contextmanager
def resource_lock(
    database_root: str | Path,
    resource_id: str,
    *,
    timeout_seconds: float = 3600,
    poll_seconds: float = 0.1,
) -> Iterator[Path]:
    """Serialize download/index/registry mutation for one resource ID."""
    safe_id = re.sub(r"[^A-Za-z0-9_.-]+", "-", resource_id).strip("-.")
    if not safe_id:
        raise ValueError("resource_id does not contain a safe lock name")
    lock_root = Path(database_root).expanduser().resolve() / ".locks"
    lock_root.mkdir(parents=True, exist_ok=True)
    lock_path = lock_root / f"{safe_id}.lock"
    descriptor = os.open(lock_path, os.O_RDWR | os.O_CREAT, 0o644)
    started = time.monotonic()
    try:
        while True:
            try:
                fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError as exc:
                if time.monotonic() - started >= timeout_seconds:
                    raise TimeoutError(f"timed out waiting for database resource lock: {lock_path}") from exc
                time.sleep(max(0.01, poll_seconds))
        os.ftruncate(descriptor, 0)
        os.write(descriptor, f"pid={os.getpid()} acquired={time.time()}\n".encode("ascii"))
        os.fsync(descriptor)
        yield lock_path
    finally:
        try:
            fcntl.flock(descriptor, fcntl.LOCK_UN)
        finally:
            os.close(descriptor)
