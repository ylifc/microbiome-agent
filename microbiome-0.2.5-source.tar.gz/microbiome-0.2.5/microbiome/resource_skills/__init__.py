"""Extensible local software and database skill registry."""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .acquisition import (
        DatabaseAcquisitionPreview,
        DatabaseAcquisitionResult,
        DatabaseAcquisitionRunner,
    )
from .registry import (
    ResourceSkill,
    ResourceSkillRegistry,
    ResourceStatus,
    SkillValidationError,
    add_database_skill,
    add_software_skill,
    compare_database_options,
    get_resource_skill_details,
    list_resource_skills,
    plan_database_acquisition,
    render_environment_create_command,
    render_software_command,
)
from .resolver import (
    CondaEnvironmentManager,
    DatabaseSkillBuilder,
    PersistentDatabaseResolver,
    ResourceBootstrapManager,
    SoftwareSkillBuilder,
    ToolAliasRegistry,
    ToolBinding,
    ToolResolver,
)

__all__ = [
    "DatabaseAcquisitionPreview",
    "DatabaseAcquisitionResult",
    "DatabaseAcquisitionRunner",
    "CondaEnvironmentManager",
    "DatabaseSkillBuilder",
    "PersistentDatabaseResolver",
    "ResourceBootstrapManager",
    "ResourceSkill",
    "ResourceSkillRegistry",
    "ResourceStatus",
    "SkillValidationError",
    "SoftwareSkillBuilder",
    "ToolAliasRegistry",
    "ToolBinding",
    "ToolResolver",
    "add_database_skill",
    "add_software_skill",
    "compare_database_options",
    "get_resource_skill_details",
    "list_resource_skills",
    "plan_database_acquisition",
    "render_environment_create_command",
    "render_software_command",
]


def __getattr__(name: str):
    """Keep acquisition exports lazy so ``python -m ...acquisition`` runs once."""
    if name in {
        "DatabaseAcquisitionPreview",
        "DatabaseAcquisitionResult",
        "DatabaseAcquisitionRunner",
    }:
        from . import acquisition

        return getattr(acquisition, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
