---
name: Bakta database
description: Versioned reference sequences, HMMs, expert rules, and annotation metadata required by Bakta.
kind: database
id: bakta
version: 5
folder: bakta
required_markers: [db-light/version.json, db-light/bakta.db, db-light/antifam.h3f, db-light/antifam.h3i, db-light/antifam.h3m, db-light/antifam.h3p, db-light/expert-protein-sequences.dmnd, db-light/ncRNA-genes.i1f, db-light/ncRNA-genes.i1i, db-light/ncRNA-genes.i1m, db-light/ncRNA-genes.i1p, db-light/ncRNA-regions.i1f, db-light/ncRNA-regions.i1i, db-light/ncRNA-regions.i1m, db-light/ncRNA-regions.i1p, db-light/oric.fna, db-light/orit.fna, db-light/pfam.h3f, db-light/pfam.h3i, db-light/pfam.h3m, db-light/pfam.h3p, db-light/rfam-go.tsv, db-light/rRNA.i1f, db-light/rRNA.i1i, db-light/rRNA.i1m, db-light/rRNA.i1p, db-light/sorf.dmnd, db-light/pscc.dmnd, db-light/amrfinderplus-db/latest/version.txt, db-light/amrfinderplus-db/latest/database_format_version.txt, db-light/amrfinderplus-db/latest/AMRProt.fa, db-light/amrfinderplus-db/latest/AMR.LIB]
raw_markers: [db-light*.tar.xz, db*.tar.xz]
compatible_software: [bakta]
advantages: [integrated bacterial annotation records HMMs and expert rules, full and light database choices, strong Bakta schema compatibility]
limitations: [bacterial scope, full database costs more disk and runtime, major database and software versions must be compatible]
estimated_size: "Bakta DB v6.0 light is 1,344,199,496 bytes compressed and about 3.9 GB extracted; full is about 30 GB compressed and 84 GB extracted."
acquisition_mode: automatic
acquisition_commands:
  - "python -m microbiome.resource_skills.acquisition download --url https://zenodo.org/records/14916843/files/db-light.tar.xz --fallback-url https://s3.computational.bio.uni-giessen.de/bakta-db/db-light-v6.0.tar.xz --output Database/bakta/db-light.tar.xz --expected-size 1344199496 --checksum md5:4a6e059ded39e9c5537ef4137d2f5648 --retries 30 --direct"
aliases: [Bakta DB, bacterial annotation database, 细菌注释数据库]
keywords: [annotation, bacterial proteins, HMM, AMR, expert system, Bakta, 注释]
contents: [Bakta SQLite annotation records, protein sequence indexes and HMMs, expert systems and version metadata]
formats: [versioned full or light Bakta database directory with version.json and bakta.db]
consumers: [bakta]
update_policy: Keep each compatible major and minor database release separate; do not update a database used by an active analysis in place.
license_notes: Bakta database component licenses and citation guidance apply; inspect the official manifest.
download_urls:
  - https://github.com/oschwengers/bakta#database
  - https://zenodo.org/records/14916843/files/db-light.tar.xz
  - https://s3.computational.bio.uni-giessen.de/bakta-db/db-light-v6.0.tar.xz
localization_commands:
  - "python -m microbiome.resource_skills.acquisition localize --database bakta --db-root Database"
---

# Bakta database

## Scope and biological meaning

The Bakta database supplies reference sequences, annotation records, HMMs, AMR/expert-system assets, and metadata needed for bacterial genome annotation. A READY executable without this database cannot perform a valid Bakta analysis. The `light` type uses a reduced sequence collection and disk footprint; `full` provides broader reference coverage at greater storage and search cost.

## Directory and readiness contract

Store this resource only under `Database/bakta/`. The current skill expects a prepared light database at `Database/bakta/db-light/` containing every file required by Bakta 1.12's database checker: version metadata, SQLite records, all HMM/covariance-model indexes, DIAMOND assets, origin sequences, `pscc.dmnd`, and a complete AMRFinderPlus release. The registry checks these concrete files rather than accepting a merely existing directory. If a full database is selected, update the skill markers/path deliberately instead of renaming it to `db-light`.

## Acquisition and localization

Planning compares Bakta light/full scope, size and compatibility. The registered v6.0 light path bypasses proxy variables for this public transfer, uses Zenodo as the primary source and Bakta's official Giessen object-store backup as a mirror, and resumes `Database/bakta/db-light.tar.xz.part` with HTTP Range requests. When `aria2c` is available its `.aria2` control file tracks non-contiguous pieces; that sparse file must never be resumed by a contiguous-only downloader. The helper verifies the exact 1,344,199,496-byte size and official MD5 and atomically publishes `db-light.tar.xz`. The localizer then safely extracts the verified archive. It reuses the pinned READY release under `Database/amrfinderplus/latest` when available; only when that local dependency is absent does it run `amrfinder_update` without proxy variables. A failed transfer retains both resume files for the next confirmed retry. A different type or release requires its own exact URL, size, checksum, and revised confirmed command; `bakta_db list` verifies software-compatible releases.

## Software consumers and parameter coupling

Bakta receives the prepared path through `--db Database/bakta/db-light` or an equivalent registry-resolved path. Software/database major compatibility and schema version must be checked. Full versus light choice affects annotation coverage, disk, and runtime and must be recorded.

## Workflow inputs and outputs

The database consumes no biological sample input. It converts an official release tarball into an indexed directory consumed by Bakta. Bakta outputs GFF3, GenBank, JSON, TSV, FAA, and FFN; those outputs must record database type/version from `version.json`.

## Versioning, provenance, and updates

Record database major/minor/type, source URL, acquisition date, tarball checksum, install command, Bakta version, and directory checksum/size. Prepare a new version beside the old one, validate on a known genome, then update the skill marker/path. Never mutate the database during a running analysis.

## Validation and failure handling

Require parseable `version.json`, every file listed in the readiness contract, readable permissions, a working pinned AMRFinderPlus release, and `bakta --db ...` compatibility. A schema/version error means software/database mismatch. A directory that merely exists is not READY. Interrupted download resumes the `.part` file; interrupted extraction reruns the safe localizer from the verified local tarball without reacquiring it.
