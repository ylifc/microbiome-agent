---
name: CheckM reference data
description: Marker genes, taxonomy, and placement data used by CheckM.
kind: database
id: checkm
version: 2
folder: checkm
required_markers: [hmms/checkm.hmm, taxon_marker_sets.tsv]
raw_markers: [checkm_data_*.tar.gz]
compatible_software: [checkm]
advantages: [lineage-specific marker interpretation, established completeness and contamination estimates, directly supports historical CheckM workflows]
limitations: [reference release is old and biased for novel lineages, bacterial and archaeal scope only, pplacer assets increase size and memory]
estimated_size: "About 1-2 GB compressed and several GB extracted for the 2015 release."
acquisition_mode: automatic
acquisition_commands: ["python -c \"from microbiome.tool.microbial_databases import download_database; print(download_database('checkm', out_dir='Database', env='microbiome'))\""]
aliases: [CheckM data, CheckM marker database, 完整度数据库]
keywords: [marker genes, lineage, taxonomy, pplacer, completeness, contamination, 完整度]
contents: [lineage marker HMMs, reference taxonomy and phylogeny, taxon marker sets and placement metadata]
formats: [HMM library, taxon marker TSV, reference tree and pplacer data]
consumers: [checkm]
update_policy: Keep the complete extracted release immutable and record its release date with every quality table.
license_notes: Follow the CheckM data provider terms and cite CheckM.
download_urls:
  - https://data.ace.uq.edu.au/public/CheckM_databases/checkm_data_2015_01_16.tar.gz
localization_commands:
  - "conda run -n microbiome checkm data setRoot Database/checkm"
---

# CheckM reference data

Keep the extracted CheckM hierarchy directly in `Database/checkm/`. Configure `CHECKM_DATA_PATH` or `checkm data setRoot` inside the CheckM skill environment.

## Scope and biological meaning

The CheckM reference data contains lineage-specific marker HMMs, taxonomic marker sets, reference trees/alignments, and pplacer assets used to estimate bacterial/archaeal completeness and contamination. Its lineage composition shapes the estimate; it is not appropriate for viruses and can be biased for lineages poorly represented by the historical reference set.

## Directory and readiness contract

The extracted hierarchy must live directly under `Database/checkm/` with non-empty `hmms/checkm.hmm`, `taxon_marker_sets.tsv`, and all companion phylogeny/taxonomy files. A partial HMM file without placement/reference assets is not usable. The currently declared release is the CheckM data dated 2015-01-16; record that age when interpreting novel lineages.

## Acquisition and localization

During separate preparation, place the official archive under `Database/checkm/` and extract the complete hierarchy. Run `conda run -n microbiome checkm data setRoot Database/checkm` or set `CHECKM_DATA_PATH` inside the isolated command, then `checkm data check`. The localization records a path; it must be repeated if the environment/configuration changes.

## Software consumers and parameter coupling

CheckM `lineage_wf` uses marker placement to choose a lineage set. `--reduced_tree`, manual taxonomy workflows, threshold/correction flags, and input gene/genome mode alter how this database is used. The database release must accompany completeness/contamination results supplied to dRep.

## Workflow inputs and outputs

The database consumes no sample files during preparation. During analysis CheckM combines it with bin FASTA to generate marker hits, lineage assignment, quality estimates, and diagnostics. Those quality tables feed dRep selection and MAG reporting; do not strip lineage/marker fields when transferring values.

## Versioning, provenance, and updates

Record source URL, release date, archive checksum, extraction layout, CheckM version, localization command, and `checkm data check` result. Keep alternative releases in separate versioned subdirectories and update the skill path deliberately. Re-evaluate representative bins before comparing estimates across releases.

## Validation and failure handling

Require all required markers plus complete pplacer/reference assets, readable files, successful data check, and a known-genome `lineage_wf` smoke test. Missing `.pkl`/tree/HMM components indicate incomplete extraction. A database found by environment config but outside `Database/checkm/` violates provenance and should be rebound, not silently used.
