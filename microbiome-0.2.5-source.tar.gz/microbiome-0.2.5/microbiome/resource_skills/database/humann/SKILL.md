---
name: HUMAnN functional profiling databases
description: Compatible ChocoPhlAn nucleotide, UniRef protein and utility-mapping databases for HUMAnN.
kind: database
id: humann
version: 2
folder: humann
required_markers: ["chocophlan/*.ffn.gz", "uniref/*.dmnd", "utility_mapping/*"]
raw_markers: ["*.tar.gz", "*.part", "*.tmp"]
compatible_software: [humann]
advantages: [species-aware nucleotide search, translated search for unmapped reads, standardized gene-family and pathway mapping]
limitations: [large storage and compute footprint, UniRef resolution affects interpretability and size, release compatibility changes output profiles]
estimated_size: "Tens of GB for ChocoPhlAn plus many tens of GB for UniRef and utility maps; disclose exact editions and free-space needs."
acquisition_mode: conditional
acquisition_commands: ["conda run -n microbiome-humann --no-capture-output humann_databases --download chocophlan full Database/humann", "conda run -n microbiome-humann --no-capture-output humann_databases --download uniref uniref90_diamond Database/humann", "conda run -n microbiome-humann --no-capture-output humann_databases --download utility_mapping full Database/humann"]
aliases: [HUMAnN DB, ChocoPhlAn, UniRef HUMAnN, 功能通路数据库]
keywords: [HUMAnN, ChocoPhlAn, UniRef, pathways, gene families, translated search]
contents: [pangenome nucleotide references, DIAMOND UniRef protein index, pathway and name mapping tables]
formats: [ChocoPhlAn compressed nucleotide families, UniRef DIAMOND index, utility mapping archives]
consumers: [humann]
update_policy: Pin ChocoPhlAn, UniRef resolution/release and utility-mapping release as one validated bundle.
license_notes: Preserve terms and citations for bioBakery, UniProt/UniRef and every redistributed mapping resource.
download_urls:
  - https://huttenhower.sph.harvard.edu/humann
  - https://github.com/biobakery/humann
localization_commands:
  - "Place the selected official nucleotide, protein and utility-mapping releases under Database/humann/chocophlan/, Database/humann/uniref/ and Database/humann/utility_mapping/; record archive checksums and extraction commands."

validation_contract:
  nonempty_globs:
  - chocophlan/*.ffn.gz
  - uniref/*.dmnd
  - utility_mapping/*
---

# HUMAnN databases

## Scope and biological meaning

The HUMAnN functional databases comprise compatible ChocoPhlAn nucleotide families, a UniRef protein DIAMOND index, and utility-mapping tables. They enable species-stratified gene-family and pathway profiling, and their releases must match the HUMAnN software version.

## Directory and readiness contract

READY requires non-empty `chocophlan/*.ffn.gz`, `uniref/*.dmnd`, and `utility_mapping/*.gz` under `Database/humann/`. A missing component blocks the corresponding search mode rather than silently degrading results.

## Acquisition and localization

ChocoPhlAn, UniRef and utility-mapping releases are downloaded manually from bioBakery/HUMAnN sources and placed under the documented subdirectories. Record archive checksums and extraction commands; obtain approval before transfer.

## Software consumers and parameter coupling

humann consumes ChocoPhlAn for nucleotide search, the UniRef `.dmnd` for translated search, and utility-mapping for pathway/name mapping. Pin them as one validated bundle.

## Workflow inputs and outputs

Input is quality-controlled shotgun FASTQ (with an optional MetaPhlAn profile for stratification); output is gene-family and pathway abundance/coverage tables. The databases stay read-only.

## Versioning, provenance, and updates

Record the ChocoPhlAn, UniRef resolution/release, and utility-mapping release together. Switching any one of them changes the profile; re-benchmark before adopting a new bundle.

## Validation and failure handling

Require all three components and matching software. A missing UniRef index or utility mapping produces empty or incomplete tables — check `humann_config` paths and the release bundle before trusting output.
