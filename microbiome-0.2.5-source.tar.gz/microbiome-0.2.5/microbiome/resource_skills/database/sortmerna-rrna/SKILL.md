---
name: SortMeRNA rRNA references
description: SortMeRNA rRNA references
kind: database
id: sortmerna-rrna
version: 3
folder: sortmerna-rrna
required_markers:
- release-manifest.yaml
compatible_software: &id001
- sortmerna
aliases:
- SortMeRNA rRNA references
keywords:
- sortmerna-rrna
- reference
contents:
- SortMeRNA rRNA references
formats:
- rRNA FASTA and version-compatible read-only indexes
consumers: *id001
advantages:
- Task-specific documented reference resource
limitations:
- Release and consumer compatibility must be validated before READY
estimated_size: Edition-dependent; exact archive, unpacked size and index workspace
  must be disclosed in the dependency plan.
acquisition_mode: manual
acquisition_commands: []
localization_commands: []
download_urls:
- https://github.com/sortmerna/sortmerna
update_policy: Immutable release per registered runtime entry; changes require maintenance
  and revalidation.
license_notes: Preserve the publisher terms, citations and provenance for each component.
documentation_status: DISCOVERY_ONLY

validation_contract:
  component_manifest: release-manifest.yaml
---

# SortMeRNA rRNA references

## Scope and biological meaning

SortMeRNA rRNA references; consumer: sortmerna.
Register the exact reference edition and scientific scope before planning analysis with it.

## Directory and readiness contract

Use one immutable release under the user-designated database root.
This discovery Skill has no fully resolved release contract yet.
The listed markers are discovery hints; a release manifest alone is not proof of a usable index.
Before READY, replace them in the approved resource specification with the full component list,
exact consumer entrypoint, release identifier, provenance and validated fingerprints.

## Acquisition and localization

Consult https://github.com/sortmerna/sortmerna for official release metadata and instructions.
Disclose exact URLs, checksums, storage, license and preparation commands before approval.
Do not execute a download or index build during production.
Reuse existing compatible READY resources; never replace them in place.

## Software consumers and parameter coupling

Bind the selected consumer to its exact runtime file, index prefix or directory.
Check the software release and all component versions together.
Record the consumer's lightweight validation result before READY registration.

## Workflow inputs and outputs

Formats: rRNA FASTA and version-compatible read-only indexes.
Raw downloads, prepared indexes and analysis outputs are different resource roles.

## Versioning, provenance, and updates

Store publisher, release, acquisition time, full checksums when available and index-builder version.
Keep versions separate and require a new dependency approval for resource changes.

## Validation and failure handling

Reject incomplete components, mixed releases and missing consumer entrypoints.
Record acquisition and validation failures in database Knowledge, preserving partial-download state.
A successful transfer alone is insufficient to register READY.
