---
name: QIIME 2 classifier
description: Pre-trained naive-bayes taxonomy classifier (.qza) for QIIME 2 feature classification of 16S/18S/ITS amplicons.
kind: database
id: qiime2
version: 2
folder: qiime2
required_markers: ["**/*.qza"]
common_markers: ["**/*.qza"]
consumer_markers:
  qiime2: ["**/*.qza"]
compatible_software: [qiime2]
advantages: [ready-to-use taxonomy classifier artifacts, region/version-matched SILVA and Greengenes2 options, integrates directly with qiime feature-classifier]
limitations: [classifier must match the amplicon region and read length, a mismatched classifier silently degrades accuracy, large .qza files need matching QIIME 2 versions]
estimated_size: "Tens to hundreds of MB per classifier."
acquisition_mode: conditional
acquisition_commands: ["Download an approved pre-trained classifier .qza (e.g. SILVA-138-99 or Greengenes2 full-length) from https://library.qiime2.org/data-resources (catalog) or the concrete hosts data.qiime2.org/classifiers/... / ftp.microbio.me into Database/qiime2/."]
aliases: [QIIME2 classifier, SILVA classifier, Greengenes classifier, 扩增子分类器]
keywords: [QIIME 2, classifier, naive-bayes, SILVA, Greengenes, taxonomy, 分类器]
contents: [pre-trained .qza classifier artifact]
formats: [one or more .qza files]
consumers: [qiime2]
update_policy: Keep classifiers in separate dated files; never overwrite a production classifier in place.
license_notes: Classifier redistribution terms follow the underlying reference (SILVA/UNITE/Greengenes); verify before commercial use.
---

# QIIME 2 classifier

## Scope and biological meaning

A QIIME 2 classifier is a pre-trained naive-bayes model (`.qza`) that assigns taxonomy to amplicon features. Its reference database (SILVA, Greengenes2, UNITE) and trained region/length define what it can classify and how accurately.

## Directory and readiness contract

READY requires one or more non-empty `.qza` files under `Database/qiime2/`. The classifier's trained region and reference version must match the study's amplicon (e.g., V3-V4 SILVA-138 for 16S V3-V4 reads). `microbiome.tool.db_inventory` auto-configures `QIIME2_CLASSIFIER` from the newest `.qza`.

## Acquisition and localization

Download an approved classifier from data.qiime2.org or ftp.microbio.me into `Database/qiime2/`. Acquisition is conditional: the download must be named in a confirmed plan. Record the classifier URL, reference version, and trained region.

## Software consumers and parameter coupling

Pass the `.qza` path to `amplicon_qiime2_pipeline(..., classifier=...)` or to `qiime feature-classifier classify-sklearn`. The classifier and the feature table must use the same QIIME 2 artifact format.

## Workflow inputs and outputs

Input is a QIIME 2 feature table/representative sequences; output is a taxonomy artifact (feature → taxon). Report the classifier identity so taxonomy is reproducible.

## Versioning, provenance, and updates

Record classifier filename, URL, reference release, region, and read-length expectations. A region mismatch is a common silent error — always verify the classifier region against the primers used.

## Validation and failure handling

Require a non-empty `.qza` that opens in the installed QIIME 2 version. A classifier/feature-region mismatch produces poor assignments without an error — cross-check a few known sequences or the expected taxa before trusting the table.
