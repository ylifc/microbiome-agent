---
name: CheckV database
description: Genome and HMM references for CheckV viral quality assessment.
kind: database
id: checkv
version: 2
folder: checkv
required_markers: ["checkv-db-v*/genome_db", "checkv-db-v*/hmm_db"]
raw_markers: []
compatible_software: [checkv]
advantages: [combines reference and HMM evidence for viral completeness and contamination, official versioned bundle, supports provirus boundary assessment]
limitations: [highly novel viruses can remain without completeness estimates, viral scope only, software and database release should be validated together]
estimated_size: "Several GB compressed and larger extracted; record the CheckV release and free disk."
acquisition_mode: automatic
acquisition_commands: ["conda run -n microbiome --no-capture-output checkv download_database Database/checkv"]
aliases: [CheckV DB, viral quality database, 病毒质量数据库]
keywords: [virus, completeness, contamination, HMM, genome reference, 病毒完整度]
contents: [viral reference genome database, viral protein HMM database, completeness and contamination model metadata]
formats: [versioned CheckV directory with genome_db and hmm_db indexes]
consumers: [checkv]
update_policy: Keep each CheckV database release in a separate versioned subdirectory and never mix index components.
license_notes: Follow CheckV database source terms and citations.
download_urls:
  - https://bitbucket.org/berkeleylab/checkv/src/master/
localization_commands:
  - "After placing the downloaded release under Database/checkv/, verify both genome_db and hmm_db directories; no additional index build is required."
---

# CheckV database

Each CheckV release remains in its own versioned directory below `Database/checkv/`. Pass that versioned directory to the CheckV skill.

## Scope and biological meaning

The CheckV database combines viral reference genomes, protein HMMs, and metadata used for reference-based completeness, gene-content completeness, host contamination boundaries, provirus analysis, and closed-genome evidence. Highly novel viruses may remain without an estimate; database absence of relatives is not biological incompleteness.

## Directory and readiness contract

Store each official release as a complete versioned directory such as `Database/checkv/checkv-db-v1.5/`. Both non-empty `genome_db` and `hmm_db` plus companion files are mandatory. Never merge indexes from different releases or point CheckV to the parent `Database/checkv/` when it expects the versioned child.

## Acquisition and localization

Planning reports CheckV source, release, size and placement. When the plan includes the acquisition marker, confirmation authorizes `checkv download_database Database/checkv`; otherwise it remains blocked. No additional index build is normally required. Pass the exact versioned child with `-d` or set `CHECKVDB` within the `conda run` process.

## Software consumers and parameter coupling

CheckV end-to-end and its contamination/completeness modules require this path. Conservative/aggressive trimming changes boundary calls, while database release affects reference/HMM matches and quality estimates. Always report database release and completeness method.

## Workflow inputs and outputs

Analysis combines viral/proviral FASTA from geNomad/PVGA with this database to produce quality, completeness, contamination, provirus, and trimmed FASTA outputs. Those outputs feed viral reporting/annotation/phylogeny. The database itself must never be modified by sample analysis.

## Versioning, provenance, and updates

Record release directory name, source, acquisition date, archive/directory checksum, CheckV version, and path passed to `-d`. Install a new release beside the old, smoke-test known sequences, and start a new result series. Do not compare quality-category shifts without reporting database change.

## Validation and failure handling

Require non-empty genome/HMM indexes, version metadata, complete companion files, readable permissions, and a known-sequence end-to-end smoke test. Database path errors often come from passing the parent rather than versioned directory. Missing index companions require re-extraction from the verified local archive, not analysis-time download.
