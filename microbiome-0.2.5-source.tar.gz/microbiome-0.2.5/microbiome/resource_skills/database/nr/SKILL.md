---
name: NCBI non-redundant proteins
description: NCBI NR protein FASTA localized as a DIAMOND database.
kind: database
id: nr
version: 2
folder: nr
required_markers: [nr.dmnd]
raw_markers: [nr.faa, nr.gz]
compatible_software: [diamond]
advantages: [maximal broad protein homology coverage across taxa, useful when curated compact databases have no hit, supports exploratory remote similarity searches]
limitations: [extremely large and expensive to index/search, heterogeneous annotation quality and taxonomic bias, similarity does not prove orthology or function]
estimated_size: "Hundreds of GB compressed and potentially several hundred GB for FASTA plus DIAMOND index and temporary files."
acquisition_mode: automatic
acquisition_commands: ["wget -c https://ftp.ncbi.nlm.nih.gov/blast/db/FASTA/nr.gz -O Database/nr/nr.gz"]
aliases: [NCBI nr, non-redundant proteins, NR蛋白数据库]
keywords: [protein homology, taxonomy, broad annotation, NCBI, nr, 蛋白注释]
contents: [broad NCBI non-redundant protein sequence collection]
formats: [source nr FASTA or compressed FASTA, local DIAMOND nr.dmnd index]
consumers: [diamond]
update_policy: Pin download date or release snapshot; rebuild nr.dmnd after any FASTA change and never mix index volumes.
license_notes: NCBI data policies apply; downstream records may have heterogeneous source licenses and annotation quality.
download_urls:
  - https://ftp.ncbi.nlm.nih.gov/blast/db/FASTA/nr.gz
localization_commands:
  - "conda run -n microbiome diamond makedb --in Database/nr/nr.faa --db Database/nr/nr.dmnd"
---

# NCBI NR

NR is extremely large. Prefer the existing `Database/nr/nr.dmnd`. A new download/rebuild requires a marked acquisition proposal that discloses transfer, source FASTA, temporary space and index size before confirmation.

## Scope and biological meaning

NCBI NR is a broad non-redundant protein sequence collection spanning curated and unreviewed records across taxa. It maximizes homology coverage but has heterogeneous annotation quality, redundant biological functions despite sequence non-redundancy, and strong sampling bias. A top NR hit is evidence of sequence similarity, not automatically taxonomy, orthology, or experimentally validated function.

## Directory and readiness contract

`Database/nr/` holds the pinned source FASTA/compressed file, `nr.dmnd`, release/download metadata, and optional DIAMOND taxonomy mapping assets. A non-empty `.dmnd` is required; all files used to build it must belong to one snapshot. The index is very large, so size/readability checks and storage headroom are part of readiness.

## Acquisition and localization

Only a confirmed plan carrying the acquisition marker may acquire `nr.gz`. Verify source/checksum and disk needs, decompress or stream into `diamond makedb`, and build a new index in this folder. DIAMOND taxonomic filtering/classification requires additional correctly matched accession-to-taxid/nodes/names assets at build time; do not assume they exist because `nr.dmnd` exists.

## Software consumers and parameter coupling

DIAMOND `blastp`/`blastx` consumes `nr.dmnd`. Large database size makes e-value, coverage, sensitivity, top/max-target selection, composition masking, memory block size, and index chunks especially important. Taxon-list options are valid only if taxonomy metadata was embedded. Broad searches should retain alternate hits and report ambiguity.

## Workflow inputs and outputs

Protein FASTA from Prodigal/Bakta or nucleotide FASTA for `blastx` yields large tabular hit files. Include subject ID, identity, alignment/query/subject coverage, e-value, bit score, title/taxid fields only when available. Downstream functional/taxonomic summaries require explicit mapping and confidence rules; never parse an organism/function solely from an unstable free-text title without preserving accession.

## Versioning, provenance, and updates

NR changes continuously, so pin acquisition date, source URL, source size/checksum, sequence count, DIAMOND build command/version/options, taxonomy assets, and index checksum/size. Build updates beside the old index and benchmark hit stability before switching. Do not compare raw hit counts across snapshots without qualification.

## Validation and failure handling

Require DIAMOND `dbinfo` success, plausible sequence/letter counts, known protein smoke hits, sufficient disk/temp space, and query/output schema checks. Version-format errors require local rebuild with the declared DIAMOND environment. OOM calls for block-size/index-chunk tuning. Empty search output must be distinguished from strict filters, wrong molecule type, truncated index, or genuine novelty.
