---
name: MetaPhlAn marker database
description: Versioned clade-specific marker sequences and taxonomy index consumed by MetaPhlAn.
kind: database
id: metaphlan
version: 2
folder: metaphlan
required_markers: ["**/*.pkl", "**/*.bt2*"]
raw_markers: ["*.tar", "*.tar.bz2", "*.md5"]
compatible_software: [metaphlan]
advantages: [compact marker-based profiling, species-level community profiles, database release tied to MetaPhlAn taxonomy]
limitations: [relative abundance only, marker representation and reference bias, database/software compatibility is release-sensitive]
estimated_size: "Typically several GB including Bowtie2 indexes and metadata; confirm the selected release before acquisition."
acquisition_mode: automatic
acquisition_commands: ["conda run -n microbiome-metaphlan --no-capture-output metaphlan --install --index <release> --bowtie2db Database/metaphlan/"]
aliases: [MetaPhlAn DB, marker gene database, MetaPhlAn数据库]
keywords: [MetaPhlAn, markers, Bowtie2, taxonomy, shotgun, relative abundance]
contents: [clade-specific marker sequences, Bowtie2 indexes, taxonomy and marker metadata]
formats: [matching MetaPhlAn pickle metadata and Bowtie2 index files]
consumers: [metaphlan]
update_policy: Keep each MetaPhlAn database release immutable and beside prior releases; switch only after benchmarked revalidation.
license_notes: Preserve MetaPhlAn database license, release metadata and citations.
download_urls:
  - https://github.com/biobakery/MetaPhlAn/wiki/MetaPhlAn-4
localization_commands:
  - "After obtaining the exact approved official release, place its pickle and all Bowtie2 index parts under Database/metaphlan/<release>/ and retain checksums/release metadata."

validation_contract:
  any_complete_set:
  - suffixes:
    - .pkl
    - .1.bt2
    - .2.bt2
    - .3.bt2
    - .4.bt2
    - .rev.1.bt2
    - .rev.2.bt2
  - suffixes:
    - .pkl
    - .1.bt2l
    - .2.bt2l
    - .3.bt2l
    - .4.bt2l
    - .rev.1.bt2l
    - .rev.2.bt2l
---

# MetaPhlAn marker database

## Scope and biological meaning

The MetaPhlAn marker database supplies clade-specific marker sequences and Bowtie2 indexes used for marker-based shotgun taxonomic profiling. Its release is tied to a specific MetaPhlAn taxonomy and software version.

## Directory and readiness contract

READY requires the marker pickle (`**/*.pkl`) and Bowtie2 index files (`**/*.bt2*`) under `Database/metaphlan/`. Missing index parts break mapping; raw `.tar`/`.md5` alone indicate an unextracted download.

## Acquisition and localization

The official release is downloaded manually from the MetaPhlAn wiki/sources and placed under a dated child. Record checksums and release metadata; obtain approval before transfer.

## Software consumers and parameter coupling

metaphlan consumes the database via `--bowtie2db`. The database release and the MetaPhlAn major version must match, since marker sets change across releases.

## Workflow inputs and outputs

Input is quality-controlled shotgun FASTQ; output is a relative-abundance taxonomic profile. The database stays read-only during profiling.

## Versioning, provenance, and updates

Keep each release immutable beside prior releases and switch only after benchmarked revalidation, because abundance shifts can result from database change alone.

## Validation and failure handling

Require a complete pickle and all Bowtie2 index parts. A broken index yields mapping failures or empty profiles; verify with `bowtie2-inspect` on the index before a full run.
