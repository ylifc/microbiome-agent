---
name: UNITE ITS reference
description: Curated fungal and eukaryotic ITS sequences and taxonomy prepared for DADA2 and QIIME 2 classification.
kind: database
id: unite
version: 2
folder: unite
required_markers: ["dada2/*.fasta*", "qiime2/*classifier*.qza", release-manifest.yaml]
common_markers: [release-manifest.yaml]
consumer_markers:
  dada2: ["dada2/*.fasta*"]
  qiime2: ["qiime2/*classifier*.qza"]
raw_markers: ["source/*.fasta*", "source/*tax*", "*.tgz", "*.zip", "*.qza"]
compatible_software: [dada2, qiime2]
advantages: [preferred curated fungal ITS and Species Hypothesis reference, multiple clustering/scope choices, supports DADA2 and QIIME2 taxonomy workflows]
limitations: [release scope clustering and singleton choices materially change labels, non-fungal eukaryote coverage depends on selected package, classifier format can be environment specific]
estimated_size: "Typically hundreds of MB to a few GB including source and trained classifier artifacts."
acquisition_mode: manual
acquisition_commands: []
aliases: [UNITE DB, fungal ITS database, 真菌ITS数据库, UNITE classifier]
keywords: [UNITE, ITS, fungi, eukaryotes, species hypothesis, DADA2, QIIME2, taxonomy]
contents: [quality-filtered ITS references, fungal/eukaryotic taxonomy, Species Hypothesis identifiers, DADA2 and QIIME-ready forms]
formats: [UNITE general FASTA for DADA2 and QIIME 2 TaxonomicClassifier artifact in separate subdirectories]
consumers: [dada2, qiime2]
update_policy: Pin release date, fungi/eukaryote scope, clustering level, singleton policy and classifier training parameters together.
license_notes: UNITE data are released under specified CC BY-SA terms; retain attribution, share-alike obligations, and citations.
download_urls:
  - https://unite.ut.ee/repository.php
  - https://unite.ut.ee/cite.php
localization_commands:
  - "After the user places the selected official UNITE release under Database/unite/, keep source files in source/ and place the DADA2-compatible general FASTA in dada2/."
  - "Place or locally build a QIIME TaxonomicClassifier in qiime2/ using the pinned environment, then write release-manifest.yaml with date, scope, cluster ID, singleton policy, versions, checksums, and commands."
consumer_localization_commands:
  dada2:
    - "Place the selected UNITE general FASTA with taxonomy-bearing headers under Database/unite/dada2/ and write release-manifest.yaml with release date, scope, cluster ID, singleton policy, source, and checksum."
  qiime2:
    - "Place a compatible UNITE TaxonomicClassifier under Database/unite/qiime2/, or build it locally from already placed sequence/taxonomy artifacts in rachis-qiime2-2026.7; record commands and checksums in release-manifest.yaml."
---

# UNITE ITS reference

## Scope and biological meaning

UNITE is the preferred curated reference for fungal ITS taxonomy and Species Hypotheses. Releases can include fungi only or broader eukaryotes, dynamic/97/99% clusters, and optional singletons. These choices affect labels and feature coverage and must be selected from the study scope rather than treated as equivalent files.

## Directory and readiness contract

Store immutable downloaded content in `Database/unite/source/`, the DADA2-compatible taxonomy FASTA in `dada2/`, and a compatible QIIME 2 classifier in `qiime2/`. Full READY requires both consumer formats; consumer-specific readiness requires `release-manifest.yaml` plus only the selected format. The manifest names release date, taxon group, cluster ID, singleton policy, taxonomy format and preparation provenance.

## Acquisition and localization

Planning presents the official UNITE repository/citation pages and asks the user to choose and place a release. Confirmed analysis performs no REST/API or repository download. An official general FASTA may be used by DADA2 after header validation. For QIIME 2, locally import sequence/taxonomy artifacts, optionally extract the sequenced primer region, and fit the classifier only as a declared conversion step.

## Software consumers and parameter coupling

DADA2 `assignTaxonomy` consumes taxonomy-encoded training FASTA. QIIME 2 `classify-sklearn` consumes a release-compatible classifier. ITS length variation means paired-read truncation/merging and primer removal require locus-specific treatment; database choice does not repair biased read processing.

## Workflow inputs and outputs

Prepared UNITE data classify DADA2/QIIME representative ASVs into fungal/eukaryotic taxonomy and SH identifiers. Preserve unclassified/non-fungal ASVs and confidence values. Taxonomy assignment follows denoising and does not change counts.

## Versioning, provenance, and updates

Record release date/version, taxon scope, clustering, singleton setting, source/prepared checksums, primer extraction, training commands, software versions, license and citations. Keep historical releases and do not merge sequence and taxonomy files from different releases.

## Validation and failure handling

Require one-to-one sequence/taxonomy identifiers, valid taxonomy ranks/SH labels, non-empty consumer files, correct QIIME semantic type and a known fungal control. High unclassified rates first trigger orientation, primer-region and scope checks. Artifact incompatibility requires local rebuild from pinned source, not a silent database switch.
