---
name: Local reference genome collection
description: Manifested, release-pinned genome and annotation packages acquired with gget or NCBI Datasets for downstream alignment, annotation and comparative workflows.
kind: database
id: reference-genomes
version: 2
folder: reference-genomes
itemized: true
item_manifest_glob: "*/release-manifest.yaml"
required_markers: ["*/release-manifest.yaml"]
raw_markers: ["*/*.fa*", "*/*.gtf*", "*/ncbi_dataset.zip"]
compatible_software: [gget, ncbi-datasets, seqkit, bwa, bowtie2, minimap2, snippy, salmon]
aliases: [reference genomes, local genomes, 参考基因组库, 本地基因组]
keywords: [genome FASTA, GTF, GFF3, assembly accession, Ensembl release, RefSeq, GenBank, 本地参考基因组]
contents: [release-pinned genomic DNA, matching gene annotation and optional transcript CDS protein assets, source package and acquisition manifest]
formats: [FASTA and optional compressed FASTA, GTF or GFF3 annotation, NCBI data package, YAML release manifest, optional consumer indexes]
consumers: [seqkit, bwa, bowtie2, minimap2, snippy, salmon, ncbi-blast]
advantages: [avoids repeated network downloads, preserves exact assembly and annotation provenance, supports many downstream tools from one immutable source package]
limitations: [a genome is organism assembly and release specific, derived indexes remain consumer and software-version specific, collection size grows with every retained release]
estimated_size: "Usually tens of MB to several GB per genome and annotation; query links/package summary and available disk before approval."
acquisition_mode: conditional
download_urls: [https://scverse.org/gget/en/ref.html, https://www.ncbi.nlm.nih.gov/datasets/docs/v2/]
acquisition_commands:
  - "Use plan_reference_genome_download(<identifier>, assets=<assets>, release=<release>, source=<gget-or-ncbi>) to render the exact call; after confirmation run download_reference_genome(..., approved=True)."
localization_commands:
  - "Keep every source/release in one Database/reference-genomes/<source-identifier-release>/ child and retain release-manifest.yaml."
  - "Build BWA, Bowtie2, Minimap2, faidx, sequence-dictionary or Salmon indexes only when selected downstream software requires them; record each command/version in the manifest or a derived-index manifest."
update_policy: Never overwrite a reference child in place; pin assembly/accession and release, add new releases side by side, and bind every result to one manifest.
license_notes: Ensembl and NCBI source/citation/redistribution terms apply to the acquired records; retain source attribution and accession/release metadata.
validation: [all manifest files exist and are non-empty, FASTA parses and sequence IDs are unique, annotation contig IDs and coordinates match the selected DNA, requested release/accession matches the manifest]
failure_handling: [reject partial transfers and empty manifests, reacquire only the failed approved package, switch gget ref to NCBI Datasets for bacteria/archaea, rebuild only consumer indexes when source files remain valid]
---

# Local reference genome collection

## Scope and biological meaning

This collection stores immutable genome/annotation packages, not a taxonomic classifier or functional annotation database. Every child represents one source, organism or accession, assembly/release and requested asset set. A local reference is reusable only when its biological assembly, coordinate system and annotation scope match the new task.

## Directory and readiness contract

Use `Database/reference-genomes/<source-identifier-release>/`. A child is READY only when `release-manifest.yaml` records all source files and every listed file is non-empty. The manifest stores source, identifier/accession, release, acquisition date, exact command, assets, relative paths and byte sizes. Consumer indexes belong under that child or a clearly linked derived directory and must not replace source files.

## Acquisition and localization

Planning calls `inspect_local_reference_genomes()` first. For eukaryotic Ensembl references, gget offers compact release-aware retrieval of DNA, GTF, cDNA, CDS and peptide assets. For bacteria, archaea and fixed RefSeq/GenBank assemblies, NCBI Datasets is the supported path. When the target is a species name rather than an accession (especially bacteria or archaea, which gget ref cannot serve), first call the read-only `resolve_reference_genome_accessions('<name>')` tool to resolve it to a RefSeq reference GCF accession, then pin that accession in the plan. The plan emits `[MICROBIOME_DB_ACQUISITION:reference-genomes]`, exact identifier, source, assets, release and destination before any transfer.

After confirmation, `download_reference_genome(..., approved=True)` performs the transfer and writes the manifest. NCBI taxon queries run with a preflight assembly-count guard (`max_assemblies`, default 25) and default to `--reference`; narrow broad taxa with `assembly_level` (for example `complete`) or `annotated=True`, or set `reference_only=False` explicitly when reference assemblies are not desired. Index only for selected downstream consumers: `samtools faidx`, BWA/Bowtie2 indexes, Minimap2 `.mmi`, sequence dictionary or Salmon index. Each index uses its own software Skill environment.

## Software consumers and parameter coupling

BWA, Bowtie2, Minimap2 and Snippy require the exact DNA reference used to define coordinates. Salmon normally consumes transcript FASTA or a genome/decoy-aware index built from matching DNA/GTF. Annotation-aware tools require matching contig names; `chr1` versus `1`, accession-version suffixes and organellar contigs must be handled explicitly rather than by blind renaming.

## Workflow inputs and outputs

The acquisition input is a reviewed species identifier, TaxID or assembly accession plus requested asset/release choices. Outputs are immutable source assets and a manifest. Derived indexes feed alignment, quantification, variant calling and comparative workflows; their results must retain the reference child path and manifest checksum.

## Versioning, provenance, and updates

Pin Ensembl release or NCBI assembly accession version whenever reproducibility matters. Add updates side by side, run a small comparison pilot, and never combine old annotation with new DNA. Record source URLs/package metadata and any checksums supplied upstream.

## Validation and failure handling

Parse FASTA/GTF/GFF3, check unique sequence IDs, compare annotation sequence names with DNA, verify requested asset counts and run a tiny downstream index/alignment test. A successful network exit with no expected file is a failure. Partial archives are not READY. Unsupported bacterial gget requests switch to NCBI Datasets; coordinate mismatch requires choosing a matching annotation/reference pair, not editing IDs without a documented mapping.
