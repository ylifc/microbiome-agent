---
name: COG2020
description: NCBI Clusters of Orthologous Groups sequences and definitions for functional annotation.
kind: database
id: cog
version: 2
folder: cog
required_markers: [cog.dmnd, cog-20.def.tab]
raw_markers: [cog-20.fa.gz, cog-20.cog.csv]
compatible_software: [diamond]
advantages: [compact ortholog-group functional categories, stable mappings and definitions, much smaller than NR for broad first-pass annotation]
limitations: [older/coarser functional categories than pathway-specific resources, homology is not guaranteed orthology, taxonomy and novel-function coverage are limited]
estimated_size: "A few GB including the DIAMOND index."
acquisition_mode: automatic
acquisition_commands: ["python -c \"from microbiome.tool.microbial_databases import download_database; print(download_database('cog', out_dir='Database', env='microbiome'))\""]
aliases: [COG2020, Clusters of Orthologous Groups, COG功能分类]
keywords: [ortholog, functional category, protein annotation, COG, 功能注释]
contents: [COG protein sequences, protein-to-COG mapping, COG definitions and functional categories]
formats: [source FASTA.GZ and CSV or TSV mappings, DIAMOND cog.dmnd index]
consumers: [diamond]
update_policy: Treat sequence mappings and definitions as one atomic COG2020 release and rebuild the DIAMOND index after sequence changes.
license_notes: NCBI COG data terms and citation apply.
download_urls:
  - https://ftp.ncbi.nih.gov/pub/COG/COG2020/data/cog-20.fa.gz
  - https://ftp.ncbi.nih.gov/pub/COG/COG2020/data/cog-20.cog.csv
  - https://ftp.ncbi.nih.gov/pub/COG/COG2020/data/cog-20.def.tab
localization_commands:
  - "conda run -n microbiome diamond makedb --in Database/cog/cog-20.fa.gz --db Database/cog/cog.dmnd"
---

# COG2020

Keep sequence, mapping, definition, and DIAMOND index files together in `Database/cog/`. Join DIAMOND hits to the COG definition table during annotation.

## Scope and biological meaning

COG2020 groups proteins into curated orthologous groups and broad functional categories. The sequence FASTA supplies searchable representatives; the protein-to-COG mapping and definition table convert sequence hits into COG IDs, categories, names, and descriptions. A DIAMOND hit ID alone is not a COG annotation until these mappings are joined correctly.

## Directory and readiness contract

`Database/cog/` must keep `cog-20.fa.gz`, `cog-20.cog.csv`, `cog-20.def.tab`, optional category metadata, and the derived `cog.dmnd` from the same release. Required readiness is a non-empty DIAMOND index plus definition table. Do not combine a newer FASTA/index with older mapping definitions.

## Acquisition and localization

Planning records COG release, compact-annotation trade-offs, size and exact files. A marked proposal may acquire them after confirmation; then verify checksums/line counts and build `cog.dmnd` with DIAMOND in `microbiome`. Preserve the exact command and DIAMOND version, and block unmarked updates.

## Software consumers and parameter coupling

DIAMOND `blastp` consumes the `.dmnd`. Sensitivity, e-value, query/subject coverage, max targets, and top-hit policy affect COG assignment. Remote homolog detection may need a more-sensitive preset and multiple candidate hits. A short domain hit should not automatically transfer a full orthologous-group function.

## Workflow inputs and outputs

Prodigal/Bakta protein FASTA is searched against `cog.dmnd`. DIAMOND output must include subject ID, identity, aligned length, e-value, bit score, and coverage. Join subject IDs to `cog-20.cog.csv`, then COG IDs to `cog-20.def.tab`; aggregate category abundance only after resolving multi-hit/multi-COG policy.

## Versioning, provenance, and updates

Record COG2020 source URLs, file dates/checksums, sequence and mapping counts, DIAMOND build command/version, and annotation thresholds. Update all source tables atomically, build a new index beside the old, test mapping coverage, then switch the skill. Never overwrite an index used by an active analysis.

## Validation and failure handling

Require parseable non-empty source/mapping/definition files, a readable DIAMOND index, subject IDs that join at high rate, and known-protein smoke hits. Low join rate indicates ID parsing or mixed release, not absence of function. Multiple equivalent hits/categories require an explicit resolution rule. Empty hits require checking query molecule type, index path, sensitivity, and thresholds before biological interpretation.
