---
name: Pfam database
description: Curated Pfam-A protein-family profile HMM library prepared for HMMER hmmscan.
kind: database
id: pfam
version: 2
folder: pfam
required_markers: [Pfam-A.hmm, Pfam-A.hmm.h3f, Pfam-A.hmm.h3i, Pfam-A.hmm.h3m, Pfam-A.hmm.h3p]
raw_markers: [Pfam-A.hmm.gz, Pfam-A.hmm.dat.gz, Pfam-A.clans.tsv.gz]
compatible_software: [hmmer]
advantages: [curated protein-family/domain profile HMMs, model-specific gathering thresholds, interpretable domain architectures]
limitations: [domain evidence alone does not prove complete protein function, full scans cost CPU, release changes alter accessions and clan relationships]
estimated_size: "A few GB compressed and larger after decompression plus hmmpress indexes."
acquisition_mode: automatic
acquisition_commands: ["wget -c https://ftp.ebi.ac.uk/pub/databases/Pfam/current_release/Pfam-A.hmm.gz -P Database/pfam"]
aliases: [Pfam DB, Pfam-A, 蛋白结构域数据库, HMM结构域库]
keywords: [Pfam, protein family, domain, HMM, hmmscan, gathering threshold]
contents: [curated Pfam-A profile HMMs, model-specific curated thresholds, family/clan annotations]
formats: [uncompressed Pfam-A.hmm plus four HMMER3 hmmpress index files]
consumers: [hmmer]
update_policy: Keep each Pfam release immutable and record release-specific model/accession changes; update indexes with the same HMMER generation.
license_notes: Follow InterPro/Pfam redistribution, attribution, and citation terms for the selected release.
download_urls:
  - https://pfam-docs.readthedocs.io/en/latest/ftp-site.html
  - https://ftp.ebi.ac.uk/pub/databases/Pfam/current_release/
localization_commands:
  - "After the user places Pfam-A.hmm.gz in Database/pfam/, run: gzip -dk Database/pfam/Pfam-A.hmm.gz"
  - "Then run: conda run -n biomni-hmmer hmmpress -f Database/pfam/Pfam-A.hmm"
---

# Pfam database

## Scope and biological meaning

Pfam-A is a curated library of profile HMMs representing protein families and domains. Models can contain curated gathering/trusted/noise thresholds. A Pfam domain assignment identifies sequence compatibility with a family model; it does not by itself prove complete protein function.

## Directory and readiness contract

This skill uses `Database/pfam/Pfam-A.hmm` and the four non-empty HMMER3 indexes `.h3f`, `.h3i`, `.h3m`, `.h3p`. Preserve `Pfam-A.hmm.dat`, clan mappings, release/readme/checksum files where acquired. The raw `.gz` without pressed indexes is `NEEDS_LOCALIZATION`.

## Acquisition and localization

Planning points to official Pfam/InterPro FTP, pins a release, records size and proposes the exact files. A plan carrying the acquisition marker may download them after confirmation. Decompress locally and run `hmmpress -f` in `biomni-hmmer`; never overwrite a valid pinned release without a separately marked upgrade.

## Software consumers and parameter coupling

`hmmscan --cut_ga Database/pfam/Pfam-A.hmm proteins.faa` is the standard domain scan because gathering thresholds are model-specific. `--cut_tc` and `--cut_nc` change stringency. Arbitrary global E-value cutoffs can be used for exploration but must not silently replace curated thresholds.

## Workflow inputs and outputs

Localization converts the distributed HMM flat file into binary lookup indexes. HMMER consumes the library and proteins, emitting `domtblout`/reports. Domain coordinates and accessions feed annotation, architecture and marker extraction; sample output never belongs in this folder.

## Versioning, provenance, and updates

Record Pfam release, source URL, download date, compressed/uncompressed checksums, HMMER version used by `hmmpress`, model count from `hmmstat`, and companion annotation versions. Prepare new releases beside or atomically switch only after validation.

## Validation and failure handling

Require `hmmstat Database/pfam/Pfam-A.hmm` to report plausible models and a small positive-control `hmmscan --cut_ga`. Index-format errors require rerunning `hmmpress` from the verified local HMM with the active HMMER version. A corrupt/truncated HMM requires user reacquisition.
