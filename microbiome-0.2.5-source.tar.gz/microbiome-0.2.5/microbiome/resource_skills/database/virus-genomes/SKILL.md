---
name: Local virus genome collection
description: Manifested, filter-pinned virus nucleotide packages acquired with gget virus or NCBI Datasets virus, with per-segment and per-isolate completeness tracking for segmented viruses such as Rotavirus.
kind: database
id: virus-genomes
version: 3
folder: virus-genomes
itemized: true
item_manifest_glob: "*/release-manifest.yaml"
required_markers: ["*/release-manifest.yaml"]
raw_markers: ["*/*.fa*", "*/ncbi_virus_dataset.zip", "*/*.csv", "*/*.jsonl"]
compatible_software: [gget, ncbi-datasets, seqkit]
aliases: [virus genomes, viral genomes, 病毒基因组库, 轮状病毒, 病毒序列库]
keywords: [virus genome, viral FASTA, NCBI Virus, gget virus, Rotavirus, 轮状病毒, segmented genome, 分节段病毒, isolate, strain, 病毒序列获取]
contents: [virus nucleotide FASTA with accession metadata, CSV/JSONL record metadata including isolate and segment fields, acquisition command summary, YAML release manifest]
formats: [FASTA nucleotide records, CSV or JSONL metadata, NCBI virus data package ZIP, YAML release manifest, TSV segment-completeness report]
consumers: [seqkit, minimap2, bwa, bowtie2, mafft, muscle, iqtree2, ncbi-blast]
advantages: [explicit filter-pinned virus population with full provenance, retains isolate and segment metadata required by segmented viruses, avoids repeated NCBI Virus queries, supports both gget and NCBI Datasets provenance]
limitations: [one complete segment record does not prove one strain carries all segments, NCBI Virus metadata schema can change, broad taxon queries may retrieve very large populations]
estimated_size: "Usually MBs to hundreds of MB depending on taxon breadth and filters; run a summary/count query and check disk before approval."
acquisition_mode: conditional
download_urls: [https://scverse.org/gget/en/virus.html, https://www.ncbi.nlm.nih.gov/datasets/docs/v2/how-tos/virus/]
acquisition_commands:
  - "Use plan_virus_genome_download(<virus>, host=<host>, nuc_completeness=<completeness>, ...) to render the exact call; after confirmation run download_virus_genomes(..., approved=True)."
localization_commands:
  - "Keep every source/virus/filter/date acquisition in one Database/virus-genomes/<source-virus-filters-date>/ child and retain release-manifest.yaml plus metadata files."
  - "Validate FASTA against metadata accessions, keep the segment-completeness report for segmented viruses, and never mix records from different acquisition children."
update_policy: Never overwrite a virus child in place; re-run acquisition with a new date-stamped child and bind every downstream result to one manifest.
license_notes: NCBI Virus/INSDC source, citation and redistribution terms apply to the acquired records; retain accession, isolate and source-database attribution.
validation: [FASTA CSV JSONL and command summary exist and are non-empty, FASTA accessions match metadata records, every record satisfies the requested nuc_completeness, isolate and segment fields are preserved, segment-completeness report separates complete segment records from strains carrying every expected segment]
failure_handling: [reject empty or accession-mismatched packages, repair a missing gget executable inside the declared biomni-gget environment instead of recreating it, fall back from gget virus to NCBI Datasets virus on upstream schema failure, reacquire only the failed approved child]
---

# Local virus genome collection

## Scope and biological meaning

This collection stores immutable virus nucleotide packages defined by an explicit query population: virus name, TaxID or accessions plus host, completeness, segment, source-database, date, length and annotation filters. A child answers "which exact viral records, with which metadata, were acquired when" — it is not a general-purpose virology database.

Segmented viruses such as Rotavirus need two distinct completeness notions: one record being a complete segment, and one isolate/strain carrying every expected segment (11 for Rotavirus: VP1, VP2, VP3, VP4, VP6, VP7, NSP1, NSP2, NSP3, NSP4, NSP5). The manifest validation keeps `isolate`/`strain` and `segment` fields and writes a per-isolate segment-completeness report so downstream analysis never silently mixes segments from different strains.

## Directory and readiness contract

Use `Database/virus-genomes/<source-virus-filters-date>/`. A child is READY only when `release-manifest.yaml` records all source files and every listed file is non-empty. The manifest stores virus identifier, source, all filters, acquisition date, exact command, any environment-repair command, relative paths, byte sizes and the validation summary.

## Acquisition and localization

Planning calls `inspect_local_virus_genomes()` first; a compatible local child is preferred over a new transfer. The plan emits `[MICROBIOME_DB_ACQUISITION:virus-genomes]` with the exact virus identifier, filters, source, destination and the confirmed `download_virus_genomes(..., approved=True)` call before any transfer.

`gget virus` is the preferred path: it natively supports completeness, host, segment, source-database, date and length filters and emits FASTA, CSV, JSONL and a command summary. `datasets download virus genome` is the fallback path and supports accession lists, `--complete-only`, host, date and length restrictions; segment and source-database filters are enforced by post-download validation there.

If the `biomni-gget` environment exists but lacks the `gget` executable, first run the plan-declared proxy prerequisite `conda install -n biomni-gget -y -c conda-forge pysocks`, then repair in place with `conda run -n biomni-gget --no-capture-output python -m pip install --upgrade "gget>=0.30.3,<0.31"`; never recreate the same-named environment. `download_virus_genomes` probes `gget virus --help` (or `datasets --version`) before transferring and runs these declared repairs only when the probe fails.

## Software consumers and parameter coupling

SeqKit validates record counts and lengths; minimap2/BWA/Bowtie2 consume the FASTA as alignment references; MAFFT/MUSCLE plus IQ-TREE consume per-segment alignments. Pass one exact child path to consumers and keep the isolate/segment metadata beside the FASTA so per-segment phylogenies never mix isolates. Consumer environments stay separate from `biomni-gget` and `biomni-ncbi-datasets`.

## Workflow inputs and outputs

Acquisition consumes an explicit virus identifier plus filters and produces FASTA, CSV/JSONL metadata, a command summary, `release-manifest.yaml` and `segment-completeness-report.tsv`. Downstream steps consume the manifest-bound FASTA and the per-isolate report; sample analysis treats the collection as read-only.

## Versioning, provenance, and updates

Record the virus identifier, source, all filters, acquisition date, exact command, repair commands, relative file paths and byte sizes in the manifest. Never edit a child in place: acquire updates into a new date-stamped child, revalidate it, and switch consumers only after the new manifest is READY.

## Validation and failure handling

After transfer, require non-empty FASTA, CSV, JSONL and command-summary outputs; FASTA accessions must match metadata records; when `nuc_completeness=complete` was requested every metadata record must be complete. The validation writes `segment-completeness-report.tsv` grouping records by isolate and listing missing expected segments. When the task requires complete strains, zero isolates carrying all expected segments is a hard failure. Empty results, upstream schema changes, or transport failures are reported with stderr and never silently marked READY.
