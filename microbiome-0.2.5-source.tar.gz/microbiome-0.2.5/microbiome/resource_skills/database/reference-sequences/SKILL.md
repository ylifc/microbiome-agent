---
name: Local accession-pinned reference sequences
description: Versioned NCBI nucleotide and protein records for genes, transcripts, plasmids, loci and proteins that do not require a whole assembly package.
kind: database
id: reference-sequences
version: 3
folder: reference-sequences
itemized: true
item_manifest_glob: "*/release-manifest.yaml"
required_markers: ["*/release-manifest.yaml"]
raw_markers: ["*/*.fasta", "*/*.gb", "*/*.gp"]
compatible_software: [ncbi-edirect, seqkit, ncbi-blast, minimap2, bwa, bowtie2, mafft, iqtree2]
aliases: [reference sequences, NCBI accessions, gene sequences, protein sequences, 参考序列, 基因序列, 蛋白序列]
keywords: [nuccore, protein, accession version, FASTA, GenBank, transcript, plasmid, locus, 参考序列]
contents: [reviewed exact-version NCBI nucleotide or protein records, FASTA and optional flat files, checksums and acquisition provenance]
formats: [FASTA, GenBank or GenPept, YAML release manifest]
consumers: [seqkit, ncbi-blast, minimap2, bwa, bowtie2, mafft, iqtree2]
advantages: [retrieves exact records without a whole genome package, supports diverse accession types, immutable accession-list target enables local reuse]
limitations: [not an assembly selector, broad Entrez queries require human review, individual records do not provide SRA reads or consumer-specific indexes]
estimated_size: "Usually KB to hundreds of MB; chromosome-scale records can be larger. Review sequence lengths and available disk before confirmation."
update_policy: "Treat accession versions and accession-list hashes as immutable. Create a new child when any selected version changes; never overwrite a cited package."
license_notes: "Review NCBI submitter rights, attribution norms, controlled-record restrictions and downstream database terms even when records are publicly retrievable."
acquisition_mode: conditional
download_urls: [https://www.ncbi.nlm.nih.gov/books/NBK179288/]
acquisition_commands:
  - "For approximate species names, first use resolve_fuzzy_species_name(); use plan_species_reference_download() only after its TaxID confidence gate passes."
  - "Use resolve_reference_sequence_accessions() to review exact versions, then plan_reference_sequence_download(); after confirmation execute download_reference_sequences(..., approved=True)."
localization_commands:
  - "Keep each exact accession set in Database/reference-sequences/<ncbi-database-first-count-hash>/ and retain release-manifest.yaml."
  - "Build BLAST, BWA, Bowtie2 or minimap2 indexes only when the selected downstream workflow requires them and record derived versions separately."
upstream: [NCBI Datasets Taxonomy name normalization, NCBI ESearch and ESummary metadata resolution, reviewed accession lists, published locus or protein identifiers]
downstream: [similarity search, read mapping, multiple-sequence alignment, phylogenetics, primer design, annotation comparison]
---

# Local accession-pinned reference sequences

Use this collection when the biological object is an individual NCBI record rather than an organism assembly. A request for a named gene, transcript, plasmid, locus, marker sequence, reference protein, or explicit `NC_`/`NM_`/`NR_`/`WP_`/`NP_` accession belongs here. Whole assemblies belong in `reference-genomes`; public experimental reads belong in the staged SRA data workflow.

## Scope and biological meaning

Each child represents an exact reviewed set of NCBI `nuccore` or `protein` accession versions. It is a small immutable reference package, not an assembly catalog, experimental read collection or comprehensive similarity-search database.

## Directory and readiness contract

Store one set under `Database/reference-sequences/<ncbi-database-first-count-hash>/`. Readiness requires `release-manifest.yaml` and every recorded FASTA/GenBank/GenPept file to be present and non-empty.

A collection-level READY status does not prove that an arbitrary accession is present. Match database, exact versions and required formats against a child manifest.

## Acquisition and localization

When the user supplies an approximate scientific name, common name, abbreviated binomial or minor misspelling, first call the read-only `resolve_fuzzy_species_name()`. It asks NCBI Datasets Taxonomy for exact records or strict TaxID suggestions, re-queries every suggestion as structured JSON Lines, scores canonical/common/abbreviated names and rejects broad or close candidates. An ambiguous result is a planning question, not permission to download.

For a whole-organism reference, `plan_species_reference_download(reference_kind="genome")` pins one assembly accession and delegates to the `reference-genomes` acquisition contract. For a named gene, locus or protein, set `reference_kind` to `nucleotide` or `protein` and provide `sequence_query`; the resolver adds an exact `txidNNN[Organism:exp]` constraint before rendering accession candidates. A species name alone must never be expanded to every Entrez record.

Other natural-language sequence queries call the read-only `resolve_reference_sequence_accessions()`. Review title, organism, TaxID, molecule and length, because a symbol may match paralogs, partial records, synthetic constructs or unrelated taxa. Pin accession versions whenever available. The acquisition proposal must contain the exact accession list, NCBI database (`nuccore` or `protein`), formats, target, estimated size and downstream purpose.

Prefer a READY child only when its manifest contains the same accession versions and required formats. A partial overlap does not authorize silently mixing releases; either use the exact compatible subset with provenance or create a newly reviewed package.

Only the rendered `download_reference_sequences(..., approved=True)` call may run after confirmation. It uses `conda run -n biomni-ncbi-edirect`, writes through temporary files and atomically publishes the manifest.

## Software consumers and parameter coupling

FASTA is the default for SeqKit, BLAST databases, mappers, MAFFT and IQ-TREE 2. GenBank/GenPept preserves feature annotations, qualifiers, source taxonomy and coding coordinates for annotation-aware processing. Do not infer annotation from FASTA headers when a flat file is required.

BLAST requires molecule-appropriate `makeblastdb -dbtype`; nucleotide mappers require nucleotide FASTA; MAFFT and IQ-TREE 2 require homologous records and the intended alphabet. Derived indexes must record source checksum and consumer version.

## Workflow inputs and outputs

Sequence FASTA may feed `makeblastdb`, mapping-index construction, alignment, tree building and targeted extraction. Protein FASTA may feed DIAMOND/BLASTP, HMM workflows and phylogenetics. Consumer indexes are derived artifacts and must record the source manifest checksum plus the consumer software version.

Upstream inputs include publication accessions, genome annotations, marker choices and reviewed metadata candidates. Outputs are exact FASTA and optional feature-rich flat files with checksums and provenance.

## Versioning, provenance, and updates

Keep accession versions, database, formats, retrieval time, complete command, size and SHA-256 in the manifest. If NCBI replaces or suppresses a record, create a reviewed new child and retain the old cited package.

Never silently combine versions across children. Every derived index or alignment must point back to explicit source manifests.

## Validation and failure handling

Only `download_reference_sequences(..., approved=True)` may run after a confirmed `[MICROBIOME_DB_ACQUISITION:reference-sequences]` proposal. It uses `conda run -n biomni-ncbi-edirect`, writes each output through a temporary file, requires exactly one parsed record per reviewed accession, calculates SHA-256 and atomically publishes `release-manifest.yaml`.

Zero or fewer records usually means an obsolete accession, an accession in the wrong database, or merged/suppressed content. Return to read-only resolution instead of widening the query during execution. Transport failures may be retried; record-count or identity failures require a revised plan.
