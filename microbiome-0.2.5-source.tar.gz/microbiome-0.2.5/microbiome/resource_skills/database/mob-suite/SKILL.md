---
name: MOB-suite databases
description: Initialized plasmid reference, biomarker, repetitive-element, Mash, BLAST, and taxonomy data for MOB-suite.
kind: database
id: mob-suite
version: 2
folder: mob-suite
required_markers: [ncbi_plasmid_full_seqs.fas, ncbi_plasmid_full_seqs.fas.msh, ncbi_plasmid_full_seqs.fas.nin, repetitive.dna.fas.nin, clusters.txt, rep.dna.fas, mob.proteins.faa, mpf.proteins.faa, orit.fas]
raw_markers: ["data.tar.gz", "mob_suite*.tar*", ncbi_plasmid_full_seqs.fas, repetitive.dna.fas]
compatible_software: [mob-suite]
advantages: [integrated plasmid reconstruction typing mobility and host-range references, official initializer builds all required indexes, supports nearest-cluster interpretation]
limitations: [novel plasmids and mosaic structures can be underrepresented, first initialization is sizeable, cluster labels and schemas vary across releases]
estimated_size: "Several GB after BLAST and Mash indexes; inspect the selected MOB-suite release before approval."
acquisition_mode: automatic
acquisition_commands: ["conda run -n biomni-mob-suite --no-capture-output mob_init -d Database/mob-suite"]
aliases: [MOB-suite DB, plasmid reference database, 质粒分型数据库]
keywords: [plasmid, MOB-suite, replicon, relaxase, Mash, BLAST, host range]
contents: [curated complete plasmid sequences and clusters, replicon relaxase MPF and oriT biomarkers, repetitive element masks, host taxonomy metadata]
formats: [initialized MOB-suite directory containing FASTA, BLAST indexes, Mash sketch, cluster and taxonomy tables]
consumers: [mob-suite]
update_policy: Keep database releases aligned with the MOB-suite major version; cluster accessions and schemas can change between releases.
license_notes: Follow MOB-suite Apache license plus source-dataset and NCBI/Zenodo attribution terms.
download_urls:
  - https://github.com/phac-nml/mob-suite#mob-init
  - https://zenodo.org/records/10304948
localization_commands:
  - "After the user places the official initialized bundle under Database/mob-suite/, extract it locally and preserve all files together."
  - "For a raw official bundle only, build ncbi_plasmid_full_seqs.fas and repetitive.dna.fas nucleotide BLAST indexes and the ncbi_plasmid_full_seqs.fas.msh Mash sketch in biomni-mob-suite; mob_init network access requires the confirmed acquisition marker."
---

# MOB-suite databases

## Scope and biological meaning

MOB-suite combines complete plasmid reference clusters with replicon, relaxase, MPF, oriT and repetitive-element evidence. The database supports reconstruction, mobility/host-range prediction and nearest-neighbor naming; database coverage strongly affects novel-plasmid assignments.

## Directory and readiness contract

All initialized assets live together under `Database/mob-suite/`. READY requires the primary plasmid FASTA, its Mash sketch and BLAST index, the repetitive-DNA BLAST index and cluster table. Preserve biomarker FASTA/indexes, taxonomy SQLite/tables, literature mappings and status/version files even when they are not minimal markers.

## Acquisition and localization

MOB-suite normally lets `mob_init -d` download and initialize databases. Planning records that command or an exact prebuilt archive, size and release. A confirmed plan carrying the acquisition marker may run the declared initializer; automatic first-run network access without that marker remains blocked. Raw official files may be indexed locally with `makeblastdb` and `mash sketch` in the dedicated environment.

## Software consumers and parameter coupling

Pass `--database_directory Database/mob-suite` to `mob_recon`/`mob_typer`. Primary/secondary cluster distances and host-range labels are coupled to the reference clustering release. Custom chromosome filters are separate inputs and should not be silently installed into this shared database.

## Workflow inputs and outputs

Localization converts official reference FASTA/tables into BLAST and Mash indexes. MOB-recon consumes those indexes plus one bacterial assembly and emits chromosome/plasmid partitions and typing reports. Sample output must never be written into the database directory.

## Versioning, provenance, and updates

Record bundle/Zenodo version, source, acquisition date, checksums of archive/primary FASTA/cluster table, initialization commands, MOB-suite version and database path. Validate a new release beside the old before changing defaults.

## Validation and failure handling

Require Mash and BLAST inspection to succeed and run a known plasmid test with automatic download disabled. Missing `.nin/.msh` means raw but not localized. A lock/status file alone is never readiness evidence. Schema/cluster incompatibility requires a matching software/database pair, not partial copying between releases.
