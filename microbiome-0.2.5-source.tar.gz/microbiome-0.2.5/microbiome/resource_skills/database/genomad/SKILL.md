---
name: geNomad database
description: MMseqs2 indexes and marker metadata used by geNomad.
kind: database
id: genomad
version: 2
folder: genomad
required_markers: [genomad_db/genomad_db.dbtype, genomad_db/version.txt]
raw_markers: []
compatible_software: [genomad]
advantages: [official marker and taxonomy bundle for geNomad virus/plasmid models, no user-built index required, tightly coupled to end-to-end geNomad output]
limitations: [not a general protein annotation database, score behavior depends on bundle version, MMseqs2 companion files must remain complete]
estimated_size: "Several GB; query the geNomad downloader before approval."
acquisition_mode: automatic
acquisition_commands: ["conda run -n microbiome --no-capture-output genomad download-database Database/genomad"]
aliases: [geNomad DB, virus plasmid marker database, 病毒质粒数据库]
keywords: [virus, plasmid, MMseqs2, marker, taxonomy, mobile element, 病毒]
contents: [MMseqs2 marker sequence indexes, marker metadata and weights, virus taxonomy and model support files]
formats: [complete genomad_db directory with MMseqs2 dbtype and companion files, version.txt]
consumers: [genomad]
update_policy: Keep the complete official bundle intact; software and database versions should be tested together.
license_notes: Follow geNomad repository and database licenses and citation guidance.
download_urls:
  - https://github.com/apcamargo/genomad
localization_commands:
  - "After placing the official geNomad database at Database/genomad/genomad_db/, verify genomad_db.dbtype and version.txt; no additional index build is required."
---

# geNomad database

Keep the complete geNomad bundle in `Database/genomad/genomad_db/`; do not split its MMseqs2 index files across directories.

## Scope and biological meaning

The geNomad database contains MMseqs2-searchable marker proteins, marker weights/classes, virus taxonomy resources, and model support files used by annotation, marker classification, provirus detection, aggregated classification, and summary. It is coupled to geNomad's model assumptions and is not a general-purpose protein database.

## Directory and readiness contract

The complete official bundle must remain at `Database/genomad/genomad_db/`. `genomad_db.dbtype` and `version.txt` are sentinel markers, but all identically prefixed MMseqs2 companion files and metadata are required. Moving only `.dbtype` or one volume makes the directory unusable.

## Acquisition and localization

Planning records the official bundle version, size and model coupling. A plan carrying the acquisition marker may invoke geNomad's downloader after confirmation and place the bundle under `Database/genomad/`; unmarked downloads remain blocked. No sample-specific index build is expected. Confirm `version.txt`, bundle completeness, permissions and a geNomad smoke run.

## Software consumers and parameter coupling

geNomad end-to-end receives this directory as its third positional argument. Annotation sensitivity and MMseqs2 split count affect marker recovery/performance; summary score, FDR, hallmark, marker-enrichment, USCG, and conservative/relaxed settings interpret evidence generated from this database. Taxonomy leniency also depends on included taxonomy metadata.

## Workflow inputs and outputs

Sample contig FASTA plus this database produces marker annotations, scores, taxonomy, provirus boundaries, summary TSV, and virus/plasmid FASTA. CheckV consumes selected viral sequences using its own database; the two database roles must not be confused.

## Versioning, provenance, and updates

Record geNomad and database versions, source/release URL, acquisition date, archive/directory checksum, size/file count, and resolved path. Prepare a new bundle in a new versioned folder, compare known controls and score distributions, then update the skill path/markers. Do not mix old intermediate output with a new database.

## Validation and failure handling

Require `version.txt`, all MMseqs2 database volumes/lookup/index companions, geNomad version compatibility, and known viral/plasmid smoke classifications. MMseqs2 open/index errors usually indicate missing companions, path damage, or incompatible bundle. Memory failure is an execution-parameter issue (`--splits`), not evidence the database is absent.
