---
name: AMRFinderPlus database
description: Version-matched NCBI curated AMR, mutation, stress, and virulence reference data for AMRFinderPlus.
kind: database
id: amrfinderplus
version: 2
folder: amrfinderplus
required_markers: [latest/version.txt, latest/database_format_version.txt, latest/AMRProt.fa, latest/AMR.LIB, latest/AMR.LIB.h3f, latest/AMRProt.fa.phr, latest/AMR_CDS.fa.nhr, latest/fam.tsv, latest/taxgroup.tsv]
raw_markers: ["*/AMRProt.fa", "*/version.txt", "amrfinderplus-db*.tar*"]
compatible_software: [amrfinderplus]
advantages: [NCBI-curated AMR families and organism-specific mutation catalogs, tightly versioned with AMRFinderPlus, includes stress and virulence categories]
limitations: [mutation support is limited to declared organisms, database and software versions must match, broader loose homology discovery needs another method]
estimated_size: "Several GB after indexing; query amrfinder_update metadata and disk before approval."
acquisition_mode: automatic
acquisition_commands: ["conda run -n biomni-amrfinderplus --no-capture-output amrfinder_update -d Database/amrfinderplus"]
aliases: [AMRFinderPlus DB, NCBI AMR database, 耐药数据库, AMR突变数据库]
keywords: [AMR, acquired resistance, point mutation, stress gene, virulence, NCBI]
contents: [curated AMR protein and nucleotide references, organism-specific mutation catalogs, HMM library, hierarchy and taxgroup metadata]
formats: [versioned AMRFinderPlus data directory with BLAST/HMM indexes and latest symlink]
consumers: [amrfinderplus]
update_policy: Install a software-compatible release beside older releases; repoint latest only after validation and never mutate a release used by an active analysis.
license_notes: NCBI AMRFinderPlus software and database are United States Government works; retain requested attribution and citations.
download_urls:
  - https://github.com/ncbi/amr/wiki/AMRFinderPlus-database
  - https://ftp.ncbi.nlm.nih.gov/pathogen/Antimicrobial_resistance/AMRFinderPlus/database/
localization_commands:
  - "After the user places a complete version directory under Database/amrfinderplus/, run: conda run -n biomni-amrfinderplus amrfinder_index Database/amrfinderplus/<release-directory>"
  - "After successful indexing, point Database/amrfinderplus/latest to that version directory and verify version.txt, database_format_version.txt, AMRProt.fa, and AMR.LIB."
---

# AMRFinderPlus database

## Scope and biological meaning

This database supplies AMRFinderPlus's curated acquired resistance genes, hierarchical protein families, HMMs, nucleotide references, supported-organism mutation catalogs, and optional stress/virulence targets. Database content controls which genes, mutations and organisms can be reported; software presence alone is insufficient.

## Directory and readiness contract

Keep every release in `Database/amrfinderplus/<release>/` and maintain `Database/amrfinderplus/latest` as an explicit symlink only after successful indexing. READY requires non-empty `version.txt`, `database_format_version.txt`, `AMRProt.fa` and `AMR.LIB` through `latest`, plus all companion BLAST/HMM indexes generated for that release.

## Acquisition and localization

During planning, show the official NCBI database page, size/compatibility trade-offs and `amrfinder_update -d Database/amrfinderplus`. A plan carrying the database acquisition marker may run that command after confirmation; otherwise network access remains blocked. After files are present, run `amrfinder_index` locally and update the `latest` symlink only after validation.

## Software consumers and parameter coupling

AMRFinderPlus receives the parent directory with `-d Database/amrfinderplus`; its `latest` pointer selects the release. `-O/--organism` is valid only for taxgroups supported by that database, while `--plus` changes reported categories. Protein/GFF/nucleotide evidence and database mutation support must be recorded together.

## Workflow inputs and outputs

The database localization stage consumes official reference files, creates BLAST/HMM indexes, and emits a versioned immutable resource. It does not consume sample genomes. AMRFinderPlus then consumes it to produce gene/mutation reports and optional matched sequences.

## Versioning, provenance, and updates

Record database release from `version.txt`, database format version, source URL, acquisition date, checksums, indexing command, software version and `latest` target. New analyses may adopt a validated new release; existing result series should remain pinned or be rerun consistently.

## Validation and failure handling

Run the installed version's read-only database version check and a packaged/known positive example while binding `-d Database/amrfinderplus`. Format-version incompatibility requires matching software and database releases. Missing indexes require local re-indexing from verified files; missing source components require a marked acquisition proposal and cannot trigger an unplanned first-run download.
