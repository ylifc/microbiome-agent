---
name: GTDB-Tk reference data
description: A versioned GTDB release with markers, taxonomy, metadata, and placement references.
kind: database
id: gtdbtk
version: 2
folder: gtdbtk
required_markers: ["release*/markers", "release*/metadata", "release*/taxonomy"]
raw_markers: [gtdbtk_data.tar.gz]
compatible_software: [gtdbtk]
advantages: [standardized bacterial and archaeal genome taxonomy, reference placement plus ANI context, strong MAG and isolate comparability within one release]
limitations: [very large download and high runtime resources, excludes viruses and amplicon reads, taxonomy and species clusters can change by release]
estimated_size: "Approximately 60-100 GB compressed and substantially more extracted, depending on release."
acquisition_mode: automatic
acquisition_commands: ["wget -c https://data.gtdb.ecogenomic.org/releases/latest/auxillary_files/gtdbtk_package/full_package/gtdbtk_data.tar.gz -P Database/gtdbtk"]
aliases: [GTDB-Tk data, GTDB release, 细菌古菌分类数据库]
keywords: [GTDB, taxonomy, bacterial markers, archaeal markers, pplacer, ANI, 分类]
excludes: [16S扩增子, 18S扩增子, ITS扩增子, amplicon FASTQ, 扩增子FASTQ]
contents: [bacterial and archaeal marker packages, GTDB taxonomy and metadata, reference alignments and placement trees, ANI reference sketches]
formats: [versioned GTDB-Tk release directory with markers metadata taxonomy msa pplacer and radii files]
consumers: [gtdbtk]
update_policy: Keep releases separate and match the GTDB-Tk software compatibility table; never replace a release in place.
license_notes: GTDB data use and citation requirements apply; the package is very large.
download_urls:
  - https://data.gtdb.ecogenomic.org/releases/latest/auxillary_files/gtdbtk_package/full_package/gtdbtk_data.tar.gz
localization_commands:
  - "Extract the package as Database/gtdbtk/release<id>/ and set GTDBTK_DATA_PATH to that release directory when invoking the GTDB-Tk skill."
---

# GTDB-Tk reference data

GTDB-Tk data is very large. Planning must prefer a compatible existing release; a new release requires an explicit marked acquisition proposal and user confirmation before download. Keep each release in a separate `Database/gtdbtk/release<id>/` directory.

## Scope and biological meaning

GTDB-Tk reference data packages bacterial/archaeal marker HMMs, reference alignments and placement trees, GTDB taxonomy/metadata, species radii, and ANI/Mash assets. Classification is release-specific: names, reference genomes, species clusters, and placement can change across GTDB releases. It does not classify viruses.

## Directory and readiness contract

Each release must occupy its own child such as `Database/gtdbtk/release232/` and retain complete `markers`, `metadata`, `taxonomy`, MSA, pplacer, radii, and reference-sketch assets. The three required marker directories are necessary but not sufficient; use GTDB-Tk's database/version checks before declaring operational readiness. Never merge files from release207/release220/release232.

## Acquisition and localization

The full package is very large. Planning must disclose release compatibility, compressed/extracted size, disk headroom and transfer command. Only a confirmed plan carrying the acquisition marker may download it to `Database/gtdbtk/`; then extract into a release-specific directory and validate checksums/file structure. Set `GTDBTK_DATA_PATH` inside the dedicated GTDB-Tk `conda run` command.

## Software consumers and parameter coupling

GTDB-Tk 2.7.2 must use a database release listed as compatible by its own metadata/documentation. `classify_wf` uses marker placement and ANI screening; Mash cache, min alignment percentage, ANI alignment fraction, reduced/full tree, and filters depend on reference assets. A software/database mismatch can fail or, worse, produce unsupported behavior.

## Workflow inputs and outputs

Quality-controlled genome/MAG FASTA plus this reference produce bacterial/archaeal summary taxonomy, ANI/AF, marker alignments, placements, and warnings. Results can guide Bakta metadata and phylogenomics. Preserve the release ID in every taxonomy table and do not map it silently to another taxonomy system.

## Versioning, provenance, and updates

Record GTDB release, package URL, archive checksum, extraction path/size, metadata version, GTDB-Tk version, environment prefix, and Mash cache relation. Install new releases side by side, classify a benchmark set, quantify taxonomy changes, then update workflows. Historical analyses remain bound to their original release.

## Validation and failure handling

Require all major directories/assets, readable pplacer packages, taxonomy/metadata/radii files, compatible version report, and known bacterial/archaeal smoke classifications. pplacer OOM is not database corruption. Missing-reference or pickle/index errors indicate incomplete extraction or version mismatch. Never repair by mixing individual files from another release.
