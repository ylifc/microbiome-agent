---
name: eggNOG-mapper database
description: Orthology, taxonomy and DIAMOND sequence indexes required by eggNOG-mapper.
kind: database
id: eggnog-mapper
version: 2
folder: eggnog-mapper
required_markers: ["**/eggnog.db", "**/eggnog.taxa.db", "**/*.dmnd"]
raw_markers: ["*.tar.gz", "*.part", "*.tmp"]
compatible_software: [eggnog-mapper]
advantages: [broad orthology-based annotation, integrated COG KEGG GO and EC mappings, taxonomic-scope controls]
limitations: [large download/index, database/software major versions must match, homology does not prove specific biochemical function]
estimated_size: "Typically tens of GB; optional Pfam and novel-families data increase the footprint."
acquisition_mode: conditional
acquisition_commands: ["conda run -n microbiome-eggnog-mapper --no-capture-output download_eggnog_data.py --data_dir Database/eggnog-mapper/<release>/"]
aliases: [eggNOG DB, emapper database, 直系同源数据库]
keywords: [eggNOG, emapper, orthology, DIAMOND, COG, KEGG, GO, annotation]
contents: [orthology SQLite data, taxonomy SQLite data, DIAMOND sequence index, optional Pfam and families data]
formats: [eggnog.db, eggnog.taxa.db, compatible DIAMOND index]
consumers: [eggnog-mapper]
update_policy: Keep every eggNOG/emapper major release in a separate immutable directory and benchmark annotations before switching.
license_notes: Preserve eggNOG, bundled source-resource licenses and required citations.
download_urls:
  - https://github.com/eggnogdb/eggnog-mapper
  - http://eggnog6.embl.de/download/emapperdb-5.0.2/
localization_commands:
  - "After selecting a software-compatible official release, place eggnog.db, eggnog.taxa.db and its DIAMOND index under Database/eggnog-mapper/<release>/; retain checksums and download metadata."
---

# eggNOG-mapper database

## Scope and biological meaning

The eggNOG-mapper database provides the orthology, taxonomy and DIAMOND indexes emapper.py needs to assign orthologs and transfer COG/KEGG/GO/EC annotations. Its release must match the emapper.py major version, and it is large (tens of GB).

## Directory and readiness contract

Each release occupies an immutable child under `Database/eggnog-mapper/`. READY requires a non-empty `eggnog.db`, `eggnog.taxa.db`, and a compatible DIAMOND index (`*.dmnd`). Partial downloads or `.part`/`.tmp` files indicate an incomplete localization.

## Acquisition and localization

The official release is manually downloaded from eggNOG/emapper sources and placed under a dated child. Record archive checksums and download metadata. Acquisition is manual: name the exact release and obtain approval before transfer.

## Software consumers and parameter coupling

emapper.py consumes `eggnog.db`, `eggnog.taxa.db`, and the DIAMOND index together. Keep them as one validated bundle because mixing releases breaks orthology lookups.

## Workflow inputs and outputs

Input is a predicted-protein FASTA; output is the emapper annotations TSV. The database itself stays read-only and only supports the search/transfer step.

## Versioning, provenance, and updates

Record the eggNOG/emapper release, file checksums, and DIAMOND index build. Benchmark annotations on a small set before switching releases, since IDs change across versions.

## Validation and failure handling

Require all three components present and mutually compatible. A missing `eggnog.taxa.db` or index mismatch yields empty or erroring runs — flag it rather than proceeding with a partial database.
