---
name: CheckM2 database
description: Version-compatible UniRef100-derived DIAMOND feature database required by CheckM2 quality prediction.
kind: database
id: checkm2
version: 2
folder: checkm2
required_markers: ["**/uniref100.KO.1.dmnd"]
raw_markers: ["checkm2_database*.tar*", "CheckM2_database*.tar*", "**/uniref100.KO.1.dmnd"]
compatible_software: [checkm2]
advantages: [fast ML-based quality prediction for broad bacterial and archaeal MAG diversity, simple prepared DIAMOND asset, preferred modern MAG quality path]
limitations: [model-specific database cannot be replaced by generic UniRef, predictions still need domain-aware interpretation, download is large]
estimated_size: "Roughly tens of GB; query the selected Zenodo record and verify expanded disk headroom."
acquisition_mode: automatic
acquisition_commands: ["conda run -n biomni-checkm2 --no-capture-output checkm2 database --download --path Database/checkm2"]
aliases: [CheckM2 DB, CheckM2 database, MAG质量数据库]
keywords: [CheckM2, UniRef100, DIAMOND, completeness, contamination, MAG]
contents: [DIAMOND protein feature database used by CheckM2 machine-learning models]
formats: [uniref100.KO.1.dmnd within a versioned CheckM2 database directory]
consumers: [checkm2]
update_policy: Pin the database release to a compatible CheckM2 version and retain old releases for reproducibility.
license_notes: Follow the CheckM2 database archive terms, UniRef source terms, Zenodo record, and citation guidance.
download_urls:
  - https://github.com/chklovski/CheckM2#databases
  - https://zenodo.org/records/14897628
localization_commands:
  - "After the user places the official archive in Database/checkm2/, extract it locally with: tar -xf Database/checkm2/<archive> -C Database/checkm2/"
  - "Resolve and record the exact resulting uniref100.KO.1.dmnd path; no DIAMOND rebuild is required for the official prepared database."
---

# CheckM2 database

## Scope and biological meaning

CheckM2 maps predicted proteins to a UniRef100-derived DIAMOND database and converts those features into completeness and contamination predictions. The database is part of the model contract: an arbitrary UniRef or DIAMOND database cannot replace it.

## Directory and readiness contract

Store each official release under `Database/checkm2/<release>/`. READY requires a non-empty `uniref100.KO.1.dmnd`; preserve any release metadata and archive checksum beside it. Pass the exact `.dmnd` file to CheckM2 rather than assuming its parent path.

## Acquisition and localization

Planning points to the CheckM2 project/Zenodo record, states its large size and pins a compatible release. A marked acquisition proposal may run `checkm2 database --download --path Database/checkm2` after confirmation. A user-provided archive is instead checksum-verified and extracted locally; the official prepared DIAMOND database needs no rebuilding.

## Software consumers and parameter coupling

Use `--database_path Database/checkm2/<release>/uniref100.KO.1.dmnd` or a process-scoped `CHECKM2DB`. `--lowmem` changes runtime memory behavior, not database content. Model/database compatibility must be checked against the pinned CheckM2 release.

## Workflow inputs and outputs

Localization consumes the official archive and produces the prepared `.dmnd`. CheckM2 consumes that file plus genomes/proteins to emit `quality_report.tsv` and intermediates. Sample analysis must have read-only access to the database.

## Versioning, provenance, and updates

Record Zenodo record/version, archive and `.dmnd` checksum, file size, acquisition date, extraction command and CheckM2 version. Keep upgrades side by side, pass an explicit path, and rerun the built-in test before switching a workflow default.

## Validation and failure handling

Require a non-empty readable DIAMOND file and run `checkm2 testrun --database_path <file>`. Invalid DIAMOND headers, key/version exceptions or failed expected test predictions mean corruption or incompatibility. Re-extract from the verified local archive before asking for reacquisition.
