---
name: GUNC database
description: ProGenomes- or GTDB-derived DIAMOND reference used by GUNC to assess genome lineage homogeneity.
kind: database
id: gunc
version: 2
folder: gunc
required_markers: ["gunc_db_*.dmnd"]
raw_markers: ["gunc_db_*.dmnd", "gunc_db_*.tar*", "gunc_db_*.gz"]
compatible_software: [gunc]
advantages: [lineage-aware contig contamination and chimerism detection, complements marker-count quality tools, prepared database is directly consumable]
limitations: [bacterial and archaeal protein evidence depends on reference representation, does not replace completeness estimation, database/software compatibility matters]
estimated_size: "Several GB to tens of GB depending on the selected GUNC database release."
acquisition_mode: automatic
acquisition_commands: ["conda run -n biomni-gunc --no-capture-output gunc download_db Database/gunc"]
aliases: [GUNC DB, ProGenomes GUNC database, GTDB GUNC database, 嵌合检测数据库]
keywords: [GUNC, ProGenomes, GTDB, DIAMOND, chimerism, contamination]
contents: [reference proteins with genome-to-taxonomy lineage mappings encoded for GUNC]
formats: [prepared gunc_db_progenomes*.dmnd or gunc_db_gtdb*.dmnd file]
consumers: [gunc]
update_policy: Treat ProGenomes and GTDB variants/releases as distinct resources; never compare scores without recording the database choice.
license_notes: Follow GUNC and selected underlying ProGenomes/GTDB database terms and citations.
download_urls:
  - https://grp-bork.embl-community.io/gunc/installation.html
localization_commands:
  - "If the user places a compressed official archive in Database/gunc/, extract it locally and retain the resulting gunc_db_<release>.dmnd plus release metadata."
  - "If a complete .dmnd is placed directly, verify its checksum and readability; no DIAMOND makedb step is required."
---

# GUNC database

## Scope and biological meaning

GUNC uses reference gene taxonomy to measure whether genes in a genome share a coherent lineage. Available official variants include ProGenomes- and GTDB-derived databases; their taxonomy and reference coverage differ, so resulting CSS/RRS/pass values are not interchangeable.

## Directory and readiness contract

Store each database as `Database/gunc/gunc_db_<source><release>.dmnd` with a sidecar provenance record. READY requires a non-empty prepared `.dmnd`. Custom databases additionally require the exact genome-to-taxonomy mapping used to construct them and should be registered as a deliberate extension.

## Acquisition and localization

Planning points to official GUNC instructions and records the selected release, size and model scope. A marked proposal may run `gunc download_db Database/gunc` after confirmation; otherwise it remains blocked. Local processing includes decompression, checksum validation and path registration for official `.dmnd` files.

## Software consumers and parameter coupling

Pass the exact file through `gunc run --db_file ...` or process-scoped `GUNC_DB`. Database family affects the meaning of lineage ranks and mapped-gene coverage. `--use_species_level` should only be enabled when reference scope and the scientific question support that resolution.

## Workflow inputs and outputs

GUNC consumes this reference and genome/protein files to emit maxCSS and detailed taxonomic assignment tables. The database is read-only; outputs belong in the analysis result directory, never beside it.

## Versioning, provenance, and updates

Record source family, release, official URL, acquisition date, compressed/prepared checksums, file size, GUNC version and command path. Validate new releases side by side on known clean/chimeric genomes before adopting them.

## Validation and failure handling

Use GUNC's official test data or a known small genome set and require expected pass/fail direction plus adequate mapped genes. A DIAMOND format error indicates corruption/incompatibility; low mapping may instead reflect novel biology or an unsuitable database family and must not be repaired by lowering thresholds blindly.
