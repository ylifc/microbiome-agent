---
name: VFDB (Virulence Factor Database)
description: Curated bacterial virulence factor protein sets (Set A/B) for DIAMOND-based virulence screening.
kind: database
id: vfdb
version: 2
folder: vfdb
required_markers: ["**/*.dmnd", "**/VFDB_setA_pro.fas*"]
common_markers: ["**/VFDB_setA_pro.fas*"]
consumer_markers:
  diamond: ["**/*.dmnd"]
compatible_software: [diamond]
advantages: [curated experimentally verified and predicted virulence factors, Set A core + Set B extended coverage, direct DIAMOND blastp screening of predicted proteomes]
limitations: [protein-only evidence, presence does not imply active virulence expression, database scope is bacterial pathogens so non-bacterial virulence is not covered]
estimated_size: "Tens of MB compressed; a built DIAMOND database is a few hundred MB."
acquisition_mode: manual
acquisition_commands: ["Download VFDB_setA_pro.fas.gz and VFDB_setB_pro.fas.gz from http://www.mgc.ac.cn/VFs/Down/ (download page http://www.mgc.ac.cn/VFs/download.htm), extract under Database/vfdb/, then build a DIAMOND database: conda run -n biomni-diamond diamond makedb --in VFDB_setA_pro.fas --db vfdb_setA."]
aliases: [VFDB, virulence factors, 毒力因子数据库, 毒力筛查]
keywords: [virulence, VFDB, toxin, effector, adhesion, pathogen, 毒力]
contents: [VFDB Set A and Set B protein FASTA, optional DIAMOND .dmnd index]
formats: [raw protein FASTA (.fas/.fas.gz), built DIAMOND database (.dmnd)]
consumers: [diamond]
update_policy: Keep each VFDB release in its own dated child; never overwrite a production build in place.
license_notes: VFDB is free for academic use; verify redistribution and commercial terms before commercial use.
download_urls:
  - http://www.mgc.ac.cn/VFs/download.htm
  - http://www.mgc.ac.cn/VFs/Down/VFDB_setA_pro.fas.gz
  - http://www.mgc.ac.cn/VFs/Down/VFDB_setB_pro.fas.gz
---

# VFDB (Virulence Factor Database)

## Scope and biological meaning

VFDB curates bacterial virulence factors, split into Set A (experimentally verified) and Set B (predicted/complete). A protein hit in VFDB indicates a homolog of a known virulence factor, not demonstrated virulence — report it as a screening signal and avoid overclaiming pathogenicity.

## Directory and readiness contract

Each release occupies one child under `Database/vfdb/`. READY requires a non-empty protein FASTA (`VFDB_setA_pro.fas*`) and, for DIAMOND consumers, a non-empty `*.dmnd`. Raw FASTA alone is enough for annotation planning; the built DIAMOND index is required for `annotate_virulence_vfdb`.

## Acquisition and localization

Download Set A/B protein FASTAs from the official VFDB site into an immutable dated child, then build the DIAMOND index once. Record the release date and the exact files. The download is manual: show the URL and require confirmation before acquisition.

## Software consumers and parameter coupling

`microbiome.tool.antimicrobial_resistance.annotate_virulence_vfdb` runs `diamond blastp` against the built `.dmnd`. Keep the DIAMOND build version and the VFDB release recorded so hits are reproducible.

## Workflow inputs and outputs

Input is a predicted proteome (Prodigal/Bakta FASTA); output is a table of top hits with identity/coverage/e-value. Preserve no-hit proteins and report only hits above the documented identity/coverage thresholds.

## Versioning, provenance, and updates

Record the VFDB release, file checksums, DIAMOND version, and build command. Re-screen with the same release when comparing samples or time points.

## Validation and failure handling

Require a non-empty FASTA and a readable `.dmnd`. A `.dmnd` that fails to open usually means a truncated build — rebuild from the raw FASTA. Report low-identity hits cautiously; a short partial alignment is not proof of a functional virulence factor.
