---
name: UniProt Swiss-Prot
description: Curated protein sequences prepared as a DIAMOND database.
kind: database
id: swissprot
version: 2
folder: swissprot
required_markers: [swissprot.dmnd]
raw_markers: [uniprot_sprot.fasta.gz]
compatible_software: [diamond]
advantages: [manually reviewed protein records and curated names, compact enough for routine high-confidence first-pass annotation, stable UniProt accessions]
limitations: [smaller and taxonomically biased compared with NR or TrEMBL, homologs can differ in substrate or specificity, remote novelty may have no hit]
estimated_size: "Several hundred MB compressed and usually a few GB including the DIAMOND index."
acquisition_mode: automatic
acquisition_commands: ["python -c \"from microbiome.tool.microbial_databases import download_database; print(download_database('swissprot', out_dir='Database', env='microbiome'))\""]
aliases: [Swiss-Prot, UniProtKB Swiss-Prot, reviewed proteins, 高质量蛋白数据库]
keywords: [reviewed protein, curated annotation, function, UniProt, 蛋白注释]
contents: [manually reviewed UniProtKB protein sequences with curated accessions and annotations]
formats: [source uniprot_sprot FASTA.GZ, local DIAMOND swissprot.dmnd index]
consumers: [diamond]
update_policy: Pin the UniProt release date and rebuild the DIAMOND index atomically after source updates.
license_notes: UniProt terms and citation requirements apply.
download_urls:
  - https://ftp.uniprot.org/pub/databases/uniprot/current_release/knowledgebase/complete/uniprot_sprot.fasta.gz
localization_commands:
  - "conda run -n microbiome diamond makedb --in Database/swissprot/uniprot_sprot.fasta.gz --db Database/swissprot/swissprot.dmnd"
---

# Swiss-Prot

Store only Swiss-Prot files in `Database/swissprot/`. Prefer the existing `swissprot.dmnd` for high-quality functional annotation with the DIAMOND skill.

## Scope and biological meaning

UniProtKB/Swiss-Prot contains manually reviewed protein sequences and curated functional annotation. It is smaller and generally higher-confidence than TrEMBL/NR, making it a preferred first reference for interpretable function transfer. It still contains homologs with different substrates/specificities, fragments/isoforms, and taxonomic bias; curation does not make every local alignment sufficient for full-name transfer.

## Directory and readiness contract

Keep `uniprot_sprot.fasta.gz`, `swissprot.dmnd`, release/readme/checksum metadata, and any accession mapping files under `Database/swissprot/`. Required readiness is a readable non-empty index built from the matching source. Do not put TrEMBL or combined UniProt indexes in this folder under the Swiss-Prot name.

## Acquisition and localization

Planning prefers an existing compatible index and otherwise records the UniProt release/date, size and exact download/index commands with the acquisition marker. After confirmation, validate/decompress or stream the FASTA and build `swissprot.dmnd` using DIAMOND in `microbiome`. Build a temporary index and atomically switch after `dbinfo`/known-hit validation.

## Software consumers and parameter coupling

DIAMOND `blastp` is typical for Prodigal/Bakta proteins; `blastx` is possible for untranslated nucleotide sequence. Use e-value plus query/subject coverage and retain alternate hits for family ambiguity. Very-sensitive modes can recover remote homology but do not justify specific function transfer without conserved domain/residue/context evidence.

## Workflow inputs and outputs

Search output should preserve UniProt accession/entry name plus quantitative alignment fields. Map accessions to curated descriptions/EC/GO only from the same release or stable UniProt identifiers. Output can feed functional summaries and candidate selection for multiple alignment/phylogeny. Record no-hit proteins rather than dropping them.

## Versioning, provenance, and updates

Record UniProt release/date, source URL/checksum, sequence count, DIAMOND build command/version, and index checksum. Keep old releases for reproducibility or store immutable checksums and source. Rebuild whenever source FASTA changes; an index timestamp alone is not provenance.

## Validation and failure handling

Require `diamond dbinfo`, plausible sequence count, known protein recovery, accession/header parse checks, and source-index release match. A high hit rate with short low-coverage matches indicates permissive transfer, not success. Empty results require query molecule/path/filter diagnosis. Corrupt/index-version errors trigger local rebuild in a separate preparation task, never network access during analysis.
