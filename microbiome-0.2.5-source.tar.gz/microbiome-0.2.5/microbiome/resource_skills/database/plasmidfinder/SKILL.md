---
name: PlasmidFinder database
description: Curated plasmid replicon/Incompatibility-group sequences for ABRicate-based plasmid typing of assemblies.
kind: database
id: plasmidfinder
version: 2
folder: plasmidfinder
required_markers: ["**/sequences"]
common_markers: ["**/sequences"]
consumer_markers:
  abricate: ["**/sequences"]
compatible_software: [abricate]
advantages: [standard plasmid replicon/Inc-group typing vocabulary, rapid screen of assemblies, integrates directly with ABRicate tabular output]
limitations: [detects known replicon types only, does not assemble or prove plasmid circularity, a replicon hit does not equal a complete plasmid]
estimated_size: "A few MB; the ABRicate-formatted PlasmidFinder sequences are small."
acquisition_mode: conditional
acquisition_commands: ["Run abricate-get_db --db plasmidfinder (or place the approved PlasmidFinder sequences under Database/plasmidfinder/) and then abricate --setupdb to build the search indexes."]
aliases: [PlasmidFinder DB, plasmid replicon database, 质粒复制子数据库, 质粒分型]
keywords: [plasmid, replicon, incompatibility group, Inc type, ABRicate, typing, 质粒, 复制子]
contents: [plasmid replicon nucleotide sequences, optional name mapping, BLAST indexes]
formats: [ABRicate database directory with a concatenated sequences file]
consumers: [abricate]
update_policy: Keep each PlasmidFinder release in its own dated child; never overwrite a production build in place.
license_notes: PlasmidFinder is from the Center for Genomic Epidemiology; preserve its citation and redistribution terms.
download_urls:
  - https://bitbucket.org/genomicepidemiology/plasmidfinder_db
---

# PlasmidFinder database

## Scope and biological meaning

PlasmidFinder provides plasmid replicon (incompatibility group) sequences. A hit assigns an incompatibility (Inc) type to a replicon, which is the standard vocabulary for plasmid typing. A replicon hit indicates a known plasmid lineage, not a complete or circular plasmid.

## Directory and readiness contract

READY requires a non-empty ABRicate-format `sequences` file under `Database/plasmidfinder/`. The database must be indexed with `abricate --setupdb` before searching.

## Acquisition and localization

Download the approved PlasmidFinder sequences via `abricate-get_db --db plasmidfinder` or place them under `Database/plasmidfinder/`, then run `abricate --setupdb`. Acquisition is conditional: name it in the confirmed plan.

## Software consumers and parameter coupling

ABRicate consumes this database via `--db plasmidfinder` (or `--datadir Database`). Record the PlasmidFinder release and the ABRicate version together.

## Workflow inputs and outputs

Input is an assembled contig FASTA; output is a per-hit TSV with replicon type, identity, and coverage. Combine with MOB-suite for mobility classification and geNomad/PlasFlow for plasmid identification.

## Versioning, provenance, and updates

Record the PlasmidFinder release date and file checksums. Replicon vocabulary changes across releases, so keep the release with the analysis and do not mix databases across runs.

## Validation and failure handling

Require a non-empty `sequences` file and a successful `--setupdb`. A zero-hit result can be valid but first test the database and a known replicon sequence. A replicon hit without plasmid-context evidence is a typing signal, not proof of a functional plasmid.
