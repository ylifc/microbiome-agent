---
name: KEGG database
description: License-gated KEGG pathway/orthology protein sequences used for DIAMOND-based functional and pathway annotation.
kind: database
id: kegg
version: 2
folder: kegg
required_markers: ["**/*.dmnd", "**/*.pep*"]
common_markers: ["**/*.pep*"]
consumer_markers:
  diamond: ["**/*.dmnd"]
compatible_software: [diamond]
advantages: [rich KEGG Orthology and pathway links, enables KO assignment and pathway mapping, widely used functional vocabulary]
limitations: [requires a KEGG subscription for bulk download, license restricts redistribution, parsing needs KO mapping files]
estimated_size: "KEGG GENES/pep files are hundreds of MB to a few GB depending on selected organisms; a built DIAMOND index is comparable."
acquisition_mode: manual
acquisition_commands: ["After the user supplies a licensed KEGG GENES pep file (or approved mirror), place it under Database/kegg/<release-date>/ and build: conda run -n biomni-diamond diamond makedb --in <release>.pep --db kegg."]
aliases: [KEGG, KEGG Orthology, KO, 通路数据库, 功能注释]
keywords: [KEGG, pathway, KO, orthology, metabolism, annotation, 通路]
contents: [KEGG GENES protein FASTA, KO-to-pathway mapping tables, optional DIAMOND .dmnd index]
formats: [raw protein FASTA (.pep), built DIAMOND database (.dmnd)]
consumers: [diamond, eggnog-mapper]
update_policy: Keep each KEGG release in its own dated child; record the subscription terms and file provenance.
license_notes: Bulk KEGG download requires a paid subscription and KEGG forbids redistribution. Never auto-download; the user must provide licensed files.
---

# KEGG database

## Scope and biological meaning

KEGG links genes to KEGG Orthology (KO) entries and metabolic/signaling pathways. A KO assignment supports functional and pathway enrichment analysis. Because bulk KEGG data is subscription-gated and non-redistributable, this database is always manually provided.

## Directory and readiness contract

Each release occupies one child under `Database/kegg/`. READY requires a non-empty protein FASTA (`*.pep*`) and, for DIAMOND consumers, a built `*.dmnd`. Raw FASTA alone can feed eggNOG-mapper-style mapping; DIAMOND search needs the index.

## Acquisition and localization

The user must supply licensed KEGG GENES pep files or place them at an approved path. Never auto-download KEGG. After files are present, build the DIAMOND index once and record the release and provenance.

## Software consumers and parameter coupling

`diamond blastp` against the `.dmnd` assigns best-hit proteins to KEGG genes; downstream tools map those genes to KO and pathways. Keep the mapping tables (KO, pathway) with the same release.

## Workflow inputs and outputs

Input is a predicted proteome; output is a best-hit table (query, target, identity, coverage, e-value) that is then mapped to KO/pathways. Report unmapped proteins and the mapping coverage.

## Versioning, provenance, and updates

Record the KEGG release, file source and checksums, DIAMOND version, and build command. KEGG releases change gene IDs across versions, so keep the exact release with the analysis.

## Validation and failure handling

Require a non-empty pep FASTA and a readable `.dmnd`. If KO mapping files are missing, functional annotation will stop at best-hit genes — flag it rather than fabricating pathway terms. Do not redistribute the provided KEGG files.
