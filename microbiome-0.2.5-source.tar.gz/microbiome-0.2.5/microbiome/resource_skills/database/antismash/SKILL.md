---
name: antiSMASH databases
description: Version-matched Pfam, ClusterBlast, KnownClusterBlast, comparison, and module data for local antiSMASH.
kind: database
id: antismash
version: 2
folder: antismash
required_markers: ["pfam/*/Pfam-A.hmm", "pfam/*/Pfam-A.hmm.h3f", "clusterblast/proteins.fasta", "knownclusterblast/*/proteins.fasta"]
raw_markers: ["pfam/*/Pfam-A.hmm.gz", "clusterblast*.tar.xz", "kcb*.tar.xz", "cc_mibig*.tar.xz"]
compatible_software: [antismash]
advantages: [official coordinated component set for all selected antiSMASH modules, includes Pfam and cluster comparison references, downloader follows the installed release]
limitations: [large multi-component download, component licenses differ, partial data support only a restricted module set]
estimated_size: "Tens of GB depending on enabled modules; check the pinned antiSMASH downloader manifest before approval."
acquisition_mode: automatic
acquisition_commands: ["conda run -n biomni-antismash --no-capture-output download-antismash-databases --database-dir Database/antismash"]
aliases: [antiSMASH DB, BGC数据库, ClusterBlast database, MIBiG comparison data]
keywords: [antiSMASH, Pfam, ClusterBlast, KnownClusterBlast, MIBiG, BGC]
contents: [Pfam profiles, general and known cluster references, cluster comparison data, optional module reference assets]
formats: [antiSMASH-managed versioned directory tree with pressed HMM and sequence-search indexes]
consumers: [antismash]
update_policy: Use the downloader manifest bundled with the pinned antiSMASH release; do not mix independently current component versions.
license_notes: Component databases have distinct licenses and citations; preserve the bundled manifest and cite enabled modules.
download_urls:
  - https://docs.antismash.secondarymetabolites.org/install/
  - https://dl.secondarymetabolites.org/releases/
localization_commands:
  - "After all official component archives/files are placed under Database/antismash/ in the expected tree, extract them locally without network access."
  - "Then run: conda run -n biomni-antismash antismash --prepare-data --databases Database/antismash"
  - "Validate with: conda run -n biomni-antismash antismash --check-prereqs --databases Database/antismash"
---

# antiSMASH databases

## Scope and biological meaning

Local antiSMASH uses a coordinated set of Pfam profiles, ClusterBlast/KnownClusterBlast sequences, MIBiG comparison data and module-specific assets. Each supports different output sections; a partial tree can run only a restricted module set and must not be advertised as fully READY.

## Directory and readiness contract

Preserve the downloader's directory names and version children below `Database/antismash/`. READY requires a pressed Pfam HMM plus non-empty general and known cluster reference FASTA files; all selected optional modules must also pass antiSMASH prerequisite checks. Do not point standalone HMMER's newer Pfam folder here as a substitute.

## Acquisition and localization

Planning shows antiSMASH's official installation/release pages, component size/license trade-offs and the release-matched downloader. When the plan carries the acquisition marker, confirmation authorizes `download-antismash-databases --database-dir Database/antismash`; otherwise it remains blocked. Then run `--prepare-data`, which builds local indexes/caches, and validate selected modules.

## Software consumers and parameter coupling

Pass the root with `--databases Database/antismash`. `--cb-general`, `--cb-knownclusters`, `--cc-mibig`, HMM and other options require their associated components. Planning must omit an optional module or block for preparation when its component is absent.

## Workflow inputs and outputs

Preparation converts HMM/FASTA/reference archives into antiSMASH's expected indexes. Sample analysis then combines them with genome records and emits HTML, JSON and annotated GenBank. Databases remain read-only during analysis.

## Versioning, provenance, and updates

Record antiSMASH release, every component version/checksum, acquisition date, preparation command and prerequisite output. Upgrade as one coordinated tree beside the previous one; do not overwrite a database used by existing results.

## Validation and failure handling

`antismash --check-prereqs --databases ...` is authoritative. Missing HMM indexes can be rebuilt from verified local HMM files; missing ClusterBlast/MIBiG components require user acquisition. A major-version mismatch requires the matching component set, not symlink tricks or disabled sanitization.
