---
name: Transporter Classification Database
description: Transporter proteins prepared for DIAMOND annotation.
kind: database
id: tcdb
version: 2
folder: tcdb
required_markers: [tcdb.dmnd]
raw_markers: [tcdb.fasta]
compatible_software: [diamond]
advantages: [curated transporter classification hierarchy, direct transporter-family reference sequences, useful for mechanistic transport hypotheses]
limitations: [sequence similarity alone does not establish substrate or complete transport system, narrower scope than general protein databases]
estimated_size: "Usually modest compared with general protein databases; confirm the download and sequence count."
acquisition_mode: automatic
acquisition_commands: ["Download the TCDB protein FASTA from https://www.tcdb.org/public/tcdb into Database/tcdb/tcdb.fasta, then build the DIAMOND index: conda run -n microbiome diamond makedb --in Database/tcdb/tcdb.fasta --db Database/tcdb/tcdb.dmnd"]
aliases: [TCDB, Transporter Classification Database, 转运蛋白数据库]
keywords: [transporter, membrane protein, transport classification, TC number, 转运蛋白]
contents: [curated transporter protein sequences and transporter classification identifiers]
formats: [source transporter protein FASTA, local DIAMOND tcdb.dmnd index]
consumers: [diamond]
update_policy: Preserve access and download date and rebuild tcdb.dmnd after sequence updates; classification metadata must match sequences.
license_notes: TCDB data is open (CC BY-SA 3.0 / GNU FDL); no registration required, only citation/attribution applies.
download_urls:
  - https://www.tcdb.org/download.php
  - https://www.tcdb.org/public/tcdb
localization_commands:
  - "conda run -n microbiome diamond makedb --in Database/tcdb/tcdb.fasta --db Database/tcdb/tcdb.dmnd"
---

# TCDB

TCDB may require registration. The current folder is not ready until `tcdb.dmnd` exists. Planning must give the user the registration/download instruction and wait for placement in `Database/tcdb/` before analysis.

## Scope and biological meaning

TCDB curates transport systems and assigns hierarchical Transporter Classification (TC) identifiers. Its protein sequences support transporter-family discovery and classification hypotheses. Many transporters share domains while differing in substrate, coupling mechanism, subunit composition, or topology; a DIAMOND hit alone does not establish the full TC function.

## Directory and readiness contract

`Database/tcdb/` must contain the user-obtained transporter FASTA, derived `tcdb.dmnd`, acquisition/terms metadata, and any classification mapping required to decode sequence headers. The current folder is MISSING until a non-empty index exists. Do not place unrelated membrane-protein databases in this directory.

## Acquisition and localization

Access the official TCDB download page manually and follow registration/usage terms. The user places permitted files under `Database/tcdb/`. In a separate localization task, validate FASTA molecule/IDs and run DIAMOND `makedb`. Analysis confirmation cannot authorize automated login, registration, or download.

## Software consumers and parameter coupling

DIAMOND `blastp` consumes the index. Transporter annotation should combine sensitivity/e-value with query/subject coverage, identity, multiple hits, membrane topology/domain architecture, and TC hierarchy. Short domain-only hits should be labeled family/domain evidence rather than full-system assignment. Multi-subunit systems require component/context analysis.

## Workflow inputs and outputs

Prodigal/Bakta proteins are searched against `tcdb.dmnd`; tabular output should include stable subject ID and quantitative fields. Join subject IDs to TC numbers/descriptions from the same acquisition. Candidate proteins may feed MAFFT/phylogeny, topology prediction, genomic-neighborhood review, and manual curation.

## Versioning, provenance, and updates

Record access date, source/terms acknowledgement, FASTA checksum/count, classification mapping checksum, DIAMOND build command/version, and index checksum. TCDB may update without a conventional frozen release, so acquisition date is mandatory. Build updates beside the old index and validate mappings before use.

## Validation and failure handling

Require accepted access terms, valid protein FASTA, unique/joinable IDs, readable index, classification mapping coverage, and known transporter smoke hits. Missing mapping can make hits uninterpretable even if search works. If download/access is unavailable, planning must report preparation instructions and stop; it must not substitute an unregistered web scrape or claim transporter classification from generic NR alone.
