---
name: CARD
description: Comprehensive Antibiotic Resistance Database files for RGI annotation.
kind: database
id: card
version: 2
folder: card
required_markers: [card.json]
raw_markers: [broadstreet-v*.tar.bz2]
compatible_software: [rgi]
advantages: [curated resistance ontology and model-specific evidence, supports mutation and homolog/variant models, interpretable Perfect Strict and Loose categories]
limitations: [model coverage is not all resistance biology, phenotype cannot be inferred from every sequence hit, RGI local loading is environment specific]
estimated_size: "Usually below a few GB including localized RGI assets; record the CARD release archive size."
acquisition_mode: automatic
acquisition_commands: ["python -c \"from microbiome.tool.microbial_databases import download_database; print(download_database('card', out_dir='Database', env='biomni-rgi'))\""]
aliases: [CARD, Comprehensive Antibiotic Resistance Database, 耐药数据库]
keywords: [AMR, ARO, resistance model, mutation, antibiotic, 耐药]
contents: [CARD ontology and model JSON, reference sequences and model metadata, release and prevalence annotations when included]
formats: [card.json consumed by RGI load, optional source tarball and auxiliary TSV or FASTA files]
consumers: [rgi]
update_policy: Pin one CARD release per analysis; reload RGI whenever card.json changes.
license_notes: Follow CARD download terms and citation requirements.
download_urls:
  - https://card.mcmaster.ca/download
localization_commands:
  - "conda run -n biomni-rgi rgi load --card_json Database/card/card.json --local"
---

# CARD

Keep one CARD release in `Database/card/`. The files are locally present when `card.json` exists, but RGI still requires one environment-specific `rgi load --local` operation before analysis.

## Scope and biological meaning

CARD combines the Antibiotic Resistance Ontology, reference sequences, curated resistance models, drug classes, mechanisms, mutation/variant rules, and supporting metadata. RGI uses model-specific logic to classify hits as Perfect, Strict, or Loose. CARD is not a generic list where every partial sequence hit proves phenotype; model/category and evidence must remain attached.

## Directory and readiness contract

Keep one pinned release under `Database/card/`, with non-empty `card.json` as the required source marker. Preserve the downloaded archive and release metadata/checksum when available. The marker establishes local source readiness, but RGI also needs that JSON loaded into its own environment; loading into another RGI environment does not configure `biomni-rgi`.

## Acquisition and localization

Planning pins the CARD release, records its model/size trade-offs and may attach the acquisition marker to the declared download. After confirmation, acquire/extract only that release under `Database/card/`, then run `conda run -n biomni-rgi rgi load --card_json Database/card/card.json --local` and verify with RGI's database/version command. Unmarked updates remain blocked.

## Software consumers and parameter coupling

RGI `main` consumes the loaded release with `--local`. `--include_loose`, `--include_nudge`, input type, ORF method, and alignment backend alter reported evidence but do not change the underlying CARD release. Reports must include CARD version, RGI version, Perfect/Strict/Loose policy, and any prevalence data used.

## Workflow inputs and outputs

Database preparation input is the official CARD archive/JSON. Localization creates environment-specific RGI data/indexes. Analysis input is contig or protein FASTA; output is RGI TSV/JSON carrying ARO/model/drug/mechanism fields. ABRicate cannot directly consume `card.json` without a separately prepared ABRicate-format CARD sequence database.

## Versioning, provenance, and updates

Record CARD release/version, URL, acquisition date, archive and `card.json` checksums, localization command, and target RGI environment. Prepare and validate a new release separately, reload it, run a known positive/negative comparison, then start a new analysis. Never overwrite release evidence for an existing result.

## Validation and failure handling

Require parseable non-empty JSON, visible version/model counts, successful `rgi load`, and a small known-query test. A `card.json` file alone does not prove RGI localization. Schema errors usually indicate CARD/RGI incompatibility or incomplete extraction. If loading fails, fix the dedicated environment or local file; do not fetch a replacement during confirmed execution.
