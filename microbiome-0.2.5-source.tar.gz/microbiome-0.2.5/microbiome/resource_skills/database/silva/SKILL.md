---
name: SILVA ribosomal RNA reference
description: Curated SSU/LSU ribosomal RNA sequences and taxonomy prepared for DADA2 and QIIME 2 classification.
kind: database
id: silva
version: 2
folder: silva
required_markers: ["dada2/*train*.fa*", "qiime2/*classifier*.qza", release-manifest.yaml]
common_markers: [release-manifest.yaml]
consumer_markers:
  dada2: ["dada2/*train*.fa*"]
  qiime2: ["qiime2/*classifier*.qza"]
raw_markers: ["source/*.fasta*", "source/*tax*", "*.tar.gz", "*.qza"]
compatible_software: [dada2, qiime2]
advantages: [broad curated SSU and LSU ribosomal reference coverage, widely used taxonomy for bacterial archaeal and eukaryotic amplicons, prepared forms support DADA2 and QIIME2]
limitations: [classifier must match locus/primer region and software format, species-level labels need caution, prepared QIIME artifacts can be environment-version specific]
estimated_size: "From hundreds of MB for a training set to several GB for source files and trained classifiers."
acquisition_mode: manual
acquisition_commands: []
aliases: [SILVA DB, SILVA classifier, 16S数据库, 核糖体RNA分类数据库]
keywords: [SILVA, 16S, 18S, SSU, LSU, taxonomy, DADA2, QIIME2, amplicon]
contents: [curated ribosomal RNA reference sequences, taxonomy labels, DADA2 training FASTA, locus/region-specific QIIME classifier]
formats: [DADA2 taxonomy training FASTA and QIIME 2 TaxonomicClassifier artifact in separate subdirectories]
consumers: [dada2, qiime2]
update_policy: Pin release, subunit, region, clustering/nonredundancy, taxonomy and classifier training parameters together.
license_notes: Follow SILVA data license, redistribution policy, and required citations; species labels may be less curated than genus-level taxonomy.
download_urls:
  - https://www.arb-silva.de/current-release
  - https://www.arb-silva.de/documentation/classifiers/qiime-2
localization_commands:
  - "After the user places official DADA2 and compatible QIIME classifier files under Database/silva/, organize them as dada2/<release>-train-set.fa.gz and qiime2/<release>-<region>-classifier.qza without changing contents."
  - "If only local sequence/taxonomy files are supplied, import them in the pinned QIIME 2 environment and fit a classifier as an explicitly planned local conversion; write release-manifest.yaml with source, locus, region, primers, versions, checksums, and commands."
consumer_localization_commands:
  dada2:
    - "Place the official DADA2 taxonomy training FASTA under Database/silva/dada2/ and write release-manifest.yaml with release, locus, checksum, and source; no QIIME artifact is required for DADA2-only use."
  qiime2:
    - "Place a release/locus/region-compatible TaxonomicClassifier artifact under Database/silva/qiime2/, or fit it locally from already placed sequence/taxonomy artifacts in rachis-qiime2-2026.7; record the full command and checksums in release-manifest.yaml."
---

# SILVA ribosomal RNA reference

## Scope and biological meaning

SILVA provides curated SSU/LSU ribosomal RNA references and taxonomy for bacterial, archaeal and eukaryotic marker-gene studies. A classifier must match 16S/18S/LSU target, primer region and orientation. Species labels require caution because SILVA taxonomy is curated principally to genus level and lower labels can derive from submitted organism names.

## Directory and readiness contract

Use `Database/silva/source/` for immutable source files, `dada2/` for an `assignTaxonomy` training FASTA, and `qiime2/` for a locus/region/version-compatible `TaxonomicClassifier` `.qza`. Full READY requires both consumer formats and `release-manifest.yaml`, while consumer-specific readiness requires the manifest plus only the selected consumer's format. The manifest records release, scope, primers/region, software version, checksums and creation commands.

## Acquisition and localization

Planning first selects locus and intended consumer, then links official SILVA release/classifier pages and asks the user to place the files here. Confirmed analysis never downloads reference data. Official prepared files need organization/checksum only. If local source sequence/taxonomy files are present, the Agent may run QIIME import, primer extraction and classifier fitting as planned local conversion; it must retain intermediate artifacts and exact parameters.

## Software consumers and parameter coupling

DADA2 `assignTaxonomy` needs a training FASTA whose headers encode taxonomy; `assignSpecies` may use a separate species file when available. QIIME 2 `classify-sklearn` needs a compatible `.qza`; region-specific training improves relevance but prevents silent use for a different primer pair. Confidence thresholds and reference release are analysis parameters.

## Workflow inputs and outputs

Source references are transformed into DADA2 training FASTA and/or typed QIIME artifacts. These classify ASV representative sequences and emit taxonomy tables/artifacts. They do not alter the ASV abundance table and are not required for denoising itself.

## Versioning, provenance, and updates

Record SILVA release, SSU/LSU and NR setting, source/prepared checksums, primer sequences, extraction/classifier commands, DADA2/QIIME versions and taxonomy rank policy. Keep new releases beside old and avoid combining taxonomy from one release with sequences from another.

## Validation and failure handling

Require parseable taxonomy headers, representative sequence count, QIIME artifact semantic type/provenance, and positive/negative controls. Classifier deserialization errors imply QIIME/scikit-learn incompatibility and require rebuilding locally from pinned source or using a compatible official artifact. Unexpectedly broad unclassified rates require checking locus/orientation/primer coverage before changing confidence.
