---
name: Kraken2 database
description: Prepared minimizer-to-taxonomy index used for Kraken2 sequence classification.
kind: database
id: kraken2
version: 3
folder: kraken2
runtime_directory_marker: hash.k2d
required_markers: ["**/hash.k2d", "**/opts.k2d", "**/taxo.k2d"]
common_markers: ["**/hash.k2d", "**/opts.k2d", "**/taxo.k2d"]
consumer_markers:
  kraken2: ["**/hash.k2d", "**/opts.k2d", "**/taxo.k2d"]
  bracken: ["**/database*mers.kmer_distrib"]
raw_markers: ["*.tar.gz", "*.tar.xz", "*/library", "*/taxonomy"]
compatible_software: [kraken2, bracken]
advantages: [very fast read/contig taxonomic classification, many prebuilt scopes available, custom builds can exactly match project organisms]
limitations: [RAM and disk depend strongly on build, abundance and false positives depend on included libraries/taxonomy, a build cannot answer outside its taxonomic scope]
estimated_size: "From a few GB for compact builds to hundreds of GB for Plus/standard variants; record required RAM as well as disk."
acquisition_mode: conditional
acquisition_commands: ["Use the exact prebuilt URL selected in the confirmed plan and extract it to Database/kraken2/<name-date>/, or run conda run -n biomni-kraken2 kraken2-build --standard --db Database/kraken2/<name-date> when that full build and its disk/RAM/time were approved."]
aliases: [Kraken2 DB, Kraken database, k-mer分类数据库, 宏基因组物种数据库]
keywords: [Kraken2, taxonomy, minimizer, k-mer, RefSeq, GTDB, SILVA, microbial classification]
contents: [compact minimizer hash, taxonomy tree, build parameters, optional source library and accession maps]
formats: [one versioned child directory containing hash.k2d, opts.k2d, and taxo.k2d]
consumers: [kraken2, bracken]
update_policy: Keep each database type and build date in a separate child directory; never replace a production build in place.
license_notes: Database licensing is the union of Kraken2 and all included source libraries; preserve source manifests and citations.
download_urls:
  - https://github.com/DerrickWood/kraken2/wiki/Manual#kraken-2-databases
  - https://benlangmead.github.io/aws-indexes/k2
localization_commands:
  - "After the user places a prebuilt Kraken2 archive under Database/kraken2/, extract it locally into a named child such as Database/kraken2/standard-YYYYMMDD/."
  - "Verify the child contains non-empty hash.k2d, opts.k2d, and taxo.k2d; a raw library/taxonomy tree requires an explicitly planned kraken2-build operation rather than analysis-time download."

validation_contract:
  nonempty_globs:
  - hash.k2d
  - opts.k2d
  - taxo.k2d
  consumers:
    bracken:
      parameter_files:
      - flag: -r
        pattern: database{value}mers.kmer_distrib
---

# Kraken2 database

## Scope and biological meaning

A Kraken2 database maps sequence minimizers to taxonomic ancestors. Its included organisms, taxonomy source, build parameters and date define what Kraken2 can classify. Standard RefSeq, PlusPF, GTDB, SILVA-special and project-specific databases have different scientific scope and resource requirements.

## Directory and readiness contract

Each build occupies one immutable child, for example `Database/kraken2/standard-202607/`. READY requires non-empty `hash.k2d`, `opts.k2d` and `taxo.k2d` in the same child. Source `library/` and `taxonomy/` directories alone indicate a raw/incomplete build, not a classifier-ready database.

## Acquisition and localization

Planning first prefers a READY local child and reports its organism scope/RAM. If none fits, it must choose one exact prebuilt archive or one exact custom build, disclose source libraries, disk/RAM/time and attach the acquisition marker. Confirmation authorizes only that declared transfer/build. Extract into an immutable named child and validate all three `.k2d` files before the pilot.

## Software consumers and parameter coupling

Pass the exact child path through `kraken2 --db`. `opts.k2d` fixes k/minimizer settings; `hash.k2d` size determines memory behavior; taxonomy content controls report ranks. Bracken consumer-readiness additionally requires a non-empty `database<read-length>mers.kmer_distrib` file; select the exact file whose read length matches the filtered reads.

## Workflow inputs and outputs

Kraken2 loads this database and classifies reads/contigs into per-sequence output and hierarchical reports. The database stays read-only. Classified/unclassified reads and reports belong in sample result folders.

## Versioning, provenance, and updates

Record child name, source manifest, build/download date, all source releases, checksums of the three `.k2d` files, size, Kraken2 version and build options. Compare new builds on a benchmark before changing defaults; abundance shifts can result from database change alone.

## Validation and failure handling

Require `kraken2-inspect --db <child>` to parse and report plausible taxonomy/database statistics. Missing one `.k2d`, inconsistent taxonomy or truncated archive blocks execution. RAM failure can use `--memory-mapping` or a smaller documented database; it does not justify silently switching scientific scope.
