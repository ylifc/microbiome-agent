"""Validated software and database skills used by Microbiome planning."""

from __future__ import annotations

import json
import os
import re
import shlex
import shutil
import subprocess

from microbiome.pipeline.process_file_policy import run_scoped_process
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

PROJECT_ROOT = Path(__file__).resolve().parents[2]
RESOURCE_HOME = PROJECT_ROOT if (PROJECT_ROOT / "pyproject.toml").is_file() else Path.home() / ".local" / "share" / "microbiome"
PACKAGE_SKILL_ROOT = Path(__file__).resolve().parent
DEFAULT_CUSTOM_SKILL_ROOT = Path(os.environ.get("MICROBIOME_RESOURCE_SKILL_ROOT", RESOURCE_HOME / "ResourceSkills"))
DEFAULT_DB_ROOT = Path(os.environ.get("MICROBIOME_DB_ROOT", RESOURCE_HOME / "Database"))
_VALID_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,62}$")
_SEARCH_TOKEN = re.compile(r"[a-z0-9][a-z0-9+.-]{1,}|[\u4e00-\u9fff]{2,}")
_CJK_RUN = re.compile(r"[\u4e00-\u9fff]{2,}")
DATABASE_ACQUISITION_MARKER = "MICROBIOME_DB_ACQUISITION"
_DATABASE_ACQUISITION_RE = re.compile(
    rf"\[{DATABASE_ACQUISITION_MARKER}:([a-z0-9-]+)(?::([a-z0-9-]+))?\]",
    re.IGNORECASE,
)


class SkillValidationError(ValueError):
    """Raised when a resource skill does not follow the required schema."""


@dataclass(frozen=True)
class ResourceSkill:
    """A parsed resource SKILL.md document."""

    kind: str
    skill_id: str
    name: str
    description: str
    metadata: dict[str, Any]
    body: str
    path: Path


@dataclass(frozen=True)
class ResourceStatus:
    """Current local readiness of one resource skill."""

    kind: str
    skill_id: str
    status: str
    path: str | None = None
    environment: str | None = None
    missing: tuple[str, ...] = ()
    command_prefix: tuple[str, ...] = ()
    create_command: str | None = None


def _parse_skill(path: Path) -> ResourceSkill:
    text = path.read_text(encoding="utf-8")
    match = re.match(r"^---\s*\n(.*?)\n---\s*\n?(.*)$", text, re.DOTALL)
    if not match:
        raise SkillValidationError(f"{path}: SKILL.md must start with YAML frontmatter")
    metadata = yaml.safe_load(match.group(1)) or {}
    if not isinstance(metadata, dict):
        raise SkillValidationError(f"{path}: frontmatter must be a mapping")

    required = ("name", "description", "kind", "id", "version")
    missing = [field for field in required if not metadata.get(field)]
    if missing:
        raise SkillValidationError(f"{path}: missing required fields: {', '.join(missing)}")

    kind = str(metadata["kind"]).lower()
    skill_id = str(metadata["id"]).lower()
    if kind not in {"software", "database"}:
        raise SkillValidationError(f"{path}: kind must be software or database")
    if not _VALID_ID.fullmatch(skill_id):
        raise SkillValidationError(f"{path}: invalid id {skill_id!r}")

    if kind == "software":
        for field in ("environment", "executables"):
            if not metadata.get(field):
                raise SkillValidationError(f"{path}: software skill requires {field}")
        if (
            not metadata.get("packages")
            and not metadata.get("environment_file")
            and not metadata.get("discovered_executable")
        ):
            raise SkillValidationError(
                f"{path}: software skill requires packages, environment_file, or discovered_executable"
            )
        selection_tier = str(metadata.get("selection_tier", "established"))
        if selection_tier not in {"default", "conditional", "established"}:
            raise SkillValidationError(f"{path}: selection_tier must be default, conditional, or established")
    else:
        folder = str(metadata.get("folder", ""))
        if not folder or Path(folder).name != folder or folder in {".", ".."}:
            raise SkillValidationError(f"{path}: database folder must be one direct Database/ subfolder")
        if not metadata.get("required_markers"):
            raise SkillValidationError(f"{path}: database skill requires required_markers")
        if not metadata.get("compatible_software"):
            raise SkillValidationError(f"{path}: database skill requires compatible_software")
        acquisition_mode = str(metadata.get("acquisition_mode", "manual"))
        if acquisition_mode not in {"automatic", "conditional", "manual"}:
            raise SkillValidationError(f"{path}: acquisition_mode must be automatic, conditional, or manual")

    return ResourceSkill(
        kind=kind,
        skill_id=skill_id,
        name=str(metadata["name"]),
        description=str(metadata["description"]),
        metadata=metadata,
        body=match.group(2).strip(),
        path=path,
    )


def _as_string_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        return [str(item) for item in value]
    raise SkillValidationError(f"Expected a string or list, got {type(value).__name__}")


def _compact_list(value: Any, limit: int = 3) -> str:
    items = _as_string_list(value)
    if not items:
        return "(none)"
    visible = items[:limit]
    suffix = f" (+{len(items) - limit} more)" if len(items) > limit else ""
    return "; ".join(visible) + suffix


def _normalized_search_text(value: str) -> str:
    return " ".join(_SEARCH_TOKEN.findall(value.lower().replace("_", "-")))


def _search_terms(value: str) -> set[str]:
    """Return word tokens plus CJK n-grams so Chinese word order is not brittle."""
    normalized = _normalized_search_text(value)
    terms = set(_SEARCH_TOKEN.findall(normalized))
    for run in _CJK_RUN.findall(normalized):
        for width in (2, 3):
            terms.update(run[index : index + width] for index in range(len(run) - width + 1))
    return terms


class ResourceSkillRegistry:
    """Load resource skills and resolve their current local readiness."""

    def __init__(
        self,
        skill_roots: list[str | Path] | None = None,
        db_root: str | Path | None = None,
        environment_catalog: dict[str, str] | None = None,
        tolerate_invalid: bool = False,
    ):
        if skill_roots is None:
            skill_roots = [PACKAGE_SKILL_ROOT, os.environ.get("MICROBIOME_RESOURCE_SKILL_ROOT") or DEFAULT_CUSTOM_SKILL_ROOT]
        self.skill_roots = [Path(root).expanduser().resolve() for root in skill_roots]
        self.db_root = Path(db_root or os.environ.get("MICROBIOME_DB_ROOT") or DEFAULT_DB_ROOT).expanduser().resolve()
        self._provided_environment_catalog = environment_catalog
        self.tolerate_invalid = bool(tolerate_invalid)
        self.environment_catalog: dict[str, str] = {}
        self.skills: dict[tuple[str, str], ResourceSkill] = {}
        self.load_errors: dict[str, str] = {}
        self.manager_command = "conda"
        self.reload()

    def reload(self) -> None:
        """Reload skills and the conda environment catalog from disk."""
        loaded: dict[tuple[str, str], ResourceSkill] = {}
        load_errors: dict[str, str] = {}
        for root in self.skill_roots:
            if not root.is_dir():
                continue
            for path in sorted(root.glob("**/SKILL.md")):
                try:
                    skill = _parse_skill(path)
                except (OSError, SkillValidationError) as error:
                    if not self.tolerate_invalid:
                        raise
                    load_errors[str(path)] = f"{type(error).__name__}: {error}"
                    continue
                loaded[(skill.kind, skill.skill_id)] = skill
        self.skills = loaded
        self.load_errors = load_errors
        self.environment_catalog = (
            dict(self._provided_environment_catalog)
            if self._provided_environment_catalog is not None
            else self._discover_conda_environments()
        )

    def _discover_conda_environments(self) -> dict[str, str]:
        from microbiome.conda_discovery import find_conda_manager

        manager = find_conda_manager()
        if not manager:
            return {}
        # The manager's *full path* is used to query the environment catalog, but the
        # bare display name stays "conda" so plan-vs-preview command matching and the
        # "conda run -p" contract remain stable regardless of PATH.
        try:
            result = run_scoped_process(
                [manager, "env", "list", "--json"],
                capture_output=True,
                text=True,
                check=False,
                timeout=15,
            )
            if result.returncode != 0:
                return {}
            prefixes = json.loads(result.stdout).get("envs", [])
        except (OSError, subprocess.SubprocessError, json.JSONDecodeError):
            return {}

        catalog = {}
        for prefix in prefixes:
            prefix_path = Path(prefix)
            catalog[prefix_path.name] = str(prefix_path)
        return catalog

    def find_skill(self, kind: str, identifier: str) -> ResourceSkill | None:
        """Resolve a logical name to a skill without treating a missing skill as fatal.

        Planner names, package-family IDs, executable names, environment names and
        human aliases are deliberately different concepts.  Direct skill IDs win;
        any other name must identify exactly one skill. Shared interpreters or
        environments are discovery hints, never an arbitrary package binding.
        """

        normalized_kind = kind.lower()
        normalized = str(identifier).strip().lower()
        direct = self.skills.get((normalized_kind, normalized))
        if direct is not None:
            return direct

        matches: list[ResourceSkill] = []
        for skill in self.list_skills(normalized_kind):
            names = {
                skill.name.lower(),
                *[value.lower() for value in _as_string_list(skill.metadata.get("aliases"))],
            }
            if normalized_kind == "software":
                names.update(value.lower() for value in _as_string_list(skill.metadata.get("executables")))
                environment = str(skill.metadata.get("environment") or "").strip().lower()
                family = str(skill.metadata.get("software_family") or "").strip().lower()
                names.update(value for value in (environment, family) if value)
            else:
                folder = str(skill.metadata.get("folder") or "").strip().lower()
                if folder:
                    names.add(folder)
            if normalized in names:
                matches.append(skill)
        return matches[0] if len(matches) == 1 else None

    def get_skill(self, kind: str, skill_id: str) -> ResourceSkill:
        """Return a skill by ID, executable, environment, family, or alias."""
        skill = self.find_skill(kind, skill_id)
        if skill is None:
            raise KeyError(f"Unknown {kind} skill: {skill_id}")
        return skill

    def list_skills(self, kind: str | None = None) -> list[ResourceSkill]:
        """List loaded skills, optionally filtering by resource kind."""
        return sorted(
            (skill for skill in self.skills.values() if kind is None or skill.kind == kind.lower()),
            key=lambda skill: (skill.kind, skill.skill_id),
        )

    @staticmethod
    def _marker_ready(db_dir: Path, pattern: str) -> bool:
        matches = list(db_dir.glob(pattern))
        for path in matches:
            try:
                if path.is_file() and path.stat().st_size > 0:
                    return True
                if path.is_dir() and any(path.iterdir()):
                    return True
            except OSError:
                continue
        return False

    def database_status(self, skill_id: str, consumer: str | None = None) -> ResourceStatus:
        """Inspect one Database/<folder>/ against global or consumer-specific markers."""
        skill = self.get_skill("database", skill_id)
        folder = str(skill.metadata["folder"])
        db_dir = self.db_root / folder
        markers = _as_string_list(skill.metadata.get("required_markers"))
        if consumer:
            consumer_markers = skill.metadata.get("consumer_markers") or {}
            if not isinstance(consumer_markers, dict):
                raise SkillValidationError(f"{skill.path}: consumer_markers must be a mapping")
            profile_markers = _as_string_list(consumer_markers.get(consumer))
            if profile_markers:
                markers = [
                    *_as_string_list(skill.metadata.get("common_markers")),
                    *profile_markers,
                ]
        missing = tuple(marker for marker in markers if not self._marker_ready(db_dir, marker))
        from microbiome.resource_skills.contracts import validate_database_contract
        contract = skill.metadata.get("validation_contract", {})
        selector = skill.metadata.get("runtime_directory_marker")
        roots = [p.parent for p in db_dir.glob("**/" + selector)] if selector else [db_dir]
        if not any(not validate_database_contract(root, contract) for root in roots):
            missing += ("no complete consumer runtime directory",)
        if not missing:
            status = "ready"
        elif db_dir.is_dir() and any(db_dir.iterdir()):
            status = "needs_localization"
        else:
            status = "missing"
        return ResourceStatus(
            kind="database",
            skill_id=skill.skill_id,
            status=status,
            path=str(db_dir),
            missing=missing,
        )

    def software_status(self, skill_id: str) -> ResourceStatus:
        """Resolve a software skill to one isolated conda environment."""
        skill = self.get_skill("software", skill_id)
        environment = str(skill.metadata["environment"])
        prefix = self.environment_catalog.get(environment)
        create_command = self.environment_create_command(skill_id)
        executables = _as_string_list(skill.metadata.get("executables"))
        from microbiome.resource_skills.runtime import package_probe
        probe = package_probe(skill.metadata.get("runtime"))
        candidates = list(dict.fromkeys([p for p in [prefix, *self.environment_catalog.values()] if p]))
        for candidate in candidates:
            if not all((Path(candidate) / "bin" / exe).is_file() for exe in executables):
                continue
            if probe:
                executable = Path(candidate) / "bin" / executables[0]
                try:
                    result = run_scoped_process([str(executable), *probe[0]], capture_output=True,
                                            text=True, timeout=20, stdin=subprocess.DEVNULL, check=False)
                    if result.returncode != 0 or probe[1] not in result.stdout:
                        continue
                except (OSError, subprocess.TimeoutExpired):
                    continue
            prefix = candidate
            environment = Path(candidate).name
            break
        else:
            if probe:
                return ResourceStatus(kind="software", skill_id=skill.skill_id, status="missing_capability",
                                      environment=environment, missing=(str(skill.metadata['runtime']['package']),),
                                      create_command=create_command)
        if not prefix:
            return ResourceStatus(
                kind="software",
                skill_id=skill.skill_id,
                status="missing_environment",
                environment=environment,
                create_command=create_command,
            )

        missing = tuple(executable for executable in executables if not (Path(prefix) / "bin" / executable).exists())
        status = "ready" if not missing else "missing_executables"
        return ResourceStatus(
            kind="software",
            skill_id=skill.skill_id,
            status=status,
            path=prefix,
            environment=environment,
            missing=missing,
            command_prefix=(
                self.manager_command,
                "run",
                "-p",
                prefix,
                "--no-capture-output",
            ),
            create_command=create_command,
        )

    def _resolve_database_command(self, command: str) -> str:
        """Bind relative Skill examples to this registry's stable absolute DB root."""
        root = str(self.db_root)
        return (
            command.replace("out_dir='Database'", f"out_dir={root!r}")
            .replace('out_dir="Database"', f"out_dir={root!r}")
            .replace(" Database/", f" {root}/")
            .replace("`Database/", f"`{root}/")
        )

    def _resolve_software_command(self, command: str, environment: str | None, prefix: str | None) -> str:
        """Bind a Skill's ``conda run -n <env>`` examples to the resolved absolute prefix.

        Logical env names resolve against whichever conda root happens to be on PATH,
        so on machines with several conda installations ``conda run -n microbiome``
        can hit a root that never contained ``microbiome`` (EnvironmentLocationNotFound).
        Rewriting to ``conda run -p <absolute-prefix>`` makes the example deterministic.
        ``conda create/install -n`` is left alone: creation still uses the logical name.
        """
        if not prefix or not environment:
            return command
        pattern = re.compile(rf"\bconda\s+run\s+-n\s+{re.escape(environment)}\b", re.IGNORECASE)
        return pattern.sub(f"conda run -p {prefix}", command)

    def _bind_software_commands(self, command: str) -> str:
        """Rewrite every catalog-known ``conda run -n <env>`` to ``conda run -p <prefix>``.

        This also covers cross-references to *other* tools' environments inside a Skill
        body (e.g. a ``conda run -n seqkit`` example embedded in the MAFFT skill), not
        just the Skill's own declared environment.
        """
        for env, prefix in self.environment_catalog.items():
            if not env or not prefix:
                continue
            command = re.sub(
                rf"\bconda\s+run\s+-n\s+{re.escape(env)}\b",
                f"conda run -p {prefix}",
                command,
                flags=re.IGNORECASE,
            )
        return command

    @staticmethod
    def _executable_command(command: str) -> str | None:
        """Extract one concrete argv-style command from Skill guidance."""
        candidate = command.strip().strip("`")
        run_match = re.search(r"(?:then\s+run|run):\s*`?(.+?)`?$", candidate, re.IGNORECASE)
        if run_match:
            candidate = run_match.group(1).strip().strip("`")
        if not candidate or re.search(r"<[^>]+>", candidate):
            return None
        if re.match(
            r"^(?:use|after|before|extract|resolve|record|keep|verify|validate|point|build|"
            r"if|for|place|when|once|only|this|the|no)\b",
            candidate,
            re.IGNORECASE,
        ):
            return None
        try:
            tokens = shlex.split(candidate)
        except ValueError:
            return None
        if not tokens or tokens[0].lower() in {"use", "after", "then", "run"}:
            return None
        return candidate

    def database_execution_commands(
        self,
        resource_id: str,
        plan_text: str = "",
    ) -> tuple[list[str], list[str]]:
        """Return machine-executable acquisition and localization commands."""
        skill_id, separator, consumer = resource_id.partition(":")
        consumer = consumer if separator else ""
        skill = self.get_skill("database", skill_id)
        commands = _as_string_list(skill.metadata.get("acquisition_commands"))
        consumer_commands = skill.metadata.get("consumer_acquisition_commands") or {}
        if consumer and isinstance(consumer_commands, dict) and consumer_commands.get(consumer):
            commands = _as_string_list(consumer_commands[consumer])
        if skill_id == "reference-genomes":
            exact_reference_call = self._reference_genome_call_from_plan(plan_text, self.db_root)
            commands = [exact_reference_call] if exact_reference_call else []
        if skill_id == "reference-sequences":
            exact_sequence_call = self._reference_sequence_call_from_plan(plan_text, self.db_root)
            commands = [exact_sequence_call] if exact_sequence_call else []
        if skill_id == "virus-genomes":
            exact_virus_call = self._virus_genome_call_from_plan(plan_text, self.db_root)
            commands = [exact_virus_call] if exact_virus_call else []

        localization = _as_string_list(skill.metadata.get("localization_commands"))
        consumer_localization = skill.metadata.get("consumer_localization_commands") or {}
        if consumer and isinstance(consumer_localization, dict) and consumer_localization.get(consumer):
            localization = _as_string_list(consumer_localization[consumer])

        acquisition_commands = [
            self._resolve_database_command(executable)
            for command in commands
            if (executable := self._executable_command(command))
        ]
        localization_commands = [
            self._resolve_database_command(executable)
            for command in localization
            if (executable := self._executable_command(command))
        ]
        if skill_id == "gtdbtk":
            localization_commands.append(
                shlex.join(
                    [
                        sys.executable,
                        "-m",
                        "microbiome.resource_skills.acquisition",
                        "localize",
                        "--database",
                        "gtdbtk",
                        "--db-root",
                        str(self.db_root),
                    ]
                )
            )
        if skill_id == "nr":
            localization_commands = [
                command.replace(f"{self.db_root}/nr/nr.faa", f"{self.db_root}/nr/nr.gz")
                for command in localization_commands
            ]
        return acquisition_commands, list(dict.fromkeys(localization_commands))

    @staticmethod
    def _command_environment_names(command: str) -> list[str]:
        names = []
        try:
            tokens = shlex.split(command)
        except ValueError:
            tokens = []
        if tokens and Path(tokens[0]).name in {"conda", "mamba", "micromamba"} and "run" in tokens:
            for flag in ("-n", "--name"):
                if flag in tokens and tokens.index(flag) + 1 < len(tokens):
                    names.append(tokens[tokens.index(flag) + 1])
        names.extend(re.findall(r"\benv\s*=\s*['\"]([a-zA-Z0-9_.-]+)['\"]", command))
        if command.startswith(("download_reference_genome(", "download_virus_genomes(")):
            source = re.search(r"\bsource\s*=\s*['\"]([a-z-]+)['\"]", command)
            if source:
                names.append("biomni-gget" if source.group(1) == "gget" else "biomni-ncbi-datasets")
        if command.startswith("download_reference_sequences("):
            names.append("biomni-ncbi-edirect")
        return list(dict.fromkeys(names))

    def database_environment_create_commands(self, resource_id: str, plan_text: str = "") -> list[str]:
        """Return creation commands for environments required by acquisition commands."""
        acquisition, localization = self.database_execution_commands(resource_id, plan_text=plan_text)
        environment_names = []
        for command in [*acquisition, *localization]:
            environment_names.extend(self._command_environment_names(command))
        commands = []
        for environment in dict.fromkeys(environment_names):
            if environment in self.environment_catalog:
                continue
            matching = [
                skill for skill in self.list_skills("software") if str(skill.metadata.get("environment")) == environment
            ]
            if not matching:
                continue
            command = self.environment_create_command(matching[0].skill_id)
            for segment in command.split(" && "):
                if segment not in commands:
                    commands.append(segment)
        return commands

    def environment_create_command(self, skill_id: str) -> str:
        """Render one complete creation command for a skill's shared environment."""
        skill = self.get_skill("software", skill_id)
        environment = str(skill.metadata["environment"])
        environment_skills = [
            candidate
            for candidate in self.list_skills("software")
            if str(candidate.metadata["environment"]) == environment
        ]

        environment_files = {
            str(candidate.metadata["environment_file"])
            for candidate in environment_skills
            if candidate.metadata.get("environment_file")
        }
        if environment_files:
            if len(environment_files) != 1:
                raise SkillValidationError(
                    f"Environment {environment!r} declares multiple environment files: "
                    f"{', '.join(sorted(environment_files))}"
                )
            manager = "mamba" if shutil.which("mamba") else self.manager_command
            return shlex.join([manager, "env", "create", "-y", "-n", environment, "-f", next(iter(environment_files))])

        def unique_metadata(field: str) -> list[str]:
            values = []
            for candidate in environment_skills:
                for value in _as_string_list(candidate.metadata.get(field)):
                    if value not in values:
                        values.append(value)
            return values

        packages = unique_metadata("packages")
        channels = unique_metadata("channels") or ["conda-forge", "bioconda"]
        manager = "mamba" if shutil.which("mamba") else self.manager_command
        args = [manager, "create", "-y", "-n", environment]
        for channel in channels:
            args.extend(["-c", channel])
        args.extend(packages)
        command = shlex.join(args)
        pip_packages = unique_metadata("pip_packages")
        if pip_packages:
            pip_args = [
                self.manager_command,
                "run",
                "-n",
                environment,
                "--no-capture-output",
                "python",
                "-m",
                "pip",
                "install",
                *pip_packages,
            ]
            command = f"{command} && {shlex.join(pip_args)}"
        return command

    def environment_repair_command(self, skill_id: str) -> str:
        """Render the repair command for an existing environment with missing executables."""
        skill = self.get_skill("software", skill_id)
        environment = str(skill.metadata["environment"])
        environment_skills = [
            candidate
            for candidate in self.list_skills("software")
            if str(candidate.metadata["environment"]) == environment
        ]
        environment_files = {
            str(candidate.metadata["environment_file"])
            for candidate in environment_skills
            if candidate.metadata.get("environment_file")
        }
        manager = "mamba" if shutil.which("mamba") else self.manager_command
        if environment_files:
            return shlex.join([manager, "env", "update", "-n", environment, "-f", next(iter(environment_files))])

        def unique_metadata(field: str) -> list[str]:
            values = []
            for candidate in environment_skills:
                for value in _as_string_list(candidate.metadata.get(field)):
                    if value not in values:
                        values.append(value)
            return values

        packages = unique_metadata("packages")
        channels = unique_metadata("channels") or ["conda-forge", "bioconda"]
        args = [manager, "install", "-y", "-n", environment]
        for channel in channels:
            args.extend(["-c", channel])
        args.extend(packages)
        command = shlex.join(args)
        pip_packages = unique_metadata("pip_packages")
        if pip_packages:
            pip_args = [
                self.manager_command,
                "run",
                "-n",
                environment,
                "--no-capture-output",
                "python",
                "-m",
                "pip",
                "install",
                *pip_packages,
            ]
            command = f"{command} && {shlex.join(pip_args)}"
        return command

    def _software_action_hint(self, status: ResourceStatus) -> str:
        """Render the status-aware provisioning action for one software binding line."""
        if status.status == "missing_executables":
            missing = ", ".join(status.missing) or "unknown"
            return (
                f"planned-repair={self.environment_repair_command(status.skill_id)} "
                f"missing={missing} (auto-repaired after plan confirmation; plan normally, "
                f"never refuse the task over this)"
            )
        return (
            f"planned-create={status.create_command} "
            "(auto-created after plan confirmation; plan normally, never refuse the task over this)"
        )

    def _skill_match_score(self, skill: ResourceSkill, text: str) -> int:
        normalized = _normalized_search_text(text)
        tokens = _search_terms(normalized)
        score = 0
        identifiers = [skill.skill_id, skill.name, *_as_string_list(skill.metadata.get("aliases"))]
        for identifier in identifiers:
            candidate = _normalized_search_text(identifier)
            if candidate and candidate in normalized:
                score = max(score, 100 + len(candidate))
        searchable = [
            skill.name,
            skill.description,
            *_as_string_list(skill.metadata.get("aliases")),
            *_as_string_list(skill.metadata.get("keywords")),
            *_as_string_list(skill.metadata.get("tasks")),
            *_as_string_list(skill.metadata.get("capabilities")),
        ]
        for phrase in searchable:
            normalized_phrase = _normalized_search_text(phrase)
            if normalized_phrase and normalized_phrase in normalized:
                score += min(24, max(9, len(normalized_phrase)))
            phrase_tokens = _search_terms(normalized_phrase)
            overlap = {
                token
                for token in phrase_tokens & tokens
                if len(token) >= 3 or (token and "\u4e00" <= token[0] <= "\u9fff")
            }
            score += sum(4 if "\u4e00" <= token[0] <= "\u9fff" else 3 for token in overlap)
            if len(phrase_tokens) > 1 and phrase_tokens <= tokens:
                score += 8
        for phrase in _as_string_list(skill.metadata.get("excludes")):
            normalized_phrase = _normalized_search_text(phrase)
            if normalized_phrase and normalized_phrase in normalized:
                score -= 100
        return max(0, score)

    def relevant_skills(self, text: str, max_skills: int = 10) -> list[ResourceSkill]:
        """Select mentioned skills, then add their declared workflow neighbours."""
        ranked = sorted(
            ((self._skill_match_score(skill, text), skill) for skill in self.list_skills()),
            key=lambda item: (-item[0], item[1].kind, item[1].skill_id),
        )
        selected = [skill for score, skill in ranked if score >= 8][:max_skills]
        selected_keys = {(skill.kind, skill.skill_id) for skill in selected}

        related = []
        for skill in selected:
            for field in (
                "upstream",
                "downstream",
                "databases",
                "optional_databases",
                "compatible_software",
            ):
                for value in _as_string_list(skill.metadata.get(field)):
                    related.extend(
                        candidate
                        for candidate in self.list_skills()
                        if candidate.skill_id == value.lower()
                        and (candidate.kind, candidate.skill_id) not in selected_keys
                    )
        for skill in related:
            if len(selected) >= max_skills:
                break
            key = (skill.kind, skill.skill_id)
            if key not in selected_keys:
                selected.append(skill)
                selected_keys.add(key)
        return selected

    def detailed_context(self, text: str, max_skills: int = 10, max_chars: int = 32000) -> str:
        """Render full guidance for skills selected from a task or draft plan."""
        sections = []
        used = 0
        for skill in self.relevant_skills(text, max_skills=max_skills):
            status = (
                self.database_status(skill.skill_id)
                if skill.kind == "database"
                else self.software_status(skill.skill_id)
            )
            header = (
                f"## {skill.kind}:{skill.skill_id} [{status.status.upper()}]\n"
                f"Source: {skill.path}\nDescription: {skill.description}\n"
            )
            body = skill.body.strip()
            if skill.kind == "software":
                # Rewrite every catalog-known `conda run -n <env>` (the Skill's own
                # environment plus any cross-referenced tool environments) to the
                # verified absolute `conda run -p <prefix>`, so the model cannot
                # reintroduce a name lookup that resolves against a different conda
                # root (the recurring EnvironmentLocationNotFound).
                body = self._bind_software_commands(body)
            elif skill.kind == "database":
                # Bind relative `Database/...` examples to the absolute DB root so a
                # CWD-dependent path cannot be re-inferred by the planner/executor.
                body = self._resolve_database_command(body)
            section = f"{header}\n{body}"
            if used + len(section) > max_chars:
                break
            sections.append(section)
            used += len(section)
        if not sections:
            return ""
        return "\n\n".join(["# TASK-RELEVANT RESOURCE SKILL GUIDANCE", *sections])

    def effective_resources(self) -> dict[str, Any]:
        """Render the effective software/database bindings for a diagnostic snapshot.

        The point is to make a registry-vs-skill mismatch visible at a glance:
        the registry's verified absolute prefix/entrypoint is shown next to the
        logical names / relative paths that the Skill body still suggests, so a
        ``conda run -n`` vs ``conda run -p`` or a CWD-dependent ``Database/`` path
        cannot hide behind a "ready" status.
        """
        software: dict[str, Any] = {}
        for skill in self.list_skills("software"):
            status = self.software_status(skill.skill_id)
            executables = _as_string_list(skill.metadata.get("executables"))
            software[skill.skill_id] = {
                "status": status.status,
                "environment_name": status.environment,
                "conda_prefix": status.path,
                "invoke": shlex.join(status.command_prefix) if status.command_prefix else None,
                "executables": {
                    exe: (str(Path(status.path) / "bin" / exe) if status.path else None)
                    for exe in executables
                },
                "skill_body_env_refs": sorted(set(re.findall(r"conda\s+run\s+-n\s+([^\s`]+)", skill.body))),
                "missing_executables": list(status.missing),
            }
        databases: dict[str, Any] = {}
        for skill in self.list_skills("database"):
            status = self.database_status(skill.skill_id)
            databases[skill.skill_id] = {
                "status": status.status,
                "folder": str(skill.metadata.get("folder")),
                "root_path": str(self.db_root / str(skill.metadata["folder"])),
                "verified_path": status.path,
                "missing_markers": list(status.missing),
                "skill_body_db_refs": sorted(set(re.findall(r"Database/[\w./+~-]+", skill.body))),
            }
        return {
            "database_root": str(self.db_root),
            "conda_manager": self.manager_command,
            "software": software,
            "databases": databases,
        }

    def skill_details(self, kind: str, skill_id: str) -> str:
        """Return one complete skill document with current readiness."""
        skill = self.get_skill(kind, skill_id)
        status = self.database_status(skill_id) if skill.kind == "database" else self.software_status(skill_id)
        metadata = yaml.safe_dump(skill.metadata, sort_keys=False, allow_unicode=True).strip()
        return (
            f"# {skill.kind}:{skill.skill_id} [{status.status.upper()}]\n"
            f"Source: {skill.path}\n\n---\n{metadata}\n---\n\n{skill.body}"
        )

    def planning_context(self, query: str | None = None) -> str:
        """Return a deterministic, readiness-ranked context for the planner."""
        relevant_keys: set[tuple[str, str]] | None = None
        if query:
            relevant = self.relevant_skills(query, max_skills=14)
            relevant_keys = {(skill.kind, skill.skill_id) for skill in relevant}
            for skill in relevant:
                if skill.kind == "software":
                    for field in ("databases", "optional_databases"):
                        relevant_keys.update(
                            ("database", database_id.lower())
                            for database_id in _as_string_list(skill.metadata.get(field))
                            if ("database", database_id.lower()) in self.skills
                        )

        database_rows = []
        for skill in self.list_skills("database"):
            status = self.database_status(skill.skill_id)
            database_rows.append((status.status != "ready", skill.skill_id, skill, status))
        software_rows = []
        for skill in self.list_skills("software"):
            status = self.software_status(skill.skill_id)
            software_rows.append((status.status != "ready", skill.skill_id, skill, status))

        lines = [
            "# LOCAL RESOURCE SKILLS",
            "READY + SKILL resources have the highest planning priority. Skills needing preparation come next; unskilled or external resources are last.",
            f"Database root: {self.db_root}",
            "",
            "## Database skills (readiness-ranked)",
        ]
        if not database_rows:
            lines.append("- (none registered)")
        compact_databases: list[str] = []
        for _not_ready, skill_id, skill, status in sorted(database_rows):
            label = status.status.upper()
            if relevant_keys is not None and ("database", skill_id) not in relevant_keys:
                compact_databases.append(skill_id)
                continue
            compatible = ", ".join(_as_string_list(skill.metadata.get("compatible_software")))
            markers = ", ".join(_as_string_list(skill.metadata.get("required_markers")))
            consumer_markers = skill.metadata.get("consumer_markers") or {}
            consumer_readiness = ""
            if isinstance(consumer_markers, dict) and consumer_markers:
                profile_labels = [
                    f"{consumer}:{self.database_status(skill_id, consumer).status.upper()}"
                    for consumer in sorted(consumer_markers)
                ]
                consumer_readiness = f" consumer_readiness={','.join(profile_labels)}"
            lines.append(
                f"- {skill_id} [{label}] folder=Database/{skill.metadata['folder']} "
                f"software={compatible} required_markers={markers} verified_path={status.path} "
                f"description={skill.description} contents={_compact_list(skill.metadata.get('contents'))} "
                f"formats={_compact_list(skill.metadata.get('formats'))}{consumer_readiness}"
            )
            lines.append(
                f"  selection: advantages={_compact_list(skill.metadata.get('advantages'))}; "
                f"limitations={_compact_list(skill.metadata.get('limitations'))}; "
                f"estimated_size={skill.metadata.get('estimated_size') or 'not documented'}; "
                f"acquisition_mode={skill.metadata.get('acquisition_mode', 'manual')}"
            )
            if skill.metadata.get("itemized"):
                manifest_glob = str(skill.metadata.get("item_manifest_glob", "*/release-manifest.yaml"))
                manifests = []
                for manifest_path in sorted((self.db_root / str(skill.metadata["folder"])).glob(manifest_glob)):
                    try:
                        manifest = yaml.safe_load(manifest_path.read_text(encoding="utf-8")) or {}
                    except (OSError, yaml.YAMLError):
                        continue
                    manifests.append(
                        f"{manifest.get('identifier', manifest_path.parent.name)}|"
                        f"{manifest.get('source', '?')}|{manifest.get('release') or 'current'}|"
                        f"{','.join(_as_string_list(manifest.get('assets')))}"
                    )
                lines.append(
                    "  itemized inventory (identifier|source|release|assets): "
                    + ("; ".join(manifests[:20]) if manifests else "(none)")
                )
            if status.status != "ready":
                urls = _as_string_list(skill.metadata.get("download_urls"))
                acquisition_commands = _as_string_list(skill.metadata.get("acquisition_commands"))
                commands = _as_string_list(skill.metadata.get("localization_commands"))
                if urls:
                    lines.append(f"  download sources: {'; '.join(urls)}")
                if acquisition_commands:
                    lines.append(
                        "  approved-acquisition commands: "
                        + "; ".join(self._resolve_database_command(command) for command in acquisition_commands)
                    )
                if commands:
                    lines.append(
                        "  localization after placement: "
                        + "; ".join(self._resolve_database_command(command) for command in commands)
                    )
                if status.missing:
                    lines.append(f"  missing format markers: {', '.join(status.missing)}")
        if compact_databases:
            lines.append("### Other database skills (compact catalog; still available for consideration)")
            lines.append(
                f"- registered IDs (status omitted because they are not task-selected): {', '.join(compact_databases)}"
            )

        lines.extend(["", "## Software skills (readiness-ranked)"])
        if not software_rows:
            lines.append("- (none registered)")
        compact_software: dict[str, list[str]] = {}
        for _not_ready, skill_id, skill, status in sorted(software_rows):
            tasks = ", ".join(_as_string_list(skill.metadata.get("tasks")))
            databases = ", ".join(_as_string_list(skill.metadata.get("databases"))) or "(none)"
            optional_databases = ", ".join(_as_string_list(skill.metadata.get("optional_databases"))) or "(none)"
            selection_tier = str(skill.metadata.get("selection_tier", "established"))
            if relevant_keys is not None and ("software", skill_id) not in relevant_keys:
                compact_software.setdefault(selection_tier, []).append(skill_id)
                continue
            line = (
                f"- {skill_id} [{status.status.upper()}] env={status.environment} "
                f"selection_tier={selection_tier} tasks={tasks} databases={databases} "
                f"optional_databases={optional_databases} "
                f"description={skill.description} "
                f"inputs={_compact_list(skill.metadata.get('inputs'))} "
                f"outputs={_compact_list(skill.metadata.get('outputs'))} "
                f"upstream={_compact_list(skill.metadata.get('upstream'))} "
                f"downstream={_compact_list(skill.metadata.get('downstream'))}"
            )
            if status.command_prefix:
                line += f" invoke={shlex.join(status.command_prefix)}"
            else:
                line += f" {self._software_action_hint(status)}"
            lines.append(line)
        if compact_software:
            lines.append("### Other software skills (compact catalog; still available for consideration)")
            for selection_tier, skill_ids in sorted(compact_software.items()):
                lines.append(
                    f"- selection_tier={selection_tier} registered IDs "
                    f"(status omitted because they are not task-selected): {', '.join(skill_ids)}"
                )

        lines.extend(
            [
                "",
                "## Mandatory planning policy",
                "- Prefer READY database and software skills before any unskilled or externally researched resource.",
                "- READY is a verified local fact. Do not ask the user to confirm its files, and do not propose downloading or rebuilding it unless execution later proves it changed.",
                "- For overlapping capabilities, prefer selection_tier=default. Select conditional skills only when their stated input, biological, or validation conditions materially improve the workflow.",
                "- Compare scientifically suitable database choices by local readiness, scope, advantages, limitations, release, size, and consumer format. Local READY resources remain the default.",
                "- For an itemized collection, collection-level READY does not prove the requested organism/release/assets are local. Match its manifest exactly; otherwise propose a new item acquisition.",
                "- A missing database may be acquired only when the plan includes its deterministic MICROBIOME_DB_ACQUISITION marker, exact Database/<database-id>/ target, source, acquisition/localization commands, and the user confirms that plan. Manual/license-gated resources remain blockers.",
                "- MISSING_ENVIRONMENT and MISSING_EXECUTABLES are auto-provisioning states, never blockers: the environment is created or repaired automatically once the plan is confirmed, so plan normally with the planned-create/planned-repair action and never refuse or shortcut the task because of them.",
                "- Name every new conda environment in the plan before execution. Invoke each software with its own conda run prefix; never chain conda activate calls.",
                "- The first confirmed execution is an end-to-end pilot on a tiny representative subset. Full-scale data may run only after the pilot is verified and the user confirms again.",
            ]
        )
        if query:
            details = self.detailed_context(query, max_skills=6, max_chars=17500)
            if details:
                lines.extend(["", details])
        return "\n".join(lines)

    def referenced_missing_databases(self, text: str) -> list[str]:
        """Return missing database skills materially referenced by a plan."""
        lowered = text.lower()
        referenced = []
        for skill in self.list_skills("database"):
            direct_path = f"database/{skill.metadata['folder']}".lower()
            if direct_path not in lowered:
                continue
            consumer_markers = skill.metadata.get("consumer_markers") or {}
            matched_profiles = []
            if isinstance(consumer_markers, dict):
                matched_profiles = [
                    consumer for consumer in consumer_markers if self._mentions_skill(text, str(consumer))
                ]
            if matched_profiles:
                referenced.extend(
                    f"{skill.skill_id}:{consumer}"
                    for consumer in matched_profiles
                    if self.database_status(skill.skill_id, str(consumer)).status != "ready"
                )
            elif self.database_status(skill.skill_id).status != "ready":
                referenced.append(skill.skill_id)
        return referenced

    @staticmethod
    def planned_database_acquisitions(text: str) -> set[str]:
        """Return database/profile IDs explicitly proposed in a plan."""
        acquisitions = set()
        for skill_id, consumer in _DATABASE_ACQUISITION_RE.findall(text or ""):
            acquisitions.add(f"{skill_id.lower()}:{consumer.lower()}" if consumer else skill_id.lower())
        return acquisitions

    def database_acquisition_candidates(self, text: str) -> list[str]:
        """Find missing or explicitly requested non-manual acquisitions in a draft plan."""
        candidates = list(self.referenced_missing_databases(text))
        lowered = text.lower()
        acquisition_intent = bool(
            re.search(
                r"(?:download_reference_genome|download_reference_sequences|download_virus_genomes|download_database|ensure_database|\bgget\s+ref\b|"
                r"\bgget\s+virus\b|\bdatasets\s+download\b|\bwget\b|\bcurl\b|下载|获取|拉取|新建数据库)",
                lowered,
            )
        )
        if acquisition_intent:
            selected_ids = {item.partition(":")[0] for item in candidates}
            for skill in self.list_skills("database"):
                if str(skill.metadata.get("acquisition_mode", "manual")) == "manual":
                    continue
                if not skill.metadata.get("itemized"):
                    continue
                direct_path = f"database/{skill.metadata['folder']}".lower()
                if direct_path in lowered and skill.skill_id not in selected_ids:
                    candidates.append(skill.skill_id)
                    selected_ids.add(skill.skill_id)
        return candidates

    @classmethod
    def _reference_genome_call_from_plan(cls, text: str, db_root: Path) -> str | None:
        """Convert a concrete planned reference-genome download into the controlled wrapper call."""
        text = text or ""
        matches = []
        for match in re.finditer(r"download_reference_genome\((.*?)\)", text, flags=re.DOTALL):
            args = " ".join(match.group(1).split())
            if re.search(r"<[^>]+>", args):
                continue
            if not re.search(r"\bapproved\s*=\s*True\b", args):
                continue
            if not re.search(r"\bidentifier\s*=\s*['\"][^'\"]+['\"]", args):
                continue
            if "db_root" not in args:
                args = f"{args}, db_root={str(db_root)!r}"
            matches.append(f"download_reference_genome({args})")
        if matches:
            return matches[0]
        blocks = re.findall(r"```(?:bash|sh)?\s*(.*?)```", text, flags=re.DOTALL | re.IGNORECASE)
        for block in blocks:
            normalized = re.sub(r"\\\s*\n", " ", block)
            try:
                tokens = shlex.split(normalized)
            except ValueError:
                continue
            call = cls._gget_reference_call_from_tokens(tokens, db_root) or cls._datasets_reference_call_from_tokens(
                tokens, db_root
            )
            if call:
                return call
        return None

    @classmethod
    def _reference_sequence_call_from_plan(cls, text: str, db_root: Path) -> str | None:
        """Extract the exact reviewed-accession sequence acquisition wrapper call."""
        text = text or ""
        for match in re.finditer(r"download_reference_sequences\((.*?)\)", text, flags=re.DOTALL):
            args = " ".join(match.group(1).split())
            if re.search(r"<[^>]+>", args):
                continue
            if not re.search(r"\bapproved\s*=\s*True\b", args):
                continue
            if not re.search(r"\baccessions\s*=\s*[\['\"]", args):
                continue
            if "db_root" not in args:
                args = f"{args}, db_root={str(db_root)!r}"
            return f"download_reference_sequences({args})"
        return None

    @classmethod
    def _sra_runs_call_from_plan(cls, text: str, db_root: Path) -> str | None:
        """Convert a concrete planned SRA download into the controlled wrapper call."""
        text = text or ""
        matches = []
        for match in re.finditer(r"download_sra_runs\((.*?)\)", text, flags=re.DOTALL):
            args = " ".join(match.group(1).split())
            if re.search(r"<[^>]+>", args):
                continue
            if not re.search(r"\bapproved\s*=\s*True\b", args):
                continue
            if not re.search(r"\baccessions\s*=\s*[\['\"]", args):
                continue
            if "db_root" not in args:
                args = f"{args}, db_root={str(db_root)!r}"
            matches.append(f"download_sra_runs({args})")
        if matches:
            return matches[0]
        blocks = re.findall(r"```(?:bash|sh)?\s*(.*?)```", text, flags=re.DOTALL | re.IGNORECASE)
        for block in blocks:
            if "prefetch" not in block and "fasterq-dump" not in block:
                continue
            accessions = list(dict.fromkeys(re.findall(r"\b[SED]RR\d+\b", block)))
            if accessions:
                return f"download_sra_runs(accessions={accessions!r}, db_root={str(db_root)!r}, approved=True)"
        return None

    @staticmethod
    def _gget_reference_call_from_tokens(tokens: list[str], db_root: Path) -> str | None:
        """Convert planned `gget ref` tokens into the controlled wrapper call."""
        for index in range(len(tokens) - 1):
            if tokens[index : index + 2] != ["gget", "ref"]:
                continue
            args = tokens[index + 2 :]
            if "-d" not in args and "--download" not in args:
                continue
            assets = "dna,gtf"
            release = None
            identifier = None
            position = 0
            options_with_value = {"-w", "--which", "-r", "--release", "-od", "--out_dir"}
            while position < len(args):
                token = args[position]
                if token in options_with_value and position + 1 < len(args):
                    value = args[position + 1]
                    if token in {"-w", "--which"}:
                        assets = value
                    elif token in {"-r", "--release"}:
                        try:
                            release = int(value)
                        except ValueError:
                            release = None
                    position += 2
                    continue
                if token.startswith("-"):
                    position += 1
                    continue
                identifier = token
                position += 1
            if identifier:
                return (
                    "download_reference_genome("
                    f"identifier={identifier!r}, assets={assets!r}, release={release!r}, "
                    f"source='gget', db_root={str(db_root)!r}, approved=True)"
                )
        return None

    @staticmethod
    def _datasets_reference_call_from_tokens(tokens: list[str], db_root: Path) -> str | None:
        """Convert planned `datasets download genome` tokens into the controlled wrapper call."""
        reverse_assets = {
            "genome": "dna",
            "gff3": "gff3",
            "gbff": "gbff",
            "protein": "protein",
            "rna": "rna",
            "cds": "cds",
        }
        for index in range(len(tokens) - 3):
            if tokens[index : index + 3] != ["datasets", "download", "genome"]:
                continue
            args = tokens[index + 3 :]
            object_type = None
            identifier = None
            includes = None
            reference_only = False
            assembly_level = None
            annotated = False
            position = 0
            while position < len(args):
                token = args[position]
                if token in {"accession", "taxon"} and position + 1 < len(args):
                    object_type = token
                    identifier = args[position + 1]
                    position += 2
                    continue
                if token == "--include" and position + 1 < len(args):
                    includes = args[position + 1]
                    position += 2
                    continue
                if token == "--assembly-level" and position + 1 < len(args):
                    assembly_level = args[position + 1]
                    position += 2
                    continue
                if token in {"--filename", "--assembly-source", "--api-key"} and position + 1 < len(args):
                    position += 2
                    continue
                if token == "--reference":
                    reference_only = True
                    position += 1
                    continue
                if token == "--annotated":
                    annotated = True
                    position += 1
                    continue
                if token.startswith("-"):
                    position += 1
                    continue
                position += 1
            if not identifier:
                continue
            parts = [f"identifier={identifier!r}"]
            if includes:
                assets = [
                    reverse_assets.get(item.strip(), item.strip()) for item in includes.split(",") if item.strip()
                ]
                if assets:
                    parts.append(f"assets={','.join(assets)!r}")
            parts.append("source='ncbi-datasets'")
            if object_type == "taxon":
                parts.append(f"reference_only={reference_only!r}")
                if assembly_level:
                    parts.append(f"assembly_level={assembly_level!r}")
                if annotated:
                    parts.append("annotated=True")
            parts.append(f"db_root={str(db_root)!r}")
            parts.append("approved=True")
            return f"download_reference_genome({', '.join(parts)})"
        return None

    @staticmethod
    def _gget_virus_call_from_tokens(tokens: list[str], db_root: Path) -> str | None:
        """Convert a concrete `gget virus` argv into the controlled wrapper call."""
        options = {
            "--nuc_completeness": "nuc_completeness",
            "--host": "host",
            "--segment": "segment",
            "--source_database": "source_database",
            "--min_release_date": "min_date",
            "--max_release_date": "max_date",
            "--min_seq_length": "min_length",
            "--max_seq_length": "max_length",
        }
        for index in range(len(tokens) - 1):
            if tokens[index : index + 2] != ["gget", "virus"]:
                continue
            args = tokens[index + 2 :]
            values: dict[str, str] = {}
            annotated = False
            is_accession = False
            identifiers = []
            position = 0
            while position < len(args):
                token = args[position]
                if token in options and position + 1 < len(args):
                    values[options[token]] = args[position + 1]
                    position += 2
                    continue
                if token == "--annotated":
                    if position + 1 < len(args) and args[position + 1].lower() in {"true", "false"}:
                        annotated = args[position + 1].lower() == "true"
                        position += 2
                    else:
                        annotated = True
                        position += 1
                    continue
                if token == "--is_accession":
                    is_accession = True
                    position += 1
                    continue
                if token in {"-od", "--out_dir", "-o", "--out"} and position + 1 < len(args):
                    position += 2
                    continue
                if token.startswith("-"):
                    position += 1
                    continue
                identifiers.append(token)
                position += 1
            if identifiers:
                parts = [f"accessions={identifiers!r}"] if is_accession else [f"virus={identifiers[0]!r}"]
                parts.extend(f"{key}={value!r}" for key, value in values.items())
                if annotated:
                    parts.append("annotated=True")
                parts.append("source='gget'")
                parts.append(f"db_root={str(db_root)!r}")
                parts.append("approved=True")
                return f"download_virus_genomes({', '.join(parts)})"
        return None

    @staticmethod
    def _datasets_virus_call_from_tokens(tokens: list[str], db_root: Path) -> str | None:
        """Convert a concrete `datasets download virus genome` argv into the wrapper call."""
        for index in range(len(tokens) - 3):
            if tokens[index : index + 4] != ["datasets", "download", "virus", "genome"]:
                continue
            args = tokens[index + 4 :]
            if any(flag in args for flag in ("--released-before", "--min-length", "--max-length")):
                continue
            virus = None
            accession_values = None
            host = None
            min_date = None
            complete = False
            position = 0
            while position < len(args):
                token = args[position]
                if token == "taxon" and position + 1 < len(args):
                    virus = args[position + 1]
                    position += 2
                    continue
                if token == "accession" and position + 1 < len(args):
                    accession_values = args[position + 1]
                    position += 2
                    continue
                if token == "--host" and position + 1 < len(args):
                    host = args[position + 1]
                    position += 2
                    continue
                if token == "--released-after" and position + 1 < len(args):
                    min_date = args[position + 1]
                    position += 2
                    continue
                if token == "--complete-only":
                    complete = True
                    position += 1
                    continue
                if token in {"--filename", "--include"} and position + 1 < len(args):
                    position += 2
                    continue
                if token.startswith("-"):
                    position += 1
                    continue
                position += 1
            if virus or accession_values:
                parts = []
                if virus:
                    parts.append(f"virus={virus!r}")
                if accession_values:
                    parts.append(f"accessions={accession_values!r}")
                if host:
                    parts.append(f"host={host!r}")
                if min_date:
                    parts.append(f"min_date={min_date!r}")
                if complete:
                    parts.append("nuc_completeness='complete'")
                parts.append("source='ncbi-datasets'")
                parts.append(f"db_root={str(db_root)!r}")
                parts.append("approved=True")
                return f"download_virus_genomes({', '.join(parts)})"
        return None

    @classmethod
    def _virus_genome_call_from_plan(cls, text: str, db_root: Path) -> str | None:
        """Convert a concrete planned virus download into the controlled wrapper call."""
        text = text or ""
        matches = []
        for match in re.finditer(r"download_virus_genomes\((.*?)\)", text, flags=re.DOTALL):
            args = " ".join(match.group(1).split())
            if re.search(r"<[^>]+>", args):
                continue
            if not re.search(r"\bapproved\s*=\s*True\b", args):
                continue
            if not re.search(r"\bvirus\s*=\s*['\"][^'\"]+['\"]", args) and not re.search(
                r"\baccessions\s*=\s*(?:\[|'|\")", args
            ):
                continue
            if "db_root" not in args:
                args = f"{args}, db_root={str(db_root)!r}"
            matches.append(f"download_virus_genomes({args})")
        if matches:
            preferred = [call for call in matches if "source='gget'" in call]
            return preferred[0] if preferred else matches[0]
        blocks = re.findall(r"```(?:bash|sh)?\s*(.*?)```", text, flags=re.DOTALL | re.IGNORECASE)
        for block in blocks:
            normalized = re.sub(r"\\\s*\n", " ", block)
            try:
                tokens = shlex.split(normalized)
            except ValueError:
                continue
            call = cls._gget_virus_call_from_tokens(tokens, db_root) or cls._datasets_virus_call_from_tokens(
                tokens, db_root
            )
            if call:
                return call
        return None

    def database_acquisition_guidance(self, skill_ids: list[str], plan_text: str = "") -> str:
        """Render deterministic acquisition proposals for missing selected databases."""
        sections = []
        for resource_id in skill_ids:
            skill_id, separator, consumer = resource_id.partition(":")
            consumer = consumer if separator else ""
            skill = self.get_skill("database", skill_id)
            mode = str(skill.metadata.get("acquisition_mode", "manual"))
            commands, localization = self.database_execution_commands(resource_id, plan_text=plan_text)
            environment_commands = self.database_environment_create_commands(resource_id, plan_text=plan_text)

            label = f"{skill_id}:{consumer}" if consumer else skill_id
            lines = [f"### {label}"]
            if mode != "manual" and commands:
                lines.append(f"[{DATABASE_ACQUISITION_MARKER}:{label}]")
                lines.append(
                    "- 授权含义：用户确认本方案后，程序会在小数据试跑前执行下列命令，"
                    "并以 Skill 就绪标记复检；下载或本地化不完整时阻断分析。\n"
                    "- Meaning of authorization: once you confirm this plan, the program runs the "
                    "commands below before the small-data pilot and then re-checks with the Skill "
                    "readiness markers; analysis is blocked if the download or localization is incomplete."
                )
            else:
                lines.append(
                    "- 获取方式：需要人工许可、登录、版本选择、文件放置，或当前 Skill 尚未提供完整的"
                    "机器可执行命令，不能自动授权下载。\n"
                    "- Acquisition method: manual permission, login, version selection, or file placement "
                    "is required, or the current Skill does not yet provide complete machine-executable "
                    "commands, so the download cannot be authorized automatically."
                )
            lines.extend(
                [
                    f"- 本地目录：`Database/{skill.metadata['folder']}/` / Local directory",
                    f"- 优势：{'；'.join(_as_string_list(skill.metadata.get('advantages'))) or 'Skill 尚未记录 / not yet recorded in the Skill'} / Advantages",
                    f"- 局限：{'；'.join(_as_string_list(skill.metadata.get('limitations'))) or 'Skill 尚未记录 / not yet recorded in the Skill'} / Limitations",
                    f"- 预计体量：{skill.metadata.get('estimated_size') or '需在下载前查询并记录 / query and record before download'} / Estimated size",
                    f"- 官方来源：{'；'.join(_as_string_list(skill.metadata.get('download_urls'))) or 'Skill 尚未记录 / not yet recorded in the Skill'} / Official sources",
                ]
            )
            if commands:
                lines.append(f"- 获取命令：{'；'.join(commands)} / Acquisition commands")
            if localization:
                lines.append(f"- 本地化命令：{'；'.join(localization)} / Localization commands")
            for environment_command in environment_commands:
                lines.append(f"- 缺失下载环境的确认后创建命令：{environment_command} / Create command for the missing download environment after confirmation")
            lines.append(f"- 就绪判据：{', '.join(_as_string_list(skill.metadata.get('required_markers')))} / Readiness criteria")
            sections.append("\n".join(lines))
        if not sections:
            return ""
        return "\n\n".join(
            [
                "## 需要确认的数据库获取与本地化\n## Database acquisitions and localization requiring confirmation",
                *sections,
                "回复“确认执行”将只授权带 MICROBIOME_DB_ACQUISITION 标记的资源，并先运行小数据全流程试跑；不代表授权全量分析。\n"
                'Replying "confirm execution" authorizes only the resources carrying the '
                "MICROBIOME_DB_ACQUISITION marker and first runs an end-to-end small-data pilot; "
                "it does not authorize full-scale analysis.",
            ]
        )

    def strip_ready_database_acquisitions(self, text: str) -> str:
        """Remove download markers and download-command lines for READY databases.

        A plan may still propose re-downloading a database the registry already has
        (e.g. a stale ``[MICROBIOME_DB_ACQUISITION:checkv]`` marker or a free-form
        ``checkv download_database ...`` step). This deterministically removes those
        from the plan text so the model cannot re-trigger a redundant download.
        """
        if not text:
            return text
        ready_ids = {
            skill.skill_id
            for skill in self.list_skills("database")
            if self.database_status(skill.skill_id).status == "ready"
        }
        if not ready_ids:
            return text
        # 1. Drop acquisition markers for READY databases.
        for skill_id in ready_ids:
            text = re.sub(
                rf"\[{DATABASE_ACQUISITION_MARKER}:{re.escape(skill_id)}(?::[a-z0-9-]+)?\]",
                "",
                text,
                flags=re.IGNORECASE,
            )
        # 2. Drop free-form download lines that reference a READY database.
        download_tokens = ("download", "下载", "获取", "拉取", "ensure_database", "download_database")
        kept: list[str] = []
        for line in text.splitlines():
            lowered = line.lower()
            if any(skill_id in lowered for skill_id in ready_ids) and any(
                token in lowered for token in download_tokens
            ):
                continue
            kept.append(line)
        text = "\n".join(kept)
        return re.sub(r"\n\s*\n\s*\n+", "\n\n", text).strip()

    def strip_ready_software_installs(self, text: str) -> str:
        """Remove environment create/install lines for software that is already READY.

        The software analog of :meth:`strip_ready_database_acquisitions`: a plan may
        still propose ``conda create -n <env>`` / ``conda install -n <env>`` for an
        environment the registry already has fully ready. Drop those lines so the
        model cannot re-trigger a redundant environment install.
        """
        if not text:
            return text
        ready_envs = set()
        for skill in self.list_skills("software"):
            status = self.software_status(skill.skill_id)
            if status.status == "ready" and status.environment:
                ready_envs.add(status.environment.lower())
        if not ready_envs:
            return text
        kept: list[str] = []
        for line in text.splitlines():
            lowered = line.lower()
            if re.search(r"\b(?:conda|mamba|micromamba)\s+(?:install|create|update)\b", lowered):
                name_match = re.search(r"(?:-n|--name)\s+['\"]?([a-z0-9_.-]+)", lowered)
                prefix_match = re.search(r"(?:-p|--prefix)\s+['\"]?(\S+?)['\"]?(?:\s|$)", lowered)
                target = name_match.group(1) if name_match else None
                if target is None and prefix_match:
                    target = Path(prefix_match.group(1).rstrip("/\\")).name.lower()
                if target and target in ready_envs:
                    continue
            kept.append(line)
        text = "\n".join(kept)
        return re.sub(r"\n\s*\n\s*\n+", "\n\n", text).strip()

    def database_comparison(self, query: str = "", software_id: str | None = None) -> str:
        """Compare local readiness and scientific trade-offs for matching databases."""
        if software_id:
            normalized = software_id.lower()
            skills = [
                skill
                for skill in self.list_skills("database")
                if normalized in {value.lower() for value in _as_string_list(skill.metadata.get("compatible_software"))}
            ]
        elif query:
            skills = [skill for skill in self.relevant_skills(query, max_skills=16) if skill.kind == "database"]
        else:
            skills = self.list_skills("database")
        rows = [
            "| database | local status | scope/advantages | limitations | size | acquisition |",
            "|---|---|---|---|---|---|",
        ]
        for skill in sorted(
            skills, key=lambda item: (self.database_status(item.skill_id).status != "ready", item.skill_id)
        ):
            status = self.database_status(skill.skill_id)
            advantages = "; ".join(_as_string_list(skill.metadata.get("advantages"))) or skill.description
            limitations = "; ".join(_as_string_list(skill.metadata.get("limitations"))) or "not documented"
            rows.append(
                f"| {skill.skill_id} | {status.status} | {advantages} | {limitations} | "
                f"{skill.metadata.get('estimated_size') or 'unknown'} | "
                f"{skill.metadata.get('acquisition_mode', 'manual')} |"
            )
        return "\n".join(["# Database option comparison", f"Database root: {self.db_root}", "", *rows])

    @staticmethod
    def _mentions_skill(text: str, skill_id: str) -> bool:
        return bool(re.search(rf"(?<![a-z0-9-]){re.escape(skill_id)}(?![a-z0-9-])", text.lower()))

    def plan_bindings(self, text: str, query: str | None = None) -> str:
        """Render authoritative paths and environment prefixes for named skills."""
        lines = []
        allowed_keys: set[tuple[str, str]] | None = None
        if query:
            selected = self.relevant_skills(query, max_skills=14)
            allowed_keys = {(skill.kind, skill.skill_id) for skill in selected}
            for skill in selected:
                if skill.kind == "software":
                    for field in ("databases", "optional_databases"):
                        allowed_keys.update(
                            ("database", database_id.lower())
                            for database_id in _as_string_list(skill.metadata.get(field))
                            if ("database", database_id.lower()) in self.skills
                        )
        for skill in self.list_skills("database"):
            if allowed_keys is not None and ("database", skill.skill_id) not in allowed_keys:
                continue
            if not self._mentions_skill(text, skill.skill_id):
                continue
            status = self.database_status(skill.skill_id)
            direct_path = f"database/{skill.metadata['folder']}".lower()
            if status.status != "ready" and direct_path not in text.lower():
                continue
            markers = ", ".join(_as_string_list(skill.metadata.get("required_markers")))
            lines.append(
                f"- database {skill.skill_id}: {status.status.upper()}, path={status.path}, required_markers={markers}"
            )
        for skill in self.list_skills("software"):
            if allowed_keys is not None and ("software", skill.skill_id) not in allowed_keys:
                continue
            if not self._mentions_skill(text, skill.skill_id):
                continue
            status = self.software_status(skill.skill_id)
            if status.command_prefix:
                lines.append(
                    f"- software {skill.skill_id}: READY, env={status.environment}, "
                    f"invoke={shlex.join(status.command_prefix)}"
                )
            else:
                lines.append(
                    f"- software {skill.skill_id}: {status.status.upper()}, env={status.environment}, "
                    f"{self._software_action_hint(status)}"
                )
        if not lines:
            return ""
        return "\n".join(["## Registry-verified resource bindings", *lines])

    def missing_database_guidance(self, skill_ids: list[str]) -> str:
        """Render deterministic preparation instructions for missing databases."""
        lines = ["资源准备尚未完成，当前不会进入分析执行。\nResource preparation is not complete, so analysis execution will not start."]
        for resource_id in skill_ids:
            skill_id, separator, consumer = resource_id.partition(":")
            consumer = consumer if separator else ""
            skill = self.get_skill("database", skill_id)
            status = self.database_status(skill_id, consumer or None)
            label = f"{skill_id} ({consumer} 格式 / format)" if consumer else skill_id
            lines.append(f"\n- {label}: 放置到 `Database/{skill.metadata['folder']}/` / place into this directory")
            urls = _as_string_list(skill.metadata.get("download_urls"))
            commands = _as_string_list(skill.metadata.get("localization_commands"))
            consumer_commands = skill.metadata.get("consumer_localization_commands") or {}
            if consumer and isinstance(consumer_commands, dict) and consumer_commands.get(consumer):
                commands = _as_string_list(consumer_commands[consumer])
            if urls:
                lines.append(f"  官方来源：{'；'.join(urls)} / Official sources")
            if commands:
                lines.append(
                    f"  放置后本地化：{'；'.join(self._resolve_database_command(command) for command in commands)} / Localization after placement"
                )
            if status.missing:
                lines.append(f"  就绪标记：{', '.join(status.missing)} / Readiness markers")
        lines.append(
            "\n这些资源当前没有可自动执行的完整获取方案。准备完成后请输入“重新规划”，"
            "届时注册表会重新扫描本地状态；也可以修改方案改用本地 READY 资源。"
            "在资源就绪前无需重复输入“确认执行”。\n"
            "These resources have no complete automatically executable acquisition plan yet. "
            'Once preparation is done, enter "re-plan" and the registry will rescan the local '
            "state; alternatively revise the plan to use local READY resources. There is no need "
            'to repeat "confirm execution" before the resources are ready.'
        )
        return "\n".join(lines)


def _validate_new_skill_id(skill_id: str) -> str:
    normalized = skill_id.strip().lower().replace("_", "-")
    if not _VALID_ID.fullmatch(normalized):
        raise SkillValidationError(f"Invalid skill id: {skill_id!r}")
    return normalized


def _markdown_bullets(values: Any, fallback: str) -> str:
    items = _as_string_list(values)
    if not items:
        return f"- {fallback}"
    return "\n".join(f"- {item}" for item in items)


def _default_software_instructions(metadata: dict[str, Any]) -> str:
    executable = _as_string_list(metadata["executables"])[0]
    environment = str(metadata["environment"])
    capabilities = metadata.get("capabilities") or [metadata["description"]]
    return f"""# {metadata["name"]}

## Capabilities and selection

{_markdown_bullets(capabilities, "Document the analyses this software can perform and its important limitations.")}

Use this skill when the requested analysis matches those capabilities. Compare it with alternative software before selection; do not treat an undocumented option as proof that the software cannot perform an analysis.

## Inputs and upstream

Expected inputs:
{_markdown_bullets(metadata.get("inputs"), "Document every accepted input format, required fields, compression support, and pairing rules.")}

Typical upstream producers:
{_markdown_bullets(metadata.get("upstream"), "Document the software or analysis that creates each accepted input.")}

Validate file existence, format, sample identity, and reference-coordinate compatibility before execution.

## Outputs and downstream

Expected outputs:
{_markdown_bullets(metadata.get("outputs"), "Document primary results, auxiliary files, logs, and their formats.")}

Typical downstream consumers:
{_markdown_bullets(metadata.get("downstream"), "Document the software or analysis that can consume each output.")}

Preserve the command, software version, environment, reference version, and sample mapping beside the outputs.

## Parameters and decision rules

{_markdown_bullets(metadata.get("parameter_guidance"), f"Inspect `{executable} --help` in the declared environment and document each workflow-relevant option, its default, valid range, and when to change it.")}

Record parameter choices in the confirmed plan. Never invent flags from a similarly named tool or a different major version.

## Workflow patterns

- Run this software through the registry-verified absolute environment prefix (`conda run -p <prefix> --no-capture-output {executable} ...`, copied from the binding's `invoke=` field); use `conda run -n {environment}` only while the prefix is not yet known, since name lookup can resolve against the wrong conda root on machines with multiple installations.
- Resolve required database paths from their database skills. Download only a database carrying an explicit MICROBIOME_DB_ACQUISITION marker in the user-confirmed plan; all other network access remains blocked.
- Check the upstream output before invoking this command, then expose all declared outputs to the next workflow component.
- Use a separate `conda run` process for the next software skill so dependencies do not leak between environments.

## Validation and failure handling

Validation rules:
{_markdown_bullets(metadata.get("validation"), "Check exit status, non-empty expected outputs, logs, record counts, and domain-specific quality metrics.")}

Failure handling:
{_markdown_bullets(metadata.get("failure_handling"), "Read stderr and logs, identify whether the cause is input, parameter, resource, environment, or database related, correct the command, and rerun only the failed unit.")}
"""


def _default_database_instructions(metadata: dict[str, Any]) -> str:
    folder = str(metadata["folder"])
    return f"""# {metadata["name"]}

## Scope and biological meaning

- {metadata["description"]}
{_markdown_bullets(metadata.get("contents"), "Document the biological entities, taxonomy, annotations, or models represented by this database.")}

State what questions this database can support and what is outside its scope. Database availability alone is not evidence that it is appropriate for a sample type or analysis goal.

## Directory and readiness contract

- Keep this database alone in `Database/{folder}/`.
- Ready-state markers: {_compact_list(metadata.get("required_markers"), limit=20)}.
- Raw but not yet localized markers: {_compact_list(metadata.get("raw_markers"), limit=20)}.
- Expected formats: {_compact_list(metadata.get("formats"), limit=20)}.

Do not mix releases or files from unrelated databases in this directory. Readiness means the declared markers exist; execution must still verify that the selected software can open them.

## Acquisition and localization

Official sources:
{_markdown_bullets(metadata.get("download_urls"), "Add an authoritative release or download page before asking the user to acquire this database.")}

Selection advantages:
{_markdown_bullets(metadata.get("advantages"), "Document why this database is preferred for specific organisms, evidence types, or reproducibility needs.")}

Selection limitations:
{_markdown_bullets(metadata.get("limitations"), "Document taxonomic scope, update lag, licensing, computational cost, and known blind spots.")}

- Estimated download/localized size: {metadata.get("estimated_size") or "Measure or query this before requesting approval."}
- Acquisition mode: {metadata.get("acquisition_mode", "manual")}

After explicit plan confirmation, acquire only with the commands declared in the plan:
{_markdown_bullets(metadata.get("acquisition_commands"), "No automatic acquisition command is declared; require manual preparation.")}

After the user or agent places source files in `Database/{folder}/`, localize them with:
{_markdown_bullets(metadata.get("localization_commands"), "Document the exact indexing, unpacking, or conversion command required after placement.")}

Planning must report missing files, scientific trade-offs, size, and these preparation instructions. Confirmed execution may download only a resource explicitly marked in the confirmed plan; all other network acquisition remains blocked.

## Software consumers and parameter coupling

Compatible software skills:
{_markdown_bullets(metadata.get("consumers") or metadata.get("compatible_software"), "Document every software skill that can consume this database and its database-path option.")}

For each consumer, document the expected index type, path argument, release compatibility, taxonomy conventions, and any mode that changes which database subset is required.

## Workflow inputs and outputs

- Input to localization: {_compact_list(metadata.get("raw_markers"), limit=20)}.
- Localized assets: {_compact_list(metadata.get("required_markers"), limit=20)}.
- The consuming software determines result-file formats; retain the database release and path in result provenance.

Never pass an archive or raw FASTA where a consumer expects a localized index. Never rebuild an already ready database unless validation proves it is incompatible or corrupt.

## Versioning, provenance, and updates

- Update policy: {metadata.get("update_policy") or "Document release cadence, compatibility rules, and whether results from different releases are comparable."}
- License notes: {metadata.get("license_notes") or "Review and record redistribution, access, citation, and commercial-use terms from the official source."}
- Record source URL, release identifier, acquisition date, checksums when available, localization command, and tool version.

## Validation and failure handling

{_markdown_bullets(metadata.get("validation"), "Verify all readiness markers, inspect release metadata, test a lightweight consumer command, and reject mixed or partial releases.")}

{_markdown_bullets(metadata.get("failure_handling"), "On failure, distinguish missing raw data, incomplete localization, wrong release, corrupt files, permissions, and software/database format mismatch before rebuilding anything.")}
"""


def _write_skill(
    kind: str,
    skill_id: str,
    metadata: dict[str, Any],
    instructions: str,
    skill_root: str | Path | None,
    overwrite: bool,
) -> str:
    root = Path(skill_root or os.environ.get("MICROBIOME_RESOURCE_SKILL_ROOT") or DEFAULT_CUSTOM_SKILL_ROOT).expanduser().resolve()
    path = root / kind / skill_id / "SKILL.md"
    if path.exists() and not overwrite:
        raise FileExistsError(f"Resource skill already exists: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    frontmatter = yaml.safe_dump(metadata, sort_keys=False, allow_unicode=True).strip()
    body = instructions.strip()
    if not body:
        body = (
            _default_software_instructions(metadata) if kind == "software" else _default_database_instructions(metadata)
        )
    path.write_text(f"---\n{frontmatter}\n---\n\n{body}\n", encoding="utf-8")
    _parse_skill(path)
    return str(path)


def add_software_skill(
    skill_id: str,
    description: str,
    environment: str,
    executables: list[str],
    packages: list[str],
    tasks: list[str] | None = None,
    databases: list[str] | None = None,
    channels: list[str] | None = None,
    instructions: str = "",
    skill_root: str | Path | None = None,
    overwrite: bool = False,
    pip_packages: list[str] | None = None,
    aliases: list[str] | None = None,
    keywords: list[str] | None = None,
    capabilities: list[str] | None = None,
    inputs: list[str] | None = None,
    outputs: list[str] | None = None,
    upstream: list[str] | None = None,
    downstream: list[str] | None = None,
    excludes: list[str] | None = None,
    parameter_guidance: list[str] | None = None,
    validation: list[str] | None = None,
    failure_handling: list[str] | None = None,
    environment_file: str = "",
    selection_tier: str = "conditional",
) -> str:
    """Add a software SKILL.md without changing Microbiome source code."""
    normalized = _validate_new_skill_id(skill_id)
    metadata = {
        "name": skill_id,
        "description": description,
        "kind": "software",
        "id": normalized,
        "version": 2,
        "selection_tier": selection_tier,
        "aliases": aliases or [],
        "keywords": keywords or [],
        "environment": environment,
        "executables": executables,
        "packages": packages,
        "environment_file": environment_file,
        "channels": channels or ["conda-forge", "bioconda"],
        "pip_packages": pip_packages or [],
        "tasks": tasks or [],
        "databases": databases or [],
        "capabilities": capabilities or [],
        "inputs": inputs or [],
        "outputs": outputs or [],
        "upstream": upstream or [],
        "downstream": downstream or [],
        "excludes": excludes or [],
        "parameter_guidance": parameter_guidance or [],
        "validation": validation or [],
        "failure_handling": failure_handling or [],
    }
    return _write_skill("software", normalized, metadata, instructions, skill_root, overwrite)


def add_database_skill(
    skill_id: str,
    description: str,
    folder: str,
    required_markers: list[str],
    compatible_software: list[str],
    download_urls: list[str] | None = None,
    localization_commands: list[str] | None = None,
    raw_markers: list[str] | None = None,
    instructions: str = "",
    skill_root: str | Path | None = None,
    overwrite: bool = False,
    aliases: list[str] | None = None,
    keywords: list[str] | None = None,
    contents: list[str] | None = None,
    formats: list[str] | None = None,
    consumers: list[str] | None = None,
    update_policy: str = "",
    license_notes: str = "",
    validation: list[str] | None = None,
    failure_handling: list[str] | None = None,
    advantages: list[str] | None = None,
    limitations: list[str] | None = None,
    estimated_size: str = "",
    acquisition_mode: str = "manual",
    acquisition_commands: list[str] | None = None,
) -> str:
    """Add a database SKILL.md; database files remain under Database/<folder>."""
    normalized = _validate_new_skill_id(skill_id)
    metadata = {
        "name": skill_id,
        "description": description,
        "kind": "database",
        "id": normalized,
        "version": 2,
        "aliases": aliases or [],
        "keywords": keywords or [],
        "folder": folder,
        "required_markers": required_markers,
        "raw_markers": raw_markers or [],
        "compatible_software": compatible_software,
        "download_urls": download_urls or [],
        "advantages": advantages or [],
        "limitations": limitations or [],
        "estimated_size": estimated_size,
        "acquisition_mode": acquisition_mode,
        "acquisition_commands": acquisition_commands or [],
        "localization_commands": localization_commands or [],
        "contents": contents or [],
        "formats": formats or [],
        "consumers": consumers or compatible_software,
        "update_policy": update_policy,
        "license_notes": license_notes,
        "validation": validation or [],
        "failure_handling": failure_handling or [],
    }
    return _write_skill("database", normalized, metadata, instructions, skill_root, overwrite)


def list_resource_skills(
    kind: str | None = None,
    skill_root: str | Path | None = None,
    db_root: str | Path | None = None,
) -> str:
    """List registered resource skills and their current local status."""
    roots = None if skill_root is None else [skill_root]
    registry = ResourceSkillRegistry(skill_roots=roots, db_root=db_root)
    if kind is None:
        return registry.planning_context()
    lines = []
    for skill in registry.list_skills(kind):
        status = (
            registry.database_status(skill.skill_id) if kind == "database" else registry.software_status(skill.skill_id)
        )
        lines.append(f"{skill.skill_id}: {status.status}")
    return "\n".join(lines) if lines else f"No {kind} skills registered."


def get_resource_skill_details(
    kind: str,
    skill_id: str,
    skill_root: str | Path | None = None,
    db_root: str | Path | None = None,
) -> str:
    """Return complete workflow and parameter guidance for one resource skill."""
    roots = None if skill_root is None else [skill_root]
    return ResourceSkillRegistry(skill_roots=roots, db_root=db_root).skill_details(kind, skill_id)


def compare_database_options(
    query: str = "",
    software_id: str | None = None,
    skill_root: str | Path | None = None,
    db_root: str | Path | None = None,
) -> str:
    """Compare matching databases without modifying local or remote state."""
    roots = None if skill_root is None else [skill_root]
    return ResourceSkillRegistry(skill_roots=roots, db_root=db_root).database_comparison(
        query=query,
        software_id=software_id,
    )


def plan_database_acquisition(
    database_id: str,
    consumer: str | None = None,
    skill_root: str | Path | None = None,
    db_root: str | Path | None = None,
) -> str:
    """Render the exact proposal that must be confirmed before acquisition."""
    roots = None if skill_root is None else [skill_root]
    registry = ResourceSkillRegistry(skill_roots=roots, db_root=db_root)
    resource_id = f"{database_id}:{consumer}" if consumer else database_id
    return registry.database_acquisition_guidance([resource_id])


def render_software_command(
    software_id: str,
    command: str | list[str],
    registry: ResourceSkillRegistry | None = None,
) -> str:
    """Render one isolated conda-run command from a software skill."""
    registry = registry or ResourceSkillRegistry()
    status = registry.software_status(software_id)
    if status.status != "ready":
        raise RuntimeError(
            f"Software skill {software_id!r} is not ready ({status.status}). "
            f"The environment must be declared during planning: {status.create_command}"
        )
    args = list(status.command_prefix)
    if isinstance(command, str):
        args.extend(["bash", "-lc", command])
    else:
        args.extend(str(part) for part in command)
    return shlex.join(args)


def render_environment_create_command(
    software_id: str,
    registry: ResourceSkillRegistry | None = None,
) -> str:
    """Render the conda/mamba create command declared by a software skill."""
    registry = registry or ResourceSkillRegistry()
    return registry.environment_create_command(software_id)
