"""Scientific adapter resources independent of any chat harness."""
from pathlib import Path
import sys

ASSET_NAMES = frozenset({"cohort_tables.py", "run_dada2.R", "run_ancombc2.R"})


def asset_path(name):
    if Path(name).name != name or name not in ASSET_NAMES:
        raise ValueError(f"Unknown bundled adapter: {name}")
    for root in (Path(__file__).parent / "runtime_assets", Path(__file__).parent / "harness/resources",
                 Path(__file__).resolve().parents[1] / "scripts"):
        candidate = root / name
        if candidate.is_file():
            return candidate
    raise FileNotFoundError(f"Incomplete installation: {name}")


def resolve_asset_token(token):
    if token.startswith("asset://"):
        return str(asset_path(token.removeprefix("asset://")))
    if token in {f"scripts/{name}" for name in ASSET_NAMES}:
        return str(asset_path(Path(token).name))
    return token


def main():
    if len(sys.argv) != 2:
        raise SystemExit("Usage: microbiome-asset <cohort_tables.py|run_dada2.R|run_ancombc2.R>")
    print(asset_path(sys.argv[1]))
