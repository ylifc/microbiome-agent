"""Compatibility entry for the credential-free NDJSON worker."""
from microbiome.harness.worker import main

if __name__ == "__main__":
    raise SystemExit(main())
