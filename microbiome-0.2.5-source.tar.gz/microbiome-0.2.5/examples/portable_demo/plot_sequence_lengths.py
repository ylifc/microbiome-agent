"""Render synthetic FASTQ record lengths; this demo does not infer biology."""
import argparse
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('reads', type=Path)
    parser.add_argument('png', type=Path)
    parser.add_argument('svg', type=Path)
    parser.add_argument('--identity', type=Path, help='Record the actual interpreter and environment for installation verification')
    args = parser.parse_args()
    lines = args.reads.read_text().splitlines()
    if len(lines) % 4 or any(not lines[i].startswith('@') for i in range(0, len(lines), 4)):
        raise ValueError('Expected complete synthetic FASTQ records')
    lengths = [len(lines[i + 1]) for i in range(0, len(lines), 4)]
    if not lengths:
        raise ValueError('No records to plot')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    with plt.rc_context({'svg.hashsalt': 'microbiome-synthetic-demo', 'font.family': 'DejaVu Sans'}):
        figure, axes = plt.subplots(figsize=(7, 4.2), constrained_layout=True)
        axes.bar(range(1, len(lengths) + 1), lengths, color='#286785')
        axes.set(title='SYNTHETIC PREVIEW: sequence lengths', xlabel='Record index', ylabel='Length (nt)')
        axes.set_xticks(range(1, len(lengths) + 1))
        axes.set_ylim(0, max(lengths) * 1.25)
        axes.spines[['top', 'right']].set_visible(False)
        for index, length in enumerate(lengths, 1):
            axes.text(index, length, str(length), ha='center', va='bottom')
        figure.savefig(args.png, dpi=150)
        figure.savefig(args.svg, metadata={'Date': None})
        plt.close(figure)
    if args.identity:
        import json
        import sys
        args.identity.write_text(json.dumps({'executable': sys.executable, 'prefix': sys.prefix,
                                              'matplotlib': matplotlib.__version__}, indent=2) + '\n')


if __name__ == '__main__':
    main()
