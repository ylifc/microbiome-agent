"""Run installed Microbiome on tiny synthetic files without models or approval shortcuts."""
from __future__ import annotations

import argparse
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check(condition, message):
    """Keep evidence checks active even when Python optimization is enabled."""
    if not condition:
        raise RuntimeError(message)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path, help="New directory for artificial inputs and reports")
    args = parser.parse_args(argv)
    root = args.output.expanduser().absolute()
    if root.is_symlink():
        parser.error("Output must not be a symlink")
    root.mkdir(parents=True, exist_ok=False)
    raw = root / "raw"
    raw.mkdir()
    fasta = raw / "example.fasta"
    fasta.write_text(">alpha synthetic\nACGTACGTNN\n>beta synthetic\nGGGGTT\n")
    left, right = raw / "reads_R1.fastq", raw / "reads_R2.fastq.gz"
    left.write_text("@one/1\nACGT\n+\nIIII\n@two/1\nAACCGG\n+\nIIIIII\n")
    with gzip.GzipFile(filename=str(right), mode="wb", mtime=0) as handle:
        handle.write(b"@one/2\nTGCA\n+\nIIII\n@two/2\nTTGGCC\n+\nIIIIII\n")
    malformed = raw / "invalid.fastq"
    malformed.write_text("@bad\nACGT\n+\nII\n")
    inputs_before = {str(path): digest(path) for path in raw.iterdir()}
    results = []

    def invoke(name, files, *, paired=False, success=True):
        arguments = {"inputs": [str(path) for path in files], "output": str(root / name), "paired": paired}
        process = subprocess.run([sys.executable, "-I", "-m", "microbiome.cli", "call", "sequence.stats",
                                  "--json", json.dumps(arguments)], cwd=root, text=True,
                                 capture_output=True, timeout=60)
        log_name = f"{len(results) + 1:02d}-{name}"
        (root / (log_name + ".stdout.json")).write_text(process.stdout)
        (root / (log_name + ".stderr.log")).write_text(process.stderr)
        reply = json.loads(process.stdout)
        if bool(reply.get("ok")) != success or (process.returncode == 0) != success:
            raise RuntimeError(f"Unexpected {name} outcome: {reply}")
        results.append({"case": name, "expected": "success" if success else "rejected",
                        "returncode": process.returncode, "response": reply})
        return reply.get("result")

    status, error = "PASSED", None
    try:
        first = invoke("fasta-statistics", [fasta])
        data = first["statistics"]["inputs"][0]
        check((data["records"], data["total_bases"], data["gc_bases"], data["canonical_bases"]) == (2, 16, 8, 14),
              "Unexpected FASTA record/base counts")
        check(abs(data["gc_percent"] - 100 * 8 / 14) < 1e-6, "Unexpected FASTA GC percentage")
        second = invoke("paired-statistics", [left, right], paired=True)
        check(second["statistics"]["pairing"]["matched_pairs"] == 2, "Unexpected matched-pair count")
        check(all(row["records"] == 2 and row["total_bases"] == 10 for row in second["statistics"]["inputs"]),
              "Unexpected paired FASTQ record/base counts")
        invoke("invalid-statistics", [malformed], success=False)
        invoke("missing-statistics", [raw / "missing.fastq"], success=False)
        # A repeated output target must fail rather than replacing verified artifacts.
        saved = digest(Path(first["result"]))
        invoke("fasta-statistics", [fasta], success=False)
        check(digest(Path(first["result"])) == saved, "Existing result changed after rejected overwrite")
        check(inputs_before == {str(path): digest(path) for path in raw.iterdir()}, "Original input files changed")
    except Exception as exc:
        status, error = "FAILED", {"type": type(exc).__name__, "message": str(exc)}
    report = {"schema_version": 1, "status": status, "synthetic_inputs": True,
              "scope": "FASTA and paired gzipped FASTQ statistics and error handling; no scientific pipeline approvals",
              "input_sha256": inputs_before, "cases": results, "error": error}
    (root / "demo-report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"status": status, "cases": len(results), "report": str(root / "demo-report.json")}, ensure_ascii=False))
    return 0 if status == "PASSED" else 1


if __name__ == "__main__":
    raise SystemExit(main())
