"""Synthetic installation exercise with an actual visual-review pause.

prepare creates a new, explicitly labelled fixture project and runs its pilot.
Inspect the returned PNG and SVG, then record visualization.review through the
public CLI. finish requires that review before freezing and running production.
All project/dependency/production decisions are fixture authorizations for the
generated data only. No user data, downloads, model or external resource is used.
"""
from __future__ import annotations

import argparse
import contextlib
import json
from pathlib import Path
import shutil
import sys


def prepare(output: Path):
    from microbiome.pipeline.project import PipelineProject, discover_project
    from microbiome.pipeline.requirements import RequirementManager, ConfirmationAction
    from microbiome.pipeline.dependencies import DependencyResolver, confirm_plan
    from microbiome.pipeline.lifecycle import save_experiment_plan, bootstrap_toolchain, resolve_databases
    from microbiome.pipeline.planning_context import PlanningContext
    from microbiome.pipeline.workflow_references import bind_reference_decisions
    from microbiome.pipeline.validation import SmallScaleValidator
    from microbiome.pipeline.freeze import PipelineFreezer
    from microbiome.pipeline.errors import FreezeError
    from microbiome.visualization.artifacts import inspect_manifest
    import microbiome

    output.mkdir(parents=True, exist_ok=False)
    raw = output / 'raw'; raw.mkdir()
    reads = raw / 'synthetic.fastq'
    reads.write_text(''.join(f'@synthetic_{i}\n{s}\n+\n{"I" * len(s)}\n'
                             for i, s in enumerate(['ACGT', 'ACGTAC', 'ACGTACGT', 'ACGTA'], 1)))
    renderer = raw / 'plot_sequence_lengths.py'
    shutil.copy2(Path(__file__).with_name('plot_sequence_lengths.py'), renderer)
    project = PipelineProject.initialize(output / 'project', raw_data_path=raw,
                                        database_path=output / 'databases', output_path=output / 'results')
    inventory = discover_project(project)
    manager = RequirementManager(project)
    for topic, value in (
        ('input', {'type': inventory['raw_data']['detected_input_type']}),
        ('dataset', {'sample_count': 1, 'synthetic': True}),
        ('target', {'organism_scope': 'synthetic fixture; no biological inference'}),
        ('analysis_goal', {'objective': 'Plot synthetic record lengths to verify installed execution.'}),
    ):
        manager.decide(topic, value, action=ConfirmationAction.CONFIRM)
    contract = {'schema_version': 1, 'figure_id': 'synthetic_lengths', 'kind': 'bar',
                'dataset_kind': 'synthetic', 'source_scientific_status': 'synthetic_fixture',
                'source_inputs': ['reads', 'renderer'], 'source_evidence_inputs': [],
                'image_outputs': ['png', 'svg'], 'required_review_outputs': ['png', 'svg'],
                'manifest_output': 'figure_manifest', 'quantity': 'length per synthetic sequence record',
                'units': 'nt', 'transformation': 'none'}
    plan = {
        'objective': 'Plot synthetic record lengths to verify installed execution.',
        'workflow_ids': ['sequence-statistics'],
        'workflow_decisions': [{'workflow_id': 'sequence-statistics', 'disposition': 'adapt',
                                'reason': 'Use only descriptive record lengths from generated FASTQ; no biological inference.',
                                'step_ids': ['draw_lengths']}], 'visualization_topics': ['tables'],
        'visualization_decision': {'disposition': 'adapt', 'reason': 'Small synthetic installation fixture; plot actual record lengths without biological inference.'},
        'steps': [{
            'step_id': 'draw_lengths', 'purpose': 'Render synthetic sequence record lengths.',
            'tool': 'python', 'tool_version_requirement': 'any',
            'environment': {'prefix': sys.prefix, 'executable': sys.executable,
                            'version_args': ['--version'], 'help_args': ['--help'],
                            'installation_source': 'isolated installed Python runtime'},
            'input': {'reads': '{runtime.reads}', 'renderer': str(renderer)},
            'output': {'png': '{run_dir}/lengths.png', 'svg': '{run_dir}/lengths.svg',
                       'figure_manifest': '{run_dir}/figure.json', 'identity': '{run_dir}/runtime.json'},
            'database': {}, 'command_template': ['{executable}', '{input.renderer}', '{input.reads}',
                                                 '{output.png}', '{output.svg}', '--identity', '{output.identity}'],
            'parameters': [], 'success_criteria': ['non_empty:output.png', 'non_empty:output.identity'],
            'failure_criteria': ['nonzero_exit'], 'dependencies': [],
            'threads_policy': {'min': 1, 'max': 1, 'default': 1}, 'memory_policy': {'max_gb': 1},
            'gpu_policy': {'enabled': False, 'min': 0, 'max': 0}, 'figure_contract': contract,
        }],
    }
    contexts = PlanningContext(project)
    context = contexts.collect(query=plan['objective'], plan=plan)
    receipt = contexts.persist(context)
    plan = bind_reference_decisions(plan, context['workflow_references'], receipt=receipt)
    save_experiment_plan(project, plan)
    confirm_plan(project, ConfirmationAction.CONFIRM)
    DependencyResolver(project).review()
    DependencyResolver(project).approve(ConfirmationAction.CONFIRM)
    bootstrap_toolchain(project)
    resolve_databases(project)
    report = SmallScaleValidator(project).validate({'reads': str(reads)}, max_records=2)
    if report['status'] != 'PASSED':
        raise RuntimeError(f'Pilot failed: {report}')
    files = report['steps'][0]['output_files']
    identity = json.loads(Path(files['identity']).read_text())
    if Path(identity['prefix']).absolute() != Path(sys.prefix).absolute():
        raise RuntimeError(f'Renderer escaped the installed runtime: {identity}')
    preview = inspect_manifest(files['figure_manifest'])
    try:
        PipelineFreezer(project).freeze()
    except FreezeError as error:
        if 'review' not in str(error).lower():
            raise
    else:
        raise RuntimeError('Freeze unexpectedly succeeded before visual review')
    state = {'schema_version': 1, 'kind': 'synthetic_figure_installation_demo', 'project': str(project.root),
             'reads': str(reads), 'runtime_prefix': sys.prefix, 'runtime_module': microbiome.__file__,
             'pilot_manifest': files['figure_manifest'], 'pilot_runtime': identity,
             'authorization_scope': 'Generated synthetic installation fixture only; no real-data scientific authorization'}
    (output / 'demo.json').write_text(json.dumps(state, indent=2) + '\n')
    return {'status': 'AWAITING_ACTUAL_VISUAL_REVIEW', 'project': str(project.root), 'preview': preview,
            'freeze_without_review': 'REJECTED', 'runtime': identity,
            'next': 'Open PNG and SVG, record visualization.review using the shown manifest hash, then run finish.'}


def finish(output: Path):
    from microbiome.pipeline.project import PipelineProject
    from microbiome.pipeline.finalizer import ValidationFinalizer
    from microbiome.pipeline.approval import ProductionApprovalManager
    from microbiome.pipeline.execution import FrozenPipelineExecutor
    from microbiome.visualization.artifacts import inspect_manifest
    state = json.loads((output / 'demo.json').read_text())
    if state.get('kind') != 'synthetic_figure_installation_demo' or state['runtime_prefix'] != sys.prefix:
        raise ValueError('Expected this runtime and a generated synthetic demo')
    if Path(state['project']).resolve() != output / 'project' or Path(state['reads']).resolve() != output / 'raw/synthetic.fastq':
        raise ValueError('Fixture state escaped its output directory')
    pilot = inspect_manifest(state['pilot_manifest'], require_review=True)
    project = PipelineProject(state['project'])
    from microbiome.pipeline.state import ProjectStateMachine, LifecycleState
    if ProjectStateMachine(project).current == LifecycleState.PRODUCTION_APPROVED:
        from microbiome.pipeline.readiness import load_current_readiness
        from microbiome.pipeline.io import read_yaml
        ready = load_current_readiness(project, read_yaml(project.pipeline_lock_path))
    else:
        ready = ValidationFinalizer(project).finalize_pretest()
        # Explicit finish is authorization to execute only this generated fixture.
        ProductionApprovalManager(project).handle('确认全量执行')
    if not ready['ready']:
        raise RuntimeError(f'Finalization failed: {ready}')
    result = FrozenPipelineExecutor(project).execute({'reads': state['reads']}, sample_id='synthetic', run_id='synthetic-production')
    if result['status'] != 'COMPLETED':
        raise RuntimeError(f'Synthetic production failed: {result}')
    manifests = list(project.runs_dir.glob('synthetic-production/**/figure.json'))
    if len(manifests) != 1:
        raise RuntimeError('Expected exactly one production figure manifest')
    production = inspect_manifest(str(manifests[0]))
    if production['visual_status'] != 'preview' or production['manifest_sha256'] == pilot['manifest_sha256']:
        raise RuntimeError('Production figure incorrectly inherited the pilot review')
    report = {'status': 'PASSED', 'pilot': pilot, 'production': production,
              'scientific_validation': 'Synthetic engineering exercise only', 'ready': ready['ready']}
    (output / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=['prepare', 'finish'])
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    output = args.output.expanduser().absolute()
    with contextlib.redirect_stdout(sys.stderr):
        result = prepare(output) if args.stage == 'prepare' else finish(output)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
