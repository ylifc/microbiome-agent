#!/usr/bin/env bash
set -euo pipefail
bundle_root="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
case "${1:-}" in
  --legacy-standalone|--standalone)
    shift
    exec "${BIOMNI_INSTALL_PYTHON:-python3}" "$bundle_root/scripts/manage_biomni.py" --bundle "$bundle_root/Biomni-Harness-Release" "$@"
    ;;
  --legacy-deepseek)
    shift
    exec "${MICROBIOME_INSTALL_PYTHON:-python3}" "$bundle_root/scripts/install_harness.py" --bundle "$bundle_root" "$@"
    ;;
esac
exec "${MICROBIOME_INSTALL_PYTHON:-python3}" "$bundle_root/scripts/install_portable.py" --bundle "$bundle_root" "$@"
