# Project Scope — Computational Bioinformatics Software Engineering

This repository is a computational bioinformatics workflow engine. It processes sequencing files such as FASTQ/FASTA, manages read-only reference resources, executes validated command-line bioinformatics tools, and produces computational analysis outputs.

Engineering work in scope includes file discovery and validation, software environment management, database/index registration, deterministic pipeline execution, logging, checkpointing, testing, reproducibility, and command/path debugging.

Input data source rules (local-first, enforced in code — not just in prompts):

- Input data source must be resolved before analysis planning.
- Explicit local files/directories/manifests take precedence over remote acquisition.
- Never infer SRA download merely because no SRA registry entry exists.
- Raw sample acquisition and reference/database acquisition are separate concerns.
- Once a local input manifest has been confirmed, downstream agents must use the persisted input manifest rather than re-inferring the source from conversation text.
- Remote acquisition requires an explicitly resolved remote identifier and the appropriate user approval.
- Missing local files are local-input errors, not evidence that SRA should be used.
- A local sample manifest such as sample_list.txt is a raw-data source, not an SRA download request.
- Classify every sample independently; a mixed manifest (local FASTQ + SRA accessions) must only download the remote records, never the whole project.

Production resource rules:

- Treat initialized databases and indexes as persistent infrastructure.
- Reuse resources registered `READY`; do not download, rebuild, relocate, or replace them during production.
- Keep executable, Conda-prefix, version, database runtime-entry, marker, and fingerprint contracts machine-readable.
- Stop on missing, incomplete, corrupt, or drifted resources; maintenance must be an explicit separate phase.
- Production replays a validated lock without invoking a planner or changing scientific parameters.

Resource resolution and self-learning rules:

- A missing software/database Skill is a discovery event, not proof that the resource is absent and not a fatal error by itself.
- Resolve software by capability in this order: frozen lock, validated tool registry, existing Skill mapping, every existing Conda environment, PATH/project software directories, Conda metadata, then an approved installation.
- Keep logical tool names, software families, package names, executable names, environment names, and Skill IDs as separate machine-readable fields. Never add one-off source-code branches for a particular executable alias.
- Every resource has three persistent layers: Registry records where and what version; Skill records how and when to use it; Knowledge records validated invocations, failures, fixes, installation/acquisition history, and local documentation.
- Install only dependencies present in the current approved dependency-plan scope. A newly discovered out-of-scope dependency requires a new dependency plan/version and explicit approval.
- Software creation/repair is allowed only during `BOOTSTRAP` or `PRETEST_REPAIR`. Never install, download, update, build a Skill, or change a scientific resource during frozen production.
- Search every existing environment before installing. Reuse a validated capability even when its environment name differs from a planner suggestion.
- Never install into `base`/`root`, delete a healthy user environment, or overwrite a non-Conda directory. Installation retries are bounded and only a validated executable/version/help smoke test may be registered `READY`.
- Save successful installation recipes and prefer them on later maintenance, but never automatically update software already registered `READY`.
- Keep databases, references, and indexes under the user-designated persistent database root, never inside Conda environments. Registry entries must store exact consumer runtime entrypoints, markers, provenance, status, and fingerprints.
- Database acquisition/localization must be approved, locked, resumable/partial-safe, idempotent, and registered `READY` only after full validation. Reuse `READY` resources without another download or rebuild.
- Skill text is guidance, not an executable fact source. Production source of truth is the frozen pipeline/toolchain/database lock; pre-production resource location truth is the validated registries.

This project does not request pathogen engineering, increased virulence or transmissibility, wet-lab culturing, synthesis protocols, or optimization of harmful biological activity. Do not evade safety controls. If a particular operation is restricted, isolate it while continuing permitted software engineering and computational data work.

Run the focused frozen-pipeline tests with:

```bash
pytest -q tests/test_frozen_pipeline.py
```
