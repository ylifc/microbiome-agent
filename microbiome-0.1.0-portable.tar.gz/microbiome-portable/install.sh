#!/usr/bin/env bash
set -euo pipefail
MICROBIOME_BUNDLE_ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
exec "${MICROBIOME_INSTALL_PYTHON:-python3}" "$MICROBIOME_BUNDLE_ROOT/scripts/install_portable.py" --bundle "$MICROBIOME_BUNDLE_ROOT"  "$@"
