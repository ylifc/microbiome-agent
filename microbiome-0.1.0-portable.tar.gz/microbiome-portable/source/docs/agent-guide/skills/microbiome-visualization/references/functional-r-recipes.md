# 基因、功能与基因组位置：8 个 R 配方

这些是面向已审核表格的源码模板，**没有在真实项目上完成绘图/视觉验收**。包是否已安装要在实际选定R环境核验；这里不安装、不联网提交数据、不生成注释或统计显著性。数据规则见 [functional-data-contract.md](functional-data-contract.md) 与 [functional-atlas.md](functional-atlas.md)；以下列名是适配后的输入契约，不意味着现有文件可以直接改后缀使用。

2026-10-14有限验证：在`/home/ylifc/miniforge3/envs/microbiome/bin/Rscript`（R4.4.1）对公共块与8配方共9个R块语法解析通过；19项纯base数值/键/缺失状态/读取/分配守恒检查通过。该环境实际探测ggplot2、digest、ComplexHeatmap、circlize、gggenes、ggalluvial、pathview均缺失，故未加载这些包、未执行完整绘图、未生成或视觉验收这些配方的图；没有安装依赖。

先执行公共块，再选一个配方。代码中的 `input_dir`、`output_parent` 指向隔离的新绘图工作区；绝不使用当前运行中的生产输出目录。每配方先做小范围真实预览，实际开图后才扩展。图册的文件SHA256、版本、纳入集和科学审核另行写入交付manifest。代码以长表输入避免丢失ID前导零，禁止默认把NA补0。

| 配方 | 对应图 | 包 | 计算边界 |
| --- | --- | --- | --- |
| FR01 基因/KO每笼dot plot | F03/F05/F09 | ggplot2,digest | 只做显式log展示变换，不检验 |
| FR02 功能热图与原值注释 | F04/F07/F24 | ComplexHeatmap,circlize,digest | 固定顺序，无默认聚类或z-score |
| FR03 MAG功能贡献 | F06/F12 | ggplot2,digest | 验证已分配贡献的守恒，不创造归属 |
| FR04 module步骤状态矩阵 | F08 | ggplot2,digest | 消费独立逻辑评估结果，不解析KEGG定义 |
| FR05 contig箭头+family量化旁表 | F14/F18 | ggplot2,gggenes,digest | 仅坐标显示变换，不推断operon/位点量化 |
| FR06 守恒多层alluvial | F13 | ggplot2,ggalluvial,digest | 消费审核后的分配流，不把成员关系当流量 |
| FR07 本地pathview | F10 | pathview,digest | KO着色、明确节点聚合；不推断通量 |
| FR08 已有效应与区间 | F25 | ggplot2,digest | 消费已拟合结果；不拟合差异模型 |

## 公共块

`begin_figure()`要求父目录已存在，在其下新建当前配方目录；已有目录或符号链接都拒绝覆盖。应给每次预览新的编号。用户表中的缺失用NA/空字符串；literal ID `NA` 如为合法基因名，必须在适配器中改用其他明确的缺失编码并同步本读取函数。

```r
need <- function(pkgs) {
  absent <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly=TRUE)]
  if (length(absent)) stop("Missing packages (no auto-install): ", paste(absent, collapse=", "))
}
read_tsv <- function(path, cols) {
  x <- read.delim(path, colClasses="character", check.names=FALSE,
                  na.strings=c("", "NA"), quote="", comment.char="")
  if (anyDuplicated(names(x)) || !all(cols %in% names(x))) stop("Bad columns: ", path)
  if (!nrow(x)) stop("Empty table: ", path)
  x
}
key <- function(x, cols) {
  if (anyNA(x[cols]) || any(vapply(x[cols], function(z) any(!nzchar(z)), logical(1))))
    stop("Missing key")
  if (anyDuplicated(x[cols])) stop("Duplicate key: ", paste(cols, collapse="+"))
  invisible(x)
}
num <- function(x, allow_na=FALSE, nonnegative=FALSE) {
  z <- suppressWarnings(as.numeric(x))
  if (any(!is.na(x) & is.na(z)) || any(!is.finite(z) & !is.na(z))) stop("Invalid number")
  if (!allow_na && anyNA(z)) stop("Missing number")
  if (nonnegative && any(z < 0, na.rm=TRUE)) stop("Negative value")
  z
}
quant <- function(x, value="value", status="quant_status") {
  x[[value]] <- num(x[[value]], allow_na=TRUE, nonnegative=TRUE)
  if (anyNA(x[[status]]) || !all(x[[status]] %in% c("measured", "not_quantified", "low_confidence")))
    stop("Unknown quant_status")
  if (any(x[[status]] == "measured" & is.na(x[[value]]))) stop("Measured value missing")
  if (any(x[[status]] != "measured" & !is.na(x[[value]])))
    stop("Move low-confidence raw values to an audit column; displayed value must be NA")
  x
}
begin_figure <- function(parent, name, inputs) {
  need("digest")
  if (!dir.exists(parent) || !grepl("^[A-Za-z0-9_.-]+$", name)) stop("Bad output parent/name")
  d <- file.path(normalizePath(parent, mustWork=TRUE), name)
  if (file.exists(d) || nzchar(Sys.readlink(d))) stop("Output exists: ", d)
  if (!dir.create(d)) stop("Cannot create output")
  stopifnot(all(file.exists(inputs)))
  hashes <- vapply(inputs, function(p) digest::digest(file=p, algo="sha256"), character(1))
  write.table(data.frame(path=normalizePath(inputs), sha256=unname(hashes)),
              file.path(d,"input_sha256.tsv"), sep="\t", row.names=FALSE, quote=FALSE)
  d
}
save_data <- function(x, path) write.table(x, path, sep="\t", quote=FALSE,
                                           row.names=FALSE, na="NA")
save_plot <- function(p, d, width=10, height=7) {
  need("ggplot2")
  ggplot2::ggsave(file.path(d,"figure.pdf"), p, width=width, height=height, units="in")
  ggplot2::ggsave(file.path(d,"figure.svg"), p, width=width, height=height, units="in", device=grDevices::svg)
  ggplot2::ggsave(file.path(d,"figure.png"), p, width=width, height=height, units="in", dpi=200)
  writeLines(capture.output(sessionInfo()), file.path(d,"sessionInfo.txt"))
}
group_colors <- c(C="#4477AA", L="#228833", M="#CCBB44", H="#AA3377")
input_dir <- "/absolute/path/to/reviewed_plot_tables"
output_parent <- "/absolute/path/to/new_plot_workspace"
```

低可信原值并不应从原始表删除。这里采用“图中NA+附表保留原值”的演示策略；若协议允许带警示绘制低可信数值，应先明确扩展状态映射与图例，不能绕过此检查静默纳入。

## FR01 — 每笼基因/KO dot plot

输入 `feature_values.tsv` 精确列：`sample_id,feature_ns,feature_id,value,unit,quant_status`；一图一个namespace/单位，一行一个样本×功能，`value`是已审核量化。`samples.tsv`为`sample_id,cage_id,group`，本配方仅适用每笼一个独立样本的DBDPE设计。已经聚类的family也可以画，但标题必须写family，不能冒充locus。图中cross为未量化；不计算组P值。

```r
need("ggplot2")
files <- file.path(input_dir, c("feature_values.tsv", "samples.tsv"))
x <- read_tsv(files[1], c("sample_id","feature_ns","feature_id","value","unit","quant_status"))
s <- read_tsv(files[2], c("sample_id","cage_id","group"))
key(s,"sample_id"); key(s,"cage_id"); key(x,c("sample_id","feature_id"))
stopifnot(!anyNA(x[c("feature_ns","unit")]), length(unique(x$feature_ns)) == 1L, length(unique(x$unit)) == 1L,
          !anyNA(s$group), all(s$group %in% names(group_colors)), setequal(x$sample_id,s$sample_id))
x <- quant(x); x$sample_id <- factor(x$sample_id, levels=s$sample_id)
x$group <- factor(s$group[match(as.character(x$sample_id),s$sample_id)], levels=names(group_colors))
features <- unique(x$feature_id)
stopifnot(nrow(x) == length(features)*nrow(s)) # explicit NA rows required
x$feature_id <- factor(x$feature_id, levels=rev(features))
x$display <- log2(x$value + 1)
p <- ggplot2::ggplot(x, ggplot2::aes(sample_id,feature_id)) +
  ggplot2::geom_point(data=x[!is.na(x$display) & x$display>0,], ggplot2::aes(size=display,colour=group)) +
  ggplot2::geom_point(data=x[!is.na(x$display) & x$display==0,], shape=1, size=1.5, colour="grey40") +
  ggplot2::geom_point(data=x[is.na(x$display),], shape=4, size=2, colour="grey40") +
  ggplot2::scale_colour_manual(values=group_colors, drop=FALSE) +
  ggplot2::scale_size_area(max_size=7, name=paste0("log2(",unique(x$unit),"+1)")) +
  ggplot2::labs(x="Independent cage sample",y=unique(x$feature_ns),
                caption="Positive-point area = log abundance; open circle = measured zero; cross = not quantified/low confidence; no test") +
  ggplot2::theme_bw() + ggplot2::theme(axis.text.x=ggplot2::element_text(angle=45,hjust=1))
d <- begin_figure(output_parent,"FR01_preview_v1",files)
save_data(x,file.path(d,"plot_data.tsv")); save_plot(p,d,height=max(5,0.24*length(features)))
```

测量零使用固定空心小圆，未量化使用cross，与正量化面积映射明确分开；检查图注及真实数据点。检出率作点大小需另有检测规则与已评估分母，不从 `value>0` 临时发明阈值。

## FR02 — 具体基因/KO/pathway热图

沿用FR01两个文件；热图默认不聚类，不允许缺少样本—功能行。`grey90`是NA，测量零是色标低端。不同namespace、聚合算法或单位分别运行；原始TPM和row-z版本不能共用标题。

```r
need(c("ComplexHeatmap","circlize"))
files <- file.path(input_dir,c("feature_values.tsv","samples.tsv"))
x <- read_tsv(files[1],c("sample_id","feature_ns","feature_id","value","unit","quant_status"))
s <- read_tsv(files[2],c("sample_id","group"))
key(s,"sample_id"); key(x,c("sample_id","feature_id")); x <- quant(x)
stopifnot(!anyNA(x[c("feature_ns","unit")]),length(unique(x$feature_ns))==1L, length(unique(x$unit))==1L,
          setequal(x$sample_id,s$sample_id), !anyNA(s$group), all(s$group %in% names(group_colors)))
ids <- unique(x$feature_id)
stopifnot(nrow(x)==length(ids)*nrow(s))
m <- matrix(NA_real_, length(ids), nrow(s), dimnames=list(ids,s$sample_id))
m[cbind(match(x$feature_id,ids),match(x$sample_id,s$sample_id))] <- x$value
display <- log2(m+1)
hi <- max(display,na.rm=TRUE)
if (!is.finite(hi)) stop("No finite measured values")
if (hi==0) hi <- 1 # display range only; zeros remain zeros
ha <- ComplexHeatmap::HeatmapAnnotation(group=s$group,col=list(group=group_colors))
h <- ComplexHeatmap::Heatmap(display,name=paste0("log2(",unique(x$unit),"+1)"),
    col=circlize::colorRamp2(c(0,hi/2,hi),c("#F7FBFF","#6BAED6","#08306B")),
    na_col="grey90",cluster_rows=FALSE,cluster_columns=FALSE,
    top_annotation=ha,show_row_names=TRUE,use_raster=FALSE)
d <- begin_figure(output_parent,"FR02_preview_v1",files)
save_data(data.frame(feature_id=rownames(m),m,check.names=FALSE),file.path(d,"raw_matrix.tsv"))
save_data(data.frame(feature_id=rownames(display),display,check.names=FALSE),file.path(d,"display_matrix.tsv"))
w <- 10; height <- max(5,0.20*nrow(m))
grDevices::pdf(file.path(d,"figure.pdf"),width=w,height=height); ComplexHeatmap::draw(h); grDevices::dev.off()
grDevices::svg(file.path(d,"figure.svg"),width=w,height=height); ComplexHeatmap::draw(h); grDevices::dev.off()
grDevices::png(file.path(d,"figure.png"),width=w,height=height,units="in",res=200); ComplexHeatmap::draw(h); grDevices::dev.off()
writeLines(capture.output(sessionInfo()),file.path(d,"sessionInfo.txt"))
```

上例仅适合可读小预览。数千行不能只把height无限放大；先固定完整排序，概览采用声明的tile栅格化，细节分成可读页，核验页间无缺行/重复。包的颜色NA能力参考[ComplexHeatmap官方手册](https://jokergoo.github.io/ComplexHeatmap-reference/book/a-single-heatmap.html)。

## FR03 — 每笼目标功能的MAG贡献

`contributions.tsv`：`sample_id,feature_id,mag_id,contribution,unit`；完整残差以`Unbinned`/`Unassigned`单独行表示。`feature_totals.tsv`：`sample_id,feature_id,total,unit`；一个目标功能、同一可量化范围。贡献必须来自独立可辨识位点量化或审核后的family分配，不能把family TPM复制到所有member。此例数值全已评估；partial totals须另用状态版图，不能漏掉NA项。

```r
need("ggplot2")
files <- file.path(input_dir,c("contributions.tsv","feature_totals.tsv"))
x <- read_tsv(files[1],c("sample_id","feature_id","mag_id","contribution","unit"))
t <- read_tsv(files[2],c("sample_id","feature_id","total","unit"))
key(x,c("sample_id","feature_id","mag_id")); key(t,c("sample_id","feature_id"))
x$contribution <- num(x$contribution,nonnegative=TRUE); t$total <- num(t$total,nonnegative=TRUE)
stopifnot(!anyNA(x$unit),!anyNA(t$unit),length(unique(x$feature_id))==1L, identical(unique(x$feature_id),unique(t$feature_id)),
          length(unique(x$unit))==1L, identical(unique(x$unit),unique(t$unit)),setequal(x$sample_id,t$sample_id))
a <- aggregate(contribution ~ sample_id,data=x,sum)
expected <- t$total[match(a$sample_id,t$sample_id)]
stopifnot(all(abs(a$contribution-expected) <= 1e-7*pmax(1,abs(expected))))
x$sample_id <- factor(x$sample_id,levels=t$sample_id)
p <- ggplot2::ggplot(x,ggplot2::aes(sample_id,contribution,fill=mag_id)) +
  ggplot2::geom_col() + ggplot2::theme_bw() +
  ggplot2::labs(x="Independent sample",y=unique(x$unit),fill="MAG / residual",title=unique(x$feature_id))
d <- begin_figure(output_parent,"FR03_preview_v1",files)
save_data(x,file.path(d,"plot_data.tsv")); save_data(a,file.path(d,"mass_balance.tsv")); save_plot(p,d)
```

MAG很多时按预先决定的排序合并“Other”，同时保存每个MAG原表与组成列表；不要因图例拥挤丢掉贡献。功能内部百分比须另导出、注明分母；总量0样本的百分比是未定义，不是每类0%。

## FR04 — KEGG module必需步骤与未知缺口

`module_blocks.tsv`列：`scope_id,module_id,block_id,block_order,required,status,logic_expression,definition_sha256`；一个module，所有scope×block完整笛卡尔积。`required`用TRUE/FALSE字符串，状态为present/not_detected/unknown。输入来自审核的定义解析/证据评估，不能把含全部KO的列表手工代替AND/OR逻辑。

```r
need("ggplot2")
f <- file.path(input_dir,"module_blocks.tsv")
x <- read_tsv(f,c("scope_id","module_id","block_id","block_order","required","status","logic_expression","definition_sha256"))
key(x,c("scope_id","module_id","block_id"))
stopifnot(!anyNA(x$definition_sha256),length(unique(x$module_id))==1L,length(unique(x$definition_sha256))==1L,
          !anyNA(x$status),all(x$status %in% c("present","not_detected","unknown")),
          !anyNA(x$required),all(x$required %in% c("TRUE","FALSE")))
x$block_order <- num(x$block_order,nonnegative=TRUE)
b <- unique(x[c("block_id","block_order","required","logic_expression")]); key(b,"block_id")
stopifnot(nrow(x)==length(unique(x$scope_id))*nrow(b))
x$block_id <- factor(x$block_id,levels=b$block_id[order(b$block_order)])
cols <- c(present="#228833",not_detected="#EE7733",unknown="#BBBBBB")
p <- ggplot2::ggplot(x,ggplot2::aes(block_id,scope_id,fill=status)) +
  ggplot2::geom_tile(colour="white") +
  ggplot2::geom_point(data=x[x$required=="FALSE",],shape=0,size=3) +
  ggplot2::scale_fill_manual(values=cols,drop=FALSE) + ggplot2::theme_bw() +
  ggplot2::labs(x="Definition block",y="Explicitly defined scope",title=unique(x$module_id),
                caption="Square border: optional item; unknown is not absence; abundance is shown separately")
d <- begin_figure(output_parent,"FR04_preview_v1",f)
save_data(x,file.path(d,"plot_data.tsv")); save_plot(p,d)
```

required/nonrequired的表达需与你的block解析契约一致：可选亚基常在必需block内部，不能为作图把亚基提升为新的独立必需block。需要细到亚基时扩展`item_id,parent_block_id`并单独画，保留原逻辑树。[KEGG MODULE 官方语法](https://www.kegg.jp/kegg/module.html)。

## FR05 — Contig基因箭头与family量化旁表

`loci.tsv`：`gene_id,family_id,contig_id,start,end,strand,function_label`，每行一个连续区间的CDS位点；`contigs.tsv`：`contig_id,length`。原坐标为1-based closed，此例显示为0-based half-open区间 `[start-1,end)`，保证箭头宽度等于CDS区间长度。多片段/跨原点CDS需要专门适配，不可直接用此例。

```r
need(c("ggplot2","gggenes"))
files <- file.path(input_dir,c("loci.tsv","contigs.tsv"))
x <- read_tsv(files[1],c("gene_id","family_id","contig_id","start","end","strand","function_label"))
c <- read_tsv(files[2],c("contig_id","length"))
key(x,"gene_id"); key(c,"contig_id")
stopifnot(all(x$contig_id %in% c$contig_id),!anyNA(x$strand),all(x$strand %in% c("+","-")))
x$start <- num(x$start); x$end <- num(x$end); c$length <- num(c$length)
len <- c$length[match(x$contig_id,c$contig_id)]
stopifnot(all(x$start>=1 & x$start<=x$end & x$end<=len),all(x$start==floor(x$start)),all(x$end==floor(x$end)))
x$xmin <- x$start-1; x$xmax <- x$end
x$function_label[is.na(x$function_label)] <- "Unannotated"
p <- ggplot2::ggplot(x,ggplot2::aes(xmin=xmin,xmax=xmax,y=contig_id,forward=strand=="+",fill=function_label)) +
  gggenes::geom_gene_arrow() + ggplot2::theme_bw() +
  ggplot2::labs(x="Position (bp; 0-based display)",y="Contig",fill="Function evidence",
    caption="Coordinates are real; adjacency does not establish an operon. Family abundance is not locus-specific.")
d <- begin_figure(output_parent,"FR05_preview_v1",files)
save_data(x,file.path(d,"locus_coordinates_and_family_ids.tsv")); save_plot(p,d)
```

此例用统一x尺度，长度跨度太大时做独立邻域页，并明确尺度差异。如果另画family TPM，保持每family×sample一行，通过链接指向所有位点；不要复制到locus后计算contig/MAG总量。若读者只需各位点旁显示相同family曲线，必须标“同一共享profile重复展示”，且不求和。颜色一致也不证明同源，需实际注释/比对证据。[gggenes作者API](https://wilkox.org/gggenes/)。

## FR06 — 已分配质量守恒的alluvial

`flows.tsv`：`flow_id,quant_id,mag_id,function_id,pathway_id,weight,unit`；一条完整三轴分配路径一行，未分配项显式保留。`source_values.tsv`：`quant_id,value,unit`；`quant_id`是实际量化单位（可能是代表基因/family），不是多个member位点。一个样本一个图，先在数据准备阶段确定合法分配权重；图函数不自行判断一基因属于哪个pathway。多标签复制口径不得送入本例。

```r
need(c("ggplot2","ggalluvial"))
files <- file.path(input_dir,c("flows.tsv","source_values.tsv"))
x <- read_tsv(files[1],c("flow_id","quant_id","mag_id","function_id","pathway_id","weight","unit"))
v <- read_tsv(files[2],c("quant_id","value","unit"))
key(x,"flow_id"); key(v,"quant_id")
stopifnot(!anyNA(x[c("quant_id","mag_id","function_id","pathway_id","unit")]),!anyNA(v$unit),setequal(x$quant_id,v$quant_id),
          length(unique(x$unit))==1L,identical(unique(x$unit),unique(v$unit)))
x$weight <- num(x$weight,nonnegative=TRUE); v$value <- num(v$value,nonnegative=TRUE)
a <- aggregate(weight ~ quant_id,data=x,sum)
expected <- v$value[match(a$quant_id,v$quant_id)]
stopifnot(all(abs(a$weight-expected) <= 1e-7*pmax(1,abs(expected))))
x$mag_axis <- paste0("MAG:",x$mag_id)
x$function_axis <- paste0("Function:",x$function_id)
x$pathway_axis <- paste0("Pathway:",x$pathway_id)
stopifnot(ggalluvial::is_alluvia_form(x,axes=match(c("mag_axis","function_axis","pathway_axis"),names(x)),silent=TRUE))
p <- ggplot2::ggplot(x,ggplot2::aes(y=weight,axis1=mag_axis,axis2=function_axis,axis3=pathway_axis)) +
  ggalluvial::geom_alluvium(ggplot2::aes(fill=mag_axis),width=0.15,alpha=0.7) +
  ggalluvial::geom_stratum(width=0.15,fill="grey90",colour="grey30") +
  ggplot2::geom_text(stat="stratum",ggplot2::aes(label=ggplot2::after_stat(stratum)),size=2.5) +
  ggplot2::scale_x_discrete(limits=c("MAG","Function","Pathway"),expand=c(0.1,0.1)) +
  ggplot2::labs(y=paste("Allocated",unique(x$unit)),x=NULL,fill="Source") + ggplot2::theme_minimal()
d <- begin_figure(output_parent,"FR06_preview_v1",files)
save_data(x,file.path(d,"plot_data.tsv")); save_data(a,file.path(d,"per_quant_id_mass_balance.tsv")); save_plot(p,d)
```

多个完整路径归属不是存在唯一真实“流向”的证据；如果分配是人为均分，图注应写出均分，不写代谢流。默认大图建议换成分面贡献矩阵，避免线宽掩盖小项。[ggalluvial官方数据格式](https://corybrunson.github.io/ggalluvial/articles/ggalluvial.html)。

## FR07 — 合法本地KGML/PNG的pathview着色

`ko_values.tsv`：`ko_id,value,unit`，唯一`K`加五位数字ID，已经审核的一份样本KO丰度；多KO分配规则在上游确定。需要本地`ko00010.xml`和`ko00010.png`一对**来自同一版本/同一图**的文件，`00010`只表示预选目标，不是默认要分析糖酵解。写入另一个新目录，旧缓存只读。输入可替换为其他实际pathway，但必须保留图源/许可。

pathview文档允许`kegg.dir`使用本地匹配文件；有些路径或依赖仍可能尝试联网。**文件存在检查不是断网保证**。本例只在执行环境已独立验证为禁止网络并记录证据时运行；缺资源或库尝试外连则失败，不自动重试在线版本。下面的显式变量只是操作者确认该前提的开关，本身不提供网络隔离。

```r
need("pathview")
offline_environment_verified <- FALSE # set TRUE only after an actual external isolation check
if (!isTRUE(offline_environment_verified)) stop("Verify and record an offline execution environment first")
pathway_id <- "00010"
cache <- "/absolute/path/to/authorized_local_kegg_cache"
f <- file.path(input_dir,"ko_values.tsv")
resource <- file.path(cache,paste0("ko",pathway_id,c(".xml",".png")))
if (!all(file.exists(resource))) stop("Missing local KEGG resources; do not download automatically")
x <- read_tsv(f,c("ko_id","value","unit")); key(x,"ko_id")
stopifnot(!anyNA(x$unit),all(grepl("^K[0-9]{5}$",x$ko_id)),length(unique(x$unit))==1L)
x$value <- num(x$value,nonnegative=TRUE)
# Max of log2(KO abundance + 1) per graphical node: an explicit display rule, not total node abundance.
v <- setNames(log2(x$value+1),x$ko_id)
d <- begin_figure(output_parent,"FR07_preview_v1",c(f,resource))
stopifnot(all(file.copy(resource,d,overwrite=FALSE)))
hi <- max(1,max(v))
pv <- pathview::pathview(gene.data=v,pathway.id=pathway_id,species="ko",gene.idtype="kegg",
        kegg.dir=d,kegg.native=TRUE,map.symbol=FALSE,map.cpdname=FALSE,
        node.sum="max",both.dirs=list(gene=FALSE,cpd=FALSE),
        limit=list(gene=hi,cpd=1),out.suffix="local_abundance",
        low=list(gene="#F7FBFF",cpd="#F7FBFF"),mid=list(gene="#F7FBFF",cpd="#F7FBFF"),
        high=list(gene="#08306B",cpd="#08306B"),na.col="grey85")
saveRDS(pv,file.path(d,"pathview_return.rds")); save_data(x,file.path(d,"ko_input.tsv"))
if (!is.null(pv$plot.data.gene)) save_data(pv$plot.data.gene,file.path(d,"node_mapping_and_values.tsv"))
writeLines(capture.output(sessionInfo()),file.path(d,"sessionInfo.txt"))
```

必须从返回节点映射核对哪些KO被使用、哪些未映射和多值节点实际显示值；API或返回结构与当前包不符就停下适配，不能写“已全部映射”。`kegg.native=TRUE`原生结果是栅格图，不能声称完整矢量；如需editable graph，另选KGML图形路线并记录它不保留原图全部绘图细节。不要把KO存在/高丰度说成完整通路/活性。若绘效应值，不使用此单向max规则：需独立协议决定同节点异向效应与颜色，附所有成员效应。[pathview官方手册](https://bioconductor.org/packages/release/bioc/manuals/pathview/man/pathview.pdf)。

## FR08 — 已有基因/KO/pathway效应及区间

`effects.tsv`：`feature_id,contrast,effect,lower,upper,effect_unit,interval_type,qvalue,model_id,n_units`；每feature×contrast一个已审核结果。该例仅接收log2 fold change，其无效应参考线为0；比值尺度要改为1并用对应模型CI，不能只改轴标签。q缺失可保留NA，不能由作图程序补检验。

```r
need("ggplot2")
f <- file.path(input_dir,"effects.tsv")
x <- read_tsv(f,c("feature_id","contrast","effect","lower","upper","effect_unit","interval_type","qvalue","model_id","n_units"))
key(x,c("feature_id","contrast"))
stopifnot(!anyNA(x$effect_unit),all(x$effect_unit=="log2_fold_change"),length(unique(x$interval_type))==1L,
          !anyNA(x$model_id),!anyNA(x$interval_type))
for (z in c("effect","lower","upper","n_units")) x[[z]] <- num(x[[z]])
x$qvalue <- num(x$qvalue,allow_na=TRUE,nonnegative=TRUE)
stopifnot(all(x$lower <= x$effect & x$effect <= x$upper),all(x$n_units>0),all(x$qvalue<=1,na.rm=TRUE))
x$feature_id <- factor(x$feature_id,levels=rev(unique(x$feature_id)))
p <- ggplot2::ggplot(x,ggplot2::aes(effect,feature_id)) +
  ggplot2::geom_vline(xintercept=0,linetype=2,colour="grey50") +
  ggplot2::geom_segment(ggplot2::aes(x=lower,xend=upper,yend=feature_id)) +
  ggplot2::geom_point(size=2) + ggplot2::facet_wrap(~contrast) + ggplot2::theme_bw() +
  ggplot2::labs(x="log2 fold change (fitted upstream)",y=NULL,
               caption=paste("Intervals:",unique(x$interval_type),"; original q-values and n in companion table"))
d <- begin_figure(output_parent,"FR08_preview_v1",f)
save_data(x,file.path(d,"plot_data.tsv")); save_plot(p,d,height=max(5,0.25*length(levels(x$feature_id))))
```

效应大小的比较要求模型尺度和参照明确；不要将不同模型的条件效应混成一个统一排名。区间缺失的结果可另用点图，但不杜撰误差条。富集结果和WGCNA相关性有不同单位与背景，不能强塞入log2FC格式。

## 每个配方之后

保存实际脚本、输出SHA256、未映射/残差表、转换与聚合说明；用实际图像检查文字/图例、边界、颜色与数字是否一致。至少抽查一个多映射基因、一个NA、一个零、一个高值、一个反链/末端位点和最密面板。大图检查首/中/尾页及页间ID连续性。`parse()`通过、包加载、数值检查、图文件生成和人眼验收各自记录；不能互相替代。示例配方没有自动提升任何产物为正式结果，也不改正在运行的项目。
