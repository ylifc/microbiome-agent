# 微生物系统发育与关联视图图谱

按问题选图，不把图种清单当作必须全部执行的分析。下列 **16 类**各有目的、输入、工具入口、解释边界与验收。函数/格式依据末尾官方资料核实，访问日期 **2026-10-14**。这些是绘图配方；仅第 1–5 类的部分基础布局提供了新增 R CLI 实现，且当前环境缺依赖，未完成 R 图形运行验收。Python 大树分页工具的已有验收也不自动覆盖这里的高级 R 配方。

## 通用科学与身份约定

- 保存原树、MSA/建树记录、taxonomy/样本 metadata、文件哈希、软件版本；每个叶节点用稳定 genome ID。每个视图的叶集、分支与标注必须能回到这些来源。不得通过截断标签或跨样本去重“解决”拥挤。
- ML bootstrap、UFBoot、SH-aLRT 是不同统计量；gCF/sCF 是基因树/位点一致性，均不能改名为 bootstrap。`SH-aLRT/UFBoot` 的顺序必须来自实际原生证据。无值与零值不同，零值也不应被阈值代码自动隐藏。
- 外群、时钟或其他方法决定的根需单独证据。矩形的左端、圆形的中心、无根图的绘图起点都不证明祖先方向。换布局不改变科学拓扑；旋转节点不构成拓扑改变。重新定根、剪枝、折叠或重新推断必须记录其具体操作。
- 完全相同 MSA 的不同样本身份保留；只有成员列表、计数和分组互相一致的多成员声明才可标“MSA 无法区分”。单例或仅有 hash/未知大小分组不能标为重复，序列相同也不证明同一菌株。
- 1,000+ 叶默认采用总览 + 分页细图 + 完整叶/分支索引。总览可明确省略文字，细图/表格须保留原值。针对新布局先看一个真实小预览；正常颜色、字号修正不必反复请求批准。

## 1. 矩形 phylogram：读分支长度与身份

- **目的**：并列读 MAG 身份、分支长度和支持度，是需要精确标签时的首选。
- **输入**：已推断 Newick，有限非负分支长度及单位；精确一对一 metadata；支持度顺序与来源。
- **R/其他软件**：`ape::plot.phylo(tr, type="phylogram", use.edge.length=TRUE)`；`ggtree::ggtree(tr, ladderize=FALSE)`。Python 现有 renderer 可输出分页完整标签；iTOL 的 rectangular 显示也可用。[ape 手册](https://cran.r-project.org/web/packages/ape/ape.pdf)
- **边界**：横向距离一般是替换数/位点，不是年；相邻叶显示顺序不等于更近。绘图不得自行缩短长枝。
- **验收**：输入/输出叶身份、长度与支持度原值一致；刻度单位明确；长标签和低/零支持可读；若按页裁切，说明是同一树的窗口而非独立子树。

## 2. Cladogram：突出拓扑

- **目的**：需要比较分支关系而不讨论进化距离时使用。
- **输入**：原拓扑和身份；原生长度仍归档，不覆盖成绘图坐标。
- **R/其他软件**：`ggtree(tr, branch.length="none", ladderize=FALSE)`；`ape::plot.phylo(tr, use.edge.length=FALSE)`。新增 R 入口 `--layout cladogram` 只改变展示。[ggtree 布局官方章节](https://yulab-smu.top/treedata-book-2ed/04_ggtree_visualization.html)
- **边界**：等长显示不是分子钟；“cladogram”描述展示，不能替代推断方法说明。
- **验收**：canonical split 集不变；图上明确 topology only；不得残留 substitutions/site 或年份刻度。

## 3. Circular：全树和多层注释总览

- **目的**：压缩大树总览，并给外圈 annotation 留空间。
- **输入**：同一原树、叶 metadata、明确显示哪些外圈字段；详细身份另表。
- **R/其他软件**：`ggtree(tr, layout="circular", ladderize=FALSE)`，标签可用 `geom_tiplab()`；iTOL 选择 circular。新增 R `--backend ggtree --layout circular` 仅提供基础树，外圈须按第 9–10 类另写配方。[ggtree 布局](https://yulab-smu.top/treedata-book-2ed/04_ggtree_visualization.html)
- **边界**：角度/顺时针位置没有生物学含义；中心不是经证实的祖先；圆形不自动比矩形更清晰。
- **验收**：检查圆周接缝、反向标签、外圈 ID 对齐；全圆图与细图/索引一起交付，不能只给一张无法读支持值的圆图。

## 4. Fan：保留空扇区的树

- **目的**：用空扇区放图例或减少首尾标签碰撞。
- **输入**：原树、预定开口角和标签政策。
- **R/其他软件**：`ggtree(tr, layout="fan", open.angle=60)`；`ape::plot.phylo(tr, type="fan", open.angle=60)`。新增 R `--layout fan` 用 60 度空扇区。[ape 手册](https://cran.r-project.org/web/packages/ape/ape.pdf)
- **边界**：fan 和 circular 是不同绘图方式；开口只属于布局。不要用拉伸角度解释演化速度。
- **验收**：空扇区两侧标签不重叠；原叶与支持完整；文档记录角度，不改变原枝长。

## 5. Unrooted / equal-angle / daylight：避免祖先暗示

- **目的**：根没有证据时展示无根关系，检查长枝与分裂结构。
- **输入**：原树的无根 splits、长度；明确原始存储树可能有任意 root 节点。
- **R/其他软件**：`ape::plot.phylo(tr, type="unrooted")`；`ggtree(tr, layout="equal_angle")` 或 `layout="daylight"`。新增 R 的 ggtree unrooted 对应 equal-angle；daylight 仅列配方。[ggtree 无根布局](https://yulab-smu.top/treedata-book-2ed/04_ggtree_visualization.html)
- **边界**：不能从画面中央推断祖先；角度优化不改变树，却可能改变视觉紧密程度。
- **验收**：无根 canonical splits 不变；所有叶仍出现；密集分叉的支持标签须另给细图或映射表。

## 6. Time tree：经校准的时间树

- **目的**：展示分化时间或采样时间与树的关系。
- **输入**：**已有日期/时间单位的校准树**，tip 日期及精度、校准点和约束、定根/时钟模型、后验或置信区间来源。仅有“测序日期”或普通 MAG ML 树不足以生成 time tree。
- **R/其他软件**：`treeio::read.beast()` 保留已推断树的时间/区间信息，再用 `ggtree()` 的时间相关布局、`mrsd` 和区间图层；`ape::plotTreeTime()` 可将提供的 tip 日期与树关联。`chronos()` 等属于额外推断，不由绘图入口自动运行。[treeio 官方手册](https://www.bioconductor.org/packages/release/bioc/manuals/treeio/man/treeio.pdf)、[ape 手册](https://cran.r-project.org/web/packages/ape/ape.pdf)
- **边界**：绘图添加日期不完成分子钟校准；不同校准模型的区间不可混用，HPD 也不是 bootstrap。
- **验收**：日期按 ID 对齐；单位与“距今年数/公历年”方向明确；缺失日期和区间显示缺失；时钟树的原始科学审核独立于图像验收。

## 7. Collapsed clades：折叠大型分支

- **目的**：保留全树关系的同时压缩已定义 clade，另提供展开细图。
- **输入**：原树、要折叠的**精确叶集合**及其在当前树中的单系性、显示标签、成员数与质量摘要。
- **R/其他软件**：`ggtree::collapse(p, node=..., mode="mixed")`，`expand()` 恢复；`geom_cladelab()` 注释。节点编号只在特定树对象中有效，须先用成员映射回节点。[ggtree 折叠章节](https://yulab-smu.top/treedata-book-2ed/07_ggtree_manipulation.html)
- **边界**：一个 taxonomy 名称不保证单系，不能把散落多处的同门 MAG 强行折成一个 clade；三角形面积不自动代表丰度或支持。
- **验收**：折叠成员总数加未折叠叶数等于原总数；无重复/丢失；完整成员清单与未折叠树可获取；三角形尺寸的含义明确。

## 8. Taxonomy hierarchy 与 sequence tree 对照

- **目的**：解释分类层级与序列系统发育的一致/不一致，避免把 taxonomy 图冒充进化树。
- **输入**：taxonomy 数据库版本和 rank 链；序列树独立来源；稳定 genome ID 的对应表；未分类项单独保留。
- **R/其他软件**：`ape::as.phylo(~phylum/class/order/family/genus/species, data=...)` 能表达嵌套分类结构；序列树用 `ggtree()`，二者以身份索引或第 12 类连线对照。[ape 分类公式手册](https://cran.r-project.org/web/packages/ape/ape.pdf)
- **边界**：分类层级边长没有 substitutions/site 意义；species 字符串可重复，不能取代 genome ID。分类图的分支支持通常不存在。
- **验收**：图标题显式 taxonomy hierarchy / sequence phylogeny；说明分类版本；不同树的共同比较单位必须一致，不能把物种节点和每样本 MAG 叶直接一一对应。

## 9. Tree + heatmap：功能/丰度/质量关联

- **目的**：并列观察树与功能模块、基因 presence/absence、覆盖度或样本丰度模式。
- **输入**：tree；行键是叶 ID 的数值矩阵；列含义、单位、归一化与缺失政策。一个样本内多个 MAG 不作为独立处理重复。
- **R/其他软件**：`ggtree::gheatmap(p, matrix, ...)`；矩形附图可用 `geom_facet()`。行按树顺序匹配，不能靠文件当前顺序。[ggtree 数据关联章节](https://yulab-smu.top/treedata-book-2ed/08_ggtree_tree_with_data.html)
- **边界**：对数/标准化改变颜色含义；0 与未测/未注释不同。图上相关不证明进化机制或剂量效应。
- **验收**：记录匹配、缺失与额外 ID 数；颜色标尺及变换明确；抽查首中末行；若允许只选部分列，完整矩阵另存而不是静默删列。

## 10. 外圈 bars / points / binary tracks

- **目的**：在大树周围表达组别、质量、MAG 丰度或特定功能的多层信息。
- **输入**：长表 `genome_id, variable, value`，每字段单位、缺失状态和分组颜色；多个测量/样本需明确聚合方法。
- **R/其他软件**：`ggtreeExtra::geom_fruit(data=..., geom=ggplot2::geom_col, mapping=aes(y=genome_id, x=value))`；点/热图可换对应 geom。iTOL 使用当前官方 simplebar、multibar、binary、colorstrip 模板，准备本地导入包，上传需在用户范围内。[ggtreeExtra 官方章节](https://yulab-smu.top/treedata-book/chapter10.html)、[iTOL 官方说明](https://itol.embl.de/help.cgi)
- **边界**：正负条形、比例与绝对量不可共用无说明标尺；iTOL binary 的缺失与0值须按格式区分。外圈宽度不是系统发育距离。
- **验收**：逐层记录 ID 覆盖和单位；色键一致；环间距、文本、最外圈不裁切；本地包附树版本和dataset模板版本。

## 11. 分支支持与 gCF / sCF 对照

- **目的**：同时显示拓扑估计的支持与基因/位点之间的一致性，识别“高支持但低一致性”的分支。
- **输入**：原 ML 树及支持；实际 `.cf.branch`、`.cf.stat`、`.cf.tree`；生成日志、模型、MSA/基因树来源；由**同一完整叶集 canonical unrooted split**得到的 branch ID 映射。不能跨程序直接以数字 node ID 合并。
- **R/其他软件**：先生成审核后的 split 表，再把表接到 ggtree 节点/分支图层或 iTOL branch datasets。IQ-TREE 的官方文档区分 gCF 与 sCF，并给出固定拓扑 `-te` 的 sCF 计算示例；这里不启动推断。[IQ-TREE concordance 文档](https://iqtree.github.io/doc/Concordance-Factor)
- **边界**：sCF 不等于 bootstrap；`sN=0` 标无信息/NA，即使原文件占位值为0；只有 `sN>0 && sCF==0` 才表示实际零一致率。gCF 也要检查其 decisive-gene 分母。新文件未携带旧支持时，从原 ML 对应 split 读取，不用 sCF 补成支持。
- **验收**：所有 splits 完全匹配、重复映射无歧义；值有限且范围正确；保持原始值/分母/信息 flag；核对每层图例和顺序；不把固定拓扑命令的退出0当成拓扑未变的证明。

## 12. Tanglegram / RF：两树对应关系

- **目的**：比较两套建树方法、核心/扩展共同叶或不同标记树的拓扑。
- **输入**：两个树及其样本单位；显式共同叶清单；若修剪只在派生副本上操作，保留各树排除 ID。一对多关联另给 association 表。
- **R/其他软件**：`phytools::cophylo(tr1, tr2, assoc=..., rotate=TRUE)` 后 `plot()`；`phangorn::RF.dist(..., rooted=FALSE, normalize=...)` 计算预先选定的比较。旋转优化连线不改变科学分支。[phytools 官方手册](https://cran.r-project.org/web/packages/phytools/phytools.pdf)、[phangorn RF 文档](https://search.r-project.org/CRAN/refmans/phangorn/html/treedist.html)
- **边界**：连线少交叉不等于树一致；RF 不测分支长度，受叶集、二分/多分及是否归一化影响。不能直接比较691与1106叶完整树的RF。
- **验收**：明确共同叶数/排除数、rooted或unrooted、原始或归一化距离；连线端点精确；报告 split 差异清单而不只给一个分数。

## 13. Gene tree / species tree discordance

- **目的**：展示单基因、标记集和物种树间的不一致及可支持的信息量。
- **输入**：同源/正交关系、各基因叶覆盖、基因树与支持、物种树、gene→genome 映射、缺失/旁系同源政策；先明确是否允许每物种多拷贝。
- **R/其他软件**：少量树用 `phytools::cophylo()`；大量基因以审核后的 split×gene 支持/一致性矩阵用 `gheatmap()` 或分面。需要 reconciliation 的 duplication/transfer/loss 事件时，使用已有专门模型结果，不能让绘图推断事件。[phytools 手册](https://cran.r-project.org/web/packages/phytools/phytools.pdf)、[ggtree 数据图层](https://yulab-smu.top/treedata-book-2ed/08_ggtree_tree_with_data.html)
- **边界**：discordance 可来自有限信息、比对误差、旁系同源或其他过程；单张冲突图不能证明 HGT。未覆盖该 split 的基因不是“不支持”。
- **验收**：分母和 missing/not decisive 标记保留；每个gene的参与叶数可查；多拷贝身份不强行合并；每个声称的事件指向其推断证据。

## 14. Placement / jplace：序列放置

- **目的**：显示 query 序列在固定参考树上的多个候选放置位置及权重。
- **输入**：实际 `.jplace` 文件中的参考树、edge numbers、queries、multiplicities、likelihood weight ratios 与距离；配套参考数据库版本。
- **R/其他软件**：`treeio::read.jplace(file)` 导入；iTOL 直接读取 `.jplace` 并生成 placement dataset，可查询一个序列的多处位置。[treeio 官方 read.jplace](https://docs.ropensci.org/treeio/reference/read.jplace.html)、[iTOL placements](https://itol.embl.de/help.cgi)
- **边界**：placement 权重不是节点bootstrap；query并非自然成为新的已推断参考树叶。只显示top1会隐藏不确定性，需明确政策并保留其余权重。
- **验收**：原生 edge number 精确映射，不与绘图 node ID 混用；每query权重和/数量检查；若有 multiplicity，区分query数与read数；多个候选位置可回查。

## 15. Split network / reticulation network

- **目的**：展示冲突 splits 或已有模型推断的网状演化关系，适合讨论重组/HGT假说但不直接证明它们。
- **输入**：明确网络类型；split权重/距离矩阵或已有network对象；若为有向reticulation网络，还需根、方向、边含义和推断模型。普通Newick树不包含这些信息。
- **R/其他软件**：已有 `phangorn` `networx` 对象可 `plot()`；SplitsTree 打开已有 network/NEXUS 并记录其workflow和显示设置。`neighborNet()`/网络推断是另一个科学步骤，不由绘图入口运行。[phangorn 官方网络 vignette](https://klausvigo.github.io/phangorn/articles/Networx.html)、[SplitsTree 官方手册](https://husonlab.github.io/splitstree6/manual.pdf)
- **边界**：split图中的盒状结构表示不相容信息，不自动等价于一次真实杂交或HGT事件；无向split network与有向进化网络不得混称。
- **验收**：ID、split权重/边注释完整；网络类型与推断来源写在标题/说明；没有偷偷把network转换为tree而丢边。

## 16. Dendrogram：距离聚类不等于进化树

- **目的**：展示菌群组成、功能谱或基因内容的层次聚类；与真正系统发育树做清楚区分。
- **输入**：已有 `hclust`/dendrogram 对象，原距离矩阵、变换、距离定义、linkage及样本ID。缺失值和标准化必须有依据。
- **R/其他软件**：`plot(as.dendrogram(hc))`；需要和矩阵对齐时用标准热图软件的 dendrogram 输入。`ape::as.phylo(hc)`只是对象转换，不赋予进化解释。[R 官方 hclust 文档](https://stat.ethz.ch/R-manual/R-devel/library/stats/html/hclust.html)
- **边界**：高度是指定距离/聚类准则，未必是替换数、时间或系统发育支持；距离矩阵重新聚类属于分析步骤，不能在绘图阶段悄悄换方法。
- **验收**：图标题写明 clustering、距离和linkage；行列顺序按ID而非位置匹配；高度单位明确；避免用MAG进化树的bootstrap图例。

## 新 R 入口：具体实现范围与使用

`../scripts/plot_phylogeny.R` 是**独立预览入口**，不修改现有 Python renderer。实现 ape 的 rectangular/cladogram/fan/unrooted；可选 ggtree 的这四类及 circular。**不实现**时钟推断、折叠、热图/环图、sCF/gCF映射、tanglegram、placement或network；上述是按需编写/调用的工具配方。

必需 Newick 与包含 `genome_id sample_id group phylum species` 的完整 TSV 精确连接。基础图以完整 genome ID 为叶标签；全部原 metadata 留在 `genome_index.tsv`，不会把species文本替代ID。ape后端使用C/L/M/H固定组色；ggtree基础后端目前用普通叶文字，配色表仍保存，不声称已完成外圈/分组渲染。

```bash
/home/ylifc/miniforge3/envs/microbiome/bin/Rscript --vanilla plot_phylogeny.R --check-runtime
Rscript --vanilla plot_phylogeny.R --tree synthetic.nwk --metadata synthetic.tsv \
  --out new_preview --dataset-kind synthetic --source-status synthetic_fixture \
  --description 'Synthetic layout test only' --support-order SH-aLRT/UFBoot \
  --backend ape --layout rectangular --title 'Synthetic tree preview'
```

生物数据用 `--dataset-kind biological --source-status unverified --evidence actual_audit.json`；即使 `source-status validated`，图形仍是 PREVIEW，脚本不替证据做科学审核。`--support-order none` 只允许树上原本没有节点标签；sCF/gCF 不接受为 ML 支持。超过80叶或120字符ID需要显式 `--labels none`，超过80叶支持需 `--supports table`，并使用已有Python分页工具作配套细图，不静默压缩/截断标签。

输出 `tree.pdf/svg/png`、完整 `genome_index.tsv`、`node_support.tsv`、`group_colors.tsv`、原树/metadata副本、来源及产物SHA256、`sessionInfo.txt`、警告和 `render_manifest.tsv`。节点编号只绑定原树，不得拿来直接与另一程序结果合并。所有成功输出为 `preview`，图像必须实际打开验收后另记录；不提供自动“validated”声明。

**本机验证边界（2026-10-14）**：Rscript 4.4.1 可执行；ape、ggtree、ggplot2、treeio、phytools、ggtreeExtra 均不可用。没有安装依赖；R语法解析、CLI帮助、输入选项拒绝与缺依赖拒绝可检查，**R绘图本体及图像未验证**。不得把这里的脚本实现/配方当成已经产出的可交付科学图。验证记录保存到项目 `improvements_20261014/skill_expansion_20261014/phylogeny`。
