# 基因功能聚合与 contig 功能图 CLI

这里的两个工具处理已批准、已提供的定量和映射，不运行序列注释、比对、TPM 计算、差异检验或 WGCNA。没有自动安装或下载。先按[功能数据契约](functional-data-contract.md)确认基因目录、定量层级和注释来源，再选择下列工具。必须保留数据库版本、命中筛选条件、比对定量策略、多重比对处理以及分母范围；`source-evidence` 仅记录来源文件及哈希，不证明来源科学结论正确。

## 1. 精确基因 ID → 功能数量

`scripts/aggregate_gene_functions.py` 只需 Python 标准库。

```bash
python3 scripts/aggregate_gene_functions.py \
  --genes catalog.tsv --samples samples.tsv --quant gene_quant.tsv \
  --annotations gene_annotations.tsv --members feature_members.tsv \
  --unit DNA_TPM --gene-scope representative_family \
  --multimap fractional --dataset-kind real \
  --source-evidence annotation_quantification_provenance.json \
  --source-note '代表基因目录的 DNA TPM；注释、目录和映射版本见来源记录' \
  --out NEW_OUTPUT_DIRECTORY
```

输入均为 UTF-8 TSV，ID 精确匹配、区分大小写，不自动去前缀或转换 accession。

| 文件 | 必须列 | 契约 |
| --- | --- | --- |
| `--genes` | `gene_id` | 本次定量的完整基因目录，包括未注释基因；ID 唯一 |
| `--samples` | `sample_id` | 完整样本清单；没有任何定量行的样本也保留 |
| `--quant` | `gene_id sample_id value` | 每个基因×样本最多一行；`0` 是观测零，`NA`/空值或缺行是缺失 |
| `--annotations` | `gene_id database feature_id` | 明确数据库命名空间，如 `KEGG_KO/K00001`、`COG/COG0001`、`arCOG/arCOG00001`、`NR_accession/具体蛋白accession`；一行一关系 |
| `--members`，可选 | `database feature_id target_database target_id target_kind` | 已有且有版本来源的成员关系；`target_kind` 为 `module`、`pathway` 或 `member_group` |

`--unit` 必选：`DNA_TPM`、`RNA_TPM`、`read_count`、`estimated_count`、`coverage`。原始 `read_count` 拒绝小数；分配后估计读数使用 `estimated_count`。工具不混合单位、不重算 TPM、不把 DNA 功能潜力称为转录表达；coverage 可聚合但结果是基因覆盖值之和，不是 contig 平均覆盖。`--gene-scope locus` 表示输入已是定位特异数量；`representative_family` 表示代表基因/家族目录数量。不能通过切换参数声称未做过的定位分配。

### 多重命中和层级成员数量

- `full_membership`：一个基因的完整数量进入每个已确认目标，适合展示多功能归属；跨目标加总可以大于原基因总量。
- `fractional`：每个基因在同一 layer/database 下的不同目标间等分。只是透明的分配政策，不是概率性功能判定。
- 直接层和 pathway/module 成员层独立分配。假设基因 G 同时注释 K1、K2，K1 和 K2 都属于 M1，G 在 M1 只出现一次。若 G 属于 M1、M2，fractional 在两个模块间等分；不会因两条 KO→M1 路径重复计入，也不是先给 KO 分摊再逐行累加。
- 完全重复注释/成员行合并并计入诊断；不同有效命中不会静默选一个。数据库命名空间分开，KEGG、COG、arCOG 和 NR 的量不能再合并求“总功能量”。NR accession 本身不是 KO，工具不推导 NR→KO。
- 无注释基因按每个命名空间进入 `__UNANNOTATED__`，完整 catalog 分母单独输出。这个 ID 是保留字，不允许源注释自行使用。
- 功能有任何已分配基因定量缺失时，`value=NA`，同时保存 `observed_sum` 和观测/缺失基因数。全零且完整观测才是 `value=0`。成员映射存在但目录中无对应基因时为 `no_catalog_members`、`value=NA`，不伪造生物学零。

这些是 **module/pathway member abundance（已注释成员基因数量）**。不是 pathway activity、代谢通量、KEGG MODULE 完整性或模块反应步骤是否齐全。真正模块完整性要解析版本化模块定义中的 AND/OR、替代路径和复合物，并说明 genome/MAG/community 的单位，不能用该求和脚本代替。[KEGG MODULE 官方说明](https://www.kegg.jp/kegg/module.html)与[KEGG API 数据对象及映射说明](https://www.kegg.jp/kegg/rest/keggapi.html)是读取模块与映射来源的入口；本工具不会联网调用它们。

### 输出与规模

- `functional_abundance.tsv`：命名空间、层级、功能×全样本表，数量、部分观测和缺失状态、unit/gene_scope。
- `gene_assignments.tsv`：精确基因→目标和权重，可与原始定量重新构成每个贡献。
- `sample_denominators.tsv`：完整目录的数量、观测/缺失基因数、未注释量和加权成员量，不做 annotated-only 重新归一化。
- `multimapped_genes.tsv`：多目标基因清单。
- 可选 `--write-contributions`：生成较大的 `gene_contributions.tsv`，保留每个基因×样本×功能贡献及缺失。
- `manifest.json`：输入/代码/输出 SHA-256、完整参数、Python 版本、映射和缺失诊断以及语义说明。

当前实现面向显式功能视图与可审计中等规模表，输入、倒排索引、赋值和输出表仍驻留内存。成员映射使用 `(database, feature_id)→gene` 倒排索引，不为每条成员映射扫描全基因目录。默认 `--max-output-rows 2000000` 检查功能、分配和可选贡献表；这是输出行数保护，不是总内存硬限或大数据性能保证。几十万 NR accession × 多样本可能超限：先报告规模、内存/磁盘预算，决定显式功能层级视图或编写流式版本。若筛选注释展示目标，保留完整 gene/sample 目录和原定量分母，并说明 `__UNANNOTATED__` 此时是“未映射到所选功能视图”，不能说完全未注释。禁止把基因目录分块后各自重算分母再无说明拼接。输出目录必须新建或为空，拒绝覆盖。

## 2. contig 基因箭头 + 数量热图

`scripts/plot_contig_functions.R` 只需带 Cairo 图形能力的 base R，无额外 R 包。它画一个 contig：上方使用真实物理坐标和方向的箭头，不同重叠基因放不同泳道；下方按基因坐标排序显示跨样本数量。两 panel 的水平轴不同，热图列是样本，**不是**基因物理距离。同一功能用固定颜色，未注释为灰色；输出完整颜色表。

```bash
Rscript scripts/plot_contig_functions.R \
  --genes gene_coordinates.tsv --contigs contig_lengths.tsv \
  --quant gene_quant.tsv --samples samples.tsv --contig contig_A \
  --unit DNA_TPM --quantity-scope locus --dataset-kind real \
  --source-evidence locus_quantification_provenance.json \
  --source-note '1-based inclusive；明确的位点特异定量，来源见记录' \
  --out NEW_CONTIG_FIGURE_DIRECTORY
```

`gene_coordinates.tsv` 必须列：`gene_id contig_id start end strand feature_id`，基因 ID 全表唯一，位置为 **1-based inclusive**、`start≤end` 且在提供的 contig 长度内，方向 `+`/`-`/`.`。`.` 为矩形、方向未知。`feature_id` 是本图选定的一个功能类别；多标签应在另一个明确的注释轨道或成员关系图展示，不能重复坐标行充当多个基因。

`contig_lengths.tsv` 必须列 `contig_id length`。quant 与 samples 同上。quant 的所有 ID 必须在坐标目录/代表映射中，其他 contig 的行会忽略并计数；不要传入无匹配目录的完整定量文件而期望静默丢弃。箭头图不推断 operon、共同转录、基因作用方向或真实功能互作。

### 代表基因数量与多成员位置

本 DBDPE 项目现有 TPM 是代表基因目录的量，并有 representative↔member 和 member↔sample/contig 关系。**不能把代表 TPM 原样复制到多个 contig 成员，再称为位点丰度或跨位点相加。**

若只需展示某 contig 上成员基因所属家族的数量轮廓，使用 `--quantity-scope family_profile`，在 coordinates 增加 `representative_gene_id`，quant 中 `gene_id` 则使用这些代表 ID。脚本明确以代表 ID 映射，图标题写明 **Representative-family profiles; NOT locus-specific abundance**，并声明重复家族不能跨位点求和；`plotted_quantities.tsv` 同时保存 locus 的 `gene_id` 与来源 `quantity_gene_id`。这是家族轮廓的定位参照，不是多位点分配算法。只有已获批准、实际完成且有证据的定位特异定量，才能使用 `locus`。

### 导出与验收

输出 `contig_functions.svg/.pdf/.png`、`plotted_genes.tsv`、`plotted_quantities.tsv`、`feature_colors.tsv`、`R_sessionInfo.txt`、`file_manifest.tsv` 和 `run_manifest.txt`。base R 自带 MD5，清单明确算法；不是 SHA-256，也不哈希自身/末尾运行说明。严格 provenance 场景可在外层统一补 SHA-256。

热图仅展示 `log10(value+1)`，没有行 z-score、聚类或统计推断。灰色 NA 与标字 0 分开；颜色刻度显示变换后的值。最多 80 基因、40 样本、18 功能颜色，超过限制应设计显式窗口/分页或更粗且有来源的功能层级，而非压缩到无法辨认。超过 50 显示列的 gene ID 以图中索引和明确的完整 TSV 提示展示，完整 ID 不截断地保留在 `plotted_genes.tsv`；超过 28 显示列的功能 ID 使用 F 编号，并在 `feature_colors.tsv` 保留对应完整 ID。样本 ID 超过 24 显示列或 contig ID 超过 80 显示列会拒绝，需建立明确短标签映射后重绘，禁止静默截断。这里没有 coverage bedGraph/bigWig 轨道、GC 滑窗、跨 contig links 或 WGCNA 网络；这些应按对应 atlas/分析设计实现，不能从本示例声称已具备运行认证。

生成后打开真实图像，检查方向、重叠泳道、坐标边界、全样本标签、零/NA、颜色刻度和来源身份。`visual_qa_status=unreviewed` 直到实际检查；测试退出 0 不等于图像验收，合成图始终标 SYNTHETIC。

## 合成验证

```bash
python3 scripts/test_functional_tools.py --out NEW_TEST_DIRECTORY \
  --rscript /absolute/path/to/Rscript
```

测试覆盖重复基因×样本拒绝、负值/无穷值/陌生 ID 拒绝、零和缺失、全样本保留、未注释完整分母、重复 KO→module 路径去重、两种分配政策、坐标错误拒绝，以及 locus/family_profile 两种 R 图像导出。合成验证不检查真实注释/比对是否正确，也不证明生产性能、统计有效性或模块完整性。
