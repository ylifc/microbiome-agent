# Figure contract and commands

Use an existing interpreter with `Bio`, `matplotlib` and `PIL`; do not install packages in a scientific production run. In the present workspace `/home/ylifc/miniforge3/bin/python3.13` has these modules. The script uses only these and the standard library.

## Inputs

Newick: exactly one tree, unique non-whitespace genome IDs, finite nonnegative branch lengths. Preserve source root as a drawing origin, not an inferred ancestor. Optional internal labels must match the explicitly declared `SH-aLRT/UFBoot`, `SH-aLRT`, or `UFBoot` order, all finite 0–100. sCF labels are rejected; do not relabel sCF as bootstrap.

For a separately audited sCF table, inspect the denominator `sN`: when `sN=0`, show **no information / NA**, even if the native file contains a placeholder `sCF=0`. Only `sN>0` with `sCF=0` is an observed zero site-concordance fraction; it is still not bootstrap support. Preserve raw native values, the information flag, original ML support and canonical split mapping separately. Missing carried ML labels must not be fabricated from sCF.

TSV: required headers `genome_id`, `sample_id`, `group`, `phylum`, `species`. All tree IDs must appear exactly once and no extra rows are allowed. `sample_id` is required; group/phylum/species may be blank and are displayed as Unknown. Optional columns: `completeness` and `contamination` (0–100), `msa_aa_fraction` (0–1), `identical_msa_group` (a provenance-backed annotation, not inferred by the renderer). Optional `identical_msa_count` and semicolon-separated `identical_msa_members` must be supplied together with the group when either has a value. Count must be a positive integer matching unique exact member IDs; each row must include itself, all members must occur in the figure metadata, and every row in the group must make the same declaration. Known singletons are never marked unresolved; only declared multi-member groups are labeled unresolved, with their member count. A group without count/members is labeled size unknown and does not establish duplicate sequences. The renderer never compares MSA sequences. Separate known multi-member, singleton and unknown-size group counts are recorded in the manifest, and all original metadata strings remain unchanged in the index. Missing qualities stay missing, distinct from zero. Long text is wrapped in detail pages and preserved verbatim in the index. A sample cannot silently map to multiple groups.

Source manifest JSON requires `dataset_kind` (`synthetic` or `biological`), `description`, `support_order`, `source_scientific_status` (`synthetic_fixture`, `unverified`, or `validated`) and `inputs` with exact tree/metadata file SHA256 strings. A biological manifest also needs `source_evidence` entries `{path,sha256}` pointing to real existing source evidence. This records provenance; it does not independently certify the evidence's scientific conclusion.

```sh
python visualize_microbiome.py manifest --tree tree.nwk --metadata genomes.tsv \
  --out sources.json --dataset-kind synthetic --description 'Synthetic renderer QA only' \
  --support-order SH-aLRT/UFBoot --source-scientific-status synthetic_fixture
python visualize_microbiome.py render --tree tree.nwk --metadata genomes.tsv \
  --source-manifest sources.json --out-dir figures --title 'Synthetic stress fixture' \
  --support-order SH-aLRT/UFBoot --rows-per-page 32
```

For biological manifest creation, `--source-evidence path` can be repeated; it records full hashes. Do not use `synthetic_fixture` for biological data or `validated` for unaudited source data. `render` verifies the hashes and source type consistency before creating output. Existing nonempty output directories are rejected. Rendering failure may leave partial files but never a PASSED/validated manifest; use a fresh directory for retry.

## Outputs and scale

`overview.svg/pdf/png` is a fixed-size tree with group/sample/phylum strips. It intentionally omits leaf text and node support text at overview scale; every branch and every leaf remain present. `details.pdf` and `pages/page_*.svg/png` provide full labels and all supplied support values. `genome_index.tsv` joins every original metadata column to its page and row. `branch_support.tsv` retains raw supports and exact descendant identities, including missing labels. `quality_counts.svg/pdf/png`, `legend.svg/pdf/png`, and `index.html` complete the bundle.

Quality scatter only includes genomes with both quality values; counts include all supplied genomes. Group counts are not numbers of independent animals/cages and must not be interpreted as treatment effects. The default C/L/M/H colors are fixed; other groups/sample/phylum palettes are deterministic. Categories, missing-data counts, identical-group declarations and page count are recorded in `render_manifest.json`.

All render output starts at `status: preview`. Check `qa_required_images` in the manifest; open those exact files and record observations in a JSON file:

```json
{
  "verdict": "pass",
  "render_manifest_sha256": "actual SHA256 of preview render_manifest.json",
  "inspected_images": ["overview.png", "legend.png", "quality_counts.png", "pages/page_001.png"],
  "checks": {"labels_readable": true, "support_mapping_clear": true, "no_clipping": true, "colors_consistent": true, "identity_coverage": true},
  "limitations": ["Overview omits text by design; read detail pages for exact support."],
  "reviewer": "actual reviewer identity"
}
```

The example image list is incomplete for multipage figures: include every required image from the actual manifest, including middle/last/densest pages. `accept-qa --out-dir figures --review-file visual_review.json` verifies source/output hashes, reviewer declaration and required-image coverage, then writes a separate `visual_validation.json` with `status: validated` and `scope: visualization_only`. It never rewrites the preview manifest or marks a scientific pipeline passed. A declaration is not machine proof of eyesight; only write it after actually inspecting the files.
