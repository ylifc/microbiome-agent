#!/usr/bin/env Rscript
# Dependency-light coordinate arrows and exact gene-profile heatmap. No inference.
args <- commandArgs(trailingOnly=TRUE)
if (length(args) == 1 && args[1] == "--help") {
  cat("Rscript plot_contig_functions.R --genes genes.tsv --contigs contigs.tsv --quant gene_quant.tsv --samples samples.tsv --contig ID --unit DNA_TPM --quantity-scope locus --dataset-kind synthetic --source-evidence provenance.json --source-note NOTE --out NEW_DIRECTORY\n")
  quit(status=0)
}
if (length(args) %% 2 != 0) stop("Arguments must be --key value pairs")
opts <- list()
for (i in seq(1, length(args), by=2)) {
  if (!startsWith(args[i], "--") || args[i] %in% names(opts)) stop("Invalid or duplicate option")
  opts[[args[i]]] <- args[i+1]
}
required <- c("genes", "contigs", "quant", "samples", "contig", "unit", "quantity-scope", "dataset-kind", "source-evidence", "source-note", "out")
if (length(setdiff(paste0("--", required), names(opts)))) stop("Missing option; see --help")
if (length(setdiff(names(opts), paste0("--", required)))) stop("Unknown option")
opt <- function(key) opts[[paste0("--", key)]]
if (!opt("unit") %in% c("DNA_TPM", "RNA_TPM", "read_count", "estimated_count", "coverage")) stop("Explicit supported unit required")
if (!opt("quantity-scope") %in% c("locus", "family_profile")) stop("quantity-scope is locus or family_profile")
if (!opt("dataset-kind") %in% c("real", "synthetic")) stop("dataset-kind is real or synthetic")
if (!file.exists(opt("source-evidence"))) stop("Missing provenance evidence")
out <- opt("out")
if (dir.exists(out) && length(list.files(out, all.files=TRUE, no..=TRUE))) stop("Output directory must be new/empty")
read_tab <- function(path, columns) {
  x <- read.delim(path, sep="\t", header=TRUE, quote="", comment.char="", check.names=FALSE, colClasses="character", na.strings=NULL, fill=FALSE)
  if (anyDuplicated(names(x)) || !all(columns %in% names(x))) stop(paste("Invalid schema:", path))
  for (col in setdiff(columns, "value")) if (any(is.na(x[[col]]) | x[[col]] == "" | trimws(x[[col]]) != x[[col]])) stop(paste("Missing/padded ID:", col))
  x
}
all_genes <- read_tab(opt("genes"), c("gene_id", "contig_id", "start", "end", "strand", "feature_id"))
contigs <- read_tab(opt("contigs"), c("contig_id", "length"))
samples <- read_tab(opt("samples"), "sample_id")
quant <- read_tab(opt("quant"), c("gene_id", "sample_id", "value"))
if (anyDuplicated(all_genes$gene_id) || anyDuplicated(contigs$contig_id) || anyDuplicated(samples$sample_id)) stop("Duplicate gene/contig/sample identity")
if (!nrow(samples) || nrow(samples) > 40) stop("Require 1-40 samples per panel")
if (any(nchar(samples$sample_id, type="width") > 24)) stop("Sample labels exceed 24 display columns; provide an explicitly mapped short sample ID manifest")
if (nchar(opt("contig"), type="width") > 80) stop("Contig title exceeds 80 display columns; use a documented short contig alias")
if (anyDuplicated(quant[c("gene_id", "sample_id")])) stop("Duplicate gene/sample quantity")
if (any(!quant$sample_id %in% samples$sample_id)) stop("Quantity sample missing from sample manifest")
if (opt("quantity-scope") == "family_profile") {
  if (!"representative_gene_id" %in% names(all_genes) || any(is.na(all_genes$representative_gene_id) | all_genes$representative_gene_id == "")) stop("family_profile requires representative_gene_id provenance per displayed locus")
  known_quant_ids <- unique(all_genes$representative_gene_id)
} else known_quant_ids <- all_genes$gene_id
unknown_genes <- setdiff(quant$gene_id, known_quant_ids)
if (length(unknown_genes)) stop("Quantity gene absent from supplied coordinate catalog/representative mapping")
to_num <- function(x) suppressWarnings(as.numeric(x))
contigs$length <- to_num(contigs$length)
all_genes$start <- to_num(all_genes$start); all_genes$end <- to_num(all_genes$end)
if (any(!is.finite(contigs$length) | contigs$length < 1 | contigs$length != floor(contigs$length))) stop("Invalid contig length")
if (any(!all_genes$contig_id %in% contigs$contig_id)) stop("Gene contig absent from length manifest")
lens <- contigs$length[match(all_genes$contig_id, contigs$contig_id)]
if (any(!is.finite(all_genes$start) | !is.finite(all_genes$end) | all_genes$start < 1 | all_genes$end < all_genes$start | all_genes$end > lens | all_genes$start != floor(all_genes$start) | all_genes$end != floor(all_genes$end))) stop("Coordinates must be 1-based inclusive within contig")
if (any(!all_genes$strand %in% c("+", "-", "."))) stop("strand must be +, -, or .")
qmissing <- quant$value %in% c("", "NA")
quant$value <- to_num(quant$value)
if (any(!qmissing & (!is.finite(quant$value) | quant$value < 0))) stop("Quantities must be finite and nonnegative; only blank/NA is missing")
quant$value[qmissing] <- NA_real_
if (opt("unit") == "read_count" && any(quant$value != floor(quant$value), na.rm=TRUE)) stop("read_count requires integers")
genes <- all_genes[all_genes$contig_id == opt("contig"), , drop=FALSE]
genes <- genes[order(genes$start, genes$end, genes$gene_id), , drop=FALSE]
if (!nrow(genes) || nrow(genes) > 80) stop("Require 1-80 genes per contig panel; explicitly select a coordinate window upstream for larger contigs")
length_bp <- contigs$length[match(opt("contig"), contigs$contig_id)]
cats <- sort(unique(genes$feature_id))
if (length(cats) > 18) stop("More than 18 colors: supply an explicitly documented coarser functional category panel")
cols <- setNames(hcl.colors(max(3, length(cats)), "Dark 3")[seq_along(cats)], cats)
cols[names(cols) %in% c("Unannotated", "__UNANNOTATED__", "NA")] <- "grey65"
mat <- matrix(NA_real_, nrow=nrow(genes), ncol=nrow(samples), dimnames=list(genes$gene_id, samples$sample_id))
quantity_ids <- if (opt("quantity-scope") == "locus") genes$gene_id else genes$representative_gene_id
for (j in seq_len(nrow(quant))) {
  gi <- which(quantity_ids == quant$gene_id[j])
  if (length(gi)) mat[gi, match(quant$sample_id[j], samples$sample_id)] <- quant$value[j]
}
trans <- log10(mat + 1)
vmax <- if (all(is.na(trans))) 1 else max(trans, na.rm=TRUE)
if (!is.finite(vmax) || vmax == 0) vmax <- 1
pal <- hcl.colors(100, "YlOrRd", rev=TRUE)
# Non-overlapping coordinate lanes; labels are gene indexes to retain readable identity.
lane_ends <- numeric(); lanes <- integer(nrow(genes))
for (i in seq_len(nrow(genes))) {
  candidate <- which(lane_ends < genes$start[i])
  lane <- if (length(candidate)) candidate[1] else length(lane_ends)+1L
  lanes[i] <- lane; lane_ends[lane] <- genes$end[i]
}
nlanes <- max(lanes)
genes$plot_index <- seq_len(nrow(genes)); genes$lane <- lanes; genes$color <- unname(cols[genes$feature_id])
genes$display_label <- ifelse(nchar(genes$gene_id,type="width") <= 50, paste0(genes$plot_index, ": ", genes$gene_id), paste0(genes$plot_index, ": [full ID in plotted_genes.tsv]"))
feature_keys <- paste0("F",seq_along(cats))
feature_labels <- ifelse(nchar(cats,type="width")<=28,cats,paste0(feature_keys," [full ID in color table]"))
scope_label <- if (opt("quantity-scope") == "locus") "Locus-specific supplied quantities" else "Representative-family profiles; NOT locus-specific abundance"
draw <- function() {
  layout(matrix(c(1,2,3), ncol=1), heights=c(max(2, nlanes*.6), max(4, nrow(genes)*.19), 1.6))
  par(mar=c(3.2, 4, 3.5, 1))
  plot(NA, xlim=c(0, length_bp), ylim=c(.3, nlanes+.9), xlab="Contig coordinate (bp; 1-based inclusive)", ylab="Lane", yaxt="n", bty="n", main=paste(if (opt("dataset-kind") == "synthetic") "SYNTHETIC |" else "", opt("contig"), "gene positions"))
  axis(2, at=seq_len(nlanes), labels=seq_len(nlanes), las=1)
  for (i in seq_len(nrow(genes))) {
    x1 <- genes$start[i]; x2 <- genes$end[i]; y <- lanes[i]; h <- .23
    tip <- min(max(1, length_bp*.006), (x2-x1+1)/3)
    if (genes$strand[i] == "+") polygon(c(x1, x2-tip, x2, x2-tip, x1), c(y-h,y-h,y,y+h,y+h), col=genes$color[i], border="grey35")
    else if (genes$strand[i] == "-") polygon(c(x2, x1+tip, x1, x1+tip, x2), c(y-h,y-h,y,y+h,y+h), col=genes$color[i], border="grey35")
    else rect(x1,y-h,x2,y+h,col=genes$color[i],border="grey35")
    text((x1+x2)/2,y+.4,labels=i,cex=.65)
  }
  par(mar=c(4.8, 14, 3.5, 1))
  plot(NA, xlim=c(.5,nrow(samples)+.5), ylim=c(.5,nrow(genes)+.5), xaxs="i", yaxs="i", xaxt="n", yaxt="n", xlab="", ylab="", bty="n", main=paste(scope_label, " | log10(", opt("unit"), " + 1)", sep=""))
  for (i in seq_len(nrow(genes))) for (j in seq_len(nrow(samples))) {
    y <- nrow(genes)+1-i
    color <- if (is.na(trans[i,j])) "grey75" else pal[1+floor(99*trans[i,j]/vmax)]
    rect(j-.48,y-.48,j+.48,y+.48,col=color,border=NA)
    cex_cell <- if (nrow(genes)<=20 && nrow(samples)<=15) .9 else .55
    if (is.na(trans[i,j])) text(j,y,"NA",cex=cex_cell)
    else if (mat[i,j] == 0) text(j,y,"0",cex=cex_cell)
  }
  axis(1,at=seq_len(nrow(samples)),labels=samples$sample_id,las=2,cex.axis=.75)
  axis(2,at=rev(seq_len(nrow(genes))),labels=genes$display_label,las=2,tick=FALSE,cex.axis=if(nrow(genes)<=20) .85 else .65)
  par(mar=c(0,1,1,1)); plot.new()
  legend("topleft",legend=feature_labels,fill=cols,ncol=min(4,length(cats)),bty="n",cex=.72)
  ticks <- seq(0,vmax,length.out=5)
  legend(x=0,y=.52,legend=paste0(format(ticks,digits=3)," log10"),fill=pal[1+floor(99*ticks/vmax)],ncol=5,bty="n",cex=.8)
  text(0,.18,"Grey/NA = missing; printed 0 = measured zero. Gene order is genomic; physical spacing only in upper panel.",adj=0,cex=.75)
  if (opt("quantity-scope") == "family_profile") text(0,.02,"Repeated family profiles must not be summed across member loci.",adj=0,cex=.75)
}
dir.create(out, recursive=TRUE, showWarnings=FALSE)
height <- min(30, max(9, 5 + nrow(genes)*.19 + nlanes*.45))
pdf(file.path(out,"contig_functions.pdf"),width=13,height=height,onefile=TRUE); draw(); dev.off()
svg(file.path(out,"contig_functions.svg"),width=13,height=height); draw(); dev.off()
png(file.path(out,"contig_functions.png"),width=13,height=height,units="in",res=160,type="cairo"); draw(); dev.off()
write.table(genes,file.path(out,"plotted_genes.tsv"),sep="\t",quote=FALSE,row.names=FALSE,na="NA")
detail <- expand.grid(gene_id=genes$gene_id,sample_id=samples$sample_id,stringsAsFactors=FALSE)
detail$value <- as.vector(mat); detail$log10_plus_one <- as.vector(trans); detail$unit <- opt("unit"); detail$quantity_scope <- opt("quantity-scope")
detail$quantity_gene_id <- quantity_ids[match(detail$gene_id,genes$gene_id)]
write.table(detail,file.path(out,"plotted_quantities.tsv"),sep="\t",quote=FALSE,row.names=FALSE,na="NA")
write.table(data.frame(feature_key=feature_keys,feature_id=cats,display_label=feature_labels,color=unname(cols)),file.path(out,"feature_colors.tsv"),sep="\t",quote=FALSE,row.names=FALSE)
capture.output(sessionInfo(),file=file.path(out,"R_sessionInfo.txt"))
source_paths <- normalizePath(c(opt("genes"),opt("contigs"),opt("quant"),opt("samples"),opt("source-evidence")),mustWork=TRUE)
source_hashes <- data.frame(kind="source",path=source_paths,md5=unname(tools::md5sum(source_paths)))
outputs <- list.files(out, full.names=TRUE)
output_hashes <- data.frame(kind="output",path=normalizePath(outputs),md5=unname(tools::md5sum(outputs)))
script_arg <- grep("^--file=",commandArgs(),value=TRUE)
if (length(script_arg)) {
  script_path <- normalizePath(sub("^--file=","",script_arg[1]))
  source_hashes <- rbind(source_hashes,data.frame(kind="script",path=script_path,md5=unname(tools::md5sum(script_path))))
}
write.table(rbind(source_hashes,output_hashes),file.path(out,"file_manifest.tsv"),sep="\t",quote=FALSE,row.names=FALSE)
writeLines(c("tool=plot_contig_functions.R", "version=1.0.0", paste0("created_utc=",format(Sys.time(),tz="UTC",usetz=TRUE)), paste0("dataset_kind=",opt("dataset-kind")),paste0("unit=",opt("unit")),paste0("quantity_scope=",opt("quantity-scope")),paste0("source_note=",opt("source-note")),paste0("contig=",opt("contig")),paste0("n_genes=",nrow(genes)),paste0("n_samples=",nrow(samples)),paste0("n_missing_cells=",sum(is.na(mat))),paste0("n_zero_cells=",sum(mat==0,na.rm=TRUE)),paste0("other_contig_quantity_rows_ignored=",sum(!quant$gene_id %in% quantity_ids)),"coordinate_convention=1-based-inclusive", "analysis=none; no normalization, statistical tests, assignment, or network inference", "visual_qa_status=unreviewed; inspect actual output", "hash_algorithm=MD5 (base R); file_manifest does not hash itself or run_manifest"),file.path(out,"run_manifest.txt"))
cat(normalizePath(out),"\n")
