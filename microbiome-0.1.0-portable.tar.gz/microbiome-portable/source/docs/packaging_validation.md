# 发行包工程验收记录

日期：2026-09-29。当前交付目标为 Linux x86_64 / Python 3.13 离线安装包。
完整交付位置为项目的 `packaged/`；当前版本由该目录的 `CURRENT` 文件标识。
每份发行目录中的 `validation/REPORT.md`、JSON、JUnit 和日志记录最终压缩包验收结果。

## 已完成的检查

- 包含 22 份流程参考、107 个软件 Skill、33 个数据库 Skill、1 个宿主 Skill，共 141 个项目 Skill。
- wheel 中的 561 个应用代码及资源文件与本次源码快照逐文件 SHA256 一致。
- 用离线 wheelhouse 在全新受管目录创建 venv；`include-system-site-packages = false`，未继承现有第三方包。
- 在源码目录之外使用安装后的 Python，清空 `PYTHONPATH`，以 `-I` 检查导入位置与运行行为。
- 16 项安装自检通过：环境身份、五个公开启动入口、已安装文件、依赖、doctor、目录、三个宿主导出、项目初始化/读取、简单任务演示。
- 小任务演示含 5 个情形：FASTA 统计、含 gzip 的双端 FASTQ、坏 FASTQ、缺失本地输入、拒绝覆盖已有结果。输入 SHA256 保持不变。
- 32 个测试文件共 424 个不同用例完成安装后验证。首轮 417 passed、7 failed；七个失败均为测试对源码目录的路径假设。修正测试以读取实际安装资源后，七个失败全部通过复测，运行时代码未因这些失败变更。
- 构建器、公开入口验证器、Skill 绑定与安装/导出兼容测试另有 76 passed。不同验证批次不累加为新的测试总数。
- 19 页中文 Word 手册已逐页渲染检查，并验证手册、流程目录及 141 项 Skill 索引链接。

## 此轮改进

新增无需模型或科研项目的 `microbiome stats`、`sequence.stats` 与 MCP `microbiome_sequence_stats`。
此入口只用 Python 标准库处理有界本地核酸 FASTA/FASTQ，检查格式、记录数、长度、GC、质量字符与配对；保存结果、日志、输入和实现指纹。

全部 21 份科学参考均复核，14 份修订了 RNA 跨样本统计、共同参考、contig-only 输入、条件软件依赖及模型/mapper 资源合同。第 22 份参考对应可直接执行的基础统计。

发行构建器核对源码、wheel、Skill/流程镜像和依赖，生成机器可读清单、归档及 SHA256。
验证器除检查 Python 导入，还检查公开启动器的符号链接和实际执行。
统计演示使用显式失败检查，在 Python 优化模式下仍核对数值与输入不变性。

## 真实执行与模拟的边界

实际执行的内容包括离线安装、FASTA/FASTQ 解析、MCP stdio/HTTP 协议、localhost 模型端口服务、合成数据的预检/冻结/生产重放和错误处理。
模型端口测试使用本机测试服务，不代表调用了外部商业模型。科学生命周期使用合成文件与确定性计算适配器；资源安装测试使用受控 fixture。

没有把 21 条科学路线全部运行真实测序数据，也没有预装全部科学工具或数据库。
Codex/VS Code 配置和 WorkBuddy Skill 导出已验证；不同版本宿主 UI 的实际导入尚未逐一验收。
其他 Python 次版本、操作系统、CPU 架构及远程调度需要各自验证；本包提供完整源码用于重新构建。

## 复现

安装、目录结构和自检命令见[发行包安装与自检](packaging.md)。完整测试命令、原始失败与复测证据保存在交付版本的 `validation/`，不写入不可变的 `bundle/`。
最终压缩包另解压到新目录重新安装；结果以 `validation/final-runtime/verification.json` 和 `validation/REPORT.md` 为准。
冻结核心的独立复验命令仍是 `pytest -q tests/test_frozen_pipeline.py`。
