"""Role-aware path validation and input-tree traversal.

``RAW_DATA_PATH`` is an input namespace, not an ownership boundary.  A user may
therefore keep ``OUTPUT_PATH`` (and, less commonly, the database root) below it
as long as every raw-data scanner prunes those configured infrastructure
roots.  This module is the single implementation of that contract.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections import abc


class PathRelationship(StrEnum):
    SEPARATE = "SEPARATE"
    OUTPUT_WITHIN_RAW = "OUTPUT_WITHIN_RAW"
    DATABASE_WITHIN_RAW = "DATABASE_WITHIN_RAW"
    RAW_WITHIN_OUTPUT = "RAW_WITHIN_OUTPUT"
    RAW_WITHIN_DATABASE = "RAW_WITHIN_DATABASE"
    DATABASE_WITHIN_OUTPUT = "DATABASE_WITHIN_OUTPUT"
    OUTPUT_WITHIN_DATABASE = "OUTPUT_WITHIN_DATABASE"


def canonical(value: str | os.PathLike[str]) -> Path:
    """Resolve a configured path without requiring it to exist."""
    return Path(value).expanduser().resolve()


def is_same_or_within(path: str | os.PathLike[str], root: str | os.PathLike[str]) -> bool:
    """Return whether *path* is *root* or a descendant, using path semantics."""
    resolved_path = canonical(path)
    resolved_root = canonical(root)
    return resolved_path == resolved_root or resolved_root in resolved_path.parents


def is_strictly_within(path: str | os.PathLike[str], root: str | os.PathLike[str]) -> bool:
    resolved_path = canonical(path)
    resolved_root = canonical(root)
    return resolved_path != resolved_root and resolved_root in resolved_path.parents


@dataclass(frozen=True)
class PathPolicyReport:
    raw_data: Path
    database: Path
    output: Path
    relationships: tuple[PathRelationship, ...]
    input_exclusion_roots: tuple[Path, ...]
    errors: tuple[str, ...]
    warnings: tuple[str, ...]

    @property
    def valid(self) -> bool:
        return not self.errors

    def as_dict(self) -> dict[str, object]:
        return {
            "policy_version": 1,
            "valid": self.valid,
            "relationships": [item.value for item in self.relationships],
            "input_exclusion_roots": [str(item) for item in self.input_exclusion_roots],
            "errors": list(self.errors),
            "warnings": list(self.warnings),
        }


class PathPolicy:
    """Validate paths according to their roles, not blanket non-nesting."""

    @classmethod
    def evaluate(
        cls,
        raw_data: str | os.PathLike[str],
        database: str | os.PathLike[str],
        output: str | os.PathLike[str],
    ) -> PathPolicyReport:
        raw = canonical(raw_data)
        db = canonical(database)
        out = canonical(output)
        errors: list[str] = []
        warnings: list[str] = []
        relationships: list[PathRelationship] = []
        exclusions: list[Path] = []

        equal_roles = []
        if raw == out:
            equal_roles.append("RAW_DATA_PATH and OUTPUT_PATH")
        if raw == db:
            equal_roles.append("RAW_DATA_PATH and DATABASE_PATH")
        if out == db:
            equal_roles.append("OUTPUT_PATH and DATABASE_PATH")
        for roles in equal_roles:
            errors.append(f"{roles} must not resolve to the same directory")

        if is_strictly_within(out, raw):
            relationships.append(PathRelationship.OUTPUT_WITHIN_RAW)
            exclusions.append(out)
            warnings.append(
                "OUTPUT_PATH is inside RAW_DATA_PATH; it is allowed and will be pruned from every input scan"
            )
        elif is_strictly_within(raw, out):
            relationships.append(PathRelationship.RAW_WITHIN_OUTPUT)
            errors.append("RAW_DATA_PATH must not be inside OUTPUT_PATH")

        if is_strictly_within(db, raw):
            relationships.append(PathRelationship.DATABASE_WITHIN_RAW)
            exclusions.append(db)
            warnings.append(
                "DATABASE_PATH is inside RAW_DATA_PATH; it is allowed and will be pruned from every input scan"
            )
        elif is_strictly_within(raw, db):
            relationships.append(PathRelationship.RAW_WITHIN_DATABASE)
            errors.append("RAW_DATA_PATH must not be inside DATABASE_PATH")

        if is_strictly_within(db, out):
            relationships.append(PathRelationship.DATABASE_WITHIN_OUTPUT)
            errors.append("DATABASE_PATH must not be inside OUTPUT_PATH")
        elif is_strictly_within(out, db):
            relationships.append(PathRelationship.OUTPUT_WITHIN_DATABASE)
            errors.append("OUTPUT_PATH must not be inside DATABASE_PATH")

        if not relationships and not equal_roles:
            relationships.append(PathRelationship.SEPARATE)

        unique_exclusions = tuple(sorted(set(exclusions), key=str))
        return PathPolicyReport(
            raw_data=raw,
            database=db,
            output=out,
            relationships=tuple(relationships),
            input_exclusion_roots=unique_exclusions,
            errors=tuple(errors),
            warnings=tuple(warnings),
        )


def iter_files_pruned(
    root: str | os.PathLike[str],
    *,
    excluded_roots: tuple[Path, ...] | list[Path] = (),
) -> abc.Iterator[Path]:
    """Yield files below *root* deterministically, pruning exclusions early.

    Directory pruning happens before descent.  Resolved path comparison handles
    symlinks and avoids string-prefix errors such as ``run1`` versus ``run10``.
    """
    resolved_root = canonical(root)
    excluded = tuple(canonical(item) for item in excluded_roots)
    if any(is_same_or_within(resolved_root, item) for item in excluded):
        return
    for current, dirnames, filenames in os.walk(resolved_root, topdown=True, followlinks=False):
        current_path = Path(current)
        dirnames[:] = sorted(
            name
            for name in dirnames
            if not any(is_same_or_within(current_path / name, item) for item in excluded)
        )
        for name in sorted(filenames):
            candidate = current_path / name
            if not any(is_same_or_within(candidate, item) for item in excluded):
                yield candidate
