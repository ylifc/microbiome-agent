"""Host-owned Microbiome entrypoint; ordinary startup never constructs a model."""
from __future__ import annotations

import argparse
import json
import sys


def inspect_installation():
    """Validate packaged interfaces without connecting to a model or scientific tool."""
    from microbiome.assets import asset_path
    from microbiome.resource_skills.audit import audit_catalog
    from microbiome.version import __version__
    from microbiome.workflows import WorkflowCatalog

    audit = audit_catalog()
    errors = list(audit["errors"])
    assets = {}
    for name in ("cohort_tables.py", "run_dada2.R", "run_ancombc2.R"):
        try:
            assets[name] = str(asset_path(name))
        except (OSError, ValueError) as error:
            errors.append(str(error))
    try:
        references = len(WorkflowCatalog().list())
    except (OSError, ValueError) as error:
        errors.append(str(error))
        references = 0
    return {"ok": not errors, "version": __version__, "python": sys.version.split()[0],
            "model_owner": "host", "model_connection": "NOT_REQUESTED",
            "scientific_runtime": "NOT_PROBED", "workflow_references": references,
            "software_skills": audit["software_count"], "database_skills": audit["database_count"],
            "assets": assets, "errors": errors, "warnings": audit["warnings"]}


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    parser = argparse.ArgumentParser(
        prog="microbiome",
        description="Microbiome workflow tools for your existing Codex, WorkBuddy, VS Code or other host.",
        epilog="The host supplies its model. Export the skill/MCP settings or use an explicitly selected endpoint; "
               "ordinary startup does not request a model or credentials.",
    )
    parser.add_argument("--version", action="store_true", help="Print the installed engine version")
    commands = parser.add_subparsers(dest="command")
    help_text = {
        "init": "Initialize explicit project/data/database/output paths",
        "call": "Call a versioned workflow operation with JSON arguments",
        "decide": "Review and record an operator decision",
        "export": "Export a host skill and connection settings",
        "mcp": "Serve workflow tools over MCP",
        "endpoint": "Use an explicitly supplied local model endpoint",
        "stats": "Inspect local FASTA/FASTQ counts, lengths, GC and optional pairing",
        "doctor": "Check installation without model or scientific resource calls",
    }
    for name, description in help_text.items():
        commands.add_parser(name, help=description, add_help=name == "doctor")
    args, forwarded = parser.parse_known_args(argv)
    if args.version:
        from microbiome.version import __version__
        print(__version__)
        return 0
    if args.command is None:
        if forwarded:
            parser.error("unrecognized arguments: " + " ".join(forwarded))
        parser.print_help()
        return 0
    if args.command == "doctor":
        if forwarded:
            parser.error("unrecognized doctor arguments: " + " ".join(forwarded))
        report = inspect_installation()
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0 if report["ok"] else 1
    if args.command == "mcp":
        from microbiome.integrations.mcp_server import main as serve
        return serve(forwarded)
    if args.command == "endpoint":
        from microbiome.integrations.endpoint_cli import main as connect
        return connect(forwarded)
    if args.command == "stats":
        from microbiome.integrations.sequence_stats import main as statistics
        return statistics(forwarded)
    from microbiome.integrations.cli import main as service
    return service([args.command, *forwarded])


if __name__ == "__main__":
    raise SystemExit(main())
