"""Project layout and read-only input/resource discovery."""

from __future__ import annotations

import gzip
import json
import os
import re
import shutil
import subprocess
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from microbiome.path_policy import PathPolicy, PathPolicyReport, iter_files_pruned
from microbiome.pipeline.errors import ConfigurationError
from microbiome.pipeline.io import (
    canonical_path,
    fast_file_fingerprint,
    object_fingerprint,
    read_yaml,
    write_json,
    write_yaml,
)
from microbiome.pipeline.models import SCHEMA_VERSION, PipelinePhase

if TYPE_CHECKING:
    from pathlib import Path

FASTQ_SUFFIXES = (".fastq", ".fq", ".fastq.gz", ".fq.gz")
FASTA_SUFFIXES = (".fasta", ".fa", ".fna", ".faa", ".ffn", ".fsa")
COMMON_BIOINFORMATICS_EXECUTABLES = (
    "fastp",
    "seqkit",
    "megahit",
    "spades.py",
    "prodigal",
    "bwa",
    "bowtie2",
    "samtools",
    "bcftools",
    "diamond",
    "blastn",
    "kraken2",
    "genomad",
    "checkv",
    "checkm2",
    "bakta",
)
PAIR_RE = re.compile(
    r"^(?P<sample>.+?)(?:[._-](?:R|READ)?(?P<mate>[12]))(?:[._-]?\d+)?(?P<suffix>\.f(?:ast)?q(?:\.gz)?)$",
    re.IGNORECASE,
)


def _utcnow() -> str:
    return datetime.now(UTC).isoformat()


class PipelineProject:
    """Access the persistent artifact layout required by the engineering rules."""

    def __init__(self, root: str | Path):
        self.root = canonical_path(root)
        self.config_dir = self.root / "config"
        self.docs_dir = self.root / "docs"
        self.config_path = self.root / "project_config.yaml"
        self.plan_path = self.root / "experiment_plan.yaml"
        self.state_dir = self.root / "state"

    @property
    def output_root(self) -> Path:
        if self.config_path.is_file():
            return canonical_path(self.load_config()["paths"]["output"])
        return self.root

    @property
    def requirements_dir(self) -> Path:
        return self.output_root / "requirements"

    @property
    def requirements_path(self) -> Path:
        return self.requirements_dir / "requirements.yaml"

    @property
    def decision_log_path(self) -> Path:
        return self.requirements_dir / "decision_log.jsonl"

    @property
    def conversation_summary_path(self) -> Path:
        return self.requirements_dir / "conversation_summary.md"

    @property
    def lifecycle_state_path(self) -> Path:
        return self.output_root / "project_state.yaml"

    @property
    def plans_dir(self) -> Path:
        return self.output_root / "plans"

    @property
    def pretest_dir(self) -> Path:
        return self.output_root / "pre_test_run"

    @property
    def pipeline_dir(self) -> Path:
        return self.output_root / "pipeline"

    @property
    def knowledge_dir(self) -> Path:
        if self.config_path.is_file():
            configured = self.load_config()["paths"].get("knowledge")
            if configured:
                return canonical_path(configured)
        return self.output_root / "knowledge"

    @property
    def resource_skills_dir(self) -> Path:
        """Project-learned Skills; packaged Skills remain read-only templates."""
        return self.output_root / "resource_skills"

    @property
    def reports_dir(self) -> Path:
        return self.output_root / "reports"

    @property
    def runs_dir(self) -> Path:
        return self.output_root / "runs"

    @property
    def database_registry_path(self) -> Path:
        return self.config_dir / "database_registry.yaml"

    @property
    def tool_registry_path(self) -> Path:
        return self.config_dir / "tool_registry.yaml"

    @property
    def tool_alias_registry_path(self) -> Path:
        return self.config_dir / "tool_alias_registry.yaml"

    @property
    def resource_catalog_path(self) -> Path:
        return self.docs_dir / "RESOURCE_CATALOG.md"

    @property
    def toolchain_lock_path(self) -> Path:
        return self.pipeline_dir / "toolchain.lock.yaml"

    @property
    def database_lock_path(self) -> Path:
        return self.pipeline_dir / "database.lock.yaml"

    @property
    def pipeline_lock_path(self) -> Path:
        return self.pipeline_dir / "pipeline.lock.yaml"

    @property
    def validation_report_path(self) -> Path:
        return self.pipeline_dir / "validation_report.json"

    @property
    def discovery_inventory_path(self) -> Path:
        return self.state_dir / "discovery_inventory.json"

    @classmethod
    def initialize(
        cls,
        root: str | Path,
        *,
        raw_data_path: str | Path,
        database_path: str | Path,
        output_path: str | Path,
        download_path: str | Path | None = None,
        knowledge_path: str | Path | None = None,
    ) -> PipelineProject:
        project = cls(root)
        raw = canonical_path(raw_data_path, must_exist=True)
        if not raw.is_dir():
            raise ConfigurationError(f"RAW_DATA_PATH is not a directory: {raw}")
        database = canonical_path(database_path)
        output = canonical_path(output_path)
        download = canonical_path(download_path or raw)
        knowledge = canonical_path(knowledge_path or output / "knowledge")
        for name, path in (("download", download), ("knowledge", knowledge)):
            if path.exists() and not path.is_dir():
                raise ConfigurationError(f"{name} path is not a directory: {path}")
        if download == database or database in download.parents or download == output:
            raise ConfigurationError("download path must be separate from the database and result roots")
        if knowledge == raw or knowledge == database or database in knowledge.parents:
            raise ConfigurationError("knowledge path must be separate from raw data and database roots")
        path_policy = PathPolicy.evaluate(raw, database, output)
        if not path_policy.valid:
            raise ConfigurationError(
                "[PATH_CONFIGURATION_ERROR] invalid RAW_DATA_PATH/DATABASE_PATH/OUTPUT_PATH roles: "
                + "; ".join(path_policy.errors)
            )
        if database.exists() and not database.is_dir():
            raise ConfigurationError(f"DATABASE_PATH is not a directory: {database}")
        if output.exists() and not output.is_dir():
            raise ConfigurationError(f"OUTPUT_PATH is not a directory: {output}")
        project.root.mkdir(parents=True, exist_ok=True)
        project.config_dir.mkdir(parents=True, exist_ok=True)
        project.docs_dir.mkdir(parents=True, exist_ok=True)
        project.state_dir.mkdir(parents=True, exist_ok=True)
        # Database and output roots are explicitly user-designated writable resources.
        database.mkdir(parents=True, exist_ok=True)
        output.mkdir(parents=True, exist_ok=True)
        (output / "runs").mkdir(parents=True, exist_ok=True)
        config = {
            "schema_version": SCHEMA_VERSION,
            "project_id": project.root.name,
            "phase": PipelinePhase.DISCOVERY.value,
            "created_at": _utcnow(),
            "paths": {
                "raw_data": str(raw),
                "database": str(database),
                "output": str(output),
                "download": str(download),
                "knowledge": str(knowledge),
                "confirmed_by_user": True,
                "confirmed_at": _utcnow(),
            },
            "discovery": {
                "configured_tools": [],
                "database_requirements": [],
            },
            "validation": {
                "pretest_fraction": 0.10,
                "random_seed": 1729,
                "max_records": None,
                "max_subset_bytes": 5 * 1024**3,
            },
            "production": {"minimum_free_disk_gb": 1.0},
            "path_policy": path_policy.as_dict(),
        }
        if project.config_path.exists():
            existing = project.load_config()
            expected_paths = {key: config["paths"][key] for key in ("raw_data", "database", "output")}
            existing_paths = {key: existing["paths"].get(key) for key in expected_paths}
            if existing_paths != expected_paths:
                raise ConfigurationError(
                    f"project already exists with different paths: {project.config_path}; create a new project root"
                )
            for key, supplied in (("download", download_path), ("knowledge", knowledge_path)):
                if supplied is not None and existing["paths"].get(key, config["paths"][key]) != config["paths"][key]:
                    raise ConfigurationError(f"project already exists with a different {key} path")
        else:
            write_yaml(project.config_path, config)
        output_config = output / "project_config.yaml"
        if output_config != project.config_path:
            if output_config.exists() or output_config.is_symlink():
                if output_config.resolve() != project.config_path.resolve():
                    raise ConfigurationError(
                        f"OUTPUT_PATH already contains a different project_config.yaml: {output_config}"
                    )
            else:
                output_config.symlink_to(project.config_path)
        from microbiome.pipeline.registry import initialize_registries
        from microbiome.pipeline.requirements import RequirementManager
        from microbiome.pipeline.state import ProjectStateMachine

        initialize_registries(project, database)
        ProjectStateMachine(project).initialize(paths_confirmed=True)
        RequirementManager(project).initialize()
        return project

    def export_paths(self) -> None:
        """Restore subprocess paths from the persisted project, never the cwd."""
        from microbiome.path_config import set_paths

        paths = self.load_config()["paths"]
        set_paths(raw_data_dir=paths["raw_data"], download_dir=paths.get("download", paths["raw_data"]),
                  db_root=paths["database"], results_dir=paths["output"],
                  software_memory_dir=str(self.knowledge_dir))
        manager_path = self.config_dir / "manager_registry.yaml"
        if manager_path.is_file():
            from microbiome.pipeline.io import fast_file_fingerprint
            manager = read_yaml(manager_path)
            executable = canonical_path(manager["executable"])
            if not executable.is_file() or manager.get("executable_fingerprint") != fast_file_fingerprint(executable):
                raise ConfigurationError("registered package manager is missing or drifted; explicit repair is required")
            os.environ["PATH"] = str(executable.parent) + os.pathsep + os.environ.get("PATH", "")

    def load_config(self) -> dict[str, Any]:
        config = read_yaml(self.config_path)
        if not isinstance(config, dict) or not isinstance(config.get("paths"), dict):
            raise ConfigurationError(f"invalid project configuration: {self.config_path}")
        required = ("raw_data", "database", "output")
        missing = [name for name in required if not config["paths"].get(name)]
        if missing:
            raise ConfigurationError(f"project configuration is missing paths: {', '.join(missing)}")
        policy = self._path_policy_from_config(config)
        if not policy.valid:
            raise ConfigurationError(
                "[PATH_CONFIGURATION_ERROR] invalid RAW_DATA_PATH/DATABASE_PATH/OUTPUT_PATH roles: "
                + "; ".join(policy.errors)
            )
        return config

    @staticmethod
    def _path_policy_from_config(config: dict[str, Any]) -> PathPolicyReport:
        paths = config["paths"]
        return PathPolicy.evaluate(paths["raw_data"], paths["database"], paths["output"])

    def path_policy(self) -> PathPolicyReport:
        """Return the live role-aware path policy for all project scanners."""
        return self._path_policy_from_config(self.load_config())

    def require_layout(self) -> None:
        if not self.config_path.is_file():
            raise ConfigurationError(f"project_config.yaml not found under {self.root}")
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.docs_dir.mkdir(parents=True, exist_ok=True)
        self.state_dir.mkdir(parents=True, exist_ok=True)
        self.runs_dir.mkdir(parents=True, exist_ok=True)
        for path in (
            self.requirements_dir,
            self.plans_dir,
            self.pretest_dir,
            self.pipeline_dir,
            self.knowledge_dir / "tools",
            self.knowledge_dir / "databases",
            self.resource_skills_dir,
            self.reports_dir,
        ):
            path.mkdir(parents=True, exist_ok=True)
        from microbiome.pipeline.registry import initialize_registries
        from microbiome.pipeline.requirements import RequirementManager
        from microbiome.pipeline.state import ProjectStateMachine

        initialize_registries(self, self.load_config()["paths"]["database"])
        ProjectStateMachine(self).initialize(paths_confirmed=True)
        RequirementManager(self).initialize()

    def set_phase(self, phase: PipelinePhase) -> None:
        config = self.load_config()
        config["phase"] = phase.value
        config["updated_at"] = _utcnow()
        write_yaml(self.config_path, config)


def _is_fastq(path: Path) -> bool:
    return path.name.lower().endswith(FASTQ_SUFFIXES)


def _is_fasta(path: Path) -> bool:
    name = path.name.lower()
    if name.endswith(".gz"):
        name = name[:-3]
    return name.endswith(FASTA_SUFFIXES)


def _peek_fastq(path: Path) -> dict[str, Any]:
    opener = gzip.open if path.name.lower().endswith(".gz") else open
    try:
        with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
            record = [handle.readline() for _ in range(4)]
        valid = all(record) and record[0].startswith("@") and record[2].startswith("+")
        return {"first_record_valid": bool(valid), "first_read_id": record[0][1:].split()[0] if valid else None}
    except (OSError, EOFError) as exc:
        return {"first_record_valid": False, "error": str(exc)}


def _peek_fasta(path: Path) -> dict[str, Any]:
    opener = gzip.open if path.name.lower().endswith(".gz") else open
    try:
        with opener(path, "rt", encoding="utf-8", errors="replace") as handle:
            header = handle.readline()
            sequence = ""
            for line in handle:
                if line.startswith(">"):
                    break
                sequence += line.strip()
                if sequence:
                    break
        valid = header.startswith(">") and bool(sequence)
        return {"first_record_valid": valid, "first_sequence_id": header[1:].split()[0] if valid else None}
    except (OSError, EOFError) as exc:
        return {"first_record_valid": False, "error": str(exc)}


def _sample_group(path: Path) -> tuple[str, str | None]:
    match = PAIR_RE.match(path.name)
    if not match:
        suffix = next((suffix for suffix in FASTQ_SUFFIXES if path.name.lower().endswith(suffix)), "")
        return path.name[: -len(suffix)] if suffix else path.stem, None
    sample = re.sub(r"[._-]+$", "", match.group("sample"))
    return sample, match.group("mate")


def _conda_environments() -> dict[str, Any]:
    conda = shutil.which("conda") or shutil.which("mamba") or shutil.which("micromamba")
    if not conda:
        return {"manager": None, "environments": [], "error": "no conda-compatible manager on PATH"}
    try:
        result = subprocess.run(
            [conda, "env", "list", "--json"],
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
        payload = json.loads(result.stdout) if result.returncode == 0 else {}
        environments = [str(canonical_path(value)) for value in payload.get("envs", [])]
        return {
            "manager": str(canonical_path(conda, must_exist=True)),
            "environments": environments,
            "exit_code": result.returncode,
            "stderr": result.stderr[-2000:],
        }
    except (OSError, subprocess.TimeoutExpired, json.JSONDecodeError) as exc:
        return {"manager": conda, "environments": [], "error": str(exc)}


def _database_inventory(database_root: Path, requirements: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by_name = {str(item.get("logical_name")): item for item in requirements if isinstance(item, dict)}
    names = set(by_name)
    if database_root.is_dir():
        names.update(item.name for item in database_root.iterdir() if not item.name.startswith("."))
    inventory = []
    for name in sorted(names):
        requirement = by_name.get(name, {})
        configured_path = requirement.get("root_path") or requirement.get("path")
        path = canonical_path(configured_path) if configured_path else database_root / name
        markers = [str(item) for item in requirement.get("expected_markers", [])]
        present = [marker for marker in markers if (path / marker).exists()]
        if not path.exists():
            status = "MISSING"
        elif markers and len(present) != len(markers):
            status = "INCOMPLETE"
        elif markers:
            status = "READY"
        else:
            status = "UNKNOWN"
        inventory.append(
            {
                "logical_name": name,
                "path": str(path.resolve()),
                "status": status,
                "expected_marker_files": markers,
                "present_marker_files": present,
            }
        )
    return inventory


def discover_project(project: PipelineProject) -> dict[str, Any]:
    """Inspect paths, FASTQs, databases, Conda envs, and executables without downloads."""
    project.require_layout()
    config = project.load_config()
    raw_root = canonical_path(config["paths"]["raw_data"], must_exist=True)
    database_root = canonical_path(config["paths"]["database"], must_exist=True)
    output_root = canonical_path(config["paths"]["output"], must_exist=True)
    path_policy = project.path_policy()
    if not raw_root.is_dir() or not database_root.is_dir() or not output_root.is_dir():
        raise ConfigurationError("configured raw/database/output paths must all be directories")

    fastqs: list[dict[str, Any]] = []
    fastas: list[dict[str, Any]] = []
    groups: dict[str, dict[str, Any]] = {}
    duplicate_inodes: dict[tuple[int, int], list[str]] = {}
    for path in (
        item
        for item in iter_files_pruned(raw_root, excluded_roots=path_policy.input_exclusion_roots)
        if _is_fastq(item) or _is_fasta(item)
    ):
        stat = path.stat()
        duplicate_inodes.setdefault((stat.st_dev, stat.st_ino), []).append(str(path.resolve()))
        common = {
            **fast_file_fingerprint(path),
            "readable": os.access(path, os.R_OK),
            "compressed": path.name.lower().endswith(".gz"),
        }
        if _is_fasta(path):
            fastas.append({**common, **_peek_fasta(path), "format": "FASTA"})
            continue
        sample, mate = _sample_group(path)
        entry = {
            **common,
            **_peek_fastq(path),
            "format": "FASTQ",
            "sample_id": sample,
            "mate": int(mate) if mate else None,
        }
        fastqs.append(entry)
        group = groups.setdefault(sample, {"sample_id": sample, "reads_1": [], "reads_2": [], "unpaired": []})
        group[f"reads_{mate}" if mate else "unpaired"].append(str(path.resolve()))

    sample_groups = list(groups.values())
    incomplete_pairs = [
        group["sample_id"]
        for group in sample_groups
        if bool(group["reads_1"]) != bool(group["reads_2"]) or len(group["reads_1"]) != len(group["reads_2"])
    ]
    paired_groups = [group for group in sample_groups if group["reads_1"] and group["reads_2"]]
    unpaired_files = [path for group in sample_groups for path in group["unpaired"]]
    if fastqs and not fastas:
        if paired_groups and not incomplete_pairs and not unpaired_files:
            detected_input_type = "paired_fastq"
        elif unpaired_files and not paired_groups and not incomplete_pairs:
            detected_input_type = "single_fastq"
        else:
            detected_input_type = "mixed_fastq"
    elif fastas and not fastqs:
        detected_input_type = "fasta"
    elif fastas or fastqs:
        detected_input_type = "mixed_sequence"
    else:
        detected_input_type = "unknown"
    corrupt_files = [
        entry["path"] for entry in [*fastqs, *fastas] if not entry.get("first_record_valid") or not entry["readable"]
    ]
    duplicate_files = [paths for paths in duplicate_inodes.values() if len(paths) > 1]
    discovery_issues = [
        *([f"incomplete paired reads: {', '.join(incomplete_pairs)}"] if incomplete_pairs else []),
        *([f"invalid or unreadable inputs: {', '.join(corrupt_files)}"] if corrupt_files else []),
        *(["duplicate files resolve to the same inode"] if duplicate_files else []),
        *(["no supported FASTA/FASTQ inputs found"] if not fastqs and not fastas else []),
    ]

    configured_tools = config.get("discovery", {}).get("configured_tools", [])
    requested = [str(item.get("executable") or item.get("tool")) for item in configured_tools if isinstance(item, dict)]
    tool_names = sorted(set(COMMON_BIOINFORMATICS_EXECUTABLES) | {name for name in requested if name})
    executables = []
    for name in tool_names:
        resolved = shutil.which(name)
        if resolved:
            executables.append({"name": name, "absolute_path": str(canonical_path(resolved, must_exist=True))})

    inventory = {
        "schema_version": SCHEMA_VERSION,
        "generated_at": _utcnow(),
        "mode": "read-only discovery; no downloads or raw-data modifications were performed",
        "paths": {"raw_data": str(raw_root), "database": str(database_root), "output": str(output_root)},
        "path_policy": path_policy.as_dict(),
        "raw_data": {
            "status": "VALID" if not discovery_issues else "INVALID",
            "detected_input_type": detected_input_type,
            "fastq_files": fastqs,
            "fasta_files": fastas,
            "sample_groups": sample_groups,
            "incomplete_pairs": incomplete_pairs,
            "duplicate_files": duplicate_files,
            "issues": discovery_issues,
        },
        "databases": _database_inventory(database_root, config.get("discovery", {}).get("database_requirements", [])),
        "conda": _conda_environments(),
        "path_executables": executables,
    }
    inventory["inventory_fingerprint"] = object_fingerprint(inventory)
    write_json(project.discovery_inventory_path, inventory)
    from microbiome.pipeline.requirements import RequirementManager
    from microbiome.pipeline.state import LifecycleState, ProjectStateMachine

    RequirementManager(project).check_discovery_compatibility(inventory)
    machine = ProjectStateMachine(project)
    if machine.current == LifecycleState.DATA_DISCOVERY:
        machine.transition(LifecycleState.DATA_CHARACTERIZATION, reason="automatic input discovery completed")
    project.set_phase(PipelinePhase.PLANNING)
    return inventory
