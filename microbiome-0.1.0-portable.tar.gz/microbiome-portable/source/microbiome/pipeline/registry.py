"""Persistent resource registries and the generated human-readable catalog.

The registries are mutable only during explicit bootstrap/database-resolution
phases.  Frozen production reads and verifies them, but never repairs them.
"""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from microbiome.pipeline.errors import ConfigurationError, ResourceNotReadyError
from microbiome.pipeline.io import (
    atomic_write_text,
    canonical_path,
    manifest_fingerprint,
    read_yaml,
    write_yaml,
)

if TYPE_CHECKING:
    from microbiome.pipeline.project import PipelineProject

REGISTRY_SCHEMA_VERSION = 1


def _utcnow() -> str:
    return datetime.now(UTC).isoformat()


def _sealed(payload: dict[str, Any]) -> dict[str, Any]:
    result = dict(payload)
    result["manifest_fingerprint"] = manifest_fingerprint(result)
    return result


def _empty_database_registry(database_root: str | Path) -> dict[str, Any]:
    return _sealed(
        {
            "schema_version": REGISTRY_SCHEMA_VERSION,
            "database_root": str(canonical_path(database_root)),
            "resources": {},
        }
    )


def _empty_tool_registry() -> dict[str, Any]:
    return _sealed({"schema_version": REGISTRY_SCHEMA_VERSION, "tools": {}})


def _load_registry(path: Path, *, kind: str) -> dict[str, Any]:
    value = read_yaml(path)
    if not isinstance(value, dict):
        raise ConfigurationError(f"{kind} registry must contain a mapping: {path}")
    if value.get("schema_version") != REGISTRY_SCHEMA_VERSION:
        raise ConfigurationError(f"unsupported {kind} registry schema: {path}")
    collection = "resources" if kind == "database" else "tools"
    if not isinstance(value.get(collection), dict):
        raise ConfigurationError(f"{kind} registry requires a {collection} mapping: {path}")
    if value.get("manifest_fingerprint") != manifest_fingerprint(value):
        raise ConfigurationError(f"{kind} registry fingerprint is invalid: {path}")
    return value


def load_database_registry(path: str | Path, *, database_root: str | Path | None = None) -> dict[str, Any]:
    target = canonical_path(path, must_exist=True)
    value = _load_registry(target, kind="database")
    registered_root = canonical_path(value.get("database_root", ""))
    if database_root is not None and registered_root != canonical_path(database_root):
        raise ConfigurationError(
            f"database registry root {registered_root} does not match configured DATABASE_PATH "
            f"{canonical_path(database_root)}"
        )
    return value


def load_tool_registry(path: str | Path) -> dict[str, Any]:
    return _load_registry(canonical_path(path, must_exist=True), kind="tool")


def find_registered_tool(registry: dict[str, Any], logical_tool: str) -> tuple[str, dict[str, Any]] | None:
    """Find a reusable READY binding by logical name, family, alias, or executable.

    Step contracts and reusable resource bindings intentionally share the same
    fingerprinted registry.  Frozen execution still addresses step contracts by
    step ID; bootstrap discovery can reuse any validated capability entry.
    """

    requested = str(logical_tool).strip().casefold()
    matches: list[tuple[str, dict[str, Any]]] = []
    for contract_id, entry in registry.get("tools", {}).items():
        if not isinstance(entry, dict) or str(entry.get("status", "READY")).upper() != "READY":
            continue
        names = {
            str(entry.get("tool_id") or "").casefold(),
            str(entry.get("resource_id") or "").casefold(),
            str(entry.get("software_family") or "").casefold(),
            Path(str(entry.get("executable") or "")).name.casefold(),
            *(str(value).casefold() for value in entry.get("aliases", []) or []),
        }
        if requested in names:
            matches.append((str(contract_id), entry))
    if not matches:
        return None
    return sorted(matches, key=lambda item: (not item[0].startswith("resource:"), item[0]))[0]


def register_tool_binding(
    path: str | Path,
    binding: dict[str, Any],
    *,
    contract_id: str | None = None,
) -> tuple[dict[str, Any], str]:
    """Persist one validated, reusable software capability binding.

    This function is bootstrap-only.  It never installs, repairs, or updates a
    frozen lock; it records the exact executable that an independent resolver
    has already smoke-tested.
    """

    executable = canonical_path(binding["executable"], must_exist=True)
    if not executable.is_file():
        raise ResourceNotReadyError(f"validated executable is not a file: {executable}")
    target = canonical_path(path)
    previous = load_tool_registry(target) if target.is_file() else _empty_tool_registry()
    tools = dict(previous["tools"])
    logical_tool = str(binding.get("tool") or binding.get("tool_id") or executable.name)
    family = str(binding.get("software_family") or binding.get("resource_id") or logical_tool)
    safe_family = "".join(character if character.isalnum() or character in "_.-" else "-" for character in family)
    safe_executable = "".join(
        character if character.isalnum() or character in "_.-" else "-" for character in executable.name
    )
    key = contract_id or f"resource:{safe_family}:{safe_executable}"
    now = _utcnow()
    old = tools.get(key, {}) if isinstance(tools.get(key), dict) else {}
    tools[key] = {
        "contract_id": key,
        "resource_id": family,
        "tool_id": logical_tool,
        "software_family": family,
        "status": "READY",
        "executable": str(executable),
        "conda_prefix": binding.get("environment_prefix") or binding.get("conda_prefix"),
        "version": binding.get("version_output") or binding.get("version"),
        "version_args": list(binding.get("version_args", ["--version"])),
        "version_exit_code": binding.get("version_exit_code", 0),
        "help_args": list(binding.get("help_args", ["--help"])),
        "runtime_launcher": list(binding.get("runtime_launcher") or []),
        "runtime_launcher_fingerprint": binding.get("runtime_launcher_fingerprint"),
        "package_candidates": list(binding.get("package_candidates") or []),
        "package_inventory": list(binding.get("package_inventory") or []),
        "aliases": list(dict.fromkeys(str(value) for value in binding.get("aliases", []) or [])),
        "skill_path": binding.get("skill_path"),
        "help_path": binding.get("help_path"),
        "installation_recipe": binding.get("installation_recipe"),
        "installation_source": (
            old.get("installation_source")
            if old and binding.get("installation_source") in {"tool registry", "pipeline lock"}
            else binding.get("installation_source")
        ),
        "installed_at": old.get("installed_at") or binding.get("installed_at"),
        "validated_at": binding.get("validated_at") or now,
        "last_successful_use": binding.get("last_successful_use") or old.get("last_successful_use"),
        "validation_result": "PASSED",
        "allow_setup_in_production": False,
        "allow_db_build_in_production": False,
    }
    updated = _sealed(
        {
            "schema_version": REGISTRY_SCHEMA_VERSION,
            "updated_at": now,
            "tools": tools,
        }
    )
    write_yaml(target, updated)
    return updated, key


def mark_tool_success(path: str | Path, logical_tool: str, *, used_at: str | None = None) -> dict[str, Any]:
    """Update last-success timestamps without changing executable identity fields."""

    target = canonical_path(path, must_exist=True)
    registry = load_tool_registry(target)
    tools = dict(registry["tools"])
    now = used_at or _utcnow()
    changed = False
    for key, entry in list(tools.items()):
        if not isinstance(entry, dict):
            continue
        found = find_registered_tool(
            _sealed({"schema_version": REGISTRY_SCHEMA_VERSION, "tools": {key: entry}}), logical_tool
        )
        if found:
            tools[key] = {**entry, "last_successful_use": now}
            changed = True
    if not changed:
        return registry
    updated = _sealed(
        {
            "schema_version": REGISTRY_SCHEMA_VERSION,
            "updated_at": now,
            "tools": tools,
        }
    )
    write_yaml(target, updated)
    return updated


def initialize_registries(project: PipelineProject, database_root: str | Path) -> None:
    """Create empty, fingerprinted registries without replacing existing facts."""
    project.config_dir.mkdir(parents=True, exist_ok=True)
    project.docs_dir.mkdir(parents=True, exist_ok=True)
    if not project.database_registry_path.exists():
        write_yaml(project.database_registry_path, _empty_database_registry(database_root))
    else:
        load_database_registry(project.database_registry_path, database_root=database_root)
    if not project.tool_registry_path.exists():
        write_yaml(project.tool_registry_path, _empty_tool_registry())
    else:
        load_tool_registry(project.tool_registry_path)
    generate_resource_catalog(project)


def _database_contract(entry: dict[str, Any]) -> dict[str, Any]:
    return {
        "resource_id": entry["logical_name"],
        "type": entry.get("type", "database"),
        "root_path": entry.get("root_path") or entry["path"],
        "source_files": list(entry.get("source_files", [])),
        "purpose": entry.get("purpose", "declared pipeline database resource"),
        "supported_tools": list(entry.get("supported_tools", [])),
        "documentation": list(entry.get("documentation", [])),
        "runtime_entry": entry.get("runtime_entry") or entry["path"],
        "consumer_entrypoints": dict(entry.get("consumer_entrypoints") or {}),
        "common_markers": list(entry.get("common_markers") or []),
        "consumer_markers": dict(entry.get("consumer_markers") or {}),
        "validation_contract": dict(entry.get("validation_contract") or {}),
        "runtime_kind": entry.get("runtime_kind", "existing"),
        "runtime_suffix_sets": list(entry.get("runtime_suffix_sets") or []),
        "consumer_entrypoint_kinds": dict(entry.get("consumer_entrypoint_kinds") or {}),
        "consumer_suffix_sets": dict(entry.get("consumer_suffix_sets") or {}),
        "marker_files": list(entry["expected_marker_files"]),
        "version": str(entry.get("database_version", "UNKNOWN")),
        "fingerprint": entry.get("fingerprint"),
        "status": entry["status"],
        "read_only": True,
    }


def update_database_registry(
    path: str | Path,
    *,
    database_root: str | Path,
    resolved: dict[str, dict[str, Any]],
) -> tuple[dict[str, Any], dict[str, dict[str, Any]], list[str]]:
    """Import or re-check local resources without downloading or rebuilding.

    A READY entry with the same contract and fingerprint is reused.  Reusing a
    resource ID for a different path, version, marker set, or runtime entry is
    rejected; such a resource needs a new ID.  Failed checks are persisted as a
    non-READY status before the caller is stopped.
    """
    target = canonical_path(path)
    registry = (
        load_database_registry(target, database_root=database_root)
        if target.is_file()
        else _empty_database_registry(database_root)
    )
    resources = dict(registry["resources"])
    now = _utcnow()
    events: list[str] = []
    failures: list[str] = []
    report_entries: dict[str, dict[str, Any]] = {}
    identity_fields = (
        "type",
        "root_path",
        "source_files",
        "runtime_entry",
        "marker_files",
        "common_markers",
        "consumer_markers",
        "version",
    )

    for resource_id, observed in sorted(resolved.items()):
        candidate = _database_contract(observed)
        previous = resources.get(resource_id)
        if previous is not None:
            changed = [field for field in identity_fields if previous.get(field) != candidate.get(field)]
            # Older registries can gain these fields after a full local check;
            # once recorded, a caller cannot remove or weaken the contract.
            changed.extend(
                field for field in ("validation_contract", "runtime_kind", "runtime_suffix_sets")
                if field in previous and previous[field] != candidate[field]
            )
            if changed:
                raise ConfigurationError(
                    f"registered database {resource_id} changed immutable contract fields "
                    f"({', '.join(changed)}); assign a new logical_name/resource_id"
                )
            previous_entrypoints = dict(previous.get("consumer_entrypoints") or {})
            changed_consumers = [
                consumer
                for consumer, entrypoint in dict(candidate.get("consumer_entrypoints") or {}).items()
                if consumer in previous_entrypoints and previous_entrypoints[consumer] != entrypoint
            ]
            if changed_consumers:
                raise ConfigurationError(
                    f"registered database {resource_id} changed immutable consumer entrypoints "
                    f"({', '.join(sorted(changed_consumers))}); assign a new logical_name/resource_id"
                )
            candidate["consumer_entrypoints"] = {
                **previous_entrypoints,
                **dict(candidate.get("consumer_entrypoints") or {}),
            }
            for field in ("consumer_entrypoint_kinds", "consumer_suffix_sets"):
                old_values = dict(previous.get(field) or {})
                new_values = candidate[field]
                if any(name in old_values and old_values[name] != value for name, value in new_values.items()):
                    raise ConfigurationError(
                        f"registered database {resource_id} changed immutable {field}; assign a new logical_name/resource_id"
                    )
                candidate[field] = {**old_values, **new_values}

        status = candidate["status"]
        if previous and previous.get("status") == "READY" and status == "READY":
            if previous.get("fingerprint") == candidate.get("fingerprint"):
                event = f"REUSE READY RESOURCE {resource_id} at {candidate['runtime_entry']}"
                events.append(event)
                candidate["created_by"] = previous.get("created_by", "import-existing")
                candidate["validated_at"] = previous.get("validated_at", now)
            else:
                candidate["status"] = "CORRUPT"
                candidate["created_by"] = previous.get("created_by", "import-existing")
                candidate["validated_at"] = previous.get("validated_at")
                failures.append(f"{resource_id}=CORRUPT (fingerprint drift)")
        elif status == "READY":
            candidate["created_by"] = previous.get("created_by", "import-existing") if previous else "import-existing"
            candidate["validated_at"] = now
            events.append(f"REGISTER READY RESOURCE {resource_id} at {candidate['runtime_entry']}")
        else:
            candidate["created_by"] = previous.get("created_by", "unresolved") if previous else "unresolved"
            candidate["validated_at"] = previous.get("validated_at") if previous else None
            failures.append(f"{resource_id}={status}")

        candidate["last_checked_at"] = now
        resources[resource_id] = candidate
        report_entries[resource_id] = {
            **observed,
            "path": candidate["runtime_entry"],
            "root_path": candidate["root_path"],
            "runtime_entry": candidate["runtime_entry"],
            "status": candidate["status"],
            "fingerprint": candidate.get("fingerprint"),
            "registry_action": events[-1] if events and events[-1].split()[3] == resource_id else None,
        }

    updated = _sealed(
        {
            "schema_version": REGISTRY_SCHEMA_VERSION,
            "database_root": str(canonical_path(database_root)),
            "updated_at": now,
            "resources": resources,
        }
    )
    write_yaml(target, updated)
    if failures:
        raise ResourceNotReadyError("database resolution failed without download or repair: " + ", ".join(failures))
    return updated, report_entries, events


def _arg_binding(command_template: list[str], alias: str) -> str:
    placeholder = f"{{database.{alias}}}"
    for index, token in enumerate(command_template):
        if placeholder not in token:
            continue
        if token == placeholder and index and command_template[index - 1].startswith("-"):
            return f"{command_template[index - 1]} {placeholder}"
        return token
    return "declared_for_validation_only"


def update_tool_registry(
    path: str | Path,
    *,
    steps: list[dict[str, Any]],
    resolved: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    """Persist exact step-level tool contracts after executable smoke tests."""
    target = canonical_path(path)
    previous = load_tool_registry(target) if target.is_file() else _empty_tool_registry()
    tools = dict(previous["tools"])
    now = _utcnow()
    repository_root = canonical_path(__file__).parents[2]
    for step in steps:
        step_id = step["step_id"]
        tool = resolved[step_id]
        database_contract: str | dict[str, Any]
        if not step.get("database"):
            database_contract = "none"
        else:
            database_contract = {
                alias: {
                    "resource_id": str(spec.get("logical_name") or alias),
                    "runtime_resource": "runtime_entry",
                    "arg_binding": _arg_binding(step["command_template"], alias),
                }
                for alias, spec in sorted(step["database"].items())
            }
        tool_name = str(step["tool"]).rsplit("/", 1)[-1].casefold()
        documentation_candidates = (
            repository_root / "software_memory" / f"{tool_name}.md",
            repository_root / "microbiome" / "resource_skills" / "software" / tool_name / "SKILL.md",
        )
        tools[step_id] = {
            "contract_id": step_id,
            "tool_id": tool["tool"],
            "conda_prefix": tool.get("environment_prefix"),
            "executable": tool["executable"],
            "version": tool["version_output"],
            "version_requirement": tool["tool_version_requirement"],
            "version_args": tool["version_args"],
            "version_exit_code": tool.get("version_exit_code", 0),
            "help_args": list(tool.get("help_args", ["--help"])),
            "runtime_launcher": list(tool.get("runtime_launcher") or []),
            "runtime_launcher_fingerprint": tool.get("runtime_launcher_fingerprint"),
            "database_contract": database_contract,
            "purpose": step["purpose"],
            "documentation": [str(item) for item in documentation_candidates if item.is_file()],
            "known_working_command": step["command_template"],
            "known_failure_modes": step["failure_criteria"],
            "resource_policy": {
                "threads": step["threads_policy"],
                "memory": step["memory_policy"],
                "gpu": step["gpu_policy"],
            },
            "preflight": [
                "executable_exists",
                "version_matches",
                *([] if database_contract == "none" else ["database_status_ready", "marker_files_exist"]),
            ],
            "allow_setup_in_production": False,
            "allow_db_build_in_production": False,
            "validated_at": now,
        }
    updated = _sealed(
        {
            "schema_version": REGISTRY_SCHEMA_VERSION,
            "updated_at": now,
            "tools": tools,
        }
    )
    write_yaml(target, updated)
    return updated


def _cell(value: Any) -> str:
    if value is None or value == "":
        return "none"
    return str(value).replace("|", "\\|").replace("\n", " ")


def render_resource_catalog(database_registry: dict[str, Any], tool_registry: dict[str, Any]) -> str:
    """Render the deterministic catalog; YAML registries remain authoritative."""
    lines = [
        "# Resource Catalog",
        "",
        "> Generated from `config/database_registry.yaml` and `config/tool_registry.yaml`. ",
        "> Do not edit this file manually; regenerate it with `microbiome-pipeline catalog`.",
        "",
        "## Tool contracts",
        "",
        "| Contract | Tool | Executable | Conda prefix | Database contract | Status |",
        "| --- | --- | --- | --- | --- | --- |",
    ]
    for contract_id, tool in sorted(tool_registry["tools"].items()):
        database_contract = tool.get("database_contract", "none")
        if isinstance(database_contract, dict):
            database_text = "; ".join(
                f"{alias}={value.get('resource_id', '?')} ({value.get('arg_binding', '?')})"
                if isinstance(value, dict)
                else f"{alias}={value}"
                for alias, value in sorted(database_contract.items())
            )
        else:
            database_text = "none"
        lines.append(
            "| "
            + " | ".join(
                _cell(value)
                for value in (
                    contract_id,
                    tool.get("tool_id"),
                    tool.get("executable"),
                    tool.get("conda_prefix"),
                    database_text,
                    "VALIDATED",
                )
            )
            + " |"
        )
    if not tool_registry["tools"]:
        lines.append("| none | none | none | none | none | NOT_CONFIGURED |")

    lines.extend(
        [
            "",
            "## Database resources",
            "",
            "| Resource ID | Type | Purpose | Root path | Runtime entry | Consumer entrypoints | Version | Marker files | Supported tools | Status | Read only |",
            "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |",
        ]
    )
    for resource_id, resource in sorted(database_registry["resources"].items()):
        lines.append(
            "| "
            + " | ".join(
                _cell(value)
                for value in (
                    resource_id,
                    resource.get("type"),
                    resource.get("purpose"),
                    resource.get("root_path"),
                    resource.get("runtime_entry"),
                    "; ".join(
                        f"{consumer}={entrypoint}"
                        for consumer, entrypoint in sorted((resource.get("consumer_entrypoints") or {}).items())
                    ),
                    resource.get("version"),
                    ", ".join(resource.get("marker_files", [])),
                    ", ".join(resource.get("supported_tools", [])),
                    resource.get("status"),
                    str(bool(resource.get("read_only"))).lower(),
                )
            )
            + " |"
        )
    if not database_registry["resources"]:
        lines.append("| none | none | none | none | none | none | none | none | none | NOT_CONFIGURED | true |")
    lines.append("")
    return "\n".join(lines)


def generate_resource_catalog(project: PipelineProject, *, check: bool = False) -> dict[str, Any]:
    database_registry = load_database_registry(
        project.database_registry_path,
        database_root=project.load_config()["paths"]["database"] if project.config_path.is_file() else None,
    )
    tool_registry = load_tool_registry(project.tool_registry_path)
    expected = render_resource_catalog(database_registry, tool_registry)
    matches = (
        project.resource_catalog_path.is_file()
        and project.resource_catalog_path.read_text(encoding="utf-8") == expected
    )
    if check and not matches:
        raise ConfigurationError(
            f"resource catalog differs from its registries: {project.resource_catalog_path}; regenerate it"
        )
    if not check and not matches:
        atomic_write_text(project.resource_catalog_path, expected)
        matches = True
    return {
        "status": "CURRENT" if matches else "STALE",
        "path": str(project.resource_catalog_path),
        "database_registry_fingerprint": database_registry["manifest_fingerprint"],
        "tool_registry_fingerprint": tool_registry["manifest_fingerprint"],
    }
