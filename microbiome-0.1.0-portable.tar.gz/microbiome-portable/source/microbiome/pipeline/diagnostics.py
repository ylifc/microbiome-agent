"""Deterministic production/validation failure classification."""

from __future__ import annotations

from typing import Any

from microbiome.pipeline.models import FailureCategory


def classify_failure(
    *,
    exit_code: int | None,
    stdout: str = "",
    stderr: str = "",
    assertion_failed: bool = False,
    preflight_kind: str | None = None,
) -> FailureCategory:
    text = f"{stdout}\n{stderr}".casefold()
    if preflight_kind == "input":
        return FailureCategory.INPUT_FAILURE
    if preflight_kind == "environment":
        return FailureCategory.ENVIRONMENT_FAILURE
    if preflight_kind == "database":
        return FailureCategory.DATABASE_FAILURE
    if preflight_kind == "resource":
        return FailureCategory.RESOURCE_FAILURE
    if assertion_failed:
        return FailureCategory.OUTPUT_VALIDATION_FAILURE
    if any(marker in text for marker in ("truncated fastq", "invalid fasta", "invalid fastq", "parse error")):
        return FailureCategory.FORMAT_FAILURE
    if any(marker in text for marker in ("no such file", "file not found", "path does not exist")):
        return FailureCategory.PATH_FAILURE
    if any(marker in text for marker in ("connection reset", "network is unreachable", "timed out", "http error")):
        return FailureCategory.NETWORK_FAILURE
    if any(marker in text for marker in ("syntax error", "unexpected token", "usage:")):
        return FailureCategory.COMMAND_SYNTAX_FAILURE
    if any(marker in text for marker in ("missing dependency", "module not found", "no module named")):
        return FailureCategory.DEPENDENCY_FAILURE
    if "index" in text and any(marker in text for marker in ("missing", "not found", "corrupt", "incompatible")):
        return FailureCategory.DATABASE_INDEX_FAILURE
    if any(marker in text for marker in ("input file", "empty input")):
        return FailureCategory.INPUT_FAILURE
    if any(marker in text for marker in ("not a conda environment", "environmentlocationnotfound", "shared libraries")):
        return FailureCategory.ENVIRONMENT_FAILURE
    if "database" in text and any(marker in text for marker in ("missing", "not found", "corrupt", "index")):
        return FailureCategory.DATABASE_FAILURE
    if any(marker in text for marker in ("out of memory", "cannot allocate memory", "disk quota", "no space left")):
        return FailureCategory.RESOURCE_FAILURE
    if any(
        marker in text
        for marker in ("unrecognized option", "unrecognized argument", "invalid option", "illegal option")
    ):
        return FailureCategory.PARAMETER_FAILURE
    if any(
        marker in text for marker in ("command not found", "permission denied", "segmentation fault", "core dumped")
    ):
        return FailureCategory.SOFTWARE_FAILURE
    if exit_code not in (None, 0):
        return FailureCategory.SOFTWARE_FAILURE
    return FailureCategory.UNKNOWN_FAILURE


def failure_record(
    *,
    step: str,
    sample: str,
    command: list[str],
    environment: str | None,
    tool_version: str,
    database: dict[str, str],
    exit_code: int | None,
    stdout: str,
    stderr: str,
    input_metadata: dict[str, Any],
    assertion_failed: bool = False,
) -> dict[str, Any]:
    category = classify_failure(exit_code=exit_code, stdout=stdout, stderr=stderr, assertion_failed=assertion_failed)
    return {
        "category": category.value,
        "step": step,
        "sample": sample,
        "command": command,
        "environment": environment,
        "tool_version": tool_version,
        "database": database,
        "exit_code": exit_code,
        "stdout": stdout,
        "stderr": stderr,
        "input_metadata": input_metadata,
        "action": "STOP_AFFECTED_BRANCH; diagnose in repair-validation mode; do not hot-patch production",
    }
