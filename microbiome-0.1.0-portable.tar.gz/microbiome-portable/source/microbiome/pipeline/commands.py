"""Template rendering, external-command logging, and output assertions."""

from __future__ import annotations

import csv
import gzip
import json
import os
import re
import subprocess
import time
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

import yaml

from microbiome.pipeline.errors import ConfigurationError, ExecutionError, ResourceNotReadyError
from microbiome.pipeline.io import atomic_write_text, canonical_path, write_json
from microbiome.resource_config import ResourceSnapshot, get_config

if TYPE_CHECKING:
    from collections.abc import Callable
    from pathlib import Path

PLACEHOLDER_RE = re.compile(r"\{([A-Za-z][A-Za-z0-9_.-]*)\}")


def utcnow() -> str:
    return datetime.now(UTC).isoformat()


def _render_string(template: str, context: dict[str, Any]) -> str:
    def replace(match: re.Match[str]) -> str:
        name = match.group(1)
        if name not in context:
            raise ConfigurationError(f"unresolved pipeline placeholder: {{{name}}}")
        value = context[name]
        if isinstance(value, (dict, list)):
            raise ConfigurationError(f"pipeline placeholder {{{name}}} is not scalar")
        return str(value)

    rendered = PLACEHOLDER_RE.sub(replace, template)
    if "{" in rendered or "}" in rendered:
        raise ConfigurationError(f"unsupported or malformed placeholder in: {template}")
    return rendered


def _render_mapping(values: dict[str, Any], context: dict[str, Any], namespace: str) -> dict[str, str]:
    result: dict[str, str] = {}
    pending = dict(values)
    for _round in range(len(pending) + 1):
        progressed = False
        for name, raw in list(pending.items()):
            if not isinstance(raw, str):
                raise ConfigurationError(f"{namespace}.{name} must be a path template string")
            try:
                rendered = _render_string(
                    raw, {**context, **{f"{namespace}.{key}": value for key, value in result.items()}}
                )
            except ConfigurationError as exc:
                if "unresolved pipeline placeholder" in str(exc):
                    continue
                raise
            result[name] = str(canonical_path(rendered))
            pending.pop(name)
            progressed = True
        if not pending:
            return result
        if not progressed:
            break
    raise ConfigurationError(f"could not resolve {namespace} templates: {', '.join(sorted(pending))}")


def step_database_paths(step: dict[str, Any], database_locks: dict[str, dict[str, Any]]) -> dict[str, str]:
    result: dict[str, str] = {}
    for key, spec in step.get("database", {}).items():
        logical_name = str(spec.get("logical_name") or key) if isinstance(spec, dict) else key
        if logical_name not in database_locks:
            raise ConfigurationError(f"step {step['step_id']}: database is not locked: {logical_name}")
        result[key] = str(database_locks[logical_name]["path"])
    return result


def select_step_resources(step: dict[str, Any], snapshot: ResourceSnapshot | dict[str, Any]) -> dict[str, Any]:
    """Select the largest live allocation permitted by a step's frozen ranges."""
    live = snapshot.as_dict() if isinstance(snapshot, ResourceSnapshot) else dict(snapshot)
    thread_policy = step.get("threads_policy", {"min": 1, "max": 1})
    threads = min(int(live["cpu_threads"]), int(thread_policy.get("max", 1)))
    minimum_threads = int(thread_policy.get("min", 1))
    if threads < minimum_threads:
        raise ResourceNotReadyError(
            f"step {step['step_id']}: {threads} CPU threads are allocatable, but at least "
            f"{minimum_threads} are required"
        )

    memory_policy = step.get("memory_policy", {})
    available_memory = int(live["memory_budget_gb"])
    maximum_memory = memory_policy.get("max_gb")
    memory_gb = min(available_memory, int(maximum_memory)) if maximum_memory is not None else available_memory
    minimum_memory = int(memory_policy.get("min_gb", 0))
    if memory_gb < minimum_memory:
        raise ResourceNotReadyError(
            f"step {step['step_id']}: {memory_gb} GiB RAM is allocatable, but at least {minimum_memory} GiB is required"
        )

    gpu_policy = step.get("gpu_policy", {})
    gpu_enabled = bool(gpu_policy.get("enabled", False))
    maximum_gpus = gpu_policy.get("max")
    gpus = int(live.get("gpu_count", 0)) if gpu_enabled else 0
    if maximum_gpus is not None:
        gpus = min(gpus, int(maximum_gpus))
    minimum_gpus = int(gpu_policy.get("min", 0)) if gpu_enabled else 0
    if gpus < minimum_gpus:
        raise ResourceNotReadyError(
            f"step {step['step_id']}: {gpus} GPUs are allocatable, but at least {minimum_gpus} are required"
        )
    device_ids = [item for item in str(live.get("gpu_devices", "")).split(",") if item][:gpus]
    live_gpu_count = int(live.get("gpu_count", 0))
    gpu_memory_gb = round(int(live.get("gpu_memory_gb", 0)) * gpus / live_gpu_count) if live_gpu_count and gpus else 0
    return {
        "strategy": "MAXIMIZE_WITHIN_LIVE_AND_FROZEN_LIMITS",
        "threads": threads,
        "memory_gb": memory_gb,
        "memory_mb": memory_gb * 1024,
        "memory_bytes": memory_gb * 1024**3,
        "gpus": gpus,
        "gpu_devices": ",".join(device_ids),
        "gpu_memory_gb": gpu_memory_gb,
        "max_parallel_samples": int(live.get("max_parallel_samples", 1)),
        "gpu_enabled": gpu_enabled,
    }


def render_step(
    step: dict[str, Any],
    tool_lock: dict[str, Any],
    database_locks: dict[str, dict[str, Any]],
    *,
    runtime_inputs: dict[str, str],
    run_dir: str | Path,
    temp_dir: str | Path,
    sample_id: str,
    threads: int | None = None,
    memory_gb: int | None = None,
    gpus: int | None = None,
    resource_snapshot: ResourceSnapshot | dict[str, Any] | None = None,
    project_paths: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Render only approved runtime placeholders into a frozen argv template."""
    snapshot = resource_snapshot or get_config().snapshot(
        threads_cap=threads,
        memory_cap_gb=memory_gb,
        gpu_cap=gpus,
    )
    resources = select_step_resources(step, snapshot)
    resolved_run = canonical_path(run_dir)
    resolved_temp = canonical_path(temp_dir)
    paths = project_paths or {}
    context: dict[str, Any] = {
        "executable": tool_lock["executable"],
        "sample_id": sample_id,
        "threads": resources["threads"],
        "memory_gb": resources["memory_gb"],
        "memory_mb": resources["memory_mb"],
        "memory_bytes": resources["memory_bytes"],
        "gpus": resources["gpus"],
        "gpu_devices": resources["gpu_devices"],
        "gpu_memory_gb": resources["gpu_memory_gb"],
        "max_parallel_samples": resources["max_parallel_samples"],
        "run_dir": str(resolved_run),
        "temp_dir": str(resolved_temp),
        "raw_data_path": paths.get("raw_data", ""),
        "database_root": paths.get("database", ""),
        "output_root": paths.get("output", ""),
    }
    for key, value in runtime_inputs.items():
        context[f"runtime.{key}"] = str(canonical_path(value))
    database_paths = step_database_paths(step, database_locks)
    for key, value in database_paths.items():
        context[f"database.{key}"] = value
    inputs = _render_mapping(step.get("input", {}), context, "input")
    context.update({f"input.{key}": value for key, value in inputs.items()})
    outputs = _render_mapping(step.get("output", {}), context, "output")
    context.update({f"output.{key}": value for key, value in outputs.items()})
    from microbiome.pipeline.models import validate_runtime_environment

    runtime_environment = {
        key: _render_string(value, context)
        for key, value in validate_runtime_environment(
            step.get("runtime_environment", {}), step["step_id"]
        ).items()
    }
    validate_runtime_environment(runtime_environment, step["step_id"])
    command = [_render_string(token, context) for token in step["command_template"]]
    if canonical_path(command[0], must_exist=True) != canonical_path(tool_lock["executable"], must_exist=True):
        raise ConfigurationError(f"step {step['step_id']}: command executable drifted from the tool lock")
    return {
        "step_id": step["step_id"],
        "command": command,
        "inputs": inputs,
        "outputs": outputs,
        "databases": database_paths,
        "threads": resources["threads"],
        "resources": resources,
        "runtime_environment": runtime_environment,
        "resource_environment": {
            "MICROBIOME_THREADS": str(resources["threads"]),
            "MICROBIOME_MEMORY_GB": str(resources["memory_gb"]),
            "MICROBIOME_GPU": str(resources["gpus"]),
            "OMP_NUM_THREADS": str(resources["threads"]),
            "OPENBLAS_NUM_THREADS": str(resources["threads"]),
            "MKL_NUM_THREADS": str(resources["threads"]),
            "NUMEXPR_NUM_THREADS": str(resources["threads"]),
            "RAYON_NUM_THREADS": str(resources["threads"]),
            **({"CUDA_VISIBLE_DEVICES": resources["gpu_devices"]} if resources["gpu_enabled"] else {}),
        },
        "working_directory": str(resolved_run),
        "environment_prefix": tool_lock.get("environment_prefix"),
        "runtime_launcher": list(tool_lock.get("runtime_launcher") or []),
        "runtime_launcher_fingerprint": tool_lock.get("runtime_launcher_fingerprint"),
        "tool_version": tool_lock.get("version_output", ""),
    }


def run_logged_command(
    rendered: dict[str, Any],
    log_path: str | Path,
    *,
    timeout_seconds: int | None = None,
    extra_environment: dict[str, str] | None = None,
    on_started: Callable[[dict[str, Any]], None] | None = None,
) -> dict[str, Any]:
    """Log before execution, run one argv directly (no shell), then finalize the log."""
    from microbiome.pipeline.resources import locked_tool_command, tool_environment

    command = locked_tool_command(list(rendered["command"]), rendered)
    cwd = canonical_path(rendered["working_directory"])
    cwd.mkdir(parents=True, exist_ok=True)
    log_target = canonical_path(log_path)
    stdout_path = log_target.with_suffix(".stdout.log")
    stderr_path = log_target.with_suffix(".stderr.log")
    record = {
        "timestamp": utcnow(),
        "status": "RUNNING",
        "working_directory": str(cwd),
        "environment_prefix": rendered.get("environment_prefix"),
        "executable": rendered["command"][0],
        "runtime_launcher": list(rendered.get("runtime_launcher") or []),
        "software_version": rendered.get("tool_version", ""),
        "argument_list": list(rendered["command"][1:]),
        "complete_command_argv": command,
        "input": rendered.get("inputs", {}),
        "output": rendered.get("outputs", {}),
        "database": rendered.get("databases", {}),
        "resources": rendered.get("resources", {}),
        "resource_environment": rendered.get("resource_environment", {}),
        "runtime_environment": rendered.get("runtime_environment", {}),
        "stdout_log": str(stdout_path),
        "stderr_log": str(stderr_path),
        "exit_code": None,
        "runtime_seconds": None,
    }
    write_json(log_target, record)
    if on_started:
        on_started(dict(record))
    environment = os.environ.copy()
    if extra_environment:
        environment.update({str(key): str(value) for key, value in extra_environment.items()})
    environment.update(rendered.get("resource_environment", {}))
    from microbiome.pipeline.models import validate_runtime_environment

    environment.update(validate_runtime_environment(
        rendered.get("runtime_environment", {}), rendered["step_id"]
    ))
    environment = tool_environment(rendered.get("environment_prefix"), environment)
    start = time.monotonic()
    try:
        result = subprocess.run(
            command,
            cwd=cwd,
            env=environment,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            check=False,
        )
        stdout = result.stdout
        stderr = result.stderr
        exit_code = result.returncode
        timed_out = False
    except subprocess.TimeoutExpired as exc:
        stdout = exc.stdout.decode(errors="replace") if isinstance(exc.stdout, bytes) else (exc.stdout or "")
        stderr = exc.stderr.decode(errors="replace") if isinstance(exc.stderr, bytes) else (exc.stderr or "")
        stderr += f"\ncommand timed out after {timeout_seconds} seconds"
        exit_code = 124
        timed_out = True
    except OSError as exc:
        stdout = ""
        stderr = str(exc)
        exit_code = 126
        timed_out = False
    runtime = time.monotonic() - start
    stdout_path.parent.mkdir(parents=True, exist_ok=True)
    stdout_path.write_text(stdout, encoding="utf-8")
    stderr_path.write_text(stderr, encoding="utf-8")
    record.update(
        {
            "status": "SUCCEEDED" if exit_code == 0 else "FAILED",
            "completed_at": utcnow(),
            "exit_code": exit_code,
            "runtime_seconds": round(runtime, 6),
            "timed_out": timed_out,
            "stdout": stdout[-20_000:],
            "stderr": stderr[-20_000:],
        }
    )
    write_json(log_target, record)
    return record


def _criterion_parts(criterion: str | dict[str, Any]) -> tuple[str, str, dict[str, Any]]:
    if isinstance(criterion, str):
        kind, separator, target = criterion.partition(":")
        if not separator:
            raise ConfigurationError(f"assertion must use '<type>:<target>': {criterion}")
        return kind.strip(), target.strip(), {}
    kind = str(criterion.get("type") or "")
    target = str(criterion.get("target") or "")
    if not kind or not target:
        raise ConfigurationError(f"assertion mapping requires type and target: {criterion}")
    return kind, target, criterion


def _target_path(target: str, rendered: dict[str, Any]) -> Path:
    namespace, separator, name = target.partition(".")
    if not separator or namespace not in {"input", "output", "database"}:
        raise ConfigurationError(f"assertion target must be input.*, output.*, or database.*: {target}")
    mapping_name = "databases" if namespace == "database" else f"{namespace}s"
    values = rendered.get(mapping_name, {})
    if name not in values:
        raise ConfigurationError(f"assertion target does not exist: {target}")
    return canonical_path(values[name])


def _parseable(path: Path, format_name: str | None = None) -> tuple[bool, str]:
    name = path.name.lower()
    selected = (format_name or "").lower()
    if not selected:
        selected = "fastq" if name.endswith((".fastq", ".fq", ".fastq.gz", ".fq.gz")) else ""
        selected = "fasta" if not selected and name.removesuffix(".gz").endswith((".fasta", ".fa", ".fna", ".faa")) else selected
        selected = "json" if not selected and name.endswith(".json") else selected
        selected = "yaml" if not selected and name.endswith((".yaml", ".yml")) else selected
        selected = "tsv" if not selected and name.endswith((".tsv", ".txt")) else selected
    try:
        if selected == "fastq":
            opener = gzip.open if name.endswith(".gz") else open
            with opener(path, "rt", encoding="utf-8") as handle:
                count = 0
                while True:
                    header = handle.readline()
                    if not header:
                        break
                    sequence, separator, quality = (handle.readline().rstrip("\r\n") for _ in range(3))
                    if not header.startswith("@") or not separator.startswith("+") or not sequence or len(sequence) != len(quality):
                        return False, f"invalid FASTQ record {count + 1}"
                    count += 1
            return count > 0, f"validated {count} complete FASTQ records"
        if selected == "fasta":
            opener = gzip.open if name.endswith(".gz") else open
            count, bases = 0, 0
            with opener(path, "rt", encoding="utf-8") as handle:
                for line in handle:
                    if not line.strip():
                        continue
                    if line.startswith(">"):
                        if count and not bases:
                            return False, "empty FASTA record"
                        count, bases = count + 1, 0
                    elif not count:
                        return False, "sequence before FASTA header"
                    else:
                        bases += len(line.strip())
            return count > 0 and bases > 0, f"validated {count} FASTA records"
        if selected == "json":
            with path.open(encoding="utf-8") as handle:
                json.load(handle)
            return True, "JSON parsed"
        if selected == "yaml":
            with path.open(encoding="utf-8") as handle:
                yaml.safe_load(handle)
            return True, "YAML parsed"
        if selected == "tsv":
            with path.open(encoding="utf-8", newline="") as handle:
                row = next(csv.reader(handle, delimiter="\t"), [])
            return bool(row), "TSV contains a row" if row else "TSV is empty"
        return False, f"no parser is registered for {path.name}; set assertion format explicitly"
    except (OSError, EOFError, ValueError, json.JSONDecodeError, yaml.YAMLError) as exc:
        return False, f"parse failed: {exc}"


def evaluate_assertions(criteria: list[Any], rendered: dict[str, Any]) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    for criterion in criteria:
        kind, target, options = _criterion_parts(criterion)
        path = _target_path(target, rendered)
        if kind == "exists":
            passed, detail = path.exists(), "path exists" if path.exists() else "path is missing"
        elif kind == "non_empty":
            if path.is_file():
                passed = path.stat().st_size > 0
                detail = f"file bytes={path.stat().st_size}"
            elif path.is_dir():
                files = [item for item in path.rglob("*") if item.is_file() and item.stat().st_size > 0]
                passed, detail = bool(files), f"non-empty files={len(files)}"
            else:
                passed, detail = False, "path is missing"
        elif kind == "parseable":
            passed, detail = _parseable(path, options.get("format")) if path.is_file() else (False, "not a file")
        elif kind == "glob_non_empty":
            pattern = str(options.get("pattern") or "*")
            matches = (
                [item for item in path.glob(pattern) if item.is_file() and item.stat().st_size > 0]
                if path.is_dir()
                else []
            )
            passed, detail = bool(matches), f"matching non-empty files={len(matches)}"
        elif kind in {"table_columns", "unique_column", "row_count"}:
            try:
                with path.open(encoding="utf-8", newline="") as handle:
                    reader = csv.DictReader(handle, delimiter=str(options.get("delimiter", "\t")))
                    columns = reader.fieldnames or []
                    rows = list(reader)
                if kind == "table_columns":
                    passed = set(options.get("columns", [])) <= set(columns) and bool(columns)
                elif kind == "unique_column":
                    values = [row.get(options["column"]) for row in rows]
                    passed = bool(values) and all(value is not None and value != "" for value in values) and len(set(values)) == len(values)
                else:
                    passed = int(options.get("min", 0)) <= len(rows) <= int(options.get("max", len(rows)))
                detail = f"columns={columns}, rows={len(rows)}"
            except (OSError, ValueError, KeyError) as error:
                passed, detail = False, str(error)
        else:
            raise ConfigurationError(f"unsupported output assertion type: {kind}")
        results.append({"type": kind, "target": target, "path": str(path), "passed": passed, "detail": detail})
    return results


_SCRIPT_TOKEN_RE = re.compile(r"\{(input|output|database)\.([A-Za-z][A-Za-z0-9_.-]*)\}")


def render_script_template(
    template: str,
    rendered: dict[str, Any],
    *,
    sample_id: str,
    temp_dir: str,
) -> str:
    """Substitute only known tokens in a synthesized script template.

    Literal braces that are not Microbiome tokens (shell variables, awk blocks,
    Python f-strings) pass through untouched; only a leftover Microbiome-scoped
    token indicates a template bug and fails loudly.
    """
    maps = {
        "input": rendered.get("inputs", {}),
        "output": rendered.get("outputs", {}),
        "database": rendered.get("databases", {}),
    }

    def replace(match: re.Match[str]) -> str:
        namespace, name = match.group(1), match.group(2)
        values = maps[namespace]
        if name not in values:
            raise ExecutionError(f"script template references an unknown {namespace} token: {name}")
        return str(values[name])

    text = _SCRIPT_TOKEN_RE.sub(replace, template)
    resources = rendered.get("resources", {})
    for token, value in (
        ("{run_dir}", rendered.get("working_directory", "")),
        ("{temp_dir}", temp_dir),
        ("{sample_id}", sample_id),
        ("{threads}", resources.get("threads", 1)),
        ("{memory_gb}", resources.get("memory_gb", 1)),
        ("{gpus}", resources.get("gpus", 0)),
    ):
        text = text.replace(token, str(value))
    return text


def materialize_script_step(
    step: dict[str, Any],
    rendered: dict[str, Any],
    *,
    sample_id: str,
    temp_dir: str | Path,
) -> None:
    """Write a synthesized step's script to its rendered path before execution."""
    template = step.get("script_template")
    if not template:
        return
    command = list(rendered.get("command") or [])
    if len(command) < 2:
        raise ExecutionError(f"step {step['step_id']}: script-mode command template is invalid")
    script_path = canonical_path(command[1])
    script_path.parent.mkdir(parents=True, exist_ok=True)
    text = render_script_template(template, rendered, sample_id=sample_id, temp_dir=str(temp_dir))
    atomic_write_text(script_path, text if text.endswith("\n") else text + "\n")
    script_path.chmod(0o755)
