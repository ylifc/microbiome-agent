"""Deterministic persistence and fingerprint helpers for frozen pipelines."""

from __future__ import annotations

import hashlib
import json
import os
import tempfile
from pathlib import Path
from typing import Any

import yaml


def canonical_path(value: str | os.PathLike[str], *, must_exist: bool = False) -> Path:
    """Return a canonical absolute path without changing the target."""
    path = Path(value).expanduser()
    return path.resolve(strict=must_exist)


def canonical_json(value: Any) -> str:
    """Serialize a JSON-compatible object in the form used for manifest hashes."""
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def object_fingerprint(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def manifest_fingerprint(value: dict[str, Any], field: str = "manifest_fingerprint") -> str:
    """Hash a manifest while excluding the field that stores its own hash."""
    payload = {key: item for key, item in value.items() if key != field}
    return object_fingerprint(payload)


def atomic_write_text(path: str | Path, text: str) -> None:
    """Atomically replace one file, without exposing a partially written manifest."""
    target = canonical_path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=f".{target.name}.", dir=target.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, target)
    except BaseException:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


def write_json(path: str | Path, value: Any) -> None:
    atomic_write_text(path, json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n")


def write_yaml(path: str | Path, value: Any) -> None:
    atomic_write_text(path, yaml.safe_dump(value, allow_unicode=True, sort_keys=False))


def read_json(path: str | Path) -> Any:
    with canonical_path(path, must_exist=True).open(encoding="utf-8") as handle:
        return json.load(handle)


def read_yaml(path: str | Path) -> Any:
    with canonical_path(path, must_exist=True).open(encoding="utf-8") as handle:
        return yaml.safe_load(handle)


def fast_file_fingerprint(path: str | Path, chunk_size: int = 1 << 20) -> dict[str, Any]:
    """Fingerprint large inputs without hashing an entire multi-gigabyte FASTQ.

    The digest covers file size plus the first and last MiB. It is designed for
    drift/checkpoint detection, not for adversarial integrity verification.
    """
    target = canonical_path(path, must_exist=True)
    stat = target.stat()
    digest = hashlib.sha256()
    digest.update(str(stat.st_size).encode("ascii"))
    with target.open("rb") as handle:
        digest.update(handle.read(chunk_size))
        if stat.st_size > chunk_size:
            handle.seek(max(0, stat.st_size - chunk_size))
            digest.update(handle.read(chunk_size))
    return {
        "path": str(target),
        "bytes": stat.st_size,
        "mtime_ns": stat.st_mtime_ns,
        "sha256_head_tail": digest.hexdigest(),
    }


def path_fingerprint(path: str | Path) -> dict[str, Any]:
    """Return a stable file or directory fingerprint for locks/checkpoints."""
    target = canonical_path(path, must_exist=True)
    if target.is_file():
        return {"kind": "file", **fast_file_fingerprint(target)}
    if not target.is_dir():
        raise ValueError(f"unsupported path type for fingerprinting: {target}")
    entries: list[dict[str, Any]] = []
    total = 0
    for child in sorted((item for item in target.rglob("*") if item.is_file()), key=lambda item: str(item)):
        stat = child.stat()
        total += stat.st_size
        entries.append(
            {
                "relative_path": str(child.relative_to(target)),
                "bytes": stat.st_size,
                "mtime_ns": stat.st_mtime_ns,
            }
        )
    return {
        "kind": "directory",
        "path": str(target),
        "bytes": total,
        "files": len(entries),
        "tree_sha256": object_fingerprint(entries),
    }


def fingerprint_existing_paths(values: dict[str, str]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for name, value in sorted(values.items()):
        path = canonical_path(value)
        result[name] = path_fingerprint(path) if path.exists() else {"path": str(path), "missing": True}
    return result
