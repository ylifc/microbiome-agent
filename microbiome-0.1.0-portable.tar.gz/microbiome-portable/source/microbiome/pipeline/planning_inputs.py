"""Require conversational plans to consume the sampled runtime input bindings."""

from __future__ import annotations

import re
from pathlib import Path

from microbiome.pipeline.errors import ConfigurationError


def validate_conversation_input_bindings(plan, manifest, project):
    """Reject literal declared samples without rejecting unrelated static references.

    The generic pipeline schema permits static inputs. A conversational pilot
    has a stronger contract: raw samples must be supplied through runtime
    bindings, so the same command receives subsets during validation and the
    complete sample during production. This is a read-only boundary check.
    """
    paths = project.load_config()["paths"]
    raw = Path(paths["raw_data"]).resolve()
    protected = {raw, (project.requirements_dir / "input_manifest.yaml").resolve()}
    for sample in manifest["samples"]:
        for role in ("r1", "r2", "fasta"):
            value = sample.get(role)
            value = value.get("path") if isinstance(value, dict) else value
            if value:
                path = Path(value).expanduser()
                protected.add((path if path.is_absolute() else raw / path).resolve())
    source_manifest = manifest.get("manifest_path") or (manifest.get("source_manifest") or {}).get("path")
    if source_manifest:
        path = Path(source_manifest).expanduser()
        protected.add((path if path.is_absolute() else raw / path).resolve())
    identities = set()
    for path in protected:
        if path.is_file():
            stat = path.stat()
            identities.add((stat.st_dev, stat.st_ino))

    def strings(value, location):
        if isinstance(value, str):
            yield location, value
        elif isinstance(value, dict):
            for key, item in value.items():
                yield from strings(item, f"{location}.{key}")
        elif isinstance(value, list):
            for index, item in enumerate(value):
                yield from strings(item, f"{location}[{index}]")

    def is_protected(value):
        # Expand only real project facts; runtime/step references remain bound
        # by the executor. Resolve aliases so symlinks cannot bypass this check.
        for key, field in (("raw_data_path", "raw_data"), ("database_root", "database"),
                           ("output_root", "output")):
            value = value.replace("{" + key + "}", str(paths[field]))
        variants = [value]
        if "{sample_id}" in value:
            variants = [value.replace("{sample_id}", row["sample_id"]) for row in manifest["samples"]]
        for variant in variants:
            candidates = [variant, variant.partition("=")[2], *re.split(r"[\s,;=\"']+", variant)]
            for candidate in candidates:
                if not candidate or "{" in candidate or "}" in candidate or "\x00" in candidate:
                    continue
                path = Path(candidate).expanduser()
                try:
                    resolved_paths = [path.resolve()]
                    if candidate not in {".", ".."}:
                        resolved_paths.append((raw / path).resolve())
                except (OSError, RuntimeError):
                    continue
                for resolved in resolved_paths:
                    if resolved in protected:
                        return True
                    try:
                        if resolved.is_file():
                            stat = resolved.stat()
                            if (stat.st_dev, stat.st_ino) in identities:
                                return True
                    except OSError:
                        # A long non-path command argument is not a file input.
                        continue
        return False

    for step in plan["steps"]:
        for field in ("input", "command_template", "parameters", "database"):
            for location, value in strings(step.get(field, {}), field):
                if is_protected(value):
                    raise ConfigurationError(
                        f"step {step['step_id']}: {location} statically references a declared raw sample, "
                        "raw-data directory or input manifest and would bypass the 5%–10% pilot. "
                        "Bind sample inputs with {runtime.reads}, {runtime.reads_1}, {runtime.reads_2}, "
                        "{runtime.fasta}, or the corresponding cohort runtime placeholders; keep "
                        "only non-sample reference/configuration files as static inputs."
                    )
    return plan
