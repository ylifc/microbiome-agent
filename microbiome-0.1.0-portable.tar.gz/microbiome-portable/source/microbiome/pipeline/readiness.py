"""Production readiness checks between freeze and the user-approval gate.

``AWAITING_PRODUCTION_APPROVAL`` may only be entered from ``PRODUCTION_READY``,
and ``PRODUCTION_READY`` is only reached when every check here passes. The
input-binding check is a dry run: it resolves the persisted manifest when
available, otherwise verifies the pruned frozen RAW inventory, and never
executes a tool.
"""

from __future__ import annotations

import os
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from microbiome.pipeline.errors import ConfigurationError, PipelineError
from microbiome.pipeline.io import manifest_fingerprint, object_fingerprint, read_json, read_yaml, write_json
from microbiome.pipeline.ledger import ExecutionLedger
from microbiome.pipeline.lifecycle import load_plan
from microbiome.pipeline.lock_schema import validate_pipeline_lock
from microbiome.pipeline.state import LifecycleState, ProjectStateMachine

if TYPE_CHECKING:
    from microbiome.pipeline.project import PipelineProject

READINESS_PATH_NAME = "production_readiness.json"

_LIFECYCLE_ALLOWED = {
    LifecycleState.FROZEN,
    LifecycleState.PIPELINE_LOCK_VALIDATING,
    LifecycleState.PRODUCTION_READY,
    LifecycleState.AWAITING_PRODUCTION_APPROVAL,
}


def _utcnow() -> str:
    return datetime.now(UTC).isoformat()


def load_current_readiness(project: PipelineProject, pipeline: dict[str, Any]) -> dict[str, Any]:
    """Load the stored readiness report and require it to match the live lock."""
    path = project.pipeline_dir / READINESS_PATH_NAME
    if not path.is_file():
        raise ConfigurationError("production readiness has never been established: run pre-test finalization first")
    report = read_json(path)
    if not report.get("ready"):
        raise ConfigurationError("production readiness check did not pass; approval is not allowed")
    if report.get("pipeline_hash") != pipeline.get("pipeline_hash"):
        raise ConfigurationError(
            "production readiness report is stale for the current pipeline lock; rerun finalization"
        )
    expected = object_fingerprint({key: value for key, value in report.items() if key != "report_fingerprint"})
    if report.get("report_fingerprint") != expected:
        raise ConfigurationError("production readiness report fingerprint is invalid")
    return report


class ProductionReadinessChecker:
    """Verify every artifact a production dispatch will rely on."""

    def __init__(self, project: PipelineProject):
        self.project = project

    def check(self, *, write_report: bool = True) -> dict[str, Any]:
        areas: dict[str, dict[str, Any]] = {}
        missing: list[str] = []
        metadata_warnings: list[str] = []

        def record(
            area: str,
            ok: bool,
            detail: str,
            *,
            missing_label: str | None = None,
            blocking: bool = True,
        ) -> None:
            """Record one area; only blocking execution facts can fail readiness.

            Derived reports may be recovered from verified records. Requirements
            and explicit approvals are independently required authorization facts;
            their absence or drift is always a blocking failure.
            """
            if ok:
                areas[area] = {"status": "PASSED", "detail": detail}
            elif blocking:
                areas[area] = {"status": "FAILED", "detail": detail}
                missing.append(missing_label or f"{area}: {detail}")
            else:
                areas[area] = {"status": "WARNING", "detail": detail}
                metadata_warnings.append(missing_label or f"{area}: {detail}")

        pipeline: dict[str, Any] | None = None
        if not self.project.pipeline_lock_path.is_file():
            record(
                "pipeline_lock",
                False,
                f"missing: {self.project.pipeline_lock_path}",
                missing_label="pipeline.lock.yaml",
            )
        else:
            try:
                pipeline = validate_pipeline_lock(read_yaml(self.project.pipeline_lock_path))
                record("pipeline_lock", True, "lock reloaded and passed schema/fingerprint validation")
            except PipelineError as exc:
                record("pipeline_lock", False, str(exc), missing_label="valid pipeline.lock.yaml")

        current = None
        try:
            current = ProjectStateMachine(self.project).current
            record("lifecycle_state", current in _LIFECYCLE_ALLOWED, f"current state {current.value}")
        except PipelineError as exc:
            record("lifecycle_state", False, str(exc), missing_label="project_state.yaml")

        plan = None
        if pipeline is not None:
            try:
                plan = load_plan(self.project)
                ok = plan["plan_fingerprint"] == pipeline["plan_fingerprint"]
                record(
                    "experiment_plan",
                    ok,
                    "plan fingerprint matches the lock" if ok else "plan fingerprint drifted",
                    missing_label="experiment_plan.yaml (auto-backfillable metadata)",
                    blocking=False,
                )
            except (PipelineError, OSError) as exc:
                record(
                    "experiment_plan",
                    False,
                    str(exc),
                    missing_label="experiment_plan.yaml (auto-backfillable metadata)",
                    blocking=False,
                )

        requirements = None
        try:
            from microbiome.pipeline.requirements import RequirementManager

            requirements = RequirementManager(self.project).require_confirmed()
            if pipeline is not None:
                ok = requirements["requirements_fingerprint"] == pipeline["requirements_fingerprint"]
                record(
                    "requirements",
                    ok,
                    "requirements fingerprint matches the lock" if ok else "requirements drifted",
                    missing_label="requirements/requirements.yaml (explicit confirmation required)",
                    blocking=True,
                )
            else:
                record("requirements", True, "requirements confirmed")
        except PipelineError as exc:
            record(
                "requirements",
                False,
                str(exc),
                missing_label="requirements/requirements.yaml (explicit confirmation required)",
                blocking=True,
            )

        self._check_approvals(pipeline, plan, requirements, record)
        self._check_phase_reports(pipeline, plan, requirements, record)
        self._check_lock_manifests(pipeline, record)
        if pipeline is not None:
            self._check_steps(pipeline, record)
            self._check_ledger(pipeline, record)
            self._check_input_binding(pipeline, record)

        ready = bool(areas) and not any(area["status"] == "FAILED" for area in areas.values())
        report = {
            "schema_version": 1,
            "checked_at": _utcnow(),
            "ready": ready,
            "pipeline_version": (pipeline or {}).get("pipeline_version"),
            "pipeline_hash": (pipeline or {}).get("pipeline_hash"),
            "lifecycle_state": current.value if current else None,
            "areas": areas,
            "missing_artifacts": missing,
            "metadata_warnings": metadata_warnings,
        }
        report["report_fingerprint"] = object_fingerprint(report)
        if write_report:
            write_json(self.project.pipeline_dir / READINESS_PATH_NAME, report)
        return report

    def _check_approvals(self, pipeline, plan, requirements, record) -> None:
        if pipeline is None or requirements is None:
            return
        from microbiome.pipeline.requirements import ConfirmationAction

        approvals = requirements.get("approvals", {})
        for name, label in (
            ("analysis_plan", "requirements approval: analysis_plan"),
            ("dependencies", "dependency approval"),
        ):
            approval = approvals.get(name) or {}
            ok = (
                approval.get("status") == ConfirmationAction.CONFIRM.value
                and approval.get("requirements_version") == requirements["requirements_version"]
                and approval.get("plan_fingerprint") == pipeline["plan_fingerprint"]
                and approval.get("source") != "auto_backfilled_from_successful_pretest"
            )
            record(
                f"approval.{name}",
                ok,
                "explicit approval bound to the current plan" if ok else "missing or stale explicit approval",
                missing_label=f"{label} (explicit confirmation required)",
                blocking=True,
            )
        gap_report = self.project.plans_dir / "dependency_gap_report.yaml"
        if not gap_report.is_file():
            record(
                "dependency_report",
                False,
                f"missing: {gap_report}",
                missing_label="plans/dependency_gap_report.yaml (auto-backfillable metadata)",
                blocking=False,
            )
        elif plan is not None:
            report = read_yaml(gap_report)
            ok = isinstance(report, dict) and report.get("plan_fingerprint") == plan["plan_fingerprint"]
            record(
                "dependency_report",
                ok,
                "dependency gap report matches the current plan" if ok else "dependency gap report is stale",
                missing_label="plans/dependency_gap_report.yaml (auto-backfillable metadata)",
                blocking=False,
            )

    def _check_phase_reports(self, pipeline, plan, requirements, record) -> None:
        if pipeline is None or plan is None or requirements is None:
            return
        for filename, label in (
            ("bootstrap_report.json", "state/bootstrap_report.json"),
            ("database_resolution.json", "state/database_resolution.json"),
        ):
            path = self.project.state_dir / filename
            if not path.is_file():
                record(
                    f"phase_report.{filename}",
                    False,
                    f"missing: {path}",
                    missing_label=f"{label} (auto-backfillable metadata)",
                    blocking=False,
                )
                continue
            report = read_json(path)
            ok = (
                report.get("status") == "PASSED"
                and report.get("plan_fingerprint") == plan["plan_fingerprint"]
                and report.get("requirements_version") == requirements["requirements_version"]
            )
            record(
                f"phase_report.{filename}",
                ok,
                "phase report PASSED and current" if ok else "phase report failed or stale",
                missing_label=f"{label} (explicit confirmation required)",
                blocking=True,
            )

    def _check_lock_manifests(self, pipeline, record) -> None:
        if pipeline is None:
            return
        for path, field, label in (
            (self.project.toolchain_lock_path, "toolchain_lock_fingerprint", "toolchain.lock.yaml"),
            (self.project.database_lock_path, "database_lock_fingerprint", "database.lock.yaml"),
        ):
            if not path.is_file():
                record(f"lock_manifest.{label}", False, f"missing: {path}", missing_label=label)
                continue
            manifest = read_yaml(path)
            ok = (
                isinstance(manifest, dict)
                and manifest.get("manifest_fingerprint") == manifest_fingerprint(manifest)
                and manifest.get("manifest_fingerprint") == pipeline.get(field)
            )
            record(
                f"lock_manifest.{label}",
                ok,
                "manifest fingerprint chain intact" if ok else "manifest fingerprint mismatch",
                missing_label=None if ok else label,
            )

    def _database_path_errors(self, pipeline) -> list[str]:
        """Verify exact consumer entries using only the authenticated frozen lock."""
        from microbiome.pipeline.execution import FrozenPipelineExecutor
        from microbiome.pipeline.io import canonical_path
        from microbiome.resource_skills.contracts import valid_entrypoint

        steps = pipeline.get("steps", [])
        if not any(step.get("database_path") for step in steps):
            return []
        try:
            manifest = read_yaml(self.project.database_lock_path)
            if (not isinstance(manifest, dict)
                    or manifest.get("manifest_fingerprint") != manifest_fingerprint(manifest)
                    or manifest.get("manifest_fingerprint") != pipeline.get("database_lock_fingerprint")
                    or not isinstance(manifest.get("databases"), dict)):
                raise ConfigurationError("database lock fingerprint chain is invalid")
        except (PipelineError, OSError) as exc:
            return [f"database.lock.yaml: {exc}"]

        errors = []
        verified: dict[str, str | None] = {}
        for step in steps:
            for alias, value in (step.get("database_path") or {}).items():
                try:
                    spec = (step.get("database") or {}).get(alias)
                    if not isinstance(spec, dict):
                        raise ConfigurationError("database alias has no frozen declaration")
                    name = str(spec.get("logical_name") or alias)
                    entry = manifest["databases"].get(name)
                    if not isinstance(entry, dict) or entry.get("status") != "READY":
                        raise ConfigurationError(f"database is not locked READY: {name}")
                    consumer = step.get("tool")
                    entrypoints = entry.get("consumer_entrypoints") or {}
                    expected = entrypoints.get(consumer, entry.get("runtime_entry") or entry.get("path"))
                    if not expected or canonical_path(value) != canonical_path(expected):
                        raise ConfigurationError("database path differs from the frozen consumer entrypoint")
                    kind = entry.get("runtime_kind", "existing")
                    suffixes = entry.get("runtime_suffix_sets", [])
                    if consumer in entrypoints:
                        kind = (entry.get("consumer_entrypoint_kinds") or {}).get(consumer, "existing")
                        suffixes = (entry.get("consumer_suffix_sets") or {}).get(consumer)
                    if not valid_entrypoint(value, kind, suffixes):
                        raise ConfigurationError("frozen database entrypoint is missing, empty or incomplete")
                    # Many sample steps share a resource. Validate its fingerprint
                    # and every consumer contract once per readiness check.
                    if name not in verified:
                        try:
                            FrozenPipelineExecutor._verify_database(entry, steps)
                            verified[name] = None
                        except (PipelineError, OSError) as exc:
                            verified[name] = str(exc)
                    if verified[name] is not None:
                        raise ConfigurationError(verified[name])
                except (PipelineError, OSError) as exc:
                    errors.append(f"{step.get('step_id')}.{alias}: {value}: {exc}")
        return errors

    def _check_steps(self, pipeline, record) -> None:
        bad_executables = []
        bad_prefixes = []
        bad_databases = self._database_path_errors(pipeline)
        bad_outputs = []
        pretest = self.project.pretest_dir.resolve()
        for step in pipeline.get("steps", []):
            executable = Path(str(step.get("absolute_executable") or ""))
            if not executable.is_file() or not os.access(executable, os.X_OK):
                bad_executables.append(f"{step.get('step_id')}: {executable}")
            prefix = step.get("environment_prefix")
            if prefix is not None and not Path(str(prefix)).is_dir():
                bad_prefixes.append(f"{step.get('step_id')}: {prefix}")
            for name, template in (step.get("output_template") or {}).items():
                if str(pretest) in str(template):
                    bad_outputs.append(f"{step.get('step_id')}.{name}")
        record(
            "executables",
            not bad_executables,
            "all frozen executables exist"
            if not bad_executables
            else "missing executables: " + "; ".join(bad_executables),
        )
        record(
            "environment_prefixes",
            not bad_prefixes,
            "all environment prefixes exist"
            if not bad_prefixes
            else "missing environment prefixes: " + "; ".join(bad_prefixes),
        )
        record(
            "database_paths",
            not bad_databases,
            "all frozen database entrypoints and resource fingerprints match"
            if not bad_databases
            else "invalid database paths: " + "; ".join(bad_databases),
        )
        record(
            "output_contract",
            not bad_outputs,
            "output templates are run-dir based"
            if not bad_outputs
            else "outputs point into pre_test_run: " + "; ".join(bad_outputs),
        )

    def _check_ledger(self, pipeline, record) -> None:
        ledger_ref = pipeline.get("execution_ledger") or {}
        ledger = ExecutionLedger(
            ledger_ref.get("path") or (self.project.pretest_dir / "pipeline" / "execution_ledger.jsonl")
        )
        if not ledger.path.is_file():
            record(
                "execution_ledger",
                False,
                f"missing: {ledger.path}",
                missing_label="pre_test_run/pipeline/execution_ledger.jsonl",
            )
            return
        digest = ledger.digest()
        if ledger_ref.get("sha256") and digest != ledger_ref["sha256"]:
            record("execution_ledger", False, "ledger drifted after freeze", missing_label="execution ledger (drifted)")
            return
        successful = {entry.get("step_id") for entry in ledger.final_successful_attempts()}
        verified_record_ids = {
            entry.get("record_id")
            for entry in ledger.entries()
            if entry.get("status") == "PASSED" and entry.get("verified")
        }
        missing_steps = []
        for step in pipeline.get("steps", []):
            lineage = step.get("validation") or {}
            record_id = lineage.get("ledger_record_id")
            if record_id is not None:
                if record_id not in verified_record_ids:
                    missing_steps.append(step["step_id"])
            elif step["step_id"] not in successful:
                missing_steps.append(step["step_id"])
        record(
            "execution_ledger",
            not missing_steps,
            "every frozen step has a verified successful attempt"
            if not missing_steps
            else "no verified attempt for: " + ", ".join(missing_steps),
        )

    def _check_input_binding(self, pipeline, record) -> None:
        from microbiome.pipeline.errors import InputErrorCategory

        try:
            from microbiome.pipeline.inputs import ProductionInputResolver

            resolver = ProductionInputResolver(self.project, pipeline)
            jobs = resolver.full_dataset_bindings()
            ok = bool(jobs)
            input_source = str(resolver.contract.get("input_source") or "LEGACY_CONTRACT")
            detail = (
                f"dry binding resolved {len(jobs)} production job(s) from {input_source}; "
                f"pruned {len(resolver.excluded_roots)} configured output/database root(s); "
                "without executing any tool; no tool was executed"
                if ok
                else "no production jobs resolved from the persisted input manifest"
            )
            record(
                "input_binding",
                ok,
                detail,
                missing_label=None if ok else InputErrorCategory.INPUT_BINDING_ERROR.value,
            )
        except PipelineError as exc:
            message = str(exc)
            record(
                "input_binding",
                False,
                message,
                missing_label=f"{InputErrorCategory.INPUT_BINDING_ERROR.value}: {message}",
            )
