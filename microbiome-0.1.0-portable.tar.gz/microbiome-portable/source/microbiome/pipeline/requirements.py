"""Versioned, append-only persistence for user-confirmed analysis requirements."""

from __future__ import annotations

import json
import os
import uuid
from datetime import UTC, datetime
from enum import StrEnum
from typing import TYPE_CHECKING, Any

from microbiome.pipeline.errors import ConfigurationError
from microbiome.pipeline.io import atomic_write_text, object_fingerprint, read_yaml, write_yaml
from microbiome.pipeline.state import LifecycleState, ProjectStateMachine

if TYPE_CHECKING:
    from microbiome.pipeline.project import PipelineProject


class ConfirmationAction(StrEnum):
    CONFIRM = "CONFIRM"
    MODIFY = "MODIFY"
    CANCEL = "CANCEL"


REQUIRED_TOPICS = ("paths", "input", "dataset", "target", "analysis_goal")
EDITABLE_TOPICS = ("input", "dataset", "target", "analysis_goal")


def _utcnow() -> str:
    return datetime.now(UTC).isoformat()


class RequirementManager:
    """Keep requirements authoritative across conversations and context compaction."""

    def __init__(self, project: PipelineProject):
        self.project = project
        self.path = project.requirements_path
        self.log_path = project.decision_log_path
        self.summary_path = project.conversation_summary_path

    @staticmethod
    def _fingerprint(value: dict[str, Any]) -> str:
        return object_fingerprint({key: item for key, item in value.items() if key != "requirements_fingerprint"})

    def initialize(self) -> dict[str, Any]:
        if self.path.is_file():
            return self.load()
        config = self.project.load_config()
        paths = config["paths"]
        now = _utcnow()
        value = {
            "schema_version": 1,
            "requirements_version": 1,
            "paths": {
                "raw_data": paths["raw_data"],
                "database_root": paths["database"],
                "output_root": paths["output"],
            },
            "input": {},
            "dataset": {},
            "target": {},
            "analysis_goal": {},
            "confirmed_fields": {
                "paths": bool(paths.get("confirmed_by_user", True)),
                "input": False,
                "dataset": False,
                "target": False,
                "analysis_goal": False,
            },
            "unresolved_questions": ["input", "dataset", "target", "analysis_goal"],
            "approvals": {},
            "last_updated": now,
        }
        value["requirements_fingerprint"] = self._fingerprint(value)
        write_yaml(self.path, value)
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self.log_path.touch(exist_ok=True)
        self._write_summary(value)
        self._append_decision(
            topic="paths",
            previous_value=None,
            new_value=value["paths"],
            action=ConfirmationAction.CONFIRM,
            confirmed_by_user=value["confirmed_fields"]["paths"],
            requirements_version=1,
        )
        return value

    def load(self) -> dict[str, Any]:
        if not self.path.is_file():
            raise ConfigurationError(f"requirements are missing: {self.path}")
        value = read_yaml(self.path)
        if not isinstance(value, dict) or value.get("schema_version") != 1:
            raise ConfigurationError(f"invalid requirements file: {self.path}")
        if value.get("requirements_fingerprint") != self._fingerprint(value):
            raise ConfigurationError(f"requirements fingerprint is invalid: {self.path}")
        if not isinstance(value.get("confirmed_fields"), dict):
            raise ConfigurationError("requirements.confirmed_fields must be a mapping")
        return value

    def _append_decision(
        self,
        *,
        topic: str,
        previous_value: Any,
        new_value: Any,
        action: ConfirmationAction,
        confirmed_by_user: bool,
        requirements_version: int,
        decision_source: dict[str, Any] | None = None,
    ) -> None:
        record = {
            "timestamp": _utcnow(),
            "decision_id": str(uuid.uuid4()),
            "topic": topic,
            "action": action.value,
            "previous_value": previous_value,
            "new_value": new_value,
            "confirmed_by_user": confirmed_by_user,
            "requirements_version": requirements_version,
        }
        if decision_source is not None:
            record["source"] = decision_source
        descriptor = os.open(self.log_path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o644)
        try:
            os.write(descriptor, (json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n").encode("utf-8"))
            os.fsync(descriptor)
        finally:
            os.close(descriptor)

    def _write_summary(self, value: dict[str, Any], note: str | None = None) -> None:
        confirmed = [name for name, ready in value["confirmed_fields"].items() if ready]
        unresolved = value.get("unresolved_questions", [])
        lines = [
            "# Conversation and requirement summary",
            "",
            f"- Requirements version: {value['requirements_version']}",
            f"- Confirmed fields: {', '.join(confirmed) or 'none'}",
            f"- Unresolved fields: {', '.join(unresolved) or 'none'}",
            f"- Last updated: {value['last_updated']}",
            "",
            "This file is a compact view. `requirements.yaml` and `decision_log.jsonl` are authoritative.",
        ]
        if note:
            lines.extend(["", "## Latest conversation note", "", note.strip()])
        atomic_write_text(self.summary_path, "\n".join(lines) + "\n")

    def save_conversation_summary(self, summary: str) -> None:
        if not isinstance(summary, str) or not summary.strip():
            raise ConfigurationError("conversation summary cannot be empty")
        self._write_summary(self.load(), summary)

    def decide(
        self,
        topic: str,
        value: dict[str, Any] | None,
        *,
        action: ConfirmationAction,
        conversation_summary: str | None = None,
        decision_source: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        if topic not in EDITABLE_TOPICS:
            raise ConfigurationError(f"unsupported requirement topic: {topic}")
        current = self.load()
        if action is ConfirmationAction.CANCEL:
            self._append_decision(
                topic=topic,
                previous_value=current.get(topic),
                new_value=None,
                action=action,
                confirmed_by_user=decision_source is None,
                requirements_version=current["requirements_version"],
                decision_source=decision_source,
            )
            ProjectStateMachine(self.project).transition(LifecycleState.CANCELLED, reason=f"user cancelled at {topic}")
            return current
        if not isinstance(value, dict) or not value:
            raise ConfigurationError(f"{topic} requires a non-empty JSON/YAML object")

        previous_value = current.get(topic, {})
        previous_confirmation = bool(current["confirmed_fields"].get(topic))
        confirmed = action is ConfirmationAction.CONFIRM
        changed = previous_value != value or previous_confirmation != confirmed
        if not changed:
            return current

        current["requirements_version"] = int(current.get("requirements_version", 0)) + 1
        current[topic] = value
        current["confirmed_fields"][topic] = confirmed
        current["unresolved_questions"] = [
            name for name in EDITABLE_TOPICS if not current["confirmed_fields"].get(name)
        ]
        current["approvals"] = {}
        current["last_updated"] = _utcnow()
        current["requirements_fingerprint"] = self._fingerprint(current)
        write_yaml(self.path, current)
        self._append_decision(
            topic=topic,
            previous_value=previous_value,
            new_value=value,
            action=action,
            confirmed_by_user=confirmed and decision_source is None,
            requirements_version=current["requirements_version"],
            decision_source=decision_source,
        )
        self._write_summary(current, conversation_summary)

        machine = ProjectStateMachine(self.project)
        machine.invalidate_for_requirements(
            current["requirements_version"],
            reason=f"requirement {topic} was {action.value.lower()}",
        )
        if self.ready_for_planning(current):
            machine.mark_requirements_confirmed(current["requirements_version"])
        return current

    @staticmethod
    def ready_for_planning(value: dict[str, Any]) -> bool:
        confirmed = value.get("confirmed_fields", {})
        return all(confirmed.get(topic) is True for topic in REQUIRED_TOPICS)

    def require_confirmed(self) -> dict[str, Any]:
        value = self.load()
        if not self.ready_for_planning(value):
            unresolved = [topic for topic in REQUIRED_TOPICS if not value["confirmed_fields"].get(topic)]
            raise ConfigurationError(
                "analysis design is blocked until requirements are confirmed: " + ", ".join(unresolved)
            )
        return value

    def check_discovery_compatibility(self, inventory: dict[str, Any]) -> None:
        value = self.load()
        if not value["confirmed_fields"].get("input"):
            return
        confirmed_type = value.get("input", {}).get("type")
        observed_type = inventory.get("raw_data", {}).get("detected_input_type")
        if confirmed_type and observed_type and confirmed_type != observed_type:
            raise ConfigurationError(
                f"confirmed input type {confirmed_type!r} conflicts with automatic discovery {observed_type!r}; "
                "use MODIFY/CONFIRM before planning"
            )

    def set_approval(self, name: str, payload: dict[str, Any]) -> dict[str, Any]:
        value = self.load()
        value.setdefault("approvals", {})[name] = payload
        value["last_updated"] = _utcnow()
        value["requirements_fingerprint"] = self._fingerprint(value)
        write_yaml(self.path, value)
        self._write_summary(value)
        return value
