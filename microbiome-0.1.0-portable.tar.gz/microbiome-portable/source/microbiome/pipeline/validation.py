"""Complete deterministic small-scale pipeline validation."""

from __future__ import annotations

import json
import re
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from microbiome.pipeline.commands import evaluate_assertions, render_step, run_logged_command
from microbiome.pipeline.diagnostics import failure_record
from microbiome.pipeline.errors import ConfigurationError, ResourceNotReadyError
from microbiome.pipeline.io import (
    canonical_path,
    fast_file_fingerprint,
    fingerprint_existing_paths,
    object_fingerprint,
    path_fingerprint,
    read_json,
    read_yaml,
    write_json,
    write_yaml,
)
from microbiome.pipeline.lifecycle import load_plan
from microbiome.pipeline.models import PipelinePhase, topological_step_ids
from microbiome.resource_config import get_config
from microbiome.tool.workflow_validation import create_sequence_pilot_dataset

if TYPE_CHECKING:
    from pathlib import Path

    from microbiome.pipeline.project import PipelineProject

SEQUENCE_SUFFIX_RE = re.compile(r"\.(?:fastq|fq|fasta|fa|fna|faa)(?:\.gz)?$", re.IGNORECASE)


def _utcnow() -> str:
    return datetime.now(UTC).isoformat()


def _load_phase_report(
    path: Path,
    plan_fingerprint: str,
    requirements_version: int,
    name: str,
) -> dict[str, Any]:
    if not path.is_file():
        raise ResourceNotReadyError(f"{name} has not run: {path}")
    report = read_json(path)
    if report.get("status") != "PASSED":
        raise ResourceNotReadyError(f"{name} did not pass")
    if report.get("plan_fingerprint") != plan_fingerprint:
        raise ResourceNotReadyError(f"{name} is stale because experiment_plan.yaml changed")
    if report.get("requirements_version") != requirements_version:
        raise ResourceNotReadyError(f"{name} is stale because requirements.yaml changed")
    return report


def _pilot_runtime_inputs(
    runtime_inputs: dict[str, str],
    validation_input_dir: Path,
    *,
    max_records: int | None,
    fraction: float,
    seed: int,
    max_subset_bytes: int,
    cohort_members: list | None = None,
) -> tuple[dict[str, str], dict[str, Any]]:
    if cohort_members:
        replacements, outputs = {}, []
        for member in cohort_members:
            names = list(member["runtime"].values())
            subset, payload = _pilot_runtime_inputs(
                {key: runtime_inputs[key] for key in names}, validation_input_dir / member["prefix"],
                max_records=max_records, fraction=fraction, seed=seed,
                max_subset_bytes=max(1, max_subset_bytes // len(cohort_members)))
            replacements.update(subset)
            outputs.extend(payload["outputs"])
        for key, value in runtime_inputs.items():
            replacements.setdefault(key, value)
        return replacements, {"outputs": outputs, "cohort_members": cohort_members,
                              "fraction": fraction, "seed": seed, "paired_sampling": "within each sample"}
    sequence_names = [name for name, value in runtime_inputs.items() if SEQUENCE_SUFFIX_RE.search(str(value))]
    if not sequence_names:
        raise ConfigurationError("validation runtime inputs must include at least one FASTA/FASTQ sequencing file")
    sequence_paths = [str(canonical_path(runtime_inputs[name], must_exist=True)) for name in sequence_names]
    payload = json.loads(
        create_sequence_pilot_dataset(
            sequence_paths,
            str(validation_input_dir),
            max_records=max_records,
            fraction=fraction,
            seed=seed,
            max_subset_bytes=max_subset_bytes,
        )
    )
    replacements = {name: payload["outputs"][index]["pilot"] for index, name in enumerate(sequence_names)}
    for name, value in runtime_inputs.items():
        if name not in replacements:
            path = canonical_path(value, must_exist=True)
            replacements[name] = str(path)
    return replacements, payload


def _write_source_mapping(
    inputs_root: Path,
    runtime_inputs: dict[str, str],
    pilot_inputs: dict[str, str],
    *,
    fraction: float,
    sample_id: str,
    cohort_members: list | None = None,
) -> Path:
    """Persist the subset -> full-source lineage for later production binding.

    Production must bind full samples from the input manifest, never by
    reverse-engineering the subset files. This mapping makes the relationship
    explicit and permanent at sampling time.
    """
    sequence_keys = [name for name, value in runtime_inputs.items() if SEQUENCE_SUFFIX_RE.search(str(value))]

    def role(name: str) -> str | None:
        lowered = name.casefold()
        if lowered in {"reads_1", "read_1", "r1", "forward"}:
            return "1"
        if lowered in {"reads_2", "read_2", "r2", "reverse"}:
            return "2"
        return None

    r1_key = next((key for key in sequence_keys if role(key) == "1"), None)
    r2_key = next((key for key in sequence_keys if role(key) == "2"), None)
    samples: list[dict[str, Any]] = []
    if cohort_members:
        for member in cohort_members:
            samples.append({"sample_id": member["sample_id"],
                            "source": {role: runtime_inputs[key] for role, key in member["runtime"].items()},
                            "subset": {role: pilot_inputs[key] for role, key in member["runtime"].items()},
                            "fraction": fraction, "paired_sampling": "reads_2" in member["runtime"]})
    elif r1_key and r2_key and len(sequence_keys) == 2:
        samples.append(
            {
                "sample_id": sample_id,
                "source": {"r1": runtime_inputs[r1_key], "r2": runtime_inputs[r2_key]},
                "subset": {"r1": pilot_inputs[r1_key], "r2": pilot_inputs[r2_key]},
                "fraction": fraction,
                "paired_sampling": True,
            }
        )
    else:
        for key in sequence_keys:
            samples.append(
                {
                    "sample_id": f"{sample_id}-{key}",
                    "source": {"r1": runtime_inputs[key]},
                    "subset": {"r1": pilot_inputs[key]},
                    "fraction": fraction,
                    "paired_sampling": False,
                }
            )
    mapping: dict[str, Any] = {
        "schema_version": 1,
        "purpose": "subset -> full-source lineage for production input binding",
        "sample_id": sample_id,
        "fraction": fraction,
        "samples": samples,
    }
    mapping["manifest_fingerprint"] = object_fingerprint(mapping)
    path = inputs_root / "source_mapping.yaml"
    write_yaml(path, mapping)
    return path


class SmallScaleValidator:
    """Run every planned node on a representative subset with output checks."""

    def __init__(self, project: PipelineProject):
        self.project = project

    def validate(
        self,
        runtime_inputs: dict[str, str],
        *,
        sample_id: str = "validation",
        max_records: int | None = None,
        fraction: float | None = None,
        seed: int | None = None,
        timeout_seconds: int | None = None,
        new_version: bool = False,
        threads: int | None = None,
        memory_gb: int | None = None,
        gpus: int | None = None,
        _manage_state: bool = True,
    ) -> dict[str, Any]:
        self.project.require_layout()
        plan = load_plan(self.project)
        config = self.project.load_config()
        from microbiome.pipeline.requirements import RequirementManager
        from microbiome.pipeline.state import LifecycleState, ProjectStateMachine

        requirements = RequirementManager(self.project).require_confirmed()
        if plan.get("requirements_version") != requirements["requirements_version"]:
            raise ResourceNotReadyError("experiment plan was created from a different requirements version")
        machine = ProjectStateMachine(self.project)
        if _manage_state:
            machine.require(LifecycleState.PRETEST_PREPARATION, LifecycleState.PRETEST_REPAIR)
        bootstrap = _load_phase_report(
            self.project.state_dir / "bootstrap_report.json",
            plan["plan_fingerprint"],
            requirements["requirements_version"],
            "environment bootstrap",
        )
        database_report = _load_phase_report(
            self.project.state_dir / "database_resolution.json",
            plan["plan_fingerprint"],
            requirements["requirements_version"],
            "database resolution",
        )
        validation_config = config.get("validation", {})
        configured_max = validation_config.get("max_records")
        max_records = int(max_records) if max_records is not None else (
            int(configured_max) if configured_max is not None else None
        )
        fraction = float(fraction if fraction is not None else validation_config.get("pretest_fraction", 0.10))
        seed = int(seed if seed is not None else validation_config.get("random_seed", 1729))
        max_subset_bytes = int(validation_config.get("max_subset_bytes", 5 * 1024**3))
        if self.project.pipeline_lock_path.exists() and not new_version:
            raise ConfigurationError(
                "an immutable pipeline is already frozen; repair validation must use new_version=True"
            )
        validation_id = f"validation-{datetime.now(UTC).strftime('%Y%m%dT%H%M%S%fZ')}"
        validation_root = self.project.pretest_dir / validation_id
        inputs_root = validation_root / "input_subset"
        run_root = validation_root / "outputs"
        temp_root = validation_root / "tmp"
        logs_root = validation_root / "logs"
        commands_root = validation_root / "commands"
        checkpoints_root = validation_root / "checkpoints"
        pipeline_root = validation_root / "pipeline"
        for path in (
            inputs_root,
            run_root,
            temp_root,
            logs_root,
            commands_root,
            checkpoints_root,
            pipeline_root,
            validation_root / "reports",
            validation_root / "regression_cases",
        ):
            path.mkdir(parents=True, exist_ok=True)
        write_yaml(pipeline_root / "experiment_plan.yaml", plan)
        pilot_inputs, subset_manifest = _pilot_runtime_inputs(
            runtime_inputs,
            inputs_root,
            max_records=max_records,
            fraction=fraction,
            seed=seed,
            max_subset_bytes=max_subset_bytes,
            cohort_members=plan.get("cohort_members"),
        )
        source_mapping_path = _write_source_mapping(
            inputs_root,
            runtime_inputs,
            pilot_inputs,
            fraction=fraction,
            sample_id=sample_id,
            cohort_members=plan.get("cohort_members"),
        )
        if _manage_state:
            machine.transition(LifecycleState.PRETEST_RUNNING, reason="deterministic input subset prepared")
        resource_snapshot = get_config().snapshot(
            threads_cap=threads,
            memory_cap_gb=memory_gb,
            gpu_cap=gpus,
        )
        steps_by_id = {step["step_id"]: step for step in plan["steps"]}
        ordered = topological_step_ids(plan["steps"])
        started_at = _utcnow()
        step_reports: list[dict[str, Any]] = []
        failed_step: str | None = None
        failure: dict[str, Any] | None = None

        for step_id in ordered:
            step = steps_by_id[step_id]
            tool_lock = bootstrap["tools"][step_id]
            rendered = render_step(
                step,
                tool_lock,
                database_report["databases"],
                runtime_inputs=pilot_inputs,
                run_dir=run_root,
                temp_dir=temp_root,
                sample_id=sample_id,
                resource_snapshot=resource_snapshot,
                project_paths=config["paths"],
            )
            for output in rendered["outputs"].values():
                target = canonical_path(output)
                try:
                    target.relative_to(run_root.resolve())
                except ValueError as exc:
                    raise ConfigurationError(
                        f"step {step_id}: validation output escapes the isolated validation directory: {target}"
                    ) from exc
                target.parent.mkdir(parents=True, exist_ok=True)
            input_fingerprint_before = fingerprint_existing_paths(rendered["inputs"])
            missing_inputs = [value for value in rendered["inputs"].values() if not canonical_path(value).exists()]
            if missing_inputs:
                command_record = {
                    "status": "NOT_RUN",
                    "exit_code": None,
                    "stdout": "",
                    "stderr": f"missing step inputs: {', '.join(missing_inputs)}",
                }
            else:
                command_record = run_logged_command(
                    rendered,
                    commands_root / f"{step_id}.command.json",
                    timeout_seconds=timeout_seconds,
                )
            assertions = (
                evaluate_assertions(step["success_criteria"], rendered) if command_record["exit_code"] == 0 else []
            )
            input_unchanged = input_fingerprint_before == fingerprint_existing_paths(rendered["inputs"])
            assertions.append(
                {
                    "type": "input_immutable",
                    "target": "all step inputs",
                    "passed": input_unchanged,
                    "detail": "input fingerprints unchanged" if input_unchanged else "an input was modified",
                }
            )
            passed = (
                command_record["exit_code"] == 0 and bool(assertions) and all(item["passed"] for item in assertions)
            )
            step_report = {
                "step_id": step_id,
                "status": "PASSED" if passed else "FAILED",
                "exact_executable_path": tool_lock["executable"],
                "exact_software_version": tool_lock["version_output"],
                "exact_environment": tool_lock.get("environment_prefix"),
                "exact_command_line": rendered["command"],
                "exact_parameters": step["parameters"],
                "exact_resources": rendered["resources"],
                "exact_database_path": rendered["databases"],
                "input_files": rendered["inputs"],
                "output_files": rendered["outputs"],
                "exit_code": command_record["exit_code"],
                "stdout_log": command_record.get("stdout_log"),
                "stderr_log": command_record.get("stderr_log"),
                "runtime_seconds": command_record.get("runtime_seconds"),
                "success_checks": assertions,
                "failure_criteria": step["failure_criteria"],
            }
            step_reports.append(step_report)
            # Record the structured execution fact immediately; the ledger is
            # the only factual source a later freeze may be built from.
            from microbiome.pipeline.ledger import ExecutionLedger

            ledger_record = ExecutionLedger.for_project(self.project).record(
                phase="validation",
                source="small-scale-validator",
                step_id=step_id,
                status="PASSED" if passed else "FAILED",
                tool={
                    "name": step["tool"],
                    "version": tool_lock["version_output"],
                    "executable": tool_lock["executable"],
                },
                environment={"conda_prefix": tool_lock.get("environment_prefix"), "conda_env": None},
                command={"kind": "argv", "argv": list(rendered["command"])},
                inputs=sorted(str(value) for value in rendered["inputs"].values()),
                outputs=sorted(str(value) for value in rendered["outputs"].values()),
                database_resources=[
                    {"alias": alias, "path": str(path)} for alias, path in rendered["databases"].items()
                ],
                parameters={"declared": list(step["parameters"])},
                exit_code=command_record["exit_code"],
                output_validation={
                    "passed": bool(passed),
                    "detail": "; ".join(
                        f"{item.get('type')}:{item.get('target')}={'PASS' if item.get('passed') else 'FAIL'}"
                        for item in assertions
                    )[:400],
                },
                error_excerpt="" if passed else str(command_record.get("stderr") or "")[-500:],
                verified=True,
                extra={"validation_id": validation_id, "plan_fingerprint": plan["plan_fingerprint"],
                       "requirements_version": requirements["requirements_version"]},
            )
            step_report["source_attempt"] = ledger_record["attempt"]
            from microbiome.pipeline.knowledge import KnowledgeBase

            knowledge = KnowledgeBase(self.project)
            knowledge.record_invocation(
                step["tool"],
                command=list(rendered["command"]),
                success=passed,
                executable=tool_lock["executable"],
                version=tool_lock["version_output"],
                environment=tool_lock.get("environment_prefix"),
                database=rendered["databases"],
                outputs=sorted(str(value) for value in rendered["outputs"].values()),
                exit_code=command_record["exit_code"],
                phase="VALIDATION",
                validation_checks=assertions,
            )
            if not passed:
                failed_step = step_id
                inputs_metadata = {
                    name: fast_file_fingerprint(value) if canonical_path(value).is_file() else {"path": value}
                    for name, value in rendered["inputs"].items()
                    if canonical_path(value).exists()
                }
                failure = failure_record(
                    step=step_id,
                    sample=sample_id,
                    command=rendered["command"],
                    environment=tool_lock.get("environment_prefix"),
                    tool_version=tool_lock["version_output"],
                    database=rendered["databases"],
                    exit_code=command_record["exit_code"],
                    stdout=command_record.get("stdout", ""),
                    stderr=command_record.get("stderr", ""),
                    input_metadata=inputs_metadata,
                    assertion_failed=command_record["exit_code"] == 0,
                )
                failure["error_signature"] = knowledge.record_failure(step["tool"], failure)
                break
            from microbiome.pipeline.registry import mark_tool_success

            mark_tool_success(self.project.tool_registry_path, step["tool"])
            write_json(
                checkpoints_root / f"{step_id}.json",
                {
                    "step_id": step_id,
                    "status": "COMPLETED",
                    "plan_fingerprint": plan["plan_fingerprint"],
                    "output_fingerprint": fingerprint_existing_paths(rendered["outputs"]),
                    "completed_at": _utcnow(),
                },
            )

        report = {
            "schema_version": 1,
            "phase": PipelinePhase.VALIDATION.value,
            "validation_id": validation_id,
            "status": "PASSED" if failed_step is None and len(step_reports) == len(ordered) else "FAILED",
            "started_at": started_at,
            "completed_at": _utcnow(),
            "plan_fingerprint": plan["plan_fingerprint"],
            "requirements_version": requirements["requirements_version"],
            "bootstrap_report_fingerprint": bootstrap["report_fingerprint"],
            "database_report_fingerprint": database_report["report_fingerprint"],
            "representative_subset": subset_manifest,
            "source_mapping": str(source_mapping_path),
            "pretest_fraction": fraction,
            "random_seed": seed,
            "resource_strategy": "MAXIMIZE_WITHIN_LIVE_AND_FROZEN_LIMITS",
            "resource_snapshot": resource_snapshot.as_dict(),
            "runtime_input_source": {name: path_fingerprint(value) for name, value in runtime_inputs.items()},
            "validation_root": str(validation_root),
            "steps": step_reports,
            "failed_step": failed_step,
            "failure": failure,
        }
        report_path = (
            self.project.state_dir / "candidates" / validation_id / "validation_report.json"
            if self.project.pipeline_lock_path.exists()
            else self.project.validation_report_path
        )
        report["report_path"] = str(report_path)
        report["report_fingerprint"] = object_fingerprint(report)
        write_json(report_path, report)
        if _manage_state:
            if report["status"] == "PASSED":
                machine.transition(
                    LifecycleState.PRETEST_PASSED,
                    reason="all pre-test DAG steps and assertions passed",
                )
            else:
                machine.transition(LifecycleState.PRETEST_REPAIR, reason="pre-test failure requires root-cause repair")
        self.project.set_phase(PipelinePhase.VALIDATION)
        return report

    def validate_repair(
        self,
        regression_manifest_path: str | Path,
        *,
        timeout_seconds: int | None = None,
        threads: int | None = None,
        memory_gb: int | None = None,
        gpus: int | None = None,
    ) -> dict[str, Any]:
        """Validate both the original subset and one minimized production regression."""
        from microbiome.pipeline.state import LifecycleState, ProjectStateMachine

        machine = ProjectStateMachine(self.project)
        machine.require(
            LifecycleState.REVALIDATION_REQUIRED,
            LifecycleState.PRETEST_PREPARATION,
            LifecycleState.PRETEST_REPAIR,
        )
        if not self.project.pipeline_lock_path.is_file() or not self.project.validation_report_path.is_file():
            raise ConfigurationError("repair validation requires an existing frozen pipeline and validation report")
        if machine.current == LifecycleState.REVALIDATION_REQUIRED:
            machine.transition(LifecycleState.PRETEST_PREPARATION, reason="production regression queued")
        machine.transition(LifecycleState.PRETEST_RUNNING, reason="original and regression validation suite started")
        original_report = read_json(self.project.validation_report_path)
        original_inputs = {
            name: str(metadata["path"])
            for name, metadata in original_report.get("runtime_input_source", {}).items()
            if isinstance(metadata, dict) and metadata.get("path")
        }
        if not original_inputs:
            raise ConfigurationError("the original validation report does not record reusable input paths")
        regression = read_yaml(regression_manifest_path)
        if not isinstance(regression, dict) or regression.get("status") != "READY":
            raise ConfigurationError(
                "regression manifest must be minimized, point to representative inputs, and have status: READY"
            )
        regression_inputs = regression.get("runtime_inputs")
        if not isinstance(regression_inputs, dict) or not regression_inputs:
            raise ConfigurationError("regression manifest requires a non-empty runtime_inputs mapping")

        cases = [
            ("original-validation", original_inputs),
            (str(regression.get("sample_id") or "production-regression"), regression_inputs),
        ]
        reports = [
            self.validate(
                inputs,
                sample_id=sample_id,
                timeout_seconds=timeout_seconds,
                new_version=True,
                threads=threads,
                memory_gb=memory_gb,
                gpus=gpus,
                _manage_state=False,
            )
            for sample_id, inputs in cases
        ]
        plan = load_plan(self.project)
        all_passed = all(report["status"] == "PASSED" for report in reports)
        case_steps = {
            report["validation_id"]: {step["step_id"]: step["status"] for step in report["steps"]} for report in reports
        }
        aggregated_steps = []
        for step in reports[0]["steps"]:
            step_id = step["step_id"]
            statuses = {validation_id: values.get(step_id, "NOT_RUN") for validation_id, values in case_steps.items()}
            aggregated = dict(step)
            aggregated["case_statuses"] = statuses
            aggregated["status"] = "PASSED" if all(value == "PASSED" for value in statuses.values()) else "FAILED"
            aggregated_steps.append(aggregated)
        repair_id = f"repair-validation-{datetime.now(UTC).strftime('%Y%m%dT%H%M%S%fZ')}"
        report_path = self.project.state_dir / "candidates" / repair_id / "validation_report.json"
        combined = {
            "schema_version": 1,
            "phase": PipelinePhase.VALIDATION.value,
            "validation_id": repair_id,
            "validation_mode": "REPAIR_REGRESSION_SUITE",
            "status": "PASSED" if all_passed else "FAILED",
            "started_at": reports[0]["started_at"],
            "completed_at": _utcnow(),
            "plan_fingerprint": plan["plan_fingerprint"],
            "requirements_version": plan["requirements_version"],
            "bootstrap_report_fingerprint": reports[0]["bootstrap_report_fingerprint"],
            "database_report_fingerprint": reports[0]["database_report_fingerprint"],
            "required_cases": ["original representative validation subset", "minimized failing regression sample"],
            "resource_strategy": "MAXIMIZE_WITHIN_LIVE_AND_FROZEN_LIMITS",
            "resource_snapshot": reports[0]["resource_snapshot"],
            "resource_snapshots": [report["resource_snapshot"] for report in reports],
            "cases": [
                {
                    "sample_id": sample_id,
                    "status": report["status"],
                    "report_path": report["report_path"],
                    "report_fingerprint": report["report_fingerprint"],
                    "failed_step": report["failed_step"],
                }
                for (sample_id, _inputs), report in zip(cases, reports, strict=True)
            ],
            "regression_manifest": str(canonical_path(regression_manifest_path, must_exist=True)),
            "runtime_input_source": reports[0]["runtime_input_source"],
            "steps": aggregated_steps,
            "failed_step": next((step["step_id"] for step in aggregated_steps if step["status"] != "PASSED"), None),
            "failure": next((report["failure"] for report in reports if report.get("failure")), None),
            "report_path": str(report_path),
        }
        combined["report_fingerprint"] = object_fingerprint(combined)
        write_json(report_path, combined)
        if all_passed and regression.get("failure_record"):
            failure_path = canonical_path(regression["failure_record"])
            if failure_path.is_file():
                original_failure = read_json(failure_path)
                failed_step = str(regression.get("failed_step") or original_failure.get("step"))
                step_by_id = {step["step_id"]: step for step in plan["steps"]}
                if failed_step in step_by_id and original_failure.get("error_signature"):
                    from microbiome.pipeline.knowledge import KnowledgeBase

                    KnowledgeBase(self.project).record_fix(
                        step_by_id[failed_step]["tool"],
                        error_signature=original_failure["error_signature"],
                        root_cause="resolved by the explicitly revised pipeline and regression validation",
                        fix=f"validated pipeline plan {plan['plan_fingerprint']}",
                        verified=True,
                        validation_report=str(report_path),
                    )
        machine.transition(
            LifecycleState.PRETEST_PASSED if all_passed else LifecycleState.PRETEST_REPAIR,
            reason="regression validation suite passed" if all_passed else "regression validation suite failed",
        )
        return combined
