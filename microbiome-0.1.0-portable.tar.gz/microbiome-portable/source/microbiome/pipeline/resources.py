"""Bootstrap-only executable resolution and persistent database validation."""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from microbiome.conda_discovery import find_conda_manager
from microbiome.pipeline.errors import ConfigurationError, ResourceNotReadyError
from microbiome.pipeline.io import canonical_path, fast_file_fingerprint, object_fingerprint
from microbiome.pipeline.models import ResourceStatus


def _utcnow() -> str:
    return datetime.now(UTC).isoformat()


def tool_environment(prefix: str | Path | None, inherited: dict[str, str] | None = None) -> dict[str, str]:
    """Select an exact runtime prefix without changing the agent process.

    Activation scripts, when needed, are handled by the validated Conda launcher;
    this function does not invent library paths or activate another environment.
    """
    environment = dict(os.environ if inherited is None else inherited)
    if prefix is None:
        return environment
    root = canonical_path(prefix, must_exist=True)
    previous = environment.get("CONDA_PREFIX")
    search = environment.get("PATH", os.defpath).split(os.pathsep)
    if previous:
        previous_bin = str(canonical_path(previous) / "bin")
        search = [part for part in search if part != previous_bin]
    environment["PATH"] = os.pathsep.join(dict.fromkeys([str(root / "bin"), *search]))
    if (root / "conda-meta").is_dir():
        environment["CONDA_PREFIX"] = str(root)
        environment["CONDA_DEFAULT_ENV"] = str(root)
        # Parent Python overrides defeat isolation even with an absolute binary.
        environment.pop("PYTHONHOME", None)
        environment.pop("PYTHONPATH", None)
    return environment


def locked_tool_command(command: list[str], contract: dict[str, Any]) -> list[str]:
    """Replay an optional validated launcher; never discover one in production."""
    launcher = contract.get("runtime_launcher") or []
    if not launcher:
        return list(command)
    prefix = contract.get("environment_prefix")
    if (not isinstance(launcher, list) or len(launcher) != 5 or not prefix
            or not isinstance(launcher[0], str) or not Path(launcher[0]).is_absolute()
            or launcher[1:] != ["run", "-p", str(prefix), "--no-capture-output"]):
        raise ConfigurationError("invalid locked Conda runtime launcher")
    manager = canonical_path(launcher[0], must_exist=True)
    fingerprint = contract.get("runtime_launcher_fingerprint")
    if not fingerprint or fast_file_fingerprint(manager) != fingerprint:
        raise ResourceNotReadyError("locked Conda runtime launcher changed; revalidation is required")
    return [*launcher, *command]


def _environment_spec(value: str | dict[str, Any]) -> dict[str, Any]:
    if isinstance(value, str):
        path = canonical_path(value) if os.sep in value or value.startswith(".") else None
        return {"name": None if path else value, "prefix": str(path) if path else None}
    return {
        "name": value.get("name"),
        "prefix": value.get("prefix"),
        "version_args": value.get("version_args"),
        "strict_probe": value.get("strict_probe", False),
        "probe_marker": value.get("probe_marker"),
        "installation_source": value.get("installation_source"),
        "executable": value.get("executable"),
        "software_dirs": value.get("software_dirs", []),
    }


def conda_catalog() -> tuple[str | None, dict[str, str]]:
    manager = find_conda_manager()
    payload = {}
    if manager:
        try:
            result = subprocess.run(
                [manager, "env", "list", "--json"], capture_output=True, text=True, timeout=30, check=False
            )
            payload = json.loads(result.stdout) if result.returncode == 0 else {}
        except (OSError, subprocess.TimeoutExpired, json.JSONDecodeError):
            pass
    prefixes = list(payload.get("envs", []))
    # Conda installations share this registry, including prefixes belonging to a
    # different manager and environments whose manager is no longer on PATH.
    registry = Path.home() / ".conda" / "environments.txt"
    try:
        prefixes.extend(line.strip() for line in registry.read_text().splitlines() if line.strip())
    except OSError:
        pass
    catalog: dict[str, str] = {}
    for value in prefixes:
        prefix = canonical_path(value)
        name = prefix.name
        if name in catalog and catalog[name] != str(prefix):
            # Names are hints, never unique identities across installations.
            name = str(prefix)
        catalog[name] = str(prefix)
        if prefix.name in {"miniconda3", "miniforge3", "anaconda3"}:
            catalog.setdefault("base", str(prefix))
    return str(canonical_path(manager)) if manager else None, catalog


def _version_satisfies(raw: str, requirement: str) -> bool:
    requirement = requirement.strip()
    if requirement in {"*", "any", "ANY"}:
        return True
    version_match = re.search(r"(?<!\d)(\d+(?:\.\d+)+(?:[-+._A-Za-z0-9]*)?)", raw)
    if not version_match:
        return requirement.casefold() in raw.casefold()
    installed = version_match.group(1)
    clauses = [part.strip() for part in requirement.split(",") if part.strip()]
    if not clauses:
        return True
    try:
        from packaging.version import Version
    except ImportError:
        return installed == requirement.removeprefix("==")
    try:
        actual = Version(installed)
        for clause in clauses:
            match = re.fullmatch(r"(==|!=|>=|<=|>|<|~=)?\s*([0-9][^\s]*)", clause)
            if not match:
                return requirement.casefold() in raw.casefold()
            operator, expected_raw = match.groups()
            expected = Version(expected_raw)
            operator = operator or "=="
            comparisons = {
                "==": actual == expected,
                "!=": actual != expected,
                ">=": actual >= expected,
                "<=": actual <= expected,
                ">": actual > expected,
                "<": actual < expected,
                "~=": actual >= expected and actual.release[:1] == expected.release[:1],
            }
            if not comparisons[operator]:
                return False
        return True
    except Exception:
        return installed == requirement.removeprefix("==")


_FATAL_RUNTIME_MARKERS = (
    "error while loading shared libraries",
    "cannot open shared object file",
    "command not found",
    "no such file or directory",
    "module not found",
    "modulenotfounderror",
    "permission denied",
    "cannot execute",
    "segmentation fault",
    "traceback (most recent call last)",
    "unrecognized tool",
    "unrecognised tool",
    "unrecognized command",
    "unrecognised command",
    "unrecognized option",
    "unrecognised option",
    "invalid command",
    "unknown option",
    "incorrect use of option",
    "未找到命令",
    "找不到命令",
)


def _looks_like_fatal_runtime_error(text: str) -> bool:
    """Return whether a probe exposed a broken runtime rather than a version banner.

    Version probes are deliberately tolerant of bioinformatics programs that print a
    usage banner and exit non-zero.  They must not, however, promote an installation
    merely because an error message contains a dotted number from an executable path
    or package directory.
    """
    lowered = text.casefold()
    return any(marker in lowered for marker in _FATAL_RUNTIME_MARKERS)


def _looks_like_version_banner(text: str) -> bool:
    """True when non-empty output carries a version/usage signature.

    Several bioinformatics executables (e.g. ``bwa``) print their version/usage
    banner to stderr and exit non-zero when invoked without a recognized command
    or flag. The smoke test must not reject those as broken installations. An
    explicit "unrecognized command/option" line means the *flag* itself was wrong,
    so that probe is still rejected (and the resolver falls through to the bare
    executable probe).
    """
    if not text:
        return False
    if _looks_like_fatal_runtime_error(text):
        return False
    if re.search(r"(?im)^\s*version\s*:\s*\S+", text):
        return True
    for line in text.splitlines():
        stripped = line.strip()
        if re.fullmatch(r"v?\d+\.\d+(?:\.\d+)?(?:[-+._A-Za-z0-9]*)?", stripped, re.IGNORECASE):
            return True
        if len(stripped) <= 120 and re.fullmatch(
            r"(?!(?:error|warning|usage|traceback)\b)"
            r"[A-Za-z][A-Za-z0-9+_.-]*(?:[ \t]+[A-Za-z][A-Za-z0-9+_.-]*){0,3}"
            r"[ \t]+v?\d+\.\d+(?:\.\d+)?(?:[-+._A-Za-z0-9]*)?(?:[ \t]+\([^\n)]{1,60}\))?",
            stripped,
            re.IGNORECASE,
        ):
            return True
        if len(stripped) <= 120 and re.match(
            r"^[A-Za-z][A-Za-z0-9+_.-]*(?:\s+\([^\n)]{1,60}\))?"
            r"(?:\s+(?:version|v))?\s*:?[ \t]+v?\d+\.\d+",
            stripped,
            re.IGNORECASE,
        ):
            return True
    return bool(re.search(r"(?im)^\s*\S[^\n]{0,80}\b(?:version|v)\s*\d+\.\d+", text))


def verified_package_probe_version(
    contract: dict[str, Any], output: str, returncode: int,
) -> dict[str, Any] | None:
    """Replay bootstrap's package-version canonicalization using frozen records.

    Older locks store the canonical package label, not the unversioned probe's
    transcript. Only that narrowly identifiable case may use installed metadata;
    this function never discovers another executable, launcher or package.
    """
    if (returncode != contract.get("version_exit_code", 0)
            or _looks_like_fatal_runtime_error(output)
            or _looks_like_version_banner(output)
            or (returncode != 0 and contract.get("version_args", ["--version"]))):
        return None
    inventory = contract.get("package_inventory") or []
    expected = contract.get("version_output", "")
    candidates = [item for item in inventory if isinstance(item, dict)
                  and expected == f"{item.get('name')} {item.get('version')}"]
    if len(candidates) != 1:
        return None

    def fail(detail: str) -> None:
        raise ResourceNotReadyError(f"frozen package version verification failed: {detail}")

    prefix_value = contract.get("environment_prefix")
    if not prefix_value:
        fail("missing environment prefix")
    prefix = canonical_path(prefix_value, must_exist=True)
    metadata_root = prefix / "conda-meta"
    if not metadata_root.is_dir():
        fail("missing conda-meta directory")
    executable = canonical_path(contract["executable"], must_exist=True)
    try:
        relative_executable = executable.relative_to(prefix).as_posix()
    except ValueError:
        fail("executable is outside the locked prefix")
    if contract.get("executable_fingerprint") is not None:
        if fast_file_fingerprint(executable) != contract["executable_fingerprint"]:
            fail("executable fingerprint changed")

    def channel_base(value: Any, platform: str) -> str:
        if not isinstance(value, str) or not value:
            return ""
        # Conda list stores base_url; prefix records may append the exact subdir.
        value = value.rstrip("/")
        suffix = "/" + platform
        return value[:-len(suffix)] if value.endswith(suffix) else value

    installed: dict[str, dict[str, Any]] = {}
    for frozen in inventory:
        if not isinstance(frozen, dict):
            fail("invalid frozen package record")
        name = frozen.get("name")
        if not isinstance(name, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*", name):
            fail("invalid frozen package name")
        if name in installed:
            fail(f"ambiguous frozen package: {name}")
        records = []
        for path in metadata_root.glob(f"{name}-*.json"):
            try:
                item = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, ValueError) as exc:
                fail(f"unreadable package record {path.name}: {exc}")
            if isinstance(item, dict) and item.get("name") == name:
                records.append(item)
        if len(records) != 1:
            fail(f"missing or ambiguous installed package: {name}")
        live = records[0]
        build = frozen.get("build_string", frozen.get("build"))
        platform = frozen.get("platform", frozen.get("subdir"))
        if (not frozen.get("version") or not build or not platform
                or frozen.get("build_number") is None):
            fail(f"incomplete frozen package identity: {name}")
        identity = {"name": name, "version": frozen["version"], "build": build,
                    "build_number": frozen["build_number"], "subdir": platform}
        if any(live.get(key) != value for key, value in identity.items()):
            fail(f"package identity/version/build/platform changed: {name}")
        if (frozen.get("build", build) != build or frozen.get("subdir", platform) != platform
                or frozen.get("dist_name", f"{name}-{frozen['version']}-{build}")
                != f"{name}-{frozen['version']}-{build}"):
            fail(f"inconsistent frozen package identity: {name}")
        base = channel_base(frozen.get("base_url") or frozen.get("channel"), platform)
        if not base or ("://" not in base and not Path(base).is_absolute()):
            fail(f"missing exact frozen channel location: {name}")
        frozen_channel = channel_base(frozen.get("channel"), platform)
        if frozen_channel and frozen_channel not in {base, base.rsplit("/", 1)[-1]}:
            fail(f"inconsistent frozen channel: {name}")
        live_channel = channel_base(live.get("channel"), platform)
        if live_channel not in {base, base.rsplit("/", 1)[-1]}:
            fail(f"package channel changed: {name}")
        # The archive URL disambiguates a short channel name in prefix records.
        url = live.get("url")
        if isinstance(url, str) and url:
            if channel_base(url.rsplit("/", 1)[0], platform) != base:
                fail(f"package archive channel changed: {name}")
        elif live_channel != base:
            fail(f"package channel cannot be verified: {name}")
        installed[name] = live

    package = installed[candidates[0]["name"]]
    files = package.get("files")
    if not isinstance(files, list) or relative_executable not in files:
        fail("locked executable is not owned by the frozen package")
    paths_data = package.get("paths_data") or {}
    if not isinstance(paths_data, dict) or not isinstance(paths_data.get("paths", []), list):
        fail("invalid package executable records")
    if any(not isinstance(item, dict) for item in paths_data.get("paths", [])):
        fail("invalid package executable records")
    paths = [item for item in paths_data.get("paths", [])
             if item.get("_path") == relative_executable]
    if len(paths) > 1:
        fail("ambiguous package executable hash")
    checksum = None
    if paths:
        record = paths[0]
        checksum = record.get("sha256_in_prefix")
        if not checksum and not record.get("prefix_placeholder"):
            checksum = record.get("sha256")
        if checksum:
            if not isinstance(checksum, str) or not re.fullmatch(r"[0-9a-fA-F]{64}", checksum):
                fail("invalid installed executable hash")
            with executable.open("rb") as handle:
                actual = hashlib.file_digest(handle, "sha256").hexdigest()
            if actual != checksum.lower():
                fail("installed executable content changed")
    if not checksum and contract.get("executable_fingerprint") is None:
        fail("no installed executable checksum or frozen executable fingerprint")
    return {"version_output": expected, "version_source": "verified_frozen_package",
            "package_name": candidates[0]["name"], "verified_package_count": len(installed),
            "package_executable_hash_verified": bool(checksum),
            "executable_integrity_source": "package_sha256" if checksum else "frozen_executable_fingerprint"}


class ToolchainResolver:
    """Find, execute-smoke-test, and record exact tool installations.

    This component never installs packages. Creation/repair belongs to an explicit
    bootstrap operation outside validation and production.
    """

    def __init__(
        self,
        project_root: str | Path,
        *,
        version_probe_timeout: float = 30,
        include_package_inventory: bool = True,
    ):
        self.project_root = canonical_path(project_root)
        self.conda_manager, self.catalog = conda_catalog()
        self.version_probe_timeout = float(version_probe_timeout)
        self.include_package_inventory = bool(include_package_inventory)
        self._package_inventory_cache: dict[tuple[str, str], list[dict[str, Any]]] = {}

    def _candidate_executables(self, tool: str, environment: dict[str, Any]) -> list[tuple[Path, Path | None, str]]:
        executable_name = str(environment.get("executable") or tool)
        candidates: list[tuple[Path, Path | None, str]] = []

        def add(path: Path, prefix: Path | None, source: str) -> None:
            resolved = path.resolve()
            if resolved.is_file() and os.access(resolved, os.X_OK) and all(item[0] != resolved for item in candidates):
                candidates.append((resolved, prefix.resolve() if prefix else None, source))

        if Path(executable_name).is_absolute():
            requested = canonical_path(environment["prefix"]) if environment.get("prefix") else None
            add(canonical_path(executable_name), requested, "configured absolute executable")
            return candidates

        # Required priority: project environments, configured Conda envs, then PATH.
        project_prefixes = [
            self.project_root / ".venv",
            self.project_root / ".conda",
            self.project_root / "env",
        ]
        project_prefixes.extend(
            sorted((self.project_root / "envs").glob("*")) if (self.project_root / "envs").is_dir() else []
        )
        project_prefixes.extend(sorted((self.project_root / ".biomni" / "envs").glob("*")))
        for prefix in project_prefixes:
            add(prefix / "bin" / executable_name, prefix, "project environment")

        requested_prefix = environment.get("prefix")
        requested_name = environment.get("name")
        if requested_prefix:
            prefix = canonical_path(requested_prefix)
            add(prefix / "bin" / executable_name, prefix, "configured environment prefix")
        if requested_name and requested_name in self.catalog:
            prefix = canonical_path(self.catalog[requested_name])
            add(prefix / "bin" / executable_name, prefix, "configured Conda environment")
        for name, value in sorted(self.catalog.items()):
            if name == requested_name:
                continue
            prefix = canonical_path(value)
            add(prefix / "bin" / executable_name, prefix, "existing Conda environment")

        project_software_dirs = [self.project_root / name for name in ("bin", "software", "Software", "tools")]
        configured_software_dirs = environment.get("software_dirs") or []
        if isinstance(configured_software_dirs, str):
            configured_software_dirs = [configured_software_dirs]
        for directory in [*project_software_dirs, *(canonical_path(value) for value in configured_software_dirs)]:
            add(directory / executable_name, None, "project software directory")

        path_hit = shutil.which(executable_name)
        if path_hit:
            resolved = canonical_path(path_hit, must_exist=True)
            prefix = (
                resolved.parent.parent
                if resolved.parent.name == "bin" and (resolved.parent.parent / "conda-meta").is_dir()
                else None
            )
            add(resolved, prefix, "PATH")
        return candidates

    def _package_inventory(self, prefix: Path | None, manager: str | None) -> list[dict[str, Any]]:
        if prefix is None or manager is None or not (prefix / "conda-meta").is_dir():
            return []
        cache_key = (str(prefix.resolve()), str(manager))
        if cache_key in self._package_inventory_cache:
            return self._package_inventory_cache[cache_key]
        try:
            result = subprocess.run(
                [manager, "list", "--json", "-p", str(prefix)],
                capture_output=True,
                text=True,
                timeout=60,
                check=False,
            )
            payload = json.loads(result.stdout) if result.returncode == 0 else []
            inventory = [item for item in payload if isinstance(item, dict)]
        except (OSError, subprocess.TimeoutExpired, json.JSONDecodeError):
            inventory = []
        self._package_inventory_cache[cache_key] = inventory
        return inventory

    def _package_version(self, prefix: Path | None, tool: str) -> str:
        """Return a human-readable version from the conda package inventory.

        Some executables (e.g. PAML's ``codeml``/``baseml``) have no version flag
        and no version banner — they are interactive and treat every argument as a
        control-file path. For those, the package metadata is the only version source.
        """
        lowered = str(tool).casefold()
        for item in self._package_inventory(prefix, self.conda_manager):
            name = str(item.get("name") or "").casefold()
            if not name:
                continue
            if name == lowered or lowered in name or name in lowered:
                version = str(item.get("version") or "").strip()
                if version:
                    return f"{item.get('name', tool)} {version}"
        return ""

    def _version_command(self, executable: Path, prefix: Path | None, version_args: list[str]) -> list[str]:
        """Build the smoke-test command using the same isolation as production.

        Executing a Conda script by absolute path is insufficient for wrappers with
        ``/usr/bin/env perl`` or similar launchers: they can inherit another
        environment's runtime and report missing modules even though the declared
        prefix is healthy.  A real Conda prefix is therefore probed through
        ``conda run -p``.  Non-Conda/project executables remain direct.
        """
        needs_conda_runtime = False
        if prefix is not None and (prefix / "conda-meta").is_dir():
            try:
                first_line = executable.open("rb").readline(512).decode("utf-8", errors="ignore").strip()
            except OSError:
                first_line = ""
            if first_line.startswith("#!"):
                interpreter = first_line[2:].split(maxsplit=1)[0]
                try:
                    interpreter_path = Path(interpreter).resolve()
                    interpreter_path.relative_to(prefix.resolve())
                except (OSError, ValueError):
                    # Scripts launched by /usr/bin/env, /bin/sh, /bin/bash, or an
                    # external Perl/R need the prefix's PATH and runtime variables.
                    needs_conda_runtime = True
        if needs_conda_runtime and self.conda_manager:
            return [
                self.conda_manager,
                "run",
                "-p",
                str(prefix),
                "--no-capture-output",
                str(executable),
                *version_args,
            ]
        return [str(executable), *version_args]

    def resolve_step(self, step: dict[str, Any]) -> dict[str, Any]:
        step_id = step["step_id"]
        environment = _environment_spec(step["environment"])
        version_args = environment.get("version_args")
        if version_args is None:
            version_args = step.get("version_args")
        if version_args is None:
            version_args = ["--version"]
        if not isinstance(version_args, list) or not all(isinstance(item, str) for item in version_args):
            raise ConfigurationError(f"step {step_id}: version_args must be a list of strings")
        failures: list[str] = []
        for executable, prefix, source in self._candidate_executables(step["tool"], environment):
            command = self._version_command(executable, prefix, version_args)
            raw_version = ""
            allow_package_fallback = False
            try:
                # stdin=DEVNULL so interactive executables (e.g. PAML codeml) that
                # read a control-file path from stdin exit instead of hanging the
                # 30s smoke test.
                result = subprocess.run(
                    command,
                    env=tool_environment(prefix),
                    capture_output=True,
                    text=True,
                    timeout=self.version_probe_timeout,
                    check=False,
                    stdin=subprocess.DEVNULL,
                )
            except (OSError, subprocess.TimeoutExpired) as exc:
                failures.append(f"{executable}: {exc}")
            else:
                raw_version = "\n".join(part.strip() for part in (result.stdout, result.stderr) if part.strip())
                fatal_runtime_error = _looks_like_fatal_runtime_error(raw_version)
                allow_package_fallback = result.returncode == 0 or (not version_args and not fatal_runtime_error)
                if environment.get("strict_probe") and (result.returncode != 0
                        or environment.get("probe_marker", "") not in raw_version):
                    failures.append(f"{executable}: required package/function capability failed: {raw_version[-500:]}")
                    raw_version = ""
                    allow_package_fallback = False
                elif fatal_runtime_error:
                    failures.append(f"{executable}: runtime smoke test exposed a fatal error: {raw_version[-500:]}")
                    raw_version = ""
                    allow_package_fallback = False
                elif result.returncode != 0:
                    # bwa and several other tools print their version/usage banner to
                    # stderr and exit non-zero when invoked without a recognized flag.
                    # Accept that banner so these tools are not falsely rejected.
                    if not _looks_like_version_banner(raw_version):
                        failures.append(
                            f"{executable}: version smoke test exited {result.returncode}: {raw_version[-500:]}"
                        )
                        raw_version = ""
                elif raw_version and not environment.get("strict_probe") and not _looks_like_version_banner(raw_version):
                    failures.append(f"{executable}: probe output had no version signature: {raw_version[-500:]}")
                    raw_version = ""
            # No executable-version output (interactive / no-flag tools such as PAML):
            # fall back to the conda package inventory as the version source.
            if not raw_version and allow_package_fallback:
                raw_version = self._package_version(prefix, step["tool"])
            if not raw_version:
                continue
            if not _version_satisfies(raw_version, step["tool_version_requirement"]):
                failures.append(
                    f"{executable}: {raw_version[:300]!r} does not satisfy {step['tool_version_requirement']}"
                )
                continue
            return {
                "step_id": step_id,
                "tool": step["tool"],
                "tool_version_requirement": step["tool_version_requirement"],
                "environment_name": prefix.name if prefix else None,
                "environment_prefix": str(prefix) if prefix else None,
                "executable": str(executable),
                "version_args": version_args,
                "version_output": raw_version[:4000],
                "version_exit_code": result.returncode,
                "runtime_launcher": command[:command.index(str(executable))],
                "runtime_launcher_fingerprint": (
                    fast_file_fingerprint(command[0]) if command[0] != str(executable) else None
                ),
                "installation_source": environment.get("installation_source") or source,
                "package_inventory": (
                    self._package_inventory(prefix, self.conda_manager) if self.include_package_inventory else []
                ),
                "validation_result": "PASSED",
                "validated_at": _utcnow(),
            }
        detail = "; ".join(failures[-5:]) or "no executable candidate was found"
        raise ResourceNotReadyError(f"step {step_id}: tool {step['tool']} is not ready: {detail}")

    def resolve_plan(self, steps: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
        return {step["step_id"]: self.resolve_step(step) for step in steps}


def _safe_marker(root: Path, marker: str) -> Path:
    candidate = (root / marker).resolve()
    try:
        candidate.relative_to(root.resolve())
    except ValueError as exc:
        raise ConfigurationError(f"database marker escapes its root: {marker}") from exc
    return candidate


def _measure_directory(root: Path, limit: int = 20_000) -> dict[str, Any]:
    rows: list[tuple[str, int, int]] = []
    total = 0
    truncated = False
    for index, path in enumerate(sorted((item for item in root.rglob("*") if item.is_file()), key=str)):
        if index >= limit:
            truncated = True
            break
        # CheckM's ScreamingBackpack manifest (`.dmanifest`) is rewritten on every
        # `checkm data` invocation even though the underlying data never changes;
        # including its mtime in the inventory causes a spurious "database drift"
        # right after a successful pre-test. It is a runtime artifact, not data.
        if path.name == ".dmanifest":
            continue
        stat = path.stat()
        total += stat.st_size
        rows.append((str(path.relative_to(root)), stat.st_size, stat.st_mtime_ns))
    return {
        "bytes_measured": total,
        "files_measured": len(rows),
        "inventory_truncated": truncated,
        "inventory_sha256": object_fingerprint(rows),
    }


def database_fingerprint(root: Path, markers: list[str]) -> dict[str, Any]:
    marker_fingerprints: dict[str, Any] = {}
    for marker in markers:
        target = _safe_marker(root, marker)
        if target.is_file():
            marker_fingerprints[marker] = fast_file_fingerprint(target)
        elif target.is_dir():
            stat = target.stat()
            children = sorted(item.name for item in target.iterdir())
            marker_fingerprints[marker] = {
                "kind": "directory",
                "mtime_ns": stat.st_mtime_ns,
                "children_sha256": object_fingerprint(children),
                "children": len(children),
            }
        else:
            marker_fingerprints[marker] = {"missing": True}
    return {
        "root": str(root.resolve()),
        "markers": marker_fingerprints,
        "root_inventory": _measure_directory(root),
    }


class DatabaseResolver:
    """Resolve only validated persistent database resources; never download."""

    def __init__(self, database_root: str | Path):
        self.database_root = canonical_path(database_root, must_exist=True)

    def _normalize(self, key: str, value: Any) -> dict[str, Any]:
        if not isinstance(value, dict):
            raise ConfigurationError(
                f"database {key}: use a mapping with logical_name, path, version, and expected_markers"
            )
        logical_name = str(value.get("logical_name") or key)
        if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_.-]{0,127}", logical_name):
            raise ConfigurationError(f"database resource_id/logical_name is invalid: {logical_name!r}")
        raw_path = value.get("root_path") or value.get("path") or str(self.database_root / logical_name)
        path_text = str(raw_path).replace("{database_root}", str(self.database_root))
        path = canonical_path(path_text)
        try:
            path.relative_to(self.database_root)
        except ValueError as exc:
            raise ConfigurationError(
                f"database {logical_name}: root_path must be inside DATABASE_PATH {self.database_root}"
            ) from exc
        raw_runtime_entry = value.get("runtime_entry")
        if raw_runtime_entry is None:
            runtime_entry = path
        else:
            runtime_text = str(raw_runtime_entry).replace("{database_root}", str(self.database_root))
            runtime_text = runtime_text.replace("{root_path}", str(path))
            runtime_path = Path(runtime_text).expanduser()
            runtime_entry = canonical_path(runtime_path if runtime_path.is_absolute() else path / runtime_path)
        try:
            runtime_entry.relative_to(path)
        except ValueError as exc:
            raise ConfigurationError(f"database {logical_name}: runtime_entry must be inside root_path {path}") from exc
        markers = value.get("expected_markers", [])
        if not isinstance(markers, list) or not markers or not all(isinstance(item, str) for item in markers):
            raise ConfigurationError(f"database {logical_name}: expected_markers must be a non-empty list")
        source_files = value.get("source_files", [])
        if not isinstance(source_files, list) or not all(isinstance(item, str) for item in source_files):
            raise ConfigurationError(f"database {logical_name}: source_files must be a list of relative paths")
        supported_tools = value.get("supported_tools", [])
        if not isinstance(supported_tools, list) or not all(isinstance(item, str) for item in supported_tools):
            raise ConfigurationError(f"database {logical_name}: supported_tools must be a string list")
        documentation = value.get("documentation", [])
        if isinstance(documentation, str):
            documentation = [documentation]
        if not isinstance(documentation, list) or not all(isinstance(item, str) for item in documentation):
            raise ConfigurationError(f"database {logical_name}: documentation must be a string or string list")
        raw_consumer_entrypoints = value.get("consumer_entrypoints", {})
        if not isinstance(raw_consumer_entrypoints, dict) or not all(
            isinstance(name, str) and isinstance(entrypoint, str)
            for name, entrypoint in raw_consumer_entrypoints.items()
        ):
            raise ConfigurationError(f"database {logical_name}: consumer_entrypoints must be a string mapping")
        consumer_entrypoints: dict[str, Path] = {}
        for consumer, raw_entrypoint in raw_consumer_entrypoints.items():
            entrypoint_text = raw_entrypoint.replace("{database_root}", str(self.database_root)).replace(
                "{root_path}", str(path)
            )
            entrypoint_path = Path(entrypoint_text).expanduser()
            entrypoint = canonical_path(entrypoint_path if entrypoint_path.is_absolute() else path / entrypoint_path)
            try:
                entrypoint.relative_to(path)
            except ValueError as exc:
                raise ConfigurationError(
                    f"database {logical_name}: consumer entrypoint for {consumer} must be inside {path}"
                ) from exc
            consumer_entrypoints[consumer] = entrypoint
        common_markers = value.get("common_markers", [])
        raw_consumer_markers = value.get("consumer_markers", {})
        if not isinstance(common_markers, list) or not all(isinstance(item, str) for item in common_markers):
            raise ConfigurationError(f"database {logical_name}: common_markers must be a string list")
        if not isinstance(raw_consumer_markers, dict) or not all(
            isinstance(consumer, str)
            and isinstance(consumer_markers, list)
            and all(isinstance(marker, str) for marker in consumer_markers)
            for consumer, consumer_markers in raw_consumer_markers.items()
        ):
            raise ConfigurationError(f"database {logical_name}: consumer_markers must map tools to string lists")
        return {
            "key": key,
            "logical_name": logical_name,
            "type": str(value.get("type") or "database"),
            "root_path": path,
            "runtime_entry": runtime_entry,
            "source_files": source_files,
            "purpose": str(value.get("purpose") or "declared pipeline database resource"),
            "supported_tools": supported_tools,
            "documentation": documentation,
            "consumer_entrypoints": consumer_entrypoints,
            "common_markers": common_markers,
            "consumer_markers": raw_consumer_markers,
            "version": str(value.get("version") or "UNKNOWN"),
            "expected_markers": markers,
            "validation_contract": value.get("validation_contract"),
            "runtime_kind": value.get("runtime_kind", "existing"),
            "runtime_suffix_sets": value.get("runtime_suffix_sets", []),
            "consumer_entrypoint_kinds": value.get("consumer_entrypoint_kinds", {}),
            "consumer_suffix_sets": value.get("consumer_suffix_sets", {}),
        }

    def resolve_plan(self, steps: list[dict[str, Any]], *, require_ready: bool = True) -> dict[str, dict[str, Any]]:
        resolved: dict[str, dict[str, Any]] = {}
        for step in steps:
            for key, raw in step.get("database", {}).items():
                spec = self._normalize(key, raw)
                identity = spec["logical_name"]
                path: Path = spec["root_path"]
                from microbiome.resource_skills.contracts import validate_database_contract, valid_entrypoint
                validation_contract = spec["validation_contract"] or {}
                contract_errors = validate_database_contract(spec["runtime_entry"], validation_contract,
                    consumer=step.get("tool"), parameters=step.get("parameters"), command=step.get("command_template"))
                if not valid_entrypoint(spec["runtime_entry"], spec["runtime_kind"], spec["runtime_suffix_sets"]):
                    contract_errors.append("runtime entrypoint is missing, empty or incomplete")
                present = (
                    [marker for marker in spec["expected_markers"] if valid_entrypoint(_safe_marker(path, marker))]
                    if path.exists()
                    else []
                )
                missing_consumer_entrypoints = [
                    consumer for consumer, entrypoint in spec["consumer_entrypoints"].items()
                    if not valid_entrypoint(entrypoint, spec["consumer_entrypoint_kinds"].get(consumer, "existing"),
                                            spec["consumer_suffix_sets"].get(consumer))
                ]
                missing_consumer_markers = [
                    f"{consumer}:{marker}"
                    for consumer, consumer_markers in spec["consumer_markers"].items()
                    for marker in [*spec["common_markers"], *consumer_markers]
                    if not valid_entrypoint(_safe_marker(path, marker))
                ]
                if not path.exists():
                    status = ResourceStatus.MISSING
                elif not path.is_dir():
                    status = ResourceStatus.CORRUPT
                elif (
                    len(present) != len(spec["expected_markers"])
                    or missing_consumer_entrypoints
                    or missing_consumer_markers
                    or contract_errors
                ):
                    status = ResourceStatus.INCOMPLETE
                else:
                    status = ResourceStatus.READY
                entry = {
                    "logical_name": identity,
                    "type": spec["type"],
                    "root_path": str(path),
                    "runtime_entry": str(spec["runtime_entry"]),
                    # The renderer consumes the exact file/directory/index prefix,
                    # not an inferred database root.
                    "path": str(spec["runtime_entry"]),
                    "source_files": spec["source_files"],
                    "purpose": spec["purpose"],
                    "supported_tools": spec["supported_tools"],
                    "documentation": spec["documentation"],
                    "consumer_entrypoints": {
                        consumer: str(entrypoint)
                        for consumer, entrypoint in sorted(spec["consumer_entrypoints"].items())
                    },
                    "common_markers": list(spec["common_markers"]),
                    "consumer_markers": {
                        consumer: list(markers) for consumer, markers in sorted(spec["consumer_markers"].items())
                    },
                    "database_version": spec["version"],
                    "expected_marker_files": spec["expected_markers"],
                    "present_marker_files": present,
                    "missing_consumer_entrypoints": missing_consumer_entrypoints,
                    "missing_consumer_markers": missing_consumer_markers,
                    "status": status.value,
                    "validation_contract": validation_contract,
                    "contract_errors": contract_errors,
                    **{key: spec[key] for key in ("runtime_kind", "runtime_suffix_sets", "consumer_entrypoint_kinds", "consumer_suffix_sets")},
                }
                if status is ResourceStatus.READY:
                    entry["fingerprint"] = database_fingerprint(path, spec["expected_markers"])
                    entry["size"] = entry["fingerprint"]["root_inventory"]
                if identity in resolved and resolved[identity] != entry:
                    previous = resolved[identity]
                    observations = {"status", "fingerprint", "size", "contract_errors"}
                    if {k: v for k, v in previous.items() if k not in observations} != {
                        k: v for k, v in entry.items() if k not in observations
                    }:
                        raise ConfigurationError(f"database {identity} is declared inconsistently across pipeline steps")
                    entry["contract_errors"] = list(dict.fromkeys(previous["contract_errors"] + entry["contract_errors"]))
                    if entry["contract_errors"]:
                        entry["status"] = ResourceStatus.INCOMPLETE.value
                        entry.pop("fingerprint", None)
                        entry.pop("size", None)
                resolved[identity] = entry
        not_ready = [name for name, entry in resolved.items() if entry["status"] != ResourceStatus.READY.value]
        if require_ready and not_ready:
            details = ", ".join(f"{name}={resolved[name]['status']}" for name in not_ready)
            raise ResourceNotReadyError(f"database resolution failed: {details}")
        return resolved

    def promote_validated_staging(self, staging: str | Path, logical_name: str, expected_markers: list[str]) -> Path:
        """Atomically promote an already-downloaded and validated staging directory."""
        source = canonical_path(staging, must_exist=True)
        if not source.is_dir():
            raise ResourceNotReadyError(f"database staging path is not a directory: {source}")
        missing = [marker for marker in expected_markers if not _safe_marker(source, marker).exists()]
        if missing:
            raise ResourceNotReadyError(f"database staging is incomplete; missing: {', '.join(missing)}")
        destination = canonical_path(self.database_root / logical_name)
        if destination.exists():
            raise ResourceNotReadyError(
                f"refusing to overwrite existing database directory: {destination}; use a new versioned name"
            )
        try:
            source.replace(destination)
        except OSError as exc:
            raise ResourceNotReadyError(
                "atomic database promotion failed; staging must be on the same filesystem as DATABASE_PATH"
            ) from exc
        return destination
