"""Schema and fingerprint validation for a written pipeline.lock.yaml.

A lock is only trustworthy after it has been re-read from disk and checked;
writing bytes is never sufficient evidence. Validation failures raise
:class:`LockValidationError` listing every violation found.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from microbiome.pipeline.errors import LockValidationError
from microbiome.pipeline.io import manifest_fingerprint

REQUIRED_LOCK_FIELDS = (
    "schema_version",
    "created_at",
    "mode",
    "objective",
    "requirements_version",
    "requirements_fingerprint",
    "plan_fingerprint",
    "validation_status",
    "validation_report_fingerprint",
    "production_input_contract",
    "toolchain_lock_fingerprint",
    "database_lock_fingerprint",
    "steps",
    "pipeline_hash",
    "pipeline_version",
    "manifest_fingerprint",
)

REQUIRED_STEP_FIELDS = (
    "step_id",
    "purpose",
    "tool",
    "tool_version",
    "absolute_executable",
    "environment_prefix",
    "command_template",
    "input_template",
    "output_template",
    "database_path",
    "success_assertions",
    "failure_criteria",
    "parameter_list",
    "dependencies",
    "validation",
)


def validate_pipeline_lock(lock: Any) -> dict[str, Any]:
    """Validate one loaded pipeline lock; return it unchanged when valid."""
    violations: list[str] = []
    if not isinstance(lock, dict):
        raise LockValidationError("pipeline lock is not a YAML mapping")
    if lock.get("schema_version") != 1:
        violations.append("schema_version must be 1")
    for field in REQUIRED_LOCK_FIELDS:
        if field not in lock:
            violations.append(f"missing lock field: {field}")
    if violations:
        raise LockValidationError("pipeline lock schema violations: " + "; ".join(violations))

    if not str(lock.get("objective") or "").strip():
        violations.append("objective must be non-empty")
    if not isinstance(lock.get("requirements_version"), int):
        violations.append("requirements_version must be an integer")
    if lock.get("validation_status") != "PASSED":
        violations.append("validation_status must be PASSED")
    for field in ("requirements_fingerprint", "plan_fingerprint", "validation_report_fingerprint"):
        if not str(lock.get(field) or "").strip():
            violations.append(f"{field} must be non-empty")

    expected_manifest = manifest_fingerprint(lock)
    if lock.get("manifest_fingerprint") != expected_manifest:
        violations.append("manifest_fingerprint does not match the lock content")
    inner = {key: value for key, value in lock.items() if key not in {"pipeline_hash", "pipeline_version", "manifest_fingerprint"}}
    if lock.get("pipeline_hash") != manifest_fingerprint(inner):
        violations.append("pipeline_hash does not match the locked payload")

    contract = lock.get("production_input_contract")
    if not isinstance(contract, dict) or not contract.get("binding_mode") or not isinstance(contract.get("bindings"), dict):
        violations.append("production_input_contract must declare a binding_mode and bindings")

    steps = lock.get("steps")
    if not isinstance(steps, list) or not steps:
        violations.append("steps must be a non-empty list")
    else:
        seen: set[str] = set()
        for index, step in enumerate(steps):
            where = f"steps[{index}]"
            if not isinstance(step, dict):
                violations.append(f"{where} is not a mapping")
                continue
            for field in REQUIRED_STEP_FIELDS:
                if field not in step:
                    violations.append(f"{where}: missing field {field}")
            step_id = str(step.get("step_id") or "")
            if not step_id:
                violations.append(f"{where}: step_id must be non-empty")
            elif step_id in seen:
                violations.append(f"{where}: duplicate step_id {step_id!r}")
            seen.add(step_id)
            executable = str(step.get("absolute_executable") or "")
            if not executable or not Path(executable).is_absolute():
                violations.append(f"{where}: absolute_executable must be an absolute path")
            prefix = step.get("environment_prefix")
            if prefix is not None and not Path(str(prefix)).is_absolute():
                violations.append(f"{where}: environment_prefix must be absolute or null")
            template = step.get("command_template")
            if not isinstance(template, list) or not template:
                violations.append(f"{where}: command_template must be a non-empty list")
            if not isinstance(step.get("input_template"), dict):
                violations.append(f"{where}: input_template must be a mapping")
            if not isinstance(step.get("output_template"), dict) or not step.get("output_template"):
                violations.append(f"{where}: output_template must be a non-empty mapping")
            if not isinstance(step.get("database_path"), dict):
                violations.append(f"{where}: database_path must be a mapping")
            if not isinstance(step.get("parameter_list"), list):
                violations.append(f"{where}: parameter_list must be a list")
            if not isinstance(step.get("failure_criteria"), list):
                violations.append(f"{where}: failure_criteria must be a list")
            if not isinstance(step.get("success_assertions"), list):
                violations.append(f"{where}: success_assertions must be a list")
            elif not step.get("success_assertions") and not step.get("script_template"):
                # Script-mode steps are exit-code verified; argv steps must assert outputs.
                violations.append(f"{where}: success_assertions must be a non-empty list")
            if not isinstance(step.get("dependencies"), list):
                violations.append(f"{where}: dependencies must be a list")
            validation = step.get("validation")
            if not isinstance(validation, dict) or not isinstance(validation.get("source_attempt"), int):
                violations.append(f"{where}: validation.source_attempt must reference a ledger attempt")
    if violations:
        raise LockValidationError("pipeline lock schema violations: " + "; ".join(violations))
    return lock
