"""Study-design requirements and a checked conversation-to-plan boundary."""

from __future__ import annotations

import json
from copy import deepcopy

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage

from microbiome.pipeline.errors import ConfigurationError
from microbiome.pipeline.models import REQUIRED_STEP_FIELDS, validate_experiment_plan


class StudyCompilationError(ConfigurationError):
    """An internal candidate-format failure, distinct from missing user facts."""

    category = "INTERNAL_PLAN_COMPILATION"

    def __init__(self, error, *, candidate, attempts, diagnostics_path=None):
        self.last_error = str(error)
        self.candidate = candidate
        self.attempts = attempts
        self.diagnostics_path = str(diagnostics_path) if diagnostics_path is not None else None
        self.candidate_available = bool(candidate)
        super().__init__(
            f"内部方案编译未通过格式检查（{attempts} 次）：{error}。"
            "这是候选方案的格式问题，无需重新描述分析目标；可继续修复保留的候选。"
        )


def compiler_schema():
    """Machine-readable output shape, using the authoritative step field list.

    This is a generation contract, not a replacement for semantic validation.
    The existing plan validator and caller's input/resource checks always run.
    """
    nonempty_string = {"type": "string", "minLength": 1}
    mapping = {"type": "object"}
    step = {
        "type": "object",
        "required": list(REQUIRED_STEP_FIELDS),
        "properties": {
            **dict.fromkeys(("step_id", "purpose", "tool", "tool_version_requirement"), nonempty_string),
            "software_family": nonempty_string,
            **{name: {"type": "array", "items": nonempty_string}
               for name in ("package_candidates", "required_packages", "channels")},
            "environment": {"anyOf": [nonempty_string, {"type": "object", "minProperties": 1}]},
            "input": {"type": "object", "additionalProperties": {"type": "string"}},
            "output": {"type": "object", "minProperties": 1,
                       "additionalProperties": {"type": "string", "pattern": "\\{run_dir\\}"}},
            "database": {"type": "object", "description": "Always present; use {} only when no database is used."},
            "command_template": {"type": "array", "minItems": 1,
                                 "prefixItems": [{"const": "{executable}"}], "items": nonempty_string},
            "parameters": {"type": ["object", "array"]},
            "success_criteria": {"type": "array", "minItems": 1,
                                 "items": {"type": ["string", "object"]}},
            "failure_criteria": {"type": "array", "items": {"type": ["string", "object"]}},
            "dependencies": {"type": "array", "items": nonempty_string},
            "threads_policy": {"type": "object", "properties": {
                key: {"type": "integer", "minimum": 1} for key in ("min", "max", "default")}},
            "memory_policy": mapping,
            "gpu_policy": {"type": "object", "properties": {"enabled": {"type": "boolean"}}},
        },
    }
    return {
        "type": "object",
        "required": ["requirements", "plan", "comparative_analysis", "research_query"],
        "properties": {
            "requirements": {"type": "object", "required": ["input", "dataset", "target", "analysis_goal"],
                             "properties": {key: {"type": "object", "minProperties": 1}
                                            for key in ("input", "dataset", "target", "analysis_goal")}},
            "comparative_analysis": {"type": "boolean"},
            "research_query": nonempty_string,
            "plan": {"type": "object", "required": ["objective", "steps", "deliverables"], "properties": {
                "objective": nonempty_string,
                "workflow_ids": {"type": "array", "items": nonempty_string},
                "workflow_decisions": {"type": "array", "items": {
                    "type": "object", "required": ["workflow_id", "disposition", "reason", "step_ids"],
                    "properties": {"workflow_id": nonempty_string, "reason": nonempty_string,
                                   "disposition": {"enum": ["use", "adapt", "not_applicable"]},
                                   "step_ids": {"type": "array", "items": nonempty_string}}}},
                "steps": {"type": "array", "minItems": 1, "items": step},
                "deliverables": {"type": "array", "minItems": 1, "items": {
                    "type": "object", "required": ["name", "step_id", "output", "purpose"],
                    "properties": dict.fromkeys(("name", "step_id", "output", "purpose"), nonempty_string)}},
            }},
        },
    }


def _database_reference(value):
    if isinstance(value, str):
        return "database." in value
    if isinstance(value, dict):
        return any("database" in str(key).casefold() or str(key).casefold() == "db"
                   or str(key).casefold().startswith("db_") or _database_reference(item)
                   for key, item in value.items())
    if isinstance(value, list):
        return any(_database_reference(item) for item in value)
    return False


def _normalize_candidate(payload):
    """Supply only an unused empty container; never fabricate resource facts."""
    checked = deepcopy(payload)
    plan = checked.get("plan")
    normalized = []
    if isinstance(plan, dict) and isinstance(plan.get("steps"), list):
        for index, step in enumerate(plan["steps"]):
            if isinstance(step, dict) and "database" not in step and not _database_reference(step):
                step["database"] = {}
                normalized.append(f"plan.steps[{index}].database={{}} (no database namespace references)")
    return checked, normalized


def _shape_errors(payload):
    """Report missing fields across every step, instead of fixing one per call."""
    plan = payload.get("plan") if isinstance(payload, dict) else None
    steps = plan.get("steps") if isinstance(plan, dict) else None
    if not isinstance(steps, list):
        return []
    return [f"plan.steps[{index}] missing required fields: {', '.join(missing)}"
            for index, step in enumerate(steps) if isinstance(step, dict)
            if (missing := [name for name in REQUIRED_STEP_FIELDS if name not in step])]



def _dependency_report(payload):
    """Expose the whole graph to repair, without guessing or changing edges."""
    plan = payload.get("plan") if isinstance(payload, dict) else None
    steps = plan.get("steps") if isinstance(plan, dict) else None
    if not isinstance(steps, list):
        return {}
    ids = [s.get("step_id") for s in steps if isinstance(s, dict) and isinstance(s.get("step_id"), str)]
    declared = set(ids)
    edges = []
    for step in steps:
        if not isinstance(step, dict):
            continue
        deps = step.get("dependencies", [])
        if isinstance(deps, list):
            edges.extend({"step_id": step.get("step_id"), "missing_dependency": dep}
                         for dep in deps if isinstance(dep, str) and dep not in declared)
    return {"declared_step_ids": ids, "unknown_dependencies": edges,
            "duplicate_step_ids": sorted(key for key in declared if ids.count(key) > 1)}


def _step_validation_report(payload):
    """Collect independent step defects using the same validator, for feedback only.

    Edges are checked separately in the full graph. Removing them from each
    temporary one-step probe must never affect the candidate or acceptance.
    """
    plan = payload.get("plan") if isinstance(payload, dict) else None
    if not isinstance(plan, dict) or not isinstance(plan.get("steps"), list):
        return []
    issues = []
    for index, step in enumerate(plan["steps"]):
        if not isinstance(step, dict):
            continue
        probe = deepcopy(plan)
        probe["steps"] = [{**deepcopy(step), "dependencies": []}]
        try:
            validate_experiment_plan(probe)
        except (ConfigurationError, ValueError, TypeError, AttributeError, KeyError) as error:
            issues.append({"step_index": index, "step_id": step.get("step_id"), "error": str(error)})
    return issues

def validate_study(payload: dict) -> dict:
    if not isinstance(payload, dict):
        raise ConfigurationError("study design must be an object")
    questions = payload.get("questions", [])
    if questions:
        raise ConfigurationError("; ".join(str(question) for question in questions))
    if type(payload.get("comparative_analysis", False)) is not bool:
        raise ConfigurationError("comparative_analysis must be a JSON boolean: true or false.")
    requirements = payload.get("requirements", {})
    for name in ("input", "dataset", "target", "analysis_goal"):
        if not isinstance(requirements.get(name), dict) or not requirements[name]:
            raise ConfigurationError(f"study design is missing {name}")
    dataset = requirements["dataset"]
    if payload.get("comparative_analysis"):
        samples = dataset.get("sample_metadata", [])
        groups = {}
        for sample in samples:
            if not sample.get("sample_id") or not sample.get("group"):
                raise ConfigurationError("comparative analysis requires sample identifiers and groups")
            groups.setdefault(sample["group"], set()).add(sample.get("biological_replicate") or sample["sample_id"])
        if len(groups) < 2 or any(len(replicates) < 2 for replicates in groups.values()):
            raise ConfigurationError("comparative inference requires an explicit design with biological replication")
        if not dataset.get("statistical_design") or not dataset.get("multiple_testing"):
            raise ConfigurationError("comparative inference requires a statistical design and multiple-testing policy")
        if payload.get("plan", {}).get("execution_scope") != "cohort":
            raise ConfigurationError("组间统计需要 execution_scope=cohort 的全样本输入适配流程")
    plan = validate_experiment_plan({**payload.get("plan", {}), "validation_strategy": "manifest_cases"})
    deliverables = plan.get("deliverables")
    if not isinstance(deliverables, list) or not deliverables:
        raise ConfigurationError("study design requires explicit deliverables")
    steps = {step["step_id"]: step for step in plan["steps"]}
    for item in deliverables:
        step = steps.get(item.get("step_id")) if isinstance(item, dict) else None
        if not step or item.get("output") not in step["output"] or not item.get("purpose"):
            raise ConfigurationError("every deliverable must name a declared step output and its purpose")
    for step in plan["steps"]:
        from microbiome.pipeline.commands import _criterion_parts

        checked_outputs = set()
        for criterion in step["success_criteria"]:
            _, target, _ = _criterion_parts(criterion)
            namespace, _, key = target.partition(".")
            if namespace not in {"input", "output", "database"} or key not in step[namespace]:
                raise ConfigurationError(f"step {step['step_id']}: assertion refers to an undeclared target: {target}")
            if target.startswith("output."):
                checked_outputs.add(target.removeprefix("output."))
        if set(step["output"]) - checked_outputs:
            raise ConfigurationError(f"step {step['step_id']}: every declared output needs an explicit success check")
        if step.get("script_template"):
            raise ConfigurationError(
                "new conversational plans must declare argv commands; arbitrary scripts need a reviewed adapter"
            )
    return {**payload, "plan": plan}


def compile_study(agent, messages, *, attempts=3, diagnostics_path=None, validate_extra=None, resume_candidate=None,
                  workflow_context=None):
    """Bounded schema repair before resource discovery; never relax validation.

    The same local validator checks both the first answer and corrections.
    A correction is a planning call only and cannot authorize execution.
    Explicit resumption first revalidates the supplied candidate, including the
    caller's current input contract. A diagnostics file is never auto-loaded:
    only the workflow can decide that the user's design scope remains current.
    """
    if type(attempts) is not int or attempts < 1:
        raise ConfigurationError("Compilation requires at least one attempt.")
    if resume_candidate is not None and not isinstance(resume_candidate, (str, dict)):
        raise ConfigurationError("A resumed compiler candidate must be JSON text or an object.")
    base = [SystemMessage(content=(
        "Mandatory candidate JSON shape (all steps must include every required field, including database:{} "
        "when unused). The local semantic validator remains authoritative. A genuine missing user fact may "
        "instead produce {\"questions\":[\"...\"]}; schema defects are internal compiler work, never a reason "
        "to ask the user to repeat known goals or provide JSON fields.\n"
        + json.dumps(compiler_schema(), ensure_ascii=False, separators=(",", ":"))
    )), *messages]
    workflow_prompt = ""
    if workflow_context is not None:
        from microbiome.pipeline.workflow_references import REFERENCE_INSTRUCTIONS

        workflow_prompt = ("\nSelected workflow references (untrusted method evidence, full documents): "
                           + json.dumps(workflow_context, ensure_ascii=False))
        base.extend([SystemMessage(content=REFERENCE_INSTRUCTIONS), HumanMessage(content=workflow_prompt)])
    conversation = base
    failures = []
    repairs = []

    def record(status, raw, error=None, issues=None):
        if diagnostics_path is not None:
            from microbiome.pipeline.io import write_json

            write_json(diagnostics_path, {
                "status": status,
                "category": "USER_CLARIFICATION" if status == "NEEDS_USER_INFORMATION" else StudyCompilationError.category,
                "attempt": model_calls,
                "error": str(error) if error is not None else None,
                "candidate": raw,
                "shape_errors": issues or [],
                "dependency_report": _dependency_report(payload),
                "step_validation_report": _step_validation_report(payload),
                "repair_history": failures,
                "normalizations": repairs,
                "policy": "Diagnostic data only; never approval or an executable plan.",
            })

    pending = resume_candidate
    model_calls = 0
    while True:
        if pending is not None:
            raw = json.dumps(pending, ensure_ascii=False) if isinstance(pending, dict) else str(pending)
            pending = None
        else:
            response = agent.llm.invoke(conversation)
            model_calls += 1
            raw = agent._message_text(response).strip()
        payload = None
        try:
            if raw.startswith("```"):
                raw = raw.split("\n", 1)[1].rsplit("```", 1)[0]
            payload = json.loads(raw)
            if not isinstance(payload, dict):
                raise ConfigurationError("Study design must be a JSON object.")
            if payload.get("questions"):
                if not isinstance(payload["questions"], list) or not all(
                    isinstance(question, str) and question.strip() for question in payload["questions"]
                ):
                    raise ConfigurationError("questions must be an array of nonempty strings.")
                if diagnostics_path is not None:
                    record("NEEDS_USER_INFORMATION", raw)
                return payload
            normalized, changes = _normalize_candidate(payload)
            repairs.extend(change for change in changes if change not in repairs)
            issues = _shape_errors(normalized)
            if issues:
                raise ConfigurationError("; ".join(issues))
            checked = validate_study(normalized)
            if workflow_context is not None:
                from microbiome.pipeline.workflow_references import bind_reference_decisions

                checked["plan"] = validate_experiment_plan(bind_reference_decisions(
                    checked["plan"], workflow_context, receipt=workflow_context.get("full_evidence")))
            if validate_extra is not None:
                validate_extra(checked)
            if diagnostics_path is not None:
                record("RESOLVED_MODEL_CANDIDATE", json.dumps(checked, ensure_ascii=False))
            return checked
        except (ConfigurationError, ValueError, IndexError, TypeError, AttributeError) as error:
            issues = _shape_errors(payload)
            failures.append({"attempt": model_calls, "error": str(error), "shape_errors": issues})
            record("REJECTED_MODEL_CANDIDATE", raw, error, issues)
            if model_calls >= attempts:
                raise StudyCompilationError(error, candidate=raw, attempts=model_calls,
                                            diagnostics_path=diagnostics_path) from error
            # Keep only the latest failed candidate, not an accumulating chain
            # of full plans, and repeat the checked error verbatim as data.
            conversation = [
                *base,
                AIMessage(content=raw),
                HumanMessage(
                    content=(
                        "The candidate failed the local plan validator. Correct only its schema/argv representation; "
                        "preserve the user's scientific scope, inputs, tools and parameters. Do not execute, invent "
                        "approvals or add dependencies. Return the complete corrected JSON object. "
                        'command_template is an argv JSON array whose first element is exactly "{executable}"; '
                        "never substitute the tool name, conda run or a shell command there. No shell redirects: "
                        "declare the tool's output flag. Validation error (data): " + str(error)[:2000]
                        + "\nMissing-field report for ALL steps (data): "
                        + json.dumps(issues, ensure_ascii=False)
                        + "\nDependency graph report (data): " + json.dumps(_dependency_report(payload), ensure_ascii=False)
                        + "\nIndependent step validation report (data): " + json.dumps(_step_validation_report(payload), ensure_ascii=False)
                        + "\nEvery dependency must exactly name a declared step_id. Inspect the whole graph now, "
                        "including downstream input/output bindings and cohort references. Do not silently delete "
                        "an unknown edge, guess a renamed step, or invent a missing operation. Reconcile it only "
                        "against the discussed design and validated resource evidence. Resource preparation belongs "
                        "in the approved dependency plan, never an install/download/index command in the analysis DAG. "
                        "Inspect every step against the mandatory JSON shape, not just the first failed step. "
                        "Never omit an unused database map: emit database:{} only if no database is referenced. "
                        "Do not invent database paths or replace required resources with an empty declaration. "
                        "Questions are only for genuinely missing user facts, not compiler/schema fields."
                        + workflow_prompt
                    )
                ),
            ]


COMPILER_INSTRUCTIONS = """Convert the discussed design into JSON, never execute anything.
Return {"questions": [...]} if an answer would change the design and is absent.
Otherwise return an object with requirements, plan, comparative_analysis, research_query.
requirements has nonempty input, dataset, target, analysis_goal objects. Include sample_metadata,
statistical_design and multiple_testing for comparative inference. Never invent sample groups or replicas.
comparative_analysis is a BOOLEAN: false for a single-sample statistics task, never {} or a string.
The requirements keys are nested OBJECTS, never strings or lists. Shape example only:
"requirements": {"input": {"type": "single_end"}, "dataset": {"sample_count": 1},
"target": {"scope": "user's stated target"}, "analysis_goal": {"objective": "user's stated objective"}}.
Replace these example values with actual user facts. All four objects are mandatory even for a tiny engineering test.
research_query is a bibliographic methods query containing no private sample identifiers or local paths.
If the user supplies an explicit research keyword/query, use it exactly; do not add constraints.
Otherwise use a short software/method query, not a long description of the particular test dataset.
plan has objective, deliverables (list of {name, step_id, output, purpose}), and steps.
Every dependencies entry must exactly match a step_id declared in this same plan.steps array.
Check all dependency references, duplicate IDs and cycles before returning the complete plan.
Resource preparation is not an analysis step; bind validated persistent resource entrypoints instead.
Never leave dangling dependencies after removing or renaming a candidate step.
Each deliverable's output is the bare OUTPUT MAP KEY, NOT a filename, path, template or output.KEY.
For a step with step_id="stats_step" and output={"stats":"{run_dir}/stats.tsv"}, the deliverable is
{"name":"sequence statistics", "step_id":"stats_step", "output":"stats", "purpose":"inspect read statistics"}.
Each step has step_id, purpose, tool, tool_version_requirement, environment (name/prefix,
executable, packages, channels), input and output maps, database map, command_template (argv
starting with {executable}), parameters, success_criteria, failure_criteria, dependencies,
threads_policy {min:1,max:1,default:1}, memory_policy {max_gb:1}, gpu_policy {enabled:false}.
For newly discovered software, keep software_family, package_candidates (alternative packages),
required_packages (additional required dependencies) and channels as separate step fields.
Use verified metadata/help or official packaging evidence, never guess a package mapping from a tool name.
environment can declare name/prefix/install_prefix, executable, version_args and help_args when known.
A suggested environment name is not an instruction to install: all existing environments must be searched
first. Actual executable and Conda prefix are resolved by the application and frozen after validation.
Missing Skill documentation does not prove software absence. New installation requirements must be
included in the dependency plan and confirmed before BOOTSTRAP/PRETEST_REPAIR; never install in production.
command_template is a JSON array, e.g. ["{executable}", "stats", "-a", "-T", "-o", "{output.stats}", "{input.reads}"].
Its first item is LITERALLY "{executable}", never a tool name/path or "conda".
Use native output flags: shell redirects, pipes, wrappers and command strings are forbidden.
Input/output map values are path strings, not nested objects; refer to their keys with {input.NAME}/{output.NAME}.
Use real resource budgets, not the example budgets. Multithreading needs a {threads} argument.
Inputs use {runtime.reads}, {runtime.reads_1}/{runtime.reads_2} or {runtime.fasta}; output
paths MUST be under {run_dir}. Downstream input paths reference the same {run_dir} outputs.
For reads use e.g. "input":{"reads":"{runtime.reads}"}, never the original FASTQ absolute path;
the runner must bind the sampled inputs during pretest and full inputs during production.
success_criteria includes exists:output.NAME, non_empty:output.NAME and an appropriate
{type:parseable,target:output.NAME,format:FORMAT} when the format is supported.
success_criteria and failure_criteria are JSON ARRAYS, never mappings. Example:
"success_criteria":["exists:output.stats", "non_empty:output.stats", {"type":"parseable","target":"output.stats","format":"tsv"}],
"failure_criteria":["nonzero_exit"]. Replace stats with your declared output key; format names are lowercase.
Database declarations contain logical_name, root_path, runtime_entry, expected_markers,
version and supported_tools, based only on actual resource evidence. No install/download/index
commands in the analysis DAG. Do not invent missing package mappings, references or evidence.
Keep scientific choices identical to the visible plan. Return JSON only, without fences.
For cross-sample analysis set plan.execution_scope="cohort" and mark each step.scope as
"sample" (run once per sample) or "cohort" (run once after all sample dependencies).
Cohort command argv can contain a standalone {cohort.STEP_ID.OUTPUT_NAME} token, expanded
to all per-sample output paths; {cohort.sample_ids} expands to aligned sample IDs.
{cohort.reads}, {cohort.reads_1}, {cohort.reads_2}, {cohort.fasta} expand raw input paths.
Declare a real, reviewed adapter; do not invent scripts. Cohort metadata and statistical
parameters must be explicit frozen parameters. All samples participate in the pilot with
reduced reads; biological sample count is never reduced for fitting statistical models.
"""
