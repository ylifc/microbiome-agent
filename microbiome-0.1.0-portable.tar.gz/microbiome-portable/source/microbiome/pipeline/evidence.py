"""Auditable local/official evidence records used by pipeline planning."""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from microbiome.pipeline.io import object_fingerprint, read_yaml, write_yaml

if TYPE_CHECKING:
    from microbiome.pipeline.project import PipelineProject


def _utcnow() -> str:
    return datetime.now(UTC).isoformat()


class EvidenceManager:
    def __init__(self, project: PipelineProject):
        self.project = project
        self.path = project.plans_dir / "evidence_registry.yaml"
        self.repository_root = Path(__file__).resolve().parents[2]

    def load(self) -> dict[str, Any]:
        if not self.path.is_file():
            return {
                "schema_version": 1,
                "external_evidence_status": "not_requested",
                "sources": [],
            }
        value = read_yaml(self.path)
        return value if isinstance(value, dict) else {"schema_version": 1, "sources": []}

    def collect_local_plan_evidence(self, plan: dict[str, Any]) -> dict[str, Any]:
        value = self.load()
        existing = {
            (item.get("source"), str(item.get("supports_step")))
            for item in value.get("sources", [])
            if isinstance(item, dict)
        }
        sources = list(value.get("sources", []))
        for step in plan.get("steps", []):
            tool_name = Path(str(step["tool"])).name.casefold()
            candidates = (
                self.project.knowledge_dir / "tools" / tool_name / "tool_profile.yaml",
                self.project.resource_skills_dir / "software" / tool_name / "SKILL.md",
                self.repository_root / "software_memory" / f"{tool_name}.md",
                self.repository_root / "microbiome" / "resource_skills" / "software" / tool_name / "SKILL.md",
            )
            available = [path.resolve() for path in candidates if path.is_file()]
            if available:
                for path in available:
                    key = (str(path), step["step_id"])
                    if key in existing:
                        continue
                    sources.append(
                        {
                            "kind": "local_documentation",
                            "source": str(path),
                            "title": path.name,
                            "read_scope": "document",
                            "review_status": "retrieved",
                            "content_fingerprint": object_fingerprint(path.read_text(encoding="utf-8")),
                            "accessed_at": _utcnow(),
                            "relevant_finding": "local tool contract and known working/failure guidance",
                            "supports_step": step["step_id"],
                        }
                    )
                    existing.add(key)
            else:
                key = (f"local-doc-unavailable:{tool_name}", step["step_id"])
                if key not in existing:
                    sources.append(
                        {
                            "kind": "local_documentation_status",
                            "source": key[0],
                            "title": tool_name,
                            "accessed_at": _utcnow(),
                            "relevant_finding": "no repository-local document was found; do not claim it was read",
                            "supports_step": step["step_id"],
                        }
                    )
                    existing.add(key)
        payload = {
            "schema_version": 1,
            "external_evidence_status": value.get("external_evidence_status", "not_requested"),
            "sources": sources,
            "updated_at": _utcnow(),
        }
        payload["evidence_fingerprint"] = object_fingerprint(
            {key: item for key, item in payload.items() if key != "evidence_fingerprint"}
        )
        write_yaml(self.path, payload)
        return payload

    def record_external_status(self, status: str, sources: list[dict[str, Any]] | None = None) -> dict[str, Any]:
        if status not in {"available", "unavailable", "not_requested", "no_results"}:
            raise ValueError("external evidence status must be available, unavailable, or not_requested")
        value = self.load()
        value["external_evidence_status"] = status
        if sources:
            value.setdefault("sources", []).extend(sources)
        value["updated_at"] = _utcnow()
        value["evidence_fingerprint"] = object_fingerprint(
            {key: item for key, item in value.items() if key != "evidence_fingerprint"}
        )
        write_yaml(self.path, value)
        return value

    def record_search(self, result: dict[str, Any]) -> dict[str, Any]:
        value = self.record_external_status(result["status"], result.get("sources"))
        value.setdefault("searches", []).append({key: item for key, item in result.items() if key != "sources"})
        value["evidence_fingerprint"] = object_fingerprint(
            {key: item for key, item in value.items() if key != "evidence_fingerprint"})
        write_yaml(self.path, value)
        return value
