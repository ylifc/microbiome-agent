"""Deterministic execution of database acquisitions approved during planning."""

from __future__ import annotations

import argparse
import ast
import hashlib
import inspect
import json
import os
import shlex
import subprocess
import tarfile
import time
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import requests
from tqdm import tqdm

from microbiome.progress import OperationInfo, emit_progress, infer_operation, print_progress, progress_event
from microbiome.proxy_config import download_env, download_env_plans, session_for, strip_proxy_env, transport_plans
from microbiome.resource_skills.registry import PROJECT_ROOT, ResourceSkillRegistry


@dataclass
class AcquisitionCommandResult:
    """Result of one environment, acquisition, or localization command."""

    command: str
    returncode: int
    stdout: str = ""
    stderr: str = ""
    duration_seconds: float = 0.0
    attempts: int = 1


@dataclass
class DatabaseAcquisitionResult:
    """Final preparation state for one database resource."""

    resource_id: str
    success: bool
    status: str
    path: str
    message: str
    commands: list[AcquisitionCommandResult] = field(default_factory=list)
    missing: list[str] = field(default_factory=list)
    manifest: str | None = None


@dataclass(frozen=True)
class DatabaseAcquisitionPreview:
    """Commands that confirmation authorizes for one resource."""

    resource_id: str
    commands: tuple[str, ...]
    blocked_reason: str | None = None


def _safe_extract_tar(archive: Path, destination: Path) -> None:
    """Extract an archive without accepting traversal paths or archive links."""
    destination = destination.resolve()
    destination.mkdir(parents=True, exist_ok=True)
    with tarfile.open(archive, "r:*") as handle:
        for member in handle.getmembers():
            unresolved_target = destination / member.name
            target = unresolved_target.resolve()
            if target != destination and destination not in target.parents:
                raise ValueError(f"unsafe archive path: {member.name}")
            if member.issym():
                link_target = (unresolved_target.parent / member.linkname).resolve()
            elif member.islnk():
                link_target = (destination / member.linkname).resolve()
            else:
                continue
            if link_target != destination and destination not in link_target.parents:
                raise ValueError(f"unsafe archive link: {member.name} -> {member.linkname}")
        kwargs = {"filter": "data"} if "filter" in inspect.signature(handle.extractall).parameters else {}
        handle.extractall(destination, **kwargs)


def localize_registered_database(database_id: str, db_root: str | Path) -> str:
    """Run internal localization that cannot be expressed as one portable CLI."""
    root = Path(db_root).expanduser().resolve()
    database_id = database_id.lower()
    if database_id == "gtdbtk":
        database_dir = root / "gtdbtk"
        archive = database_dir / "gtdbtk_data.tar.gz"
        if not archive.is_file() or archive.stat().st_size == 0:
            raise FileNotFoundError(f"missing or empty GTDB-Tk archive: {archive}")
        marker = database_dir / ".biomni-extracted-gtdbtk"
        if not marker.is_file():
            _safe_extract_tar(archive, database_dir)
            marker.write_text(
                f"archive={archive.name}\nextracted_at={datetime.now(UTC).isoformat()}\n",
                encoding="utf-8",
            )
        return f"GTDB-Tk archive localized under {database_dir}"

    if database_id == "bakta":
        database_dir = root / "bakta"
        archive = database_dir / "db-light.tar.xz"
        if not archive.is_file() or archive.stat().st_size == 0:
            raise FileNotFoundError(f"missing or empty Bakta archive: {archive}")
        _safe_extract_tar(archive, database_dir)
        prepared = database_dir / "db-light"
        if not (prepared / "version.json").is_file():
            raise FileNotFoundError(f"Bakta archive did not create the expected database: {prepared}")

        embedded_amr = prepared / "amrfinderplus-db"
        embedded_latest = embedded_amr / "latest"
        shared_latest = root / "amrfinderplus" / "latest"
        shared_markers = ("version.txt", "database_format_version.txt", "AMRProt.fa", "AMR.LIB")
        shared_ready = shared_latest.is_dir() and all(
            (shared_latest / marker).is_file() and (shared_latest / marker).stat().st_size > 0
            for marker in shared_markers
        )
        if shared_ready:
            shared_release = shared_latest.resolve()
            embedded_amr.mkdir(parents=True, exist_ok=True)
            release_link = embedded_amr / shared_release.name
            relative_release = os.path.relpath(shared_release, embedded_amr)
            if release_link.is_symlink() or release_link.exists():
                if release_link.resolve() != shared_release:
                    raise FileExistsError(f"conflicting Bakta AMRFinderPlus release path: {release_link}")
            else:
                release_link.symlink_to(relative_release, target_is_directory=True)
            if embedded_latest.is_symlink() or embedded_latest.exists():
                if embedded_latest.resolve() != shared_release:
                    if embedded_latest.is_symlink():
                        embedded_latest.unlink()
                    else:
                        raise FileExistsError(f"conflicting Bakta AMRFinderPlus latest path: {embedded_latest}")
            if not embedded_latest.exists():
                embedded_latest.symlink_to(shared_release.name, target_is_directory=True)
            return f"Bakta archive localized under {prepared}; reused AMRFinderPlus {shared_release.name}"

        if not embedded_latest.is_dir():
            # 有代理/无代理都能下：auto 探测选择直连或归一化代理通道。
            environment = download_env()
            command = [
                shutil_which("conda") or "conda",
                "run",
                "-n",
                "microbiome",
                "--no-capture-output",
                "amrfinder_update",
                "--database",
                str(embedded_amr),
                "--force_update",
            ]
            completed = subprocess.run(command, env=environment, capture_output=True, text=True, check=False)
            if completed.returncode != 0:
                raise RuntimeError(
                    f"AMRFinderPlus localization failed with exit code {completed.returncode}: "
                    f"{(completed.stderr or completed.stdout)[-2000:]}"
                )
        return f"Bakta archive localized under {prepared}; prepared its AMRFinderPlus dependency"

    raise ValueError(f"no internal localizer is registered for {database_id}")


def _file_checksum(path: Path, algorithm: str, chunk_size: int = 8 << 20) -> str:
    digest = hashlib.new(algorithm)
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def download_file_with_resume(
    url: str,
    output: str | Path,
    expected_size: int | None = None,
    checksum: str | None = None,
    retries: int = 30,
    direct: bool = False,
    connect_timeout: int = 30,
    read_timeout: int = 120,
    accelerator: str = "auto",
    fallback_urls: list[str] | tuple[str, ...] | None = None,
    progress_callback=print_progress,
) -> dict[str, Any]:
    """Download a large file with Range resume, validation, and atomic completion."""
    target = Path(output).expanduser().resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    partial = target.with_name(f"{target.name}.part")
    aria2_control = partial.with_name(f"{partial.name}.aria2")
    source_urls = list(dict.fromkeys([url, *(fallback_urls or [])]))
    operation = OperationInfo(
        "download",
        f"下载数据库文件 {target.name} / Download database file {target.name}",
        "将已确认的数据库资源完整保存到指定目录\nSave the confirmed database resource completely to the target directory",
        "本地文件缺失、不完整或未通过大小/校验和验证\nA local file is missing, incomplete, or did not pass size/checksum verification",
        str(target),
    )

    def report(percent, *, status="running", detail=""):
        emit_progress(progress_callback, progress_event(percent, operation, status=status, detail=detail))
    algorithm = expected_digest = None
    if checksum:
        algorithm, separator, expected_digest = checksum.lower().partition(":")
        if not separator or algorithm not in hashlib.algorithms_available or not expected_digest:
            raise ValueError("checksum must use the form algorithm:hex-digest")

    def valid_complete_file(path: Path) -> bool:
        if not path.is_file():
            return False
        if expected_size is not None and path.stat().st_size != expected_size:
            return False
        return not expected_digest or _file_checksum(path, algorithm or "md5") == expected_digest

    if valid_complete_file(target):
        report(100, status="skipped", detail="目标文件已存在并通过完整性验证 / The target file already exists and passed integrity verification")
        return {
            "status": "READY",
            "path": str(target),
            "bytes": target.stat().st_size,
            "resumed": False,
            "checksum": checksum,
        }

    if target.is_file():
        target_size = target.stat().st_size
        can_resume = expected_size is None or target_size < expected_size
        if can_resume and (not partial.exists() or target_size > partial.stat().st_size):
            os.replace(target, partial)
        elif not can_resume:
            corrupt = target.with_name(f"{target.name}.invalid-{int(time.time())}")
            os.replace(target, corrupt)

    def finalize_download(attempts: int, engine: str) -> dict[str, Any]:
        current_size = partial.stat().st_size if partial.is_file() else 0
        if expected_size is not None and current_size != expected_size:
            raise OSError(f"incomplete transfer: received {current_size} of {expected_size} bytes")
        if expected_digest:
            observed = _file_checksum(partial, algorithm or "md5")
            if observed != expected_digest:
                corrupt = partial.with_name(f"{partial.name}.invalid-{int(time.time())}")
                os.replace(partial, corrupt)
                raise ValueError(
                    f"checksum mismatch for {target.name}: expected {expected_digest}, got {observed}; "
                    f"preserved as {corrupt}"
                )
        os.replace(partial, target)
        return {
            "status": "READY",
            "path": str(target),
            "bytes": target.stat().st_size,
            "resumed": resumed,
            "attempts": attempts,
            "checksum": checksum,
            "engine": engine,
        }

    if accelerator not in {"auto", "aria2", "requests"}:
        raise ValueError("accelerator must be auto, aria2, or requests")
    aria2 = shutil_which("aria2c") if accelerator in {"auto", "aria2"} else None
    if accelerator == "aria2" and not aria2:
        raise RuntimeError("aria2 accelerator was requested but aria2c is not installed")
    if aria2_control.exists() and not aria2:
        raise RuntimeError(
            f"segmented aria2 state exists at {aria2_control}; resume with aria2 instead of treating "
            "the sparse partial file as a contiguous HTTP download"
        )
    resumed = partial.is_file() and (aria2_control.exists() or partial.stat().st_size > 0)
    report(
        int(partial.stat().st_size * 100 / expected_size) if partial.is_file() and expected_size else 0,
        detail=f"来源：{source_urls[0]}；支持断点续传和完成后校验 / Source: {source_urls[0]}; supports resumable transfer and post-completion verification",
    )
    if aria2:
        command = [
            aria2,
            "--continue=true",
            "--max-connection-per-server=8",
            "--split=16",
            "--min-split-size=1M",
            "--file-allocation=none",
            "--auto-file-renaming=false",
            "--allow-overwrite=true",
            f"--max-tries={max(1, retries)}",
            "--retry-wait=5",
            f"--connect-timeout={connect_timeout}",
            f"--timeout={read_timeout}",
            "--summary-interval=30",
            "--console-log-level=notice",
            "--download-result=full",
            "--dir",
            str(target.parent),
            "--out",
            partial.name,
        ]
        if direct:
            command.append("--all-proxy=")
        if expected_digest:
            command.append(f"--checksum={algorithm}={expected_digest}")
        # aria2 treats multiple command-line URIs as mirrors of the same file.
        command.extend(source_urls)
        # 有代理/无代理都能下：direct 强制直连；否则按 auto 探测结果生成 env，
        # 多次进程尝试时在直连↔代理通道间轮换。
        environments = [strip_proxy_env()] if direct else download_env_plans(source_urls[0])
        for attempt in range(1, max(1, retries) + 1):
            environment = environments[(attempt - 1) % len(environments)]
            completed = subprocess.run(command, cwd=target.parent, env=environment, check=False)
            if completed.returncode == 0:
                result = finalize_download(attempt, "aria2")
                report(100, status="completed", detail="aria2 下载完成并通过完整性验证 / aria2 download completed and passed integrity verification")
                return result
            if attempt < max(1, retries):
                print(
                    f"aria2c stopped with exit code {completed.returncode}; preserving piece state and "
                    f"restarting ({attempt + 1}/{max(1, retries)})",
                    flush=True,
                )
                time.sleep(min(attempt * 5, 60))
        raise RuntimeError(
            f"aria2c failed after {max(1, retries)} process attempts; partial file retained at {partial}"
        )

    # 有代理/无代理都能下：direct 强制直连；否则按 auto 探测的首选通道下载，
    # 重试时在直连↔代理通道间轮换（session 不信任进程环境，代理显式注入）。
    plans = [("direct", None)] if direct else transport_plans(source_urls[0])
    user_agent = "Microbiome/1 database-acquisition (resumable download)"
    last_error: Exception | None = None

    for attempt in range(1, max(1, retries) + 1):
        transport = plans[(attempt - 1) % len(plans)]
        session = session_for(source_urls[(attempt - 1) % len(source_urls)], transport=transport)
        offset = partial.stat().st_size if partial.is_file() else 0
        headers = {"User-Agent": user_agent}
        if offset:
            headers["Range"] = f"bytes={offset}-"
        try:
            with session.get(
                source_urls[(attempt - 1) % len(source_urls)],
                headers=headers,
                stream=True,
                allow_redirects=True,
                timeout=(connect_timeout, read_timeout),
            ) as response:
                if response.status_code == 416 and expected_size is not None and offset == expected_size:
                    pass
                else:
                    response.raise_for_status()
                    append = offset > 0 and response.status_code == 206
                    if append:
                        content_range = response.headers.get("Content-Range", "")
                        if not content_range.startswith(f"bytes {offset}-"):
                            raise OSError(
                                f"server returned an unexpected Content-Range for offset {offset}: {content_range}"
                            )
                    elif offset:
                        offset = 0
                    mode = "ab" if append else "wb"
                    last_report = time.monotonic()
                    response_size = int(response.headers.get("Content-Length", 0) or 0)
                    total_bytes = expected_size or (offset + response_size if response_size else None)
                    with (
                        partial.open(mode) as handle,
                        tqdm(
                            total=total_bytes,
                            initial=offset,
                            unit="B",
                            unit_scale=True,
                            unit_divisor=1024,
                            desc=f"⏬ {target.name}"[:60],
                            dynamic_ncols=True,
                            mininterval=0.5,
                        ) as bar,
                    ):
                        last_percent = int(offset * 100 / total_bytes) if total_bytes else -1
                        for chunk in response.iter_content(chunk_size=1 << 20):
                            if not chunk:
                                continue
                            handle.write(chunk)
                            bar.update(len(chunk))
                            if total_bytes:
                                percent = min(99, int(handle.tell() * 100 / total_bytes))
                                if percent >= last_percent + 5:
                                    report(percent, detail=f"已接收 {handle.tell()}/{total_bytes} 字节 / Received {handle.tell()}/{total_bytes} bytes")
                                    last_percent = percent
                            if time.monotonic() - last_report >= 30:
                                current = handle.tell()
                                total = expected_size or "unknown"
                                print(
                                    f"download progress: {current}/{total} bytes (attempt {attempt})",
                                    flush=True,
                                )
                                last_report = time.monotonic()

            result = finalize_download(attempt, "requests")
            report(100, status="completed", detail="下载完成并通过大小/校验和验证 / Download completed and passed size/checksum verification")
            return result
        except ValueError:
            raise
        except (OSError, requests.RequestException) as error:
            last_error = error
            if attempt == max(1, retries):
                break
            print(
                f"download interrupted at {partial.stat().st_size if partial.exists() else 0} bytes: "
                f"{type(error).__name__}: {error}; retrying",
                flush=True,
            )
            current = partial.stat().st_size if partial.exists() else 0
            percent = int(current * 100 / expected_size) if expected_size else 0
            report(percent, status="retrying", detail=f"连接中断，保留断点；{type(error).__name__}: {error} / Connection interrupted; resume point preserved; {type(error).__name__}: {error}")
            time.sleep(min(attempt * 5, 60))
    raise RuntimeError(
        f"download failed after {max(1, retries)} attempts; partial file retained at {partial}: {last_error}"
    )


_CONTROLLED_DOWNLOAD_MODULES = {
    "download_reference_genome": "genome_retrieval",
    "download_reference_sequences": "sequence_retrieval",
    "download_virus_genomes": "genome_retrieval",
}


def _literal_download_call(command: str, function_name: str) -> dict[str, Any]:
    """Parse a controlled download_*(...) representation into literal keyword arguments."""
    expression = ast.parse(command, mode="eval").body
    if not isinstance(expression, ast.Call) or not isinstance(expression.func, ast.Name):
        raise ValueError("controlled acquisition must be a direct function call")
    if expression.func.id != function_name or expression.args:
        raise ValueError("unsupported controlled acquisition call")
    kwargs = {}
    for keyword in expression.keywords:
        if keyword.arg is None:
            raise ValueError("expanded keyword arguments are not allowed")
        kwargs[keyword.arg] = ast.literal_eval(keyword.value)
    if kwargs.get("approved") is not True:
        raise PermissionError("controlled acquisition call is not approved")
    return kwargs


class DatabaseAcquisitionRunner:
    """Execute only deterministic commands from a user-confirmed database plan."""

    def __init__(
        self,
        registry: ResourceSkillRegistry,
        project_root: str | Path = PROJECT_ROOT,
        timeout_seconds: int = 604_800,
        progress_callback=print_progress,
    ):
        self.registry = registry
        self.project_root = Path(project_root).expanduser().resolve()
        self.timeout_seconds = max(1, int(timeout_seconds))
        self.progress_callback = progress_callback

    def preview(self, resource_id: str, confirmed_plan: str) -> DatabaseAcquisitionPreview:
        """Return the exact commands that would be run, or a deterministic blocker."""
        approved = self.registry.planned_database_acquisitions(confirmed_plan)
        if resource_id not in approved:
            return DatabaseAcquisitionPreview(
                resource_id,
                (),
                f"confirmed plan does not authorize [{resource_id}]",
            )
        acquisition, localization = self.registry.database_execution_commands(
            resource_id, plan_text=confirmed_plan
        )
        if not acquisition:
            return DatabaseAcquisitionPreview(
                resource_id,
                (),
                "the database Skill does not provide a complete machine-executable acquisition command",
            )

        environment_commands = self.registry.database_environment_create_commands(
            resource_id, plan_text=confirmed_plan
        )
        unauthorized = [command for command in environment_commands if command not in confirmed_plan]
        if unauthorized:
            return DatabaseAcquisitionPreview(
                resource_id,
                (*environment_commands, *acquisition, *localization),
                "a required conda environment creation command was not included in the confirmed plan",
            )
        return DatabaseAcquisitionPreview(
            resource_id,
            (*environment_commands, *acquisition, *localization),
        )

    def _command_argv(self, command: str) -> list[str]:
        argv = shlex.split(command)
        if not argv:
            raise ValueError("empty acquisition command")
        if argv[0] in {"conda", "mamba", "micromamba"}:
            resolved = shutil_which(argv[0]) or shutil_which(self.registry.manager_command)
            if resolved:
                argv[0] = resolved
        return argv

    @staticmethod
    def _is_transient_failure(result: AcquisitionCommandResult) -> bool:
        output = f"{result.stdout}\n{result.stderr}".lower()
        return any(
            marker in output
            for marker in (
                "timed out",
                "timeout",
                "temporary failure",
                "temporarily unavailable",
                "connection reset",
                "connection aborted",
                "connection refused",
                "remote end closed",
                "network is unreachable",
                "unexpected eof",
                "tls error",
                "too slow",
                "could not download",
                "download failed",
                "http error 429",
                "http error 500",
                "http error 502",
                "http error 503",
                "http error 504",
            )
        )

    def _run_subprocess(self, command: str) -> AcquisitionCommandResult:
        attempts = 3
        last: AcquisitionCommandResult | None = None
        operation = infer_operation(command, target_hint=str(self.registry.db_root))
        for attempt in range(1, attempts + 1):
            emit_progress(
                self.progress_callback,
                progress_event(
                    0,
                    operation,
                    status="retrying" if attempt > 1 else "running",
                    detail=f"执行命令（尝试 {attempt}/{attempts}）：{command} / Running command (attempt {attempt}/{attempts}): {command}",
                ),
            )
            started = time.monotonic()
            try:
                completed = subprocess.run(
                    self._command_argv(command),
                    cwd=self.project_root,
                    env=os.environ.copy(),
                    capture_output=True,
                    text=True,
                    check=False,
                    timeout=self.timeout_seconds,
                )
                last = AcquisitionCommandResult(
                    command=command,
                    returncode=completed.returncode,
                    stdout=(completed.stdout or "")[-12_000:],
                    stderr=(completed.stderr or "")[-12_000:],
                    duration_seconds=round(time.monotonic() - started, 3),
                    attempts=attempt,
                )
            except subprocess.TimeoutExpired as error:
                last = AcquisitionCommandResult(
                    command=command,
                    returncode=124,
                    stdout=str(error.stdout or "")[-12_000:],
                    stderr=f"command timed out after {self.timeout_seconds} seconds",
                    duration_seconds=round(time.monotonic() - started, 3),
                    attempts=attempt,
                )
            except OSError as error:
                return AcquisitionCommandResult(
                    command=command,
                    returncode=127,
                    stderr=str(error),
                    duration_seconds=round(time.monotonic() - started, 3),
                    attempts=attempt,
                )
            if last.returncode == 0 or not self._is_transient_failure(last) or attempt == attempts:
                emit_progress(
                    self.progress_callback,
                    progress_event(
                        100,
                        operation,
                        status="completed" if last.returncode == 0 else "failed",
                        detail=f"命令退出码 {last.returncode}，耗时 {last.duration_seconds:.1f} 秒 / Command exit code {last.returncode}, took {last.duration_seconds:.1f} seconds",
                    ),
                )
                return last
            time.sleep(min(5 * attempt, 15))
        assert last is not None
        return last

    def _run_controlled_download(self, command: str, function_name: str) -> AcquisitionCommandResult:
        started = time.monotonic()
        operation = infer_operation(command, target_hint=str(self.registry.db_root))
        emit_progress(self.progress_callback, progress_event(0, operation, detail=f"受控下载函数：{function_name} / Controlled download function: {function_name}"))
        try:
            import importlib

            module = importlib.import_module(
                f"microbiome.tool.{_CONTROLLED_DOWNLOAD_MODULES[function_name]}"
            )
            function = getattr(module, function_name)
            output = function(**_literal_download_call(command, function_name))
            result = AcquisitionCommandResult(
                command=command,
                returncode=0,
                stdout=output[-12_000:],
                duration_seconds=round(time.monotonic() - started, 3),
            )
            emit_progress(
                self.progress_callback,
                progress_event(100, operation, status="completed", detail="下载函数执行成功并返回验证结果 / Download function executed successfully and returned the validation result"),
            )
            return result
        except Exception as error:
            result = AcquisitionCommandResult(
                command=command,
                returncode=1,
                stderr=f"{type(error).__name__}: {error}",
                duration_seconds=round(time.monotonic() - started, 3),
            )
            emit_progress(
                self.progress_callback,
                progress_event(100, operation, status="failed", detail=result.stderr[-1000:]),
            )
            return result

    def _run_command(self, command: str) -> AcquisitionCommandResult:
        for function_name in _CONTROLLED_DOWNLOAD_MODULES:
            if command.startswith(f"{function_name}("):
                return self._run_controlled_download(command, function_name)
        return self._run_subprocess(command)

    def _status(self, resource_id: str):
        skill_id, separator, consumer = resource_id.partition(":")
        return self.registry.database_status(skill_id, consumer if separator else None)

    def _write_manifest(
        self,
        resource_id: str,
        confirmed_plan: str,
        result: DatabaseAcquisitionResult,
    ) -> str:
        skill_id = resource_id.partition(":")[0]
        skill = self.registry.get_skill("database", skill_id)
        directory = self.registry.db_root / str(skill.metadata["folder"])
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / "microbiome-acquisition.json"
        temporary = directory / "microbiome-acquisition.json.part"
        payload = {
            "resource_id": resource_id,
            "status": result.status,
            "success": result.success,
            "completed_at": datetime.now(UTC).isoformat(),
            "confirmed_plan_sha256": hashlib.sha256(confirmed_plan.encode("utf-8")).hexdigest(),
            "path": result.path,
            "missing": result.missing,
            "message": result.message,
            "commands": [asdict(command) for command in result.commands],
        }
        temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(temporary, path)
        return str(path)

    def prepare(self, resource_id: str, confirmed_plan: str) -> DatabaseAcquisitionResult:
        """Acquire one approved database under an inter-process resource lock."""
        from microbiome.resource_skills.locking import resource_lock

        with resource_lock(
            self.registry.db_root,
            resource_id,
            timeout_seconds=min(self.timeout_seconds, 3600),
        ):
            # Another process may have completed the resource while this process
            # waited, so readiness is intentionally rechecked inside the lock.
            self.registry.reload()
            return self._prepare_locked(resource_id, confirmed_plan)

    def _prepare_locked(self, resource_id: str, confirmed_plan: str) -> DatabaseAcquisitionResult:
        """Acquire, localize, and revalidate one approved database."""
        initial = self._status(resource_id)
        skill_id = resource_id.partition(":")[0]
        skill = self.registry.get_skill("database", skill_id)
        if initial.status == "ready" and not skill.metadata.get("itemized"):
            return DatabaseAcquisitionResult(
                resource_id=resource_id,
                success=True,
                status="ready",
                path=initial.path or "",
                message="database became READY before acquisition; no command was needed",
            )

        preview = self.preview(resource_id, confirmed_plan)
        if preview.blocked_reason:
            return DatabaseAcquisitionResult(
                resource_id=resource_id,
                success=False,
                status="blocked",
                path=initial.path or "",
                message=preview.blocked_reason,
                missing=list(initial.missing),
            )

        acquisition, localization = self.registry.database_execution_commands(
            resource_id, plan_text=confirmed_plan
        )
        environment_commands = self.registry.database_environment_create_commands(
            resource_id, plan_text=confirmed_plan
        )
        results: list[AcquisitionCommandResult] = []

        for command in environment_commands:
            command_result = self._run_command(command)
            results.append(command_result)
            if command_result.returncode != 0:
                return self._finalize_failure(
                    resource_id,
                    confirmed_plan,
                    results,
                    f"environment preparation failed with exit code {command_result.returncode}",
                )
        if environment_commands:
            self.registry.reload()

        for command in acquisition:
            command_result = self._run_command(command)
            results.append(command_result)
            if command_result.returncode != 0:
                return self._finalize_failure(
                    resource_id,
                    confirmed_plan,
                    results,
                    f"database acquisition failed with exit code {command_result.returncode}",
                )

        self.registry.reload()
        status = self._status(resource_id)
        if status.status != "ready":
            for command in localization:
                command_result = self._run_command(command)
                results.append(command_result)
                if command_result.returncode != 0:
                    return self._finalize_failure(
                        resource_id,
                        confirmed_plan,
                        results,
                        f"database localization failed with exit code {command_result.returncode}",
                    )
            self.registry.reload()
            status = self._status(resource_id)

        success = status.status == "ready"
        result = DatabaseAcquisitionResult(
            resource_id=resource_id,
            success=success,
            status=status.status,
            path=status.path or "",
            message=(
                "download, localization, and readiness validation completed"
                if success
                else "commands completed but the database did not satisfy its readiness markers"
            ),
            commands=results,
            missing=list(status.missing),
        )
        try:
            result.manifest = self._write_manifest(resource_id, confirmed_plan, result)
        except OSError as error:
            result.success = False
            result.status = "manifest_error"
            result.message += f"; failed to write acquisition manifest: {error}"
        return result

    def _finalize_failure(
        self,
        resource_id: str,
        confirmed_plan: str,
        commands: list[AcquisitionCommandResult],
        message: str,
    ) -> DatabaseAcquisitionResult:
        self.registry.reload()
        status = self._status(resource_id)
        result = DatabaseAcquisitionResult(
            resource_id=resource_id,
            success=False,
            status=status.status,
            path=status.path or "",
            message=message,
            commands=commands,
            missing=list(status.missing),
        )
        try:
            result.manifest = self._write_manifest(resource_id, confirmed_plan, result)
        except OSError as error:
            result.message += f"; failed to write acquisition manifest: {error}"
        return result


def shutil_which(command: str) -> str | None:
    """Small indirection kept patchable in tests."""
    from shutil import which

    return which(command)


def _main() -> int:
    parser = argparse.ArgumentParser(description="Microbiome database acquisition helpers")
    subparsers = parser.add_subparsers(dest="command", required=True)
    localize = subparsers.add_parser("localize")
    localize.add_argument("--database", required=True)
    localize.add_argument("--db-root", required=True)
    download = subparsers.add_parser("download")
    download.add_argument("--url", required=True)
    download.add_argument("--output", required=True)
    download.add_argument("--expected-size", type=int)
    download.add_argument("--checksum")
    download.add_argument("--retries", type=int, default=30)
    download.add_argument("--direct", action="store_true")
    download.add_argument("--accelerator", choices=("auto", "aria2", "requests"), default="auto")
    download.add_argument("--fallback-url", action="append", default=[])
    args = parser.parse_args()
    if args.command == "localize":
        print(localize_registered_database(args.database, args.db_root))
        return 0
    if args.command == "download":
        result = download_file_with_resume(
            args.url,
            args.output,
            expected_size=args.expected_size,
            checksum=args.checksum,
            retries=args.retries,
            direct=args.direct,
            accelerator=args.accelerator,
            fallback_urls=args.fallback_url,
        )
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(_main())
