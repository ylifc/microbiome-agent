"""Generic, approval-gated discovery and learning for software and databases.

Registry answers *where* a resource is, Skill answers *how* to use it, and
Knowledge records what actually succeeded or failed.  None of these layers is a
substitute for a frozen production lock.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from microbiome.pipeline.errors import ConfigurationError, ResourceNotReadyError
from microbiome.pipeline.io import (
    atomic_write_text,
    canonical_path,
    manifest_fingerprint,
    read_yaml,
    write_yaml,
)
from microbiome.pipeline.registry import (
    find_registered_tool,
    load_database_registry,
    load_tool_registry,
    register_tool_binding,
    update_database_registry,
)
from microbiome.conda_discovery import find_conda_manager
from microbiome.pipeline.resources import DatabaseResolver, ToolchainResolver, database_fingerprint
from microbiome.pipeline.resources import _environment_spec, _looks_like_fatal_runtime_error, tool_environment
from microbiome.resource_skills.registry import (
    DEFAULT_CUSTOM_SKILL_ROOT,
    PACKAGE_SKILL_ROOT,
    ResourceSkill,
    ResourceSkillRegistry,
    _as_string_list,
    _default_database_instructions,
    _default_software_instructions,
    _validate_new_skill_id,
    _write_skill,
)

if TYPE_CHECKING:
    from collections.abc import Callable

    from microbiome.pipeline.knowledge import KnowledgeBase
    from microbiome.pipeline.project import PipelineProject


MUTABLE_PHASES = {"BOOTSTRAP", "PRETEST_REPAIR"}
PRODUCTION_PHASES = {"FROZEN", "PRODUCTION"}


def _utcnow() -> str:
    return datetime.now(UTC).isoformat()


def _normalized(value: str) -> str:
    return str(value).strip().casefold()


def _safe_id(value: str) -> str:
    normalized = re.sub(r"[^a-z0-9-]+", "-", value.casefold().replace("_", "-")).strip("-")
    if len(normalized) > 63:
        digest = hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:10]
        normalized = f"{normalized[:52].rstrip('-')}-{digest}"
    return _validate_new_skill_id(normalized or "unknown-tool")


def _append_jsonl(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor = os.open(path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o644)
    try:
        os.write(descriptor, (json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n").encode("utf-8"))
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


@dataclass(frozen=True)
class ToolBinding:
    logical_tool: str
    executable: str
    software_family: str
    environment_prefix: str | None
    environment_name: str | None
    version_output: str
    version_args: list[str]
    help_args: list[str]
    help_exit_code: int | None
    source: str
    status: str = "READY"
    skill_id: str | None = None
    skill_path: str | None = None
    help_path: str | None = None
    package_candidates: list[str] = field(default_factory=list)
    package_inventory: list[dict[str, Any]] = field(default_factory=list)
    family_executables: list[str] = field(default_factory=list)
    aliases: list[str] = field(default_factory=list)
    runtime_launcher: list[str] = field(default_factory=list)
    runtime_launcher_fingerprint: dict[str, Any] | None = None
    version_exit_code: int = 0
    installed: bool = False
    reused: bool = True
    validated_at: str = field(default_factory=_utcnow)
    installation_recipe: str | None = None

    def as_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload.update(
            {
                "tool": self.logical_tool,
                "validation_result": "PASSED",
                "installation_source": self.source,
            }
        )
        return payload


class ToolAliasRegistry:
    """Machine-readable mapping between logical names, packages, binaries and Skills."""

    def __init__(
        self,
        path: str | Path,
        skill_registry: ResourceSkillRegistry,
        *,
        mutable: bool,
    ):
        self.path = canonical_path(path)
        self.skill_registry = skill_registry
        self.mutable = mutable
        self.tools: dict[str, dict[str, Any]] = {}
        self.reload()

    def reload(self) -> None:
        stored: dict[str, Any] = {}
        if self.path.is_file():
            try:
                payload = read_yaml(self.path)
                if (
                    isinstance(payload, dict)
                    and isinstance(payload.get("tools"), dict)
                    and payload.get("manifest_fingerprint") == manifest_fingerprint(payload)
                ):
                    stored = payload["tools"]
            except Exception:
                # Alias data is an index, not a resource fact. Bootstrap may
                # reconstruct a damaged index from validated Skills.
                stored = {}
        self.tools = {str(key).casefold(): dict(value) for key, value in stored.items() if isinstance(value, dict)}
        owners = {}
        for skill in self.skill_registry.list_skills("software"):
            for name in [skill.skill_id, skill.name, str(skill.metadata.get("environment") or ""),
                         *skill.metadata.get("executables", []), *skill.metadata.get("aliases", [])]:
                owners.setdefault(_normalized(name), set()).add(skill.skill_id)
        self.ambiguous = {name for name, families in owners.items() if len(families) > 1}
        for name in self.ambiguous:
            self.tools.pop(name, None)
        changed = False
        for skill in self.skill_registry.list_skills("software"):
            record = self._from_skill(skill)
            names = {
                skill.skill_id,
                skill.name,
                str(skill.metadata.get("environment") or ""),
                *_as_string_list(skill.metadata.get("executables")),
                *_as_string_list(skill.metadata.get("aliases")),
            }
            for name in names:
                alias = _normalized(name)
                if not alias or alias in self.ambiguous:
                    continue
                if self.tools.get(alias) != record:
                    self.tools[alias] = dict(record)
                    changed = True
        if changed and self.mutable:
            self.save()

    @staticmethod
    def _from_skill(skill: ResourceSkill) -> dict[str, Any]:
        raw_version_args = skill.metadata.get("version_args")
        return {
            "software_family": str(skill.metadata.get("software_family") or skill.skill_id),
            "skill_id": skill.skill_id,
            "skill_path": str(skill.path),
            "environment": str(skill.metadata.get("environment") or ""),
            "executables": _as_string_list(skill.metadata.get("executables")),
            "package_candidates": _as_string_list(skill.metadata.get("packages")),
            "channels": _as_string_list(skill.metadata.get("channels")) or ["conda-forge", "bioconda"],
            "runtime": skill.metadata.get("runtime"),
            # None means "no declaration" (use the default probe list); an empty
            # list means "run the bare executable" (tool prints version without a flag).
            "version_args": None if raw_version_args is None else _as_string_list(raw_version_args),
            "help_args": skill.metadata.get("help_args"),
            "aliases": list(
                dict.fromkeys(
                    [
                        skill.skill_id,
                        skill.name,
                        *_as_string_list(skill.metadata.get("executables")),
                        *_as_string_list(skill.metadata.get("aliases")),
                    ]
                )
            ),
        }

    def resolve(self, logical_tool: str) -> dict[str, Any] | None:
        record = self.tools.get(_normalized(logical_tool))
        return dict(record) if record else None

    def register(self, binding: ToolBinding) -> None:
        if not self.mutable:
            return
        existing_records = [
            value for value in self.tools.values() if value.get("software_family") == binding.software_family
        ]
        existing_executables = [
            str(value) for record in existing_records for value in record.get("executables", []) or []
        ]
        existing_channels = [str(value) for record in existing_records for value in record.get("channels", []) or []]
        record = {
            "software_family": binding.software_family,
            "runtime": next((v.get("runtime") for v in existing_records if v.get("runtime")), None),
            "skill_id": binding.skill_id,
            "skill_path": binding.skill_path,
            "environment": binding.environment_name or "",
            "executables": list(
                dict.fromkeys([*existing_executables, *binding.family_executables, Path(binding.executable).name])
            ),
            "package_candidates": binding.package_candidates,
            "channels": list(dict.fromkeys(existing_channels)),
            "version_args": list(binding.version_args),
            "help_args": list(binding.help_args),
            "aliases": list(dict.fromkeys([binding.logical_tool, *binding.aliases, Path(binding.executable).name])),
        }
        for name in record["aliases"]:
            if name and _normalized(name) not in self.ambiguous:
                self.tools[_normalized(name)] = dict(record)
        self.save()

    def save(self) -> None:
        payload = {
            "schema_version": 1,
            "updated_at": _utcnow(),
            "tools": dict(sorted(self.tools.items())),
        }
        payload["manifest_fingerprint"] = manifest_fingerprint(payload)
        write_yaml(self.path, payload)


class CondaEnvironmentManager:
    """Bounded installer for approved dependencies; never mutates base or production."""

    def __init__(
        self,
        project_root: str | Path,
        *,
        knowledge: KnowledgeBase | None = None,
        max_install_attempts: int = 3,
        timeout_seconds: int = 7200,
        install_hook: Callable[[dict[str, Any], Path], str | Path | None] | None = None,
        history_root: str | Path | None = None,
    ):
        self.project_root = canonical_path(project_root)
        self.knowledge = knowledge
        self.max_install_attempts = max(1, int(max_install_attempts))
        self.timeout_seconds = max(1, int(timeout_seconds))
        self.install_hook = install_hook
        self.history_root = canonical_path(history_root or self.project_root / ".biomni" / "knowledge")
        self.manager = find_conda_manager()

    def install(
        self,
        request: dict[str, Any],
        *,
        phase: str,
        approved_tools: set[str],
    ) -> tuple[Path, str | None]:
        phase = phase.upper()
        logical_tool = str(request["logical_tool"])
        family = str(request["software_family"])
        approved = {_normalized(value) for value in approved_tools}
        if phase not in MUTABLE_PHASES:
            raise ConfigurationError(f"software installation is forbidden in phase {phase}")
        if _normalized(logical_tool) not in approved:
            raise ConfigurationError(
                f"unplanned dependency {logical_tool!r}; generate and approve a new dependency plan before install"
            )
        packages = list(dict.fromkeys(str(value) for value in request.get("package_candidates") or [] if value))
        if not packages:
            raise ResourceNotReadyError(
                f"{logical_tool}: no verified package mapping is available; dependency plan needs package_candidates"
            )
        recipe_path = ((self.knowledge._tool_dir(family) if self.knowledge is not None
                        else self.history_root / "tools" / _safe_id(family)) / "installation_recipe.yaml")
        if recipe_path.is_file():
            try:
                recipe = read_yaml(recipe_path).get("successful_installation", {})
                preferred = recipe.get("package") if recipe.get("validated") is True else None
                if preferred in packages:
                    packages = [preferred, *(package for package in packages if package != preferred)]
            except (OSError, ValueError, AttributeError):
                pass
        prefix = canonical_path(
            request.get("install_prefix") or self.project_root / ".biomni" / "envs" / _safe_id(family)
        )
        protected = {
            canonical_path(value) for name in ("CONDA_ROOT", "_CONDA_ROOT", "MAMBA_ROOT_PREFIX")
            if (value := os.environ.get(name))
        }
        if self.manager:
            manager_path = canonical_path(self.manager)
            if manager_path.parent.name in {"bin", "condabin", "Scripts"}:
                protected.add(manager_path.parent.parent)
        if prefix.name.casefold() in {"base", "root"} or prefix in protected:
            raise ConfigurationError("refusing to install software into base/root")
        if prefix.exists() and not (prefix / "conda-meta" / "history").is_file() and self.install_hook is None:
            raise ResourceNotReadyError(
                f"refusing to overwrite non-Conda directory selected as environment prefix: {prefix}"
            )
        for attempt_number, package in enumerate(packages[: self.max_install_attempts], start=1):
            started = _utcnow()
            if self.install_hook is not None:
                returned = self.install_hook({**request, "package": package, "attempt": attempt_number}, prefix)
                if returned:
                    prefix = canonical_path(returned)
                returncode, output, command = 0, "install hook completed", ["<install-hook>", package]
            else:
                if not self.manager:
                    raise ResourceNotReadyError("conda/mamba/micromamba is required for approved software installation")
                action = "install" if (prefix / "conda-meta" / "history").is_file() else "create"
                command = [self.manager, action, "-y", "-p", str(prefix)]
                for channel in request.get("channels") or ["conda-forge", "bioconda"]:
                    command.extend(["-c", str(channel)])
                command.extend(dict.fromkeys([package, *request.get("required_packages", [])]))
                try:
                    result = subprocess.run(
                        command,
                        cwd=self.project_root,
                        capture_output=True,
                        text=True,
                        timeout=self.timeout_seconds,
                        check=False,
                    )
                    returncode = result.returncode
                    output = "\n".join(part for part in (result.stdout, result.stderr) if part)[-20_000:]
                except (OSError, subprocess.TimeoutExpired) as error:
                    returncode, output = 124, f"{type(error).__name__}: {error}"
            executable = prefix / "bin" / str(request["executable_name"])
            executable_present = returncode == 0 and executable.is_file() and os.access(executable, os.X_OK)
            record = {
                "attempt": attempt_number,
                "started_at": started,
                "completed_at": _utcnow(),
                "method": "hook" if self.install_hook else Path(str(command[0])).name,
                "environment_prefix": str(prefix),
                "package": package,
                "channels": list(request.get("channels") or ["conda-forge", "bioconda"]),
                "command": command,
                "returncode": returncode,
                "output_excerpt": output[-4000:],
                "executable_present": executable_present,
                "validated": False,
                "status": "PENDING_VERSION_HELP_VALIDATION" if executable_present else "FAILED",
            }
            if self.knowledge is not None:
                self.knowledge.record_installation_attempt(family, record)
            else:
                _append_jsonl(
                    self.history_root / "tools" / _safe_id(family) / "installation_history.jsonl",
                    record,
                )
            if executable_present:
                return prefix, package
        raise ResourceNotReadyError(
            f"{logical_tool}: approved installation exhausted {min(len(packages), self.max_install_attempts)} attempts"
        )


class SoftwareSkillBuilder:
    """Build a schema-compatible Skill from an independently validated executable."""

    def __init__(self, skill_root: str | Path):
        self.skill_root = canonical_path(skill_root)

    @staticmethod
    def package_metadata(prefix: Path | None, executable_name: str) -> tuple[list[str], list[str]]:
        if prefix is None:
            return [], [executable_name]
        metadata_root = prefix / "conda-meta"
        if not metadata_root.is_dir():
            return [], [executable_name]
        for metadata_path in sorted(metadata_root.glob("*.json")):
            try:
                payload = json.loads(metadata_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            files = [str(value) for value in payload.get("files", [])]
            if f"bin/{executable_name}" not in files:
                continue
            executables = []
            for value in files:
                path = prefix / value
                if value.startswith("bin/") and "/" not in value[4:] and path.is_file() and os.access(path, os.X_OK):
                    executables.append(Path(value).name)
            return [str(payload.get("name"))] if payload.get("name") else [], executables or [executable_name]
        return [], [executable_name]

    def build(
        self,
        binding: ToolBinding,
        *,
        version_text: str,
        help_text: str,
        task_contract: dict | None = None,
    ) -> ResourceSkill:
        skill_id = _safe_id(binding.software_family)
        target = self.skill_root / "software" / skill_id
        metadata = {
            "name": binding.software_family,
            "description": f"Auto-learned usage contract for validated executable {Path(binding.executable).name}.",
            "kind": "software",
            "id": skill_id,
            "version": 2,
            "selection_tier": "established",
            "software_family": binding.software_family,
            "aliases": list(dict.fromkeys([binding.logical_tool, *binding.aliases])),
            "keywords": [],
            "environment": binding.environment_name or f"prefix-{skill_id}",
            "executables": list(dict.fromkeys(binding.family_executables or [Path(binding.executable).name])),
            "packages": binding.package_candidates,
            "version_args": binding.version_args,
            "help_args": binding.help_args,
            "discovered_executable": binding.executable,
            "channels": [],
            "tasks": [task_contract["purpose"]] if task_contract and task_contract.get("purpose") else [],
            "databases": [],
            "capabilities": [f"invoke the validated {Path(binding.executable).name} executable"],
            "inputs": list((task_contract or {}).get("input", {})),
            "outputs": list((task_contract or {}).get("output", {})),
            "documentation_status": "EXECUTABLE_PROBED",
            "task_contract_status": "PROPOSED_REQUIRES_OUTPUT_VALIDATION",
            "upstream": [],
            "downstream": [],
            "parameter_guidance": ["Use the locally captured help document; never infer flags from another tool."],
            "validation": ["Executable exists and version/help smoke tests pass before use."],
            "failure_handling": ["Consult Knowledge known_errors.jsonl and reuse VERIFIED fixes only."],
            "generated_from": "validated-installed-tool",
        }
        from microbiome.resource_skills.command_schema import schema_from_help, render_parameter_reference
        schema = schema_from_help(binding.executable, version_text, help_text)
        body = _default_software_instructions(metadata) + render_parameter_reference(schema)
        body += "\n## Local documentation\n\nSee `docs/version.txt` and `docs/help.txt`, captured from the validated executable.\n"
        existing = target / "SKILL.md"
        if existing.is_file():
            archive = target / f"SKILL.invalid.{datetime.now(UTC).strftime('%Y%m%dT%H%M%S%fZ')}.md"
            existing.replace(archive)
        _write_skill("software", skill_id, metadata, body, self.skill_root, overwrite=False)
        docs = target / "docs"
        atomic_write_text(docs / "version.txt", version_text.rstrip() + "\n")
        atomic_write_text(docs / "help.txt", help_text.rstrip() + "\n")
        write_yaml(target / "command_schema.yaml", schema)
        return ResourceSkillRegistry(skill_roots=[self.skill_root], environment_catalog={}).get_skill(
            "software", skill_id
        )


class DatabaseSkillBuilder:
    """Create a database Skill only from a validated persistent database contract."""

    def __init__(self, skill_root: str | Path):
        self.skill_root = canonical_path(skill_root)

    def build(self, resource_id: str, entry: dict[str, Any]) -> ResourceSkill:
        skill_id = _safe_id(resource_id)
        root_path = canonical_path(entry["root_path"], must_exist=True)
        metadata = {
            "name": resource_id,
            "description": str(entry.get("purpose") or f"Validated persistent database {resource_id}."),
            "kind": "database",
            "id": skill_id,
            "version": 2,
            "aliases": [],
            "keywords": [],
            "folder": root_path.name,
            "required_markers": list(entry["expected_marker_files"]),
            "raw_markers": [],
            "compatible_software": list(entry.get("supported_tools") or ["external-consumer"]),
            "consumers": list(entry.get("supported_tools") or ["external-consumer"]),
            "download_urls": [],
            "advantages": [],
            "limitations": [],
            "estimated_size": str(entry.get("size") or "measured during registry validation"),
            "acquisition_mode": "manual",
            "acquisition_commands": [],
            "localization_commands": [],
            "contents": [],
            "formats": [],
            "update_policy": "READY resources are immutable; register a new ID for a new release.",
            "license_notes": "Preserve source licensing and provenance in the registry.",
            "validation": ["Validate markers, runtime entry, and fingerprint before use."],
            "failure_handling": ["Never register READY after a partial acquisition or failed localization."],
            "resolved_entrypoint": entry.get("runtime_entry") or entry.get("path"),
            "consumer_entrypoints": dict(entry.get("consumer_entrypoints") or {}),
            "common_markers": list(entry.get("common_markers") or []),
            "consumer_markers": dict(entry.get("consumer_markers") or {}),
            "generated_from": "validated-database-contract",
        }
        body = _default_database_instructions(metadata)
        body += (
            "\n## Resolved consumer entrypoints\n\n"
            "Use the exact `consumer_entrypoints` mapping in the frontmatter/Registry; "
            "never pass the database root when a tool requires an index prefix or file.\n"
        )
        existing = self.skill_root / "database" / skill_id / "SKILL.md"
        if existing.is_file():
            archive = existing.parent / f"SKILL.invalid.{datetime.now(UTC).strftime('%Y%m%dT%H%M%S%fZ')}.md"
            existing.replace(archive)
        _write_skill("database", skill_id, metadata, body, self.skill_root, overwrite=False)
        return ResourceSkillRegistry(
            skill_roots=[self.skill_root], db_root=root_path.parent, environment_catalog={}
        ).get_skill("database", skill_id)


class ToolResolver:
    """Resolve Unknown Tool into a validated binding, optional install, and learned Skill."""

    def __init__(
        self,
        project_root: str | Path,
        *,
        phase: str = "BOOTSTRAP",
        approved_tools: set[str] | None = None,
        project: PipelineProject | None = None,
        skill_registry: ResourceSkillRegistry | None = None,
        skill_root: str | Path | None = None,
        alias_registry_path: str | Path | None = None,
        tool_registry_path: str | Path | None = None,
        knowledge: KnowledgeBase | None = None,
        installer: CondaEnvironmentManager | None = None,
        mutable: bool = True,
    ):
        self.project_root = canonical_path(project_root)
        self.phase = phase.upper()
        self.approved_tools = approved_tools or set()
        self.project = project
        self.skill_root = canonical_path(
            skill_root
            or (project.output_root / "resource_skills" if project is not None else DEFAULT_CUSTOM_SKILL_ROOT)
        )
        roots = [PACKAGE_SKILL_ROOT, self.skill_root]
        self.discovery = ToolchainResolver(self.project_root)
        self.skill_registry = skill_registry or ResourceSkillRegistry(
            skill_roots=roots,
            environment_catalog=self.discovery.catalog,
            tolerate_invalid=True,
        )
        self.mutable = bool(mutable and self.phase in MUTABLE_PHASES)
        alias_path = alias_registry_path or (
            project.config_dir / "tool_alias_registry.yaml"
            if project is not None
            else self.skill_root / "tool_alias_registry.yaml"
        )
        self.alias_registry = ToolAliasRegistry(alias_path, self.skill_registry, mutable=self.mutable)
        self.tool_registry_path = canonical_path(
            tool_registry_path
            or (project.tool_registry_path if project is not None else self.skill_root / "tool_registry.yaml")
        )
        if knowledge is None and project is not None:
            from microbiome.pipeline.knowledge import KnowledgeBase

            knowledge = KnowledgeBase(project)
        self.knowledge = knowledge
        self.installer = installer or CondaEnvironmentManager(
            self.project_root,
            knowledge=knowledge,
            history_root=self.skill_root / "knowledge",
        )
        # Tests and legacy Agent instances may supply a catalog explicitly.
        if getattr(self.skill_registry, "environment_catalog", None):
            for name, prefix in self.skill_registry.environment_catalog.items():
                key = str(prefix) if name in self.discovery.catalog and self.discovery.catalog[name] != prefix else name
                self.discovery.catalog[key] = prefix

    @staticmethod
    def _matches(logical_tool: str, entry: dict[str, Any]) -> bool:
        requested = _normalized(logical_tool)
        names = {
            _normalized(entry.get("tool") or entry.get("tool_id") or ""),
            _normalized(entry.get("logical_tool") or ""),
            _normalized(entry.get("software_family") or ""),
            _normalized(Path(str(entry.get("executable") or "")).name),
            *(_normalized(value) for value in entry.get("aliases", []) or []),
        }
        return requested in names

    def _locked_entry(self, logical_tool: str, *, executable_name: str | None = None,
                      configured_exact: str | None = None) -> dict[str, Any] | None:
        if (
            self.project is None
            or not self.project.pipeline_lock_path.is_file()
            or not self.project.toolchain_lock_path.is_file()
        ):
            return None
        try:
            pipeline_lock = read_yaml(self.project.pipeline_lock_path)
            if pipeline_lock.get("manifest_fingerprint") != manifest_fingerprint(pipeline_lock):
                return None
            lock = read_yaml(self.project.toolchain_lock_path)
            if lock.get("manifest_fingerprint") != manifest_fingerprint(lock):
                return None
            incompatible = None
            for entry in lock.get("tools", {}).values():
                if isinstance(entry, dict) and self._matches(logical_tool, entry):
                    if executable_name is None or self._binding_matches_executable(
                        entry, executable_name, configured_exact
                    ):
                        return entry
                    incompatible = incompatible or entry
            # Retain the mismatch as drift evidence if no compatible lock exists.
            return incompatible
        except Exception:
            return None
        return None

    def _registered_entry(self, logical_tool: str, *, executable_name: str | None = None,
                          configured_exact: str | None = None) -> dict[str, Any] | None:
        if not self.tool_registry_path.is_file():
            return None
        try:
            registry = load_tool_registry(self.tool_registry_path)
            if executable_name is not None:
                compatible = {key: entry for key, entry in registry["tools"].items()
                              if self._binding_matches_executable(entry, executable_name, configured_exact)}
                found = find_registered_tool({"tools": compatible}, logical_tool)
                if found:
                    return found[1]
            found = find_registered_tool(registry, logical_tool)
            return found[1] if found else None
        except Exception:
            return None

    @staticmethod
    def _executable_name(logical_tool: str, spec: dict[str, Any], alias: dict[str, Any] | None) -> str:
        configured = spec.get("executable")
        if configured:
            return Path(str(configured)).name
        executables = list((alias or {}).get("executables") or [])
        requested = Path(logical_tool).name
        if requested in executables:
            return requested
        return str(executables[0]) if executables else requested

    @staticmethod
    def _binding_matches_executable(
        candidate: dict[str, Any], executable_name: str, configured_exact: str | None,
    ) -> bool:
        """A family/alias match is not proof of the requested command identity."""
        executable = candidate.get("executable")
        if not executable:
            return False
        actual = canonical_path(executable)
        if configured_exact is not None:
            return actual == canonical_path(configured_exact)
        if Path(str(executable)).name == executable_name:
            return True
        # Discovery canonicalizes paths. Preserve legitimate bin-name symlinks
        # (for example an interpreter alias), but never accept a sibling binary
        # just because both commands belong to the same package.
        prefix = candidate.get("conda_prefix") or candidate.get("environment_prefix")
        return bool(prefix and canonical_path(Path(prefix) / "bin" / executable_name) == actual)

    def _validate(
        self,
        logical_tool: str,
        executable_name: str,
        *,
        version_requirement: str,
        environment: dict[str, Any],
        exact_executable: str | None = None,
    ) -> tuple[dict[str, Any], str, list[str], int | None]:
        environment = dict(environment)
        environment["executable"] = exact_executable or executable_name
        if exact_executable is None:
            errors = []
            for candidate, prefix, _source in self.discovery._candidate_executables(logical_tool, environment):
                try:
                    return self._validate(logical_tool, executable_name,
                        version_requirement=version_requirement,
                        environment={**environment, "prefix": str(prefix) if prefix else None},
                        exact_executable=str(candidate))
                except ResourceNotReadyError as error:
                    errors.append(str(error))
            raise ResourceNotReadyError("; ".join(errors[-3:]) or f"{logical_tool}: no executable candidate was found")
        from microbiome.resource_skills.runtime import package_probe
        runtime = (self.alias_registry.resolve(logical_tool) or {}).get("runtime") if self.phase not in PRODUCTION_PHASES else None
        probe = package_probe(runtime)
        if probe:
            environment.update(version_args=probe[0], strict_probe=True, probe_marker=probe[1])
        configured_version_args = environment.get("version_args")
        # Semantics: None -> default probe list; [] -> bare executable only;
        # ["flag", ...] -> that probe first, then the defaults as fallback.
        default_candidates: list[list[str]] = [["--version"], ["-version"], ["version"], ["-v"], []]
        if configured_version_args is None:
            version_candidates = list(default_candidates)
        elif isinstance(configured_version_args, list) and not configured_version_args:
            version_candidates = [[]]
        else:
            version_candidates = [list(configured_version_args), *default_candidates]
        if probe:
            version_candidates = [probe[0]]
        elif self.phase in PRODUCTION_PHASES and configured_version_args is not None:
            version_candidates = [list(configured_version_args)]
        unique_candidates: list[list[str]] = []
        for candidate in version_candidates:
            if isinstance(candidate, list) and candidate not in unique_candidates:
                unique_candidates.append(candidate)
        validation_errors: list[str] = []
        resolved = None
        for version_args in unique_candidates:
            step = {
                "step_id": f"resolve-{_safe_id(logical_tool)}",
                "tool": logical_tool,
                "tool_version_requirement": version_requirement or "any",
                "environment": {**environment, "version_args": version_args},
                "version_args": version_args,
            }
            try:
                resolved = self.discovery.resolve_step(step)
                break
            except ResourceNotReadyError as error:
                validation_errors.append(str(error))
        if resolved is None:
            raise ResourceNotReadyError("; ".join(validation_errors[-3:]))
        help_text = ""
        used_help: list[str] = []
        help_exit_code: int | None = None
        fallback_help: tuple[str, list[str], int] | None = None
        declared_help = environment.get("help_args")
        help_candidates = [declared_help] if declared_help is not None else [["--help"], ["-help"], ["-h"], ["help"], []]
        for args in help_candidates:
            try:
                result = subprocess.run(
                    self.discovery._version_command(Path(resolved["executable"]),
                        Path(resolved["environment_prefix"]) if resolved.get("environment_prefix") else None, args),
                    capture_output=True,
                    env=tool_environment(resolved.get("environment_prefix")),
                    text=True,
                    timeout=30,
                    check=False,
                    stdin=subprocess.DEVNULL,
                )
            except (OSError, subprocess.TimeoutExpired):
                continue
            candidate = "\n".join(part for part in (result.stdout, result.stderr) if part).strip()
            if candidate and not _looks_like_fatal_runtime_error(candidate):
                if result.returncode == 0:
                    help_text, used_help, help_exit_code = candidate[:200_000], args, result.returncode
                    break
                if fallback_help is None and re.search(r"\b(usage|options|help)\b", candidate, re.IGNORECASE):
                    fallback_help = (candidate[:200_000], args, result.returncode)
        if not help_text and fallback_help is not None:
            help_text, used_help, help_exit_code = fallback_help
        if not help_text:
            raise ResourceNotReadyError(f"{logical_tool}: executable version passed but help smoke test failed")
        return resolved, help_text, used_help, help_exit_code

    def dependency_request(self, step: dict[str, Any]) -> dict[str, Any]:
        """Normalize declared installation hints for both review and bootstrap.

        Hints identify capabilities and packages; they never assert installation
        or authorize a dependency. Package candidates are alternatives, while
        required_packages are the explicitly declared companion dependencies.
        """
        logical = str(step["tool"])
        raw = step.get("environment") or {}
        environment = _environment_spec(raw) if isinstance(raw, str) else dict(raw)
        alias = self.alias_registry.resolve(logical) or {}
        skill = self.skill_registry.find_skill("software", logical)
        if not alias and skill:
            alias = ToolAliasRegistry._from_skill(skill)

        def declared_list(key, *values):
            items = []
            for value in values:
                if value is None:
                    continue
                if not isinstance(value, list) or not all(isinstance(item, str) and item.strip() for item in value):
                    raise ConfigurationError(f"tool {logical}: {key} must be a list of non-empty strings")
                items.extend(value)
            return list(dict.fromkeys(items))

        family = step.get("software_family") or environment.get("software_family") or alias.get("software_family") or Path(logical).name
        if not isinstance(family, str) or not family.strip():
            raise ConfigurationError(f"tool {logical}: software_family must be a non-empty string")
        packages = declared_list("package_candidates", step.get("package_candidates"),
            environment.get("package_candidates"), environment.get("packages"), alias.get("package_candidates"))
        required = declared_list("required_packages", step.get("required_packages"),
            environment.get("required_packages"), environment.get("packages"), skill.metadata.get("packages") if skill else None)
        channels = declared_list("channels", step.get("channels"), environment.get("channels"), alias.get("channels")) or ["conda-forge", "bioconda"]
        for package in [*packages, *required]:
            # Conda accepts each spec as one argv token; never allow an option,
            # explicit URL or filesystem artifact to masquerade as a package.
            if not re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_.-]*(?:\[[^\]\r\n]+\]|(?:[=<>!~][A-Za-z0-9.*,+_!<>=~-]+))?", package):
                raise ConfigurationError(f"tool {logical}: invalid Conda package specification: {package!r}")
        for channel in channels:
            if not re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_./-]*", channel):
                raise ConfigurationError(f"tool {logical}: channel must be an explicit Conda channel name: {channel!r}")
        for field in ("version_args", "help_args"):
            value = environment.get(field, step.get(field, alias.get(field)))
            if value is not None:
                environment[field] = declared_list(field, value)
        executable_name = self._executable_name(logical, environment, alias)
        if Path(executable_name).name != executable_name or not executable_name:
            raise ConfigurationError(f"tool {logical}: executable must identify one command")
        return {
            "logical_tool": logical, "software_family": family,
            "executable_name": executable_name, "package_candidates": packages,
            "required_packages": required, "channels": channels,
            "install_prefix": environment.get("install_prefix"),
            "version_requirement": str(step.get("tool_version_requirement") or "any"),
            "environment": environment,
        }

    def probe_step(self, step: dict[str, Any]) -> dict[str, Any]:
        return self._resolve(step["tool"], step=step, persist=False, allow_install=False).as_dict()

    def resolve_step(self, step: dict[str, Any]) -> dict[str, Any]:
        binding = self._resolve(step["tool"], step=step, persist=True, allow_install=True)
        payload = binding.as_dict()
        payload.update(
            {
                "step_id": step["step_id"],
                "tool": step["tool"],
                "tool_version_requirement": step["tool_version_requirement"],
            }
        )
        return payload

    def resolve(
        self,
        logical_tool: str,
        *,
        version_requirement: str = "any",
        environment: str | dict[str, Any] | None = None,
        package_candidates: list[str] | None = None,
        channels: list[str] | None = None,
    ) -> ToolBinding:
        step = {
            "step_id": f"resolve-{_safe_id(logical_tool)}",
            "tool": logical_tool,
            "tool_version_requirement": version_requirement,
            "environment": environment or {},
            "package_candidates": package_candidates or [],
            "channels": channels or [],
        }
        return self._resolve(logical_tool, step=step, persist=True, allow_install=True)

    def _resolve(
        self,
        logical_tool: str,
        *,
        step: dict[str, Any],
        persist: bool,
        allow_install: bool,
    ) -> ToolBinding:
        request = self.dependency_request(step)
        environment = dict(request["environment"])
        alias = self.alias_registry.resolve(logical_tool)
        skill = self.skill_registry.find_skill("software", logical_tool)
        if skill is not None and alias is None:
            alias = ToolAliasRegistry._from_skill(skill)
        # A SKILL-declared version_args (None absent / [] bare / ["flag"] exact) is
        # authoritative unless the caller already supplied an explicit override.
        declared_version_args = (alias or {}).get("version_args")
        if declared_version_args is not None and "version_args" not in environment:
            environment["version_args"] = list(declared_version_args)
        executable_name = self._executable_name(logical_tool, environment, alias)
        configured_exact = None
        configured_executable = str(environment.get("executable") or "")
        if configured_executable and Path(configured_executable).is_absolute():
            configured_exact = configured_executable
        elif Path(logical_tool).is_absolute():
            configured_exact = logical_tool
        family = request["software_family"]
        packages = request["package_candidates"]
        channels = request["channels"]
        requirement = str(step.get("tool_version_requirement") or "any")

        locked = self._locked_entry(logical_tool, executable_name=executable_name,
                                    configured_exact=configured_exact)
        registered = self._registered_entry(logical_tool, executable_name=executable_name,
                                            configured_exact=configured_exact)
        candidates = [("pipeline lock", locked), ("tool registry", registered)]
        failures: list[str] = []
        resolved: dict[str, Any] | None = None
        help_text = ""
        help_args: list[str] = []
        help_exit_code: int | None = None
        source = ""
        for candidate_source, candidate in candidates:
            if not candidate or not candidate.get("executable"):
                continue
            if not self._binding_matches_executable(candidate, executable_name, configured_exact):
                detail = (
                    f"{candidate_source} executable {candidate['executable']} does not match "
                    f"requested executable {configured_exact or executable_name}"
                )
                if self.phase in PRODUCTION_PHASES and candidate_source == "pipeline lock":
                    raise ResourceNotReadyError(f"production resource drift: {detail}")
                failures.append(detail)
                continue
            identities = {_normalized(candidate.get(key) or "")
                          for key in ("tool", "tool_id", "software_family", "resource_id")}
            if _normalized(logical_tool) in self.alias_registry.ambiguous and _normalized(logical_tool) not in identities:
                # A registered package probe is not an interpreter capability.
                continue
            try:
                resolved, help_text, help_args, help_exit_code = self._validate(
                    logical_tool,
                    executable_name,
                    version_requirement=requirement,
                    environment={
                        "version_args": candidate.get("version_args", environment.get("version_args")),
                        "help_args": candidate.get("help_args", environment.get("help_args")),
                        "prefix": candidate.get("conda_prefix") or candidate.get("environment_prefix"),
                    },
                    exact_executable=str(candidate["executable"]),
                )
                if self.phase in PRODUCTION_PHASES and (
                    candidate.get("runtime_launcher", []) != resolved.get("runtime_launcher", [])
                    or candidate.get("runtime_launcher_fingerprint") != resolved.get("runtime_launcher_fingerprint")
                ):
                    raise ResourceNotReadyError("locked Conda runtime launcher changed")
                source = candidate_source
                break
            except ResourceNotReadyError as error:
                failures.append(str(error))
                if self.phase in PRODUCTION_PHASES and candidate_source == "pipeline lock":
                    raise ResourceNotReadyError(f"production resource drift: {error}") from error
        if self.phase in PRODUCTION_PHASES:
            if resolved is None or source != "pipeline lock":
                raise ResourceNotReadyError(
                    f"production requires a validated pipeline lock binding for {logical_tool}; no discovery/install is allowed"
                )
            if not registered or canonical_path(registered.get("executable", "")) != canonical_path(
                resolved["executable"]
            ):
                raise ResourceNotReadyError(f"production tool registry is missing or drifted for {logical_tool}")

        installed = False
        recipe_path: str | None = None
        if resolved is None:
            search_environment = dict(environment)
            search_environment.setdefault("name", (alias or {}).get("environment"))
            try:
                resolved, help_text, help_args, help_exit_code = self._validate(
                    logical_tool,
                    executable_name,
                    version_requirement=requirement,
                    environment=search_environment,
                    exact_executable=configured_exact,
                )
                source = str(resolved.get("installation_source") or "existing executable")
            except ResourceNotReadyError as error:
                failures.append(str(error))

        if resolved is None and allow_install:
            approved = getattr(self, "approved_requests", None)
            if approved is not None:
                reviewed = approved.get(step.get("step_id"), {})
                if reviewed.get("status") != "NEEDS_INSTALL" or reviewed.get("installation_request") != request:
                    raise ConfigurationError(f"{logical_tool}: installation scope changed; review and approve a new dependency plan")
            prefix, installed_package = self.installer.install(
                request,
                phase=self.phase,
                approved_tools=self.approved_tools,
            )
            installed = True
            resolved, help_text, help_args, help_exit_code = self._validate(
                logical_tool,
                executable_name,
                version_requirement=requirement,
                environment={**environment, "prefix": str(prefix)},
                exact_executable=str(prefix / "bin" / executable_name),
            )
            source = "approved installation"
            packages = list(dict.fromkeys([installed_package, *request["required_packages"]]))
            successful_installation = {
                "completed_at": _utcnow(),
                "method": "approved bounded installer",
                "environment_prefix": str(prefix),
                "package": installed_package,
                "channels": channels,
                "executable": resolved["executable"],
                "version": resolved["version_output"],
                "version_args": resolved["version_args"],
                "help_args": help_args,
                "help_exit_code": help_exit_code,
                "validated": True,
                "status": "READY",
            }
            if self.knowledge is not None:
                self.knowledge.record_installation_attempt(family, successful_installation)
                recipe_path = str(self.knowledge._tool_dir(family) / "installation_recipe.yaml")
            else:
                recipe = self.skill_root / "knowledge" / "tools" / _safe_id(family) / "installation_recipe.yaml"
                write_yaml(
                    recipe,
                    {
                        "schema_version": 1,
                        "software_family": family,
                        "successful_installation": successful_installation,
                    },
                )
                recipe_path = str(recipe)
        if resolved is None:
            detail = "; ".join(failures[-4:]) or "no candidate executable was found"
            raise ResourceNotReadyError(f"{logical_tool}: unresolved software dependency: {detail}")

        prefix = canonical_path(resolved["environment_prefix"]) if resolved.get("environment_prefix") else None
        owner_packages, family_executables = SoftwareSkillBuilder.package_metadata(prefix, executable_name)
        if skill is not None:
            family_executables = _as_string_list(skill.metadata.get("executables")) or [executable_name]
        if not packages:
            packages = owner_packages
        relevant_package_names = {
            re.split(r"[<>=!~ ]", package, maxsplit=1)[0].casefold() for package in packages if package
        }
        package_inventory = [
            item
            for item in resolved.get("package_inventory") or []
            if str(item.get("name") or "").casefold() in relevant_package_names
        ]
        aliases = list(
            dict.fromkeys(
                [
                    logical_tool,
                    executable_name,
                    *family_executables,
                    *list((alias or {}).get("aliases") or []),
                ]
            )
        )
        preliminary = ToolBinding(
            logical_tool=logical_tool,
            executable=resolved["executable"],
            software_family=family,
            environment_prefix=resolved.get("environment_prefix"),
            environment_name=resolved.get("environment_name"),
            version_output=resolved["version_output"],
            version_args=list(resolved["version_args"]),
            help_args=help_args,
            help_exit_code=help_exit_code,
            source=source,
            runtime_launcher=list(resolved.get("runtime_launcher") or []),
            runtime_launcher_fingerprint=resolved.get("runtime_launcher_fingerprint"),
            version_exit_code=resolved.get("version_exit_code", 0),
            skill_id=skill.skill_id if skill else None,
            skill_path=str(skill.path) if skill else None,
            package_candidates=packages,
            package_inventory=package_inventory,
            family_executables=family_executables,
            aliases=aliases,
            installed=installed,
            reused=not installed,
            installation_recipe=recipe_path,
        )
        if skill is None and persist and self.mutable:
            skill = SoftwareSkillBuilder(self.skill_root).build(
                preliminary,
                version_text=resolved["version_output"],
                help_text=help_text,
                task_contract=step,
            )
            self.skill_registry.reload()
        docs_root = (
            self.project.knowledge_dir / "tools" / _safe_id(family) / "docs"
            if self.project is not None
            else self.skill_root / "software" / _safe_id(family) / "docs"
        )
        help_path = docs_root / "help.txt"
        if persist and self.mutable:
            atomic_write_text(help_path, help_text.rstrip() + "\n")
            atomic_write_text(docs_root / "version.txt", resolved["version_output"].rstrip() + "\n")
            from microbiome.resource_skills.command_schema import schema_from_help
            write_yaml(docs_root.parent / "command_schema.yaml",
                       schema_from_help(resolved["executable"], resolved["version_output"], help_text))
        binding = ToolBinding(
            **{
                **asdict(preliminary),
                "skill_id": skill.skill_id if skill else preliminary.skill_id,
                "skill_path": str(skill.path) if skill else preliminary.skill_path,
                "help_path": str(help_path) if persist and self.mutable else None,
            }
        )
        if persist and self.mutable:
            self.alias_registry.register(binding)
            register_tool_binding(self.tool_registry_path, binding.as_dict())
            if self.knowledge is not None:
                self.knowledge.record_tool_profile(str(step.get("step_id") or logical_tool), binding.as_dict())
                self.knowledge.record_tool_validation(family, binding.as_dict())
            else:
                standalone = self.skill_root / "knowledge" / "tools" / _safe_id(family)
                write_yaml(
                    standalone / "tool_profile.yaml",
                    {
                        "schema_version": 1,
                        "tool_id": family,
                        "executable": binding.executable,
                        "conda_prefix": binding.environment_prefix,
                        "version": binding.version_output,
                        "skill_path": binding.skill_path,
                        "last_validated": binding.validated_at,
                    },
                )
                _append_jsonl(
                    standalone / "validation_history.jsonl",
                    {
                        "timestamp": binding.validated_at,
                        "status": "PASSED",
                        "executable": binding.executable,
                        "version": binding.version_output,
                        "version_args": binding.version_args,
                        "help_args": binding.help_args,
                        "source": binding.source,
                    },
                )
        return binding


def inspect_software_request(
    logical_tool: str,
    *,
    executable: str | None = None,
    software_family: str | None = None,
    environment_name: str | None = None,
    project_root: str | Path | None = None,
) -> dict[str, Any]:
    """Inspect a capability and local package ownership without installation/writeback.

    Missing local metadata is not a package mapping: the caller must obtain an
    explicit mapping from upstream/package documentation before proposing an
    installation. Returned external help and metadata are evidence, not commands.
    """
    root = canonical_path(project_root or Path.cwd())
    from microbiome.pipeline.project import PipelineProject

    project = PipelineProject(root) if (root / "project_config.yaml").is_file() else None
    resolver = ToolResolver(root, phase="DISCOVERY", mutable=False, project=project,
                            skill_root=project.resource_skills_dir if project else root / "resource_skills",
                            tool_registry_path=project.tool_registry_path if project else root / "config" / "tool_registry.yaml")
    environment = {}
    if executable:
        environment["executable"] = executable
    if environment_name:
        environment["name"] = environment_name
    step = {"step_id": "inspect", "tool": logical_tool, "environment": environment,
            "tool_version_requirement": "any"}
    if software_family:
        step["software_family"] = software_family
    request = resolver.dependency_request(step)
    alias = resolver.alias_registry.resolve(logical_tool) or {}
    mapping_source = None
    if alias.get("package_candidates"):
        mapping_source = ("CURATED_SKILL" if Path(alias.get("skill_path") or root).resolve().is_relative_to(PACKAGE_SKILL_ROOT.resolve())
                          else "PROJECT_SKILL")
    result = {"logical_tool": logical_tool, "request": request,
              "searched_prefixes": sorted(set(resolver.discovery.catalog.values())),
              "mapping_source": mapping_source,
              "policy": "Read-only evidence; never installation or execution approval."}
    try:
        binding = resolver.probe_step(step)
    except ResourceNotReadyError as error:
        result.update(status="NEEDS_INSTALL" if request["package_candidates"] else "NEEDS_PACKAGE_MAPPING",
                      probe_error=str(error), binding=None)
        if result["status"] == "NEEDS_PACKAGE_MAPPING":
            result["next_action"] = (
                "Consult official upstream or package documentation for an explicit package/executable mapping, "
                "then include its sources and installation scope in a dependency plan for approval. "
                "No package name has been inferred from the logical capability."
            )
    else:
        result.update(status="READY", binding=binding)
        owner_packages, _executables = SoftwareSkillBuilder.package_metadata(
            Path(binding["environment_prefix"]) if binding.get("environment_prefix") else None,
            Path(binding["executable"]).name)
        if owner_packages:
            result.update(mapping_source="LOCAL_CONDA_PACKAGE_OWNERSHIP", owner_packages=owner_packages)
    return result


class PersistentDatabaseResolver:
    """Approval-gated database resolver with Registry/Skill/Knowledge writeback."""

    def __init__(
        self,
        project: PipelineProject,
        *,
        phase: str = "BOOTSTRAP",
        approved_resources: set[str] | None = None,
        skill_registry: ResourceSkillRegistry | None = None,
        skill_root: str | Path | None = None,
        knowledge: KnowledgeBase | None = None,
        acquirer: Callable[[str, dict[str, Any]], Any] | None = None,
    ):
        self.project = project
        self.phase = phase.upper()
        self.approved_resources = {_normalized(value) for value in approved_resources or set()}
        self.database_root = canonical_path(project.load_config()["paths"]["database"], must_exist=True)
        self.skill_root = canonical_path(skill_root or project.output_root / "resource_skills")
        self.skill_registry = skill_registry or ResourceSkillRegistry(
            skill_roots=[PACKAGE_SKILL_ROOT, self.skill_root], db_root=self.database_root
        )
        if knowledge is None:
            from microbiome.pipeline.knowledge import KnowledgeBase

            knowledge = KnowledgeBase(project)
        self.knowledge = knowledge
        self.acquirer = acquirer

    @staticmethod
    def _consumer_spec(spec: dict[str, Any], consumer: str | None) -> dict[str, Any]:
        # The registry stores one immutable base contract plus a map of exact
        # consumer entrypoints. Selecting a consumer must not rewrite the base
        # identity and accidentally create a conflicting resource record.
        return dict(spec)

    @staticmethod
    def _select_entrypoint(entry: dict[str, Any], consumer: str | None) -> dict[str, Any]:
        selected = dict(entry)
        entrypoint = (entry.get("consumer_entrypoints") or {}).get(
            consumer, entry.get("runtime_entry") or entry.get("path")
        )
        selected["path"] = entrypoint
        selected["resolved_entrypoint"] = entrypoint
        selected["consumer"] = consumer
        return selected

    def resolve(
        self, resource_id: str, spec: dict[str, Any], *, consumer: str | None = None,
        parameters: dict[str, Any] | None = None, command_template: list[str] | None = None,
    ) -> dict[str, Any]:
        spec = self._consumer_spec(spec, consumer)
        spec["logical_name"] = resource_id
        pseudo = {"step_id": "database-resolution", "tool": consumer, "parameters": parameters or {},
                  "command_template": command_template or [], "database": {"resource": spec}}
        observed = DatabaseResolver(self.database_root).resolve_plan([pseudo], require_ready=False)[resource_id]
        if self.phase in PRODUCTION_PHASES:
            if not self.project.pipeline_lock_path.is_file() or not self.project.database_lock_path.is_file():
                raise ResourceNotReadyError(
                    f"production requires pipeline/database locks for {resource_id}; no discovery/acquisition is allowed"
                )
            pipeline_lock = read_yaml(self.project.pipeline_lock_path)
            database_lock = read_yaml(self.project.database_lock_path)
            if pipeline_lock.get("manifest_fingerprint") != manifest_fingerprint(pipeline_lock):
                raise ResourceNotReadyError("production pipeline lock fingerprint is invalid")
            if database_lock.get("manifest_fingerprint") != manifest_fingerprint(database_lock):
                raise ResourceNotReadyError("production database lock fingerprint is invalid")
            locked = database_lock.get("databases", {}).get(resource_id)
            registry = load_database_registry(self.project.database_registry_path, database_root=self.database_root)
            registered = registry["resources"].get(resource_id)
            if not locked or not registered or registered.get("status") != "READY" or observed.get("status") != "READY":
                raise ResourceNotReadyError(f"production database {resource_id} is not READY in its frozen registry")
            contract_fields = (
                "root_path", "runtime_entry", "consumer_entrypoints", "common_markers", "consumer_markers",
                "expected_marker_files", "database_version", "validation_contract", "runtime_kind",
                "runtime_suffix_sets", "consumer_entrypoint_kinds", "consumer_suffix_sets",
            )
            if any(field in locked and locked[field] != observed.get(field) for field in contract_fields):
                raise ResourceNotReadyError(f"production database contract differs from frozen lock: {resource_id}")
            current = database_fingerprint(
                canonical_path(observed["root_path"], must_exist=True), observed["expected_marker_files"]
            )
            if registered.get("fingerprint") != current or locked.get("fingerprint") != current:
                raise ResourceNotReadyError(f"production database drift: {resource_id}")
            return self._select_entrypoint(observed, consumer)

        if observed["status"] != "READY":
            if self.phase not in MUTABLE_PHASES or _normalized(resource_id) not in self.approved_resources:
                update_database_registry(
                    self.project.database_registry_path,
                    database_root=self.database_root,
                    resolved={resource_id: observed},
                )
            if self.acquirer is None:
                raise ResourceNotReadyError(
                    f"database {resource_id} is {observed['status']}; an approved deterministic acquirer is required"
                )
            self.acquirer(resource_id, spec)
            observed = DatabaseResolver(self.database_root).resolve_plan([pseudo], require_ready=True)[resource_id]
            if self.knowledge is not None:
                self.knowledge.record_database_event(
                    resource_id, {"event": "ACQUIRED_AND_VALIDATED", "status": "READY"}
                )
        _registry, entries, events = update_database_registry(
            self.project.database_registry_path,
            database_root=self.database_root,
            resolved={resource_id: observed},
        )
        entry = entries[resource_id]
        skill = self.skill_registry.find_skill("database", resource_id)
        if skill is None:
            DatabaseSkillBuilder(self.skill_root).build(resource_id, entry)
            self.skill_registry.reload()
        if self.knowledge is not None:
            self.knowledge.record_database_profile(resource_id, entry)
            self.knowledge.record_database_event(
                resource_id,
                {"event": events[-1] if events else "VALIDATED", "status": entry["status"]},
            )
        return self._select_entrypoint(entry, consumer)


class ResourceBootstrapManager:
    """Orchestrate independent software and database managers for one approved plan."""

    def __init__(
        self,
        project: PipelineProject,
        *,
        phase: str,
        approved_tools: set[str],
        approved_databases: set[str],
        knowledge: KnowledgeBase | None = None,
        installer: CondaEnvironmentManager | None = None,
        database_acquirer: Callable[[str, dict[str, Any]], Any] | None = None,
    ):
        self.tool_resolver = ToolResolver(
            project.root,
            phase=phase,
            approved_tools=approved_tools,
            project=project,
            knowledge=knowledge,
            installer=installer,
        )
        report_path = project.plans_dir / "dependency_gap_report.yaml"
        if report_path.is_file():
            report = read_yaml(report_path)
            self.tool_resolver.approved_requests = {
                item["step_id"]: item for item in report.get("tools", [])
                if "installation_request" in item
            }
        self.database_resolver = PersistentDatabaseResolver(
            project,
            phase=phase,
            approved_resources=approved_databases,
            knowledge=knowledge,
            acquirer=database_acquirer,
        )

    def resolve_tools(self, steps: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
        return {step["step_id"]: self.tool_resolver.resolve_step(step) for step in steps}

    def resolve_databases(self, steps: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
        resolved: dict[str, dict[str, Any]] = {}
        for step in steps:
            for alias, spec in step.get("database", {}).items():
                resource_id = str(spec.get("logical_name") or alias)
                consumer = str(step.get("tool") or "")
                entry = self.database_resolver.resolve(
                    resource_id, spec, consumer=consumer,
                    parameters=step.get("parameters"), command_template=step.get("command_template"),
                )
                if resource_id in resolved:
                    previous = resolved[resource_id]
                    identity_fields = ("root_path", "runtime_entry", "database_version", "fingerprint")
                    if any(previous.get(field) != entry.get(field) for field in identity_fields):
                        raise ConfigurationError(f"database {resource_id} has inconsistent resource identity")
                    bindings = dict(previous.get("resolved_consumer_entrypoints") or {})
                    bindings[consumer] = entry["resolved_entrypoint"]
                    previous["resolved_consumer_entrypoints"] = bindings
                else:
                    entry["resolved_consumer_entrypoints"] = {consumer: entry["resolved_entrypoint"]}
                    resolved[resource_id] = entry
        return resolved
