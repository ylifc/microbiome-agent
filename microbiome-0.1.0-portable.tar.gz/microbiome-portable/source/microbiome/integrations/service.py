"""Versioned workflow operations shared by the JSON CLI and MCP adapter.

No model, network listener, implicit approvals, or scientific installation runs
at import/startup. Authoritative decisions remain in the existing pipeline.
"""
from __future__ import annotations

import contextlib
import fcntl
import hashlib
import sys
import threading
from pathlib import Path

from microbiome.pipeline.errors import ConfigurationError
from microbiome.pipeline.io import object_fingerprint, read_json, read_yaml, write_json, write_yaml
from microbiome.pipeline.project import PipelineProject

SCHEMA_VERSION = 1
_OUTPUT_LOCK = threading.RLock()
TOPICS = ("input", "dataset", "target", "analysis_goal", "analysis_plan", "dependencies", "production")


def project_at(project: str) -> PipelineProject:
    if not Path(project).expanduser().is_absolute():
        raise ConfigurationError("project must be an absolute path on the execution machine")
    instance = PipelineProject(project)
    instance.require_layout()
    return instance


@contextlib.contextmanager
def project_lock(project: PipelineProject, *, blocking: bool = False):
    """Share the existing worker's operation lock across adapters and processes."""
    with (project.root / ".microbiome-operation.lock").open("a") as handle:
        try:
            fcntl.flock(handle, fcntl.LOCK_EX | (0 if blocking else fcntl.LOCK_NB))
        except BlockingIOError as error:
            raise ConfigurationError("PROJECT_BUSY: another operation owns this project") from error
        yield


def _proposal_path(project: PipelineProject, topic: str) -> Path:
    if topic not in TOPICS[:4]:
        raise ConfigurationError("unsupported requirement topic")
    return project.state_dir / "portable" / "proposals" / f"{topic}.json"


def catalog_list() -> dict:
    from microbiome.workflows import WorkflowCatalog
    return {"authority": "CURATED_REFERENCE", "workflows": WorkflowCatalog().list()}


def catalog_show(workflow_id: str) -> dict:
    from microbiome.workflows import WorkflowCatalog
    return WorkflowCatalog().get(workflow_id)


def catalog_search(query: str, workflow_ids: list[str] | None = None, limit: int = 4) -> dict:
    from microbiome.workflows import WorkflowCatalog
    if type(limit) is not int or not 1 <= limit <= 20:
        raise ConfigurationError("limit must be an integer between 1 and 20")
    return WorkflowCatalog().selection_context(query, workflow_ids=workflow_ids, limit=limit)


def inspect_software(project: str, logical_tool: str, executable: str | None = None,
                     software_family: str | None = None, environment_name: str | None = None) -> dict:
    from microbiome.resource_skills.resolver import inspect_software_request
    instance = project_at(project)
    if not isinstance(logical_tool, str) or not logical_tool.strip():
        raise ConfigurationError("logical_tool must be a nonempty capability name")
    return inspect_software_request(logical_tool, executable=executable, software_family=software_family,
                                    environment_name=environment_name, project_root=instance.root)


def inspect_project(project: str) -> dict:
    from microbiome.integrations.delegation import load_authorization
    from microbiome.pipeline.requirements import RequirementManager
    from microbiome.pipeline.state import ProjectStateMachine
    instance = project_at(project)
    paths = {
        "input_manifest": instance.requirements_dir / "input_manifest.yaml",
        "plan": instance.plan_path,
        "dependency_report": instance.plans_dir / "dependency_gap_report.yaml",
        "validation": instance.validation_report_path,
        "pipeline_lock": instance.pipeline_lock_path,
        "toolchain_lock": instance.toolchain_lock_path,
        "database_lock": instance.database_lock_path,
        "production_approval": instance.pipeline_dir / "production_approval.yaml",
    }
    return {"project": str(instance.root), "paths": instance.load_config()["paths"],
            "approval_mode": load_authorization(instance),
            "lifecycle": ProjectStateMachine(instance).load(),
            "requirements": RequirementManager(instance).load(),
            "artifacts": {name: {"path": str(path), "exists": path.is_file()} for name, path in paths.items()},
            "reports": [str(path) for path in sorted(instance.reports_dir.glob("*")) if path.is_file()]}


def confirmed_manifest(project: PipelineProject) -> dict:
    from microbiome.pipeline.requirements import RequirementManager
    requirements = RequirementManager(project).require_confirmed()
    manifest = read_yaml(project.requirements_dir / "input_manifest.yaml")
    fingerprint = object_fingerprint({k: v for k, v in manifest.items() if k != "manifest_fingerprint"})
    if manifest.get("manifest_fingerprint") != fingerprint or manifest.get("resolution_status") != "CONFIRMED":
        raise ConfigurationError("Input manifest is unconfirmed or changed; resolve and confirm inputs again")
    declared = requirements["input"].get("manifest_fingerprint")
    if declared and declared not in {fingerprint, object_fingerprint(manifest)}:
        raise ConfigurationError("Input manifest differs from confirmed requirements")
    if not manifest.get("samples"):
        raise ConfigurationError("Input manifest has no samples")
    return manifest


def resolve_input(project: str, declaration: str) -> dict:
    """Resolve once into a pending proposal; only operator confirmation persists it."""
    from microbiome.input_resolution import InputSourceResolver
    from microbiome.integrations.delegation import load_authorization
    instance = project_at(project)
    with project_lock(instance):
        load_authorization(instance)
        resolver = InputSourceResolver(instance.load_config()["paths"]["raw_data"], instance.output_root)
        result = resolver.resolve(declaration, allow_sra_download=False)
        if result.errors or not result.samples:
            raise ConfigurationError("; ".join(result.errors or ["No resolved input samples"]))
        manifest = resolver.to_input_manifest(result)
        if manifest.get("resolution_status") != "CONFIRMED":
            raise ConfigurationError("Input needs explicit remote acquisition or clarification; no download was started")
        manifest["manifest_fingerprint"] = object_fingerprint(manifest)
        value = {"source": manifest["overall_source"], "layout": manifest["layout"],
                 "manifest_fingerprint": manifest["manifest_fingerprint"], "sample_count": len(manifest["samples"])}
        write_json(_proposal_path(instance, "input"), {"value": value, "manifest": manifest})
        return decision_snapshot(project, "input")


def propose_requirement(project: str, topic: str, value: dict) -> dict:
    from microbiome.integrations.delegation import load_authorization
    if topic not in ("dataset", "target", "analysis_goal") or not isinstance(value, dict) or not value:
        raise ConfigurationError("Use a nonempty dataset/target/analysis_goal proposal; resolve input separately")
    instance = project_at(project)
    with project_lock(instance):
        load_authorization(instance)
        write_json(_proposal_path(instance, topic), {"value": value})
        return decision_snapshot(project, topic)


def validate_plan(plan: dict) -> dict:
    from microbiome.pipeline.models import validate_experiment_plan
    from microbiome.pipeline.workflow_references import bind_reference_decisions, workflow_ids
    from microbiome.workflows import WorkflowCatalog
    candidate = dict(plan)
    # A host-supplied path is not proof that the application persisted/read evidence.
    candidate.pop("workflow_reference_evidence", None)
    candidate.pop("planning_evidence", None)
    normalized = validate_experiment_plan(candidate)
    selection = WorkflowCatalog().selection_context(normalized["objective"], workflow_ids=workflow_ids(normalized))
    return validate_experiment_plan(bind_reference_decisions(normalized, selection, require_match=True))


def planning_context(project: str, query: str, workflow_ids: list[str] | None = None) -> dict:
    from microbiome.pipeline.planning_context import PlanningContext
    instance = project_at(project)
    confirmed_manifest(instance)
    with project_lock(instance):
        context_service = PlanningContext(instance)
        context = context_service.collect(plan={"workflow_ids": workflow_ids} if workflow_ids is not None else None, query=query)
        receipt = context_service.persist(context)
        return {"context": context_service.workflow_for_model(context),
                "resource_context": context_service.for_model(context), "receipt": receipt}


def _verify_reference_delivery(instance: PipelineProject, original: dict, normalized: dict, manifest: dict):
    """Prove documents were supplied by planning.context; never claim to prove model thought."""
    from microbiome.pipeline.workflow_references import reference_summary
    references = normalized.get("workflow_references") or []
    if not references:
        return
    receipt = original.get("workflow_reference_evidence")
    if not isinstance(receipt, dict) or not receipt.get("path") or not receipt.get("context_fingerprint"):
        raise ConfigurationError("Call planning.context before designing; include its receipt as workflow_reference_evidence")
    path = Path(receipt["path"]).expanduser().resolve()
    if not path.is_relative_to((instance.plans_dir / "planning_evidence").resolve()):
        raise ConfigurationError("Workflow evidence must be a planning.context receipt inside this project")
    context = read_json(path)
    fingerprint = object_fingerprint({k: v for k, v in context.items() if k != "context_fingerprint"})
    if context.get("context_fingerprint") != fingerprint or receipt["context_fingerprint"] != fingerprint:
        raise ConfigurationError("Workflow evidence changed; request planning.context again")
    delivered = reference_summary(context.get("workflow_references", {}))
    if sorted(delivered, key=lambda item: item["workflow_id"]) != sorted(references, key=lambda item: item["workflow_id"]):
        raise ConfigurationError("Selected references differ from the delivered documents; request planning.context again")
    if (context.get("project_paths") != instance.load_config()["paths"] or
            context.get("input_contract", {}).get("manifest_fingerprint") != manifest["manifest_fingerprint"]):
        raise ConfigurationError("Workflow evidence refers to different project inputs; request planning.context again")


def save_plan(project: str, plan: dict) -> dict:
    from microbiome.pipeline.lifecycle import save_experiment_plan
    from microbiome.pipeline.planning_context import PlanningContext
    from microbiome.pipeline.workflow_references import bind_reference_decisions
    instance = project_at(project)
    with project_lock(instance):
        from microbiome.pipeline.requirements import RequirementManager
        requirements = RequirementManager(instance).require_confirmed()
        manifest = confirmed_manifest(instance)
        normalized = validate_plan(plan)
        _verify_reference_delivery(instance, plan, normalized, manifest)
        from microbiome.pipeline.study import validate_study
        from microbiome.pipeline.planning_inputs import validate_conversation_input_bindings
        from microbiome.pipeline.cohort import expand_cohort_plan
        comparative = requirements["dataset"].get("comparative_analysis", requirements["analysis_goal"].get("comparative_analysis", False))
        normalized = validate_study({"requirements": requirements, "plan": normalized,
                                     "comparative_analysis": comparative})["plan"]
        metadata = requirements["dataset"].get("sample_metadata", [])
        if metadata and (len(metadata) != len(manifest["samples"]) or
                         {row.get("sample_id") for row in metadata} != {row["sample_id"] for row in manifest["samples"]}):
            raise ConfigurationError("Sample metadata must match every confirmed manifest sample exactly once")
        validate_conversation_input_bindings(normalized, manifest, instance)
        if normalized.get("cohort_members"):
            raise ConfigurationError("Submit an unexpanded cohort template; membership is derived from the confirmed manifest")
        normalized = expand_cohort_plan(normalized, manifest)
        context_service = PlanningContext(instance)
        context = context_service.collect(plan=normalized, query=normalized["objective"])
        receipt = context_service.persist(context)
        normalized = bind_reference_decisions(normalized, context["workflow_references"], receipt=receipt, require_match=True)
        normalized["planning_evidence"] = receipt
        return save_experiment_plan(instance, normalized)


def preview_dependencies(project: str, plan: dict | None = None) -> dict:
    from microbiome.pipeline.dependencies import DependencyResolver
    from microbiome.pipeline.lifecycle import load_plan
    instance = project_at(project)
    with project_lock(instance):
        candidate = validate_plan(plan) if plan is not None else load_plan(instance)
        return DependencyResolver(instance).review(preview_plan=candidate)


def review_dependencies(project: str) -> dict:
    from microbiome.pipeline.dependencies import DependencyResolver
    instance = project_at(project)
    with project_lock(instance):
        return DependencyResolver(instance).review()


def decision_snapshot(project: str, topic: str) -> dict:
    """Return exact review material; this operation cannot grant any approval."""
    from microbiome.pipeline.requirements import RequirementManager
    if topic not in TOPICS:
        raise ConfigurationError("Unknown decision topic")
    instance = project_at(project)
    requirements = RequirementManager(instance).load()
    if topic in TOPICS[:4]:
        artifact = read_json(_proposal_path(instance, topic))
    else:
        path = {"analysis_plan": instance.plan_path,
                "dependencies": instance.plans_dir / "dependency_gap_report.yaml",
                "production": instance.pipeline_lock_path}[topic]
        artifact = read_yaml(path)
    material = {"project": str(instance.root), "topic": topic,
                "requirements_fingerprint": requirements["requirements_fingerprint"], "artifact": artifact}
    if topic == "production":
        from microbiome.pipeline.approval import ProductionApprovalManager
        material["validation_summary"] = ProductionApprovalManager(instance).render_validation_summary()
    from microbiome.integrations.delegation import load_authorization
    authorization = load_authorization(instance)
    if authorization["mode"] == "host_delegated":
        material["authorization_fingerprint"] = authorization["authorization_fingerprint"]
    return {**material, "decision_fingerprint": object_fingerprint(material),
            "approval_channel": ("project-scoped host delegation or interactive local operator CLI"
                                 if authorization["mode"] == "host_delegated"
                                 else "interactive local operator CLI; host delegation is not enabled")}


def _apply_operator_decision(project: str, topic: str, action: str, expected: str) -> dict:
    """Internal CLI-only boundary. The caller must obtain an actual operator response."""
    from microbiome.pipeline.requirements import ConfirmationAction
    instance = project_at(project)
    with project_lock(instance):
        snapshot = decision_snapshot(project, topic)
        if snapshot["decision_fingerprint"] != expected:
            raise ConfigurationError("STALE_DECISION: review the changed artifact before deciding")
        return _apply_reviewed_decision(instance, snapshot, ConfirmationAction(action))


def _apply_reviewed_decision(instance: PipelineProject, snapshot: dict, decision,
                             *, decision_source: dict | None = None) -> dict:
    """Apply a reviewed snapshot while the caller holds the project lock."""
    from microbiome.pipeline.requirements import ConfirmationAction, RequirementManager
    from microbiome.pipeline.dependencies import confirm_plan, DependencyResolver
    topic = snapshot["topic"]
    if topic in TOPICS[:4]:
        proposal = snapshot["artifact"]
        if topic == "input" and decision is ConfirmationAction.CONFIRM:
            manifest = proposal["manifest"]
            if manifest.get("manifest_fingerprint") != object_fingerprint(
                {k: v for k, v in manifest.items() if k != "manifest_fingerprint"}
            ):
                raise ConfigurationError("Input proposal fingerprint is invalid")
            for sample in manifest["samples"]:
                for key in ("r1", "r2", "fasta"):
                    if sample.get(key) and not Path(sample[key]["path"]).is_file():
                        raise ConfigurationError("Confirmed local input is missing; resolve it again")
            write_yaml(instance.requirements_dir / "input_manifest.yaml", manifest)
        return RequirementManager(instance).decide(topic, proposal["value"], action=decision,
                                                   decision_source=decision_source)
    if topic == "analysis_plan":
        return confirm_plan(instance, decision, decision_source=decision_source)
    if topic == "dependencies":
        return DependencyResolver(instance).approve(decision, decision_source=decision_source)
    from microbiome.pipeline.approval import ProductionApprovalManager
    message = {"CONFIRM": "确认全量执行", "MODIFY": "修改方案", "CANCEL": "先等等"}[decision.value]
    return ProductionApprovalManager(instance).handle(message, decision_source=decision_source)


def execution_binding(project: PipelineProject) -> dict:
    """Fingerprint all execution contracts at submission and check them in the worker."""
    paths = [project.config_path, project.requirements_path, project.plan_path,
             project.requirements_dir / "input_manifest.yaml",
             project.plans_dir / "dependency_gap_report.yaml", project.pipeline_lock_path,
             project.toolchain_lock_path, project.database_lock_path,
             project.pipeline_dir / "production_approval.yaml"]
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None for path in paths}


def dispatch(operation: str, arguments: dict | None = None) -> dict:
    """Invoke only explicit public operations, with protocol-clean structured results."""
    from microbiome.integrations.jobs import cancel_job, start_job, job_status
    from microbiome.integrations.sequence_stats import sequence_stats
    from microbiome.integrations.delegation import configure_authorization, inspect_authorization, record_decision
    operations = {
        "catalog.list": catalog_list, "catalog.show": catalog_show, "catalog.search": catalog_search,
        "project.inspect": inspect_project, "software.inspect": inspect_software,
        "input.resolve": resolve_input, "planning.context": planning_context,
        "requirements.propose": propose_requirement, "plan.validate": validate_plan, "plan.save": save_plan,
        "dependencies.preview": preview_dependencies, "dependencies.review": review_dependencies,
        "decision.inspect": decision_snapshot, "job.start": start_job, "job.status": job_status,
        "approval.configure": configure_authorization, "approval.inspect": inspect_authorization,
        "decision.record": record_decision,
        "job.cancel": cancel_job,
        "sequence.stats": sequence_stats,
    }
    try:
        if operation not in operations or (arguments is not None and not isinstance(arguments, dict)):
            raise ConfigurationError("Unknown operation or invalid arguments")
        with _OUTPUT_LOCK, contextlib.redirect_stdout(sys.stderr):
            value = operations[operation](**(arguments or {}))
        return {"schema_version": SCHEMA_VERSION, "ok": True, "result": value}
    except Exception as error:
        return {"schema_version": SCHEMA_VERSION, "ok": False,
                "error": {"code": type(error).__name__, "message": str(error)}}
