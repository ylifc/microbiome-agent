"""JSON workflow client and interactive operator decision channel."""
from __future__ import annotations

import argparse
import contextlib
import json
import sys
from pathlib import Path

from microbiome.integrations.service import dispatch


def main(argv=None):
    parser = argparse.ArgumentParser(prog="microbiome-service")
    commands = parser.add_subparsers(dest="command", required=True)
    call = commands.add_parser("call", help="Call the same versioned operation used by MCP")
    call.add_argument("operation")
    source = call.add_mutually_exclusive_group()
    source.add_argument("--json", default="{}", help="Operation arguments as JSON")
    source.add_argument("--file", help="JSON argument file; '-' reads stdin")
    init = commands.add_parser("init", help="Explicitly initialize user-designated project paths")
    for name in ("project", "raw-data", "database", "output"):
        init.add_argument("--" + name, required=True)
    decision = commands.add_parser("decide", help="Review and decide in an actual operator terminal; unavailable over MCP")
    decision.add_argument("--project", required=True)
    decision.add_argument("--topic", required=True)
    decision.add_argument("--action", required=True, choices=("CONFIRM", "MODIFY", "CANCEL"))
    decision.add_argument("--expected", required=True, help="Exact decision_fingerprint returned by decision.inspect")
    export = commands.add_parser("export", help="Export a thin skill and host settings without modifying host configuration")
    export.add_argument("--host", choices=("codex", "vscode", "workbuddy"), required=True)
    export.add_argument("--output", required=True)
    export.add_argument("--mcp-url", help="Use an already running loopback HTTP MCP endpoint instead of stdio")
    args = parser.parse_args(argv)
    try:
        if args.command == "call":
            if args.file:
                payload = json.loads(sys.stdin.read() if args.file == "-" else Path(args.file).read_text())
            else:
                payload = json.loads(args.json)
            response = dispatch(args.operation, payload)
        elif args.command == "init":
            from microbiome.pipeline.project import PipelineProject
            from microbiome.integrations.service import inspect_project
            with contextlib.redirect_stdout(sys.stderr):
                if not Path(args.project).expanduser().is_absolute():
                    raise ValueError("project must be an absolute path")
                if (Path(args.project) / "project_config.yaml").exists():
                    raise ValueError("Project exists; use project.inspect instead of reinitializing it")
                project = PipelineProject.initialize(args.project, raw_data_path=args.raw_data,
                                                     database_path=args.database, output_path=args.output)
                result = inspect_project(str(project.root))
            response = {"schema_version": 1, "ok": True, "result": result}
        elif args.command == "export":
            import shutil
            if args.mcp_url:
                from urllib.parse import urlsplit
                parsed = urlsplit(args.mcp_url)
                if (parsed.scheme != "http" or parsed.hostname not in {"localhost", "127.0.0.1", "::1"}
                        or parsed.username or parsed.password or parsed.query or parsed.fragment
                        or parsed.path != "/mcp"):
                    raise ValueError("--mcp-url must be a loopback HTTP URL ending in /mcp, without credentials or query")
                if parsed.port is None:
                    raise ValueError("--mcp-url requires an explicit port")
            output = Path(args.output).expanduser().resolve()
            output.mkdir(parents=True, exist_ok=False)
            templates = Path(__file__).parent / "templates"
            shutil.copytree(templates / "skills/microbiome-workflow", output / "microbiome-workflow")
            if args.host == "codex":
                configuration = (templates / "configs/codex.toml").read_text()
                configuration = configuration.replace('"/absolute/runtime/bin/python"', json.dumps(sys.executable))
                if args.mcp_url:
                    configuration = '[mcp_servers.microbiome]\nurl = ' + json.dumps(args.mcp_url) + '\ntool_timeout_sec = 120\n'
                (output / "config.toml").write_text(configuration)
            elif args.host == "vscode":
                configuration = json.loads((templates / "configs/vscode.json").read_text())
                configuration["servers"]["microbiome"]["command"] = sys.executable
                if args.mcp_url:
                    configuration["servers"]["microbiome"] = {"type": "http", "url": args.mcp_url}
                (output / "mcp.json").write_text(json.dumps(configuration, indent=2) + "\n")
            response = {"schema_version": 1, "ok": True, "result": {
                "directory": str(output), "host": args.host,
                "runtime_python": sys.executable,
                "transport": "http" if args.mcp_url else "stdio", "mcp_url": args.mcp_url,
                "next": "Import the local skill and review/merge host settings; add the runtime bin directory to PATH for CLI use",
                "mcp_configuration": "not generated; WorkBuddy connector configuration requires host-specific verification" if args.host == "workbuddy" else "generated",
            }}
        else:
            from microbiome.integrations.service import decision_snapshot, _apply_operator_decision
            if not sys.stdin.isatty() or not sys.stderr.isatty():
                raise ValueError("Decisions require an interactive operator terminal; no piped or MCP approval")
            snapshot = decision_snapshot(args.project, args.topic)
            if snapshot["decision_fingerprint"] != args.expected:
                raise ValueError("STALE_DECISION: inspect the current artifact again")
            print(json.dumps(snapshot, ensure_ascii=False, indent=2), file=sys.stderr)
            challenge = args.action + " " + args.expected[:12]
            print(f"Review the exact artifact above. Type {challenge!r} to record your decision:", file=sys.stderr)
            if sys.stdin.readline().strip() != challenge:
                raise ValueError("Decision not recorded")
            with contextlib.redirect_stdout(sys.stderr):
                result = _apply_operator_decision(args.project, args.topic, args.action, args.expected)
            response = {"schema_version": 1, "ok": True, "result": result}
    except Exception as error:
        response = {"schema_version": 1, "ok": False, "error": {"code": type(error).__name__, "message": str(error)}}
    print(json.dumps(response, ensure_ascii=False, indent=2))
    return 0 if response["ok"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
