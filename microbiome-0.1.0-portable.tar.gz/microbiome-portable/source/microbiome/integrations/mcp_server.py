"""Stdio or loopback Streamable HTTP MCP adapter (MCP SDK 1.x)."""
from __future__ import annotations

from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations

from microbiome.integrations.service import dispatch


def create_server(*, port: int = 8765) -> FastMCP:
    server = FastMCP("Microbiome Workflow", host="127.0.0.1", port=port, instructions=(
        "Use curated workflow guides to design candidates. The pipeline engine validates and executes them. "
        "Default approvals use the operator CLI. An explicitly user-authorized project delegation "
        "allows the host to record fingerprint-bound decisions with honest delegation provenance. "
        "Long jobs have durable IDs on the execution machine; do not resubmit when the chat disconnects."
    ))

    @server.tool()
    def microbiome_sequence_stats(inputs: list[str], output: str, paired: bool = False) -> dict:
        """Inspect one/two explicit local FASTA/FASTQ files, including gzip, without a model or scientific pipeline.

        Creates only statistics and execution provenance in a new output directory outside input directories.
        Verifies nucleotide records, lengths/GC and optional paired FASTQ identifiers (R1,R2 order).
        Bounded to 256 MiB decompressed input and 2,000,000 total records. No approval/state changes,
        network, downloads, installation or scientific commands; never substitutes for a frozen analysis.
        """
        return dispatch("sequence.stats", {"inputs": inputs, "output": output, "paired": paired})

    @server.tool(annotations=ToolAnnotations(readOnlyHint=True))
    def microbiome_catalog(action: str = "list", query: str = "", workflow_id: str = "", limit: int = 4) -> dict:
        """List workflow metadata, show one guide, or search curated analysis guidance; never runs tools."""
        if action == "list":
            return dispatch("catalog.list")
        if action == "show":
            return dispatch("catalog.show", {"workflow_id": workflow_id})
        if action == "search":
            return dispatch("catalog.search", {"query": query, "limit": limit})
        raise ValueError("action must be list, show or search")

    @server.tool(annotations=ToolAnnotations(readOnlyHint=True))
    def microbiome_software_inspect(project: str, logical_tool: str, executable: str | None = None,
                                    software_family: str | None = None, environment_name: str | None = None) -> dict:
        """Inspect existing environments, executable/version/help and package ownership without installation/writeback.

        Keep logical capability, executable, software family and preferred environment separate.
        Missing mapping is discovery work, not a reason to guess a package or install software.
        """
        return dispatch("software.inspect", {"project": project, "logical_tool": logical_tool, "executable": executable,
                                             "software_family": software_family, "environment_name": environment_name})

    @server.tool(annotations=ToolAnnotations(readOnlyHint=True))
    def microbiome_project_status(project: str) -> dict:
        """Read persistent project state, approvals and report paths across host conversations."""
        return dispatch("project.inspect", {"project": project})

    @server.tool()
    def microbiome_resolve_input(project: str, declaration: str) -> dict:
        """Resolve explicit local files/manifest into a pending input proposal; never approve or download."""
        return dispatch("input.resolve", {"project": project, "declaration": declaration})

    @server.tool()
    def microbiome_propose_requirement(project: str, topic: str, value: dict) -> dict:
        """Propose dataset, target or analysis_goal for operator review; does not confirm it."""
        return dispatch("requirements.propose", {"project": project, "topic": topic, "value": value})

    @server.tool()
    def microbiome_planning_context(project: str, query: str, workflow_ids: list[str] | None = None) -> dict:
        """Read selected full workflow guides and project evidence after requirements/input confirmation.

        For each selected reference, the candidate plan must provide workflow_decisions with
        workflow_id, disposition (use/adapt/not_applicable), reason and actual step_ids.
        """
        return dispatch("planning.context", {"project": project, "query": query, "workflow_ids": workflow_ids})

    @server.tool()
    def microbiome_plan(plan: dict, project: str = "", save: bool = False) -> dict:
        """Validate a candidate plan; optionally persist it for review after requirements are confirmed."""
        return dispatch("plan.save" if save else "plan.validate", {"plan": plan, **({"project": project} if save else {})})

    @server.tool()
    def microbiome_dependencies(project: str, review_confirmed_plan: bool = False, plan: dict | None = None) -> dict:
        """Preview local resources or create the dependency decision report for an already confirmed plan. No install."""
        if review_confirmed_plan and plan is not None:
            raise ValueError("Review uses the saved confirmed plan; omit plan")
        return dispatch("dependencies.review" if review_confirmed_plan else "dependencies.preview",
                        {"project": project, **({} if review_confirmed_plan else {"plan": plan})})

    @server.tool(annotations=ToolAnnotations(readOnlyHint=True))
    def microbiome_decision_review(project: str, topic: str) -> dict:
        """Get exact material/fingerprint for an operator decision. This tool cannot approve anything."""
        return dispatch("decision.inspect", {"project": project, "topic": topic})

    @server.tool()
    def microbiome_approval_mode(project: str, action: str = "inspect", mode: str = "",
                                 user_request: str = "", source: str = "", scope: str = "",
                                 topics: list[str] | None = None) -> dict:
        """Inspect mode or configure project delegation only at the user's explicit request.

        Preserve the real user request, conversation source, scope and allowed topics.
        This records a host assertion, not independent authentication. Interactive mode
        uses an empty topic list and stops future delegated decisions, not existing jobs.
        """
        if action == "inspect":
            return dispatch("approval.inspect", {"project": project})
        if action != "configure":
            raise ValueError("action must be inspect or configure")
        return dispatch("approval.configure", {"project": project, "mode": mode,
                        "user_request": user_request, "source": source, "scope": scope, "topics": topics})

    @server.tool()
    def microbiome_record_decision(project: str, topic: str, action: str, expected: str,
                                    authorization_fingerprint: str, reason: str) -> dict:
        """Record a reviewed decision under explicit project delegation, retaining all scientific gates.

        Read decision_review first; pass its full current fingerprint and the active
        authorization fingerprint. Explain the review in reason. Never invent the user's
        request or use this when project delegation is absent or outside its scope.
        """
        return dispatch("decision.record", {"project": project, "topic": topic, "action": action,
                        "expected": expected, "authorization_fingerprint": authorization_fingerprint,
                        "reason": reason})

    @server.tool()
    def microbiome_job_start(project: str, operation: str, request_id: str, parameters: dict | None = None) -> dict:
        """Start bootstrap, resolve_databases, pretest, finalize or frozen production behind existing approval gates.

        Bootstrap may install only dependencies already explicitly approved in the current dependency plan.
        Reuse the same request_id when retrying submission; query the returned durable job_id after disconnects.
        """
        return dispatch("job.start", {"project": project, "operation": operation, "request_id": request_id, "parameters": parameters})

    @server.tool()
    def microbiome_job_status(project: str, job_id: str) -> dict:
        """Read durable local job status and result/log paths; a dead worker is reported as interrupted."""
        return dispatch("job.status", {"project": project, "job_id": job_id})

    @server.tool()
    def microbiome_job_cancel(project: str, job_id: str) -> dict:
        """Cancel only the verified process group for this local job; never deletes project artifacts."""
        return dispatch("job.cancel", {"project": project, "job_id": job_id})

    return server


def main(argv=None):
    import argparse
    parser = argparse.ArgumentParser(prog="microbiome-mcp", description=__doc__)
    parser.add_argument("--transport", choices=("stdio", "http"), default="stdio")
    parser.add_argument("--port", type=int, default=8765, help="Loopback HTTP port; endpoint is /mcp")
    args = parser.parse_args(argv)
    if not 1 <= args.port <= 65535:
        parser.error("--port must be between 1 and 65535")
    create_server(port=args.port).run(transport="streamable-http" if args.transport == "http" else "stdio")


if __name__ == "__main__":
    main()
