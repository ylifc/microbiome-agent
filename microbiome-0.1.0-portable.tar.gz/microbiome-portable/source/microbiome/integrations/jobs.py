"""Durable single-machine jobs independent of the MCP/chat process.

This is not a remote scheduler. A host change reconnects to the same project
on the same Linux machine. Crashes are reported, never automatically replayed.
"""
from __future__ import annotations

import hashlib
import os
import re
import signal
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path

from microbiome.pipeline.errors import ConfigurationError
from microbiome.pipeline.io import object_fingerprint, read_json, write_json

_CHILDREN: dict[str, subprocess.Popen] = {}
TERMINAL = {"completed", "failed", "cancelled", "interrupted"}


class JobCancelled(BaseException):
    """Cancellation must cross scientific code's OSError/Exception handlers."""


PARAMETERS = {
    "bootstrap": set(), "resolve_databases": set(),
    "pretest": {"fraction"},
    "finalize": {"new_version"},
    "production": {"run_id", "threads", "memory_gb", "gpus", "resume"},
}


def _now():
    return datetime.now(UTC).isoformat()


def _process(pid: int) -> str | None:
    """Linux PID start time prevents signalling a recycled PID."""
    try:
        parts = Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()
        return None if parts[0] == "Z" else parts[19]
    except (FileNotFoundError, ProcessLookupError, IndexError):
        return None


def _directory(project, job_id):
    if not re.fullmatch(r"[a-f0-9]{32}", job_id):
        raise ConfigurationError("Invalid job_id")
    return project.state_dir / "portable" / "jobs" / job_id


def _request(operation: str, parameters: dict) -> None:
    if operation not in PARAMETERS or not isinstance(parameters, dict) or parameters.keys() - PARAMETERS[operation]:
        raise ConfigurationError("Unsupported job operation or parameters")
    if operation == "pretest" and "fraction" in parameters:
        from microbiome.pipeline.cases import validate_pretest_fraction
        validate_pretest_fraction(parameters["fraction"])
    for name in ("new_version", "resume"):
        if name in parameters and type(parameters[name]) is not bool:
            raise ConfigurationError(f"{name} must be a boolean")


def _gate(project, operation):
    from microbiome.integrations.service import confirmed_manifest
    from microbiome.pipeline.state import LifecycleState, ProjectStateMachine
    from microbiome.pipeline.dependencies import require_bootstrap_approval
    from microbiome.pipeline.lifecycle import load_plan
    confirmed_manifest(project)
    if operation in {"bootstrap", "resolve_databases", "pretest"}:
        allowed = {"bootstrap": (LifecycleState.BOOTSTRAP,),
                   "resolve_databases": (LifecycleState.BOOTSTRAP, LifecycleState.PRETEST_PREPARATION),
                   "pretest": (LifecycleState.PRETEST_PREPARATION, LifecycleState.PRETEST_REPAIR)}[operation]
        require_bootstrap_approval(project, load_plan(project), allowed_states=allowed)
    elif operation == "production":
        from microbiome.pipeline.approval import ProductionApprovalManager
        ProductionApprovalManager(project).require_valid_approval()
    else:
        ProjectStateMachine(project).require(LifecycleState.PRETEST_PASSED, LifecycleState.VALIDATED,
                                             LifecycleState.PRETEST_FINALIZATION_FAILED)


def start_job(project: str, operation: str, request_id: str, parameters: dict | None = None) -> dict:
    from microbiome.integrations.service import execution_binding, project_at, project_lock
    if not sys.platform.startswith("linux"):
        raise ConfigurationError("Portable job execution currently requires Linux or WSL2")
    if not isinstance(request_id, str) or not 1 <= len(request_id) <= 200:
        raise ConfigurationError("A stable request_id of 1–200 characters is required")
    parameters = {} if parameters is None else parameters
    _request(operation, parameters)
    instance = project_at(project)
    request = {"project": str(instance.root), "operation": operation, "parameters": parameters, "request_id": request_id}
    job_id = hashlib.sha256((str(instance.root) + "\0" + request_id).encode()).hexdigest()[:32]
    directory = _directory(instance, job_id)
    request_hash = object_fingerprint(request)
    if (directory / "request.json").is_file():
        if read_json(directory / "request.json")["request_fingerprint"] != request_hash:
            raise ConfigurationError("request_id already identifies a different operation")
        return {**job_status(project, job_id), "reused": True}
    with project_lock(instance):
        # Submission and the worker share the existing project operation lock.
        # This closes the gap between process creation and worker lock acquisition.
        for path in (instance.state_dir / "portable" / "jobs").glob("*/status.json"):
            if job_status(project, path.parent.name)["status"] not in TERMINAL:
                raise ConfigurationError("PROJECT_BUSY: another portable job is queued/running")
        _gate(instance, operation)
        request.update(request_fingerprint=request_hash, binding=execution_binding(instance), job_id=job_id)
        directory.mkdir(parents=True, exist_ok=False)
        write_json(directory / "request.json", request)
        write_json(directory / "status.json", {"job_id": job_id, "operation": operation, "status": "queued", "created_at": _now()})
        try:
            # A detached local worker survives MCP shutdown. No model credentials are required.
            with (directory / "worker.log").open("ab") as output:
                child = subprocess.Popen([sys.executable, "-m", "microbiome.integrations.jobs", str(directory / "request.json")],
                                         cwd=Path(__file__).resolve().parents[2], stdin=subprocess.DEVNULL,
                                         stdout=output, stderr=output, start_new_session=True)
            _CHILDREN[job_id] = child
            write_json(directory / "process.json", {"pid": child.pid, "start_time": _process(child.pid)})
        except Exception as error:
            write_json(directory / "status.json", {"job_id": job_id, "operation": operation, "status": "failed", "error": str(error)})
            raise
    return {"job_id": job_id, "status": "queued", "project": str(instance.root), "reused": False}


def job_status(project: str, job_id: str) -> dict:
    from microbiome.integrations.service import project_at
    directory = _directory(project_at(project), job_id)
    state = read_json(directory / "status.json")
    if job_id in _CHILDREN and _CHILDREN[job_id].poll() is not None:
        _CHILDREN.pop(job_id)
    if state["status"] not in TERMINAL and (directory / "process.json").is_file():
        process = read_json(directory / "process.json")
        if not process["start_time"] or _process(process["pid"]) != process["start_time"]:
            # Re-read to avoid overwriting a terminal result published just before exit.
            state = read_json(directory / "status.json")
            if state["status"] not in TERMINAL:
                state.update(status="interrupted", error="Worker exited; inspect state before an explicit retry", finished_at=_now())
                write_json(directory / "status.json", state)
    return {**state, "result_path": str(directory / "result.json"), "log_path": str(directory / "worker.log")}


def cancel_job(project: str, job_id: str) -> dict:
    from microbiome.integrations.service import project_at
    directory = _directory(project_at(project), job_id)
    state = job_status(project, job_id)
    if state["status"] in TERMINAL:
        return state
    process = read_json(directory / "process.json")
    if not process["start_time"] or _process(process["pid"]) != process["start_time"]:
        raise ConfigurationError("Worker identity changed; refusing to signal another process")
    write_json(directory / "cancel.json", {"requested_at": _now()})
    os.killpg(process["pid"], signal.SIGTERM)
    return {"job_id": job_id, "status": "cancelling", "note": "Query job.status for the durable terminal outcome"}


def _execute(project, operation, parameters):
    if operation == "bootstrap":
        from microbiome.pipeline.lifecycle import bootstrap_toolchain
        return bootstrap_toolchain(project)
    if operation == "resolve_databases":
        from microbiome.pipeline.lifecycle import resolve_databases
        return resolve_databases(project)
    if operation == "pretest":
        from microbiome.pipeline.cases import validate_manifest_cases
        from microbiome.integrations.service import confirmed_manifest
        return validate_manifest_cases(project, confirmed_manifest(project), all_samples=True, **parameters)
    if operation == "finalize":
        from microbiome.pipeline.finalizer import ValidationFinalizer
        return ValidationFinalizer(project).finalize_pretest(**parameters)
    from microbiome.pipeline.execution import FrozenPipelineExecutor
    from microbiome.pipeline.inputs import ProductionInputResolver
    from microbiome.pipeline.batch import execute_batch
    from microbiome.pipeline.io import read_yaml
    pipeline = read_yaml(project.pipeline_lock_path)
    return execute_batch(project, FrozenPipelineExecutor(project), pipeline,
                         ProductionInputResolver(project, pipeline), **parameters)


def main(argv=None):
    import time
    from microbiome.integrations.service import execution_binding, project_at, project_lock
    request_path = Path((argv or sys.argv[1:])[0]).resolve()
    request = read_json(request_path)
    instance = project_at(request["project"])
    directory = _directory(instance, request["job_id"])
    if request_path != directory / "request.json":
        raise ConfigurationError("Job request is outside its managed directory")
    state = read_json(directory / "status.json")

    def cancelled(*_):
        raise JobCancelled("Cancellation requested")

    signal.signal(signal.SIGTERM, cancelled)
    try:
        # Parent publishes the PID identity before releasing the project lock.
        for _ in range(100):
            if (directory / "process.json").is_file():
                break
            time.sleep(0.01)
        with project_lock(instance, blocking=True):
            if (directory / "cancel.json").is_file():
                raise JobCancelled("Cancellation requested")
            if execution_binding(instance) != request["binding"]:
                raise ConfigurationError("STALE_JOB: project contracts changed after submission")
            _request(request["operation"], request["parameters"])
            _gate(instance, request["operation"])
            instance.export_paths()
            state.update(status="running", started_at=_now())
            write_json(directory / "status.json", state)
            result = _execute(instance, request["operation"], request["parameters"])
            write_json(directory / "result.json", result)
            failed = isinstance(result, dict) and (result.get("status") in {"FAILED", "ERROR", "BLOCKED"} or result.get("ready") is False)
            state.update(status="failed" if failed else "completed", finished_at=_now())
    except JobCancelled as error:
        state.update(status="cancelled", error=str(error), finished_at=_now())
    except Exception as error:
        state.update(status="failed", error=str(error), error_code=type(error).__name__, finished_at=_now())
    write_json(directory / "status.json", state)
    return 0 if state["status"] == "completed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
