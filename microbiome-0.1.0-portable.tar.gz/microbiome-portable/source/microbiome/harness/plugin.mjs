/** Host-routed models and session-owned Microbiome background operations. */
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { createHash, randomUUID } from 'node:crypto'
import { setTimeout as delay } from 'node:timers/promises'

export const name = 'microbiome-harness'
export const inject = ['tools', 'llm', 'subprocess', 'jobs']
const directory = path.dirname(fileURLToPath(import.meta.url))
const FRAME_LIMIT = 32 * 1024 * 1024

export function latestUser(session) {
  const event = [...session.events].reverse().find(e => e.type === 'user/message' && e.data.source?.kind === 'user')
  if (!event) throw new Error('No actual user message is available')
  const text = event.data.content.filter(b => b.type === 'text').map(b => b.text).join('\n')
  if (!text.trim()) throw new Error('A textual user task or confirmation is required')
  return { text, id: String(event.data.id ?? event.seq) }
}

function bound(text, limit) {
  const bytes = Buffer.from(text)
  return bytes.length <= limit ? text : bytes.subarray(0, limit - 80).toString('utf8') + '\n[完整记录已保存到项目文件]'
}

function hostMessages(messages, route) {
  return messages.map(m => {
    let content = typeof m.content === 'string' ? [{ type: 'text', text: m.content }] : m.content
    if (!Array.isArray(content) || content.some(b => b.type !== 'text')) throw new Error('Unsupported input; provide text summaries')
    if (m.tool_calls?.length) content = [...content, ...m.tool_calls.map(c => ({
      type: 'tool-call', id: c.id, name: c.name, arguments: JSON.stringify(c.args),
    }))]
    if (m.role === 'tool') return { id: randomUUID(), role: 'user', source: { kind: 'tool', callId: m.tool_call_id },
      content: [{ type: 'tool-result', toolCallId: m.tool_call_id, content }] }
    if (!['system', 'user', 'assistant'].includes(m.role)) throw new Error('Unsupported message role')
    return { id: randomUUID(), role: m.role, content, source: m.role === 'assistant'
      ? { kind: 'model', provider: route.provider, model: route.model }
      : { kind: 'plugin', plugin: name } }
  })
}

/** Never resolve credentials: serve calls through the captured host model route. */
export async function hostCompletion(ctx, session, route, params, signal, attempts = 3) {
  if (!route?.provider || !route?.model) throw new Error('HARNESS_UNAVAILABLE: current session has no model route')
  const messages = hostMessages(params.messages, route)
  const tools = (params.tools ?? []).map(t => ({ name: t.function.name,
    description: t.function.description ?? '', parameters: t.function.parameters }))
  for (let attempt = 1; attempt <= attempts; attempt++) {
    signal.throwIfAborted()
    const prepared = await ctx.llm.prepareCall({ ...route, ...(params.stop?.length ? { stop: params.stop } : {}) }, signal)
    const request = { ...prepared.config, messages, sessionId: session.id, signal,
      ...(tools.length ? { tools } : {}) }
    const { signal: _signal, ...record } = request
    session.append('microbiome/model-request', { attempt, request: record })
    let text = '', usage = {}, finish, failure
    const calls = new Map(), completed = new Map()
    try {
      for await (const chunk of prepared.stream(request)) {
        if (chunk.type === 'text-delta') text += chunk.text
        if (chunk.type === 'block-end') completed.set(chunk.index, chunk.block)
        if (chunk.type === 'tool-call-delta') {
          const c = calls.get(chunk.index) ?? { id: chunk.id, name: '', arguments: '' }
          if (chunk.name) c.name = chunk.name
          c.arguments += chunk.argumentsDelta
          calls.set(chunk.index, c)
        }
        if (chunk.type === 'usage') usage = chunk.usage
        if (chunk.type === 'finish') { finish = chunk.reason; failure = chunk.reason.failure }
        if (Buffer.byteLength(text) + [...calls.values()].reduce((n, c) => n + Buffer.byteLength(c.arguments), 0) > FRAME_LIMIT / 2) throw new Error('Model response exceeds transport limit')
      }
      if (!finish) throw new Error('Model stream ended without a terminal result')
      if (finish.kind === 'error' || finish.kind === 'aborted') {
        const error = new Error(failure?.message ?? 'Model request failed')
        error.code = failure?.code
        throw error
      }
      if (finish.kind === 'max-tokens') throw new Error('Model response truncated; revise context or host output budget')
      if (!text) text = [...completed.values()].filter(b => b.type === 'text').map(b => b.text).join('')
      for (const [index, block] of completed) if (block.type === 'tool-call') calls.set(index, block)
      const result = { text, usage, tool_calls: [...calls.values()].map(c => ({
        id: c.id, name: c.name, args: JSON.parse(c.arguments || '{}'), type: 'tool_call',
      })) }
      session.append('microbiome/model-result', { attempt, result })
      return result
    } catch (error) {
      session.append('microbiome/model-error', { attempt, error: error.message, code: error.code ?? 'MODEL_ERROR', usage })
      const policy = prepared.retryPolicy
      if (signal.aborted || attempt === attempts ||
          (policy.mode !== 'always' && (!policy.retryableCodes.includes(error.code) || attempt > policy.maxRetries))) throw error
      await delay(Math.min(1000 * 2 ** (attempt - 1), 10000), undefined, { signal })
    }
  }
}

async function* frames(stream) {
  let pending = Buffer.alloc(0)
  for await (const chunk of stream) {
    pending = Buffer.concat([pending, Buffer.from(chunk)])
    let index
    while ((index = pending.indexOf(10)) >= 0) {
      if (index > FRAME_LIMIT) throw new Error('Worker frame exceeds limit')
      const value = JSON.parse(pending.subarray(0, index).toString('utf8'))
      pending = pending.subarray(index + 1)
      if (value.protocol !== 1) throw new Error('Worker protocol version mismatch')
      yield value
    }
    if (pending.length > FRAME_LIMIT) throw new Error('Worker frame exceeds limit')
  }
  if (pending.length) throw new Error('Worker ended with a partial frame')
}

/** Transfer process ownership to ctx.jobs after successful admission. */
export function startWorker(ctx, config, request, agent, route) {
  const abort = new AbortController()
  const child = ctx.subprocess.spawn({ argv: [config.python, '-m', 'microbiome.harness.worker'],
    cwd: config.runtime, env: { MICROBIOME_LLM_TRANSPORT: 'harness', PYTHONUNBUFFERED: '1' },
    stdio: { stdin: 'pipe', stdout: 'pipe', stderr: { maxBytes: 65536 } }, graceMs: 10000, signal: abort.signal })
  child.stdin.on('error', () => {}) // Process settlement reports closed input.
  const send = value => child.stdin.write(JSON.stringify({ protocol: 1, ...value }) + '\n')
  send(request)
  let pending = '', result
  const done = (async () => {
    try {
      for await (const frame of frames(child.stdout)) {
        if (frame.type === 'model_request') {
          try {
            const reply = await hostCompletion(ctx, agent.session, route, frame.params, abort.signal, config.modelAttempts)
            send({ type: 'model_response', id: frame.id, result: reply })
          } catch (error) {
            send({ type: 'model_response', id: frame.id, result: { error: error.message } })
          }
        } else if (frame.type === 'progress') {
          pending = bound(pending + JSON.stringify(frame.event) + '\n', config.outputBytes)
        } else if (frame.type === 'result') {
          result = frame.result
          pending = bound(pending + JSON.stringify(result, null, 2), config.outputBytes)
        } else throw new Error('Unknown worker event')
      }
      const outcome = await child.done
      if (!result || outcome.exitCode !== 0 || result.ok === false) {
        if (!result) pending = bound(pending + '\n' + (child.collected.stderr?.readFrom(0).text ?? ''), config.outputBytes)
        return { status: abort.signal.aborted ? 'killed' : 'failed', detail: result?.error ?? 'Worker failed; inspect project state' }
      }
      return { status: 'completed', detail: result.state ?? 'done' }
    } catch (error) {
      pending = bound(pending + '\n' + error.message, config.outputBytes)
      abort.abort()
      await child.done.catch(() => {})
      return { status: 'failed', detail: error.message }
    }
  })()
  return { cancel: () => abort.abort(), done, readOutput: () => { const text = pending; pending = ''; return text } }
}

export function apply(ctx, supplied = {}) {
  const file = path.join(directory, 'runtime.json')
  const config = { ...(fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : {}), ...supplied }
  for (const key of ['python', 'runtime', 'stateDir']) if (!path.isAbsolute(config[key] ?? '')) throw new Error(`Installation needs absolute ${key}; rerun install.sh`)
  if (config.protocol !== 1 || !Number.isInteger(config.modelAttempts) || config.modelAttempts < 1 ||
      !Number.isInteger(config.outputBytes) || config.outputBytes < 4096) throw new Error('Unsupported Microbiome runtime configuration')
  fs.mkdirSync(config.stateDir, { recursive: true, mode: 0o700 })
  const modeTools = new Set(['microbiome_workflow', 'microbiome_project_status', 'job_output', 'job_list', 'job_kill'])
  // A standing preset's allow-list also filters its own tools when inherited
  // by agents. Mask only registered global tools, and guard later additions.
  const inherited = ctx.tools.schemas().map(t => t.name).filter(n => !modeTools.has(n) && n !== 'run_code')
  if (inherited.length) ctx.effect(() => ctx.tools.restrict({ deny: inherited }))
  ctx.effect(() => ctx.tools.guard(exec => modeTools.has(exec.name) ? undefined : '请通过 Microbiome 工作流执行分析并保留确认和冻结校验。'))
  const pending = new Map()
  const bindingFile = agent => path.join(config.stateDir, createHash('sha256').update(agent.session.id).digest('hex') + '.json')
  const render = (_args, result) => [{ type: 'text', text: JSON.stringify(result, null, 2) }]
  const properties = Object.fromEntries(['project', 'data_dir', 'db_dir', 'download_dir', 'knowledge_dir'].map(k => [k, { type: 'string' }]))
  ctx.effect(() => ctx.tools.register({ name: 'microbiome_workflow',
    description: '处理用户最近一条真实消息：设计生信流程、接受实际确认、预检或冻结全量运行。新项目提供原始数据、数据库和结果项目路径。返回后台任务编号；用宿主任务工具查询。不能传入替用户编写的确认。',
    parameters: { type: 'object', properties, additionalProperties: false }, output: { schema: {}, render },
    async execute(args, exec) {
      if (!exec.agent) throw new Error('Microbiome requires a Harness session')
      for (const [key, value] of Object.entries(args)) if (!(key in properties) || typeof value !== 'string') throw new Error('Invalid workflow argument')
      exec.signal.throwIfAborted()
      const agent = exec.agent, user = latestUser(agent.session), file = bindingFile(agent)
      const prior = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : {}
      const project = path.resolve(args.project ?? prior.project ?? path.join(agent.session.header.cwd, '.microbiome', 'project'))
      if (prior.project && project !== prior.project) throw new Error('Session bound to another project; open a new session')
      if (!prior.project && !fs.existsSync(path.join(project, "project_config.yaml")) &&
          (!args.data_dir?.trim() || !args.db_dir?.trim())) {
        throw new Error("NEEDS_PATHS: provide data_dir and db_dir before binding a new project")
      }
      const key = `${agent.session.id}:${user.id}:${project}`
      if (pending.has(key)) return { job_id: pending.get(key), reused: true, project }
      const route = structuredClone(agent.session.requestHeader()?.config ?? agent.options)
      if (!route?.provider || !route?.model) throw new Error('HARNESS_UNAVAILABLE: current session has no model route')
      const id = ctx.jobs.start({ kind: 'microbiome', label: `Microbiome: ${project}`, owner: agent,
        outputLimitBytes: config.outputBytes,
        run: () => startWorker(ctx, config, { ...args, type: 'run', project, session_id: agent.session.id,
          message_id: user.id, message: user.text }, agent, route) })
      pending.set(key, id)
      const temporary = file + '.' + randomUUID()
      fs.writeFileSync(temporary, JSON.stringify({ project }), { mode: 0o600 })
      fs.renameSync(temporary, file)
      return { job_id: id, project, status: 'started', model: route.model, provider: route.provider }
    },
  }))
  ctx.effect(() => ctx.tools.register({ name: 'microbiome_project_status',
    description: '读取本会话生信项目的阶段、路径和结果报告，不启动分析或安装。',
    parameters: { type: 'object', properties: {}, additionalProperties: false }, output: { schema: {}, render },
    async execute(_args, exec) {
      if (!exec.agent) throw new Error('A Harness session is required')
      const file = bindingFile(exec.agent)
      if (!fs.existsSync(file)) return { status: 'unbound', message: '请提供原始数据、数据库和结果项目路径。' }
      const { project } = JSON.parse(fs.readFileSync(file, 'utf8'))
      const snapshotFile = path.join(project, '.microbiome-harness-status.json')
      const snapshot = fs.existsSync(snapshotFile) ? JSON.parse(fs.readFileSync(snapshotFile, 'utf8')) : {}
      const outputRoot = snapshot.output_root ?? project
      const read = (relative, root = project) => {
        const p = path.join(root, relative)
        return fs.existsSync(p) ? bound(fs.readFileSync(p, 'utf8'), config.outputBytes) : null
      }
      return { project, paths: read('project_config.yaml'), state: read('project_state.yaml', outputRoot),
        reports: fs.existsSync(path.join(outputRoot, 'reports')) ? fs.readdirSync(path.join(outputRoot, 'reports')) : [],
        recovery: '重启后请查看状态；中断批次使用“恢复批次 <batch-id>”，不要重新批准一个新批次。' }
    },
  }))
}
