"""Conversational UI orchestration; scientific execution stays in the frozen workflow."""

from __future__ import annotations

import json
import re
from pathlib import Path

PATH_QUESTIONS = (
    ("data_dir", "第一阶段 · 1/3：请输入原始数据目录的绝对路径（服务器上已有的 FASTQ/FASTA 或样本清单目录）。"),
    ("db_dir", "第一阶段 · 2/3：请输入持久数据库目录的绝对路径。已有数据库将复用，不重新下载。"),
    ("project", "第一阶段 · 3/3：请输入输出目录的绝对路径，方案、预检、全量结果和报告保存在这里。"),
)


def new_guided_state():
    return {
        "enabled": True,
        "path_step": 0,
        "path_engaged": False,
        "draft_paths": {},
        "ready": False,
        "tasks": [],
        "plan_confirmation": None,
        "fraction": 0.10,
        "fraction_confirmed": False,
    }


class GuidedConversation:
    @staticmethod
    def _valid_stage(value):
        return value if type(value) is int and 1 <= value <= 6 else None

    def _message_stage(self, state):
        guided = state.get("guided", {})
        if not guided.get("ready") and not guided.get("path_engaged"):
            return None
        return self._valid_stage(self._guided_public(state).get("current_stage"))

    def _prepare_guided_paths(self, state, *, refresh=False):
        """Migrate stored paths into a reviewable draft, never automatic authority."""
        before = json.dumps(state.get("guided"), sort_keys=True)
        guided = state.setdefault("guided", new_guided_state())
        if not guided.get("ready") and (refresh or not guided.get("path_engaged")):
            bindings = dict(state.get("bindings") or {})
            if bindings.get("project") and not all(bindings.get(key) for key, _ in PATH_QUESTIONS):
                try:
                    from microbiome.pipeline.project import PipelineProject

                    paths = PipelineProject(bindings["project"]).load_config()["paths"]
                    for key, name in (
                        ("data_dir", "raw_data"),
                        ("db_dir", "database"),
                        ("download_dir", "download"),
                        ("knowledge_dir", "knowledge"),
                    ):
                        if paths.get(name):
                            bindings.setdefault(key, paths[name])
                except Exception:
                    pass  # Missing/corrupt projects still need the normal path questions.
            if all(bindings.get(key) for key, _ in PATH_QUESTIONS):
                guided.update(path_step=3, path_engaged=True, draft_paths=bindings)
        return before != json.dumps(guided, sort_keys=True)

    def _session_lock(self, identity):
        import threading

        with self.lock:
            return self.session_locks.setdefault(identity, threading.RLock())

    def _progress(self, state):
        from microbiome.harness.workflow_status import workflow_progress

        guided = state.get("guided", {})
        return workflow_progress(state["bindings"].get("project"), plan_confirmation=guided.get("plan_confirmation"))

    def _guided_public(self, state):
        guided = state.get("guided", {})
        progress = self._progress(state)
        active = next((t for t in guided.get("tasks", []) if not t.get("finished")), None)
        if not guided.get("ready"):
            step = guided.get("path_step", 0)
            prompt = (
                PATH_QUESTIONS[step][1]
                if step < 3
                else (
                    "请核对已保存的目录：\n"
                    + json.dumps(guided["draft_paths"], ensure_ascii=False, indent=2)
                    + "\n回复“确认路径”后继续，或“重新设置路径”。"
                )
            )
            suggestions = (
                ["开始分析"] if not guided.get("path_engaged") else (["确认路径", "重新设置路径"] if step == 3 else [])
            )
        elif progress.get("compiler_repair"):
            prompt = "候选方案尚未通过内部编译检查。回复“继续修复方案”沿用已有目标和候选重试；无需重新描述需求。"
            suggestions = ["继续修复方案"]
        elif progress.get("pending_questions"):
            prompt = "请回答以下待补充问题，回答后将沿用此前目标继续设计：\n" + "\n".join(progress["pending_questions"])
            suggestions = []
        elif progress.get("production_complete"):
            prompt, suggestions = "第六阶段 · 查看分析总结与实际报告。", ["查看报告"]
        elif progress.get("pretest_ready"):
            prompt, suggestions = "第五阶段 · 预检已通过；回复“确认全量执行”启动全量分析。", ["确认全量执行"]
        elif (
            progress.get("plan_ready")
            and progress["stages"][2]["status"] == "completed"
            and progress.get("phase")
            in {
                "BOOTSTRAP",
                "PRETEST_PREPARATION",
                "PRETEST_RUNNING",
                "PRETEST_REPAIR",
                "PRETEST_FINALIZATION_FAILED",
            }
        ):
            if progress["phase"] == "PRETEST_FINALIZATION_FAILED":
                prompt, suggestions = "第四阶段 · 验证后的冻结尚未完成，请回复“重试冻结”核验并重试。", ["重试冻结"]
            else:
                prompt = "第四阶段 · 上一次预检未完成。回复“重试预检”后将核验原批准范围，沿用已批准比例重新验证；不会自动重放确认。"
                suggestions = ["重试预检"]
        elif progress.get("plan_ready") and progress["stages"][1]["status"] != "completed":
            prompt, suggestions = progress["stages"][1]["detail"], ["重新检索并完善方案"]
        elif progress.get("plan_ready"):
            if guided.get("plan_confirmation") == progress.get("draft_fingerprint"):
                prompt = (
                    "第四阶段 · 请选择抽样比例 5%–10%；保留全部样本及配对关系。"
                    if not guided.get("fraction_confirmed")
                    else f"第四阶段 · 对全部样本按 {guided['fraction']:.0%} 抽样验证完整流程。回复“确认执行”开始。"
                )
                suggestions = ["5%", "10%"] if not guided.get("fraction_confirmed") else ["确认执行"]
            else:
                prompt, suggestions = (
                    "第三阶段 · 请审阅具体流程、参数和依赖差异，回复“确认方案”或提出修改。",
                    ["确认方案"],
                )
        else:
            if any(task.get("kind") == "planning" for task in guided.get("tasks", [])):
                prompt = (
                    "第二阶段 · 已保留此前对话和补充说明。请回答上一次问题、补充或更正信息，"
                    "或回复“继续完善方案”；不必重述整个目标。"
                )
                suggestions = ["继续完善方案"]
                progress["stages"][1]["detail"] = "此前目标、补充说明和任务记录已保存，将沿用这些上下文继续设计。"
            else:
                prompt = (
                    "第二阶段 · 请说明具体分析目标、数据类型、样本分组和期望交付物；将结合本地知识库及网络文献设计方案。"
                )
                suggestions = []
        if active:
            prompt = active.get("progress") or "后台正在处理当前阶段，进度和结果会自动回到此对话。"
            suggestions = ["取消任务"]
            stage = self._valid_stage(active.get("stage")) or {"planning": 2, "pretest": 4, "production": 5}.get(
                active.get("kind"), progress["current_stage"]
            )
            for entry in progress["stages"]:
                if entry["id"] == stage:
                    entry.update(status="running", detail=prompt)
            progress["current_stage"] = stage
        public_active = {key: active.get(key) for key in ("id", "status", "kind", "progress")} if active else None
        return progress | {
            "enabled": guided.get("enabled", False),
            "prompt": prompt,
            "suggestions": suggestions,
            "active_task": public_active,
        }

    def _sync_guided(self, state):
        migrated = self._prepare_guided_paths(state)
        guided = state.get("guided")
        if not guided or not hasattr(self.manager, "get"):
            return migrated
        before = json.dumps(guided, sort_keys=True), len(state["messages"])
        for tracked in guided["tasks"]:
            if tracked.get("finished"):
                continue
            try:
                task = self.manager.get(tracked["id"])
            except KeyError:
                task = {"status": "interrupted", "result": "{}"}
            tracked["status"] = task["status"]
            try:
                events = self.manager.progress_events(tracked["id"]) if hasattr(self.manager, "progress_events") else []
            except KeyError:
                events = []  # A missing durable task stays interrupted rather than breaking chat reads.
            try:
                result = json.loads(task.get("result") or "{}")
            except (TypeError, ValueError):
                result = {"ok": False}
            if isinstance(result, dict) and isinstance(result.get("events"), list):
                events = events + result["events"]
            seen = tracked.setdefault("seen", [])
            event_stage = {"planning": 2, "pretest": 4, "production": 5}.get(tracked.get("kind"), 2)
            tracked.setdefault("stage", event_stage)
            for event in events:
                if not isinstance(event, dict):
                    continue
                content = event.get("content") or event.get("message")
                if not isinstance(content, str) or not content.strip():
                    continue
                explicit_stage = self._valid_stage(event.get("stage"))
                stage = explicit_stage or event_stage
                event_stage = stage
                tracked["stage"] = stage
                legacy_key = str(event.get("type")) + ":" + content
                key = str(stage) + ":" + legacy_key
                if key in seen or legacy_key in seen or (
                    explicit_stage is None and any(item.endswith(":" + legacy_key) for item in seen)
                ):
                    continue
                seen.append(key)
                tracked["progress"] = content[:400]
                state["messages"].append(
                    {
                        "role": "assistant",
                        "content": content,
                        "kind": event.get("type"),
                        "task_id": tracked["id"],
                        "stage": stage,
                    }
                )
            if task["status"] in {"queued", "running"}:
                continue
            tracked["finished"] = True
            compilation_failed = any(isinstance(e, dict) and (
                e.get("category") == "INTERNAL_PLAN_COMPILATION"
                or (e.get("type") == "workflow_blocked" and "内部方案编译未通过格式检查" in e.get("content", ""))
            ) for e in events)
            if compilation_failed:
                state["messages"].append({"role": "assistant", "task_id": tracked["id"], "kind": "error",
                                          "stage": tracked["stage"],
                                          "content": "内部方案编译尚未完成，候选和分析目标已保留。回复“继续修复方案”重试；无需补充目标，未启动分析。"})
            elif task["status"] != "completed" or (isinstance(result, dict) and result.get("ok") is False):
                state["messages"].append(
                    {
                        "role": "assistant",
                        "task_id": tracked["id"],
                        "kind": "error",
                        "stage": tracked["stage"],
                        "content": "本阶段尚未完成（"
                        + task["status"]
                        + "）。上方保留真实进度；请根据错误补充信息或修改方案，执行批准不会自动重放。",
                    }
                )
            elif not seen:
                state["messages"].append(
                    {
                        "role": "assistant",
                        "task_id": tracked["id"],
                        "content": "后台任务已结束，正在依据项目验收记录更新阶段状态。",
                        "stage": tracked["stage"],
                    }
                )
            progress = self._progress(state)
            if tracked["kind"] == "planning" and progress.get("draft_fingerprint") != guided.get("plan_confirmation"):
                guided["plan_confirmation"] = None
                guided["fraction_confirmed"] = False
            if progress.get("production_complete") and progress.get("reports"):
                self._deliver_report(state, progress)
            elif task["status"] == "completed":
                public = self._guided_public(state)
                state["messages"].append(
                    {"role": "assistant", "content": public["prompt"], "stage": public["current_stage"]}
                )
        return migrated or before != (json.dumps(guided, sort_keys=True), len(state["messages"]))

    def _deliver_report(self, state, progress):
        from microbiome.harness.workflow_status import read_report

        guided = state["guided"]
        names = [r["name"] for r in progress["reports"]]
        if guided.get("delivered_reports") == names:
            return
        sections = ["第六阶段 · 分析结果与报告", progress.get("report_summary", "")]
        for report in progress["reports"]:
            if report["name"].endswith(".md"):
                sections.extend(["报告：" + report["name"], read_report(state["bindings"]["project"], report["name"])])
                break
        sections.append("结果文件与可下载报告见本对话的报告列表。以上内容依据实际执行记录生成。")
        state["messages"].append({"role": "assistant", "content": "\n\n".join(sections), "kind": "report", "stage": 6})
        guided["delivered_reports"] = names

    def _submit_guided(self, state, message, kind):
        guided = state["guided"]
        payload = state["bindings"] | {
            "profile": state["profile"],
            "message": message,
            "conversation_id": state["id"],
            # Only ordinary chat history is seeded. Path/model setup and actual
            # guided approvals live in messages and are never imported as acts.
            "historical_context": [
                {"role": item["role"], "content": item["content"]} for item in state.get("history", [])
            ],
        }
        recovering = message in {"重试预检", "重试冻结"}
        if not recovering:
            payload.update(pretest_fraction=guided["fraction"], pretest_all_samples=True)
        task = self.manager.submit(payload)
        if kind == "planning":
            from microbiome.agent import A1

            if not A1._looks_like_pure_query(message):
                # A requested revision revokes UI confirmation even when its model
                # call fails and the backend retains the previous draft for reference.
                guided["plan_confirmation"] = None
                guided["fraction_confirmed"] = False
        guided["tasks"].append(
            {
                "id": task["id"],
                "kind": kind,
                "status": task.get("status", "queued"),
                "seen": [],
                "stage": {"planning": 2, "pretest": 4, "production": 5}[kind],
            }
        )
        if recovering:
            return "已收到实际重试请求。将核对当前方案、输入与原批准记录，沿用已批准的采样配置；不增加安装或下载范围。"
        return {
            "planning": "已开始分析目标与方案设计。将先解析本地输入，再读取软件知识库和检索文献，具体方案会自动显示在此对话。",
            "pretest": f"已收到实际执行确认。现在按 {guided['fraction']:.0%} 对全部样本抽样，生成并验证完整流程。",
            "production": "已收到全量执行确认。正在重放已验证的冻结流程，进度和报告会自动回到对话。",
        }[kind]

    def _guided_message(self, state, message):
        from microbiome.pipeline.errors import PipelineError

        guided = state.setdefault("guided", new_guided_state())
        active = next((t for t in guided["tasks"] if not t.get("finished")), None)
        if active:
            if message == "取消任务":
                self.manager.cancel(active["id"])
                self._sync_guided(state)
                return "取消请求已处理；已有结果和记录保留，未完成阶段不会打勾。"
            return "当前阶段仍在运行，结果会自动回到对话。可输入“取消任务”停止；本条消息不会启动另一个任务。"
        if message in {"开始分析", "重新设置路径"}:
            if guided.get("ready"):
                return self._guided_public(state)["prompt"] + " 已绑定的项目路径保留；另一个分析项目请新建对话。"
            guided.update(path_step=0, path_engaged=True, draft_paths={})
            return PATH_QUESTIONS[0][1]
        if not guided.get("ready"):
            step = guided["path_step"]
            if step < 3:
                value = message.strip().strip("\"'")
                if not guided.get("path_engaged") and not value.startswith(("/", "~/")):
                    return None
                key = PATH_QUESTIONS[step][0]
                path = Path(value).expanduser()
                if (
                    not path.is_absolute()
                    or (path.exists() and not path.is_dir())
                    or (key == "data_dir" and not path.is_dir())
                ):
                    return (
                        "目录无效：请输入服务器绝对目录，原始数据目录必须已存在。不会据此下载 SRA。\n"
                        + PATH_QUESTIONS[step][1]
                    )
                guided["draft_paths"][key] = str(path.resolve())
                guided.update(path_step=step + 1, path_engaged=True)
                if step < 2:
                    return PATH_QUESTIONS[step + 1][1]
                from microbiome.path_policy import PathPolicy

                p = guided["draft_paths"]
                policy = PathPolicy.evaluate(p["data_dir"], p["db_dir"], p["project"])
                if not policy.valid:
                    guided["path_step"] = 2
                    return "目录角色冲突：" + "; ".join(policy.errors) + "\n请重新输入输出目录，或回复“重新设置路径”。"
                return (
                    "请确认第一阶段目录：\n"
                    + json.dumps(p, ensure_ascii=False, indent=2)
                    + "\n回复“确认路径”保存，或“重新设置路径”修改。"
                )
            if message != "确认路径":
                return "请回复“确认路径”保存以上目录，或“重新设置路径”修改。"
            try:
                from microbiome.harness.worker import open_project

                project = open_project(guided["draft_paths"])
                paths = project.load_config()["paths"]
                state["bindings"] = {
                    "project": str(project.root),
                    "data_dir": paths["raw_data"],
                    "db_dir": paths["database"],
                    "download_dir": paths["download"],
                    "knowledge_dir": paths["knowledge"],
                }
            except (PipelineError, ValueError, OSError) as error:
                return "目录尚未保存：" + str(error) + "\n请回复“重新设置路径”核对。"
            guided.update(ready=True, path_engaged=False)
            return "第一阶段已完成 ✓\n" + self._guided_public(state)["prompt"]
        progress = self._progress(state)
        if message in {"查看报告", "生成报告", "总结报告"}:
            if not progress.get("production_complete") or not progress.get("reports"):
                return "全量分析或报告验收尚未完成，暂不能生成完成总结。\n" + self._guided_public(state)["prompt"]
            self._deliver_report(state, progress)
            return progress.get("report_summary") or "真实报告已显示在对话中，可从报告列表继续查看。"
        if message == "确认方案":
            if not progress.get("plan_ready") or progress["stages"][1]["status"] != "completed":
                return "尚无取证完整的具体方案可确认，请先补齐分析目标、输入或网络检索依据。"
            guided["plan_confirmation"] = progress["draft_fingerprint"]
            guided["fraction_confirmed"] = False
            guided.pop("delivered_reports", None)
            return "第三阶段方案已确认 ✓\n第四阶段：请选择抽样比例 5%–10%（例如“5%”或“10%”），保留全部样本及配对。选择后会再次询问是否执行。"
        if message in {"重试预检", "重试冻结"}:
            allowed = (
                {"PRETEST_FINALIZATION_FAILED"}
                if message == "重试冻结"
                else {
                    "BOOTSTRAP",
                    "PRETEST_PREPARATION",
                    "PRETEST_RUNNING",
                    "PRETEST_REPAIR",
                }
            )
            if (
                not progress.get("plan_ready")
                or progress["stages"][2]["status"] != "completed"
                or progress.get("phase") not in allowed
            ):
                return (
                    "当前没有可沿用原批准记录的中断预检，请先核对方案与失败原因。\n"
                    + self._guided_public(state)["prompt"]
                )
            return self._submit_guided(state, message, "pretest")
        fraction = re.fullmatch(r"(?:抽样(?:比例)?\s*)?(\d+(?:\.\d+)?)\s*%", message)
        if fraction:
            value = float(fraction[1]) / 100
            if not 0.05 <= value <= 0.10:
                return "抽样比例必须在 5%–10% 之间。"
            if progress.get("pretest_ready"):
                return "当前流程已通过预检并冻结；改变抽样方案需要修改方案并重新预检。"
            if progress.get("phase") in {"BOOTSTRAP", "PRETEST_PREPARATION", "PRETEST_RUNNING", "PRETEST_REPAIR"}:
                return "中断预检必须沿用原批准的比例；请回复“重试预检”。需要改变采样设置时，请先修改方案并重新批准。"
            if (
                not progress.get("draft_fingerprint")
                or guided.get("plan_confirmation") != progress["draft_fingerprint"]
            ):
                return "请先审阅并回复“确认方案”，再选择抽样比例。"
            guided.update(fraction=value, fraction_confirmed=True)
            return f"抽样比例已设置为 {value:.0%}，覆盖所有样本并保留配对关系。回复“确认执行”批准已展示的依赖变更和小数据全流程测试。"
        # Exact gate phrases keep phase approvals distinct and never manufacture approval text.
        if message == "确认执行":
            if progress.get("pretest_ready"):
                return "小数据流程已经通过；启动全量分析请单独回复“确认全量执行”。"
            if progress.get("phase") in {"BOOTSTRAP", "PRETEST_PREPARATION", "PRETEST_RUNNING", "PRETEST_REPAIR"}:
                return "上一次已批准的预检尚未完成，请回复“重试预检”核验并沿用原批准配置；不会重复创建执行批准。"
            if progress.get("phase") == "PRETEST_FINALIZATION_FAILED":
                return "请回复“重试冻结”核验现有预检结果，不需要重新批准执行。"
            if (
                not progress.get("plan_ready")
                or progress["stages"][1]["status"] != "completed"
                or guided.get("plan_confirmation") != progress.get("draft_fingerprint")
                or not guided.get("fraction_confirmed")
            ):
                return "请先确认具体方案并选择 5%–10% 抽样比例，然后再确认执行。"
            return self._submit_guided(state, message, "pretest")
        if message == "确认全量执行":
            if progress.get("production_complete"):
                return "本次全量分析已完成，不重复启动。可以回复“查看报告”。"
            if not progress.get("pretest_ready"):
                return "尚未通过预检和冻结验收，不能启动全量分析。"
            return self._submit_guided(state, message, "production")
        if message.startswith("恢复批次 "):
            if not progress.get("pretest_ready"):
                return "请先完成当前流程的验证与冻结，再恢复已有批次。"
            return self._submit_guided(state, message, "production")
        if progress.get("pending_questions") and message in {"继续", "同意", "可以", "确认", "是", "好的"}:
            return self._submit_guided(state, message, "planning")
        if message in {"继续", "同意", "可以", "开始", "执行", "开始全量执行", "取消任务"}:
            return self._guided_public(state)["prompt"]
        # Other actual user messages can refine goals or ask questions; broad positive
        # phrases recognized by the legacy engine may not bypass the UI phase gates.
        from microbiome.agent import A1
        from microbiome.pipeline.approval import ProductionApprovalManager, ProductionIntent

        if ProductionApprovalManager.classify_intent(
            message
        ) is ProductionIntent.APPROVE_PRODUCTION or A1.is_execution_confirmation(message):
            return self._guided_public(state)["prompt"]
        return self._submit_guided(state, message, "planning")
