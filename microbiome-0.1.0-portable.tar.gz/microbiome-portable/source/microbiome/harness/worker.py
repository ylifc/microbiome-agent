"""One project operation over bidirectional NDJSON; stdout is protocol-only."""
from __future__ import annotations

import contextlib
import fcntl
import hashlib
import json
import os
import signal
import sys
import threading
import uuid
from pathlib import Path

from microbiome.harness import PROTOCOL_VERSION

MAX_FRAME = 32 * 1024 * 1024


class Protocol:
    def __init__(self, reader=None, writer=None):
        self.reader = reader or sys.stdin
        self.writer = writer or sys.__stdout__
        self.exchange_lock = threading.RLock()

    def read(self):
        line = self.reader.readline(MAX_FRAME + 1)
        if not line or len(line.encode("utf8")) > MAX_FRAME:
            raise RuntimeError("HARNESS_PROTOCOL_CLOSED_OR_OVERSIZED")
        value = json.loads(line)
        if not isinstance(value, dict) or value.get("protocol") != PROTOCOL_VERSION:
            raise ValueError("HARNESS_PROTOCOL_VERSION_MISMATCH")
        return value

    def emit(self, kind, **fields):
        line = json.dumps({"protocol": PROTOCOL_VERSION, "type": kind, **fields}, ensure_ascii=False)
        if len(line.encode("utf8")) > MAX_FRAME:
            raise ValueError("HARNESS_PROTOCOL_FRAME_TOO_LARGE")
        self.writer.write(line + "\n")
        self.writer.flush()

    def model(self, params):
        with self.exchange_lock:
            return self._model(params)

    def _model(self, params):
        request_id = uuid.uuid4().hex
        self.emit("model_request", id=request_id, params=params)
        reply = self.read()
        if reply.get("type") != "model_response" or reply.get("id") != request_id:
            raise RuntimeError("HARNESS_PROTOCOL_RESPONSE_MISMATCH")
        return reply.get("result", {"error": "missing model result"})


def open_project(request):
    from microbiome.pipeline.project import PipelineProject
    root = Path(request["project"]).expanduser().resolve()
    if (root / "project_config.yaml").is_file():
        project = PipelineProject(root)
        # A resumed project owns its paths, not the latest tool arguments.
        paths = project.load_config()["paths"]
        for arg, key in (("data_dir", "raw_data"), ("db_dir", "database"), ("download_dir", "download"), ("knowledge_dir", "knowledge")):
            if request.get(arg) and Path(request[arg]).expanduser().resolve() != Path(paths[key]).resolve():
                raise ValueError(f"Persisted {arg} differs; open the correct project instead of changing its paths")
        return project
    if not request.get("data_dir") or not request.get("db_dir"):
        raise ValueError("NEEDS_PATHS: 新项目需要原始数据 data_dir、持久数据库 db_dir 和结果项目 project 路径")
    return PipelineProject.initialize(root, raw_data_path=request["data_dir"],
        database_path=request["db_dir"], output_path=root,
        download_path=request.get("download_dir") or root / "downloads",
        knowledge_path=request.get("knowledge_dir") or root / "knowledge")


def run_operation(request, protocol):
    if request.get("protocol") != PROTOCOL_VERSION or request.get("type") != "run":
        raise ValueError("HARNESS_PROTOCOL_VERSION_MISMATCH")
    if any(key in request for key in ("api_key", "base_url", "turns", "model", "source")):
        raise ValueError("Host model configuration cannot be supplied to the workflow worker")
    for key in ("project", "session_id", "message_id", "message"):
        if not isinstance(request.get(key), str) or not request[key].strip():
            raise ValueError(f"Missing {key}")
    root = Path(request["project"]).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    # Serialize first initialization as well as every later operation.
    with (root / ".microbiome-operation.lock").open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise RuntimeError("PROJECT_BUSY: 同一项目已有活动操作，请查询任务状态") from exc
        return _run_project_operation(request, protocol)


def _run_project_operation(request, protocol):
    project = open_project(request)
    project.export_paths()
    os.environ["MICROBIOME_RESOURCE_SKILL_ROOT"] = str(project.resource_skills_dir)
    state = project.state_dir / "harness"
    state.mkdir(parents=True, exist_ok=True)
    identity = hashlib.sha256(json.dumps([request["session_id"], request["message_id"], str(project.root)]).encode()).hexdigest()
    receipt = state / f"{identity}.json"
    from microbiome.pipeline.io import read_json, write_json
    write_json(project.root / ".microbiome-harness-status.json", {
        "protocol": 1, "output_root": str(project.output_root), "paths": project.load_config()["paths"]})
    with (state / "operation.lock").open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise RuntimeError("PROJECT_BUSY: 同一项目已有活动操作，请查询任务状态") from exc
        if receipt.is_file():
            return {**read_json(receipt), "reused": True}
        from microbiome.harness.model import HarnessChatModel, use_host_model
        os.environ["MICROBIOME_LLM_TRANSPORT"] = "harness"
        with use_host_model(HarnessChatModel(protocol.model)):
            from microbiome.agent import A1
            from microbiome.agent.workflow import ConversationWorkflow
            from microbiome.conversation_memory import merge_task_outcomes
            from microbiome.pipeline.state import ProjectStateMachine
            workflow = ConversationWorkflow(project)
            workflow.turn_id = request["message_id"]
            if "prior_task_outcomes" in request:
                history = workflow.state["history"]
                updated = merge_task_outcomes(history, request["prior_task_outcomes"])
                if len(updated) != len(history):
                    workflow.state["history"] = updated
                    workflow.save()
            if request.get("historical_context"):
                workflow.import_history(request["historical_context"], source=request["session_id"])
            agent = A1(path=str(project.state_dir / "agent_runtime"),
                       enable_datalake_download=False, require_frozen_production=True,
                       resource_skill_dirs=[str(project.resource_skills_dir)])
            agent.harness_planning = True
            workflow.guided_confirmation = bool(request.get("pretest_all_samples"))
            workflow.registry = agent.resource_skill_registry
            workflow.auto_install = True
            if "pretest_fraction" in request:
                workflow.pretest_fraction = request["pretest_fraction"]
            if "pretest_all_samples" in request:
                workflow.pretest_all_samples = request["pretest_all_samples"]
            events = []
            for event in workflow.handle(agent, request["message"]):
                events.append(event)
                protocol.emit("progress", event=event)
            result = {"ok": not any(e.get("type") in {"error", "validation_failed", "workflow_blocked"} for e in events),
                      "project": str(project.root), "events": events,
                      "state": ProjectStateMachine(project).current.value,
                      "receipt": str(receipt), "reused": False,
                      "reports": [str(p) for p in sorted(project.output_root.glob("reports/*")) if p.is_file()]}
            write_json(receipt, result)
            return result


def main():
    protocol = Protocol()
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(143))
    try:
        request = protocol.read()
        with contextlib.redirect_stdout(sys.stderr):
            result = run_operation(request, protocol)
        protocol.emit("result", result=result)
    except Exception as exc:
        protocol.emit("result", result={"ok": False, "error": str(exc)})
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
