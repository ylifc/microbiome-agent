"""Standard Microbiome Agent boundary shared by the CLI and browser task runner."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Protocol as TypingProtocol

from langchain_core.messages import convert_to_messages

from microbiome.harness.worker import Protocol, run_operation


class AgentAdapter(TypingProtocol):
    def run(self, request: dict, emit): ...
    def status(self, project: str) -> dict: ...


def project_state(project):
    """Compact authoritative state; full manifests and histories stay on disk."""
    from microbiome.conversation_memory import build_conversation_memory
    from microbiome.pipeline.io import read_yaml
    from microbiome.pipeline.project import PipelineProject

    root = Path(project)
    if not (root / "project_config.yaml").is_file():
        return {"project": str(root), "phase": "UNINITIALIZED"}
    instance = PipelineProject(root)
    state_file = instance.output_root / "project_state.yaml"
    state = read_yaml(state_file) if state_file.is_file() else {}
    manifest_file = instance.requirements_dir / "input_manifest.yaml"
    manifest = read_yaml(manifest_file) if manifest_file.is_file() else {}
    conversation_path = instance.state_dir / "conversation.json"
    conversation = json.loads(conversation_path.read_text()) if conversation_path.is_file() else {}
    draft = conversation.get("draft") or {}
    return {
        "project": str(root),
        "paths": instance.load_config()["paths"],
        "lifecycle": state,
        "input_manifest": str(manifest_file),
        "manifest_fingerprint": manifest.get("manifest_fingerprint"),
        "sample_count": len(manifest.get("samples", [])),
        "input_samples": [
            {key: sample.get(key) for key in ("sample_id", "source_type", "layout")}
            for sample in manifest.get("samples", [])
        ],
        # Keep the scientific contract even when old chat excerpts are dropped.
        # Full documents/visible prose are intentionally not duplicated here.
        "current_design": {key: draft[key] for key in ("requirements", "plan", "draft_fingerprint") if key in draft},
        # A clarification or failed attempt may not have a draft yet. Preserve
        # all user constraints and the latest outcomes even if old turns are
        # omitted from the provider request to meet its context budget.
        "conversation_memory": build_conversation_memory(conversation.get("history", [])),
        "pipeline_lock": str(instance.pipeline_lock_path),
        "frozen": instance.pipeline_lock_path.is_file(),
        "policy": "Approvals are evaluated from actual user messages by the deterministic workflow only.",
    }


class MicrobiomeAgentAdapter:
    adapter_id = "microbiome"
    protocol_version = 1

    def __init__(self, model_config):
        self.model_config = model_config

    def run(self, request, emit):
        from microbiome.harness.providers import create_model

        model = create_model(
            self.model_config,
            state=lambda: project_state(request["project"]) | {"current_user_message": request["message"]},
            record=lambda report: emit("context", report),
        )

        class LocalProtocol(Protocol):
            def emit(self, kind, **fields):
                emit(kind, fields)

            def model(self, params):
                messages = convert_to_messages(params["messages"])
                response = model.invoke(messages, stop=params.get("stop"), tools=params.get("tools", []))
                emit(
                    "model_usage",
                    {
                        "usage": response.usage_metadata or {},
                        "provider": self_config.provider,
                        "model": self_config.model,
                    },
                )
                return {
                    "text": response.content,
                    "tool_calls": response.tool_calls,
                    "usage": response.usage_metadata or {},
                }

        self_config = self.model_config
        return run_operation({"protocol": 1, "type": "run", **request}, LocalProtocol())

    def status(self, project):
        return project_state(project)


def main():
    """A task is executed in its own process to isolate project environment variables."""
    import argparse
    import contextlib
    import os
    import signal
    import sys

    if sys.platform == "linux":
        import ctypes

        # A crashed local supervisor must not leave a scientific worker running.
        def terminate_group(signum, _frame):
            signal.signal(signum, signal.SIG_DFL)
            os.killpg(os.getpgrp(), signum)

        signal.signal(signal.SIGTERM, terminate_group)
        if ctypes.CDLL(None).prctl(1, signal.SIGTERM, 0, 0, 0) != 0 or os.getppid() == 1:
            return 1
    from microbiome.harness.settings import ModelConfig

    parser = argparse.ArgumentParser()
    parser.add_argument("--task", required=True)
    args = parser.parse_args()
    task = json.loads(Path(args.task).read_text())
    writer = sys.stdout

    def emit(kind, data):
        writer.write(json.dumps({"type": kind, "data": data}, ensure_ascii=False) + "\n")
        writer.flush()

    try:
        with contextlib.redirect_stdout(sys.stderr):
            result = MicrobiomeAgentAdapter(ModelConfig.model_validate(task["model_config"])).run(task["request"], emit)
        emit("result", result)
        return 0 if result.get("ok") else 1
    except Exception as exc:
        # Provider exceptions may echo request headers. Keep the public failure generic.
        from microbiome.conversation_memory import ConversationMemoryOverflow
        from microbiome.harness.context import ContextOverflow

        message = "Task failed; check configuration, context budget and project state."
        if isinstance(exc, ContextOverflow):
            # This exception is generated locally from integer budget accounting.
            message = "模型上下文预算不足；请通过“模型设置”增大上下文长度。" + str(exc)
        elif isinstance(exc, ConversationMemoryOverflow):
            message = str(exc)
        emit(
            "error",
            {
                "category": type(exc).__name__,
                "message": message,
            },
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
