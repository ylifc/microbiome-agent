"""Installed artifact checks; no credential, environment or database mutation."""
import argparse
import importlib
import json
from pathlib import Path
import platform
import sys


def inspect_installation():
    from microbiome.harness.assets import asset_path
    from microbiome.resource_skills.audit import audit_catalog
    from microbiome.version import __version__
    errors = []
    for name in ("microbiome.agent", "microbiome.harness.worker", "microbiome.pipeline.execution",
                 "microbiome.pipeline.cohort", "microbiome.research", "microbiome.know_how"):
        try:
            importlib.import_module(name)
        except Exception as exc:
            errors.append(f"{name}: {exc}")
    assets = {}
    for name in ("cohort_tables.py", "run_dada2.R", "run_ancombc2.R"):
        try:
            assets[name] = str(asset_path(name))
        except Exception as exc:
            errors.append(str(exc))
    audit = audit_catalog()
    errors.extend(audit["errors"])
    if not (Path(__file__).parent / "plugin.mjs").is_file():
        errors.append("Harness plugin is missing")
    return {"ok": not errors, "version": __version__, "python": sys.version.split()[0],
            "platform": platform.platform(), "assets": assets, "software_skills": audit["software_count"],
            "database_skills": audit["database_count"], "errors": errors, "warnings": audit["warnings"],
            "scientific_runtime": "NOT_PROBED", "host_model": "PROBED_WHEN_HARNESS_CONNECTS"}


def main():
    argparse.ArgumentParser(description=__doc__).parse_args()
    report = inspect_installation()
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
