"""Harness-owned model transport and portable workflow integration."""

PROTOCOL_VERSION = 1
