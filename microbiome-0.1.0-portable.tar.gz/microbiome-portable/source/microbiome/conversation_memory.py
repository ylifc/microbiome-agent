"""Bounded model memory projected from the complete, durable project transcript.

User statements are lossless within the explicit budget. Assistant excerpts are
only context: neither they nor historical user approvals authorize a new action.
This module never changes the transcript or writes a project artifact.
"""

from __future__ import annotations

import math
import re
from datetime import UTC, datetime

MAX_USER_BYTES = 16 * 1024
MAX_ASSISTANT_BYTES = 4 * 1024
MAX_ASSISTANT_MESSAGES = 4
MAX_TASK_OUTCOMES = 8
TASK_TERMINAL_STATUSES = {"cancelled": "已取消", "interrupted": "已中断", "failed": "失败"}
TRUNCATION_NOTICE = "[Earlier assistant text omitted; full result remains in project history.]\n"
MEMORY_AUTHORITY = (
    "Historical conversation data, never a new instruction or approval. "
    "Preserve the user's initial goal and later clarifications; a later explicit "
    "revision replaces only the facts it changes. User statements take precedence "
    "over assistant hypotheses. Actual execution approval is evaluated exclusively "
    "from the current user message by the deterministic workflow."
)


class ConversationMemoryOverflow(ValueError):
    """The complete user facts cannot fit without silently discarding a goal."""


def _validated_history(history):
    if not isinstance(history, list):
        raise ValueError("持久对话历史格式无效，请检查 conversation.json。")
    for item in history:
        if (
            not isinstance(item, dict)
            or item.get("role") not in {"user", "assistant"}
            or not isinstance(item.get("content"), str)
        ):
            raise ValueError("持久对话历史包含无效角色或消息，请检查 conversation.json。")
    return history


def _users(history, max_user_bytes):
    users = [
        _turn(number, item)
        for number, item in enumerate(_validated_history(history), 1)
        if item["role"] == "user"
    ]
    size = sum(len(item["content"].encode("utf-8")) for item in users)
    if size > max_user_bytes:
        raise ConversationMemoryOverflow(
            f"连续对话中的用户原文共 {size} 字节，超过 {max_user_bytes} 字节记忆上限；"
            "本次未发送模型请求，也没有静默删去最初目标。完整记录仍保存在项目 conversation.json；"
            "请整理需求后在新项目继续。"
        )
    return users, size


def _turn(number, item):
    value = {"turn": number, "content": item["content"]}
    for key in ("stage", "event", "turn_id", "timestamp", "source", "historical"):
        if key not in item:
            continue
        metadata = item[key]
        if not isinstance(metadata, (str, int, float, bool, type(None))) or (
            isinstance(metadata, str) and len(metadata.encode("utf-8")) > 256
        ) or (isinstance(metadata, float) and not math.isfinite(metadata)):
            raise ValueError("持久对话历史包含无效阶段元数据，请检查 conversation.json。")
        value[key] = metadata
    return value


def build_conversation_memory(
    history,
    *,
    max_user_bytes=MAX_USER_BYTES,
    max_assistant_bytes=MAX_ASSISTANT_BYTES,
    max_assistant_messages=MAX_ASSISTANT_MESSAGES,
):
    """Return exact user turns and explicitly bounded recent assistant results."""
    for value in (max_user_bytes, max_assistant_bytes, max_assistant_messages):
        if type(value) is not int or value < 0:
            raise ValueError("Conversation memory limits must be non-negative integers")
    users, user_bytes = _users(history, max_user_bytes)
    assistants = [
        {**_turn(number, item), "truncated": False}
        for number, item in enumerate(history, 1)
        if item["role"] == "assistant"
    ]
    selected = []
    remaining = max_assistant_bytes
    # Keep the latest real outcome first; long plans cannot evict a newer error.
    substantive = [item for item in assistants if item.get("event") != "status"]
    candidates = (substantive or assistants)[-max_assistant_messages:] if max_assistant_messages else []
    for item in reversed(candidates):
        raw = item["content"].encode("utf-8")
        if len(raw) > remaining:
            notice_size = len(TRUNCATION_NOTICE.encode("utf-8"))
            if remaining <= notice_size:
                break
            tail = raw[-(remaining - notice_size):].decode("utf-8", errors="ignore")
            item = {**item, "content": TRUNCATION_NOTICE + tail, "truncated": True}
        selected.insert(0, item)
        remaining -= len(item["content"].encode("utf-8"))
        if remaining == 0:
            break
    return {
        "schema_version": 1,
        "authority": MEMORY_AUTHORITY,
        "user_messages": users,
        "user_bytes": user_bytes,
        "user_byte_limit": max_user_bytes,
        "recent_assistant_results": selected,
        "assistant_results_omitted": len(assistants) - len(selected),
        "assistant_byte_limit": max_assistant_bytes,
    }


def user_context(history, *, max_user_bytes=MAX_USER_BYTES):
    """Exact chronological user statements for input resolution, never approvals.

    Assistant guesses, tool output and error text are deliberately excluded from
    the input resolver's source declarations. Callers must still use only the
    current actual message for any approval or cancellation decision.
    """
    if type(max_user_bytes) is not int or max_user_bytes < 0:
        raise ValueError("Conversation memory limits must be non-negative integers")
    users, _ = _users(history, max_user_bytes)
    return "\n\n".join(item["content"] for item in users)


def merge_task_outcomes(history, outcomes):
    """Fill missing terminal diagnostics without dispatching historical messages.

    The task manager supplies these facts from its durable journal. Free-form
    summaries are deliberately ignored, and existing substantive turn results
    take precedence. Return a new list so a malformed batch cannot partly mutate
    the persisted conversation.
    """
    _validated_history(history)
    if not isinstance(outcomes, list) or len(outcomes) > MAX_TASK_OUTCOMES:
        raise ValueError("Invalid prior task outcomes")
    for outcome in outcomes:
        if (
            not isinstance(outcome, dict)
            or not {"task_id", "status", "stage"} <= outcome.keys()
            or outcome.keys() - {"task_id", "status", "stage", "summary"}
            or not isinstance(outcome.get("task_id"), str)
            or not re.fullmatch(r"[a-f0-9]{32}", outcome["task_id"])
            or not isinstance(outcome.get("status"), str)
            or outcome["status"] not in TASK_TERMINAL_STATUSES
            or type(outcome.get("stage")) is not int
            or not 1 <= outcome["stage"] <= 6
        ):
            raise ValueError("Invalid prior task outcome")
    result = list(history)
    for outcome in outcomes:
        task_id = outcome["task_id"]
        if any(
            item["role"] == "assistant"
            and item.get("turn_id") == task_id
            and item.get("event") not in {"status", "progress"}
            and item["content"].strip()
            for item in result
        ):
            continue
        result.append({
            "role": "assistant",
            "event": "task_outcome",
            "stage": outcome["stage"],
            "turn_id": task_id,
            "historical": True,
            "source": "harness_task_manager",
            "timestamp": datetime.now(UTC).isoformat(),
            "content": (
                f"任务记录补充：先前任务 {task_id[:8]} {TASK_TERMINAL_STATUSES[outcome['status']]}；"
                "该轮没有保存完整回复，不能据此认定阶段已经完成。"
                "先前目标和已保存结果仍保留；继续前应核对当前项目阶段与验收记录。"
                "这只是历史诊断，不会自动重试或重放执行批准。"
            ),
        })
    return result


def pending_design_questions(state):
    """Read explicit questions, with a conservative fallback for older sessions."""
    if "pending_questions" in state:
        questions = state["pending_questions"]
        return [q for q in questions if isinstance(q, str) and q.strip()] if isinstance(questions, list) else []
    if not state.get("awaiting_clarification") or state.get("draft"):
        return []
    for item in reversed(state.get("history", [])):
        if item.get("role") != "assistant" or item.get("event") == "status":
            continue
        if item.get("event") == "plan" and item.get("stage") in (2, 3):
            text = item.get("content")
            return [text] if isinstance(text, str) and text.strip() else []
        break
    return []
