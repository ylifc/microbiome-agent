"""Verify a bundle and an installed runtime without model accounts or scientific downloads.

Run with the standard library of any Python 3.11+ interpreter. --python is the
newly installed runtime's Python, whose venv must not inherit system packages.
Alternatively --prefix locates that Python through the managed install marker.
The report and synthetic examples are written only into a new --output directory.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

PUBLIC_LAUNCHERS = ("microbiome", "biomni", "microbiome-run", "microbiome-service", "microbiome-mcp")


def validate_launchers(prefix, runtime, marker):
    """Check the public commands users actually invoke, not only venv imports."""
    for name in PUBLIC_LAUNCHERS:
        command = prefix / "bin" / name
        target = runtime / "bin" / name
        if (marker.get("launchers", {}).get(name) != str(target)
                or not command.is_symlink() or not target.is_file()
                or command.resolve() != target.resolve() or not os.access(command, os.X_OK)):
            raise ValueError(f"Managed launcher missing or changed: {name}")


def sha256(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def verify_manifest(bundle):
    manifest = json.loads((bundle / "manifest.json").read_text())
    declared = manifest.get("files")
    if not isinstance(declared, dict) or not declared:
        raise ValueError("Release manifest has no file inventory")
    for name, expected in declared.items():
        relative = Path(name)
        path = bundle / relative
        if (relative.is_absolute() or ".." in relative.parts or path.is_symlink()
                or not path.resolve().is_relative_to(bundle) or not path.is_file()):
            raise ValueError(f"Invalid release path: {name}")
        if sha256(path) != expected:
            raise ValueError(f"Release checksum mismatch: {name}")
    actual = {str(path.relative_to(bundle)) for path in bundle.rglob("*") if path.is_file()}
    if actual != set(declared) | {"manifest.json"}:
        raise ValueError("Release contains files absent from its manifest")
    return manifest


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", required=True, type=Path)
    runtime_choice = parser.add_mutually_exclusive_group(required=True)
    runtime_choice.add_argument("--python", type=Path)
    runtime_choice.add_argument("--prefix", type=Path, help="Managed prefix created by this release's installer")
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args(argv)
    bundle = args.bundle.expanduser().resolve()
    # Resolving this symlink would select the base interpreter instead of the venv.
    if args.prefix:
        prefix = args.prefix.expanduser().resolve()
        marker = json.loads((prefix / ".microbiome-portable.json").read_text())
        if (marker.get("format") != "microbiome-portable-v1" or not marker.get("enabled")
                or marker.get("prefix") != str(prefix)):
            parser.error("--prefix is not an active managed Microbiome installation")
        runtime = Path(marker["runtime"])
        if not runtime.resolve().is_relative_to(prefix / "runtimes"):
            parser.error("Managed runtime lies outside its installation prefix")
        python = runtime / "bin/python"
    else:
        python = args.python.expanduser().absolute()
    output = args.output.expanduser().absolute()
    if output.is_symlink() or output.resolve().is_relative_to(bundle):
        parser.error("--output must be a new directory outside the checksummed bundle")
    output.mkdir(parents=True, exist_ok=False)
    report = {"schema_version": 1, "status": "RUNNING", "bundle": str(bundle),
              "runtime_python": str(python), "checked_at": datetime.now(timezone.utc).isoformat(),
              "checks": [], "scope": "synthetic computational smoke tests; no real biological validation"}
    env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "LANG": "C.UTF-8",
           "PYTHONNOUSERSITE": "1", "PYTHONPATH": ""}

    def run(label, arguments, *, as_json=False, executable=None):
        result = subprocess.run([str(executable or python), *arguments], cwd=output, env=env,
                                text=True, capture_output=True, timeout=90)
        (output / (label + ".stdout.log")).write_text(result.stdout)
        (output / (label + ".stderr.log")).write_text(result.stderr)
        report["checks"].append({"name": label, "returncode": result.returncode})
        if result.returncode:
            raise RuntimeError(f"{label} failed; inspect its logs")
        payload = json.loads(result.stdout) if as_json else result.stdout
        if isinstance(payload, dict) and payload.get("ok") is False:
            raise RuntimeError(f"{label} returned a failed operation")
        return payload

    try:
        manifest = verify_manifest(bundle)
        report["manifest_sha256"] = sha256(bundle / "manifest.json")
        report["file_count"] = len(manifest["files"])
        identity = run("installed_identity", ["-I", "-c", "import json,sys,pathlib,microbiome; "
            "print(json.dumps({'module':microbiome.__file__,'prefix':sys.prefix,'base_prefix':sys.base_prefix,"
            "'python':sys.version,'venv_config':(pathlib.Path(sys.prefix)/'pyvenv.cfg').read_text()}))"], as_json=True)
        if (identity["prefix"] == identity["base_prefix"]
                or "include-system-site-packages = false" not in identity["venv_config"].lower()
                or not Path(identity["module"]).resolve().is_relative_to(Path(identity["prefix"]).resolve())):
            raise RuntimeError("Expected an isolated installed venv, not the source tree or inherited packages")
        report["installed_identity"] = identity
        if args.prefix:
            validate_launchers(prefix, runtime, marker)
            public_bin = prefix / "bin"
        else:
            public_bin = Path(identity["prefix"]) / "bin"
        for name in PUBLIC_LAUNCHERS:
            arguments = (["--help"] if name == "microbiome-mcp" else
                         ["call", "catalog.list"] if name == "microbiome-service" else ["doctor"])
            public = run("launcher_" + name, arguments, as_json=name != "microbiome-mcp",
                         executable=public_bin / name)
            if name == "microbiome-service" and not public.get("result", {}).get("workflows"):
                raise RuntimeError("Public service launcher did not return its workflow catalog")
            if name in {"microbiome", "biomni", "microbiome-run"} and (
                    public.get("model_connection") != "NOT_REQUESTED" or not public.get("ok")):
                raise RuntimeError(f"Public launcher failed its host-owned doctor: {name}")
        report["installed_source_match"] = run("installed_source_match", ["-I", "-c", """
import hashlib, importlib.metadata, json, pathlib, sys
manifest = json.loads(pathlib.Path(sys.argv[1]).read_text())
distribution = importlib.metadata.distribution('microbiome')
expected = {name: checksum for name, checksum in manifest['source']['files'].items()
            if name.startswith(('microbiome/', 'microbiome_env/'))}
mismatch = [name for name, checksum in expected.items()
            if not distribution.locate_file(name).is_file()
            or hashlib.sha256(distribution.locate_file(name).read_bytes()).hexdigest() != checksum]
print(json.dumps({'files': len(expected), 'mismatched': mismatch}))
sys.exit(1 if mismatch else 0)
""", str(bundle / "manifest.json")], as_json=True)
        run("pip_check", ["-I", "-m", "pip", "check"])
        doctor = run("doctor", ["-I", "-m", "microbiome.cli", "doctor"], as_json=True)
        if not doctor.get("ok") or doctor.get("model_connection") != "NOT_REQUESTED":
            raise RuntimeError("Doctor attempted a model connection or failed")
        catalog = run("catalog", ["-I", "-m", "microbiome.cli", "call", "catalog.list"], as_json=True)
        report["catalog"] = {"workflows": len(catalog["result"]["workflows"]),
                             "software_skills": doctor["software_skills"], "database_skills": doctor["database_skills"]}
        for host in ("codex", "vscode", "workbuddy"):
            run("export_" + host, ["-I", "-m", "microbiome.cli", "export", "--host", host,
                                   "--output", str(output / (host + "-adapter"))], as_json=True)
        raw = output / "raw"
        raw.mkdir()
        run("init", ["-I", "-m", "microbiome.cli", "init", "--project", str(output / "project"),
                     "--raw-data", str(raw), "--database", str(output / "databases"),
                     "--output", str(output / "results")], as_json=True)
        project = run("project", ["-I", "-m", "microbiome.cli", "call", "project.inspect", "--json",
                                  json.dumps({"project": str(output / "project")})], as_json=True)
        if project["result"]["project"] != str(output / "project"):
            raise RuntimeError("Project was not bound to the requested directory")
        demo = bundle / "examples/portable_demo/run_demo.py"
        if not demo.is_file():
            raise RuntimeError("Bundle is missing its deterministic sequence demo")
        demonstration = run("sequence_demo", ["-I", str(demo), "--output", str(output / "sequence-demo")], as_json=True)
        if demonstration.get("status") != "PASSED":
            raise RuntimeError("Sequence demonstration did not pass")
        report["sequence_demo"] = demonstration
        report["status"] = "PASSED"
    except Exception as error:
        report["status"] = "FAILED"
        report["error"] = {"type": type(error).__name__, "message": str(error)}
    (output / "verification.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"status": report["status"], "report": str(output / "verification.json")}, ensure_ascii=False))
    return 0 if report["status"] == "PASSED" else 1


if __name__ == "__main__":
    raise SystemExit(main())
