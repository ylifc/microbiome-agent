"""Install the host-owned workflow service in a dedicated, user-owned Python runtime."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import uuid

FORMAT = "microbiome-portable-v1"
MARKER = ".microbiome-portable.json"
COMMANDS = ("microbiome", "biomni", "microbiome-run", "microbiome-service", "microbiome-mcp")
EXPECTED_ENTRYPOINTS = {
    "microbiome": "microbiome.cli:main",
    "biomni": "microbiome.cli:main",
    "microbiome-run": "microbiome.cli:main",
    "microbiome-service": "microbiome.integrations.cli:main",
    "microbiome-mcp": "microbiome.integrations.mcp_server:main",
    "microbiome-legacy-run": "microbiome.legacy_cli:main",
}


def run(argv, **kwargs):
    return subprocess.run([str(value) for value in argv], check=True, **kwargs)


def bundle_spec(root, offline=False):
    """Accept a local source checkout or a checksummed existing release layout."""
    root = root.expanduser().resolve()
    manifest_path = root / "manifest.json"
    manifest = None
    if manifest_path.is_file():
        manifest = json.loads(manifest_path.read_text())
        if manifest.get("protocol") != 1 and manifest.get("format") not in {
            "biomni-standalone-v1", FORMAT,
        }:
            raise ValueError("Unsupported release manifest")
        if not isinstance(manifest.get("files"), dict) or not manifest["files"]:
            raise ValueError("Release manifest must contain checked files")
        for name, digest in manifest["files"].items():
            path = root / name
            if (path.is_symlink() or not path.resolve().is_relative_to(root) or not path.is_file()
                    or hashlib.sha256(path.read_bytes()).hexdigest() != digest):
                raise ValueError(f"Release checksum/path mismatch: {name}")
        candidates = [*root.glob("wheels/microbiome-*.whl"), *root.glob("microbiome_agent/microbiome-*.whl")]
        if len(candidates) != 1 or str(candidates[0].relative_to(root)) not in manifest["files"]:
            raise ValueError("Release must declare exactly one Microbiome wheel")
        package = candidates[0]
    else:
        import tomllib
        project = root / "pyproject.toml"
        if not project.is_file() or tomllib.loads(project.read_text()).get("project", {}).get("name") != "microbiome":
            raise ValueError("Expected a Microbiome source checkout or checksummed release bundle")
        if offline:
            raise ValueError("Offline installation requires a checksummed wheel bundle")
        package = root
    wheels = next((path for path in (root / "wheelhouse", root / "requirements/wheelhouse") if path.is_dir()), None)
    constraints = next((path for path in (root / "requirements.lock", root / "requirements/requirements.lock") if path.is_file()), None)
    if manifest and constraints and str(constraints.relative_to(root)) not in manifest["files"]:
        raise ValueError("Release constraints are not covered by the integrity manifest")
    if offline and wheels is None:
        raise ValueError("Offline dependencies are missing from this release")
    if manifest and offline:
        for dependency in wheels.glob("*.whl"):
            if str(dependency.relative_to(root)) not in manifest["files"]:
                raise ValueError(f"Undeclared offline wheel: {dependency.name}")
    return package, wheels, constraints, manifest


def _owned_state(prefix):
    marker = prefix / MARKER
    if prefix.exists() and not marker.is_file():
        raise ValueError("Refusing to use an unmanaged existing directory; choose a new --prefix")
    state = json.loads(marker.read_text()) if marker.is_file() else None
    if state and (state.get("format") != FORMAT or state.get("prefix") != str(prefix.resolve())):
        raise ValueError("Installation ownership marker mismatch")
    return state


def _check_launchers(prefix, state):
    for name in COMMANDS:
        path = prefix / "bin" / name
        if path.exists() or path.is_symlink():
            expected = (state or {}).get("launchers", {}).get(name)
            if not expected or not path.is_symlink() or str(path.readlink()) != expected:
                raise ValueError(f"Refusing to replace an unrelated launcher: {path}")


def _summary(prefix, state):
    return {"installed": str(prefix / "bin/microbiome"), "runtime": state.get("runtime"),
            "model_owner": "host", "model_configuration_required": False,
            "path_hint": f"Add {prefix / 'bin'} to PATH if desired; no shell files were changed",
            "next": f"{prefix / 'bin/microbiome'} export --host codex --output /new/host-integration-directory",
            "other_hosts": "Use --host vscode or --host workbuddy; inspect the exported settings before importing"}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--prefix", type=Path, default=Path.home() / ".local/share/microbiome-runtime")
    parser.add_argument("--python", default=sys.executable)
    parser.add_argument("--offline", action="store_true", help="Use only the release's verified dependency wheels")
    action = parser.add_mutually_exclusive_group()
    action.add_argument("--upgrade", action="store_true", help="Build a new runtime and switch managed launchers after validation")
    action.add_argument("--uninstall", action="store_true", help="Disable managed launchers; retain runtimes and all user data")
    args = parser.parse_args(argv)
    prefix = args.prefix.expanduser().absolute()
    if prefix.is_symlink() or prefix.resolve() in {Path("/"), Path.home().resolve(), Path(sys.prefix).resolve()}:
        raise ValueError("Unsafe installation prefix")
    state = _owned_state(prefix)
    _check_launchers(prefix, state)
    if args.uninstall:
        if state:
            for name in COMMANDS:
                path = prefix / "bin" / name
                if path.is_symlink():
                    path.unlink()
            state["enabled"] = False
            (prefix / MARKER).write_text(json.dumps(state, indent=2))
        print(json.dumps({"uninstalled": bool(state), "retained": str(prefix), "projects_and_host_settings": "unchanged"}))
        return 0
    if state and state.get("enabled") and not args.upgrade:
        print(json.dumps({**_summary(prefix, state), "status": "already_installed", "upgrade": "Pass --upgrade to replace the managed runtime"}, indent=2))
        return 0
    if args.upgrade and not state:
        raise ValueError("No managed installation to upgrade")
    package, wheels, constraints, manifest = bundle_spec(args.bundle, args.offline)
    probe = run([args.python, "-c", "import sys,platform,json;print(json.dumps({'version':list(sys.version_info[:2]),'machine':platform.machine(),'platform':sys.platform}))"], capture_output=True, text=True)
    runtime_info = json.loads(probe.stdout)
    minimum = [3, 11]
    if manifest and manifest.get("release_python_min"):
        minimum = list(map(int, manifest["release_python_min"].split(".")[:2]))
    if runtime_info["version"] < minimum:
        raise ValueError(f"Python {'.'.join(map(str, minimum))}+ is required")
    if args.offline:
        expected_version = (manifest.get("build_python") or manifest.get("python") or "").split(".")[:2]
        expected_machine = manifest.get("architecture") or manifest.get("machine")
        expected_platform = manifest.get("sys_platform")
        if (not expected_version or runtime_info["version"] != list(map(int, expected_version))
                or runtime_info["machine"] != expected_machine
                or (expected_platform and runtime_info["platform"] != expected_platform)
                or (not expected_platform and not runtime_info["platform"].startswith("linux"))):
            raise ValueError("Offline bundle requires its build Python minor version, OS and architecture")
    prefix.mkdir(parents=True, exist_ok=True, mode=0o700)
    if not state:
        state = {"format": FORMAT, "prefix": str(prefix.resolve()), "enabled": False, "launchers": {}, "runtimes": []}
        (prefix / MARKER).write_text(json.dumps(state, indent=2))
    runtime = prefix / "runtimes" / uuid.uuid4().hex
    runtime.parent.mkdir(exist_ok=True)
    # Build at its final path: Python entrypoint shebangs contain absolute paths.
    run([args.python, "-m", "venv", runtime])
    python = runtime / "bin/python"
    command = [python, "-m", "pip", "install", "--disable-pip-version-check"]
    if args.offline:
        command += ["--no-index", "--find-links", wheels]
    if constraints:
        command += ["--constraint", constraints]
    run([*command, package])
    # Older bundles exposed a standalone model runner at microbiome.cli.
    # Reject those artifacts before invoking any application entrypoint.
    for name in COMMANDS:
        if not (runtime / "bin" / name).is_file():
            raise ValueError(f"Installed wheel lacks the portable entrypoint {name}; rebuild the bundle; previous launchers retained")
    # Inspect distribution metadata through the standard library only. A prior
    # generation may already have all launchers while cli.main still starts a
    # standalone model; importing or invoking application code is premature.
    metadata = run([
        python, "-c",
        "import importlib.metadata as m,json; "
        "print(json.dumps({e.name:e.value for e in m.distribution('microbiome').entry_points "
        "if e.group=='console_scripts'}))",
    ], cwd=runtime, env={**os.environ, "PYTHONPATH": ""}, capture_output=True, text=True, timeout=30)
    installed_entrypoints = json.loads(metadata.stdout)
    if (not isinstance(installed_entrypoints, dict)
            or any(installed_entrypoints.get(name) != expected for name, expected in EXPECTED_ENTRYPOINTS.items())):
        raise ValueError("Installed wheel has incompatible console entrypoint mappings; rebuild the bundle; previous launchers retained")
    smoke = run([python, "-m", "microbiome.cli", "doctor"], cwd=runtime,
                env={**os.environ, "PYTHONPATH": ""}, capture_output=True, text=True, timeout=60)
    (runtime / "installation-check.json").write_text(smoke.stdout)
    report = json.loads(smoke.stdout)
    if not report.get("ok") or report.get("model_owner") != "host":
        raise ValueError("Installed portable service validation failed; previous launchers retained")
    run([python, "-m", "pip", "check"], cwd=runtime)
    (prefix / "bin").mkdir(exist_ok=True)
    for name in COMMANDS:
        target = runtime / "bin" / name
        temporary = prefix / "bin" / (".install-" + uuid.uuid4().hex)
        temporary.symlink_to(target)
        temporary.replace(prefix / "bin" / name)
        state["launchers"][name] = str(target)
    state.update(enabled=True, runtime=str(runtime), model_owner="host")
    state["runtimes"].append(str(runtime))
    (prefix / MARKER).write_text(json.dumps(state, indent=2))
    print(json.dumps(_summary(prefix, state), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, OSError, RuntimeError, subprocess.SubprocessError) as error:
        print(f"Microbiome installation failed: {error}", file=sys.stderr)
        raise SystemExit(1)
