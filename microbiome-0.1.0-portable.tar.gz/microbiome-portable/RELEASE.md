# Microbiome 0.1.0 portable release

The existing host owns the model; no provider credentials or private host settings are copied.

Run `bash install.sh --prefix /new/user-owned/runtime`. Use `upgrade.sh` for an existing managed prefix; `uninstall.sh` disables owned launchers and retains runtimes/data. Set `MICROBIOME_INSTALL_PYTHON` to choose Python.

Dependency mode: online; pip resolves requirements at install time. Build platform: Python 3.12.3, linux, x86_64. Offline wheels require that Python minor version/OS/architecture. Source supports Python 3.11+, but other platforms have not been validated by this build.

`source/` contains the allowlisted source, tests, scripts, docs and examples. `skills/`, `workflows/` and `integrations/templates/` are exact source mirrors. `catalog/` and `manifest.json` record inventories and hashes. Skills describe capabilities, not installed or READY scientific resources. No actual scientific tools, databases, local registries, input datasets, credentials, user-home Skills, or software_memory history are included. Synthetic fixtures/examples remain part of source tests. Legacy library/harness source is retained only for compatibility.

For a same-platform offline source rebuild, create a build venv, install `build-requirements.in` with `pip install --no-index --find-links wheelhouse -c requirements.lock -r build-requirements.in`, then install `requirements.in` with the same flags (the catalog audit needs runtime imports). Run `python source/scripts/build_portable_release.py --output /new/release --offline-deps --wheel-cache wheelhouse --no-index`. For an online release, omit the offline/cache flags. Every output must be new or empty.
